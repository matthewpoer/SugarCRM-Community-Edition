<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): SYNOLIA TEAM - contactsugar@synolia.fr / http://www.synolia.fr
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Opportunities/language/en_us.lang.php,v 1.10 2004/08/03 07:43:19 sugarclint Exp $
 * Description:  Defines the English language pack for the Account module.
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_MODULE_NAME'=>'Opportunit�s',
'LBL_MODULE_TITLE'=>'Opportunit�s: Accueil',
'LBL_SEARCH_FORM_TITLE'=>'Recherche Opportunit�',
'LBL_LIST_FORM_TITLE'=>'Liste des Opportunit�s',
'LBL_OPPORTUNITY_NAME'=>"Nom de l'Opportunit�:",
'LBL_OPPORTUNITY'=>'Opportunit�:',
'LBL_NAME'=>"Nom de l'Opportunit�",

'LBL_LIST_OPPORTUNITY_NAME'=>'Opportunit�',
'LBL_LIST_ACCOUNT_NAME'=>'Nom du Compte',
'LBL_LIST_AMOUNT'=>'Montant',
'LBL_LIST_DATE_CLOSED'=>'Date de cl�ture',
'LBL_LIST_SALES_STAGE'=>'Phase de vente',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_sales_stage' => 'LBL_LIST_SALES_STAGE',
  'db_name' => 'LBL_NAME',
  'db_amount' => 'LBL_LIST_AMOUNT',
  'db_date_closed' => 'LBL_LIST_DATE_CLOSED',
//END DON'T CONVERT
  'UPDATE' => 'Opportunit� - Mise � jour devise',
  'UPDATE_DOLLARAMOUNTS' => 'Mise � jour montants US DOLLARS ',
  'UPDATE_VERIFY' => 'Verifier les montants',
  'UPDATE_VERIFY_TXT' => 'Verifier que les valeurs des montants dans les opportunit�s soient valides au niveau des d�cimales avec seulement des caract�res num�riques(0-9) et d�cimales(.)',
  'UPDATE_FIX' => 'Correction des Montants ',
  'UPDATE_FIX_TXT' => "Tentative de correction de montants invalides en cr�ant une valeur d�cimale valide pour le montant actuel. Les montants modifi�s seront sauvegard�s dans la bases
   dans un champ amount_backup. Si vous constatez des probl�mes, ne reexecutez pas la correction sinon les donn�es sauvegard�es seront �cras�es.",
  'UPDATE_DOLLARAMOUNTS_TXT' => 'Mise � jour des montants en $ US pour les opportunit�s bas� sur le taux de change actuel. Cette valeur est utilis�e pour r�alisr les graphs et vues par listes.',
  'UPDATE_CREATE_CURRENCY' => 'Cr�er une nouvelle devise:',
  'UPDATE_VERIFY_FAIL' => "Echec de v�rification de l'enregistrement:",
  'UPDATE_VERIFY_CURAMOUNT' => 'Montant devise:',
  'UPDATE_VERIFY_FIX' => 'Lancer la correction permettrait',
  'UPDATE_INCLUDE_CLOSE' => 'Inclure enregistrements clos',
  'UPDATE_VERIFY_NEWAMOUNT' => 'Nouveau montant:',
  'UPDATE_VERIFY_NEWCURRENCY' => 'Nouvelle devise:',
  'UPDATE_DONE' => 'Modification effectu�e',
  'UPDATE_ISSUE_COUNT' => 'Erreurs trouv�es tentative de r�solution:',
  'UPDATE_ISSUEFOUND_COUNT' => 'Erreurs rencontr�es:',
  'UPDATE_COUNT' => 'Enregistrements mis � jour:',
  'UPDATE_RESTORE_COUNT' => 'Montants des enregistrements restaur�s:',
  'UPDATE_RESTORE' => 'Restauration des Montants',
  'UPDATE_RESTORE_TXT' => 'Restaurer les montants depuis le backup cr�er durant la correction.',
  'UPDATE_FAIL' => 'Mise � jour impossible - ',
  'UPDATE_NULL_VALUE' => 'Le montant est NULL, �tablissez le � 0 -',
  'UPDATE_MERGE' => 'Fusion des devises',
  'UPDATE_MERGE_TXT' => 'Fusionner plusieurs devises en une seule. ',
  
'LBL_OPPORTUNITY_NAME'=>"Nom de l'Opportunit�:",
'LBL_ACCOUNT_NAME'=>'Nom du Compte:',
'LBL_AMOUNT'=>'Montant:',
'LBL_DATE_CLOSED'=>'date de cl�ture:',
'LBL_TYPE'=>'Type:',
'LBL_NEXT_STEP'=>'prochaine �tape:',
'LBL_LEAD_SOURCE'=>'Source du Lead:',
'LBL_SALES_STAGE'=>'Phase de vente:',
'LBL_PROBABILITY'=>'Probabilit� (%):',
'LBL_DESCRIPTION'=>'Description:',


'LBL_NEW_FORM_TITLE'=>'Nouveau Compte',
'LNK_NEW_CONTACT'=>'Nouveau Contact',
'LNK_NEW_ACCOUNT'=>'Nouveau Compte',
'LNK_NEW_OPPORTUNITY'=>'Nouvelle Opportunit�',
'LNK_NEW_CASE'=>'Nouveau Ticket',
'LNK_NEW_NOTE'=>'Nouvelle Note',
'LNK_NEW_CALL'=>'Nouvel Appel',
'LNK_NEW_EMAIL'=>'Nouvel Email',
'LNK_NEW_MEETING'=>'Nouveau Rendez-vous',
'LNK_NEW_TASK'=>'Nouvelle T�che',

'ERR_DELETE_RECORD'=>"Un num�ro d'enregistrement doit �tre sp�cifi� pour supprimer l'Opportunit�.",
'LBL_TOP_OPPORTUNITIES'=>"Top des Opportunit�s",
'NTC_REMOVE_OPP_CONFIRMATION'=>'Etes vous sur de vouloir supprimer ce contact pour cette Opportunit� ? ',
'LBL_INVITEE'=>'Contacts',
 'LNK_OPPORTUNITY_LIST' => 'Opportunit�s',
);

?>
