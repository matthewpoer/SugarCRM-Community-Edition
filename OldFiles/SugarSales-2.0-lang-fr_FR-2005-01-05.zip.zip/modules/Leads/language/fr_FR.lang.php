<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * 
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and 
 * (ii) the SugarCRM copyright notice 
 * in the same form as they appear in the distribution.  See full license for requirements.
 * 
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): SYNOLIA TEAM - contactsugar@synolia.fr / http://www.synolia.fr
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/sugarcrm/modules/Leads/language/en_us.lang.php,v 1.14 2004/10/25 02:53:26 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): SYNOLIA TEAM - contactsugar@synolia.fr / http://www.synolia.fr
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Leads',
  'LBL_INVITEE' => 'Rapports directs',
  'LBL_MODULE_TITLE' => 'Leads: Accueil',
  'LBL_SEARCH_FORM_TITLE' => 'Recherche Lead',
  'LBL_LIST_FORM_TITLE' => 'Liste Leads',
  'LBL_NEW_FORM_TITLE' => 'Nouveau Lead',
  'LBL_CONTACT_OPP_FORM_TITLE' => 'Lead-Opportunit�:',
  'LBL_CONTACT' => 'Lead:',
  'LBL_BUSINESSCARD' => 'Convertir Lead',
  'LBL_LIST_NAME' => 'Nom',
  'LBL_LIST_LAST_NAME' => 'Nom',
  'LBL_LIST_CONTACT_NAME' => 'Nom Lead',
  'LBL_LIST_TITLE' => 'Titre',
  'LBL_LIST_ACCOUNT_NAME' => 'Nom Compte',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email',
  'LBL_LIST_PHONE' => 'T�l�phone',
  'LBL_LIST_CONTACT_ROLE' => 'Fonction',
  'LBL_LIST_FIRST_NAME' => 'Pr�nom',
  'LBL_LIST_REFERED_BY' => 'R�f�renc� par',
  'LBL_LIST_LEAD_SOURCE' => 'Source du Lead',
  'LBL_LIST_STATUS' => 'Statut',
  'LBL_LIST_DATE_ENTERED' => 'Date de cr�ation',
  'LBL_LIST_LEAD_SOURCE_DESCRIPTION' => 'Description Source du Lead',
  'LBL_LIST_MY_LEADS' => 'Mes Leads',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_account_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_email2' => 'LBL_LIST_EMAIL_ADDRESS',
//END DON'T CONVERT
  'LBL_EXISTING_CONTACT' => 'Utiliser un contact existant',
  'LBL_CREATED_CONTACT' => 'Cr�er un nouveau contact',
  'LBL_EXISTING_OPPORTUNITY' => 'Utiliser une opportunit� existante',
  'LBL_CREATED_OPPORTUNITY' => 'Cr�er une nouvelle opportunit�',
  'LBL_EXISTING_ACCOUNT' => 'Uutiliser un compte existant',
  'LBL_CREATED_ACCOUNT' => 'Cr�er un nouveau compte',
  'LBL_CREATED_CALL' => 'Cr�er un nouvel appel',
  'LBL_CREATED_MEETING' => 'Cr�er un nouveau rendez-vous',
  'LBL_BACKTOLEADS' => 'Retour aux Leads',
  'LBL_CONVERTLEAD' => 'Convert Lead',
  'LBL_NAME' => 'Nom:',
  'LBL_CONTACT_NAME' => 'Nom Lead:',
  'LBL_CONTACT_INFORMATION' => 'Informations sur le Lead',
  'LBL_FIRST_NAME' => 'Pr�nom:',
  'LBL_OFFICE_PHONE' => 'T�l�phone bureau:',
  'LBL_ACCOUNT_NAME' => 'Nom Compte:',
  'LBL_OPPORTUNITY_NAME' => 'Nom Opportunit�:',
  'LBL_OPPORTUNITY_AMOUNT' => 'Montant Opportunit�:',
  'LBL_ANY_PHONE' => 'Autre T�l�phone:',
  'LBL_PHONE' => 'T�l�phone:',
  'LBL_LAST_NAME' => 'Nom:',
  'LBL_MOBILE_PHONE' => 'T�l�phone Mobile:',
  'LBL_HOME_PHONE' => 'T�l�phone personnel:',
  'LBL_LEAD_SOURCE' => 'Source du Lead:',
  'LBL_STATUS' => 'Statut:',
  'LBL_LEAD_SOURCE_DESCRIPTION' => 'Description source du Lead:',
  'LBL_STATUS_DESCRIPTION' => 'Description Statut:',
  'LBL_OTHER_PHONE' => 'Autre T�l�phone:',
  'LBL_FAX_PHONE' => 'Fax:',
  'LBL_TITLE' => 'Civilit�:',
  'LBL_DEPARTMENT' => 'Division:',
  'LBL_EMAIL_ADDRESS' => 'Email:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Autre Email:',
  'LBL_ANY_EMAIL' => 'Email:',
  'LBL_REPORTS_TO' => 'Rend compte � :',
  'LBL_DO_NOT_CALL' => 'Ne pas appeler:',
  'LBL_EMAIL_OPT_OUT' => 'Ne pas prospecter par mail:',
  'LBL_PRIMARY_ADDRESS' => 'Adresse principale:',
  'LBL_ALTERNATE_ADDRESS' => 'Autre Adresse:',
  'LBL_ANY_ADDRESS' => 'Autre Adresse:',
  'LBL_REFERED_BY' => 'R�f�renc� par:',
  'LBL_CITY' => 'Ville:',
  'LBL_STATE' => 'Etat:',
  'LBL_POSTAL_CODE' => 'Code Postal:',
  'LBL_COUNTRY' => 'Pays:',
  'LBL_DESCRIPTION_INFORMATION' => 'Information Description',
  'LBL_ADDRESS_INFORMATION' => 'Information Adresse',
  'LBL_DESCRIPTION' => 'Description:',
  'LBL_CONTACT_ROLE' => 'Fonction:',
  'LBL_OPP_NAME' => 'Nom Opportunit�:',
  'LBL_IMPORT_VCARD' => 'Importer vCard',
  'LNK_IMPORT_VCARD' => 'Cr�er depuis vCard',
  'LBL_IMPORT_VCARDTEXT' => 'Cr�er automatiquement un nouveau Lead par import de vCard depuis votre syst�me.',
  'LBL_DUPLICATE' => 'Leads Similaires',
  'MSG_DUPLICATE' => 'Des Leads similaires ont �t� trouv�. Merci de v�rifier les Leads que vous souhaitez associer avec les enregistrements qui vont �tre cr��s lors de cette conversion. Une fois cette v�rification effectu�e, cliquez sur suivant.',
  'LBL_ADD_BUSINESSCARD' => 'Ajouter Business Card',
  'LNK_NEW_APPOINTMENT' => 'Cr�er Rendez-vous',
  'LNK_NEW_LEAD' => 'Cr�er Lead',
  'LNK_LEAD_LIST' => 'Leads',
  'NTC_DELETE_CONFIRMATION' => 'Etes vous s�r de vouloir supprimer cet enregistrement ?',
  'NTC_REMOVE_CONFIRMATION' => 'Etes vous s�r de vouloir supprimer ce Lead de ce ticket?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Etes vous s�r de vouloir supprimer cet enregistrement pour le rapport direct ?',
  'ERR_DELETE_RECORD' => "Un num�ro d'enregistrement doit �tre sp�cifi� pour supprimer ce lead.",
  'NTC_COPY_PRIMARY_ADDRESS' => "Copier l'adresse principale sur l'adresse secondaire",
  'NTC_COPY_ALTERNATE_ADDRESS' => "Copier l'adresse secondaire sur l'adresse principale",
  'LNK_NEW_CONTACT' => 'Cr�er Contact',
  'LNK_NEW_NOTE' => 'Cr�er Note',
  'LNK_NEW_ACCOUNT' => 'Cr�er Compte',
  'LNK_NEW_OPPORTUNITY' => 'Cr�er Opportunit�',
  'LNK_SELECT_ACCOUNT' => 'Selectionner Compte',
  'LBL_SALUTATION' => 'Salutation',
);


?>
