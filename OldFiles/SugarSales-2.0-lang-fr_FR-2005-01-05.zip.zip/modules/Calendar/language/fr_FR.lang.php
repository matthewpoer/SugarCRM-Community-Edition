<?php
/*********************************************************************************
 *The contents of this file are subject to the SugarCRM Professional End User License Agreement 
 *("License") which can be viewed at http://www.sugarcrm.com/EULA.  
 *By installing or using this file, You have unconditionally agreed to the terms and conditions of the License, and You may 
 *not use this file except in compliance with the License. Under the terms of the license, You 
 *shall not, among other things: 1) sublicense, resell, rent, lease, redistribute, assign or 
 *otherwise transfer Your rights to the Software, and 2) use the Software for timesharing or 
 *service bureau purposes such as hosting the Software for commercial gain and/or for the benefit 
 *of a third party.  Use of the Software may be subject to applicable fees and any use of the 
 *Software without first paying applicable fees is strictly prohibited.  You do not have the 
 *right to remove SugarCRM copyrights from the source code or user interface. 
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and 
 * (ii) the SugarCRM copyright notice 
 * in the same form as they appear in the distribution.  See full license for requirements.
 *Your Warranty, Limitations of liability and Indemnity are expressly stated in the License.  Please refer 
 *to the License for the specific language governing these rights and limitations under the License.
 *Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.; All Rights Reserved.  
 *Contributor(s): SYNOLIA TEAM - contactsugar@synolia.com / http://www.synolia.fr
 ********************************************************************************/

$mod_strings = array (
  'LNK_NEW_CALL' => 'Cr�er un Appel',
  'LNK_NEW_MEETING' => 'Cr�er une R�union',
  'LNK_NEW_APPOINTMENT' => 'Cr�er un Rendez-vous',
  'LNK_NEW_TASK' => 'Cr�er une T�che',
  'LNK_CALL_LIST' => 'Appels',
  'LNK_MEETING_LIST' => 'r�unions',
  'LNK_TASK_LIST' => 'T�ches',
  'LNK_VIEW_CALENDAR' => 'Aujourd\'hui',
  'LBL_MONTH' => 'Mois',
  'LBL_DAY' => 'Jour',
  'LBL_YEAR' => 'Ann�e',
  'LBL_WEEK' => 'Semaine',
  'LBL_PREVIOUS_MONTH' => 'Mois pr�c�dent',
  'LBL_PREVIOUS_DAY' => 'Jour pr�c�dent',
  'LBL_PREVIOUS_YEAR' => 'Ann�e pr�c�dente',
  'LBL_PREVIOUS_WEEK' => 'PSemaine pr�c�dente',
  'LBL_NEXT_MONTH' => 'Mois suivant',
  'LBL_NEXT_DAY' => 'Jour suivant',
  'LBL_NEXT_YEAR' => 'Ann�e suivante',
  'LBL_NEXT_WEEK' => 'Semaine suivante',
  'LBL_AM' => 'Matin',
  'LBL_PM' => 'Apr�s-midi',
);

$mod_list_strings = array (
  'dom_cal_weekdays' => 
  array (
    0 => 'Dim',
    1 => 'Lun',
    2 => 'Mar',
    3 => 'Mer',
    4 => 'Jeu',
    5 => 'Ven',
    6 => 'Sam',
  ),
  'dom_cal_weekdays_long' => 
  array (
    0 => 'Dimanche',
    1 => 'Lundi',
    2 => 'Mardi',
    3 => 'Mercredi',
    4 => 'Jeudi',
    5 => 'Vendredi',
    6 => 'Samedi',
  ),
  'dom_cal_month' => 
  array (
    0 => '',
    1 => 'Jan',
    2 => 'Fev',
    3 => 'Mar',
    4 => 'Avr',
    5 => 'Mai',
    6 => 'Jun',
    7 => 'Jui',
    8 => 'Aou',
    9 => 'Sept',
    10 => 'Oct',
    11 => 'Nov',
    12 => 'Dec',
  ),
  'dom_cal_month_long' => 
  array (
    0 => '',
    1 => 'Janvier',
    2 => 'F�vrier',
    3 => 'Mars',
    4 => 'avril',
    5 => 'Mai',
    6 => 'Juin',
    7 => 'Juillet',
    8 => 'A�ut',
    9 => 'Septembre',
    10 => 'Octobre',
    11 => 'Novembre',
    12 => 'D�cembre',
  ),
);


?>
