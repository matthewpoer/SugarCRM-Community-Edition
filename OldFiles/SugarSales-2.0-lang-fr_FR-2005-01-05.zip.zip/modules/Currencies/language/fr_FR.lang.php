<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * 
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and 
 * (ii) the SugarCRM copyright notice 
 * in the same form as they appear in the distribution.  See full license for requirements.
 * 
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): SYNOLIA TEAM - contactsugar@synolia.fr / http://www.synolia.fr
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/sugarcrm/modules/Currencies/language/en_us.lang.php,v 1.12 2004/10/25 02:48:08 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): SYNOLIA TEAM - contactsugar@synolia.fr / http://www.synolia.fr
 ********************************************************************************/

$mod_strings = array (
  'LBL_LIST_FORM_TITLE' => 'Devises',
  'LBL_CURRENCY' => 'Devise',
  'LBL_ADD' => 'Ajouter',
  'LBL_MERGE' => 'Fusionner',
  'LBL_MERGE_TXT' => 'Merci de v�rifier les devises que vous souhaitez aligner sur la devise selectionn�e. Cela effacera toutes les devises coch�es et r�affectera toute valeur par rapport � la devise selectionn�e.',
  'LBL_US_DOLLAR' => 'U.S. Dollar',
  'LBL_DELETE' => 'Supprimer',
  'LBL_LIST_SYMBOL' => 'Symbole de la devise',
  'LBL_LIST_NAME' => 'Nom devise',
  'LBL_LIST_ISO4217' => 'Code ISO 4217 ',
  'LBL_UPDATE' => 'Mise � jour',
  'LBL_LIST_RATE' => 'Taux de conversion',
  'LBL_LIST_STATUS' => 'Statut',
  'LNK_NEW_CONTACT' => 'Nouveau Contact',
  'LNK_NEW_ACCOUNT' => 'Nouveau Compte',
  'LNK_NEW_OPPORTUNITY' => 'Nouvelle Opportunit�',
  'LNK_NEW_CASE' => 'Nouveau Ticket',
  'LNK_NEW_NOTE' => 'Cr�er Note',
  'LNK_NEW_CALL' => 'Nouvel Appel',
  'LNK_NEW_EMAIL' => 'Nouvel Email',
  'LNK_NEW_MEETING' => 'Nouvelle R�union',
  'LNK_NEW_TASK' => 'Nouvelle T�che',
  'NTC_DELETE_CONFIRMATION' => 'Confirmez vous la suppression de cet enregistrement ? Il pourrait �tre pr�f�rable de modifier son statut en "inactif" sinon toutes les valeurs utilisant cette devise seront converties en U.S DOLLARS.',
  'currency_status_dom' => 
  array (
    'Active' => 'Actif',
    'Inactive' => 'Inactif',
  ),
);


?>
