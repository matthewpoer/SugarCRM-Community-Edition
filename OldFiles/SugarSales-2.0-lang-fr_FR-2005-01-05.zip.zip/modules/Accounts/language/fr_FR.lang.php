<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): SYNOLIA TEAM - contactsugar@synolia.fr / http://www.synolia.fr
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Accounts/language/en_us.lang.php,v 1.6 2004/08/03 07:43:13 sugarclint Exp $
 * Description:  Defines the English language pack 
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_MODULE_NAME'=>'Comptes',
'LBL_MODULE_TITLE'=>'Comptes: Accueil',
'LBL_SEARCH_FORM_TITLE'=>'Recherche de Compte',
'LBL_LIST_FORM_TITLE'=>'Liste des Comptes',
'LBL_NEW_FORM_TITLE'=>'Nouveau Compte',
'LBL_MEMBER_ORG_FORM_TITLE'=>'Membre des Organisations',

'LBL_LIST_ACCOUNT_NAME'=>'Nom du Compte',
'LBL_LIST_CITY'=>'Ville',
'LBL_LIST_WEBSITE'=>'Site web',
'LBL_LIST_STATE'=>'Etat',
'LBL_LIST_PHONE'=>'T�l�phone',

'LBL_ACCOUNT'=>'Compte:',
'LBL_ACCOUNT_NAME'=>'Nom du Compte:',
'LBL_PHONE'=>'T�l�phone:',
'LBL_WEBSITE'=>'Site web:',
'LBL_FAX'=>'Fax:',
'LBL_TICKER_SYMBOL'=>'Symbole:',
'LBL_OTHER_PHONE'=>'Autres T�l�phones:',
'LBL_ANY_PHONE'=>'T�l�hphone alternatif:',
'LBL_MEMBER_OF'=>'Membre de:',
'LBL_EMAIL'=>'Email:',
'LBL_EMPLOYEES'=>'Employ�s:',
'LBL_OTHER_EMAIL_ADDRESS'=>'Autre Email:',
'LBL_ANY_EMAIL'=>'Email alternatif:',
'LBL_OWNERSHIP'=>'Propri�taire:',
'LBL_RATING'=>'Note:',
'LBL_INDUSTRY'=>'Activit�:',
'LBL_SIC_CODE'=>'code NAF:',
'LBL_TYPE'=>'Type:',
'LBL_ANNUAL_REVENUE'=>'CA:',
'LBL_ADDRESS_INFORMATION'=>'Adresse',
'LBL_BILLING_ADDRESS'=>'Adresse de facturation:',
'LBL_SHIPPING_ADDRESS'=>'Adresse de livraison:',
'LBL_ANY_ADDRESS'=>'autre Adresse:',
'LBL_CITY'=>'Ville:',
'LBL_STATE'=>'Etat:',
'LBL_POSTAL_CODE'=>'Code Postal:',
'LBL_COUNTRY'=>'Pays:',
'LBL_DESCRIPTION_INFORMATION'=>'Description',
'LBL_DESCRIPTION'=>'Description:',
'NTC_COPY_BILLING_ADDRESS'=>'Copier adresse de facturation sur adresse de livraison',
'NTC_COPY_SHIPPING_ADDRESS'=>'Copier adresse de livraison sur adresse de facturation',
'NTC_REMOVE_MEMBER_ORG_CONFIRMATION'=>'Etes vous sur de vouloir supprimer ces informations ?',

'LNK_NEW_CONTACT'=>'Nouveau Contact',
'LNK_NEW_ACCOUNT'=>'Nouveau Compte',
'LNK_NEW_OPPORTUNITY'=>'Nouvelle affaire',
'LNK_NEW_CASE'=>'Nouveau Ticket',
'LNK_NEW_NOTE'=>'Nouvelle Note',
'LNK_NEW_CALL'=>'Nouvel Appel',
'LNK_NEW_EMAIL'=>'Nouvel Email',
'LNK_NEW_MEETING'=>'Nouveau Rendez-vous',
'LNK_NEW_TASK'=>'Nouvelle T�che',
'LBL_INVITEE'=>'Contacts',
'ERR_DELETE_RECORD'=>"Un num�ro d'enregistrement doit �tre sp�cifi� pour supprimer le compte.",
'LBL_LIST_EMAIL_ADDRESS'=>'Adresse Email',
'LBL_LIST_CONTACT_NAME'=>'Nom du Contact',
 'LNK_ACCOUNT_LIST' => 'Comptes',

);

?>
