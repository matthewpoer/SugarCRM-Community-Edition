<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * 
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and 
 * (ii) the SugarCRM copyright notice 
 * in the same form as they appear in the distribution.  See full license for requirements.
 * 
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): SYNOLIA TEAM - contactsugar@synolia.fr / http://www.synolia.fr
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/sugarcrm/modules/Administration/language/en_us.lang.php,v 1.30 2004/10/25 04:05:30 majed Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): SYNOLIA TEAM - contactsugar@synolia.fr / http://www.synolia.fr
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Administration',
  'LBL_MODULE_TITLE' => 'Administration: Accueil',
  'LBL_NEW_FORM_TITLE' => 'Nouveau Compte',
  'LNK_NEW_USER' => 'Nouvel Utilisateur',
  'ERR_DELETE_RECORD' => "Un num�ro d'enregistrement doit �tre sp�cifi� pour supprimer ce compte.",
  'LBL_CONFIGURE_SETTINGS_TITLE' => 'Panneau de configuration',
  'LBL_CONFIGURE_SETTINGS' => 'Configuration du syst�me',
  'LBL_UPGRADE_TITLE' => 'Mise � jour',
  'LBL_UPGRADE' => 'Mise � jour Sugar Sales',
  'LBL_MANAGE_USERS_TITLE' => 'Gestion Utilisateur',
  'LBL_MANAGE_USERS' => 'Gestion des comptes et mots de passe utilisateurs',
  'LBL_ADMINISTRATION_HOME_TITLE' => 'Administration du syst�me',
  'LBL_NOTIFY_TITLE' => 'Options de Notification par mail ',
  'LBL_NOTIFY_FROMADDRESS' => 'Adresse "From" :',
  'LBL_MAIL_SMTPSERVER' => 'Serveur SMTP :',
  'LBL_MAIL_SMTPPORT' => 'Port SMTP :',
  'LBL_MAIL_SENDTYPE' => 'Agent de transfert par mail:',
  'LBL_MAIL_SMTPUSER' => 'nom utilisateur SMTP :',
  'LBL_MAIL_SMTPPASS' => 'Password SMTP :',
  'LBL_MAIL_SMTPAUTH_REQ' => 'Authentication SMTP ?',
  'LBL_NOTIFY_SEND_BY_DEFAULT' => 'Envoyer notification par defaut ?',
  'LBL_NOTIFY_SUBJECT' => 'sujet E-mail :',
  'LBL_NOTIFY_ON' => 'Activer les notifications ? ',
  'LBL_NOTIFY_FROMNAME' => 'Nom "From" :',
  'LBL_CURRENCY' => 'Configuration des devises et taux de taxes',
  'LBL_MANAGE_CURRENCIES' => 'Devises',
  'LBL_MANAGE_OPPORTUNITIES' => 'Opportunit�s',
  'LBL_UPGRADE_CURRENCY' => 'Mise � jour des montants des devises des ',























);


?>
