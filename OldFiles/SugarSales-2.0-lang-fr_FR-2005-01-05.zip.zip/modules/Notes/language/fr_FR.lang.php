<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): SYNOLIA TEAM - contactsugar@synolia.fr / http://www.synolia.fr
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Notes/language/en_us.lang.php,v 1.8 2004/08/03 07:43:18 sugarclint Exp $
 * Description:  Defines the English language pack for the Account module.
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_MODULE_NAME'=>'Notes',
'LBL_MODULE_TITLE'=>'Notes: Accueil',
'LBL_SEARCH_FORM_TITLE'=>'Recherche de Note',
'LBL_LIST_FORM_TITLE'=>'Liste des Notes',
'LBL_NEW_FORM_TITLE'=>'Nouvelle Note',

'LBL_LIST_SUBJECT'=>'Sujet',
'LBL_LIST_CONTACT_NAME'=>'Nom du Contact',
'LBL_LIST_RELATED_TO'=>'Relatif �',
'LBL_LIST_DATE_MODIFIED'=>'Derni�re Modification',

'LBL_NOTE'=>'Note:',
'LBL_NOTE_SUBJECT'=>'Sujet de la note:',
'LBL_CONTACT_NAME'=>'Nom du Contact:',
'LBL_PHONE'=>'T�l�phone:',
'LBL_SUBJECT'=>'Sujet:',
'LBL_CLOSE'=>'Close:',
'LBL_RELATED_TO'=>'Relatif �:',
'LBL_DATE_MODIFIED'=>'Derni�re modification:',
'LBL_EMAIL_ADDRESS'=>'Adresse Email:',
'LBL_COLON'=>':',

'LNK_NEW_CALL'=>'Cr�er Appel',
'LNK_NEW_MEETING'=>'Cr�er R�union',
'LNK_NEW_TASK'=>'Cr�er T�che',
'LNK_NEW_NOTE'=>'Cr�er Note',
'LNK_NEW_EMAIL'=>'Cr�er Email',
'LNK_CALL_LIST'=>'Appels',
'LNK_MEETING_LIST'=>'R�unions',
'LNK_TASK_LIST'=>'T�ches',
'LNK_NOTE_LIST'=>'Notes',
'LNK_EMAIL_LIST'=>'Emails',

'ERR_DELETE_RECORD'=>"Un num�ro d'enregistrement doit �tre sp�cifi� pour supprimer le compte.",
'LBL_FILENAME'=>'Pi�ce jointe:',
'LBL_LIST_FILENAME'=>'Pi�ce jointe',
);

?>
