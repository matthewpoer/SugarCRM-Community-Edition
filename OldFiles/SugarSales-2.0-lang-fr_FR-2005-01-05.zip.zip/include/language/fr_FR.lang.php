<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * 
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and 
 * (ii) the SugarCRM copyright notice 
 * in the same form as they appear in the distribution.  See full license for requirements.
 * 
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): SYNOLIA TEAM - contactsugar@synolia.fr / http://www.synolia.fr
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/sugarcrm/include/language/en_us.lang.php,v 1.90 2004/10/25 08:19:09 majed Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): SYNOLIA TEAM - contactsugar@synolia.fr / http://www.synolia.fr
 ********************************************************************************/

//the left value is the key stored in the db and the right value is the display value
//to translate, only modify the right value in each key/value pair
$app_list_strings = array (
//e.g. auf Deutsch 'Contacts'=>'Contakten',
  'moduleList' => 
  array (
    'Home' => 'Accueil',
    'Dashboard' => 'Tableaux de bord',
    'Contacts' => 'Contacts',
    'Accounts' => 'Comptes',
    'Opportunities' => 'Opportunit�s',
    'Cases' => 'Tickets',
    'Notes' => 'Notes',
    'Calls' => 'Appels',
    'Emails' => 'Emails',
    'Meetings' => 'Rendez-vous',
    'Tasks' => 'T�ches',
    'Calendar' => 'Calendrier',
    'Leads' => 'Leads',





    'Activities' => 'Activit�s',
  ),
  //e.g. en fran�ais 'Analyst'=>'Analyste',
  'account_type_dom' => 
  array (
    '' => '',
    'Analyst' => 'Analyste',
    'Competitor' => 'Concurrent',
    'Customer' => 'Client',
    'Integrator' => 'Integrateur',
    'Investor' => 'Investisseur',
    'Partner' => 'Partenaire',
    'Press' => 'Presse',
    'Prospect' => 'Prospect',
    'Reseller' => 'Revendeur',
    'Other' => 'Autre',
  ),
  //e.g. en espa�ol 'Apparel'=>'Ropa',
  'industry_dom' => 
  array (
    '' => '',
    'Apparel'=>'Textile'
		, 'Banking'=>'Banque'
		, 'Biotechnology'=>'Biotechnologie'
		, 'Chemicals'=>'Industrie Chimique'
		, 'Communications'=>'Communications'
		, 'Construction'=>'Construction - BTP'
		, 'Consulting'=>'Conseil'
		, 'Education'=>'Education'
		, 'Electronics'=>'Informatique - Electronique'
		, 'Energy'=>'Energie'
		, 'Engineering'=>'Ingenierie'
		, 'Entertainment'=>'Culture-Presse'
		, 'Environmental'=>'Environnement'
		, 'Finance'=>'Finance'
		, 'Food & Beverage'=>'Agro-alimentaire'
		, 'Government'=>'Administration'
		, 'Healthcare'=>'Sant�'
		, 'Hospitality'=>'Hopitaux'
		, 'Insurance'=>'Assurance'
		, 'Machinery'=>'Industrie lourde'
		, 'Manufacturing'=>'Industrie Manufact.'
		, 'Media'=>'Media'
		, 'Not For Profit'=>'Sans but lucratif'
		, 'Recreation'=>'Loisir'
		, 'Retail'=>'Commerce d�tail'
		, 'Shipping'=>'Transports'
		, 'Technology'=>'Technologie'
		, 'Telecommunications'=>'Telecommunications'
		, 'Transportation'=>'Voyage-hotellerie'
		, 'Utilities'=>'Services'
		, 'Other'=>'Autre'
		),

  'lead_source_dom' => 
  array (
    '' => '',
    'Cold Call'=>'Appel entrant'
		, 'Existing Customer'=>'Client existant'
		, 'Self Generated'=>'R�current'
		, 'Employee'=>'Employ�'
		, 'Partner'=>'Partenaire'
		, 'Public Relations'=>'Relation publique'
		, 'Direct Mail'=>'Mailing'
		, 'Conference'=>'Conference'
		, 'Trade Show'=>'Salon'
		, 'Web Site'=>'Site web'
		, 'Word of mouth'=>'Recommand�'
		, 'Other'=>'Autre'
		  ),
'opportunity_type_dom' => Array(''=>''
		, 'Existing Business'=>'Recurrent'
		, 'New Business'=>'Nouvelle affaire'
		 ),
 
 
//Note:  do not translate opportunity_relationship_type_default_key
//       it is the key for the default opportunity_relationship_type_dom value
'opportunity_relationship_type_default_key' => 'Primary Decision Maker',
'opportunity_relationship_type_dom' => Array(''=>''
		, 'Primary Decision Maker'=>'D�cideur principal'
		, 'Business Decision Maker'=>'Acheteur'
		, 'Business Evaluator'=>'Chef de projet'
		, 'Technical Decision Maker'=>'Responsable technique'
		, 'Technical Evaluator'=>'Utilisateur'
		, 'Executive Sponsor'=>'Sponsor'
		, 'Influencer'=>'Influenceur'
		, 'Other'=>'Autre'
		  ),
		  
//Note:  do not translate case_relationship_type_default_key
//       it is the key for the default case_relationship_type_dom value
'case_relationship_type_default_key' => 'Contact Principal',
'case_relationship_type_dom' => Array(''=>''
		, 'Primary Contact'=>'Contact Principal'
		, 'Alternate Contact'=>'Contact Alternatif'
		),
		
 'sales_stage_dom' => Array('Prospecting'=>'Prospection'
		, 'Qualification'=>'Qualification'
		, 'Needs Analysis'=>'Analyse des besoins'
		, 'Value Proposition'=>'Chiffrage'
		, 'Id. Decision Makers'=>'Id. D�cideurs'
		, 'Perception Analysis'=>'Evaluation'
		, 'Proposal/Price Quote'=>'Devis/Proposition'
		, 'Negotiation/Review'=>'Negociation'
		, 'Closed Won'=>'Gagn�'
		, 'Closed Lost'=>'Perdu'
		),
		
  'activity_dom' => 
  array (
    'Call' => 'Appel',
    'Meeting' => 'Rendez-vous',
    'Task' => 'T�ches',
    'Email' => 'Email',
    'Note' => 'Note',
  ),
  
  
 'salutation_dom' => Array(''=>''
		, 'Mr.'=>'Mr.'
		, 'Ms.'=>'Mlle.'
		, 'Mrs.'=>'Mme.'
		, 'Dr.'=>'Dr.'
		, 'Prof.'=>'Prof.'
		),

'task_priority_dom' => Array('High'=>'Haute'
		, 'Medium'=>'Moyenne'
		, 'Low'=>'Basse'
		),

 'task_status_dom' => Array('Not Started'=>'Non d�marr�e'
		, 'In Progress'=>'En cours'
		, 'Completed'=>'R�alis�e'
		, 'Pending Input'=>'En attente'
		, 'Deferred'=>'Report�e'
		),

'meeting_status_dom' => Array('Planned'=>'Plannifi�'
		, 'Held'=>'Confirm�'
		, 'Not Held'=>'Non Confirm�'
		),
		
		
  'call_status_dom' => Array('Planned'=>'Plannifi�'
		, 'Held'=>'Confirm�'
		, 'Not Held'=>'Non Confirm�'
		),

  'call_direction_dom' => 
  array (
    'Inbound' => 'Entrant',
    'Outbound' => 'Sortant',
  ),
  'lead_status_dom' => 
  array (
    '' => '',
    'New' => 'Nouveau',
    'Assigned' => 'Affect�',
    'In Process' => 'En cours',
    'Converted' => 'Transform�',
    'Recycled' => 'Transmis',
    'Dead' => 'Abandonn�',
  ),
  'lead_status_noblank_dom' => 
  array (
    'New' => 'Nouveau',
    'Assigned' => 'Affect�',
    'In Process' => 'En cours',
    'Converted' => 'Transform�',
    'Recycled' => 'Transmis',
    'Dead' => 'Abandonn�',
  ),
  //Note:  do not translate case_status_default_key
//       it is the key for the default case_status_dom value
  'case_status_default_key' => 'Nouveau',
'case_status_dom' => Array('New'=>'Nouveau'
		, 'Assigned'=>'Assign�'
		, 'Closed'=>'Ferm�'
		, 'Pending Input'=>'En attente'
		, 'Rejected'=>'Rejet�'
		),
		
  'case_priority_default_key' => 'P2',
  'case_priority_dom' => 
  array (
    'P1' => 'Haute',
    'P2' => 'Moyenne',
    'P3' => 'Basse',
  ),
  'user_status_dom' => 
  array (
    'Active' => 'Actif',
    'Inactive' => 'Inactif',
  ),
  //Note:  do not translate record_type_default_key
//       it is the key for the default record_type_module value
  'record_type_default_key' => 'Accounts',
  'record_type_display' => 
  array (
    'Accounts' => 'Compte',
    'Opportunities' => 'Opportunit�',
    'Cases' => 'Ticket',
    'Leads' => 'Lead',




  ),
  'notifymail_sendtype' => 
  array (
    'sendmail' => 'sendmail',
    'SMTP' => 'SMTP',
  ),
);

$app_strings = array (
  'LBL_CHARSET' => 'ISO-8859-1',
  'LBL_BROWSER_TITLE' => 'SugarCRM - Solution CRM Open Source',
  'LBL_MY_ACCOUNT' => 'Mon Compte',
  'LBL_ADMIN' => 'Admin',
  'LBL_LOGOUT' => 'Deconnexion',
  'LBL_SEARCH' => 'Recherche',
  'LBL_LAST_VIEWED' => 'Derni�res consultations',
  'NTC_WELCOME' => 'Bienvenue',
  'NTC_SUPPORT_SUGARCRM' => "Soutenez le projet Open Source SugarCRM en effectuant un don au moyen de PAYPAL - C'est rapide, sans frais et s�curis�!",
  'NTC_NO_ITEMS_DISPLAY' => 'Aucun',
  'LBL_ALT_HOT_KEY' => 'Alt+',
  'LBL_SAVE_BUTTON_TITLE' => 'Sauvegarder [Alt+S]',
  'LBL_EDIT_BUTTON_TITLE' => 'Editer [Alt+E]',
  'LBL_EDIT_BUTTON' => 'Editer',
  'LBL_DUPLICATE_BUTTON_TITLE' => 'Dupliquer [Alt+U]',
  'LBL_DUPLICATE_BUTTON' => 'Dupliquer',
  'LBL_DELETE_BUTTON_TITLE' => 'Supprimer [Alt+D]',
  'LBL_DELETE_BUTTON' => 'Supprimer',
  'LBL_NEW_BUTTON_TITLE' => 'Nouveau [Alt+N]',
  'LBL_CHANGE_BUTTON_TITLE' => 'Modifier [Alt+G]',
  'LBL_CANCEL_BUTTON_TITLE' => 'Annuler [Alt+X]',
  'LBL_SEARCH_BUTTON_TITLE' => 'Rechercher [Alt+Q]',
  'LBL_CLEAR_BUTTON_TITLE' => 'Initialiser [Alt+C]',
  'LBL_SELECT_BUTTON_TITLE' => 'Selectionner [Alt+T]',
  'LBL_SAVE_BUTTON_KEY' => 'S',
  'LBL_EDIT_BUTTON_KEY' => 'E',
  'LBL_DUPLICATE_BUTTON_KEY' => 'U',
  'LBL_DELETE_BUTTON_KEY' => 'D',
  'LBL_NEW_BUTTON_KEY' => 'N',
  'LBL_CHANGE_BUTTON_KEY' => 'G',
  'LBL_CANCEL_BUTTON_KEY' => 'X',
  'LBL_SEARCH_BUTTON_KEY' => 'Q',
  'LBL_CLEAR_BUTTON_KEY' => 'C',
  'LBL_SELECT_BUTTON_KEY' => 'T',
  'LBL_SAVE_BUTTON_LABEL' => 'Sauvegarder',
  'LBL_EDIT_BUTTON_LABEL' => 'Editer',
  'LBL_DUPLICATE_BUTTON_LABEL' => 'Dupliquer',
  'LBL_DELETE_BUTTON_LABEL' => 'Supprimer',
  'LBL_NEW_BUTTON_LABEL' => 'Nouveau',
  'LBL_CHANGE_BUTTON_LABEL' => 'Modifier',
  'LBL_CANCEL_BUTTON_LABEL' => 'Annuler',
  'LBL_SEARCH_BUTTON_LABEL' => 'Rechercher',
  'LBL_CLEAR_BUTTON_LABEL' => 'Initialiser',
  'LBL_NEXT_BUTTON_LABEL' => 'Suivant',
  'LBL_SELECT_BUTTON_LABEL' => 'Selectionner',
  'LBL_SELECT_CONTACT_BUTTON_TITLE' => 'Selectionner Contact [Alt+T]',
  'LBL_SELECT_CONTACT_BUTTON_KEY' => 'T',
  'LBL_VIEW_PDF_BUTTON_LABEL' => 'Voir PDF',
  'LBL_VIEW_PDF_CONTACT_BUTTON_TITLE' => 'Voir PDF [Alt+P]',
  'LBL_VIEW_PDF_CONTACT_BUTTON_KEY' => 'P',
  'LBL_SELECT_CONTACT_BUTTON_LABEL' => 'Selectionner Contact',
  'LBL_SELECT_USER_BUTTON_TITLE' => 'Selectionner Utilisateur [Alt+U]',
  'LBL_SELECT_USER_BUTTON_KEY' => 'U',
  'LBL_SELECT_USER_BUTTON_LABEL' => 'Selectionner Utilisateur',
  'LBL_CREATE_BUTTON_LABEL' => 'Nouveau',
  'LBL_SHORTCUTS' => 'Raccourcis',
  
  'LBL_LIST_NAME' => 'Nom',
  'LBL_LIST_USER_NAME'=>'Nom Uutilisateur',
'LBL_LIST_EMAIL'=>'Email',
'LBL_LIST_PHONE'=>'T�l�phone',
'LBL_LIST_CONTACT_NAME'=>'Nom Contact',

  'LBL_LIST_CONTACT_ROLE' => 'Fonction Contact',
  'LBL_LIST_ACCOUNT_NAME' => 'Nom Compte',
  'LBL_USER_LIST' => 'Liste Utilisateurs',
  'LBL_CONTACT_LIST' => 'Liste Contacts',
  'LBL_RELATED_RECORDS' => 'Enregistrements associ�s',
  'LBL_MASS_UPDATE' => 'Mise � jour globale',
  'LNK_ADVANCED_SEARCH' => 'Avanc�e',
  'LNK_BASIC_SEARCH' => 'Standard',
  'LNK_EDIT' => 'editer',
  'LNK_REMOVE' => 'supp',
  'LNK_DELETE' => 'eff',
  'LNK_LIST_START' => 'D�part',
  'LNK_LIST_NEXT' => 'Suivant',
  'LNK_LIST_PREVIOUS' => 'Pr�c�dent',
  'LNK_LIST_END' => 'Fin',
  'LBL_LIST_OF' => 'sur',
  'LBL_OR' => 'Ou',
  'LNK_PRINT' => 'Imprimer',
  'LNK_HELP' => 'Aide',
  'LNK_ABOUT' => 'About',
  'NTC_REQUIRED' => 'Indique les champs requis',
  'LBL_REQUIRED_SYMBOL' => '*',
  'LBL_CURRENCY_SYMBOL' => '$',
  'LBL_PERCENTAGE_SYMBOL' => '%',
  'LBL_THOUSANDS_SYMBOL' => 'K',
  'NTC_DATE_FORMAT' => '(aaaa-mm-jj)',
  'NTC_TIME_FORMAT' => '(24:00)',
  'NTC_DATE_TIME_FORMAT' => '(aaaa-mm-jj 24:00)',
 'NTC_DELETE_CONFIRMATION'=>'Etes vous s�r de vouloir supprimer cet enregistrement ?',
'ERR_DELETE_RECORD'=>"Un num�ro d'enregistrement doit �tre sp�cifi� pour supprimer le contact.",
'ERR_CREATING_TABLE'=>'Erreur de cr�ation de la table: ',
'ERR_CREATING_FIELDS'=>'Erreur de saisie de champs: ',
'ERR_MISSING_REQUIRED_FIELDS'=>'Champs requis non renseign�s:',
'ERR_INVALID_EMAIL_ADDRESS'=>"n'est pas une adresse valide.",
'ERR_INVALID_DATE_FORMAT'=>'Le format de la date doit �tre: aaaa-mm-jj',
'ERR_INVALID_MONTH'=>'Merci de saisir un mois valide.',
'ERR_INVALID_DAY'=>'Merci de saisir un jour valide.',
'ERR_INVALID_YEAR'=>'Merci de saisir une ann�e � 4 chiffres valide.',
'ERR_INVALID_DATE'=>'Merci de saisir une date valide.',
'ERR_INVALID_HOUR'=>'Merci de saisir une heure valide.',
'ERR_INVALID_TIME'=>'Merci de saisir un horaire valide.',
  'ERR_INVALID_AMOUNT' => 'Merci de saisir un montant valide.',
 'NTC_CLICK_BACK'=>'Merci de cliquer sur le bouton pr�c�dent du navigateur et de corriger le probl�me.',
  'LBL_LIST_ASSIGNED_USER' => 'Assign� � ',
  'LBL_ASSIGNED_TO' => 'Assign� �:',
  'LBL_DATE_MODIFIED' => 'Derni�re Modification:',
  'LBL_DATE_ENTERED' => 'Date Cr�ation:',
 'LBL_CURRENT_USER_FILTER'=>'Montrer uniquement les �l�ments qui me sont assign�s:',
 'NTC_LOGIN_MESSAGE'=>"Merci de vous authentifier.",
  'LBL_NONE' => '--Aucun(e)--',
  'LBL_BACK' => 'Retour',
  'LBL_IMPORT' => 'Import',
  'LBL_EXPORT' => 'Export',
  'LBL_EXPORT_ALL' => 'Exporter Tout',
  'LBL_SAVE_NEW_BUTTON_TITLE' => 'Sauvegarder & Cr�er un nouveau [Alt+V]',
  'LBL_SAVE_NEW_BUTTON_KEY' => 'V',
  'LBL_SAVE_NEW_BUTTON_LABEL' => 'Sauvegarder & Cr�er un nouveau',
  'LBL_NAME' => 'Nom',
  'LBL_SUBJECT' => 'Sujet',
);


?>
