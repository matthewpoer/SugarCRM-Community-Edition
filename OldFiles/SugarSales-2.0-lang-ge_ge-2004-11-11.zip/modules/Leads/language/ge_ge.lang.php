<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/modules/Accounts/Account.php,v 1.92 2004/11/10 22:27:36 clint Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Hinweise',
  'LBL_INVITEE' => 'Direkter Bericht',
  'LBL_MODULE_TITLE' => 'Hinweise: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Hinweis Suchen',
  'LBL_LIST_FORM_TITLE' => 'Liste der Hinweise',
  'LBL_NEW_FORM_TITLE' => 'Neuer Hinweis',
  'LBL_CONTACT_OPP_FORM_TITLE' => 'Hinweis-Auftrag:',
  'LBL_CONTACT' => 'Hinweis:',
  'LBL_BUSINESSCARD' => 'Hinweis umwandeln',
  'LBL_LIST_NAME' => 'Namen',
  'LBL_LIST_LAST_NAME' => 'Nachnamen',
  'LBL_LIST_CONTACT_NAME' => 'Hinweis',
  'LBL_LIST_TITLE' => 'Titel',
  'LBL_LIST_ACCOUNT_NAME' => 'Kunde',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email',
  'LBL_LIST_PHONE' => 'Telefon',
  'LBL_LIST_CONTACT_ROLE' => 'Rolle',
  'LBL_LIST_FIRST_NAME' => 'Vornamen',
  'LBL_LIST_REFERED_BY' => 'Zugewiesen durch',
  'LBL_LIST_LEAD_SOURCE' => 'Hinweis Herkunft',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_LIST_DATE_ENTERED' => 'Erstellt am',
  'LBL_LIST_LEAD_SOURCE_DESCRIPTION' => 'Beschriebung der Herkunft des Hinweises',
  'LBL_LIST_MY_LEADS' => 'Meine Hinweise',
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_account_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_email2' => 'LBL_LIST_EMAIL_ADDRESS',
  'LBL_EXISTING_CONTACT' => 'Bestehender Kontakt verwendet',
  'LBL_CREATED_CONTACT' => 'Neuer Kontakt angelegt',
  'LBL_EXISTING_OPPORTUNITY' => 'Bestehender Auftrag verwendet',
  'LBL_CREATED_OPPORTUNITY' => 'Neuer Auftrag angelegt',
//END DON'T CONVERT
  'LBL_EXISTING_ACCOUNT' => 'Bestehender Kunde verwendet',
  'LBL_CREATED_ACCOUNT' => 'Neuer Kunde angelegt',
  'LBL_CREATED_CALL' => 'Neuer Anruf angelegt',
  'LBL_CREATED_MEETING' => 'Neuen Termin angelegt',
  'LBL_BACKTOLEADS' => 'Zur�ck zu Hinweisen',
  'LBL_CONVERTLEAD' => 'Hinweise umwandeln',
  'LBL_NAME' => 'Namen:',
  'LBL_CONTACT_NAME' => 'Hinweis:',
  'LBL_CONTACT_INFORMATION' => 'Informationen',
  'LBL_FIRST_NAME' => 'Vornamen:',
  'LBL_OFFICE_PHONE' => 'Gesch�ft Telefon:',
  'LBL_ACCOUNT_NAME' => 'Kuden Namen:',
  'LBL_OPPORTUNITY_NAME' => 'Auftrag Namen:',
  'LBL_OPPORTUNITY_AMOUNT' => 'Auftrag Betrag:',
  'LBL_ANY_PHONE' => 'eine Telefon Nummer:',
  'LBL_PHONE' => 'Telefon:',
  'LBL_LAST_NAME' => 'Nachnamen:',
  'LBL_MOBILE_PHONE' => 'Mobile:',
  'LBL_HOME_PHONE' => 'Privates Telefon:',
  'LBL_LEAD_SOURCE' => 'Hinweis Herkunft:',
  'LBL_STATUS' => 'Status:',
  'LBL_LEAD_SOURCE_DESCRIPTION' => 'Beschreibung der Hinweis Herkunft:',
  'LBL_STATUS_DESCRIPTION' => 'Status:',
  'LBL_OTHER_PHONE' => 'Weiteres Telefon:',
  'LBL_FAX_PHONE' => 'Fax:',
  'LBL_TITLE' => 'Titel:',
  'LBL_DEPARTMENT' => 'Abteilung:',
  'LBL_EMAIL_ADDRESS' => 'Email:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Weitere Email:',
  'LBL_ANY_EMAIL' => 'eine Email:',
  'LBL_REPORTS_TO' => 'Rapportiert an:',
  'LBL_DO_NOT_CALL' => 'Nicht anrufen:',
  'LBL_EMAIL_OPT_OUT' => 'Email Opt Out:',
  'LBL_PRIMARY_ADDRESS' => 'Prim�re Adresse:',
  'LBL_ALTERNATE_ADDRESS' => 'Weitere Adresse:',
  'LBL_ANY_ADDRESS' => 'eine Address:',
  'LBL_REFERED_BY' => 'Zugewiesen von:',
  'LBL_CITY' => 'Ort:',
  'LBL_STATE' => 'Bundesland:',
  'LBL_POSTAL_CODE' => 'PLZ:',
  'LBL_COUNTRY' => 'Land:',
  'LBL_DESCRIPTION_INFORMATION' => 'Beschreibung',
  'LBL_ADDRESS_INFORMATION' => 'Adresse',
  'LBL_DESCRIPTION' => 'Beschreibung:',
  'LBL_CONTACT_ROLE' => 'Funktion:',
  'LBL_OPP_NAME' => 'Auftrag:',
  'LBL_IMPORT_VCARD' => 'Importiere vCard',
  'LNK_IMPORT_VCARD' => 'Erstelle von vCard',
  'LBL_IMPORT_VCARDTEXT' => 'Erstelle automatisch einen neuen Lead durch das importieren einer vCard.',
  'LBL_DUPLICATE' => '�hnliche Hinweise',
  'MSG_DUPLICATE' => '�hnliche Hinweise wurden gefunden. W�hle die Boxen verschiedener Hinweise welche Sie mit den Eintr�gen aus dieser Umwandlung erzeugen wollen. Sobald Sie dies fertiggestellt haben, klicken Sie auf Weiter.',
  'LBL_ADD_BUSINESSCARD' => 'Business Card hinzuf�gen',
  'LNK_NEW_APPOINTMENT' => 'Neuer Termin',
  'LNK_NEW_LEAD' => 'Neuer Hinweis',
  'LNK_LEAD_LIST' => 'Hinweise',
  'NTC_DELETE_CONFIRMATION' => 'Sind Sie sicher das Sie diesen Eintrag l�schen wollen?',
  'NTC_REMOVE_CONFIRMATION' => 'Sind Sie sicher das Sie diesen Hinweis von dieser Anfrage entfernen m�chten?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Sind Sie sicher das Sie diesen Eintrag als direkten Bericht entfernen m�chten?',
  'ERR_DELETE_RECORD' => 'en_us Eine Datensatz Nummer muss spezifiziert sein um den Hinweis l�schen zu k�nnen.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Kopiere prim�re Adresse zur alternativen Adresse',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Copy alternative adresse zur prim�ren Adresse',
  'LNK_NEW_CONTACT' => 'Neuer Kontakt',
  'LNK_NEW_NOTE' => 'Neue Notiz',
  'LNK_NEW_ACCOUNT' => 'Neuer Kunde',
  'LNK_NEW_OPPORTUNITY' => 'Neuer Auftrag',
  'LNK_SELECT_ACCOUNT' => 'W�hle Kunde',
  'LBL_SALUTATION' => 'Anrede',
  'NTC_OPPORTUNITY_REQUIRES_ACCOUNT' => 'Zum Erstellen eines Auftrages ben�tigen Sie einen Kunden.\\n Erstellen Sie dazu einen neuen Kunden oder selektieren Sie einen bestehenden.',
);


?>
