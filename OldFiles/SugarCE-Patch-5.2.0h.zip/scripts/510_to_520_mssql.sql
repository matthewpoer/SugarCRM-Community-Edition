-- MSSQL upgrade script for Sugar 5.1.0 to 5.2.0

--
-- Table structure for table sugarfeed
--

CREATE TABLE sugarfeed (
	id varchar(36) NOT NULL,
	name varchar(255) NULL,
	date_entered datetime NULL,
	date_modified datetime NULL,
	modified_user_id varchar(36) NULL,
	created_by varchar(36) NULL,
	description varchar(255) NULL,
	deleted bit DEFAULT '0' NULL,



	assigned_user_id varchar(36) NULL,
	related_module varchar(100) NULL,
	related_id varchar(36) NULL,
	link_url varchar(255) NULL,
	link_type varchar(30) NULL  
); 

ALTER TABLE sugarfeed ADD CONSTRAINT pk_sugarfeed PRIMARY KEY (id) create index sgrfeed_date on sugarfeed ( date_entered, 



deleted 
);

ALTER TABLE email_cache alter column senddate datetime NULL;
