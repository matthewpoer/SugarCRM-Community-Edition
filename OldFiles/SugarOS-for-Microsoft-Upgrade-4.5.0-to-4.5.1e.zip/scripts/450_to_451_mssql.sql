-- SQL Server upgrade script for Sugar 4.5.0 to 4.5.1

--
-- CHANGED TABLES
--

-- accounts
ALTER TABLE [dbo].[accounts] ADD [campaign_id] [varchar] (36);

-- campaign_log
ALTER TABLE [dbo].[campaign_log] ADD [marketing_id] [varchar] (36);

-- campaigns
ALTER TABLE [dbo].[campaigns] ADD [impressions] [int];
ALTER TABLE [dbo].[campaigns] ADD [frequency] [varchar] (25);

-- contacts
ALTER TABLE [dbo].[contacts] ADD [campaign_id] [varchar] (36);

-- email_templates




ALTER TABLE [dbo].[email_templates] ADD [text_only] [bit];

-- emails_contacts
ALTER TABLE [dbo].[emails_contacts] ADD [campaign_data] [text];

-- emails_leads
ALTER TABLE [dbo].[emails_leads] ADD [campaign_data] [text];

-- emails_prospects
ALTER TABLE [dbo].[emails_prospects] ADD [campaign_data] [text];

-- emails_users
ALTER TABLE [dbo].[emails_users] ADD [campaign_data] [text];

-- notes
ALTER TABLE [dbo].[notes] ADD [embed_flag] [bit] NOT NULL DEFAULT ('0');

-- opportunities
ALTER TABLE [dbo].[opportunities] ADD [campaign_id] [varchar] (36);









-- prospects
ALTER TABLE [dbo].[prospects] ADD [campaign_id] [varchar] (36);






-- user_preferences
DROP INDEX [idx_userprefnamecat] ON [dbo].[user_preferences];
ALTER TABLE [dbo].[user_preferences] ALTER COLUMN [assigned_user_id] [varchar] (36) NOT NULL;
CREATE NONCLUSTERED INDEX [idx_userprefnamecat] ON [dbo].[user_preferences] ([category], [assigned_user_id]);

-- upgrade_history
ALTER TABLE [dbo].[upgrade_history] ADD [name] [varchar] (255);
ALTER TABLE [dbo].[upgrade_history] ADD [description] [text];
ALTER TABLE [dbo].[upgrade_history] ADD [id_name] [varchar] (255);
ALTER TABLE [dbo].[upgrade_history] ADD [manifest] [text];






