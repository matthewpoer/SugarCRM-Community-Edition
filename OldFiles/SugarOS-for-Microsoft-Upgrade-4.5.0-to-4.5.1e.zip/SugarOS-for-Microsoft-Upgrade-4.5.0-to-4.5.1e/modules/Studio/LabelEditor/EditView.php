<?php

if(empty($_REQUEST['custom_module']))$_REQUEST['custom_module'] = $_SESSION['studio']['module'];
$custom_module = $_REQUEST['custom_module']; 
$selected_lang = (!empty($_REQUEST['selected_lang'])?$_REQUEST['selected_lang']:$_SESSION['authenticated_user_language']);
if(empty($selected_lang)){
    $selected_lang = $GLOBALS['sugar_config']['default_language'];
} 
$smarty = new Sugar_Smarty();
$smarty->assign('available_languages', unserialize($_SESSION['avail_languages']));
$edit_mod_strings = return_module_language($selected_lang, $custom_module);
$smarty->assign('MOD', $edit_mod_strings);
$smarty->assign('custom_module', $custom_module);
$smarty->assign('APP', $GLOBALS['app_strings']);
$smarty->assign('selected_lang', $selected_lang);
$smarty->display('modules/Studio/LabelEditor/EditView.tpl');
?>
