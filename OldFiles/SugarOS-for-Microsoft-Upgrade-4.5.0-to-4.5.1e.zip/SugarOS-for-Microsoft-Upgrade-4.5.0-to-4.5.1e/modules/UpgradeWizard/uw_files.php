<?php
/**
 * The contents of this file are subject to the SugarCRM Community License Version
 * 1.0 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/S-CL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */

 // $Id$

global $sugar_version;
if(!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

///////////////////////////////////////////////////////////////////////////////
////	DYNAMICALLY GENERATE UPGRADEWIZARD MODULE FILE LIST
$uwFilesCurrent = findAllFiles('modules/UpgradeWizard/', array());

// handle 4.x to 4.5.x+ (no UpgradeWizard module)
if(count($uwFilesCurrent) < 5) {
	$uwFiles = array(
		'modules/UpgradeWizard/language/en_us.lang.php',
		'modules/UpgradeWizard/cancel.php',
		'modules/UpgradeWizard/commit.php',
		'modules/UpgradeWizard/commitJson.php',
		'modules/UpgradeWizard/end.php',
		'modules/UpgradeWizard/Forms.php',
		'modules/UpgradeWizard/index.php',
		'modules/UpgradeWizard/Menu.php',
		'modules/UpgradeWizard/preflight.php',
		'modules/UpgradeWizard/preflightJson.php',
		'modules/UpgradeWizard/start.php',
		'modules/UpgradeWizard/su_utils.php',
		'modules/UpgradeWizard/su.php',
		'modules/UpgradeWizard/systemCheck.php',
		'modules/UpgradeWizard/systemCheckJson.php',
		'modules/UpgradeWizard/upgradeWizard.js',
		'modules/UpgradeWizard/upload.php',
		'modules/UpgradeWizard/uw_ajax.php',
		'modules/UpgradeWizard/uw_files.php',
		'modules/UpgradeWizard/uw_main.tpl',
		'modules/UpgradeWizard/uw_utils.php',
	);
} else {
	$uwFilesCurrent = findAllFiles('ModuleInstall', $uwFilesCurrent);
	$uwFilesCurrent = findAllFiles('include/javascript/yui', $uwFilesCurrent);
	$uwFilesCurrent[] = 'HandleAjaxCall.php';

	$uwFiles = array();
	foreach($uwFilesCurrent as $file) {
		$uwFiles[] = str_replace("./", "", clean_path($file));
	}
}
////	END DYNAMICALLY GENERATE UPGRADEWIZARD MODULE FILE LIST
///////////////////////////////////////////////////////////////////////////////

$uw_files = array(
    // standard files we steamroll with no warning
    'log4php.properties',
    'include/utils/encryption_utils.php',
    'include/Pear/Crypt_Blowfish/Blowfish.php',
    'include/Pear/Crypt_Blowfish/Blowfish/DefaultKey.php',
    'include/utils.php',
    'include/utils/external_cache.php',
    'include/language/en_us.lang.php',
    'include/modules.php',
    'include/Localization/Localization.php',
    'install/language/en_us.lang.php',
    'XTemplate/xtpl.php',
    'include/database/DBHelper.php',
    'include/database/DBManager.php',
    'include/database/DBManagerFactory.php',
    'include/database/MssqlHelper.php',
    'include/database/MssqlManager.php',
    'include/database/MysqlHelper.php',
    'include/database/MysqlManager.php',
    'include/database/PearDatabase.php',




);

$uw_files = array_merge($uw_files, $uwFiles);

