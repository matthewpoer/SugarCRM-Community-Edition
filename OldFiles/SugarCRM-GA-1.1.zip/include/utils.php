<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/include/utils.php,v 1.27 2004/08/03 10:44:01 sugarjacob Exp $
 * Description:  Includes generic helper functions used throughout the application.
 ********************************************************************************/

function get_languages()
{
	global $languages;
	return $languages;
}
 
function get_language_dispay($key)
{
	global $languages;
	return $languages[$key];
}
 
function get_assigned_user_name(&$assigned_user_id)
{
	$user_list = &get_user_array();
	if(isset($user_list[$assigned_user_id]))
	{
		return $user_list[$assigned_user_id];
	}

	return "";
}
 
function get_user_array()
{
	static $user_array = null;
	
	if($user_array == null)
	{
		$temp_result = Array();
		// Including deleted users for now.
		$query = "SELECT id, user_name from users";
		$result = mysql_query($query) or die("Error filling in user array: ".mysql_error());
	
		// Get the id and the name.
		while($row = mysql_fetch_assoc($result))
		{
			$temp_result[$row['id']] = $row['user_name'];
		}
		
		// Add in a blank row
		$temp_result[""] = "";
		
		$user_array = &$temp_result;
	}		
	
	return $user_array;
}
 
function clean($string, $maxLength)
{
	$string = substr($string, 0, $maxLength);
	return escapeshellcmd($string);
}

/** 
 * Copy the specified request variable to the member variable of the specified object.  
 * Do no copy if the member variable is already set.
 */
function safe_map($request_var, & $focus, $always_copy = false)
{
	safe_map_named($request_var, $focus, $request_var, $always_copy);
}

/** 
 * Copy the specified request variable to the member variable of the specified object.  
 * Do no copy if the member variable is already set.
 */
function safe_map_named($request_var, & $focus, $member_var, $always_copy)
{
	global $log;
	if (isset($_REQUEST[$request_var]) && ($always_copy || is_null($focus->$member_var))) {
		$log->debug("safe map named called assigning '{$_REQUEST[$request_var]}' to $member_var");
		$focus->$member_var = $_REQUEST[$request_var];
	}
}

/** This function retrieves an application language file and returns the array of strings included in the $app_list_strings var.
 * If you are using the current language, do not call this function unless you are loading it for the first time */
function return_app_list_strings_language($language)
{
	global $app_list_strings, $default_language, $log, $translation_string_prefix;
	$temp_app_list_strings = $app_list_strings;
	$language_used = $language;
	
	@include("include/language/$language.lang.php");
	if(!isset($app_list_strings))
	{
		$log->warn("Unable to find the application language file for language: ".$language);
		require("include/language/$default_language.lang.php");
		$language_used = $default_language;
	}
	
	if(!isset($app_list_strings))
	{
		$log->fatal("Unable to load the application language file for the selected language($language) or the default language($default_language)");
		return null;
	}		

	
	$return_value = $app_list_strings;
	$app_list_strings = $temp_app_list_strings;
	
	return $return_value;
}

/** This function retrieves an application language file and returns the array of strings included.
 * If you are using the current language, do not call this function unless you are loading it for the first time */
function return_application_language($language)
{
	global $app_strings, $default_language, $log, $translation_string_prefix;
	$temp_app_strings = $app_strings;
	$language_used = $language;
	
	@include("include/language/$language.lang.php");
	if(!isset($app_strings))
	{
		$log->warn("Unable to find the application language file for language: ".$language);
		require("include/language/$default_language.lang.php");
		$language_used = $default_language;
	}
	
	if(!isset($app_strings))
	{
		$log->fatal("Unable to load the application language file for the selected language($language) or the default language($default_language)");
		return null;
	}		

	// If we are in debug mode for translating, turn on the prefix now!
	if($translation_string_prefix)
	{
		foreach($app_strings as $entry_key=>$entry_value)
		{
			$app_strings[$entry_key] = $language_used.' '.$entry_value;
		}
	}
	
	$return_value = $app_strings;
	$app_strings = $temp_app_strings;
	
	return $return_value;
}

/** This function retrieves a module's language file and returns the array of strings included.
 * If you are in the current module, do not call this function unless you are loading it for the first time */
function return_module_language($language, $module)
{
	global $mod_strings, $default_language, $log, $currentModule, $translation_string_prefix;
	
	if($currentModule == $module && isset($mod_strings) && $mod_strings != null)
	{
		// We should have already loaded the array.  return the current one.
		$log->fatal("module strings already loaded for language: ".$language." and module: ".$module);
		return $mod_strings;
	}
	
	$temp_mod_strings = $mod_strings;
	$language_used = $language;
	
	@include("modules/$module/language/$language.lang.php");
	if(!isset($mod_strings))
	{
		$log->warn("Unable to find the module language file for language: ".$language." and module: ".$module);
		require("modules/$module/language/$default_language.lang.php");
		$language_used = $default_language;
	}

	if(!isset($mod_strings))
	{
		$log->fatal("Unable to load the module($module) language file for the selected language($language) or the default language($default_language)");
		return null;
	}		

	// If we are in debug mode for translating, turn on the prefix now!
	if($translation_string_prefix)
	{
		foreach($mod_strings as $entry_key=>$entry_value)
		{
			$mod_strings[$entry_key] = $language_used.' '.$entry_value;
		}
	}
	
	$return_value = $mod_strings;
	$mod_strings = $temp_mod_strings;

	return $return_value;
}

/** If the session variable is defined and is not equal to "" then return it.  Otherwise, return the default value.
*/
function return_session_value_or_default($varname, $default)
{
	if(isset($_SESSION[$varname]) && $_SESSION[$varname] != "")
	{
		return $_SESSION[$varname];
	}
	
	return $default;
}

/**
  * Creates an array of where restrictions.  These are used to construct a where SQL statement on the query
  * It looks for the variable in the $_REQUEST array.  If it is set and is not "" it will create a where clause out of it.
  * @param &$where_clauses - The array to append the clause to
  * @param $variable_name - The name of the variable to look for an add to the where clause if found
  * @param $SQL_name - [Optional] If specified, this is the SQL column name that is used.  If not specified, the $variable_name is used as the SQL_name.
  */
function append_where_clause(&$where_clauses, $variable_name, $SQL_name = null)
{
	if($SQL_name == null)
	{
		$SQL_name = $variable_name;
	}
		
	if(isset($_REQUEST[$variable_name]) && $_REQUEST[$variable_name] != "")
	{
		array_push($where_clauses, "$SQL_name like '$_REQUEST[$variable_name]%'");
	}
}

/**
  * Generate the appropriate SQL based on the where clauses.
  * @param $where_clauses - An Array of individual where clauses stored as strings
  * @returns string where_clause - The final SQL where clause to be executed.
  */
function generate_where_statement($where_clauses)
{
	global $log;
	$where = "";
	foreach($where_clauses as $clause)
	{
		if($where != "")
		$where .= " and ";
		$where .= $clause;
	}

	$log->info("Here is the where clause for the list view: $where");
	return $where;
}

/**
 * A temporary method of generating GUIDs of the correct format for our DB.
 * @return String contianing a GUID in the format: aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee
 * 
*/
function create_guid()
{
    $microTime = microtime();
	list($a_dec, $a_sec) = explode(" ", $microTime);
	
	$dec_hex = sprintf("%x", $a_dec* 1000000);
	$sec_hex = sprintf("%x", $a_sec);

	ensure_length($dec_hex, 5);	
	ensure_length($sec_hex, 6);	
	
	$guid = "";
	$guid .= $dec_hex;
	$guid .= create_guid_section(3);
	$guid .= '-';
	$guid .= create_guid_section(4);
	$guid .= '-';
	$guid .= create_guid_section(4);
	$guid .= '-';
	$guid .= create_guid_section(4);
	$guid .= '-';
	$guid .= $sec_hex;
	$guid .= create_guid_section(6);
	
	return $guid;
		
}

function create_guid_section($characters)
{
	$return = "";
	for($i=0; $i<$characters; $i++)
	{
		$return .= sprintf("%x", rand(0,15));
	}
	return $return;
}

function ensure_length(&$string, $length)
{
	$strlen = strlen($string);
	if($strlen < $length)
	{
		$string = str_pad($string,$length,"0"); 
	}
	else if($strlen > $length)
	{
		$string = substr($string, 0, $length);
	}
}

function microtime_diff($a, $b) {
   list($a_dec, $a_sec) = explode(" ", $a);
   list($b_dec, $b_sec) = explode(" ", $b);
   return $b_sec - $a_sec + $b_dec - $a_dec;
}

/**
 * Check if user id belongs to a system admin.
 */
function is_admin($user) {
	if ($user->is_admin == 'on') return true;
	else return false;
}

/**
 * Return the display name for a theme if it exists.
 */
function get_theme_display($theme) {
	global $theme_name, $theme_description;
	$temp_theme_name = $theme_name;
	$temp_theme_description = $theme_description;

	if (is_file("./themes/$theme/config.php")) {
		@include("./themes/$theme/config.php");
		$return_theme_value = $theme_name;
	}
	else {
		$return_theme_value = $theme;
	}	
	$theme_name = $temp_theme_name;
	$theme_description = $temp_theme_description;
	
	return $return_theme_value;
}

/**
 * Return an array of directory names.
 */
function get_theme_options($current_theme) {
   if ($dir = @opendir("./themes")) {
		while (($file = readdir($dir)) !== false) {
           if ($file != ".." && $file != "." && $file != "CVS" && $file != "Attic") {
			   if(is_dir("./themes/".$file)) {
				   if(!($file[0] == '.')) {
				   	// set the initial theme name to the filename
				   	$name = $file;
				   	
				   	// if there is a configuration class, load that.
				   	if(is_file("./themes/$file/config.php"))
				   	{
				   		require_once("./themes/$file/config.php");
				   		$name = $theme_name;
				   	}
				   	
				   	if(is_file("./themes/$file/header.php"))
					{
						$filelist[strtolower($name)] = Array($name, $file);
					}
				   }
			   }
		   }
	   }
	   closedir($dir);
   }
   
   $filelist['--Default--'] = Array('--Default--', '');
   ksort($filelist);

   $options = "";
   if (is_array($filelist)) {
	   while (list ($key, $val) = each ($filelist)) {
		   $options .= "<option value='$val[1]' label='$val[0]' ";
		   if ($current_theme == $val[1]) {
			   $options .= " selected";
		   }
		   $options .= ">$val[0]</option>";
	   }
   }
   return $options;
}

/**
 * Create HTML to display select options in a dropdown list.  To be used inside 
 * of a select statement in a form.
 * param $option_list - the array of strings to that contains the option list
 * param $selected - the string which contains the default value
 */
function get_select_options (&$option_list, $selected) {
	$select_options = "";
	
	//for setting null selection values to human readable --None--
	$pattern = "/''></";
	$replacement = "''>--None--<";
	
	//create the type dropdown domain and set the selected value if $opp value already exists
	foreach ($option_list as $option) {
		if ($selected == $option) $select_options .= "\n<OPTION selected value='$option'>$option</OPTION>";
		else $select_options .= "\n<OPTION value='$option'>$option</OPTION>";
	}
	$select_options = preg_replace($pattern, $replacement, $select_options);
	
	return $select_options;
}

/**
 * Create HTML to display select options in a dropdown list.  To be used inside 
 * of a select statement in a form.   This method expects the option list to have keys and values.  The keys are the ids.  The values are the display strings.
 * param $option_list - the array of strings to that contains the option list
 * param $selected - the string which contains the default value
 */
function get_select_options_with_id (&$option_list, $selected_key) {
	$select_options = "";
	
	//for setting null selection values to human readable --None--
	$pattern = "/''></";
	$replacement = "''>--None--<";
	
	//create the type dropdown domain and set the selected value if $opp value already exists
	foreach ($option_list as $option_key=>$option_value) {
		if ($selected_key == $option_key || ($selected_key == 0 && $option_key == '')) 
		{
			$select_options .= "\n<OPTION selected value='$option_key'>$option_value</OPTION>";
		}
		else 
		{
			$select_options .= "\n<OPTION value='$option_key'>$option_value</OPTION>";
		}
	}
	$select_options = preg_replace($pattern, $replacement, $select_options);
	
	return $select_options;
}

/**
 * Create javascript to clear values of all elements in a form.
 */
function get_clear_form_js () {
$the_script = <<<EOQ
<script type="text/javascript" language="JavaScript">
<!-- Begin
function clear_form(form) {
	for (j = 0; j < form.elements.length; j++) {
		if (form.elements[j].type == 'text' || form.elements[j].type == 'select-one') {
			form.elements[j].value = '';
		}
	}
}
//  End -->
</script>
EOQ;

return $the_script;
}

/**
 * Create javascript to set the cursor focus to specific field in a form 
 * when the screen is rendered.  The field name is currently hardcoded into the
 * the function.
 */
function get_set_focus_js () {
//TODO Clint 5/20 - Make this function more generic so that it can take in the target form and field names as variables
$the_script = <<<EOQ
<script type="text/javascript" language="JavaScript">
<!-- Begin
function set_focus() {
	if (document.forms.length > 0) {
		for (i = 0; i < document.forms.length; i++) {
			for (j = 0; j < document.forms[i].elements.length; j++) {
				var field = document.forms[i].elements[j];
				if ((field.type == "text" || field.type == "textarea" || field.type == "password") && 
						!field.disabled && (field.name == "first_name" || field.name == "name")) {
					field.focus();
                    if (field.type == "text") {
                        field.select();
                    }
					break;
	    		}
			}
      	}
   	}
}
//  End -->
</script>
EOQ;

return $the_script;
}

/**
 * Very cool algorithm for sorting multi-dimensional arrays.  Found at http://us2.php.net/manual/en/function.array-multisort.php 
 * Syntax: $new_array = array_csort($array [, 'col1' [, SORT_FLAG [, SORT_FLAG]]]...);
 * Explanation: $array is the array you want to sort, 'col1' is the name of the column 
 * you want to sort, SORT_FLAGS are : SORT_ASC, SORT_DESC, SORT_REGULAR, SORT_NUMERIC, SORT_STRING
 * you can repeat the 'col',FLAG,FLAG, as often you want, the highest prioritiy is given to 
 * the first - so the array is sorted by the last given column first, then the one before ...
 * Example: $array = array_csort($array,'town','age',SORT_DESC,'name');
 */
function array_csort() {  
   $args = func_get_args();
   $marray = array_shift($args);
   $i = 0;

   $msortline = "return(array_multisort(";
   foreach ($args as $arg) {
	   $i++;
	   if (is_string($arg)) {
		   foreach ($marray as $row) {
			   $sortarr[$i][] = $row[$arg];
		   }
	   } else {
		   $sortarr[$i] = $arg;
	   }
	   $msortline .= "\$sortarr[".$i."],";
   }
   $msortline .= "\$marray));";

   eval($msortline);
   return $marray;
}

?>