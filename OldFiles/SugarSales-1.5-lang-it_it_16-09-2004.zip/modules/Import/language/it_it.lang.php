<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Import/language/en_us.lang.php,v 1.2 2004/09/08 17:41:40 sugarrob Exp $
 * Description:  Defines the English language pack for the Account module.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/
/* 
'LBL_GO_TO_BUTTON_TITLE'=>'Go To Step 2',
'LBL_IMPORT_MODULE_SELECT_DELIMITER'=>'Select Delimiter',
'LBL_IMPORT_MODULE_COMMA_CSV'=>'Comma (CSV)',
'LBL_IMPORT_MODULE_TAB'=>'Tab',
'LBL_IMPORT_MODULE_CUSTOM'=>'Custom:',
'LBL_IMPORT_MODULE_ERROR_NO_UPLOAD'=>'File was not uploaded successfully, try again',
'LBL_IMPORT_MODULE_ERROR_LARGE_FILE'=>'File is too large. Max:',
'LBL_IMPORT_MODULE_ERROR_LARGE_FILE_END'=>'Bytes',
'LBL_IMPORT_MODULE_ERROR'=>'Error:',
'LBL_IMPORT_MODULE_ERROR_MULTIPLE'=>'Multiple columns have been defined with the same field name.',
'LBL_IMPORT_MODULE_ERROR_DELIMITER_NOT'=>'Delimiter was not defined.',
'LBL_IMPORT_MODULE_ERROR_CANT_OPEN'=>'File could not be opened.',
'LBL_IMPORT_MODULE_STEP_1_TITLE'=>'Step 1: File Upload',
'LBL_IMPORT_MODULE_STEP_2_TITLE'=>'Step 2: Choose Field Mappings',
*/



$mod_strings = Array(
'LBL_MODULE_NAME'=>'Import',
'LBL_TRY_AGAIN'=>'Prova ancora',
'LBL_ERROR'=>'Errore:',
'ERR_MULTIPLE'=>'Sono state definite colonne multiple con lo stesso nome campo.',
'ERR_MISSING_REQUIRED_FIELDS'=>'Mancano campi richiesti:',
'ERR_SELECT_FULL_NAME'=>'Non puoi selezionare il Nome completo quando sia Nome che cognome sono selezionati.',
'ERR_SELECT_FILE'=>'Seleziona un file da caricare.',
'LBL_SELECT_FILE'=>'Seleziona file:',
'LBL_CUSTOM'=>'Custom',
'LBL_DONT_MAP'=>'-- Non mappare questo campo --',
'LBL_STEP_1_TITLE'=>'Passo 1: Seleziona la Fonte',
'LBL_WHAT_IS'=>'Qual\'è la fonte dati?',
'LBL_MICROSOFT_OUTLOOK'=>'Microsoft Outlook',
'LBL_ACT'=>'Act!',
'LBL_SALESFORCE'=>'Salesforce.com',
'LBL_MY_SAVED'=>'My Saved Sources:',
'LBL_PUBLISH'=>'pubblica',
'LBL_DELETE'=>'cancella',
'LBL_PUBLISHED_SOURCES'=>'Fonti pubblicate:',
'LBL_UNPUBLISH'=>'rimuovi',
'LBL_NEXT'=>'Prossimo >',
'LBL_BACK'=>'< Indietro',
'LBL_STEP_2_TITLE'=>'Passo 2: Carica il file di export',
'LBL_HAS_HEADER'=>'Ha header:',

'LBL_NUM_1'=>'1.',
'LBL_NUM_2'=>'2.',
'LBL_NUM_3'=>'3.',
'LBL_NUM_4'=>'4.',
'LBL_NUM_5'=>'5.',
'LBL_NUM_6'=>'6.',
'LBL_NUM_7'=>'7.',
'LBL_NUM_8'=>'8.',
'LBL_NUM_9'=>'9.',
'LBL_NUM_10'=>'10.',
'LBL_NUM_11'=>'11.',
'LBL_NUM_12'=>'12.',
'LBL_NOW_CHOOSE'=>'Ora scegli il file da importare:',
'LBL_IMPORT_OUTLOOK_TITLE'=>'Microsoft Outlook 98 e 2000 possono esportare dati in formato <b>Comma Separated Values</b> che può essere usato per importare i dati nel sistema. Per esportare i dati da Outlook, segui i passi qui sotto:',
'LBL_OUTLOOK_NUM_1'=>'Avvia <b>Outlook</b>',
'LBL_OUTLOOK_NUM_2'=>'Seleziona il menu <b>File</b>, poi l\'opzione <b>Import and Export ...</b>',
'LBL_OUTLOOK_NUM_3'=>'Scegli <b>Export to a file</b> e clicca Next',
'LBL_OUTLOOK_NUM_4'=>'Scegli <b>Comma Separated Values (Windows)</b> e clicca <b>Next</b>.<br>  Nota: potresti dover istallare il componente di export',
'LBL_OUTLOOK_NUM_5'=>'Seleziona la cartella <b>Contatti</b> e clicca <b>Next</b>. Puoi selezionare diverse cartelle di contatti se i tuoi contatti sono in varie cartelle',
'LBL_OUTLOOK_NUM_6'=>'Scegli un nome file e clicca <b>Next</b>',
'LBL_OUTLOOK_NUM_7'=>'Clicca <b>Finish</b>',
'LBL_IMPORT_ACT_TITLE'=>'Act! può esportare dati in formato <b>Comma Separated Values</b> che può essere usato per importare i dati nel sistema. Per esportare i dati da Act!, segui i passi qui sotto:',
'LBL_ACT_NUM_1'=>'Esegui <b>ACT!</b>',
'LBL_ACT_NUM_2'=>'Seleziona il menu <b>File</b>, l\'opzione<b>Data Exchange</b>, e infine l\'opzione<b>Export...</b>',
'LBL_ACT_NUM_3'=>'Seleziona il tipo file <b>Text-Delimited</b>',
'LBL_ACT_NUM_4'=>'Scegli un nome file ed una directory per i dati esportati e clicca <b>Next</b>',
'LBL_ACT_NUM_5'=>'Seleziona <b>Contacts records only</b>',
'LBL_ACT_NUM_6'=>'Clicca sul bottone <b>Options...</b>',
'LBL_ACT_NUM_7'=>'Seleziona <b>Comma</b> come carattere separatore di campo',
'LBL_ACT_NUM_8'=>'Abilita il checkbox <b>Yes, export field names</b> e clicca <b>OK</b>',
'LBL_ACT_NUM_9'=>'Clicca <b>Next</b>',
'LBL_ACT_NUM_10'=>'Seleziona <b>All Records</b> e poi clicca <b>Finish</b>',

'LBL_IMPORT_SF_TITLE'=>'Salesforce.com può esportare dati in formato <b>Comma Separated Values</b> che può essere usato per importare dati nel sistema. Per esportare i ttuoi dati da Salesforce.com, segui i passi qui sotto:',
'LBL_SF_NUM_1'=>'Apri il tuo browser, vai a http://www.salesforce.com, e collegati con il tuo indirizzo email e la password',
'LBL_SF_NUM_2'=>'Seleziona sul tab <b>Reports</b> nel menu in alto',
'LBL_SF_NUM_3'=>'Per esportare i clienti:</b> Clicca sul link <b>Active Accounts</b> link<br><b>Per esportare i contatti:</b> Clicca sul link <b>Mailing List</b> link',
'LBL_SF_NUM_4'=>'Su <b>Step 1: Select your report type</b>, seleziona <b>Tabular Report</b>clicca <b>Next</b>',
'LBL_SF_NUM_5'=>'Su <b>Step 2: Select the report columns</b>, seleziona le colonne che vuoi esportare e clicca <b>Next</b>',
'LBL_SF_NUM_6'=>'Su <b>Step 3: Select the information to summarize</b>, clicca <b>Next</b>',
'LBL_SF_NUM_7'=>'Su <b>Step 4: Order the report columns</b>, clicca <b>Next</b>',
'LBL_SF_NUM_8'=>'Su <b>Step 5: Select your report criteria</b>, sotto <b>Start Date</b>, scegli una data passata sufficinete per includere tutti i Clienti. Puoi anche esportare un sotoinsieme del clienti usando criteri più avanzati. Quando hai finito, clicca <b>Run Report</b>',
'LBL_SF_NUM_9'=>'Sarà generato un report, e la pagina dovrebbe mostrare <b>Report Generation Status: Complete.</b> Ora clicca <b>Export to Excel</b>',
'LBL_SF_NUM_10'=>'Su <b>Export Report:</b>, per <b>Export File Format:</b>, scegli <b>Comma Delimited .csv</b>. Clicca <b>Export</b>.',
'LBL_SF_NUM_11'=>'Apparirà un dialogo per salvare il file di exportsul tuo computer.',
'LBL_IMPORT_CUSTOM_TITLE'=>'Molte applicazioni ti permettono di esportare dati in formato <b>Comma Delimited text file (.csv)</b>. Generalmente, la maggior parte delle applicazioni seguono questa procedura:',
'LBL_CUSTOM_NUM_1'=>'Esegui l\'applicazione e apri il file di dati',
'LBL_CUSTOM_NUM_2'=>'Seleziona il <b>Save As...</b> o l\'opzione di menu <b>Export...</b>',
'LBL_CUSTOM_NUM_3'=>'Salva il file in formato <b>CSV</b> o <b>Comma Separated Values</b>',

'LBL_STEP_3_TITLE'=>'Passo 3: conferma i campi e importa',

'LBL_SELECT_FIELDS_TO_MAP'=>'Nella lista sotto seleziona i campi del file di import che devono essere importati nel sistema. quando hai finito clicca <b>Import Now</b>:',

'LBL_DATABASE_FIELD'=>'Campi del database',
'LBL_HEADER_ROW'=>'Riga di intestazione',
'LBL_ROW'=>'Riga',
'LBL_SAVE_AS_CUSTOM'=>'Salva come Custom Mapping:',
'LBL_CONTACTS_NOTE_1'=>'Devi mappare o il Cognome o il nome completo.',
'LBL_CONTACTS_NOTE_2'=>'Se mappi il Nome completo, allora Nome e Cognome vengono ignorati.',
'LBL_CONTACTS_NOTE_3'=>'Se mappi il Nome completo, allora idati in questo campo verranno separati in Nome e Cognome all\'inserimento nel database.',
'LBL_CONTACTS_NOTE_4'=>'I campi Address Street 2 and Address Street 3 sono concatenati assieme a Address Street all\'inserimento nel database.',
'LBL_ACCOUNTS_NOTE_1'=>'Il nome cliente deve essere mappato.',
'LBL_ACCOUNTS_NOTE_2'=>'I campi Address Street 2 and Address Street 3 sono concatenati assieme a Address Street all\'inserimento nel database.',
'LBL_IMPORT_NOW'=>'Importa ora',
'LBL_'=>'',
'LBL_'=>'',
'LBL_CANNOT_OPEN'=>'Non posso aprire in lettura il file di import',
'LBL_NOT_SAME_NUMBER'=>'Non ci sono lo stesso numero di campi per riga nel tuo file',
'LBL_NO_LINES'=>'Non ci sono righe nel tuo file di import',
'LBL_FILE_ALREADY_BEEN_OR'=>'Il file di import è gia stato processato o non esiste',
'LBL_SUCCESS'=>'Riuscito:',
'LBL_SUCCESSFULLY'=>'Import riuscito',
'LBL_LAST_IMPORT_UNDONE'=>'Il tuo ultimo import è stato annullato',
'LBL_NO_IMPORT_TO_UNDO'=>'Non ci sono import da annullare.',
'LBL_FAIL'=>'Fallito:',
'LBL_RECORDS_SKIPPED'=>'righe saltate',
'LBL_IDS_EXISTED_OR_LONGER'=>'id che gia esistono o sono più lunghe di 36 caratteri',
'LBL_RESULTS'=>'Risultati',
'LBL_IMPORT_MORE'=>'Importa ancora',
'LBL_FINISHED'=>'Finito',
'LBL_UNDO_LAST_IMPORT'=>'Annulla l\'ultimo Import',



);

$mod_list_strings = Array(
'contacts_import_fields' => Array(
	"id"=>"Contact ID"
	,"first_name"=>"Nome"
	,"last_name"=>"Cognome"
	,"salutation"=>"Titolo"
	,"lead_source"=>"Origine del Lead"	,"birthdate"=>"data di nascita"
	,"do_not_call"=>"non chiamare"
	,"email_opt_out"=>"non inviare email"
	,"primary_address_street_2"=>"Indirizzo principale Via 2"
	,"primary_address_street_3"=>"Indirizzo principale Via 3"
	,"alt_address_street_2"=>"Altro Indirizzo Via 2"
	,"alt_address_street_3"=>"altro Indirizzo Via 3"
	,"full_name"=>"Nome Completo"
	,"account_name"=>"Nome Cliente"
	,"account_id"=>"ID Cliente"
	,"title"=>"Titolo"
	,"department"=>"Dipartimento"
	,"birthdate"=>"Data di nascita"
	,"do_not_call"=>"Non chiamare"
	,"phone_home"=>"Telefono (Casa)"
	,"phone_mobile"=>"Telefono (Mobile)"
	,"phone_work"=>"Telefono (Ufficio)"
	,"phone_other"=>"Telefono (Altro)"
	,"phone_fax"=>"Fax"
	,"email1"=>"Email"
	,"email2"=>"Email (altra)"
	,"yahoo_id"=>"Yahoo! ID"
	,"assistant"=>"Assistente"
	,"assistant_phone"=>"Telefono Assistente"
	,"primary_address_street"=>"Indirizzo principale: Via"
	,"primary_address_city"=>"Indirizzo principale: Località"
	,"primary_address_state"=>"Indirizzo principale: Provincia"
	,"primary_address_postalcode"=>"Indirizzo principale: C.A.P."
	,"primary_address_country"=>"Indirizzo principale: Nazione"
	,"alt_address_street"=>"Altro indirizzo: Via"
	,"alt_address_city"=>"Altro indirizzo: Località"
	,"alt_address_state"=>"Altro indirizzo: Provincia"
	,"alt_address_postalcode"=>"Altro indirizzo: C.A.P."
	,"alt_address_country"=>"Altro indirizzo: Nazione"
	,"description"=>"Descrizione"

	),

'accounts_import_fields' => Array(
	"id"=>"ID cliente",
	"name"=>"Nome cliente",
	"website"=>"sito web",
	"industry"=>"Sett.Merceologico",
	"type"=>"Tipo",
	"ticker_symbol"=>"Simbolo (Ticker)",
	"parent_name"=>"Membro di",
	"employees"=>"Occupati",
	"ownership"=>"Proprietà",
	"phone_office"=>"Telefono",
	"phone_fax"=>"Fax",
	"phone_alternate"=>"Altro telefono",
	"email1"=>"Email",
	"email2"=>"Altra Email",
	"rating"=>"Rating",
	"sic_code"=>"Codice SIC",
	"annual_revenue"=>"Revenue Annuali",
	"billing_address_street"=>"Indirizzo di Fatturazione: Via",
	"billing_address_street_2"=>"Indirizzo di Fatturazione: Via 2",
	"billing_address_street_3"=>"Indirizzo di Fatturazione: Via 3",
	"billing_address_street_4"=>"Indirizzo di Fatturazione: Via 4",
	"billing_address_city"=>"Indirizzo di Fatturazione: Località",
	"billing_address_state"=>"Indirizzo di Fatturazione: Provincia",
	"billing_address_postalcode"=>"Indirizzo di Fatturazione: C.A.P.",
	"billing_address_country"=>"Indirizzo di Fatturazione: Nazione",
	"shipping_address_street"=>"Indirizzo di Spedizione: Via",
	"shipping_address_street_2"=>"Indirizzo di Spedizione: Via 2",
	"shipping_address_street_3"=>"Indirizzo di Spedizione: Via 3",
	"shipping_address_street_4"=>"Indirizzo di Spedizione: Via 4",
	"shipping_address_city"=>"Indirizzo di Spedizione: Località",
	"shipping_address_state"=>"Indirizzo di Spedizione: Provincia",
	"shipping_address_postalcode"=>"Indirizzo di Spedizione: C.A.P.",
	"shipping_address_country"=>"Indirizzo di Spedizione: Nazione",
	"description"=>"Descrizione"
	)

);

?>
