<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1
 * ("License"); You may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Opportunities/ListView.php,v 1.12 2004/06/29 21:06:28 sugarclint Exp $
 * Description:  TODO: To be written.
 ********************************************************************************/

require_once('XTemplate/xtpl.php');
require_once("data/Tracker.php");
require_once('modules/Opportunities/Opportunity.php');
require_once('include/utils.php');
require_once('themes/'.$theme.'/layout_utils.php');
require_once('include/logging.php');

global $list_max_entries_per_page;
global $urlPrefix;

$log = LoggerManager::getLogger('opportunity_list');

global $currentModule;
global $moduleList;
global $theme;

if (!isset($where)) $where = "";

$seedOpportunity = new Opportunity();
if(isset($_REQUEST['query']))
{
	// we have a query
	if (isset($_REQUEST['name'])) $name = $_REQUEST['name'];
	if (isset($_REQUEST['account_name'])) $account_name = $_REQUEST['account_name'];
	if (isset($_REQUEST['date_closed'])) $date_closed = $_REQUEST['date_closed'];

	if (isset($_REQUEST['amount'])) $amount = $_REQUEST['amount'];
	if (isset($_REQUEST['next_step'])) $next_step = $_REQUEST['next_step'];
	if (isset($_REQUEST['probability'])) $probability = $_REQUEST['probability'];

	if (isset($_REQUEST['lead_source'])) $lead_source = $_REQUEST['lead_source']; 
	if (isset($_REQUEST['opportunity_type'])) $opportunity_type = $_REQUEST['opportunity_type']; 
	if (isset($_REQUEST['sales_stage'])) $sales_stage = $_REQUEST['sales_stage']; 

	$where_clauses = Array();

	if(isset($name) && $name != "") array_push($where_clauses, "opportunities.name like '$name%'");
	if(isset($account_name) && $account_name != "") array_push($where_clauses, "accounts.name like '$account_name%'");
	if(isset($lead_source) && $lead_source != "") array_push($where_clauses, "opportunities.lead_source = '$lead_source'");
	if(isset($opportunity_type) && $opportunity_type != "") array_push($where_clauses, "opportunities.opportunity_type = '$opportunity_type'");
	if(isset($amount) && $amount != "") array_push($where_clauses, "opportunities.amount like '$amount%%'");
	if(isset($next_step) && $next_step != "") array_push($where_clauses, "opportunities.next_step like '$next_step%'");
	if(isset($sales_stage) && $sales_stage != "") array_push($where_clauses, "opportunities.sales_stage = '$sales_stage'");
	if(isset($probability) && $probability != "") array_push($where_clauses, "opportunities.probability like '$probability%'");

	$where = "";
	foreach($where_clauses as $clause)
	{
		if($where != "")
		$where .= " and ";
		$where .= $clause;
	}

	$log->info("Here is the where clause for the list view: $where");

}

if (!isset($_REQUEST['search_form']) || $_REQUEST['search_form'] != 'false') {
	// Stick the form header out there.
	$search_form=new XTemplate ('modules/Opportunities/SearchForm.html');
	
	if (isset($name)) $search_form->assign("NAME", $name);
	if (isset($account_name)) $search_form->assign("ACCOUNT_NAME", $account_name);
	$search_form->assign("JAVASCRIPT", get_clear_form_js());

	echo get_form_header("Opportunity Search", "", false);
	if (isset($_REQUEST['advanced']) && $_REQUEST['advanced'] == 'true') { 
		if (isset($amount)) $search_form->assign("AMOUNT", $amount);
		if (isset($date_entered)) $search_form->assign("DATE_ENTERED", $date_entered);
		if (isset($date_closed)) $search_form->assign("DATE_CLOSED", $date_closed);
		if (isset($next_step)) $search_form->assign("NEXT_STEP", $next_step);
		if (isset($probability)) $search_form->assign("PROBABILITY", $probability);
		if (isset($date_modified)) $search_form->assign("DATE_MODIFIED", $date_modified);
		if (isset($modified_user_id)) $search_form->assign("MODIFIED_USER_ID", $modified_user_id);

		if (isset($lead_source)) $search_form->assign("LEAD_SOURCE_OPTIONS", get_select_options($seedOpportunity->lead_source_dom, $lead_source));
		else $search_form->assign("LEAD_SOURCE_OPTIONS", get_select_options($seedOpportunity->lead_source_dom, ''));
		if (isset($opportunity_type)) $search_form->assign("TYPE_OPTIONS", get_select_options($seedOpportunity->opportunity_type_dom, $opportunity_type));
		else $search_form->assign("TYPE_OPTIONS", get_select_options($seedOpportunity->opportunity_type_dom, ''));
		
		$sales_stage_dom = & $seedOpportunity->sales_stage_dom;
		array_unshift($sales_stage_dom, '');
		if (isset($sales_stage)) $search_form->assign("SALES_STAGE_OPTIONS", get_select_options($sales_stage_dom, $sales_stage));
		else $search_form->assign("SALES_STAGE_OPTIONS", get_select_options($seedOpportunity->sales_stage_dom, ''));

		$search_form->parse("advanced");
		$search_form->out("advanced");
	}
	else {
		$search_form->parse("main");
		$search_form->out("main");
	}
	echo get_form_footer();
	echo "\n<BR>\n";
}

$list_form=new XTemplate ('modules/Opportunities/ListView.html');
$list_form->assign("THEME", $theme);
$list_form->assign("IMAGE_PATH", $image_path);
$list_form->assign("MODULE_NAME", $currentModule);

$current_offset = 0;
if(isset($_REQUEST['current_offset']))
    $current_offset = $_REQUEST['current_offset'];

$response = $seedOpportunity->get_list("name", $where, $current_offset);

$opportunityList = $response['list'];
$row_count = $response['row_count'];
$next_offset = $response['next_offset'];
$previous_offset = $response['previous_offset'];

$start_record = $current_offset + 1;

// Set the start row to 0 if there are no rows (adding one looks bad)
if($row_count == 0)
    $start_record = 0;

$end_record = $start_record + $list_max_entries_per_page;

// back up the the last page.
if($end_record > $row_count+1)
{
    $end_record = $row_count+1;
}

// Deterime the start location of the last page
if($row_count == 0)
	$number_pages = 0;
else
	$number_pages = floor(($row_count - 1) / $list_max_entries_per_page);

$last_page_offset = $number_pages * $list_max_entries_per_page;


// Create the base URL without the current offset.
// Check to see if the current offset is already there
// If not, add it to the end.

// All of the other values should use a regular expression search
$base_URL = "http://".$_SERVER['HTTP_HOST'].$_SERVER['SCRIPT_NAME'] .'?'.$_SERVER['QUERY_STRING']."&current_offset=";
$start_URL = $base_URL."0";
$previous_URL  = $base_URL.$previous_offset;
$next_URL  = $base_URL.$next_offset;
$end_URL  = $base_URL.$last_page_offset;

$sort_URL_base = $base_URL.$current_offset."&sort_order=";

$log->debug("Offsets: (start, previous, next, last)(0, $previous_offset, $next_offset, $last_page_offset)");

if(0 == $current_offset)
    $start_link = "Start";
else
    $start_link = "<a href=\"$start_URL\" class=\"listFormHeaderLinks\">Start</a>";

if($previous_offset < 0)
    $previous_link = "Previous";
else
    $previous_link = "<a href=\"$previous_URL\" class=\"listFormHeaderLinks\">Previous</a>";

if($next_offset >= $end_record)
    $next_link = "Next";
else
    $next_link = "<a href=\"$next_URL\" class=\"listFormHeaderLinks\">Next</a>";

if($last_page_offset <= $current_offset)
    $end_link = "End";
else
    $end_link = "<a href=\"$end_URL\" class=\"listFormHeaderLinks\">End</a>";

$log->info("Offset (next, current, prev)($next_offset, $current_offset, $previous_offset)");
$log->info("Start/end records ($start_record, $end_record)");

$list_form->assign("START_RECORD", $start_record);
$list_form->assign("END_RECORD", $end_record-1);
$list_form->assign("ROW_COUNT", $row_count);
if ($start_link !== "") $list_form->assign("START_LINK", "[ ".$start_link." ]");
if ($end_link !== "") $list_form->assign("END_LINK", "[ ".$end_link." ]");
if ($next_link !== "") $list_form->assign("NEXT_LINK", "[ ".$next_link." ]");
if ($previous_link !== "") $list_form->assign("PREVIOUS_LINK", "[ ".$previous_link." ]");
$list_form->parse("main.list_nav_row");


$oddRow = true;
foreach($opportunityList as $opportunity)
{
	$opportunity_fields = array(
		'ID' => $opportunity->id,
		'NAME' => $opportunity->name,
		'ACCOUNT_NAME' => $opportunity->account_name,
		'ACCOUNT_ID' => $opportunity->account_id,
		'DATE_CLOSED' => $opportunity->date_closed,
	);
	
	if ($opportunity_fields['NAME'] == '') $opportunity_fields['NAME'] = '<em>blank</em>';
	
	$list_form->assign("OPPORTUNITY", $opportunity_fields);
	
	if($oddRow)
    {
        //todo move to themes
		$list_form->assign("ROW_COLOR", 'oddListRow');
    }
    else
    {
        //todo move to themes
		$list_form->assign("ROW_COLOR", 'evenListRow');
    }
    $oddRow = !$oddRow;

	$list_form->parse("main.row");
// Put the rows in.
}

$list_form->parse("main");

echo get_form_header("Opportunity List", "", false);
$list_form->out("main");
echo get_form_footer();

echo "</td></tr>\n</table>\n";

?>
