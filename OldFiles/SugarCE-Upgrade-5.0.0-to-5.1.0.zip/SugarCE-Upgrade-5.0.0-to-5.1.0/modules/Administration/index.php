<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2008 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/
/*********************************************************************************

 * Description: TODO:  To be written.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

global $app_strings;
global $app_list_strings;
global $mod_strings;
global $theme;
global $currentModule;
global $current_language;
global $gridline;
global $current_user;
global $sugar_flavor;

$theme_path="themes/".$theme."/";
$image_path=$theme_path."images/";

require_once($theme_path.'layout_utils.php');

require_once('XTemplate/xtpl.php');



if (!is_admin($current_user))
{
   sugar_die("Unauthorized access to administration.");
}

echo '<p>' .
      get_module_title($mod_strings['LBL_MODULE_NAME'],
                       $mod_strings['LBL_MODULE_TITLE'], true)
      . '</p>';











//Sugar Network
$admin_option_defs=array();
$license_key = 'no_key';

$admin_option_defs['support']= array($image_path . 'Support','LBL_SUPPORT_TITLE','LBL_SUPPORT','./index.php?module=Administration&action=SupportPortal&view=support_portal');
//$admin_option_defs['documentation']= array($image_path . 'OnlineDocumentation','LBL_DOCUMENTATION_TITLE','LBL_DOCUMENTATION','./index.php?module=Administration&action=SupportPortal&view=documentation&help_module=Administration&edition='.$sugar_flavor.'&key='.$server_unique_key.'&language='.$current_language);
$admin_option_defs['documentation']= array($image_path . 'OnlineDocumentation','LBL_DOCUMENTATION_TITLE','LBL_DOCUMENTATION',
    'javascript:void window.open("index.php?module=Administration&action=SupportPortal&view=documentation&help_module=Administration&edition='.$sugar_flavor.'&key='.$server_unique_key.'&language='.$current_language.'", "helpwin","width=600,height=600,status=0,resizable=1,scrollbars=1,toolbar=0,location=0")');

$admin_option_defs['update'] = array($image_path . 'sugarupdate','LBL_SUGAR_UPDATE_TITLE','LBL_SUGAR_UPDATE','./index.php?module=Administration&action=Updater');
if(!empty($license->settings['license_latest_versions'])){
	$encodedVersions = $license->settings['license_latest_versions'];
	$versions = unserialize(base64_decode( $encodedVersions));
	include('sugar_version.php');
	if(!empty($versions)){
		foreach($versions as $version){
			if($version['version'] > $sugar_version )
			{
				$admin_option_defs['update'][] ='red';
				if(!isset($admin_option_defs['update']['additional_label']))$admin_option_defs['update']['additional_label']= '('.$version['version'].')';

			}
		}
	}
}








$admin_group_header[]=array('LBL_SUGAR_NETWORK_TITLE','',false,$admin_option_defs, 'LBL_SUGAR_NETWORK_DESC');
















//system.
$admin_option_defs=array();
$admin_option_defs['configphp_settings']= array($image_path .'Administration','LBL_CONFIGURE_SETTINGS_TITLE','LBL_CONFIGURE_SETTINGS','./index.php?module=Configurator&action=EditView');

$admin_option_defs['backup_management']= array($image_path . 'Backups','LBL_BACKUPS_TITLE','LBL_BACKUPS','./index.php?module=Administration&action=Backups');

$admin_option_defs['scheduler'] = array($image_path . 'Schedulers','LBL_SUGAR_SCHEDULER_TITLE','LBL_SUGAR_SCHEDULER','./index.php?module=Schedulers&action=index');
$admin_option_defs['repair']= array($image_path . 'Repair','LBL_UPGRADE_TITLE','LBL_UPGRADE','./index.php?module=Administration&action=Upgrade');
$admin_option_defs['diagnostic']= array($image_path . 'Diagnostic','LBL_DIAGNOSTIC_TITLE','LBL_DIAGNOSTIC_DESC','./index.php?module=Administration&action=Diagnostic');

$admin_option_defs['currencies_management']= array($image_path . 'Currencies','LBL_MANAGE_CURRENCIES','LBL_CURRENCY','./index.php?module=Currencies&action=index');

$admin_option_defs['upgrade_wizard']= array($image_path . 'Upgrade','LBL_UPGRADE_WIZARD_TITLE','LBL_UPGRADE_WIZARD','./index.php?module=UpgradeWizard&action=index');


//$admin_option_defs['module_loader'] = array($image_path . 'ModuleLoader','LBL_MODULE_LOADER_TITLE','LBL_MODULE_LOADER','./index.php?module=Administration&action=UpgradeWizard&view=module');

$admin_option_defs['locale']= array($image_path . 'Currencies','LBL_MANAGE_LOCALE','LBL_LOCALE','./index.php?module=Administration&action=Locale&view=default');






$admin_option_defs['tracker_settings']=array($image_path . 'Trackers','LBL_TRACKER_SETTINGS','LBL_TRACKER_SETTINGS_DESC','./index.php?module=Trackers&action=TrackerSettings');

$admin_group_header[]=array('LBL_ADMINISTRATION_HOME_TITLE','',false,$admin_option_defs, 'LBL_ADMINISTRATION_HOME_DESC');

//users and security.
$admin_option_defs=array();
$admin_option_defs['user_management']= array($image_path . 'Users','LBL_MANAGE_USERS_TITLE','LBL_MANAGE_USERS','./index.php?module=Users&action=index');
$admin_option_defs['roles_management']= array($image_path . 'Roles','LBL_MANAGE_ROLES_TITLE','LBL_MANAGE_ROLES','./index.php?module=ACLRoles&action=index');



$admin_group_header[]=array('LBL_USERS_TITLE','',false,$admin_option_defs, 'LBL_USERS_DESC');

//email manager.
$admin_option_defs=array();
$admin_option_defs['mass_Email_config']= array($image_path . 'EmailMan','LBL_MASS_EMAIL_CONFIG_TITLE','LBL_MASS_EMAIL_CONFIG_DESC','./index.php?module=EmailMan&action=config');

$admin_option_defs['mass_Email']= array($image_path . 'EmailMan','LBL_MASS_EMAIL_MANAGER_TITLE','LBL_MASS_EMAIL_MANAGER_DESC','./index.php?module=EmailMan&action=index');

$admin_option_defs['mailboxes']= array($image_path . 'InboundEmail','LBL_MANAGE_MAILBOX','LBL_MAILBOX_DESC','./index.php?module=InboundEmail&action=index');

$admin_option_defs['campaignconfig']= array($image_path . 'Campaigns','LBL_CAMPAIGN_CONFIG_TITLE','LBL_CAMPAIGN_CONFIG_DESC','./index.php?module=EmailMan&action=campaignconfig');

$admin_group_header[]=array('LBL_EMAIL_TITLE','',false,$admin_option_defs, 'LBL_EMAIL_DESC');



//studio.
$admin_option_defs=array();
$admin_option_defs['studio']= array($image_path . 'Studio','LBL_STUDIO','LBL_STUDIO_DESC','./index.php?module=ModuleBuilder&action=index&type=studio');
$admin_option_defs['portal']= array($image_path . 'iFrames','LBL_IFRAME','DESC_IFRAME','./index.php?module=iFrames&action=index');
$admin_option_defs['moduleBuilder']= array($image_path . 'ModuleBuilder','LBL_MODULEBUILDER','LBL_MODULEBUILDER_DESC','./index.php?module=ModuleBuilder&action=index&type=mb');



$admin_option_defs['module_loader'] = array($image_path . 'ModuleLoader','LBL_MODULE_LOADER_TITLE','LBL_MODULE_LOADER','./index.php?module=Administration&action=UpgradeWizard&view=module');
$admin_option_defs['configure_tabs']= array($image_path . 'ConfigureTabs','LBL_CONFIGURE_TABS','LBL_CHOOSE_WHICH','./index.php?module=Administration&action=ConfigureTabs');
$admin_option_defs['dropdowneditor']= array($image_path . 'Dropdown','LBL_DROPDOWN_EDITOR','DESC_DROPDOWN_EDITOR','./index.php?module=ModuleBuilder&action=index&type=dropdowns');
$admin_option_defs['configure_group_tabs']= array($image_path . 'ConfigureTabs','LBL_CONFIGURE_GROUP_TABS','LBL_CONFIGURE_GROUP_TABS_DESC','./index.php?action=wizard&module=Studio&wizard=StudioWizard&option=ConfigureGroupTabs');
//$admin_option_defs['migrate_custom_fields']= array($image_path . 'MigrateFields','LBL_EXTERNAL_DEV_TITLE','LBL_EXTERNAL_DEV_DESC','./index.php?module=Administration&action=Development');



$admin_option_defs['rename_tabs']= array($image_path . 'RenameTabs','LBL_RENAME_TABS','LBL_CHANGE_NAME_TABS',"./index.php?action=wizard&module=Studio&wizard=StudioWizard&option=RenameTabs");

$admin_group_header[]=array('LBL_STUDIO_TITLE','',false,$admin_option_defs, 'LBL_TOOLS_DESC');














//bug tracker.
$admin_option_defs=array();
$admin_option_defs['bug_tracker']= array($image_path . 'Releases','LBL_MANAGE_RELEASES','LBL_RELEASE','./index.php?module=Releases&action=index');
$admin_group_header[]=array('LBL_BUG_TITLE','',false,$admin_option_defs, 'LBL_BUG_DESC');















if(file_exists('custom/modules/Administration/Ext/Administration/administration.ext.php')){
	require_once('custom/modules/Administration/Ext/Administration/administration.ext.php');
}
$xtpl=new XTemplate ('modules/Administration/index.html');

foreach ($admin_group_header as $values) {
	$group_header_value=get_form_header($mod_strings[$values[0]],$values[1],$values[2]);
	$xtpl->assign("GROUP_HEADER", '<table cellpadding="0" cellspacing="0" width="100%" class="h3Row"><tr ><td width="20%" valign="bottom"><h3>' . translate($values[0]) . '</h3></td></tr>');
	if (isset($values[4])) {
	   $xtpl->assign("GROUP_DESC", '<tr><td style="padding-top: 3px; padding-bottom: 5px;">' . translate($values[4]) . '</td></tr></table>');
	}else {
	    $xtpl->assign("GROUP_DESC", "</tr></table>");
	}

   $colnum=0;
	foreach ($values[3] as $link_idx=>$admin_option) {
		if(!empty($GLOBALS['admin_access_control_links']) && in_array($link_idx, $GLOBALS['admin_access_control_links'])){
			continue;
		}
		$colnum+=1;
		$xtpl->assign("ITEM_HEADER_IMAGE", get_image($admin_option[0],'alt="' .  $mod_strings[$admin_option[1]] .'" border="0" align="absmiddle"'));
		$xtpl->assign("ITEM_URL", $admin_option[3]);
		$label = $mod_strings[$admin_option[1]];
		if(!empty($admin_option['additional_label']))$label.= ' '. $admin_option['additional_label'];
		if(!empty($admin_option[4])){
			$label = ' <font color="red">'. $label . '</font>';
		}

		$xtpl->assign("ITEM_HEADER_LABEL",$label);
		$xtpl->assign("ITEM_DESCRIPTION", $mod_strings[$admin_option[2]]);

		$xtpl->parse('main.group.row.col');
		if (($colnum % 2) == 0) {
			$xtpl->parse('main.group.row');
		}
	}
	//if the loop above ends with an odd entry add a blank column.
	if (($colnum % 2) != 0) {
		$xtpl->parse('main.group.row.empty');
		$xtpl->parse('main.group.row');
	}

	$xtpl->parse('main.group');
}
$xtpl->parse('main');
$xtpl->out('main');
?>
