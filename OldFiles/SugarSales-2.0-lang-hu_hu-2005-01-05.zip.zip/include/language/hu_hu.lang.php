<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * 
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and 
 * (ii) the SugarCRM copyright notice 
 * in the same form as they appear in the distribution.  See full license for requirements.
 * 
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 *
 * Description:  Defines the Hungarian (Magyar) language pack for the base application.
 * Portions created by Pict&Show are Copyright (C) Pict&Show Kft.
 * All Rights Reserved. Version 0.1.0.
 * Contributor(s): Csaba Szigetv�ri (Pict&Show Kft., Hungary). 2004-11-25
 ********************************************************************************/

//the left value is the key stored in the db and the right value is the display value
//to translate, only modify the right value in each key/value pair
$app_list_strings = array (
//pl. magyarul 'Contacts'=>'Kapcsolatok',
  'moduleList' => 
  array (
    'Home' => 'Honlap',
    'Dashboard' => 'Kimutat�sok',
    'Contacts' => 'Kapcsolatok',
    'Accounts' => '�gyfelek',
    'Opportunities' => '�zlet',
    'Cases' => '�gyek',
    'Notes' => 'Jegyzetek',
    'Calls' => 'H�v�sok',
    'Emails' => 'Emailek',
    'Meetings' => 'T�rgyal�sok',
    'Tasks' => 'Feladatok',
    'Calendar' => 'Napt�r',
    'Leads' => '�rdekl�d�k',





    'Activities' => 'Aktivit�sok',
  ),
  //e.g. en fran�ais 'Analyst'=>'Analyste',
  'account_type_dom' => 
  array (
    '' => '',
    'Analyst' => 'Analitikus',
    'Competitor' => 'Vet�lyt�rs',
    'Customer' => '�gyf�l',
    'Integrator' => 'Integr�tor',
    'Investor' => 'Befektet�',
    'Partner' => 'Partner',
    'Press' => 'Sajt�',
    'Prospect' => 'Lehets�ges �gyf�l',
    'Reseller' => 'Viszontelad�',
    'Other' => 'M�s',
  ),
  //e.g. en espa�ol 'Apparel'=>'Ropa',
  'industry_dom' => 
  array (
    '' => '',
    'Apparel' => 'Ruhaipar',
    'Banking' => 'Bank',
    'Biotechnology' => 'Biotechnol�gia',
    'Chemicals' => 'Vegyipar',
    'Communications' => 'Kommunik�ci�',
    'Construction' => 'G�pipar',
    'Consulting' => 'Konzult�ci�',
    'Education' => 'Oktat�s',
    'Electronics' => 'Elektronika',
    'Energy' => 'Energia',
    'Engineering' => 'M�szaki tervez�s',
    'Entertainment' => 'Sz�rakoztat�s',
    'Environmental' => 'K�rnyezetv�delem',
    'Finance' => 'P�nz�gyek',
    'Food & Beverage' => '�lelmiszeripar',
    'Government' => 'Korm�nyzat',
    'Healthcare' => 'Eg�szs�g�gy',
    'Hospitality' => 'Vend�gl�t�ipar',
    'Insurance' => 'Biztos�t�s',
    'Machinery' => 'G�p�szet',
    'Manufacturing' => 'Manufakt�ra',
    'Media' => 'M�dia',
    'Not For Profit' => 'K�zhaszn�',
    'Recreation' => 'Regener�l�s',
    'Retail' => 'Kiskereskedelem',
    'Shipping' => 'Csomagk�ld�s',
    'Technology' => 'Technol�gia',
    'Telecommunications' => 'Telekommunik�ci�',
    'Transportation' => 'Sz�ll�tm�nyoz�s',
    'Utilities' => 'Eszk�z�k',
    'Other' => 'M�s',
  ),
  'lead_source_dom' => 
  array (
    '' => '',
    'Cold Call' => 'Hideg h�v�s',
    'Existing Customer' => 'Megl�v� �gyf�l',
    'Self Generated' => 'Saj�t kezdem�nyez�s',
    'Employee' => 'Alkalmazott',
    'Partner' => 'Partner',
    'Public Relations' => 'Public Relations',
    'Direct Mail' => 'Direct Mail',
    'Conference' => 'Konferencia',
    'Trade Show' => 'Ki�ll�t�s',
    'Web Site' => 'Honlap',
    'Word of mouth' => 'Besz�lget�s',
    'Other' => 'M�s',
  ),
  'opportunity_type_dom' => 
  array (
    '' => '',
    'Existing Business' => 'Megl�v� �zleti kapcsolat',
    'New Business' => '�j �zleti kapcsolat',
  ),
  //Note:  do not translate opportunity_relationship_type_default_key
//       it is the key for the default opportunity_relationship_type_dom value
  'opportunity_relationship_type_default_key' => 'Primary Decision Maker',
  'opportunity_relationship_type_dom' => 
  array (
    '' => '',
    'Primary Decision Maker' => 'Els�dleges d�nt�shoz�',
    'Business Decision Maker' => '�zleti d�nt�shoz�',
    'Business Evaluator' => '�zleti �gyvizsg�l�',
    'Technical Decision Maker' => 'M�szaki d�nt�shoz�',
    'Technical Evaluator' => 'M�szaki �gyvizsg�l�',
    'Executive Sponsor' => 'Kivitelez� t�mogat�',
    'Influencer' => 'Befoly�ssal rendelkez�',
    'Other' => 'M�s',
  ),
  //Note:  do not translate case_relationship_type_default_key
//       it is the key for the default case_relationship_type_dom value
  'case_relationship_type_default_key' => 'Primary Contact',
  'case_relationship_type_dom' => 
  array (
    '' => '',
    'Primary Contact' => 'Els�dleges kapcsolat',
    'Alternate Contact' => 'Alternat�v kapcsolat',
  ),
  'sales_stage_dom' => 
  array (
    'Prospecting' => 'Kibontakoz�',
    'Qualification' => 'Min�s�t�s alatt',
    'Needs Analysis' => 'Elemz�st ig�nyel',
    'Value Proposition' => '�rt�kbecsl�s',
    'Id. Decision Makers' => 'D�nt�shoz�k el�rve',
    'Perception Analysis' => 'Ki�rt�kel�s',
    'Proposal/Price Quote' => 'Aj�nlat/�rlista',
    'Negotiation/Review' => 'Egyeztet�s/�ttekint�s',
    'Closed Won' => 'Sikerrel z�rva',
    'Closed Lost' => 'Sikertelen�l z�rva',
  ),
  'activity_dom' => 
  array (
    'Call' => 'H�v�s',
    'Meeting' => 'T�rgyal�s',
    'Task' => 'Feladat',
    'Email' => 'Email',
    'Note' => 'Jegyzet',
  ),
  'salutation_dom' => 
  array (
    '' => '',
    'Mr.' => '', /* sz�nd�kosan �res a k�vetkez� 2 mez�vel egy�tt a sz�rendi sorrend miatt (Mr. X - X �r) */
    'Ms.' => '',
    'Mrs.' => '',
    'Dr.' => 'Dr.',
    'Prof.' => 'Prof.',
  ),
  'task_priority_dom' => 
  array (
    'High' => 'Magas',
    'Medium' => 'K�zepes',
    'Low' => 'Alacsony',
  ),
  'task_status_dom' => 
  array (
    'Not Started' => 'Indul�s el�tt',
    'In Progress' => 'Folyamatban',
    'Completed' => 'Teljes�tve',
    'Pending Input' => 'Kimenetel f�gg�ben',
    'Deferred' => '�tir�ny�tva',
  ),
  'meeting_status_dom' => 
  array (
    'Planned' => 'Tervezett',
    'Held' => 'Visszatartott',
    'Not Held' => 'Nem visszatartott',
  ),
  'call_status_dom' => 
  array (
    'Planned' => 'Tervezett',
    'Held' => 'Visszatartott',
    'Not Held' => 'Nem visszatartott',
  ),
  'call_direction_dom' => 
  array (
    'Inbound' => 'Bels�',
    'Outbound' => 'K�ls�',
  ),
  'lead_status_dom' => 
  array (
    '' => '',
    'New' => '�j',
    'Assigned' => 'Kiosztva',
    'In Process' => 'Folyamatban',
    'Converted' => '�tv�ltva',
    'Recycled' => 'Visszavezetve',
    'Dead' => 'Le�ll�tva',
  ),
  'lead_status_noblank_dom' => 
  array (
    'New' => '�j',
    'Assigned' => 'Kiosztva',
    'In Process' => 'Folyamatban',
    'Converted' => '�tv�ltva',
    'Recycled' => 'Visszavezetve',
    'Dead' => 'Le�ll�tva',
  ),
  //Note:  do not translate case_status_default_key
//       it is the key for the default case_status_dom value
  'case_status_default_key' => 'New',
  'case_status_dom' => 
  array (
    'New' => '�j',
    'Assigned' => 'Kiosztva',
    'Closed' => 'Lez�rva',
    'Pending Input' => 'Kimenetel f�gg�ben',
    'Rejected' => 'Visszautas�tva',
  ),
  'case_priority_default_key' => 'P2',
  'case_priority_dom' => 
  array (
    'P1' => 'Magas',
    'P2' => 'K�zepes',
    'P3' => 'Alacsony',
  ),
  'user_status_dom' => 
  array (
    'Active' => 'Akt�v',
    'Inactive' => 'Passz�v',
  ),
  //Note:  do not translate record_type_default_key
//       it is the key for the default record_type_module value
  'record_type_default_key' => 'Accounts',
  'record_type_display' => 
  array (
    'Accounts' => '�gyf�l',
    'Opportunities' => '�zlet',
    'Cases' => '�gy',
    'Leads' => '�rdekl�d�k',




  ),
  'notifymail_sendtype' => 
  array (
    'sendmail' => 'sendmail',
    'SMTP' => 'SMTP',
  ),
);

$app_strings = array (
  'LBL_CHARSET' => 'ISO-8859-2',
  'LBL_BROWSER_TITLE' => 'SugarCRM - Commercial Open Source CRM',
  'LBL_MY_ACCOUNT' => 'Szem�lyes fi�k',
  'LBL_ADMIN' => 'Adminisztr�ci�',
  'LBL_LOGOUT' => 'Kil�p�s',
  'LBL_SEARCH' => 'Keres�s',
  'LBL_LAST_VIEWED' => 'Legut�bb megtekintve',
  'NTC_WELCOME' => '�dv�zl�m',
  'NTC_SUPPORT_SUGARCRM' => 'T�mogassa a SugarCRM szabad forr�s projektet!',
  'NTC_NO_ITEMS_DISPLAY' => 'nincs',
  'LBL_ALT_HOT_KEY' => 'Alt+',
  'LBL_SAVE_BUTTON_TITLE' => 'Ment�s [Alt+S]',
  'LBL_EDIT_BUTTON_TITLE' => 'Szerkeszt�s [Alt+E]',
  'LBL_EDIT_BUTTON' => 'Szerkeszt�s',
  'LBL_DUPLICATE_BUTTON_TITLE' => 'M�sol�s [Alt+U]',
  'LBL_DUPLICATE_BUTTON' => 'M�sol�s',
  'LBL_DELETE_BUTTON_TITLE' => 'T�rl�s [Alt+D]',
  'LBL_DELETE_BUTTON' => 'T�rl�s',
  'LBL_NEW_BUTTON_TITLE' => '�j [Alt+N]',
  'LBL_CHANGE_BUTTON_TITLE' => 'M�dos�t�s [Alt+G]',
  'LBL_CANCEL_BUTTON_TITLE' => 'M�gsem [Alt+X]',
  'LBL_SEARCH_BUTTON_TITLE' => 'Keres�s [Alt+Q]',
  'LBL_CLEAR_BUTTON_TITLE' => 'T�rl�s [Alt+C]',
  'LBL_SELECT_BUTTON_TITLE' => 'Kijel�l�s [Alt+T]',
  'LBL_SAVE_BUTTON_KEY' => 'S',
  'LBL_EDIT_BUTTON_KEY' => 'E',
  'LBL_DUPLICATE_BUTTON_KEY' => 'U',
  'LBL_DELETE_BUTTON_KEY' => 'D',
  'LBL_NEW_BUTTON_KEY' => 'N',
  'LBL_CHANGE_BUTTON_KEY' => 'G',
  'LBL_CANCEL_BUTTON_KEY' => 'X',
  'LBL_SEARCH_BUTTON_KEY' => 'Q',
  'LBL_CLEAR_BUTTON_KEY' => 'C',
  'LBL_SELECT_BUTTON_KEY' => 'T',
  'LBL_SAVE_BUTTON_LABEL' => 'Ment�s',
  'LBL_EDIT_BUTTON_LABEL' => 'Szerkeszt�s',
  'LBL_DUPLICATE_BUTTON_LABEL' => 'M�sol�s',
  'LBL_DELETE_BUTTON_LABEL' => 'T�rl�s',
  'LBL_NEW_BUTTON_LABEL' => '�j',
  'LBL_CHANGE_BUTTON_LABEL' => 'M�dos�t�s',
  'LBL_CANCEL_BUTTON_LABEL' => 'M�gsem',
  'LBL_SEARCH_BUTTON_LABEL' => 'Keres�s',
  'LBL_CLEAR_BUTTON_LABEL' => 'T�rl�s',
  'LBL_NEXT_BUTTON_LABEL' => 'K�vetkez�',
  'LBL_SELECT_BUTTON_LABEL' => 'Kijel�l�s',
  'LBL_SELECT_CONTACT_BUTTON_TITLE' => 'Kapcsolat kijel�l�se [Alt+T]',
  'LBL_SELECT_CONTACT_BUTTON_KEY' => 'T',
  'LBL_VIEW_PDF_BUTTON_LABEL' => 'PDF megtekint�se',
  'LBL_VIEW_PDF_CONTACT_BUTTON_TITLE' => 'PDF megtekint�se [Alt+P]',
  'LBL_VIEW_PDF_CONTACT_BUTTON_KEY' => 'P',
  'LBL_SELECT_CONTACT_BUTTON_LABEL' => 'Kapcsolat kijel�l�se',
  'LBL_SELECT_USER_BUTTON_TITLE' => 'Felhaszn�l� kijel�l�se [Alt+U]',
  'LBL_SELECT_USER_BUTTON_KEY' => 'U',
  'LBL_SELECT_USER_BUTTON_LABEL' => 'Felhaszn�l� kijel�l�se',
  'LBL_CREATE_BUTTON_LABEL' => '�j',
  'LBL_SHORTCUTS' => 'Eszk�zt�r',
  'LBL_LIST_NAME' => 'N�v',



  'LBL_LIST_USER_NAME' => 'Felhaszn�l�n�v',
  'LBL_LIST_EMAIL' => 'Email',
  'LBL_LIST_PHONE' => 'Telefon',
  'LBL_LIST_CONTACT_NAME' => 'Kapcsolat neve',
  'LBL_LIST_CONTACT_ROLE' => 'Kapcsolat munkak�re',
  'LBL_LIST_ACCOUNT_NAME' => '�gyf�l neve',
  'LBL_USER_LIST' => 'Felhaszn�l�i lista',
  'LBL_CONTACT_LIST' => 'Kapcsolatok lista',
  'LBL_RELATED_RECORDS' => 'Kapcsol�d� adategys�gek',
  'LBL_MASS_UPDATE' => 'T�meges friss�t�s',
  'LNK_ADVANCED_SEARCH' => 'Halad�',
  'LNK_BASIC_SEARCH' => 'Alapfok�',
  'LNK_EDIT' => 'szerkeszt�s',
  'LNK_REMOVE' => 'elt�vol�t�s',
  'LNK_DELETE' => 't�rl�s',
  'LNK_LIST_START' => 'Kezd�s',
  'LNK_LIST_NEXT' => 'K�vetkez�',
  'LNK_LIST_PREVIOUS' => 'El�z�',
  'LNK_LIST_END' => 'V�ge',
  'LBL_LIST_OF' => '/',
  'LBL_OR' => 'vagy',
  'LNK_PRINT' => 'Nyomtat�s',
  'LNK_HELP' => 'S�g�',
  'LNK_ABOUT' => 'Ismertet�',
  'NTC_REQUIRED' => 'Sz�ks�ges mez�k kijel�l�se',
  'LBL_REQUIRED_SYMBOL' => '*',
  'LBL_CURRENCY_SYMBOL' => '$',
  'LBL_PERCENTAGE_SYMBOL' => '%',
  'LBL_THOUSANDS_SYMBOL' => 'K',
  'NTC_DATE_FORMAT' => '(yyyy-mm-dd)',
  'NTC_TIME_FORMAT' => '(24:00)',
  'NTC_DATE_TIME_FORMAT' => '(yyyy-mm-dd 24:00)',
  'NTC_DELETE_CONFIRMATION' => 'Biztosan t�r�lni k�v�nja ezt az adategys�get?',
  'ERR_DELETE_RECORD' => 'Az adategys�g azonos�t�sz�ma sz�ks�ges a kapcsolat t�rl�s�hez.',
  'ERR_CREATING_TABLE' => 'Hiba a t�bla l�trehozatala sor�n: ',
  'ERR_CREATING_FIELDS' => 'Hiba az adatmez�k kit�lt�se sor�n: ',
  'ERR_MISSING_REQUIRED_FIELDS' => 'Sz�ks�ges adatmez�k kimaradtak:',
  'ERR_INVALID_EMAIL_ADDRESS' => 'az Email-c�m nem �rv�nyes.',
  'ERR_INVALID_DATE_FORMAT' => 'A sz�ks�ges d�tumform�tum: yyyy-mm-dd',
  'ERR_INVALID_MONTH' => 'Adjon meg egy val�s h�napot.',
  'ERR_INVALID_DAY' => 'Adjon meg egy val�s napot.',
  'ERR_INVALID_YEAR' => 'N�gy sz�mjegy� �vet adjon meg.',
  'ERR_INVALID_DATE' => 'Adjon meg egy val�s d�tumot.',
  'ERR_INVALID_HOUR' => 'Adjon meg egy val�s �r�t.',
  'ERR_INVALID_TIME' => 'Adjon meg egy val�s id�pontot.',
  'ERR_INVALID_AMOUNT' => 'Adjon meg egy val�s mennyis�get.',
  'NTC_CLICK_BACK' => 'A b�ng�sz� visszal�p�-gombj�val t�rjen vissza �s jav�tsa a hib�t.',
  'LBL_LIST_ASSIGNED_USER' => 'Felhaszn�l�',
  'LBL_ASSIGNED_TO' => 'Illet�kes:',
  'LBL_DATE_MODIFIED' => 'Utols� m�dos�t�s:',
  'LBL_DATE_ENTERED' => 'L�trehozva:',
  'LBL_CURRENT_USER_FILTER' => 'Csak a saj�t adatok:',
  'NTC_LOGIN_MESSAGE' => 'K�rem adja meg a felhaszn�l�nev�t �s jelszav�t.',
  'LBL_NONE' => '--Nincs--',
  'LBL_BACK' => 'Vissza',
  'LBL_IMPORT' => 'Import',
  'LBL_EXPORT' => 'Export',
  'LBL_EXPORT_ALL' => 'Export mindenre',
  'LBL_SAVE_NEW_BUTTON_TITLE' => 'Ment�s & �j [Alt+V]',
  'LBL_SAVE_NEW_BUTTON_KEY' => 'V',
  'LBL_SAVE_NEW_BUTTON_LABEL' => 'Ment�s & �j',
  'LBL_NAME' => 'N�v',





  'LBL_SUBJECT' => 'T�rgy',
);


?>
