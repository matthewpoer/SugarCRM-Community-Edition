<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * 
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and 
 * (ii) the SugarCRM copyright notice 
 * in the same form as they appear in the distribution.  See full license for requirements.
 * 
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 *
 * Description:  Defines the Hungarian (Magyar) language pack for the base application.
 * Portions created by Pict&Show are Copyright (C) Pict&Show Kft.
 * All Rights Reserved. Version 0.1.0.
 * Contributor(s): Csaba Szigetv�ri (Pict&Show Kft., Hungary). 2004-11-29
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Jegyzetek',
  'LBL_MODULE_TITLE' => 'Jegyzetek: Nyilv�ntart�s',
  'LBL_SEARCH_FORM_TITLE' => 'Jegyzetek keres�s',
  'LBL_LIST_FORM_TITLE' => 'Jegyzetek lista',
  'LBL_NEW_FORM_TITLE' => '�j jegyzet',
  'LBL_LIST_SUBJECT' => 'T�rgy',
  'LBL_LIST_CONTACT_NAME' => 'Kapcsolat neve',
  'LBL_LIST_RELATED_TO' => 'Kapcsol�dik ehhez',
  'LBL_LIST_DATE_MODIFIED' => 'Utols� m�dos�t�s',
  'LBL_LIST_FILENAME' => 'Csatol�s',
  'LBL_NOTE' => 'Jegyzet:',
  'LBL_NOTE_SUBJECT' => 'Jegyzet t�rgya:',
  'LBL_CONTACT_NAME' => 'Kapcsolat neve:',
  'LBL_PHONE' => 'Telefon:',
  'LBL_SUBJECT' => 'T�rgy:',
  'LBL_FILENAME' => 'Csatol�s:',
  'LBL_CLOSE' => 'Z�r�s:',
  'LBL_RELATED_TO' => 'Kapcsol�dik ehhez:',
  'LBL_EMAIL_ADDRESS' => 'Email c�m:',
  'LBL_COLON' => ':',
  'LNK_NEW_NOTE' => '�j jegyzet',
  'LNK_NOTE_LIST' => 'Jegyzetek',
  'ERR_DELETE_RECORD' => 'Az azonos�t�sz�m meghat�roz�sa sz�ks�ges az adategys�g t�rl�s�hez',

'LNK_NEW_CALL'=>'�j h�v�s',
'LNK_NEW_MEETING'=>'�j t�rgyal�s',
'LNK_NEW_TASK'=>'�j feladat',
'LNK_NEW_NOTE'=>'�j jegyzet',
'LNK_NEW_EMAIL'=>'�j Email',
'LNK_CALL_LIST'=>'H�v�sok',
'LNK_MEETING_LIST'=>'T�rgyal�sok',
'LNK_TASK_LIST'=>'Feladatok',
'LNK_NOTE_LIST'=>'Jegyzetek',
'LNK_EMAIL_LIST'=>'Emailek',

);


?>
