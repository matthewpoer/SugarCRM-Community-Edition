<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * 
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and 
 * (ii) the SugarCRM copyright notice 
 * in the same form as they appear in the distribution.  See full license for requirements.
 * 
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 *
 * Description:  Defines the Hungarian (Magyar) language pack for the base application.
 * Portions created by Pict&Show are Copyright (C) Pict&Show Kft.
 * All Rights Reserved. Version 0.1.0.
 * Contributor(s): Csaba Szigetv�ri (Pict&Show Kft., Hungary). 2004-11-29
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => '�rdekl�d�k',
  'LBL_INVITEE' => 'Direct Reports',
  'LBL_MODULE_TITLE' => '�rdekl�d�k: Nyilv�ntart�s',
  'LBL_SEARCH_FORM_TITLE' => '�rdekl�d�k keres�s',
  'LBL_LIST_FORM_TITLE' => '�rdekl�d�k lista',
  'LBL_NEW_FORM_TITLE' => '�j �rdekl�d�',
  'LBL_CONTACT_OPP_FORM_TITLE' => '�rdekl�d�-�zlet:',
  'LBL_CONTACT' => '�rdekl�d�:',
  'LBL_BUSINESSCARD' => '�rdekl�d� konvert�l�s',
  'LBL_LIST_NAME' => 'N�v',
  'LBL_LIST_LAST_NAME' => 'Vezet�kn�v',
  'LBL_LIST_CONTACT_NAME' => '�rdekl�d� neve',
  'LBL_LIST_TITLE' => 'Beoszt�s',
  'LBL_LIST_ACCOUNT_NAME' => '�gyf�l n�v',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email',
  'LBL_LIST_PHONE' => 'Telefon',
  'LBL_LIST_CONTACT_ROLE' => 'Szerep',
  'LBL_LIST_FIRST_NAME' => 'Keresztn�v',
  'LBL_LIST_REFERED_BY' => 'Aj�nlotta: ',
  'LBL_LIST_LEAD_SOURCE' => '�rdekl�d�s forr�sa',
  'LBL_LIST_STATUS' => 'St�tusz',
  'LBL_LIST_DATE_ENTERED' => 'Keltez�s',
  'LBL_LIST_LEAD_SOURCE_DESCRIPTION' => '�rdekl�d�s forr�s�nak le�r�sa',
  'LBL_LIST_MY_LEADS' => '�ltalam kezelt �rdekl�d�k',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_account_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_email2' => 'LBL_LIST_EMAIL_ADDRESS',
//END DON'T CONVERT
  'LBL_EXISTING_CONTACT' => 'Megl�v� kapcsolat ig�nybev�tele',
  'LBL_CREATED_CONTACT' => '�j kapcsolat l�trehozva',
  'LBL_EXISTING_OPPORTUNITY' => 'Megl�v� �zlet ig�nybev�tele',
  'LBL_CREATED_OPPORTUNITY' => '�j �zlet l�trehozva',
  'LBL_EXISTING_ACCOUNT' => 'Megl�v� �gyf�l ig�nybev�tele',
  'LBL_CREATED_ACCOUNT' => '�j �gyf�l l�trehozva',
  'LBL_CREATED_CALL' => '�j h�v�s l�trehozva',
  'LBL_CREATED_MEETING' => '�j t�rgyal�s l�trehozva',
  'LBL_BACKTOLEADS' => 'Vissza az �rdekl�d�khez',
  'LBL_CONVERTLEAD' => '�rdekl�d� konvert�l�sa',
  'LBL_NAME' => 'N�v:',
  'LBL_CONTACT_NAME' => '�rdekl�d� neve:',
  'LBL_CONTACT_INFORMATION' => '�rdekl�d�r�l inform�ci�',
  'LBL_FIRST_NAME' => 'Keresztn�v:',
  'LBL_OFFICE_PHONE' => 'Munkahelyi telefon:',
  'LBL_ACCOUNT_NAME' => '�gyf�l neve:',
  'LBL_OPPORTUNITY_NAME' => '�zlet megnevez�se:',
  'LBL_OPPORTUNITY_AMOUNT' => '�zlet hozama:',
  'LBL_ANY_PHONE' => 'B�rmely telefon:',
  'LBL_PHONE' => 'Telefon:',
  'LBL_LAST_NAME' => 'Vezet�kn�v:',
  'LBL_MOBILE_PHONE' => 'Mobil:',
  'LBL_HOME_PHONE' => 'Honlap:',
  'LBL_LEAD_SOURCE' => '�rdekl�d�s forr�sa:',
  'LBL_STATUS' => 'St�tusz:',
  'LBL_LEAD_SOURCE_DESCRIPTION' => '�rdekl�d�si forr�s le�r�sa:',
  'LBL_STATUS_DESCRIPTION' => 'St�tusz le�r�sa:',
  'LBL_OTHER_PHONE' => 'M�s telefon:',
  'LBL_FAX_PHONE' => 'Fax:',
  'LBL_TITLE' => 'Beoszt�s:',
  'LBL_DEPARTMENT' => 'Oszt�ly:',
  'LBL_EMAIL_ADDRESS' => 'Email:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'M�s Email:',
  'LBL_ANY_EMAIL' => 'B�rmely Email:',
  'LBL_REPORTS_TO' => 'Felettes:',
  'LBL_DO_NOT_CALL' => 'Ne h�vja:',
  'LBL_EMAIL_OPT_OUT' => 'Opc. kimen� Email:',
  'LBL_PRIMARY_ADDRESS' => 'Els�dleges c�m:',
  'LBL_ALTERNATE_ADDRESS' => 'M�s c�m:',
  'LBL_ANY_ADDRESS' => 'B�rmely c�m:',
  'LBL_REFERED_BY' => 'Aj�nlotta:',
  'LBL_CITY' => 'V�ros:',
  'LBL_STATE' => '�llam:',
  'LBL_POSTAL_CODE' => 'Ir�ny�t�sz�m:',
  'LBL_COUNTRY' => 'Orsz�g:',
  'LBL_DESCRIPTION_INFORMATION' => 'Le�r�si inform�ci�',
  'LBL_ADDRESS_INFORMATION' => 'C�m inform�ci�',
  'LBL_DESCRIPTION' => 'Le�r�s:',
  'LBL_CONTACT_ROLE' => 'Szerep:',
  'LBL_OPP_NAME' => '�zlet megnevez�se:',
  'LBL_IMPORT_VCARD' => 'Import vCard',
  'LNK_IMPORT_VCARD' => 'L�trehozni vCardb�l',
  'LBL_IMPORT_VCARDTEXT' => '�rdekl�d� automatikus l�trehozatala vCard import�l�ssal a f�jlrendszerb�l.',
  'LBL_DUPLICATE' => 'Hasonl� �rdekl�d�k',
  'MSG_DUPLICATE' => 'Hasonl� �rdekl�d�k megtal�lva. K�rem jel�lje meg azokat az �rdekl�d�ket, akiket szeretne t�rs�tani a konvert�l�s sor�n keletkez� adategys�ggel. Ha elk�sz�lt, k�rem nyomja meg a "K�vetkez�" nyom�gombot.',
  'LBL_ADD_BUSINESSCARD' => 'C�gk�rtya h�zz�f�z�se',
  'LNK_NEW_APPOINTMENT' => '�j t�rgyal�s',
  'LNK_NEW_LEAD' => '�j �rdekl�d�',
  'LNK_LEAD_LIST' => '�rdekl�d�k',
  'NTC_DELETE_CONFIRMATION' => 'Biztosan t�r�lni k�v�nja az adategys�get?',
  'NTC_REMOVE_CONFIRMATION' => 'Biztosan t�r�lni szeretn� a kijel�lt �rdekl�d�t ebb�l az �gyb�l?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Biztosan t�r�lni szeretn� az adategys�get a k�zvetlen jelent�sb�l?',
  'ERR_DELETE_RECORD' => 'Az adategys�g azonos�t�sz�m�t meg kell hat�rozni az �rdekl�d� t�rl�s�hez.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Az els�dleges c�m m�sol�sa a alternat�v c�mhez',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Az alternat�v c�m m�sol�sa az els�dleges c�mhez',
  'LNK_NEW_CONTACT' => '�j kapcsolat',
  'LNK_NEW_NOTE' => '�j jegyzet',
  'LNK_NEW_ACCOUNT' => '�j �gyf�l',
  'LNK_NEW_OPPORTUNITY' => '�j �gyf�l',
  'LNK_SELECT_ACCOUNT' => '�gyf�l kijel�l�se',
  'LBL_SALUTATION' => 'Megsz�l�t�s',
);


?>
