<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * 
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and 
 * (ii) the SugarCRM copyright notice 
 * in the same form as they appear in the distribution.  See full license for requirements.
 * 
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 *
 * Description:  Defines the Hungarian (Magyar) language pack for the base application.
 * Portions created by Pict&Show are Copyright (C) Pict&Show Kft.
 * All Rights Reserved. Version 0.1.0.
 * Contributor(s): Csaba Szigetv�ri (Pict&Show Kft., Hungary). 2004-11-29
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Felhaszn�l�k',
  'LBL_MODULE_TITLE' => 'Felhaszn�l�k: Nyilv�ntart�s',
  'LBL_SEARCH_FORM_TITLE' => 'Felhaszn�l� keres�s',
  'LBL_LIST_FORM_TITLE' => 'Felhaszn�l�k',
  'LBL_NEW_FORM_TITLE' => '�j felhaszn�l�',
  'LBL_USER' => 'Felhaszn�l�k:',
  'LBL_LOGIN' => 'Bejelentkez�s',
  'LBL_RESET_PREFERENCES' => 'Alep�rtelmezett be�ll�t�sok vissza�ll�t�sa',
  'LBL_TIME_FORMAT' => 'Id� form�tum:',
  'LBL_CURRENCY' => 'P�nznem:',
  'LBL_LIST_NAME' => 'N�v',
  'LBL_LIST_LAST_NAME' => 'Vezet�kn�v',
  'LBL_LIST_USER_NAME' => 'Keresztn�v',
  'LBL_LIST_DEPARTMENT' => 'Oszt�ly',
  'LBL_LIST_EMAIL' => 'Email',
  'LBL_LIST_PRIMARY_PHONE' => 'F� telefon',
  'LBL_LIST_ADMIN' => 'Admin',
  'LBL_NEW_USER_BUTTON_TITLE' => '�j felhaszn�l� [Alt+N]',
  'LBL_NEW_USER_BUTTON_LABEL' => '�j felhaszn�l�',
  'LBL_NEW_USER_BUTTON_KEY' => 'N',
  'LBL_ERROR' => 'Hiba:',
  'LBL_PASSWORD' => 'Jelsz�:',
  'LBL_USER_NAME' => 'Felhaszn�l�n�v:',
  'LBL_FIRST_NAME' => 'Keresztn�v:',
  'LBL_LAST_NAME' => 'Vezet�kn�v:',
  'LBL_USER_SETTINGS' => 'Felhaszn�l� be�ll�t�sok',
  'LBL_THEME' => 'T�ma:',
  'LBL_LANGUAGE' => 'Nyelv:',
  'LBL_ADMIN' => 'Adminisztr�tor:',
  'LBL_USER_INFORMATION' => 'Felhaszn�l�i inform�ci�',
  'LBL_OFFICE_PHONE' => 'Hivatalos telefon:',
  'LBL_REPORTS_TO' => 'Felettes:',
  'LBL_OTHER_PHONE' => 'M�s:',
  'LBL_OTHER_EMAIL' => 'M�s Email:',
  'LBL_NOTES' => 'Jegyzetek:',
  'LBL_DEPARTMENT' => 'Oszt�ly:',
  'LBL_STATUS' => 'St�tusz:',
  'LBL_TITLE' => 'Beoszt�s:',
  'LBL_ANY_PHONE' => 'B�rmely telefon:',
  'LBL_ANY_EMAIL' => 'B�rmely Email:',
  'LBL_ADDRESS' => 'C�m:',
  'LBL_CITY' => 'V�ros:',
  'LBL_STATE' => '�llam:',
  'LBL_POSTAL_CODE' => 'Ir�ny�t�sz�m:',
  'LBL_COUNTRY' => 'Orsz�g:',
  'LBL_NAME' => 'N�v:',
  'LBL_MOBILE_PHONE' => 'Mobil:',
  'LBL_OTHER' => 'M�s:',
  'LBL_FAX' => 'Fax:',
  'LBL_EMAIL' => 'Email:',
  'LBL_HOME_PHONE' => 'Otthoni telefon:',
  'LBL_ADDRESS_INFORMATION' => 'C�m inform�ci�',
  'LBL_PRIMARY_ADDRESS' => 'Els�dleges c�m:',
  'LBL_CHANGE_PASSWORD_BUTTON_TITLE' => 'Jelsz�v�lt�s [Alt+P]',
  'LBL_CHANGE_PASSWORD_BUTTON_KEY' => 'P',
  'LBL_CHANGE_PASSWORD_BUTTON_LABEL' => 'Jelsz�v�lt�s',
  'LBL_LOGIN_BUTTON_TITLE' => 'Bejelentkez�s [Alt+L]',
  'LBL_LOGIN_BUTTON_KEY' => 'L',
  'LBL_LOGIN_BUTTON_LABEL' => 'Bejelentkez�s',
  'LBL_CHANGE_PASSWORD' => 'Jelsz�v�lt�s',
  'LBL_OLD_PASSWORD' => 'R�gi jelsz�:',
  'LBL_NEW_PASSWORD' => '�j jelsz�:',
  'LBL_CONFIRM_PASSWORD' => 'Jelsz� meger�s�t�se:',
  'ERR_ENTER_OLD_PASSWORD' => '�rja be a r�gi jelszav�t.',
  'ERR_ENTER_NEW_PASSWORD' => '�rja be az �j jelszav�t.',
  'ERR_ENTER_CONFIRMATION_PASSWORD' => 'Er�s�tse meg a jelszav�t.',
  'ERR_REENTER_PASSWORDS' => '�rja be �jra a jelszavakat.  Az \\"�j jelsz�\\" �s \\"jelsz� meger�s�t�s\\" adatai nem egyeznek.',
  'ERR_INVALID_PASSWORD' => '�rv�nyes felhaszn�l�i nevet �s jelsz�t kell be�rni.',
  'ERR_PASSWORD_CHANGE_FAILED_1' => 'Felhaszn�l�i jelsz� m�dos�t�sa sor�n hiba l�pett fel, ez�rt ',
  'ERR_PASSWORD_CHANGE_FAILED_2' => ' sikertelen.  �j jelsz�t kell megadni.',
  'ERR_PASSWORD_INCORRECT_OLD' => 'Helytelen r�gi jelsz� a $this->user_name felhaszn�l�hoz. �jra adjon meg egy jelsz�t.',
  'ERR_USER_NAME_EXISTS_1' => 'A felhaszn�l� neve ',
  'ERR_USER_NAME_EXISTS_2' => ' m�r l�tezik.  K�t azonos felhaszn�l�n�v nem szerepelhet.<br>V�lasszon egyedi felhaszn�l�nevet.',
  'ERR_LAST_ADMIN_1' => 'A megadott felhaszn�l�n�v ',
  'ERR_LAST_ADMIN_2' => ' az utols� Admin felhaszn�l�.  Legal�bb az egyik felhaszn�l�nak Admin jogokkal kell rendelkeznie.<br>Ellen�rizze az Admin felhaszn�l� be�ll�t�sait.',
  'LNK_NEW_USER' => '�j felhaszn�l�',
  'LNK_USER_LIST' => 'Felhaszn�l�k',
  'ERR_DELETE_RECORD' => 'Az azonos�t�sz�m meghat�roz�sa sz�ks�ges az adategys�g t�rl�s�hez.',
  'LBL_RECEIVE_NOTIFICATIONS' => 'Illet�kess�gi �rtes�t�s:',
  'LBL_RECEIVE_NOTIFICATIONS_TEXT' => '�rkezzen Email, ha valamely adategys�g illet�kes�nek jel�ltek ki.',
  'LBL_ADMIN_TEXT' => 'Adminisztr�tor-jogokat ad a felhaszn�l�nak',
  'LBL_TIME_FORMAT_TEXT' => 'A ki�r�si form�tum megad�sa az id�pecs�thez',
  'LBL_GRIDLINE' => 'Mutasd a seg�dvonalakat:',
  'LBL_GRIDLINE_TEXT' => 'Seg�dvonalak vez�rl�se a r�szletes n�zetben',
  'LBL_CURRENCY_TEXT' => 'Az alap�rtelmezett p�nznem kiv�laszt�sa',







);


?>
