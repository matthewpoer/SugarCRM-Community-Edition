<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * 
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and 
 * (ii) the SugarCRM copyright notice 
 * in the same form as they appear in the distribution.  See full license for requirements.
 * 
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 *
 * Description:  Defines the Hungarian (Magyar) language pack for the base application.
 * Portions created by Pict&Show are Copyright (C) Pict&Show Kft.
 * All Rights Reserved. Version 0.1.0.
 * Contributor(s): Csaba Szigetv�ri (Pict&Show Kft., Hungary). 2004-11-29
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Feladatok',
  'LBL_TASK' => 'Feladatok: ',
  'LBL_MODULE_TITLE' => ' Feladatok: Nyilv�ntart�s',
  'LBL_SEARCH_FORM_TITLE' => ' Feladatok keres�s',
  'LBL_LIST_FORM_TITLE' => ' Feladat lista',
  'LBL_NEW_FORM_TITLE' => ' �j feladat',
  'LBL_NEW_FORM_SUBJECT' => 'T�rgy:',
  'LBL_NEW_FORM_DUE_DATE' => 'Esed�kess�g d�tuma:',
  'LBL_NEW_FORM_DUE_TIME' => 'Esed�kess�g id�pontja:',
  'LBL_NEW_TIME_FORMAT' => '(24:00)',
  'LBL_LIST_CLOSE' => 'Z�r�s',
  'LBL_LIST_SUBJECT' => 'T�rgy',
  'LBL_LIST_CONTACT' => 'Kapcsolat',
  'LBL_LIST_RELATED_TO' => 'Kapcsol�dik ehhez',
  'LBL_LIST_DUE_DATE' => 'Esed�kess�g d�tuma',
  'LBL_LIST_DUE_TIME' => 'Esed�kess�g id�pontja',
  'LBL_SUBJECT' => 'T�rgy:',
  'LBL_STATUS' => 'St�tusz:',
  'LBL_DUE_DATE' => 'Esed�kess�g d�tuma:',
  'LBL_PRIORITY' => 'Priorit�s:',
  'LBL_COLON' => ':',
  'LBL_DUE_DATE_AND_TIME' => 'Esed�kess�g d�tuma & id�pontja:',
  'DATE_FORMAT' => '(yyyy-mm-dd)',
  'LBL_NONE' => 'nincs',
  'LBL_CONTACT' => 'Kapcsolat:',
  'LBL_PHONE' => 'Telefon:',
  'LBL_EMAIL' => 'Email:',
  'LBL_DESCRIPTION_INFORMATION' => 'Le�r�si inform�ci�',
  'LBL_DESCRIPTION' => 'Le�r�s:',
  'LBL_NAME' => 'N�v:',
  'LBL_CONTACT_NAME' => 'Kapcsolat n�v: ',
  'LBL_LIST_COMPLETE' => 'Lez�rva:',
  'LBL_LIST_STATUS' => 'St�tusz:',
  'ERR_DELETE_RECORD' => 'Az azonos�t�sz�m meghat�roz�sa sz�ks�ges a kapcsolat t�rl�s�hez.',
  'ERR_INVALID_HOUR' => 'Adjon meg egy �ra�rt�ket 0 �s 24 k�z�tt',
  'LBL_DEFAULT_STATUS' => 'Indul�s el�tt',
  'LBL_DEFAULT_PRIORITY' => 'K�zepes',
  'LNK_NEW_CALL' => '�j h�v�s',
  'LNK_NEW_MEETING' => '�j t�rgyal�s',
  'LNK_NEW_TASK' => '�j feladat',
  'LNK_NEW_NOTE' => '�j jegyzet',
  'LNK_NEW_EMAIL' => '�j Email',
  'LNK_CALL_LIST' => 'H�v�sok',
  'LNK_MEETING_LIST' => 'T�rgyal�sok',
  'LNK_TASK_LIST' => 'Feladatok',
  'LNK_NOTE_LIST' => 'Jegyzetek',
  'LNK_EMAIL_LIST' => 'Emailek',
  'LNK_VIEW_CALENDAR' => 'Ma',
);


?>
