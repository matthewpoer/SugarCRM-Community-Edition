<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * 
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and 
 * (ii) the SugarCRM copyright notice 
 * in the same form as they appear in the distribution.  See full license for requirements.
 * 
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 *
 * Description:  Defines the Hungarian (Magyar) language pack for the base application.
 * Portions created by Pict&Show are Copyright (C) Pict&Show Kft.
 * All Rights Reserved. Version 0.1.0.
 * Contributor(s): Csaba Szigetv�ri (Pict&Show Kft., Hungary). 2004-11-25
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Adminisztr�ci�',
  'LBL_MODULE_TITLE' => 'Adminisztr�ci�: Nyilv�ntart�s',
  'LBL_NEW_FORM_TITLE' => '�j �gyf�l',
  'LNK_NEW_USER' => '�j felhaszn�l�',
  'ERR_DELETE_RECORD' => 'Az azonos�t�sz�m meghat�roz�sa sz�ks�ges az adategys�g t�rl�s�hez.',
  'LBL_CONFIGURE_SETTINGS_TITLE' => 'Be�ll�t�sok konfigur�l�sa',
  'LBL_CONFIGURE_SETTINGS' => 'Be�ll�t�sok rendszer-szint� konfigur�l�sa',
  'LBL_UPGRADE_TITLE' => 'Friss�t�s',
  'LBL_UPGRADE' => 'Sugar Sales friss�t�s',
  'LBL_MANAGE_USERS_TITLE' => 'Felhaszn�l�k kezel�se',
  'LBL_MANAGE_USERS' => 'Felhaszn�l�i fi�kok �s jelszavak kezel�se',
  'LBL_ADMINISTRATION_HOME_TITLE' => 'Rendszer adminisztr�ci�',
  'LBL_NOTIFY_TITLE' => 'E-mail �rtes�t�si opci�k',
  'LBL_NOTIFY_FROMADDRESS' => '"K�ld�" c�m:',
  'LBL_MAIL_SMTPSERVER' => 'SMTP szerver:',
  'LBL_MAIL_SMTPPORT' => 'SMTP port:',
  'LBL_MAIL_SENDTYPE' => 'Mail Transfer Agent:',
  'LBL_MAIL_SMTPUSER' => 'SMTP felhaszn�l�n�v:',
  'LBL_MAIL_SMTPPASS' => 'SMTP jelsz�:',
  'LBL_MAIL_SMTPAUTH_REQ' => 'SMTP azonos�t�s alkalmaz�sa?',
  'LBL_NOTIFY_SEND_BY_DEFAULT' => '�rtes�t�sek alap�rtelmezett k�ld�se?',
  'LBL_NOTIFY_SUBJECT' => 'E-mail t�rgy:',
  'LBL_NOTIFY_ON' => '�rtes�t�si id�pont?',
  'LBL_NOTIFY_FROMNAME' => '"K�ld�" n�v:',
  'LBL_CURRENCY' => 'P�nznem �s �rfolyamok be�ll�t�sa',
  'LBL_MANAGE_CURRENCIES' => 'P�nznemek',
  'LBL_MANAGE_OPPORTUNITIES' => 'Lehet�s�gek',
  'LBL_UPGRADE_CURRENCY' => 'P�nznem friss�t�s�nek eredm�nye ',

























);


?>
