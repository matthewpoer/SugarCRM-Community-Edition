<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * 
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and 
 * (ii) the SugarCRM copyright notice 
 * in the same form as they appear in the distribution.  See full license for requirements.
 * 
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 *
 * Description:  Defines the Hungarian (Magyar) language pack for the base application.
 * Portions created by Pict&Show are Copyright (C) Pict&Show Kft.
 * All Rights Reserved. Version 0.1.0.
 * Contributor(s): Csaba Szigetv�ri (Pict&Show Kft., Hungary). 2004-11-25
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Emailek',
  'LBL_MODULE_TITLE' => 'Emailek: Nyilv�ntart�s',
  'LBL_SEARCH_FORM_TITLE' => 'Email keres�s',
  'LBL_LIST_FORM_TITLE' => 'Email lista',
  'LBL_NEW_FORM_TITLE' => 'Email elt�rol�sa',
  'LBL_LIST_SUBJECT' => 'T�rgy',
  'LBL_LIST_CONTACT' => 'Kapcsolat',
  'LBL_LIST_RELATED_TO' => 'Kapcsol�dik ehhez',
  'LBL_LIST_DATE' => 'K�ld�s d�tuma',
  'LBL_LIST_TIME' => 'K�ld�s id�pontja',
  'ERR_DELETE_RECORD' => 'Az azonos�t�sz�m meghat�roz�sa sz�ks�ges az adategys�g t�rl�s�hez.',
  'LBL_DATE_SENT' => 'K�ld�s d�tuma:',
  'LBL_SUBJECT' => 'T�rgy:',
  'LBL_BODY' => '�zenet:',
  'LBL_DATE_AND_TIME' => 'K�ld�si d�tum �s id�pont:',
  'LBL_DATE' => 'K�ld�s d�tuma:',
  'LBL_TIME' => 'K�ld�s id�pontja:',
  'LBL_CONTACT_NAME' => ' Kapcsolat neve: ',
  'LBL_EMAIL' => 'Email:',
  'LBL_COLON' => ':',
  'LNK_NEW_EMAIL' => '�j Email',
  'LNK_EMAIL_LIST' => 'Emailek',
  'NTC_REMOVE_INVITEE' => 'Biztosan t�r�lni k�v�nja a megh�vottat err�l az Emailr�l?',
  'LBL_INVITEE' => 'Megh�vottak',
'LNK_NEW_CALL'=>'�j h�v�s',
'LNK_NEW_MEETING'=>'�j t�rgyal�s',
'LNK_NEW_TASK'=>'�j feladat',
'LNK_NEW_NOTE'=>'�j jegyzet',
'LNK_NEW_EMAIL'=>'�j Email',
'LNK_CALL_LIST'=>'H�v�sok',
'LNK_MEETING_LIST'=>'T�rgyal�sok',
'LNK_TASK_LIST'=>'Feladatok',
'LNK_NOTE_LIST'=>'Jegyzetek',
'LNK_EMAIL_LIST'=>'Emailek',

);


?>
