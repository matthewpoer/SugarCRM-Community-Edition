<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/modules/Accounts/Account.php,v 1.92 2004/11/10 22:27:36 clint Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Sager',
  'LBL_MODULE_TITLE' => 'Sag : Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'S�g Sager',
  'LBL_LIST_FORM_TITLE' => 'Sagsliste',
  'LBL_NEW_FORM_TITLE' => 'Ny Sag',
  'LBL_CONTACT_CASE_TITLE' => 'Kontakt-Sag:',
  'LBL_SUBJECT' => 'Sag:',
  'LBL_CASE' => 'Sag:',
  'LBL_CASE_NUMBER' => 'Sagsenummer:',
  'LBL_NUMBER' => 'Nummer:',
  'LBL_STATUS' => 'Status:',
  'LBL_PRIORITY' => 'Priority:',
  'LBL_ACCOUNT_NAME' => 'Firmanavn:',
  'LBL_DESCRIPTION' => 'Beskrivelse:',
  'LBL_CONTACT_NAME' => 'Kontakt Navn:',
  'LBL_CASE_SUBJECT' => 'Sag overskrift:',
  'LBL_CONTACT_ROLE' => 'Rolle:',
  'LBL_LIST_NUMBER' => 'Num.',
  'LBL_LIST_SUBJECT' => 'Rubrik',
  'LBL_LIST_ACCOUNT_NAME' => 'Firmanavn',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_LIST_PRIORITY' => 'Priority',
  'LBL_LIST_LAST_MODIFIED' => 'Sidst opdateret',
  'LBL_INVITEE' => 'Kontaker',
  'LNK_NEW_CASE' => 'Ny Sag',
  'LNK_CASE_LIST' => 'Cases',
  'NTC_REMOVE_INVITEE' => 'Er du sikker p� at du vil fjerne denne kontakt fra sagen?',
  'ERR_DELETE_RECORD' => 'Et Postnummer skal angives for at slette Firmaet.',
  'LNK_NEW_CONTACT' => 'Ny Kontakt',
  'LNK_NEW_ACCOUNT' => 'Nyt Firma',
  'LNK_NEW_OPPORTUNITY' => 'Ny Mulig Forretning',
  'LNK_NEW_NOTE' => 'Ny Bem�rkning',
  'LNK_NEW_CALL' => 'Ny Samtale',
  'LNK_NEW_EMAIL' => 'Ny Email',
  'LNK_NEW_MEETING' => 'Nyt M�de',
  'LNK_NEW_TASK' => 'Ny Opgave',
);


?>