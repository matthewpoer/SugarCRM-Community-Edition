<?php
/*********************************************************************************
 *The contents of this file are subject to the SugarCRM User License Agreement 
 *("License") which can be viewed at http://www.sugarcrm.com/EULA.  
 *By installing or using this file, You have unconditionally agreed to the terms and conditions of the License, and You may 
 *not use this file except in compliance with the License. Under the terms of the license, You 
 *shall not, among other things: 1) sublicense, resell, rent, lease, redistribute, assign or 
 *otherwise transfer Your rights to the Software, and 2) use the Software for timesharing or 
 *service bureau purposes such as hosting the Software for commercial gain and/or for the benefit 
 *of a third party.  Use of the Software may be subject to applicable fees and any use of the 
 *Software without first paying applicable fees is strictly prohibited.  You do not have the 
 *right to remove SugarCRM copyrights from the source code or user interface. 
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and 
 * (ii) the SugarCRM copyright notice 
 * in the same form as they appear in the distribution.  See full license for requirements.
 *Your Warranty, Limitations of liability and Indemnity are expressly stated in the License.  Please refer 
 *to the License for the specific language governing these rights and limitations under the License.
 *Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.; All Rights Reserved.  
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/modules/Calendar/language/en_us.lang.php,v 1.14 2004/11/10 16:56:38 robert Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LNK_NEW_CALL' => 'Lave opringning',
  'LNK_NEW_MEETING' => 'Lave M�de',
  'LNK_NEW_APPOINTMENT' => 'Aftale',
  'LNK_NEW_TASK' => 'Lave opgave',
  'LNK_CALL_LIST' => 'Opringninger',
  'LNK_MEETING_LIST' => 'M�der',
  'LNK_TASK_LIST' => 'Opgaver',
  'LNK_VIEW_CALENDAR' => 'I dag',
  'LBL_MONTH' => 'M�ned',
  'LBL_DAY' => 'Dag',
  'LBL_YEAR' => '�r',
  'LBL_WEEK' => 'Uge',
  'LBL_PREVIOUS_MONTH' => 'Sidste M�ned',
  'LBL_PREVIOUS_DAY' => 'Foreg�ende dag',
  'LBL_PREVIOUS_YEAR' => 'Foreg�ende �r',
  'LBL_PREVIOUS_WEEK' => 'Foreg�ende uge',
  'LBL_NEXT_MONTH' => 'N�ste m�ned',
  'LBL_NEXT_DAY' => 'N�ste dag',
  'LBL_NEXT_YEAR' => 'N�ste �r',
  'LBL_NEXT_WEEK' => 'N�ste uge',
  'LBL_AM' => 'AM',
  'LBL_PM' => 'PM',
  'LBL_SCHEDULED' => 'Planlagt',
  'LBL_BUSY' => 'Optaget',
  'LBL_CONFLICT' => 'Konflikt',
  'LBL_USER_CALENDARS' => 'Brugeres Kalender',
);

$mod_list_strings = array(
'dom_cal_weekdays'=>array(
"S�n",
"Man",
"Tir",
"Ons",
"Tor",
"Fre",
"L�r",
),
'dom_cal_weekdays_long'=>array(
"S�ndag",
"Mandag",
"Tirsdag",
"Onsdag",
"Torsdag",
"Fredag",
"L�rdag",
),
'dom_cal_month'=>array(
"",
"Jan",
"Feb",
"Mar",
"Apr",
"Maj",
"Jun",
"Jul",
"Aug",
"Sep",
"Okt",
"Nov",
"Dec",
),
'dom_cal_month_long'=>array(
"",
"Januar",
"Februar",
"Marts",
"April",
"Maj",
"Juni",
"Juli",
"August",
"September",
"Oktober",
"November",
"December",
)
);
?>
