/* Copyright (c) 2006 Yahoo! Inc. All rights reserved. */
YAHOO.widget.RootNode=function(oTree){this.init(null,null,true);this.tree=oTree;};YAHOO.widget.RootNode.prototype=new YAHOO.widget.Node();YAHOO.widget.RootNode.prototype.getNodeHtml=function(){return"";};
