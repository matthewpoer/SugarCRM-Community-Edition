<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Contacts/language/dk.lang.php,v 1.0 2004/09/17 HHN Exp $
 * Description:  Defines the Danish language pack for the Contacts module
 ********************************************************************************/

$mod_strings = Array(
'LBL_MODULE_NAME'=>'Kontakter',
'LBL_MODULE_TITLE'=>'Kontakter : Hjem',
'LBL_SEARCH_FORM_TITLE'=>'S�g Kontakt',
'LBL_LIST_FORM_TITLE'=>'Kontaktliste',
'LBL_NEW_FORM_TITLE'=>'Ny Kontakt',
'LBL_CONTACT_OPP_FORM_TITLE'=>'Kontakt - Firma:',
'LBL_CONTACT'=>'Kontakt:',

'LBL_LIST_NAME'=>'Navn',
'LBL_LIST_LAST_NAME'=>'Efternavn',
'LBL_LIST_CONTACT_NAME'=>'Kontaktnavn',
'LBL_LIST_TITLE'=>'Titel',
'LBL_LIST_ACCOUNT_NAME'=>'Firmanavn',
'LBL_LIST_EMAIL_ADDRESS'=>'Email',
'LBL_LIST_PHONE'=>'Telefon',
'LBL_LIST_CONTACT_ROLE'=>'Rolle',

'LBL_NAME'=>'Navn:',
'LBL_CONTACT_NAME'=>'Kontakt Navn:',
'LBL_CONTACT_INFORMATION'=>'Kontakt Information',
'LBL_FIRST_NAME'=>'Fornavn:',
'LBL_OFFICE_PHONE'=>'Firmatlf:',
'LBL_ACCOUNT_NAME'=>'Firmanavn:',
'LBL_ANY_PHONE'=>'Telefon:',
'LBL_PHONE'=>'Telefon:',
'LBL_LAST_NAME'=>'Efternavn:',
'LBL_MOBILE_PHONE'=>'Mobiltlf:',
'LBL_HOME_PHONE'=>'Hjemmetlf:',
'LBL_LEAD_SOURCE'=>'Kilde:',
'LBL_OTHER_PHONE'=>'Anden Telefon:',
'LBL_FAX_PHONE'=>'Fax:',
'LBL_TITLE'=>'Titel:',
'LBL_DEPARTMENT'=>'Afdeling:',
'LBL_BIRTHDATE'=>'F�dselsdato:',
'LBL_EMAIL_ADDRESS'=>'Email:',
'LBL_OTHER_EMAIL_ADDRESS'=>'Anden Email:',
'LBL_ANY_EMAIL'=>'Email:',
'LBL_REPORTS_TO'=>'Rapporterer Til:',
'LBL_ASSISTANT'=>'Assistent:',
'LBL_YAHOO_ID'=>'Yahoo! ID:',
'LBL_ASSISTANT_PHONE'=>'Assistent Telefon:',
'LBL_DO_NOT_CALL'=>'�nsker ikke opkald:',
'LBL_EMAIL_OPT_OUT'=>'�nsker ikke Emails:',
'LBL_PRIMARY_ADDRESS'=>'Prim�r Adresse:',
'LBL_ALTERNATE_ADDRESS'=>'Anden Adresse:',
'LBL_ANY_ADDRESS'=>'Adresse:',
'LBL_CITY'=>'By:',
'LBL_STATE'=>'Stat:',
'LBL_POSTAL_CODE'=>'Postnummer:',
'LBL_COUNTRY'=>'Land:',
'LBL_DESCRIPTION_INFORMATION'=>'Beskrivelse',
'LBL_DESCRIPTION'=>'Beskrivelse:',
'LBL_CONTACT_ROLE'=>'Rolle:',
'LBL_OPP_NAME'=>'Firma Navn:',

'LNK_NEW_CONTACT'=>'Ny Kontakt',
'LNK_NEW_ACCOUNT'=>'Nyt Firma',
'LNK_NEW_OPPORTUNITY'=>'Ny Mulig Forretning',
'LNK_NEW_CASE'=>'Ny Case',
'LNK_NEW_NOTE'=>'Ny Bem�rkning',
'LNK_NEW_CALL'=>'Ny Samtale',
'LNK_NEW_EMAIL'=>'Ny Email',
'LNK_NEW_MEETING'=>'Nyt M�de',
'LNK_NEW_TASK'=>'Ny Opgave',
'NTC_DELETE_CONFIRMATION'=>'Er du sikker p� at du vil slette denne Record?',
'NTC_REMOVE_CONFIRMATION'=>'Er du sikker p� at du vil slette denne Kontakt fra dette Firma?',
'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION'=>'Er du sikker p� at du vil slette denne record som direkte rapporterende?',
'ERR_DELETE_RECORD'=>"Et Postnummer skal angives for at slette denne Kontakt.",

'NTC_COPY_PRIMARY_ADDRESS'=>'Kopier prim�r adresse til sekund�r adresse',
'NTC_COPY_ALTERNATE_ADDRESS'=>'Kopier sekund�r adresse til prim�r adresse',

'LBL_INVITEE'=>'Direct Reports',

'LBL_ADDRESS_INFORMATION'=>'Addresse Information',
);

?>