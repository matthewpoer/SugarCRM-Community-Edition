<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Activities/language/dk.lang.php,v 1.0 2004/09/17 HHN Exp $
 * Description:  Defines the Danish language pack for the Activity module.
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_OPEN_ACTIVITIES'=>'�bne Aktiviteter',
'LBL_HISTORY'=>'Historie',
'LBL_UPCOMING'=>"Kommende Aktiviteter",
'LBL_TODAY'=>'til ',

'LBL_NEW_TASK_BUTTON_TITLE'=>'Ny opgave [Alt+N]',
'LBL_NEW_TASK_BUTTON_KEY'=>'N',
'LBL_NEW_TASK_BUTTON_LABEL'=>'Ny opgave',
'LBL_SCHEDULE_MEETING_BUTTON_TITLE'=>'Aftal M�de [Alt+M]',
'LBL_SCHEDULE_MEETING_BUTTON_KEY'=>'M',
'LBL_SCHEDULE_MEETING_BUTTON_LABEL'=>'Aftal M�de',
'LBL_SCHEDULE_CALL_BUTTON_TITLE'=>'Aftal Samtale [Alt+C]',
'LBL_SCHEDULE_CALL_BUTTON_KEY'=>'C',
'LBL_SCHEDULE_CALL_BUTTON_LABEL'=>'Aftal Samtale',
'LBL_NEW_NOTE_BUTTON_TITLE'=>'Ny Bem�rkning [Alt+T]',
'LBL_NEW_NOTE_BUTTON_KEY'=>'T',
'LBL_NEW_NOTE_BUTTON_LABEL'=>'Ny bem�rkning',
'LBL_TRACK_EMAIL_BUTTON_TITLE'=>'Opf�lgningsmail [Alt+K]',
'LBL_TRACK_EMAIL_BUTTON_KEY'=>'K',
'LBL_TRACK_EMAIL_BUTTON_LABEL'=>'Opf�lgningsmail',

'LBL_LIST_CLOSE'=>'Afslut',
'LBL_LIST_STATUS'=>'Status',
'LBL_LIST_CONTACT'=>'Kontakt',
'LBL_LIST_RELATED_TO'=>'Relateret til',
'LBL_LIST_DUE_DATE'=>'Afslutningsdato',
'LBL_LIST_DATE'=>'Dato',
'LBL_LIST_SUBJECT'=>'Vedr�rende',
'LBL_LIST_LAST_MODIFIED'=>'Sidst Opdateret',

'LNK_NEW_CONTACT'=>'Ny Kontakt',
'LNK_NEW_ACCOUNT'=>'Nyt Firma',
'LNK_NEW_OPPORTUNITY'=>'Ny Mulig Forretning',
'LNK_NEW_CASE'=>'Ny Case',
'LNK_NEW_NOTE'=>'Ny Bem�rkning',
'LNK_NEW_CALL'=>'Ny Samtale',
'LNK_NEW_EMAIL'=>'Ny Email',
'LNK_NEW_MEETING'=>'Nyt M�de',
'LNK_NEW_TASK'=>'Ny Opgave',
'ERR_DELETE_RECORD'=>"Et Postnummer skal angives for at slette Firmaet.",

//New strings for 1.1c.  These still need to be translated.
'NTC_NONE_SCHEDULED'=>'None scheduled.',
);

?>