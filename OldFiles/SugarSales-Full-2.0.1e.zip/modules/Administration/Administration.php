<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/sugarcrm/modules/Administration/Administration.php,v 1.8 2004/10/24 20:06:42 clint Exp $
 * Description:  TODO: To be written.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/
include_once('config.php');
require_once('include/logging.php');
require_once('include/database/PearDatabase.php');
require_once('data/SugarBean.php');

class Administration extends SugarBean {
	var $log;
	var $db;
	var $table_name = "config";
	var $object_name = "Administration";
	var $new_schema = true;
	var $config_categories = Array("mail", "notify");
	var $checkbox_fields = Array("notify_send_by_default", "mail_smtpauth_req", "notify_on");

	function Administration() {
		$this->log = LoggerManager::getLogger('Administration');
		$this->db = new PearDatabase();



	}

	function create_tables() {
		$query = "CREATE TABLE $this->table_name (";
		$query .='category VARCHAR(32) NOT NULL';
		$query .=', name VARCHAR(32) NOT NULL';
		$query .=', value TEXT NOT NULL)';

		$this->db->query($query,true,"Error creating config table: ");
	}

	function drop_tables() {
		$query = 'DROP TABLE IF EXISTS '.$this->table_name;
		$this->db->query($query);
	}

	function retrieveSettings($category = FALSE) {
		global $db;

		$query = "SELECT category, name, value FROM $this->table_name";
		if ($category) {
			$query .= " WHERE category='$category'";
		}

		$result =& $this->db->query($query, true, "Unable to retrieve system settings");
		if (empty($result)) {
			return NULL;
		}

		while ($row = $this->db->fetchByAssoc($result, -1, true)) {
			$this->settings[$row['category']."_".$row['name']] = $row['value'];
		}

		return $this;
	}

	function get_config_prefix($str) {
		return Array(substr($str, 0, strpos($str, "_")), substr($str, strpos($str, "_")+1));
	}
}
?>
