<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/sugarcrm/modules/Emails/language/en_us.lang.php,v 1.27 2004/10/25 03:01:25 robert Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Emails',
  'LBL_MODULE_TITLE' => 'Emails: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Email Search',
  'LBL_LIST_FORM_TITLE' => 'Email List',
  'LBL_NEW_FORM_TITLE' => 'Archive Email',
  'LBL_LIST_SUBJECT' => 'Subject',
  'LBL_LIST_CONTACT' => 'Contact',
  'LBL_LIST_RELATED_TO' => 'Related to',
  'LBL_LIST_DATE' => 'Date Sent',
  'LBL_LIST_TIME' => 'Time Sent',
  'ERR_DELETE_RECORD' => 'A record number must be specified to delete the account.',
  'LBL_DATE_SENT' => 'Date Sent:',
  'LBL_SUBJECT' => 'Subject:',
  'LBL_BODY' => 'Body:',
  'LBL_DATE_AND_TIME' => 'Date & Time Sent:',
  'LBL_DATE' => 'Date Sent:',
  'LBL_TIME' => 'Time Sent:',
  'LBL_CONTACT_NAME' => ' Contact Name: ',
  'LBL_EMAIL' => 'Email:',
  'LBL_COLON' => ':',
  'LNK_NEW_EMAIL' => 'Create Email',
  'LNK_EMAIL_LIST' => 'Emails',
  'NTC_REMOVE_INVITEE' => 'Are you sure you want to remove this recipient from the email?',
  'LBL_INVITEE' => 'Recipients',
'LNK_NEW_CALL'=>'Create Call',
'LNK_NEW_MEETING'=>'Create Meeting',
'LNK_NEW_TASK'=>'Create Task',
'LNK_NEW_NOTE'=>'Create Note',
'LNK_NEW_EMAIL'=>'Create Email',
'LNK_CALL_LIST'=>'Calls',
'LNK_MEETING_LIST'=>'Meetings',
'LNK_TASK_LIST'=>'Tasks',
'LNK_NOTE_LIST'=>'Notes',
'LNK_EMAIL_LIST'=>'Emails',

);


?>
