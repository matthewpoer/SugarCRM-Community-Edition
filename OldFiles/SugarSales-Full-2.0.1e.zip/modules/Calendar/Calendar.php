<?php 
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/sugarcrm/modules/Calendar/Calendar.php,v 1.29 2004/11/11 02:27:30 clint Exp $
 ********************************************************************************/
require_once('modules/Meetings/Meeting.php');
require_once('modules/Calls/Call.php');
$mod_list_strings = return_mod_list_strings_language($current_language,"Calendar");

function sort_func_by_act_date($act0,$act1)
{
	if ($act0->start_time->ts == $act1->start_time->ts) 
	{
		return 0;
	}

	return ($act0->start_time->ts < $act1->start_time->ts) ? -1 : 1;
}

class DateTime
{
		var $timezone;
		var $sec;
		var $min;
		var $hour;
		var $day;
		var $zday;
		var $day_of_week;
		var $day_of_week_short;
		var $day_of_week_long;
		var $day_of_year;
		var $week;
		var $month;
		var $zmonth;
		var $month_short;
		var $month_long;
		var $year;
		var $am_pm;

		// unix epoch time
		var $ts;
	function get_time_start( $date_start, $time_start)
	{
		//print "TIME: $date_start,$time_start<br>";
		$match=array();
		preg_match("/^(\d\d\d\d)\-(\d\d*)\-(\d\d*)$/",$date_start,$match);
		$time_arr = array();
		$time_arr['year'] = $match[1];
		$time_arr['month'] = $match[2];
		$time_arr['day'] = $match[3];

		if ( empty( $time_start) )
		{
			$time_arr['hour'] = 0;
			$time_arr['min'] = 0;
		}
		else
		{
			preg_match("/^(\d\d*):(\d\d*):(\d\d*)$/",$time_start,$match);
			$time_arr['hour'] = $match[1];
			$time_arr['min'] = $match[2];
		//echo "hour:".$match[1]."<br>";
		//echo "min:".$match[2]."<br>";
		}
		return new DateTime($time_arr,true);

	}
	function get_time_end( $start_time, $duration_hours,$duration_minutes)
	{
		if ( empty($duration_hours))
		{
			$duration_hours = "00";
		}
		if ( empty($duration_minutes))
		{
			$duration_minutes = "00";
		}
		$added_seconds = ($duration_hours * 60 * 60 + $duration_minutes * 60 ) - 1; 
		$time_arr = array();
		$time_arr['year'] = $start_time->year;
		$time_arr['month'] = $start_time->month;
		$time_arr['day'] = $start_time->day;
		//$time_arr['hour'] = $start_time->hour + $duration_hours;
		//$time_arr['min'] = $start_time->min + $duration_minutes;
		$time_arr['hour'] = $start_time->hour;
		$time_arr['min'] = $start_time->min;
		$time_arr['sec'] = $added_seconds;
		//echo "ts:".$start_time->ts."<br>";
		//echo "hours:".$time_arr['hour']."<br>";
		//echo "min:".$time_arr['min']."<br>";
		return new DateTime($time_arr,true);

	}
	function get_date_str()
	{
		
		$arr = array();
		if ( isset( $this->hour))
		{
		 array_push( $arr, "hour=".$this->hour);
		}
		if ( isset( $this->day))
		{
		 array_push( $arr, "day=".$this->day);
		}
		if ( isset( $this->month))
		{
		 array_push( $arr, "month=".$this->month);
		}
		if ( isset( $this->year))
		{
		 array_push( $arr, "year=".$this->year);
		}
		return  ("&".implode('&',$arr));
	}
	function get_today()
	{
			$today = ($this->day).$this->month.($this->year);

		return $today;
	}
	function get_tomorrow()
	{
			$date_arr = array('day'=>($this->day + 1),		
			'month'=>$this->month,
			'year'=>$this->year);

		return new DateTime($date_arr,true);
	}
	function get_yesterday()
	{
			$date_arr = array('day'=>($this->day - 1),		
			'month'=>$this->month,
			'year'=>$this->year);

		return new DateTime($date_arr,true);
	}

	function get_mysql_date()
	{
		return $this->year."-".$this->zmonth."-".$this->zday;
	}
	function get_mysql_time()
	{
		return $this->hour.":".$this->min;
	}

	function get_first_day_of_last_year()
	{
			$date_arr = array('day'=>1,		
			'month'=>1,
			'year'=>($this->year - 1));

		return new DateTime($date_arr,true);

	}
	function get_first_day_of_next_year()
	{
			$date_arr = array('day'=>1,		
			'month'=>1,
			'year'=>($this->year + 1));

		return new DateTime($date_arr,true);

	}

	function get_first_day_of_next_week()
	{
		$first_day = $this->get_day_by_index_this_week(0);
			$date_arr = array('day'=>($first_day->day + 7),		
			'month'=>$first_day->month,
			'year'=>$first_day->year);

		return new DateTime($date_arr,true);

	}
	function get_first_day_of_last_week()
	{
		$first_day = $this->get_day_by_index_this_week(0);
			$date_arr = array('day'=>($first_day->day - 7),		
			'month'=>$first_day->month,
			'year'=>$first_day->year);

		return new DateTime($date_arr,true);
	}
	function get_first_day_of_last_month()
	{
		if ($this->month == 1)
		{
			$month = 12;
			$year = $this->year - 1;
		}
		else
		{
			$month = $this->month - 1;
			$year = $this->year ;
		}
			$date_arr = array('day'=>1,		
			'month'=>$month,
			'year'=>$year);

		return new DateTime($date_arr,true);

	}
	function get_first_day_of_next_month()
	{
		$date_arr = array('day'=>1,		
			'month'=>($this->month + 1),
			'year'=>$this->year);
		return new DateTime($date_arr,true);
	}


	function fill_in_details()
	{
		global $mod_strings;
		$hour = 0;
		$min = 0;
		$sec = 0;
		$day = 1;
		$month = 1;
		$year = 1970;

		if ( isset($this->sec))
		{
			$sec = $this->sec;
		}
		if ( isset($this->min))
		{
			$min = $this->min;
		}
		if ( isset($this->hour))
		{
			$hour = $this->hour;
		}
		if ( isset($this->day))
		{
			$day= $this->day;
		}
		if ( isset($this->month))
		{
			$month = $this->month;
		}
		if ( isset($this->year))
		{
			$year = $this->year;
		}
		else
		{
			sugar_die ("fill_in_details: year was not set");
		}
		$this->ts = mktime($hour,$min,$sec,$month,$day,$year);
		$this->load_ts($this->ts);

	}

	function load_ts($timestamp)
	{
		global $mod_list_strings;
		if ( empty($timestamp))
		{
			$timestamp = time();
		}

		$date_str = date('i:G:j:d:t:w:z:L:W:n:m:Y',$timestamp);

		list(
		$this->min,
		$this->hour,
		$this->day,
		$this->zday,
		$this->days_in_month,
		$this->day_of_week,
		$this->day_of_year,
		$is_leap,
		$this->week,
		$this->month,
		$this->zmonth,
		$this->year)
		 = split(':',$date_str);

		$this->day_of_week_short =$mod_list_strings['dom_cal_weekdays'][$this->day_of_week];
		$this->day_of_week_long=$mod_list_strings['dom_cal_weekdays_long'][$this->day_of_week];
		$this->month_short=$mod_list_strings['dom_cal_month'][$this->month];
		$this->month_long=$mod_list_strings['dom_cal_month_long'][$this->month];

		$this->days_in_year = 365;

		if ($is_leap == 1)
		{
			$this->days_in_year += 1;
		}


	}

	function DateTime(&$time,$fill_in_details)
	{	
		if (! isset( $time) || count($time) == 0 )
		{
			$this->load_ts(null);
		}
		else if ( isset( $time['ts']))
		{
			$this->load_ts($time['ts']);
		}
		else if ( isset( $time['date_str']))
		{
			list($this->year,$this->month,$this->day)= 
				split("-",$time['date_str']);
			if ($fill_in_details == true)
			{
				$this->fill_in_details();
			}
		}
		else
		{
			if ( isset($time['sec']))
			{
        			$this->sec = $time['sec'];
			}
			if ( isset($time['min']))
			{
        			$this->min = $time['min'];
			}
			if ( isset($time['hour']))
			{
        			$this->hour = $time['hour'];
			}
			if ( isset($time['day']))
			{
        			$this->day = $time['day'];
			}
			if ( isset($time['week']))
			{
        			$this->week = $time['week'];
			}
			if ( isset($time['month']))
			{
        			$this->month = $time['month'];
			}
			if ( isset($time['year']) && $time['year'] >= 1970)
			{
        			$this->year = $time['year'];
			}
			else
			{
				return null;
			}

			if ($fill_in_details == true)
			{
				$this->fill_in_details();
			}

		}
	}

	function dump_date_info()
	{
		echo "min:".$this->min."<br>\n";
		echo "hour:".$this->hour."<br>\n";
		echo "day:".$this->day."<br>\n";
		echo "month:".$this->month."<br>\n";
		echo "year:".$this->year."<br>\n";
	}

	function get_hour()
	{
		$hour = $this->hour;
		if ($this->hour > 12)
		{
			$hour -= 12;
		}
		else if ($this->hour == 0)
		{
			$hour = 12;
		}
		return $hour;
	}
	
	function get_24_hour()
	{
		return $this->hour;
	}
	
	function get_am_pm()
	{
		if ($this->hour >=12)
		{
			return "PM";
		}
		return "AM";
	}
	
	function get_day()
	{
		return $this->day;
	}

	function get_month()
	{
		return $this->month;
	}

	function get_day_of_week_short()
	{
		return $this->day_of_week_short;
	}
	function get_day_of_week()
	{
		return $this->day_of_week_long;
	}


	function get_month_name()
	{
		return $this->month_long;
	}

	function get_datetime_by_index_today($hour_index)
	{
		$arr = array();

		if ( $hour_index < 0 || $hour_index > 23  )
		{
			sugar_die("hour is outside of range");
		}

		$arr['hour'] = $hour_index;
		$arr['min'] = 0;
		$arr['day'] = $this->day;

		$arr['month'] = $this->month;
		$arr['year'] = $this->year;

		return new DateTime($arr,true);
	}

	function get_hour_end_time()
	{
		$arr = array();
		$arr['hour'] = $this->hour;
		$arr['min'] = 59;
		$arr['sec'] = 59;
		$arr['day'] = $this->day;

		$arr['month'] = $this->month;
		$arr['year'] = $this->year;

		return new DateTime($arr,true);
	}

	function get_day_end_time()
	{
		$arr = array();
		$arr['hour'] = 23;
		$arr['min'] = 59;
		$arr['sec'] = 59;
		$arr['day'] = $this->day;

		$arr['month'] = $this->month;
		$arr['year'] = $this->year;

		return new DateTime($arr,true);
	}

	function get_day_by_index_this_week($day_index)
	{
		$arr = array();

		if ( $day_index < 0 || $day_index > 6  )
		{
			sugar_die("day is outside of week range");
		}

		$arr['day'] = $this->day + 
			($day_index - $this->day_of_week);

		$arr['month'] = $this->month;
		$arr['year'] = $this->year;

		return new DateTime($arr,true);
	}
	function get_day_by_index_this_year($month_index)
	{
		$arr = array();
		$arr['day'] = $this->day;
		$arr['month'] = $month_index+1;
		$arr['year'] = $this->year;

		return new DateTime($arr,true);
	}

	function get_day_by_index_this_month($day_index)
	{
		$arr = array();
		$arr['day'] = $day_index + 1;
		$arr['month'] = $this->month;
		$arr['year'] = $this->year;

		return new DateTime($arr,true);
	}
}

class Calendar
{
	var $view = 'month';
	var $date_time;
	var $slices_arr = array();
        // for monthly calendar view, if you want to see all the 
        // days in the grid, otherwise you only see that months
	var $show_only_current_slice = false;
	var $show_activities = true;
	var $show_tasks = true;
	var $activity_focus;
        var $show_week_on_month_view = true;
	var $use_24 = 1;
	var $toggle_appt = true;
//	var $shared_users_arr = array();

	function Calendar($view,$time_arr=array())
	{
		global $current_user;
		global $defaultTimeFormat;
		if ( $current_user->getPreference('time'))
		{
			$time = $current_user->getPreference('time');
		}
		else 
		{
			$time = $defaultTimeFormat;
		}
        	if( substr_count($time, 'HH') > 0)
		{
			$this->use_24 = 0;
		}

		$this->view = $view;

		if ( isset($time_arr['activity_focus']))
		{
			$this->activity_focus =  new CalendarActivity($time_arr['activity_focus']);
			$this->date_time =  $this->activity_focus->start_time;
		}
		else
		{
			$this->date_time = new DateTime($time_arr,true);
		}

		if (!( $view == 'day' || $view == 'month' || $view == 'year' || $view == 'week') )
		{
			sugar_die ("view needs to be one of: day, week, month, or year");
		}

		if ( empty($this->date_time->year))
		{
			sugar_die ("all views: year was not set");
		}
		else if ( $view == 'month' && empty($this->date_time->month))
		{
			sugar_die ("month view: month was not set");
		}
		else if ( $view == 'week' && empty($this->date_time->week))
		{
			sugar_die ("week view: week was not set");
		}
		else if ( $view == 'day' && empty($this->date_time->day) && empty($this->date_time->month))
		{
			sugar_die ("day view: day and month was not set");
		}

		$this->create_slices();
		
	}
	function add_shared_users(&$shared_users_arr)
	{
		$this->shared_users_arr = $shared_users_arr;
	}

	function get_view_name($view)
	{
		if ($view == 'month')
		{
			return "MONTH";
		}
		else if ($view == 'week')
		{
			return "WEEK";
		}
		else if ($view == 'day')
		{
			return "DAY";
		}
		else if ($view == 'year')
		{
			return "YEAR";
		}
		else 
		{
			sugar_die ("get_view_name: view ".$this->view." not supported");
		}
	}

	function get_slices_arr()
	{
		return $this->slices_arr;
	}

	function create_slices()
	{
		
		global $current_user;

		if ( $this->view == 'month')
		{
			$days_in_month = $this->date_time->days_in_month;

			
			$first_day_of_month = $this->date_time->get_day_by_index_this_month(0);
			$num_of_prev_days = $first_day_of_month->day_of_week;
			// do 42 slices (6x7 grid)

			for($i=0;$i < 42;$i++)
			{
				$slice = new Slice('day',$this->date_time->get_day_by_index_this_month($i-$num_of_prev_days));
				array_push($this->slices_arr, $slice);	
			}	

		}
		else if ( $this->view == 'week')
		{
			$days_in_week = 7;

			for($i=0;$i<$days_in_week;$i++)
			{
				$slice = new Slice('day',$this->date_time->get_day_by_index_this_week($i));
				array_push($this->slices_arr, $slice);	
			}	
		}
		else if ( $this->view == 'day')
		{
			$hours_in_day = 24;

			for($i=0;$i<$hours_in_day;$i++)
			{
				$slice = new Slice('hour',$this->date_time->get_datetime_by_index_today($i));
				array_push($this->slices_arr, $slice);	
			}	
		}
		else if ( $this->view == 'year')
		{

			for($i=0;$i<12;$i++)
			{
				$slice = new Slice('month',$this->date_time->get_day_by_index_this_year($i));
				array_push($this->slices_arr, $slice);	
			}	
		}
		else 
		{
			sugar_die("not a valid view:".$this->view);
		}

		// add activities to the slice
/*
		if($this->show_activities )
		{
			$this->add_activities($current_user);
		}
*/

		// now put it on the array
	}

	function add_activities($user)
	{
		//array_unshift($this->shared_users_arr,$current_user);

		$acts_arr = CalendarActivity::get_activities($user->id);
		for ($i=0;$i < count($this->slices_arr);$i++)
		{
			//print "<br>--------------------------------<br>";
			foreach ($acts_arr as $act)
			{
			//print "<br>~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~<br>";
				//print "ACT start:".$act->start_time->ts."<br>";
				//print "ACT END:".$act->end_time->ts."<br>";
				//print "slice start:".$this->slices_arr[$i]->start_time->ts."<br>"; 
				//print "slice END:".$this->slices_arr[$i]->end_time->ts."<br>"; 


				if ($this->occurs_within_slice($this->slices_arr[$i],$act))
				{
//	print "OCCURS WITHIN!<BR>";
					if ( ! isset($this->slices_arr[$i]->acts_arr[$user->id]))
					{
						$this->slices_arr[$i]->acts_arr[$user->id] = array();
					}
					array_push($this->slices_arr[$i]->acts_arr[$user->id], $act);	
				}
			}
		}
		
	}

	function occurs_within_slice(&$slice,&$act)
	{
		if ( ($act->end_time->ts >= $slice->start_time->ts && 
			$act->end_time->ts <= $slice->end_time->ts )
			||
			( $act->start_time->ts >= $slice->start_time->ts && 
			$act->start_time->ts < $slice->end_time->ts) 
			||
			( $act->start_time->ts < $slice->start_time->ts && 
			$act->end_time->ts > $slice->end_time->ts) 
		)
		{
			return true;
		}

		return false;

	}

	function get_previous_date_str()
	{
		if ($this->view == 'month')
		{
			$day = $this->date_time->get_first_day_of_last_month();
		}	
		else if ($this->view == 'week')
		{
			$day = $this->date_time->get_first_day_of_last_week();
		}	
		else if ($this->view == 'day')
		{
			$day = $this->date_time->get_yesterday();
		}	
		else if ($this->view == 'year')
		{
			$day = $this->date_time->get_first_day_of_last_year();
		}
		else
		{
			return "get_previous_date_str: notdefined for this view";
		}
		return $day->get_date_str();
	}

	function get_next_date_str()
	{
		if ($this->view == 'month')
		{
			$day = $this->date_time->get_first_day_of_next_month();
		}	
		else
		if ($this->view == 'week')
		{
			$day = $this->date_time->get_first_day_of_next_week();
		}
		else
		if ($this->view == 'day')
		{
			$day = $this->date_time->get_tomorrow();
		}
		else
		if ($this->view == 'year')
		{
			$day = $this->date_time->get_first_day_of_next_year();
		}
		else
		{
			sugar_die("get_next_date_str: not defined for view");
		}
		return $day->get_date_str();
	}

	function get_start_slice_idx()
	{

		if ( $this->view == 'day' )
		{
			$start_at = 8;

			for($i=0;$i < 8; $i++)
			{
				if (count($this->slices_arr[$i]->acts_arr) > 0)
				{
					$start_at = $i;
					break;
				}
			}
			return $start_at;
		}
		else
		{
			return 0;
		}
	}
	function get_end_slice_idx()
	{
		if ( $this->view == 'month')
		{
			return $this->date_time->days_in_month - 1;
		}
		else if ( $this->view == 'week')
		{
			return 6;
		}
		else if ( $this->view == 'day' )
		{
			$end_at = 18;

			for($i=$end_at;$i < 23; $i++)
			{
				if (count($this->slices_arr[$i]->acts_arr) > 0)
				{
					$end_at = $i + 1;
				}
			}
			return $end_at;

		}
		else
		{
			return 1;
		}
	}


}

class Slice
{
	var $view = 'day';
	var $start_time;
	var $end_time;
	var $acts_arr = array();

	function Slice($view,$time)
	{
		$this->view = $view;
		$this->start_time = $time;

		if ( $view == 'day')
		{
			$this->end_time = $this->start_time->get_day_end_time();
		}
		if ( $view == 'hour')
		{
			$this->end_time = $this->start_time->get_hour_end_time();
		}
		
	}
	function get_view()
	{
		return $this->view;
	}

}

class CalendarActivity
{
	var $sugar_bean;
	var $start_time;
	var $end_time;

	function CalendarActivity($sugar_bean)
	{
		$this->sugar_bean = $sugar_bean;	
		if ($sugar_bean->object_name == 'Task')
		{

			$this->start_time = DateTime::get_time_start(
				$this->sugar_bean->date_due,
				$this->sugar_bean->time_due
			);
			if ( empty($this->start_time))
			{
				return null;
			}

			$this->end_time = $this->start_time;
		}
		else
		{
			$this->start_time = DateTime::get_time_start(
			$this->sugar_bean->date_start,
			$this->sugar_bean->time_start
			);

		$this->end_time = DateTime::get_time_end(
			$this->start_time,
         		$this->sugar_bean->duration_hours,
        		$this->sugar_bean->duration_minutes
			);
		}
		
	}
	function get_activities($user_id)
	{
		$act_list = array();
		$seen_ids = array();
		// get all upcoming meetings, tasks due, and calls for a user

		$today = date("Y-m-d", time());
		$later = date("Y-m-d", strtotime("$today + 7 days"));

		$meeting = new Meeting();
	//	$where = "";
		$where = "meetings.assigned_user_id='$user_id'";
		$focus_meetings_list = $meeting->get_full_list("time_start", $where);

                $query = "SELECT meeting_id as id from meetings_users where user_id='$user_id' AND deleted=0";

		if(! isset($focus_meetings_list))
		{
			$focus_meetings_list = array();
		}

                $focus_meetings_list += $meeting->build_related_list($query, new Meeting());

		foreach($focus_meetings_list as $meeting)
		{
			if (isset($seen_ids[$meeting->id]))
			{
				continue;
			}
			$seen_ids[$meeting->id] = 1;
			$act = new CalendarActivity($meeting);

			if ( ! empty($act))
			{
				array_push($act_list,$act);
			}
		}

		$call = new Call();
		$where = "calls.assigned_user_id='$user_id'";
		$focus_calls_list = $call->get_full_list("time_start", $where);

                $query = "SELECT call_id as id from calls_users where user_id='$user_id' AND deleted=0";

		if(! isset($focus_calls_list))
		{
			$focus_calls_list = array();
		}

                $focus_calls_list += $call->build_related_list($query, new Call());

		foreach($focus_calls_list as $call)
		{
			if (isset($seen_ids[$call->id]))
			{
				continue;
			}
			$seen_ids[$call->id] = 1;

			$act = new CalendarActivity($call);
			if ( ! empty($act))
			{
				array_push($act_list,$act);
			}
		}
		
		if ( $this->show_tasks )
		{

			$task = new Task();
			$where = "tasks.assigned_user_id='$user_id'";
			$focus_tasks_list = $task->get_full_list("", $where);

			if(! isset($focus_tasks_list))
			{
				$focus_tasks_list = array();
			}

			foreach($focus_tasks_list as $task)
			{
				$act = new CalendarActivity($task);
				if ( ! empty($act))
				{
					array_push($act_list,$act);
				}
			}
		}

		usort($act_list,'sort_func_by_act_date');
		return $act_list;




	}
}

?>
