<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => '電子郵件',
  'LBL_MODULE_TITLE' => '電子郵件: 首頁',
  'LBL_SEARCH_FORM_TITLE' => '搜尋郵件',
  'LBL_LIST_FORM_TITLE' => '郵件列表',
  'LBL_NEW_FORM_TITLE' => '發送郵件',
  'LBL_LIST_SUBJECT' => '主題',
  'LBL_LIST_CONTACT' => '聯絡人',
  'LBL_LIST_RELATED_TO' => '相關於',
  'LBL_LIST_DATE' => '發送日期',
  'LBL_LIST_TIME' => '發送時間',
  'ERR_DELETE_RECORD' => '必須指定公司記錄編號才能進行刪除.',
  'LBL_DATE_SENT' => '發送日期：',
  'LBL_SUBJECT' => '主題：',
  'LBL_BODY' => '內容：',
  'LBL_DATE_AND_TIME' => '發送日期與時間：',
  'LBL_DATE' => '發送日期：',
  'LBL_TIME' => '發送時間：',
  'LBL_CONTACT_NAME' => ' 聯絡人姓名: ',
  'LBL_EMAIL' => '電子郵件：',
  'LBL_COLON' => '：',
  'NTC_REMOVE_INVITEE' => '你確定要把此人從Email收件人刪除嗎？',
  'LBL_INVITEE' => '收件人',
  'LNK_NEW_CALL' => '新增電話記錄',
  'LNK_NEW_MEETING' => '新增會議',
  'LNK_NEW_TASK' => '新增任務',
  'LNK_NEW_NOTE' => '新增備註',
  'LNK_NEW_EMAIL' => '新增電子郵件',
  'LNK_CALL_LIST' => 'Calls',
  'LNK_MEETING_LIST' => 'Meetings',
  'LNK_TASK_LIST' => 'Tasks',
  'LNK_NOTE_LIST' => 'Notes',
  'LNK_EMAIL_LIST' => 'Emails',
  'LNK_VIEW_CALENDAR' => 'Today',
  'LNK_NEW_CONTACT' => '新增聯絡人',
  'LNK_NEW_ACCOUNT' => '新增公司',
  'LNK_NEW_OPPORTUNITY' => '新增機會',
  'LNK_NEW_CASE' => '新增事件',
);


?>