******************************
*SugarCRM Fall 2004 Release  * 
******************************


Sugar Sales v1.5
September 9, 2004 

-=Overview=-
An import & export tool, file attachments, more and better charts, sortable columns, a calendar date picker, and more!  The team at SugarCRM Inc. is pleased to bring you the v1.5 release. 

For businesses that rely on Sugar Sales as a mission-critical system, SugarCRM Inc. has also introduced Sugar Sales Professional which includes an MS Outlook Plug-In, exemplary customer support, and more.  The Outlook Plug-In simplifies archiving email communications with customers by allowing users to easily push emails from MS Outlook into Sugar Sales.

You can send us an email any time with your feedback at contact@sugarcrm.com.  Our goal continues to be to build the sales automation system that you have always wanted, so your input is vital.

Check out http://www.sugarcrm.com for details on Sugar Professional, the latest product roadmap, support forums, detailed product information and much more.  We hope you find this a useful tool for building your business.

Enjoy! 
The Sugar Team 


------------------------------------------------------------------------------------------
1.5d
------------------------------------------------------------------------------------------
Added: Better checks for blank passwords
Fix: File Upload - Cleanroom Implementation
Fix: "Last Viewed" - problems with German characters
Fix: "Last Viewed" - problems with HTML escaping
Fix: Modified user id no longer being set
Fix: business card not escaping chars
Fix: searching for duplicates returns deleted records
Fix: Spelling mistake in about box
Fix: Import Contacts from saved custom source
Fix: Current User ignored on Home page
Fix: No Calendar prompt on Edit Task
Fix: Items in history before user is logged in

------------------------------------------------------------------------------------------
1.5c
------------------------------------------------------------------------------------------

Added: Form for easy data entry from business card 
Fix: Improved handling of bad HTML and DB queries
Fix: Creating or selecting contacts from accounts
Fix: Large import causes file error
Fix: Drop down list values not preserved after changing translation
Fix: "Last Viewed" listing deleted Email Object
Fix: Import fails without good error message if cache directory is not writable
Fix: Goldmine import breaks file parser
Fix: Quick add disapears after executing a search
Fix: Case list view requires an account for cases to display

------------------------------------------------------------------------------------------
1.5b
------------------------------------------------------------------------------------------

Fix: better undo with imports that link in ID's from other modules
Fix: upload failure for some platforms
Fix: Problem with italian translation
Fix: Screen goes blank after sending registration
Fix: No line breaks in "Description" field (DetailView) few more
Fix: Change password screen initial cursor position
Fix: Adding a contact to an existing account (account doesn't carry over)
Fix: Quick add disappears aftering executing a search
Fix: "Last Viewed" listing deleted Email Object

------------------------------------------------------------------------------------------
1.5a
------------------------------------------------------------------------------------------

New: Enable/disable export feature from configuration directives
Fix: PHP Encoding was returning incorrect value for non-English systems.
Fix: A few list view fields were replicating data from above when they were empty
Fix: Traditional Chinese works better with graphs
New: Imports for Opportunities
New: Import maximum file size now looks in config.php and has a better error message if it is exceeded.
Fix: Cache directory checks during import enhanced.
Fix: Column labels not showing up on last imported contacts
Fix: Import parsed SalesForce.com's footer
Fix: Import contacts, contact skipped was still entering account.
Fix: Import contacts, Related account records were not assigned to the current user
Fix: Import contacts, Account IDs were not used when available


-=Included Features=-
An overview of the features in this release. 

Import and Export
New to v1.5, any user can import contacts and accounts from CSV (comma separated values) files.  Users can also easily export data from the system to CSV files.

Opportunities
Sugar Sales provides a complete, yet easy-to-use Opportunities module.  From deal size to each contact�s role, from listing the competitors to tracking the lead source, sales reps can easily manage each sales opportunity to completion.  

Accounts & Contacts
With the Accounts & Contacts module, you can easily enter and update key account and contact information. Tracking and staying in touch with your customers is simply a click away. 

Activity & Task Management
Managing your customer interactions is at the heart of a sales automation application. Sugar Sales provides a simple and clean set of tools for quickly tracking tasks, phone calls, emails and meetings. 

Notes & Attachments
Easily keep notes on every contact, opportunity or account. New to v1.5, add file attachments to notes.  

Home Screen 
Focus on the right activities with a quick view of your top opportunities, pipeline, today's appointments and task list.

Dashboard 
A picture is always worth a thousand words.  With the dashboard module, you can graphically view how your opportunities breakdown by sales stage or industry.  New to v1.5, you can customize the charts to display the data you want.

Administration 
Easily manage all the users in the system, their passwords, user interface themes and more. 


-=Future Planned Features=-
What we're working on next. 

Internationalization 
Support for local and localized date and time display. 

Leads
Put standardized processes into practice to make sure all sales reps use the same, consistent lead qualification methodology. With the click of a button, quickly turn leads into opportunities. With the Sugar Sales Leads module, you can also easily manage rented lists and prospect data separate from your customer data.

Forecasting
Accurately predict and forecast revenue by territory, product line or indirect channels. 

Sales Teams 
Assign your sales force to territories and sales teams and manage access permissions by teams or territories. 

Accounts & Contacts
Easily sync customer contact information between Sugar Sales and MS Outlook and Palm devices. 

Activity & Task Management
Plug-ins for PDAs and email applications that deliver a best-in-class open source solution for tracking key customer information in your PDA quickly and easily.

Notes & Attachments
Ability to enter HTML notes. Also provide for full-text searching across text or HTML notes as well as most file attachments.

Dashboard 
More dashboard charts including the ability to customize the charts by time ranges, deal size and more. 

Reports 
An easy-to-customize and easy-to-use reporting tool. 

Administration 
A simple set of tools that anybody can use for adding new fields to forms and changing columns displayed in lists. 
