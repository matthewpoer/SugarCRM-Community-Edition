<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Andre L L Dantas (alld@sourceforge) from Visuelles Informatica.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Opportunities/language/pt_br.lang.php,v 1.00 2004/08/09 21:00:00 sugarclint Exp $
 * Description:  Defines the Portuguese (Brazilian) language pack for the Opportunity module.
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_MODULE_NAME'=>'Oportunidades',
'LBL_MODULE_TITLE'=>'Oportunidades: Principal',
'LBL_SEARCH_FORM_TITLE'=>'Pesquisar Oportunidades',
'LBL_LIST_FORM_TITLE'=>'Lista de Oportunidades',
'LBL_OPPORTUNITY_NAME'=>'Nome da Oportunidade:',
'LBL_OPPORTUNITY'=>'Oportunidade:',
'LBL_NAME'=>'Nome da Oportunidade',

'LBL_LIST_OPPORTUNITY_NAME'=>'Oportunidade',
'LBL_LIST_ACCOUNT_NAME'=>'Nome da Conta',
'LBL_LIST_AMOUNT'=>'Valor',
'LBL_LIST_DATE_CLOSED'=>'Data Prevista',
'LBL_LIST_SALES_STAGE'=>'Est�gio Vendas',

'LBL_OPPORTUNITY_NAME'=>'Nome da Oportunidade:',
'LBL_ACCOUNT_NAME'=>'Nome da Conta:',
'LBL_AMOUNT'=>'Valor:',
'LBL_DATE_CLOSED'=>'Data Prevista:',
'LBL_TYPE'=>'Tipo:',
'LBL_NEXT_STEP'=>'Pr�ximo Passo:',
'LBL_LEAD_SOURCE'=>'Fonte:',
'LBL_SALES_STAGE'=>'Est�gio Venda:',
'LBL_PROBABILITY'=>'Probabilidade (%):',
'LBL_DESCRIPTION'=>'Descri��o:',

'LBL_NEW_FORM_TITLE'=>'Nova Oportunidade',
'LNK_NEW_CONTACT'=>'Novo Contato',
'LNK_NEW_ACCOUNT'=>'Nova Conta',
'LNK_NEW_OPPORTUNITY'=>'Nova Oportunidade',
'LNK_NEW_CASE'=>'Novo Caso',
'LNK_NEW_NOTE'=>'Nova Nota',
'LNK_NEW_CALL'=>'Nova Chamada',
'LNK_NEW_EMAIL'=>'Novo Email',
'LNK_NEW_MEETING'=>'Nova Reuni�o',
'LNK_NEW_TASK'=>'Nova Tarefa',

'ERR_DELETE_RECORD'=>"Um n�mero de registro deve ser especificado para excluir a oportunidade.",
'LBL_TOP_OPPORTUNITIES'=>"Minhas Melhores Oportunidades",
);

?>