<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Andre L L Dantas (alld@sourceforge) from Visuelles Informatica.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Accounts/language/pt_br.lang.php,v 1.00 2004/08/09 21:00:00 sugarclint Exp $
 * Description:  Defines the Portuguese (Brazilian) language pack for the Account module.
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_MODULE_NAME'=>'Contas',
'LBL_MODULE_TITLE'=>'Contas: Principal',
'LBL_SEARCH_FORM_TITLE'=>'Pesquisar Conta',
'LBL_LIST_FORM_TITLE'=>'Lista de Contas',
'LBL_NEW_FORM_TITLE'=>'Nova Conta',
'LBL_MEMBER_ORG_FORM_TITLE'=>'Organiza��es Membros',

'LBL_LIST_ACCOUNT_NAME'=>'Nome da Conta',
'LBL_LIST_CITY'=>'Cidade',
'LBL_LIST_WEBSITE'=>'Website',
'LBL_LIST_STATE'=>'Estado',
'LBL_LIST_PHONE'=>'Fone',

'LBL_ACCOUNT'=>'Conta:',
'LBL_ACCOUNT_NAME'=>'Nome da Conta:',
'LBL_PHONE'=>'Fone:',
'LBL_WEBSITE'=>'Website:',
'LBL_FAX'=>'Fax:',
'LBL_TICKER_SYMBOL'=>'C�digo Bolsa:',
'LBL_OTHER_PHONE'=>'Outro Fone:',
'LBL_ANY_PHONE'=>'Fone qualquer:',
'LBL_MEMBER_OF'=>'Membro de:',
'LBL_EMAIL'=>'Email:',
'LBL_EMPLOYEES'=>'Funcion�rios:',
'LBL_OTHER_EMAIL_ADDRESS'=>'Outro Email:',
'LBL_ANY_EMAIL'=>'Email qualquer:',
'LBL_OWNERSHIP'=>'Propriedade:',
'LBL_RATING'=>'Avalia��o:',
'LBL_INDUSTRY'=>'Neg�cio:',
'LBL_SIC_CODE'=>'C�digo SIC:',
'LBL_TYPE'=>'Tipo:',
'LBL_ANNUAL_REVENUE'=>'Receita Anual:',
'LBL_ADDRESS_INFORMATION'=>'Informa��o de Endere�o',
'LBL_BILLING_ADDRESS'=>'Endere�o Cobran�a:',
'LBL_SHIPPING_ADDRESS'=>'Endere�o Entrega:',
'LBL_ANY_ADDRESS'=>'Endere�o qualquer:',
'LBL_CITY'=>'Cidade:',
'LBL_STATE'=>'Estado:',
'LBL_POSTAL_CODE'=>'CEP:',
'LBL_COUNTRY'=>'Pa�s:',
'LBL_DESCRIPTION_INFORMATION'=>'Informa��o de Descri��o',
'LBL_DESCRIPTION'=>'Descri��o:',
'NTC_COPY_BILLING_ADDRESS'=>'Copiar endere�o cobran�a para endere�o entrega',
'NTC_COPY_SHIPPING_ADDRESS'=>'Copiar endere�o entrega para endere�o cobran�a',
'NTC_REMOVE_MEMBER_ORG_CONFIRMATION'=>'Tem certeza que quer remover este registro como uma organiza��o membro?',

'LNK_NEW_CONTACT'=>'Novo Contato',
'LNK_NEW_ACCOUNT'=>'Nova Conta',
'LNK_NEW_OPPORTUNITY'=>'Nova Oportunidade',
'LNK_NEW_CASE'=>'Novo Caso',
'LNK_NEW_NOTE'=>'Nova Nota',
'LNK_NEW_CALL'=>'Nova Chamada',
'LNK_NEW_EMAIL'=>'Novo Email',
'LNK_NEW_MEETING'=>'Nova Reuni�o',
'LNK_NEW_TASK'=>'Nova Tarefa',
'ERR_DELETE_RECORD'=>"Um n�mero de registro deve ser especificado para excluir a conta.",


);

?>