<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Andre L L Dantas (alld@sourceforge) from Visuelles Informatica.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Contacts/language/pt_br.lang.php,v 1.00 2004/08/09 21:00:00 sugarclint Exp $
 * Description:  Defines the Portuguese (Brazilian) language pack 
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_MODULE_NAME'=>'Contatos',
'LBL_DIRECT_REPORTS_FORM_NAME'=>'Reporta-se a',
'LBL_MODULE_TITLE'=>'Contatos: Principal',
'LBL_SEARCH_FORM_TITLE'=>'Pesquisar Contatos',
'LBL_LIST_FORM_TITLE'=>'Lista de Contatos',
'LBL_NEW_FORM_TITLE'=>'Novo Contato',
'LBL_CONTACT_OPP_FORM_TITLE'=>'Contato-Oportunidade:',
'LBL_CONTACT'=>'Contato:',

'LBL_LIST_NAME'=>'Nome',
'LBL_LIST_LAST_NAME'=>'Sobrenome',
'LBL_LIST_CONTACT_NAME'=>'Nome do Contato',
'LBL_LIST_TITLE'=>'Cargo',
'LBL_LIST_ACCOUNT_NAME'=>'Nome da Conta',
'LBL_LIST_EMAIL_ADDRESS'=>'Email',
'LBL_LIST_PHONE'=>'Fone',
'LBL_LIST_CONTACT_ROLE'=>'Papel',

'LBL_NAME'=>'Nome:',
'LBL_CONTACT_NAME'=>'Nome do Contato:',
'LBL_CONTACT_INFORMATION'=>'Informa��o do Contato',
'LBL_FIRST_NAME'=>'Nome:',
'LBL_OFFICE_PHONE'=>'Fone Escrit�rio:',
'LBL_ACCOUNT_NAME'=>'Nome da Conta:',
'LBL_ANY_PHONE'=>'Fone qualquer:',
'LBL_PHONE'=>'Fone:',
'LBL_LAST_NAME'=>'Sobrenome:',
'LBL_MOBILE_PHONE'=>'Celular:',
'LBL_HOME_PHONE'=>'Home:',
'LBL_LEAD_SOURCE'=>'Fonte:',
'LBL_OTHER_PHONE'=>'Outro Fone:',
'LBL_FAX_PHONE'=>'Fax:',
'LBL_TITLE'=>'Cargo:',
'LBL_DEPARTMENT'=>'Departamento:',
'LBL_BIRTHDATE'=>'Data Nascimento:',
'LBL_EMAIL_ADDRESS'=>'Email:',
'LBL_OTHER_EMAIL_ADDRESS'=>'Outro Email:',
'LBL_ANY_EMAIL'=>'Email qualquer:',
'LBL_REPORTS_TO'=>'Reporta-se a:',
'LBL_ASSISTANT'=>'Assistente:',
'LBL_YAHOO_ID'=>'ID Yahoo!:',
'LBL_ASSISTANT_PHONE'=>'Fone do Assistente:',
'LBL_DO_NOT_CALL'=>'N�o Chamar:',
'LBL_EMAIL_OPT_OUT'=>'N�o Quer Email:',
'LBL_PRIMARY_ADDRESS'=>'Endere�o Principal:',
'LBL_ALTERNATE_ADDRESS'=>'Endere�o Alternativo:',
'LBL_ANY_ADDRESS'=>'Endere�o qualquer:',
'LBL_CITY'=>'Cidade:',
'LBL_STATE'=>'Estado:',
'LBL_POSTAL_CODE'=>'CEP:',
'LBL_COUNTRY'=>'Pa�s:',
'LBL_DESCRIPTION_INFORMATION'=>'Informa��o de Descri��o',
'LBL_DESCRIPTION'=>'Descri��o:',
'LBL_CONTACT_ROLE'=>'Papel:',
'LBL_OPP_NAME'=>'Nome da Oportunidade:',

'LNK_NEW_CONTACT'=>'Novo Contato',
'LNK_NEW_ACCOUNT'=>'Nova Conta',
'LNK_NEW_OPPORTUNITY'=>'Nova Oportunidade',
'LNK_NEW_CASE'=>'Novo Caso',
'LNK_NEW_NOTE'=>'Nova Nota',
'LNK_NEW_CALL'=>'Nova Chamada',
'LNK_NEW_EMAIL'=>'Novo Email',
'LNK_NEW_MEETING'=>'Nova Reuni�o',
'LNK_NEW_TASK'=>'Nova Tarefa',
'NTC_DELETE_CONFIRMATION'=>'Tem certeza que deseja excluir este registro?',
'NTC_REMOVE_CONFIRMATION'=>'Tem certeza que deseja remover este contato deste caso?',
'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION'=>'Tem certeza que deseja remover este registro como um reporter direto?',
'NTC_REMOVE_OPP_CONFIRMATION'=>'Tem certeza que deseja remover este contato desta oportunidade?',
'ERR_DELETE_RECORD'=>"Um n�mero de registro deve ser especificado para excluir o contato.",
'NTC_COPY_PRIMARY_ADDRESS'=>'Copiar endere�o principal para endere�o alternativo',
'NTC_COPY_ALTERNATE_ADDRESS'=>'Copiar endere�o alternativo para endere�o principal',
);

?>