<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Accounts/language/ge_ch.lang.php, v 1.00 2004/08/05 09:48:58 erich.althaus@creative-solutions.ch $
 * Description:  Defines the Swiss German language pack 
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_MODULE_NAME'=>'Accounts',
'LBL_MODULE_TITLE'=>'Accounts: Home',
'LBL_SEARCH_FORM_TITLE'=>'Account Suchen',
'LBL_LIST_FORM_TITLE'=>'Account Liste',
'LBL_NEW_FORM_TITLE'=>'Neuer Account',
'LBL_MEMBER_ORG_FORM_TITLE'=>'Organisation',

'LBL_LIST_ACCOUNT_NAME'=>'Account Namen',
'LBL_LIST_CITY'=>'Ort',
'LBL_LIST_WEBSITE'=>'Web',
'LBL_LIST_STATE'=>'Kanton',
'LBL_LIST_PHONE'=>'Telefon',

'LBL_ACCOUNT'=>'Account:',
'LBL_ACCOUNT_NAME'=>'Account Namen:',
'LBL_PHONE'=>'Telefon:',
'LBL_WEBSITE'=>'Web:',
'LBL_FAX'=>'Fax:',
'LBL_TICKER_SYMBOL'=>'Ticker Symbol:',
'LBL_OTHER_PHONE'=>'Weitere Telefonnummer:',
'LBL_ANY_PHONE'=>'Andere Telefonnummer:',
'LBL_MEMBER_OF'=>'Mitglied von:',
'LBL_EMAIL'=>'Email:',
'LBL_EMPLOYEES'=>'Mitarbeiter:',
'LBL_OTHER_EMAIL_ADDRESS'=>'Andere Email:',
'LBL_ANY_EMAIL'=>'Weitere Email:',
'LBL_OWNERSHIP'=>'Eigent�mer:',
'LBL_RATING'=>'Bewertung:',
'LBL_INDUSTRY'=>'Branche:',
'LBL_SIC_CODE'=>'SIC Code:',
'LBL_TYPE'=>'Typ:',
'LBL_ANNUAL_REVENUE'=>'Erl�s pro Jahr:',
'LBL_ADDRESS_INFORMATION'=>'Addressinformationen',
'LBL_BILLING_ADDRESS'=>'Rechnungs Addresse:',
'LBL_SHIPPING_ADDRESS'=>'Liefer Addresse:',
'LBL_ANY_ADDRESS'=>'weitere Addresse:',
'LBL_CITY'=>'Ort:',
'LBL_STATE'=>'Kanton:',
'LBL_POSTAL_CODE'=>'PLZ:',
'LBL_COUNTRY'=>'Land:',
'LBL_DESCRIPTION_INFORMATION'=>'Zus�tzliche Informationen',
'LBL_DESCRIPTION'=>'Beschreibung:',
'NTC_COPY_BILLING_ADDRESS'=>'Rechnungs Adresse in Liefer Adresse kopieren',
'NTC_COPY_SHIPPING_ADDRESS'=>'Liefer Adresse in Rechnungs Adresse kopieren',
'NTC_REMOVE_MEMBER_ORG_CONFIRMATION'=>'Sind Sie sicher das Sie diesen Eintrag als Mitglieder Organisation entfernen wollen?',

'LNK_NEW_CONTACT'=>'Neuer Kontakt',
'LNK_NEW_ACCOUNT'=>'Neuer Account',
'LNK_NEW_OPPORTUNITY'=>'Neue Opportunity',
'LNK_NEW_CASE'=>'Neuer Case',
'LNK_NEW_NOTE'=>'Neue Notiz',
'LNK_NEW_CALL'=>'Neues Telefonat',
'LNK_NEW_EMAIL'=>'Neue Email',
'LNK_NEW_MEETING'=>'Neues Meeting',
'LNK_NEW_TASK'=>'Neue Pendenz',
'ERR_DELETE_RECORD'=>"Ein Eintrg muss ausgew�hlt sein um ein Account zu l�schen.",


);

?>