<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Notes/language/ge_ch.lang.php, v 1.00 2004/08/05 09:48:58 erich.althaus@creative-solutions.ch $
 * Description:  Defines the Swiss German language pack 
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_MODULE_NAME'=>'Notizen',
'LBL_MODULE_TITLE'=>'Notizen: Home',
'LBL_SEARCH_FORM_TITLE'=>'Notizen Suchen',
'LBL_LIST_FORM_TITLE'=>'Notizen Liste',
'LBL_NEW_FORM_TITLE'=>'Neue Notiz',

'LBL_LIST_SUBJECT'=>'Titel',
'LBL_LIST_CONTACT_NAME'=>'Kontakt Namen',
'LBL_LIST_RELATED_TO'=>'Zugewiesen an',
'LBL_LIST_DATE_MODIFIED'=>'Zuletzt ge�ndert',

'LBL_NOTE'=>'Notiz:',
'LBL_NOTE_SUBJECT'=>'Notiz Titel:',
'LBL_CONTACT_NAME'=>'Kontakt Namen:',
'LBL_PHONE'=>'Telefon:',
'LBL_SUBJECT'=>'Titel:',
'LBL_CLOSE'=>'Schliessen:',
'LBL_RELATED_TO'=>'Zugewiesen an:',
'LBL_DATE_MODIFIED'=>'Zuletzt ge�ndert:',
'LBL_EMAIL_ADDRESS'=>'Email Addresse:',
'LBL_COLON'=>':',

'LNK_NEW_CONTACT'=>'Neuer Kontakt',
'LNK_NEW_ACCOUNT'=>'Neuer Account',
'LNK_NEW_OPPORTUNITY'=>'Neue Opportunity',
'LNK_NEW_CASE'=>'Neuer Case',
'LNK_NEW_NOTE'=>'Neue Notiz',
'LNK_NEW_CALL'=>'Neues Telefonat',
'LNK_NEW_EMAIL'=>'Neue Email',
'LNK_NEW_MEETING'=>'Neues Meeting',
'LNK_NEW_TASK'=>'Neue Pendenz',
'ERR_DELETE_RECORD'=>"Ein Eintrg muss ausgew�hlt sein um eine Notiz zu l�schen.",
);

?>