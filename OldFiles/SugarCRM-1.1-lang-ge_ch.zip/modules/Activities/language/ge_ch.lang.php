<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Activities/language/ge_ch.lang.php, v 1.00 2004/08/05 09:48:58 erich.althaus@creative-solutions.ch $
 * Description:  Defines the Swiss German language pack 
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_OPEN_ACTIVITIES'=>'Offene Aktivit�ten',
'LBL_HISTORY'=>'Verlauf',
'LBL_UPCOMING'=>"Anstehende Aktivit�ten",
'LBL_TODAY'=>'am ',

'LBL_NEW_TASK_BUTTON_TITLE'=>'Neuer Task [Alt+N]',
'LBL_NEW_TASK_BUTTON_KEY'=>'N',
'LBL_NEW_TASK_BUTTON_LABEL'=>'Neuer Task',
'LBL_SCHEDULE_MEETING_BUTTON_TITLE'=>'Meeting eintragen [Alt+M]',
'LBL_SCHEDULE_MEETING_BUTTON_KEY'=>'M',
'LBL_SCHEDULE_MEETING_BUTTON_LABEL'=>'Meeting eintragen',
'LBL_SCHEDULE_CALL_BUTTON_TITLE'=>'Telefonat eintragen [Alt+C]',
'LBL_SCHEDULE_CALL_BUTTON_KEY'=>'C',
'LBL_SCHEDULE_CALL_BUTTON_LABEL'=>'Telefonat eintragen',
'LBL_NEW_NOTE_BUTTON_TITLE'=>'Neue Notiz [Alt+T]',
'LBL_NEW_NOTE_BUTTON_KEY'=>'T',
'LBL_NEW_NOTE_BUTTON_LABEL'=>'Neue Notiz',
'LBL_TRACK_EMAIL_BUTTON_TITLE'=>'Email verfolgen [Alt+K]',
'LBL_TRACK_EMAIL_BUTTON_KEY'=>'K',
'LBL_TRACK_EMAIL_BUTTON_LABEL'=>'Email verfolgen',

'LBL_LIST_CLOSE'=>'Schliessen',
'LBL_LIST_STATUS'=>'Status',
'LBL_LIST_CONTACT'=>'Kontakt',
'LBL_LIST_RELATED_TO'=>'Zugewiesen an',
'LBL_LIST_DUE_DATE'=>'F�llig am',
'LBL_LIST_DATE'=>'Datum',
'LBL_LIST_SUBJECT'=>'Titel',
'LBL_LIST_LAST_MODIFIED'=>'Zuletzt ge�ndert',

'LNK_NEW_CONTACT'=>'Neuer Kontakt',
'LNK_NEW_ACCOUNT'=>'Neuer Account',
'LNK_NEW_OPPORTUNITY'=>'Neue Opportunity',
'LNK_NEW_CASE'=>'Neuer Case',
'LNK_NEW_NOTE'=>'Neue Notiz',
'LNK_NEW_CALL'=>'Neues Telefonat',
'LNK_NEW_EMAIL'=>'Neue Email',
'LNK_NEW_MEETING'=>'Neues Meeting',
'LNK_NEW_TASK'=>'Neue Pendenz',
'ERR_DELETE_RECORD'=>"Ein Eintrg muss ausgew�hlt sein um eine Aktivit�t zu l�schen.",

);

?>