<?php
	// $Id: sugar_version.php,v 1.31.2.5 2005/04/08 16:19:35 bob Exp $
	$sugar_version = '2.5.1c';
?>
