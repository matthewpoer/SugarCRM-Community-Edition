<?php
// created: 2008-02-13 10:59:06
$manifest = array (
  'acceptable_sugar_flavors' => 
  array (
    0 => 'CE',
    1 => 'OS',
  ),
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '4\\.5\\.1',
    ),
  ),
  'author' => 'SugarCRM, Inc.',
  'copy_files' => 
  array (
    'from_dir' => 'SugarCE-Upgrade-4.5.1-to-5.0.0b',
    'to_dir' => '',
    'force_copy' => 
    array (
    ),
  ),
  'description' => '',
  'icon' => '',
  'is_uninstallable' => false,
  'offline_client_applicable' => true,
  'name' => 'SugarCE',
  'published_date' => '2008-02-13 10:59:06',
  'type' => 'patch',
  'version' => '5.0.0b',
);
?>
