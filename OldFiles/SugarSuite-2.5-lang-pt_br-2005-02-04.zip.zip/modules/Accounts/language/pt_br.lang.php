<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Contas',
  'LBL_MODULE_TITLE' => 'Contas: Principal',
  'LBL_SEARCH_FORM_TITLE' => 'Pesquisar Conta',
  'LBL_LIST_FORM_TITLE' => 'Lista de Contas',
  'LBL_NEW_FORM_TITLE' => 'Nova Conta',
  'LBL_MEMBER_ORG_FORM_TITLE' => 'Organiza��es Membros',
  'LBL_BUG_FORM_TITLE' => 'Accounts',
  'LBL_LIST_ACCOUNT_NAME' => 'Nome da Conta',
  'LBL_LIST_CITY' => 'Cidade',
  'LBL_LIST_WEBSITE' => 'Website',
  'LBL_LIST_STATE' => 'Estado',
  'LBL_LIST_PHONE' => 'Fone',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email',
  'LBL_LIST_CONTACT_NAME' => 'Contato',
  'db_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_website' => 'LBL_LIST_WEBSITE',
  'db_billing_address_city' => 'LBL_LIST_CITY',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'LBL_ACCOUNT_INFORMATION' => 'Informa��o da Conta',
  'LBL_ACCOUNT' => 'Conta:',
  'LBL_ACCOUNT_NAME' => 'Nome da Conta:',
//END DON'T CONVERT
  'LBL_PHONE' => 'Fone:',
  'LBL_PHONE_ALT' => 'Alternate Phone:',
  'LBL_WEBSITE' => 'Website:',
  'LBL_FAX' => 'Fax:',
  'LBL_TICKER_SYMBOL' => 'C�digo Bolsa:',
  'LBL_OTHER_PHONE' => 'Outro Fone:',
  'LBL_ANY_PHONE' => 'Fone qualquer:',
  'LBL_MEMBER_OF' => 'Membro de:',
  'LBL_PHONE_OFFICE' => 'Phone Office:',
  'LBL_PHONE_FAX' => 'Phone Fax:',
  'LBL_EMAIL' => 'Email:',
  'LBL_EMPLOYEES' => 'Funcion�rios:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Outro Email:',
  'LBL_ANY_EMAIL' => 'Email qualquer:',
  'LBL_OWNERSHIP' => 'Propriedade:',
  'LBL_RATING' => 'Avalia��o:',
  'LBL_INDUSTRY' => 'Neg�cio:',
  'LBL_SIC_CODE' => 'C�digo SIC:',
  'LBL_TYPE' => 'Tipo:',
  'LBL_ANNUAL_REVENUE' => 'Receita Anual:',
  'LBL_ADDRESS_INFORMATION' => 'Informa��o de Endere�o',
  'LBL_BILLING_ADDRESS' => 'Endere�o Cobran�a:',
  'LBL_BILLING_ADDRESS_STREET' => 'Billing Address Street:',
  'LBL_BILLING_ADDRESS_CITY' => 'Billing Address City:',
  'LBL_BILLING_ADDRESS_STATE' => 'Billing Address State:',
  'LBL_BILLING_ADDRESS_POSTALCODE' => 'Billing Address Postal Code:',
  'LBL_BILLING_ADDRESS_COUNTRY' => 'Billing Address Country:',
  'LBL_SHIPPING_ADDRESS_STREET' => 'Shipping Address Street:',
  'LBL_SHIPPING_ADDRESS_CITY' => 'Shipping Address City:',
  'LBL_SHIPPING_ADDRESS_STATE' => 'Shipping Address State:',
  'LBL_SHIPPING_ADDRESS_POSTALCODE' => 'Shipping Address Postal Code:',
  'LBL_SHIPPING_ADDRESS_COUNTRY' => 'Shipping Address Country:',
  'LBL_SHIPPING_ADDRESS' => 'Endere�o Entrega:',
  'LBL_DATE_MODIFIED' => 'Date Modified:',
  'LBL_DATE_ENTERED' => 'Date Entered:',
  'LBL_ANY_ADDRESS' => 'Endere�o qualquer:',
  'LBL_CITY' => 'Cidade:',
  'LBL_STATE' => 'Estado:',
  'LBL_POSTAL_CODE' => 'CEP:',
  'LBL_COUNTRY' => 'Pa�s:',
  'LBL_DESCRIPTION_INFORMATION' => 'Informa��o de Descri��o',
  'LBL_DESCRIPTION' => 'Descri��o:',
  'NTC_COPY_BILLING_ADDRESS' => 'Copiar endere�o cobran�a para endere�o entrega',
  'NTC_COPY_SHIPPING_ADDRESS' => 'Copiar endere�o entrega para endere�o cobran�a',
  'NTC_REMOVE_MEMBER_ORG_CONFIRMATION' => 'Tem certeza que quer remover este registro como uma organiza��o membro?',
  'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Are you sure you want to remove this record?',
  'LBL_DUPLICATE' => 'Possible Duplicate Account',
  'MSG_SHOW_DUPLICATES' => 'Creating this contact may potentialy create a duplicate contact. You may either click on Create Account to continue creating this new account with the previously entered data or you may click Cancel.',
  'MSG_DUPLICATE' => 'Creating this account may potentialy create a duplicate account. You may either select an account from the list below or you may click on Create New Account to continue creating a new account with the previously entered data.',
  'LNK_NEW_ACCOUNT' => 'Nova Conta',
  'LNK_ACCOUNT_LIST' => 'Accounts',
  'LBL_INVITEE' => 'Contatos',
  'ERR_DELETE_RECORD' => 'Um n�mero de registro deve ser especificado para excluir a conta.',
  'NTC_DELETE_CONFIRMATION' => 'Are you sure you want to delete this record?',
  'LBL_SAVE_ACCOUNT' => 'Save Account',
  'LNK_NEW_CONTACT' => 'Novo Contato',
  'LNK_NEW_OPPORTUNITY' => 'Nova Oportunidade',
  'LNK_NEW_CASE' => 'Novo Caso',
  'LNK_NEW_NOTE' => 'Nova Nota',
  'LNK_NEW_CALL' => 'Nova Chamada',
  'LNK_NEW_EMAIL' => 'Novo Email',
  'LNK_NEW_MEETING' => 'Nova Reuni�o',
  'LNK_NEW_TASK' => 'Nova Tarefa',
);


?>