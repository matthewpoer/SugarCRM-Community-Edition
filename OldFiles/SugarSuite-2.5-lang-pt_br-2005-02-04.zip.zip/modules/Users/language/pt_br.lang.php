<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Usu�rios',
  'LBL_MODULE_TITLE' => 'Usu�rios: Principal',
  'LBL_SEARCH_FORM_TITLE' => 'Pesquisar Usu�rios',
  'LBL_LIST_FORM_TITLE' => 'Lista de Usu�rios',
  'LBL_NEW_FORM_TITLE' => 'Novo Usu�rio',
  'LBL_USER' => 'Usu�rio:',
  'LBL_LOGIN' => 'Login',
  'LBL_RESET_PREFERENCES' => 'Retornar para as Prefer�ncia Padr�o (Default)',
  'LBL_TIME_FORMAT' => 'Time Format:',
  'LBL_DATE_FORMAT' => 'Date Format:',
  'LBL_TIMEZONE' => 'Current Time:',
  'LBL_CURRENCY' => 'Currency:',
  'LBL_LIST_NAME' => 'Nome',
  'LBL_LIST_LAST_NAME' => 'Sobrenome',
  'LBL_LIST_USER_NAME' => 'Nome',
  'LBL_LIST_DEPARTMENT' => 'Departamento',
  'LBL_LIST_EMAIL' => 'Email',
  'LBL_LIST_PRIMARY_PHONE' => 'Fone Principal',
  'LBL_LIST_ADMIN' => 'Admin',
  'LBL_NEW_USER_BUTTON_TITLE' => 'Novo Usu�rio [Alt+N]',
  'LBL_NEW_USER_BUTTON_LABEL' => 'Novo Usu�rio',
  'LBL_NEW_USER_BUTTON_KEY' => 'N',
  'LBL_ERROR' => 'Erro:',
  'LBL_PASSWORD' => 'Senha:',
  'LBL_USER_NAME' => 'Nome do Usu�rio:',
  'LBL_FIRST_NAME' => 'Primeiro Nome:',
  'LBL_LAST_NAME' => 'Sobrenome:',
  'LBL_USER_SETTINGS' => 'Par�metros do Usu�rio',
  'LBL_THEME' => 'Tema:',
  'LBL_LANGUAGE' => 'Idioma:',
  'LBL_ADMIN' => 'Admin:',
  'LBL_USER_INFORMATION' => 'Informa��o do Usu�rio',
  'LBL_OFFICE_PHONE' => 'Fone Escrit�rio:',
  'LBL_REPORTS_TO' => 'Se Reporta a:',
  'LBL_OTHER_PHONE' => 'Outro:',
  'LBL_OTHER_EMAIL' => 'Outro Email:',
  'LBL_NOTES' => 'Notas:',
  'LBL_DEPARTMENT' => 'Departamento:',
  'LBL_STATUS' => 'Situa��o:',
  'LBL_TITLE' => 'Cargo:',
  'LBL_ANY_PHONE' => 'Fone qualquer:',
  'LBL_ANY_EMAIL' => 'Email qualquer:',
  'LBL_ADDRESS' => 'Endere�o:',
  'LBL_CITY' => 'Cidade:',
  'LBL_STATE' => 'Estado:',
  'LBL_POSTAL_CODE' => 'CEP:',
  'LBL_COUNTRY' => 'Pa�s:',
  'LBL_NAME' => 'Nome:',
  'LBL_MOBILE_PHONE' => 'Celular:',
  'LBL_OTHER' => 'Outro:',
  'LBL_FAX' => 'Fax:',
  'LBL_EMAIL' => 'Email:',
  'LBL_HOME_PHONE' => 'Fone Resid�ncia:',
  'LBL_ADDRESS_INFORMATION' => 'Informa��o de Endere�o',
  'LBL_PRIMARY_ADDRESS' => 'Endere�o Principal:',
  'LBL_CHANGE_PASSWORD_BUTTON_TITLE' => 'Alterar Senha [Alt+P]',
  'LBL_CHANGE_PASSWORD_BUTTON_KEY' => 'P',
  'LBL_CHANGE_PASSWORD_BUTTON_LABEL' => 'Alterar Senha',
  'LBL_LOGIN_BUTTON_TITLE' => 'Login [Alt+L]',
  'LBL_LOGIN_BUTTON_KEY' => 'L',
  'LBL_LOGIN_BUTTON_LABEL' => 'Login',
  'LBL_CHANGE_PASSWORD' => 'Alterar Senha',
  'LBL_OLD_PASSWORD' => 'Senha Antiga:',
  'LBL_NEW_PASSWORD' => 'Senha Nova:',
  'LBL_CONFIRM_PASSWORD' => 'Confirmar Senha:',
  'ERR_ENTER_OLD_PASSWORD' => 'Por favor informe sua senha antiga.',
  'ERR_ENTER_NEW_PASSWORD' => 'Por favor informe sua senha nova.',
  'ERR_ENTER_CONFIRMATION_PASSWORD' => 'Por favor informe sua confirma��o da senha nova.',
  'ERR_REENTER_PASSWORDS' => 'Por favor informe novamente as senhas.  A \\"senha nova\\" e \\"confirmar senha\\" n�o s�o compat�veis.',
  'ERR_INVALID_PASSWORD' => 'Voc� deve informa um usu�rio e senha v�lidos.',
  'ERR_PASSWORD_CHANGE_FAILED_1' => 'Alte��o da senha de usu�rio falhou para ',
  'ERR_PASSWORD_CHANGE_FAILED_2' => ' falhou.  A nova senha deve ser informada.',
  'ERR_PASSWORD_INCORRECT_OLD' => 'Senha antiga est� incorreta para o usu�rio $this->user_name. Informe novamente a senha.',
  'ERR_USER_NAME_EXISTS_1' => 'O nome do usu�rio ',
  'ERR_USER_NAME_EXISTS_2' => ' j� existe.  Nomes de usu�rios duplicados n�o s�o permitidos.<br>Altere o nome do usu�rio para ser �nico.',
  'ERR_LAST_ADMIN_1' => 'O nome do usu�rio ',
  'ERR_LAST_ADMIN_2' => ' � o �ltimo usu�rio Admin.  No m�nimo um usu�rio deve ser Admin.<br>Marque a op��o de usu�rio Admin.',
  'LNK_NEW_USER' => 'New User',
  'LNK_USER_LIST' => 'Users',
  'ERR_DELETE_RECORD' => 'Um n�mero de registro deve ser especificado para excluir a conta.',
  'LBL_RECEIVE_NOTIFICATIONS' => 'Assignment Notification:',
  'LBL_RECEIVE_NOTIFICATIONS_TEXT' => 'Receive an e-mail notification when a record is assigned to you.',
  'LBL_ADMIN_TEXT' => 'Grants administrator privileges to this user',
  'LBL_TIME_FORMAT_TEXT' => 'Set the display format for time stamps',
  'LBL_DATE_FORMAT_TEXT' => 'Set the display format for date stamps',
  'LBL_TIMEZONE_TEXT' => 'Set the current time',
  'LBL_GRIDLINE' => 'Show Gridlines:',
  'LBL_GRIDLINE_TEXT' => 'Controls gridlines on detail views',
  'LBL_CURRENCY_TEXT' => 'Select the default currency',
  'LBL_DISPLAY_TABS' => 'Display Tabs',
  'LBL_HIDE_TABS' => 'Hide Tabs',
  'LBL_EDIT_TABS' => 'Edit Tabs',
  'LBL_CHOOSE_WHICH' => 'Choose which tabs are displayed',
  'LBL_YAHOO_ID' => 'ID Yahoo:',
  'LNK_NEW_CONTACT' => 'Novo Contato',
  'LNK_NEW_ACCOUNT' => 'Nova Conta',
  'LNK_NEW_OPPORTUNITY' => 'Nova Oportunidade',
  'LNK_NEW_CASE' => 'Novo Caso',
  'LNK_NEW_NOTE' => 'Nova Nota',
  'LNK_NEW_CALL' => 'Nova Chamada',
  'LNK_NEW_EMAIL' => 'Novo Email',
  'LNK_NEW_MEETING' => 'Nova Reuni�o',
  'LNK_NEW_TASK' => 'Nova Tarefa',
);


?>