<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Contatos',
  'LBL_INVITEE' => 'Reporta-se a',
  'LBL_MODULE_TITLE' => 'Contatos: Principal',
  'LBL_SEARCH_FORM_TITLE' => 'Pesquisar Contatos',
  'LBL_LIST_FORM_TITLE' => 'Lista de Contatos',
  'LBL_NEW_FORM_TITLE' => 'Novo Contato',
  'LBL_CONTACT_OPP_FORM_TITLE' => 'Contato-Oportunidade:',
  'LBL_CONTACT' => 'Contato:',
  'LBL_BUSINESSCARD' => 'Business Card',
  'LBL_LIST_NAME' => 'Nome',
  'LBL_LIST_LAST_NAME' => 'Sobrenome',
  'LBL_LIST_CONTACT_NAME' => 'Nome do Contato',
  'LBL_LIST_TITLE' => 'Cargo',
  'LBL_LIST_ACCOUNT_NAME' => 'Nome da Conta',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email',
  'LBL_LIST_OTHER_EMAIL_ADDRESS' => 'Other Email',
  'LBL_LIST_PHONE' => 'Fone',
  'LBL_LIST_CONTACT_ROLE' => 'Papel',
  'LBL_LIST_FIRST_NAME' => 'First Name',
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_email2' => 'LBL_LIST_OTHER_EMAIL_ADDRESS',
  'LBL_EXISTING_CONTACT' => 'Used an existing contact',
  'LBL_CREATED_CONTACT' => 'Created a new contact',
  'LBL_EXISTING_ACCOUNT' => 'Used an existing account',
//END DON'T CONVERT
  'LBL_CREATED_ACCOUNT' => 'Created a new account',
  'LBL_CREATED_CALL' => 'Created a new call',
  'LBL_CREATED_MEETING' => 'Created a new meeting',
  'LBL_ADDMORE_BUSINESSCARD' => 'Add another business card',
  'LBL_ADD_BUSINESSCARD' => 'Create From Business Card',
  'LBL_NAME' => 'Nome:',
  'LBL_CONTACT_NAME' => 'Nome do Contato:',
  'LBL_CONTACT_INFORMATION' => 'Informa��o do Contato',
  'LBL_FIRST_NAME' => 'Nome:',
  'LBL_OFFICE_PHONE' => 'Fone Escrit�rio:',
  'LBL_ACCOUNT_NAME' => 'Nome da Conta:',
  'LBL_ANY_PHONE' => 'Fone qualquer:',
  'LBL_PHONE' => 'Fone:',
  'LBL_LAST_NAME' => 'Sobrenome:',
  'LBL_MOBILE_PHONE' => 'Celular:',
  'LBL_HOME_PHONE' => 'Home:',
  'LBL_LEAD_SOURCE' => 'Fonte:',
  'LBL_OTHER_PHONE' => 'Outro Fone:',
  'LBL_FAX_PHONE' => 'Fax:',
  'LBL_PRIMARY_ADDRESS_STREET' => 'Primary Address Street:',
  'LBL_PRIMARY_ADDRESS_CITY' => 'Primary Address City:',
  'LBL_PRIMARY_ADDRESS_COUNTRY' => 'Primary Address Country:',
  'LBL_PRIMARY_ADDRESS_STATE' => 'Primary Address State:',
  'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'Primary Address Postal Code:',
  'LBL_ALT_ADDRESS_STREET' => 'Alternate Address Street:',
  'LBL_ALT_ADDRESS_CITY' => 'Alternate Address City:',
  'LBL_ALT_ADDRESS_COUNTRY' => 'Alternate Address Country:',
  'LBL_ALT_ADDRESS_STATE' => 'Alternate Address State:',
  'LBL_ALT_ADDRESS_POSTALCODE' => 'Alternate Address Postal Code:',
  'LBL_TITLE' => 'Cargo:',
  'LBL_DEPARTMENT' => 'Departamento:',
  'LBL_BIRTHDATE' => 'Data Nascimento:',
  'LBL_EMAIL_ADDRESS' => 'Email:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Outro Email:',
  'LBL_ANY_EMAIL' => 'Email qualquer:',
  'LBL_REPORTS_TO' => 'Reporta-se a:',
  'LBL_ASSISTANT' => 'Assistente:',
  'LBL_ASSISTANT_PHONE' => 'Fone do Assistente:',
  'LBL_DO_NOT_CALL' => 'N�o Chamar:',
  'LBL_EMAIL_OPT_OUT' => 'N�o Quer Email:',
  'LBL_PRIMARY_ADDRESS' => 'Endere�o Principal:',
  'LBL_ALTERNATE_ADDRESS' => 'Endere�o Alternativo:',
  'LBL_ANY_ADDRESS' => 'Endere�o qualquer:',
  'LBL_CITY' => 'Cidade:',
  'LBL_STATE' => 'Estado:',
  'LBL_POSTAL_CODE' => 'CEP:',
  'LBL_COUNTRY' => 'Pa�s:',
  'LBL_DESCRIPTION_INFORMATION' => 'Informa��o de Descri��o',
  'LBL_ADDRESS_INFORMATION' => 'Informa��o de Endere�o',
  'LBL_DESCRIPTION' => 'Descri��o:',
  'LBL_CONTACT_ROLE' => 'Papel:',
  'LBL_OPP_NAME' => 'Nome da Oportunidade:',
  'LBL_IMPORT_VCARD' => 'Import vCard',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new contact by importing a vCard from your file system.',
  'LBL_DUPLICATE' => 'Possible Duplicate Contacts',
  'MSG_SHOW_DUPLICATES' => 'Creating this contact may potentialy create a duplicate contact. You may either click on Create Contact to continue creating this new contact with the previously entered data or you may click Cancel.',
  'MSG_DUPLICATE' => 'Creating this contact may potentialy create a duplicate contact. You may either select a contact from the list below or you may click on Create New Contact to continue creating a new contact with the previously entered data.',
  'LNK_CONTACT_LIST' => 'Contacts',
  'LNK_IMPORT_VCARD' => 'Create From vCard',
  'LNK_NEW_CONTACT' => 'Novo Contato',
  'LNK_NEW_ACCOUNT' => 'Nova Conta',
  'LNK_NEW_OPPORTUNITY' => 'Nova Oportunidade',
  'LNK_NEW_CASE' => 'Novo Caso',
  'LNK_NEW_NOTE' => 'Nova Nota',
  'LNK_NEW_CALL' => 'Nova Chamada',
  'LNK_NEW_EMAIL' => 'Novo Email',
  'LNK_NEW_MEETING' => 'Nova Reuni�o',
  'LNK_NEW_TASK' => 'Nova Tarefa',
  'LNK_NEW_APPOINTMENT' => 'Create Appointment',
  'NTC_DELETE_CONFIRMATION' => 'Tem certeza que deseja excluir este registro?',
  'NTC_REMOVE_CONFIRMATION' => 'Tem certeza que deseja remover este contato deste caso?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Tem certeza que deseja remover este registro como um reporter direto?',
  'ERR_DELETE_RECORD' => 'Um n�mero de registro deve ser especificado para excluir o contato.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Copiar endere�o principal para endere�o alternativo',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Copiar endere�o alternativo para endere�o principal',
  'LBL_SALUTATION' => 'Salutation',
  'LBL_SAVE_CONTACT' => 'Save Contact',
  'LBL_YAHOO_ID' => 'ID Yahoo!:',
);


?>