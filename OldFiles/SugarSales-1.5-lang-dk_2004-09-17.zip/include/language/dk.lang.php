<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/include/language/dk.lang.php,v 1.0.1 2004/09/29 HHN Exp $
 * Description:  Defines the Danish language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$app_strings = Array(
'LNK_ABOUT'=>'About',

'LBL_DATE_MODIFIED'=>'Sidst rettet:',
'LBL_DATE_ENTERED'=>'Oprettet:',

'LBL_BACK'=>'Tilbage',
'LBL_IMPORT'=>'Import',
'LBL_EXPORT'=>'Export',
'LBL_EXPORT_ALL'=>'Export All',

'LBL_BROWSER_TITLE'=>'SugarCRM - Commercial Open Source CRM',
'LBL_MY_ACCOUNT'=>'Min Konto',
'LBL_ADMIN'=>'Admin',
'LBL_LOGOUT'=>'Log ud',
'LBL_SEARCH'=>'S�g',
'LBL_LAST_VIEWED'=>'Seneste info',
'NTC_WELCOME'=>'Velkommen',
'NTC_SUPPORT_SUGARCRM'=>"St�t SugarCRM open source projektet med en donation via PayPal - det er hurtigt, gratis og sikkert!",
'NTC_NO_ITEMS_DISPLAY'=>'ingenting',
'LBL_ALT_HOT_KEY'=>'Alt+',

'LBL_SAVE_BUTTON_TITLE'=>'Gem [Alt+S]',
'LBL_EDIT_BUTTON_TITLE'=>'Rediger [Alt+E]',
'LBL_EDIT_BUTTON'=>'Rediger',
'LBL_DUPLICATE_BUTTON_TITLE'=>'Kopier [Alt+U]',
'LBL_DUPLICATE_BUTTON'=>'Kopier',
'LBL_DELETE_BUTTON_TITLE'=>'Slet [Alt+D]',
'LBL_DELETE_BUTTON'=>'Slet',
'LBL_NEW_BUTTON_TITLE'=>'Ny [Alt+N]',
'LBL_CHANGE_BUTTON_TITLE'=>'�ndre [Alt+G]',
'LBL_CANCEL_BUTTON_TITLE'=>'Afbryd [Alt+X]',
'LBL_SEARCH_BUTTON_TITLE'=>'S�g [Alt+Q]',
'LBL_CLEAR_BUTTON_TITLE'=>'Slet [Alt+C]',
'LBL_SELECT_BUTTON_TITLE'=>'V�lg [Alt+T]',
'LBL_SAVE_BUTTON_KEY'=>'S',
'LBL_EDIT_BUTTON_KEY'=>'E',
'LBL_DUPLICATE_BUTTON_KEY'=>'U',
'LBL_DELETE_BUTTON_KEY'=>'D',
'LBL_NEW_BUTTON_KEY'=>'N',
'LBL_CHANGE_BUTTON_KEY'=>'G',
'LBL_CANCEL_BUTTON_KEY'=>'X',
'LBL_SEARCH_BUTTON_KEY'=>'Q',
'LBL_CLEAR_BUTTON_KEY'=>'C',
'LBL_SELECT_BUTTON_KEY'=>'T',
'LBL_SAVE_BUTTON_LABEL'=>'Gem',
'LBL_EDIT_BUTTON_LABEL'=>'Rediger',
'LBL_DUPLICATE_BUTTON_LABEL'=>'Kopier',
'LBL_DELETE_BUTTON_LABEL'=>'Slet',
'LBL_NEW_BUTTON_LABEL'=>'Ny',
'LBL_CHANGE_BUTTON_LABEL'=>'�ndre',
'LBL_CANCEL_BUTTON_LABEL'=>'Afbryd',
'LBL_SEARCH_BUTTON_LABEL'=>'S�g',
'LBL_CLEAR_BUTTON_LABEL'=>'Slet',
'LBL_SELECT_BUTTON_LABEL'=>'V�lg',

'LNK_ADVANCED_SEARCH'=>'Avanceret',
'LNK_BASIC_SEARCH'=>'Enkel',
'LNK_EDIT'=>'rediger',
'LNK_REMOVE'=>'fjern',
'LNK_DELETE'=>'slet',
'LNK_LIST_START'=>'Start',
'LNK_LIST_NEXT'=>'N�ste',
'LNK_LIST_PREVIOUS'=>'Forrige',
'LNK_LIST_END'=>'Stop',
'LBL_LIST_OF'=>'af',
'LNK_PRINT'=>'Udskriv',
'LNK_HELP'=>'Hj�lp',

'NTC_REQUIRED'=>'Markerer obligatoriske felter',
'LBL_REQUIRED_SYMBOL'=>'*',
'LBL_CURRENCY_SYMBOL'=>'Kr. ',
'LBL_THOUSANDS_SYMBOL'=>'K',
'NTC_DATE_FORMAT'=>'(����-mm-dd)',
'NTC_TIME_FORMAT'=>'(24:00)',
'NTC_DATE_TIME_FORMAT'=>'(����-mm-dd 24:00)',
'NTC_DELETE_CONFIRMATION'=>'Er du sikker p� at du vil slette denne record?',
'ERR_DELETE_RECORD'=>'Et record nr kr�ves for at slette den aktuelle kontakt.',
'ERR_CREATING_TABLE'=>'Fejl ved oprettelse af tabellen: ',
'ERR_CREATING_FIELDS'=>'Fejl ved udfylning af ekstra detaljeret information: ',
'ERR_MISSING_REQUIRED_FIELDS'=>'Obligatorisk felt mangler:',
'ERR_INVALID_EMAIL_ADDRESS'=>'er inte en gyldig emailadresse.',
'ERR_INVALID_DATE_FORMAT'=>'Datoformatet skal v�re : ����-mm-dd',
'ERR_INVALID_MONTH'=>'Angiv en gyldig m�ned.',
'ERR_INVALID_DAY'=>'Angiv en gyldig dato.',
'ERR_INVALID_YEAR'=>'Angiv et gyldigt �rstal med 4 cifre.',
'ERR_INVALID_DATE'=>'Angiv en gyldig dato.',
'ERR_INVALID_HOUR'=>'Angiv en gyldig time.',
'ERR_INVALID_TIME'=>'Angiv en gyldig klokkeslet.',
'NTC_CLICK_BACK'=>'Klik p� tilbageknappen og korriger oplysningerne.',
'LBL_LIST_ASSIGNED_USER'=>'Tildelt til',
'LBL_ASSIGNED_TO'=>'Tildelt til:',
'LBL_CURRENT_USER_FILTER'=>'Vis kun de oplysninger som er tildelt til mig:',

//New strings for 1.1c.  These still need to be translated.
'LBL_SELECT_CONTACT_BUTTON_TITLE'=>'V�lg kontakt [Alt+T]',
'LBL_SELECT_CONTACT_BUTTON_KEY'=>'T',
'LBL_SELECT_CONTACT_BUTTON_LABEL'=>'V�lg kontakt',
'LBL_SELECT_USER_BUTTON_TITLE'=>'V�lg bruger [Alt+U]',
'LBL_SELECT_USER_BUTTON_KEY'=>'U',
'LBL_SELECT_USER_BUTTON_LABEL'=>'V�lg bruger',
'LBL_USER_LIST'=>'Brugerliste',
'LBL_CONTACT_LIST'=>'Kontaktliste',
'LBL_LIST_NAME'=>'Navn',
'LBL_LIST_USER_NAME'=>'Brugernavn',
'LBL_LIST_EMAIL'=>'Email',
'LBL_LIST_PHONE'=>'Tlf.',
'LBL_LIST_CONTACT_NAME'=>'Kontakt navn',
'LBL_LIST_ACCOUNT_NAME'=>'Firma navn',
'NTC_LOGIN_MESSAGE'=>"Log ind for at bruge applikationen",
'LBL_NONE'=>'--Ingen--',
'LBL_CHARSET'=>'ISO-8859-1',
);

//the left value is the key stored in the db and the right value is the display value
//to translate, only modify the right value in each key/value pair
$app_list_strings = Array(
//e.g. auf Deutsch 'Contacts'=>'Kontakter',
'moduleList' => Array('Home'=>'Forside'
				, 'Dashboard'=>'Dashboard'
				, 'Contacts'=>'Kontakter'
				, 'Accounts'=>'Firma'
				, 'Opportunities'=>'Mulige Forretninger'
				, 'Cases'=>'Sager'
				, 'Notes'=>'Noter & Attachments'
				, 'Calls'=>'Samtaler'
				, 'Emails'=>'Emails'
				, 'Meetings'=>'M�der'
				, 'Tasks'=>'Opgaver'),

//e.g. en fran�ais 'Analyst'=>'Analyste',
'account_type_dom' => Array(''=>''
		, 'Analyst'=>'Analytiker'
		, 'Integrator'=>'Integrator'
		, 'Investor'=>'Investor'
		, 'Competitor'=>'Konkurrent'
		, 'Customer'=>'Kunde'
		, 'Prospect'=>'Kundeemne'
		, 'Partner'=>'Partner'
		, 'Press'=>'Presse'
		, 'Reseller'=>'Forhandler'
		, 'Other'=>'Andet'
		),

//e.g. en espa�ol 'Apparel'=>'Ropa',
'industry_dom' => Array(''=>''
		, 'Banking'=>'Bank'
		, 'Apparel'=>'Bekl�dningsindustri'
		, 'Biotechnology'=>'Bioteknologi'
		, 'Electronics'=>'Elektronik'
		, 'Energy'=>'Energi'
		, 'Finance'=>'Finans'
		, 'Shipping'=>'Fragt'
		, 'Insurance'=>'Forsikring'
		, 'Retail'=>'Handel'
		, 'Hospitality'=>'Hotel/Restaurent'
		, 'Healthcare'=>'Helse'
		, 'Not For Profit'=>'Non profit'
		, 'Engineering'=>'Ingeni�rer'
		, 'Chemicals'=>'Kemikalie'
		, 'Communications'=>'Kommunikation'
		, 'Consulting'=>'Konsulting'
		, 'Construction'=>'Konstruktion'
		, 'Food & Beverage'=>'Levnesmiddel'
		, 'Machinery'=>'Maskinteknik'
		, 'Media'=>'Media'
		, 'Environmental'=>'Milj�'
		, 'Government'=>'Offentlig forvaltning'
		, 'Entertainment'=>'Underholdning'
		, 'Education'=>'Uddannelse'
		, 'Manufacturing'=>'Fabrik'
		, 'Technology'=>'Teknologi'
		, 'Telecommunications'=>'Telekommunikationer'
		, 'Transportation'=>'Transport'
		, 'Recreation'=>'Turisme/rejser'
		, 'Utilities'=>'V�rkt�j'
		, 'Other'=>'Andet'
		),

'lead_source_dom' => Array(''=>''
		, 'Cold Call'=>'Uintresseret'
		, 'Existing Customer'=>'Eksisterende kunde'
		, 'Self Generated'=>'Personlig'
		, 'Employee'=>'Ansat'
		, 'Partner'=>'Partner'
		, 'Public Relations'=>'Public Relations'
		, 'Direct Mail'=>'Direct Mail'
		, 'Conference'=>'Konference'
		, 'Trade Show'=>'Messe'
		, 'Web Site'=>'Webside'
		, 'Word of mouth'=>'Mundtlig'
		, 'Other'=>'Andet'
		),

'opportunity_type_dom' => Array(''=>''
		, 'Existing Business'=>'Eksisterende forretning'
		, 'New Business'=>'Ny forretning'
		),

//Note:  do not translate opportunity_relationship_type_default_key
//       it is the key for the default opportunity_relationship_type_dom value
'opportunity_relationship_type_default_key' => 'Primary Decision Maker',
'opportunity_relationship_type_dom' => Array(''=>''
		, 'Primary Decision Maker'=>'Prim�r beslutningstager'
		, 'Business Decision Maker'=>'Forretningsm�ssig beslutningstager'
		, 'Business Evaluator'=>'Forretningsm�ssig evaluator'
		, 'Technical Decision Maker'=>'Teknisk beslutningstager'
		, 'Technical Evaluator'=>'Teknisk evaluator'
		, 'Executive Sponsor'=>'Ledelse'
		, 'Influencer'=>'Person med indflydelse'
		, 'Other'=>'Andet'
		),

//Note:  do not translate case_relationship_type_default_key
//       it is the key for the default case_relationship_type_dom value
'case_relationship_type_default_key' => 'Primary Contact',
'case_relationship_type_dom' => Array(''=>''
		, 'Primary Contact'=>'Prim�r kontakt'
		, 'Alternate Contact'=>'Alternativ kontakt'
		),

'sales_stage_dom' => Array('Prospecting'=>'Prospektering'
		, 'Qualification'=>'Kvalifikation'
		, 'Needs Analysis'=>'Analyse noedvendig'
		, 'Value Proposition'=>'Foreslaa vaerdi'
		, 'Id. Decision Makers'=>'Id. beslutningstager'
		, 'Perception Analysis'=>'Analyser opfattelse'
		, 'Proposal/Price Quote'=>'Tilbud'
		, 'Negotiation/Review'=>'Forhandlinger'
		, 'Closed Won'=>'Afsluttet vundet'
		, 'Closed Lost'=>'Afsluttet tabt'
		),

'salutation_dom' => Array(''=>''
		, 'Mr.'=>'Hr'
		, 'Ms.'=>'Frk'
		, 'Mrs.'=>'Fru'
		, 'Dr.'=>'Dr.'
		, 'Prof.'=>'Prof.'
		),

'task_priority_dom' => Array('High'=>'H�j'
		, 'Medium'=>'Medium'
		, 'Low'=>'Lav'
		),

'task_status_dom' => Array('Not Started'=>'Ej p�begyndt'
		, 'In Progress'=>'Aktiv'
		, 'Completed'=>'Afsluttet'
		, 'Pending Input'=>'Venter p� oplysninger'
		, 'Deferred'=>'Udskudt'
		),

'meeting_status_dom' => Array('Planned'=>'Planlagt'
		, 'Held'=>'Gennemf�rt'
		, 'Not Held'=>'Ej gennemf�rt'
		),

'call_status_dom' => Array('Planned'=>'Planlagt'
		, 'Held'=>'Gennemf�rt'
		, 'Not Held'=>'Ej gennemf�rt'
		),

//Note:  do not translate case_status_default_key
//       it is the key for the default case_status_dom value
'case_status_default_key' => 'New',
'case_status_dom' => Array('New'=>'Ny'
		, 'Assigned'=>'Tildelt'
		, 'Closed'=>'Afsluttet'
		, 'Pending Input'=>'Venter p� oplysninger'
		, 'Rejected'=>'Afslag'
		),

'user_status_dom' => Array('Active'=>'Aktiv'
		, 'Inactive'=>'Inaktiv'
		),

//Note:  do not translate record_type_default_key
//       it is the key for the default record_type_module value
'record_type_default_key' => 'Accounts',
'record_type_display' => array('Accounts' => '*Kunde',
		'Opportunities' => '*Mulig forretning',
		'Cases' => '*Sag'),

);

?>