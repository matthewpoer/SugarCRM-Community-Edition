<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Meetings/language/dk.lang.php,v 1.0.1 2004/09/29 HHN Exp $
 * Description:  Defines the Danish language pack for the Meetings module.
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_MODULE_NAME'=>'M�der',
'LBL_MODULE_TITLE'=>'M�der : Hjem',
'LBL_SEARCH_FORM_TITLE'=>'S�g M�de',
'LBL_LIST_FORM_TITLE'=>'M�deliste',
'LBL_NEW_FORM_TITLE'=>'Aftal M�de',

'LBL_LIST_SUBJECT'=>'Vedr�rende',
'LBL_LIST_CONTACT'=>'Kontakt Navn',
'LBL_LIST_RELATED_TO'=>'Relateret til',
'LBL_LIST_DATE'=>'Start Dato',
'LBL_LIST_TIME'=>'Start Tid',

'LBL_SUBJECT'=>'Vedr�rende:',
'LBL_STATUS'=>'Status:',
'LBL_LOCATION'=>'Plads:',
'LBL_DATE_TIME'=>'Start Dato & Tid:',
'LBL_DATE'=>'Start Dato:',
'LBL_TIME'=>'Start Tid:',
'LBL_DURATION'=>'Varighed',
'LBL_HOURS_MINS'=>'(timer/minutter)',
'LBL_SUBJECT'=>'Vedr�rende: ',
'LBL_CONTACT_NAME'=>'Kontakt Navn: ',
'LBL_MEETING'=>'M�de:',
'LBL_DESCRIPTION_INFORMATION'=>'Beskrivelse',
'LBL_DESCRIPTION'=>'Beskrivelse:',
'LBL_COLON'=>':',
'LBL_DEFAULT_STATUS'=>'Planlagt',

'LNK_NEW_CONTACT'=>'Ny Kontakt',
'LNK_NEW_ACCOUNT'=>'Nyt Firma',
'LNK_NEW_OPPORTUNITY'=>'Ny Mulig Forretning',
'LNK_NEW_CASE'=>'Ny Sag',
'LNK_NEW_NOTE'=>'Ny Bem�rkning',
'LNK_NEW_CALL'=>'Ny Samtale',
'LNK_NEW_EMAIL'=>'Ny Email',
'LNK_NEW_MEETING'=>'Nyt M�de',
'LNK_NEW_TASK'=>'Ny Opgave',
'ERR_DELETE_RECORD'=>"Et Postnummer skal angives for at slette m�det.",

//New strings for 1.1c.  These still need to be translated.
'LBL_LIST_CLOSE'=>'Luk',
'NTC_REMOVE_INVITEE'=>'Er du sikker p� at du vil fjerne denne inviterede fra m�det?',
'LBL_INVITEE'=>'Inviterede',
);

?>