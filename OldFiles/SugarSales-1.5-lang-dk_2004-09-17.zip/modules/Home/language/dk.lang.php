<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Home/language/dk.lang.php,v 1.0.1 2004/09/29 HHN Exp $
 * Description:  Defines the Danish language pack for the Home module
 ********************************************************************************/

$mod_strings = Array(
'LBL_NEW_FORM_TITLE'=>'Ny Kontakt',
'LBL_FIRST_NAME'=>'Fornavn:',
'LBL_LAST_NAME'=>'Efternavn:',
'LBL_PHONE'=>'Telefon:',
'LBL_EMAIL_ADDRESS'=>'Email:',

'LBL_PIPELINE_FORM_TITLE'=>'Pipeline',

'LNK_NEW_CONTACT'=>'Ny Kontakt',
'LNK_NEW_ACCOUNT'=>'Nyt Firma',
'LNK_NEW_OPPORTUNITY'=>'Ny Mulig Forretning',
'LNK_NEW_CASE'=>'Ny Sag',
'LNK_NEW_NOTE'=>'Ny Bem�rkning',
'LNK_NEW_CALL'=>'Ny Samtale',
'LNK_NEW_EMAIL'=>'Ny Email',
'LNK_NEW_MEETING'=>'Nyt M�de',
'LNK_NEW_TASK'=>'Ny Opgave',

'ERR_ONE_CHAR'=>'Angiv mindst et bogstav eller ciffer f�r din s�gning...',

//New strings for 1.1c.  These still need to be translated.
'LBL_LIST_LAST_NAME'=>'Efternavn',
'LBL_PIPELINE_FORM_TITLE'=>'Min Pipeline',
'LBL_OPEN_TASKS'=>'Mine �bne opgaver',
);

?>