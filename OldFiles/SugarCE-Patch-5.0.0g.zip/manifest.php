<?php
// created: 2008-07-30 14:31:46
$manifest = array (
  'acceptable_sugar_flavors' => 
  array (
    0 => 'CE',
    1 => 'OS',
  ),
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '5\\.0\\.0',
    ),
  ),
  'author' => 'SugarCRM, Inc.',
  'copy_files' => 
  array (
    'from_dir' => 'SugarCE-Patch-5.0.0g',
    'to_dir' => '',
    'force_copy' => 
    array (
    ),
  ),
  'description' => '',
  'icon' => '',
  'is_uninstallable' => false,
  'offline_client_applicable' => true,
  'name' => 'SugarCE',
  'published_date' => '2008-07-30 14:31:46',
  'type' => 'patch',
  'version' => '5.0.0g',
);
?>
