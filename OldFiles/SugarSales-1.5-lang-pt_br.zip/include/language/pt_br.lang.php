<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Andre L L Dantas (alld@sourceforge) from Visuelles Informatica.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/include/language/pt_br.lang.php,v 1.00 2004/08/09 21:00:00 sugarclint Exp $
 * Description:  Defines the Portuguese (Brazilian) language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$app_strings = Array(
'LNK_ABOUT'=>'*About',

'LBL_DATE_MODIFIED'=>'*Last Modified:',
'LBL_DATE_ENTERED'=>'*Created:',

'LBL_BACK'=>'*Back',
'LBL_IMPORT'=>'*Import',
'LBL_EXPORT'=>'*Export',

'LBL_CHARSET'=>'ISO-8859-1',
'LBL_BROWSER_TITLE'=>'SugarCRM - Commercial Open Source CRM',
'LBL_MY_ACCOUNT'=>'Minha conta',
'LBL_ADMIN'=>'Admin',
'LBL_LOGOUT'=>'Logout',
'LBL_SEARCH'=>'Pesquisar',
'LBL_LAST_VIEWED'=>'�ltimos acessos',
'NTC_WELCOME'=>'Bem-vindo',
'NTC_SUPPORT_SUGARCRM'=>"Colabore com o projeto SugarCRM com uma doa��o atrav�s do PayPal - � r�pido, gr�tis e seguro!",
'NTC_NO_ITEMS_DISPLAY'=>'nada',
'LBL_ALT_HOT_KEY'=>'Alt+',

'LBL_SAVE_BUTTON_TITLE'=>'Salvar [Alt+S]',
'LBL_EDIT_BUTTON_TITLE'=>'Editar [Alt+E]',
'LBL_EDIT_BUTTON'=>'Editar',
'LBL_DUPLICATE_BUTTON_TITLE'=>'Duplicar [Alt+U]',
'LBL_DUPLICATE_BUTTON'=>'Duplicar',
'LBL_DELETE_BUTTON_TITLE'=>'Excluir [Alt+D]',
'LBL_DELETE_BUTTON'=>'Excluir',
'LBL_NEW_BUTTON_TITLE'=>'Novo [Alt+N]',
'LBL_CHANGE_BUTTON_TITLE'=>'Alterar [Alt+G]',
'LBL_CANCEL_BUTTON_TITLE'=>'Cancelar [Alt+X]',
'LBL_SEARCH_BUTTON_TITLE'=>'Pesquisar [Alt+Q]',
'LBL_CLEAR_BUTTON_TITLE'=>'Limpar [Alt+C]',
'LBL_SELECT_BUTTON_TITLE'=>'Selecionar [Alt+T]',
'LBL_SAVE_BUTTON_KEY'=>'S',
'LBL_EDIT_BUTTON_KEY'=>'E',
'LBL_DUPLICATE_BUTTON_KEY'=>'U',
'LBL_DELETE_BUTTON_KEY'=>'D',
'LBL_NEW_BUTTON_KEY'=>'N',
'LBL_CHANGE_BUTTON_KEY'=>'G',
'LBL_CANCEL_BUTTON_KEY'=>'X',
'LBL_SEARCH_BUTTON_KEY'=>'Q',
'LBL_CLEAR_BUTTON_KEY'=>'C',
'LBL_SELECT_BUTTON_KEY'=>'T',
'LBL_SAVE_BUTTON_LABEL'=>'Salvar',
'LBL_EDIT_BUTTON_LABEL'=>'Editar',
'LBL_DUPLICATE_BUTTON_LABEL'=>'Duplicar',
'LBL_DELETE_BUTTON_LABEL'=>'Excluir',
'LBL_NEW_BUTTON_LABEL'=>'Novo',
'LBL_CHANGE_BUTTON_LABEL'=>'Alterar',
'LBL_CANCEL_BUTTON_LABEL'=>'Cancelar',
'LBL_SEARCH_BUTTON_LABEL'=>'Buscar',
'LBL_CLEAR_BUTTON_LABEL'=>'Limpar',
'LBL_SELECT_BUTTON_LABEL'=>'Selecionar',
'LBL_SELECT_CONTACT_BUTTON_TITLE'=>'Selecione Contato [Alt+T]',
'LBL_SELECT_CONTACT_BUTTON_KEY'=>'T',
'LBL_SELECT_CONTACT_BUTTON_LABEL'=>'Selecione Contato',
'LBL_SELECT_USER_BUTTON_TITLE'=>'Selecione Usu�rio [Alt+U]',
'LBL_SELECT_USER_BUTTON_KEY'=>'U',
'LBL_SELECT_USER_BUTTON_LABEL'=>'Selecione Usu�rio',

'LBL_LIST_NAME'=>'Nome',
'LBL_LIST_USER_NAME'=>'Nome do Usu�rioUse',
'LBL_LIST_EMAIL'=>'Email',
'LBL_LIST_PHONE'=>'Fone',
'LBL_LIST_CONTACT_NAME'=>'Nome Contato',
'LBL_LIST_ACCOUNT_NAME'=>'Nome Conta',
'LBL_USER_LIST'=>'Lista de Usu�rio',
'LBL_CONTACT_LIST'=>'Lista de Contato',

'LNK_ADVANCED_SEARCH'=>'Avan�ada',
'LNK_BASIC_SEARCH'=>'B�sica',
'LNK_EDIT'=>'edit',
'LNK_REMOVE'=>'rem',
'LNK_DELETE'=>'exc',
'LNK_LIST_START'=>'In�cio',
'LNK_LIST_NEXT'=>'Pr�ximo',
'LNK_LIST_PREVIOUS'=>'Anterior',
'LNK_LIST_END'=>'Final',
'LBL_LIST_OF'=>'de',
'LNK_PRINT'=>'Imprimir',
'LNK_HELP'=>'Ajuda',

'NTC_REQUIRED'=>'Indica campo obrigat�rio',
'LBL_REQUIRED_SYMBOL'=>'*',
'LBL_CURRENCY_SYMBOL'=>'$',
'LBL_THOUSANDS_SYMBOL'=>'K',
'NTC_DATE_FORMAT'=>'(aaaa-mm-dd)',
'NTC_TIME_FORMAT'=>'(24:00)',
'NTC_DATE_TIME_FORMAT'=>'(aaaa-mm-dd 24:00)',
'NTC_DELETE_CONFIRMATION'=>'Tem certeza que quer excluir este registro?',
'ERR_DELETE_RECORD'=>'Um n�mero de registro precisa ser espec�ficado para excluir o contato.',
'ERR_CREATING_TABLE'=>'Erro criando tabela: ',
'ERR_CREATING_FIELDS'=>'Erro preenchendo campos de detalhe adicional: ',
'ERR_MISSING_REQUIRED_FIELDS'=>'Faltam campos obrigat�rios:',
'ERR_INVALID_EMAIL_ADDRESS'=>'n�o � um endere�o de email v�lido.',
'ERR_INVALID_DATE_FORMAT'=>'O formatdo da data deve ser: aaaa-mm-dd',
'ERR_INVALID_MONTH'=>'Por favor informe um m�s v�lido.',
'ERR_INVALID_DAY'=>'Por favor informe um dia v�lido.',
'ERR_INVALID_YEAR'=>'Por favor informe um ano v�lido (4 d�gitos).',
'ERR_INVALID_DATE'=>'Por favor informe uma data v�lida.',
'ERR_INVALID_HOUR'=>'Por favor informe uma hora v�lido.',
'ERR_INVALID_TIME'=>'Por favor informe um hor�rio v�lido.',
'NTC_CLICK_BACK'=>'Por favor clique o bot�o voltar do navegador e corrija o erro.',
'LBL_LIST_ASSIGNED_USER'=>'Designado para',
'LBL_ASSIGNED_TO'=>'Designado para:',
'LBL_CURRENT_USER_FILTER'=>'Apenas meus itens:',
'NTC_LOGIN_MESSAGE'=>"Por favor autentique-se na aplica��o.",
'LBL_NONE'=>'--Nada--',
);

//the left value is the key stored in the db and the right value is the display value
//to translate, only modify the right value in each key/value pair
$app_list_strings = Array(
//e.g. auf Deutsch 'Contacts'=>'Contakten',
'moduleList' => Array('Home'=>'Principal'
				, 'Dashboard'=>'Painel'
				, 'Contacts'=>'Contatos'
				, 'Accounts'=>'Contas'
				, 'Opportunities'=>'Oportunidades'
				, 'Cases'=>'Casos'
				, 'Notes'=>'Notes & Attachments'
				, 'Calls'=>'Chamadas'
				, 'Emails'=>'Emails'
				, 'Meetings'=>'Reuni�es'
				, 'Tasks'=>'Tarefas'),

//e.g. en fran�ais 'Analyst'=>'Analyste',
'account_type_dom' => Array(''=>''
		, 'Analyst'=>'Analista'
		, 'Competitor'=>'Competidor'
		, 'Customer'=>'Cliente'
		, 'Integrator'=>'Integrador'
		, 'Investor'=>'Investidor'
		, 'Partner'=>'Parceiro'
		, 'Press'=>'Imprenssa'
		, 'Prospect'=>'Prospecto'
		, 'Reseller'=>'Revendedor'
		, 'Other'=>'Outro'
		),

//e.g. en espa�ol 'Apparel'=>'Ropa',
'industry_dom' => Array(''=>''
		, 'Apparel'=>'T�xtil'
		, 'Banking'=>'Banco'
		, 'Biotechnology'=>'Biotecnologia'
		, 'Chemicals'=>'Qu�mica'
		, 'Communications'=>'Comunica��es'
		, 'Construction'=>'Constru��o'
		, 'Consulting'=>'Consultoria'
		, 'Education'=>'Ensino'
		, 'Electronics'=>'Eletr�nicos'
		, 'Energy'=>'Energia'
		, 'Engineering'=>'Engenharia'
		, 'Entertainment'=>'Entretenimento'
		, 'Environmental'=>'Ambiental'
		, 'Finance'=>'Financeira'
		, 'Food & Beverage'=>'Alimentos & Bebidas'
		, 'Government'=>'Governo'
		, 'Healthcare'=>'Sa�de'
		, 'Hospitality'=>'Hotelaria'
		, 'Insurance'=>'Seguros'
		, 'Machinery'=>'Maquin�rio'
		, 'Manufacturing'=>'Manufatura'
		, 'Media'=>'Meios de Comunica��o'
		, 'Not For Profit'=>'Sem Fins Lucrativos'
		, 'Recreation'=>'Recrea��o'
		, 'Retail'=>'Revenda/Varejo'
		, 'Shipping'=>'Envio'
		, 'Technology'=>'Tecnologia'
		, 'Telecommunications'=>'Telecomunica��es'
		, 'Transportation'=>'Transportes'
		, 'Utilities'=>'Servi�os P�blicos (Utilities)'
		, 'Other'=>'Outro'
		),

'lead_source_dom' => Array(''=>''
		, 'Cold Call'=>'Ativo (Cold Call)'
		, 'Existing Customer'=>'Cliente Existente'
		, 'Self Generated'=>'Auto Gerada'
		, 'Employee'=>'Empregado/Colaborador'
		, 'Partner'=>'Parceiro'
		, 'Public Relations'=>'Rela��es P�blicas'
		, 'Direct Mail'=>'Correio Direto'
		, 'Conference'=>'Confer�ncia'
		, 'Trade Show'=>'Feira/Evento'
		, 'Web Site'=>'Site Web'
		, 'Word of mouth'=>'Ouviu Falar'
		, 'Other'=>'Outro'
		),

'opportunity_type_dom' => Array(''=>''
		, 'Existing Business'=>'Neg�cios Existentes'
		, 'New Business'=>'Novos Neg�cios'
		),

//Note:  do not translate opportunity_relationship_type_default_key
//       it is the key for the default opportunity_relationship_type_dom value
'opportunity_relationship_type_default_key' => 'Primary Decision Maker',
'opportunity_relationship_type_dom' => Array(''=>''
		, 'Primary Decision Maker'=>'Decisor Principal'
		, 'Business Decision Maker'=>'Decisor de Neg�cios'
		, 'Business Evaluator'=>'Avaliador de Neg�cios'
		, 'Technical Decision Maker'=>'Decisor T�cnico'
		, 'Technical Evaluator'=>'Avaliador T�cnico'
		, 'Executive Sponsor'=>'Patrocinador Executivo'
		, 'Influencer'=>'Influenciador'
		, 'Other'=>'Outro'
		),

//Note:  do not translate case_relationship_type_default_key
//       it is the key for the default case_relationship_type_dom value
'case_relationship_type_default_key' => 'Primary Contact',
'case_relationship_type_dom' => Array(''=>''
		, 'Primary Contact'=>'Contato Principal'
		, 'Alternate Contact'=>'Contato Alternativo'
		),

'sales_stage_dom' => Array('Prospecting'=>'Prospec��o'
		, 'Qualification'=>'Qualifica��o'
		, 'Needs Analysis'=>'An�lise de Necessidades'
		, 'Value Proposition'=>'Proposi��o de Valor'
		, 'Id. Decision Makers'=>'Id. Decisores'
		, 'Perception Analysis'=>'An�lise da Percep��o'
		, 'Proposal/Price Quote'=>'Cota��o Proposta/Pre�o'
		, 'Negotiation/Review'=>'Negocia��o/Revis�o'
		, 'Closed Won'=>'Ganhamos'
		, 'Closed Lost'=>'Perdemos'
		),

'salutation_dom' => Array(''=>''
		, 'Mr.'=>'Sr.'
		, 'Ms.'=>'Srta.'
		, 'Mrs.'=>'Sra.'
		, 'Dr.'=>'Dr.'
		, 'Prof.'=>'Prof.'
		),

'task_priority_dom' => Array('High'=>'Alta'
		, 'Medium'=>'M�dia'
		, 'Low'=>'Baixa'
		),

'task_status_dom' => Array('Not Started'=>'N�o Iniciada'
		, 'In Progress'=>'Em Progresso'
		, 'Completed'=>'Terminada'
		, 'Pending Input'=>'Informa��o Pendente'
		, 'Deferred'=>'Adiada'
		),

'meeting_status_dom' => Array('Planned'=>'Planejada'
		, 'Held'=>'Realizada'
		, 'Not Held'=>'N�o Realizada'
		),

'call_status_dom' => Array('Planned'=>'Planejada'
		, 'Held'=>'Realizada'
		, 'Not Held'=>'N�o Realizada'
		),

//Note:  do not translate case_status_default_key
//       it is the key for the default case_status_dom value
'case_status_default_key' => 'New',
'case_status_dom' => Array('New'=>'Novo'
		, 'Assigned'=>'Designado'
		, 'Closed'=>'Encerrado'
		, 'Pending Input'=>'Informa��o Pendente'
		, 'Rejected'=>'Rejeitado'
		),

'user_status_dom' => Array('Active'=>'Ativo'
		, 'Inactive'=>'Inativo'
		),

//Note:  do not translate record_type_default_key
//       it is the key for the default record_type_module value
'record_type_default_key' => 'Accounts',
'record_type_display' => array('Accounts' => '*Account',
		'Opportunities' => '*Opportunity',
		'Cases' => '*Case'),
);

?>
