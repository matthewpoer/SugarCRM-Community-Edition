<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Andre L L Dantas (alld@sourceforge) from Visuelles Informatica.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Activities/language/pt_br.lang.php,v 1.00 2004/08/09 21:00:00 sugarclint Exp $
 * Description:  Defines the Portuguese (Brazilian) language pack for the Activity module.
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_OPEN_ACTIVITIES'=>'Atividades Abertas',
'LBL_HISTORY'=>'Hist�rico',
'LBL_UPCOMING'=>"Pr�ximas Atividades",
'LBL_TODAY'=>'at� ',

'LBL_NEW_TASK_BUTTON_TITLE'=>'Nova Tarefa [Alt+N]',
'LBL_NEW_TASK_BUTTON_KEY'=>'N',
'LBL_NEW_TASK_BUTTON_LABEL'=>'Nova Tarefa',
'LBL_SCHEDULE_MEETING_BUTTON_TITLE'=>'Agendar Reuni�o [Alt+M]',
'LBL_SCHEDULE_MEETING_BUTTON_KEY'=>'M',
'LBL_SCHEDULE_MEETING_BUTTON_LABEL'=>'Agendar Reuni�o',
'LBL_SCHEDULE_CALL_BUTTON_TITLE'=>'Agendar Chamada [Alt+C]',
'LBL_SCHEDULE_CALL_BUTTON_KEY'=>'C',
'LBL_SCHEDULE_CALL_BUTTON_LABEL'=>'Agendar Chamada',
'LBL_NEW_NOTE_BUTTON_TITLE'=>'Nova Noto [Alt+T]',
'LBL_NEW_NOTE_BUTTON_KEY'=>'T',
'LBL_NEW_NOTE_BUTTON_LABEL'=>'Nova Nota',
'LBL_TRACK_EMAIL_BUTTON_TITLE'=>'Acompanhar Email [Alt+K]',
'LBL_TRACK_EMAIL_BUTTON_KEY'=>'K',
'LBL_TRACK_EMAIL_BUTTON_LABEL'=>'Acompanhar Email',

'LBL_LIST_CLOSE'=>'Fechar',
'LBL_LIST_STATUS'=>'Situa��o',
'LBL_LIST_CONTACT'=>'Contato',
'LBL_LIST_RELATED_TO'=>'Relacionado a',
'LBL_LIST_DUE_DATE'=>'Data Devida',
'LBL_LIST_DATE'=>'Data',
'LBL_LIST_SUBJECT'=>'Assunto',
'LBL_LIST_LAST_MODIFIED'=>'�ltima Modificada',

'LNK_NEW_CONTACT'=>'Novo Contato',
'LNK_NEW_ACCOUNT'=>'Nova Conta',
'LNK_NEW_OPPORTUNITY'=>'Nova Oportunidade',
'LNK_NEW_CASE'=>'Novo Caso',
'LNK_NEW_NOTE'=>'Nova Nota',
'LNK_NEW_CALL'=>'Nova Chamada',
'LNK_NEW_EMAIL'=>'Novo Email',
'LNK_NEW_MEETING'=>'Nova Reuni�o',
'LNK_NEW_TASK'=>'Nova Tarefa',
'ERR_DELETE_RECORD'=>"Um n�mero de registro deve ser especificado para excluir a tarefa.",
'NTC_NONE_SCHEDULED'=>'Nada agendado.',
);

?>
