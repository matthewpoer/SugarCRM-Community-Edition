<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Andre L L Dantas (alld@sourceforge) from Visuelles Informatica.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Tasks/language/pt_br.lang.php,v 1.00 2004/08/09 21:00:00 sugarclint Exp $
 * Description:  Defines the Portuguese (Brazilian) language pack for Task module.
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_MODULE_NAME'=>'Tarefas',
'LBL_TASK'=>'Tarefas: ',
'LBL_MODULE_TITLE'=>' Tarefas: Principal',
'LBL_SEARCH_FORM_TITLE'=>' Pesquisar Tarefas',
'LBL_LIST_FORM_TITLE'=>' Lista de Tarefas',
'LBL_NEW_FORM_TITLE'=>' Nova Tarefa',

'LBL_NEW_FORM_SUBJECT'=>'Assunto:',
'LBL_NEW_FORM_DUE_DATE'=>'Data Devida:',
'LBL_NEW_FORM_DUE_TIME'=>'Hora Devida:',
'LBL_NEW_TIME_FORMAT'=>'(24:00)',

'LBL_LIST_CLOSE'=>'Encerrar',
'LBL_LIST_SUBJECT'=>'Assunto',
'LBL_LIST_CONTACT'=>'Contato',
'LBL_LIST_RELATED_TO'=>'Relacionada a',
'LBL_LIST_DUE_DATE'=>'Data Devida',
'LBL_LIST_DUE_TIME'=>'Hora Devida',

'LBL_SUBJECT'=>'Assunto:',
'LBL_STATUS'=>'Situa��o:',
'LBL_DUE_DATE'=>'Data Devida:',
'LBL_PRIORITY'=>'Prioridade:',
'LBL_COLON'=>':',
'LBL_DUE_DATE_AND_TIME'=>'Data & Hora Devidas:',
'DATE_FORMAT'=>'(aaaa-mm-dd 24:00)',
'LBL_NONE'=>'nada',
'LBL_PRIORITY'=>'Prioridade:',
'LBL_CONTACT'=>'Contato:',
'LBL_PHONE'=>'Fone:',
'LBL_EMAIL'=>'Email:',
'LBL_DESCRIPTION_INFORMATION'=>'Informa��o de Descri��o',
'LBL_DESCRIPTION'=>'Descri��o:',
'LBL_NAME'=>'Nome:',
'LBL_CONTACT_NAME'=>'Nome do Contato: ',
'LBL_LIST_COMPLETE'=>'Completar:',
'LBL_LIST_STATUS'=>'Situa��o:',
'ERR_DELETE_RECORD'=>'Um n�mero de registro deve ser especificado para excluir a tarefa.',
'ERR_INVALID_HOUR'=>'Por favor informe uma hora entre 00:00 e 24:00',
'LBL_DEFAULT_STATUS'=>'N�o Iniciada',
'LBL_DEFAULT_PRIORITY'=>'M�dio',

'LNK_NEW_CONTACT'=>'Novo Contato',
'LNK_NEW_ACCOUNT'=>'Nova Conta',
'LNK_NEW_OPPORTUNITY'=>'Nova Oportunidade',
'LNK_NEW_CASE'=>'Novo Caso',
'LNK_NEW_NOTE'=>'Nova Nota',
'LNK_NEW_CALL'=>'Nova Chamada',
'LNK_NEW_EMAIL'=>'Novo Email',
'LNK_NEW_MEETING'=>'Nova Reuni�o',
'LNK_NEW_TASK'=>'Nova Tarefa',

);

?>