<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.2 2004/10/29 15:59:25 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Activities',
  'LBL_MODULE_TITLE' => 'Activities: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Activities Search',
  'LBL_LIST_FORM_TITLE' => 'Activities List',
  'LBL_LIST_SUBJECT' => '主題',
  'LBL_LIST_CONTACT' => '聯絡人',
  'LBL_LIST_RELATED_TO' => '相關',
  'LBL_LIST_DATE' => '日期',
  'LBL_LIST_TIME' => 'Start Time',
  'LBL_LIST_CLOSE' => '結束',
  'LBL_SUBJECT' => 'Subject:',
  'LBL_STATUS' => 'Status:',
  'LBL_LOCATION' => 'Location:',
  'LBL_DATE_TIME' => 'Start Date & Time:',
  'LBL_DATE' => 'Start Date:',
  'LBL_TIME' => 'Start Time:',
  'LBL_DURATION' => 'Duration:',
  'LBL_HOURS_MINS' => '(hours/minutes)',
  'LBL_CONTACT_NAME' => 'Contact Name: ',
  'LBL_MEETING' => 'Meeting:',
  'LBL_DESCRIPTION_INFORMATION' => 'Description Information',
  'LBL_DESCRIPTION' => 'Description:',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'Planned',
  'LNK_NEW_CALL' => '新增電話記錄',
  'LNK_NEW_MEETING' => '新增會議',
  'LNK_NEW_TASK' => '新增任務',
  'LNK_NEW_NOTE' => '新增備註',
  'LNK_NEW_EMAIL' => '新增電子郵件',
  'LNK_CALL_LIST' => 'Calls',
  'LNK_MEETING_LIST' => 'Meetings',
  'LNK_TASK_LIST' => 'Tasks',
  'LNK_NOTE_LIST' => 'Notes',
  'LNK_EMAIL_LIST' => 'Emails',
  'ERR_DELETE_RECORD' => '必須指定記錄編號才能刪除公司.',
  'NTC_REMOVE_INVITEE' => 'Are you sure you want to remove this invitee from the meeting?',
  'LBL_INVITEE' => 'Invitees',
  'LBL_LIST_DIRECTION' => 'Direction',
  'LBL_DIRECTION' => 'Direction',
  'LNK_NEW_APPOINTMENT' => 'New Appointment',
  'LNK_VIEW_CALENDAR' => 'Today',
  'LBL_OPEN_ACTIVITIES' => '在做的活動',
  'LBL_HISTORY' => '歷史記錄',
  'LBL_UPCOMING' => '最近安排',
  'LBL_TODAY' => '顯示到時間 ',
  'LBL_NEW_TASK_BUTTON_TITLE' => '新增任務 [Alt+N]',
  'LBL_NEW_TASK_BUTTON_KEY' => 'N',
  'LBL_NEW_TASK_BUTTON_LABEL' => '新增任務',
  'LBL_SCHEDULE_MEETING_BUTTON_TITLE' => '安排會議 [Alt+M]',
  'LBL_SCHEDULE_MEETING_BUTTON_KEY' => 'M',
  'LBL_SCHEDULE_MEETING_BUTTON_LABEL' => '安排會議',
  'LBL_SCHEDULE_CALL_BUTTON_TITLE' => '安排電話 [Alt+C]',
  'LBL_SCHEDULE_CALL_BUTTON_KEY' => 'C',
  'LBL_SCHEDULE_CALL_BUTTON_LABEL' => '安排電話',
  'LBL_NEW_NOTE_BUTTON_TITLE' => '新增備註 [Alt+T]',
  'LBL_NEW_NOTE_BUTTON_KEY' => 'T',
  'LBL_NEW_NOTE_BUTTON_LABEL' => '新增備註',
  'LBL_TRACK_EMAIL_BUTTON_TITLE' => '撰寫郵件 [Alt+K]',
  'LBL_TRACK_EMAIL_BUTTON_KEY' => 'K',
  'LBL_TRACK_EMAIL_BUTTON_LABEL' => '撰寫郵件',
  'LBL_LIST_STATUS' => '狀態',
  'LBL_LIST_DUE_DATE' => '到期',
  'LBL_LIST_LAST_MODIFIED' => '最新修改',
  'NTC_NONE_SCHEDULED' => '沒有安排.',
  'LNK_NEW_CONTACT' => '新增聯絡人',
  'LNK_NEW_ACCOUNT' => '新增公司',
  'LNK_NEW_OPPORTUNITY' => '新增機會',
  'LNK_NEW_CASE' => '新增事件',
);


?>