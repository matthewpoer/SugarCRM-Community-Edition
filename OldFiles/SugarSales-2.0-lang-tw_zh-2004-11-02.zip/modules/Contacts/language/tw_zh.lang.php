<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.2 2004/10/29 15:59:25 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => '聯絡人',
  'LBL_INVITEE' => '*Direct Reports',
  'LBL_MODULE_TITLE' => '聯絡人: 首頁',
  'LBL_SEARCH_FORM_TITLE' => '搜尋聯絡人',
  'LBL_LIST_FORM_TITLE' => '聯絡人列表',
  'LBL_NEW_FORM_TITLE' => '新增聯絡人',
  'LBL_CONTACT_OPP_FORM_TITLE' => '聯絡人-機會：',
  'LBL_CONTACT' => '聯絡人：',
  'LBL_BUSINESSCARD' => 'Business Card',
  'LBL_LIST_NAME' => '姓名',
  'LBL_LIST_LAST_NAME' => '名',
  'LBL_LIST_CONTACT_NAME' => '聯絡姓名',
  'LBL_LIST_TITLE' => '職務',
  'LBL_LIST_ACCOUNT_NAME' => '公司名稱',
  'LBL_LIST_EMAIL_ADDRESS' => '電子郵件',
  'LBL_LIST_OTHER_EMAIL_ADDRESS' => 'Other Email',
  'LBL_LIST_PHONE' => '電話',
  'LBL_LIST_CONTACT_ROLE' => '角色',
  'LBL_LIST_FIRST_NAME' => 'First Name',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_email2' => 'LBL_LIST_OTHER_EMAIL_ADDRESS',
//END DON'T CONVERT
  'LBL_EXISTING_CONTACT' => 'Used an existing contact',
  'LBL_CREATED_CONTACT' => 'Created a new contact',
  'LBL_EXISTING_ACCOUNT' => 'Used an existing account',
  'LBL_CREATED_ACCOUNT' => 'Created a new account',
  'LBL_CREATED_CALL' => 'Created a new call',
  'LBL_CREATED_MEETING' => 'Created a new meeting',
  'LBL_ADDMORE_BUSINESSCARD' => 'Add another business card',
  'LBL_ADD_BUSINESSCARD' => 'Create From Business Card',
  'LBL_NAME' => '姓名：',
  'LBL_CONTACT_NAME' => '聯絡姓名：',
  'LBL_CONTACT_INFORMATION' => '聯絡資訊',
  'LBL_FIRST_NAME' => '姓：',
  'LBL_OFFICE_PHONE' => '辦公電話：',
  'LBL_ACCOUNT_NAME' => '公司名稱：',
  'LBL_ANY_PHONE' => '任意電話：',
  'LBL_PHONE' => '電話：',
  'LBL_LAST_NAME' => '名：',
  'LBL_MOBILE_PHONE' => '移動電話：',
  'LBL_HOME_PHONE' => '家：',
  'LBL_LEAD_SOURCE' => '接觸來源：',
  'LBL_OTHER_PHONE' => '其它電話：',
  'LBL_FAX_PHONE' => '傳真：',
  'LBL_TITLE' => '職務：',
  'LBL_DEPARTMENT' => '部門：',
  'LBL_BIRTHDATE' => '生日：',
  'LBL_EMAIL_ADDRESS' => '電子郵件：',
  'LBL_OTHER_EMAIL_ADDRESS' => '其它電子郵件：',
  'LBL_ANY_EMAIL' => '任意電子郵件：',
  'LBL_REPORTS_TO' => '匯報給：',
  'LBL_ASSISTANT' => '輔助：',
  'LBL_ASSISTANT_PHONE' => '輔助電話：',
  'LBL_DO_NOT_CALL' => '不能呼叫：',
  'LBL_EMAIL_OPT_OUT' => '另發的 Email：',
  'LBL_PRIMARY_ADDRESS' => '主地址：',
  'LBL_ALTERNATE_ADDRESS' => '其它地址：',
  'LBL_ANY_ADDRESS' => '任意地址：',
  'LBL_CITY' => '城市：',
  'LBL_STATE' => '省份：',
  'LBL_POSTAL_CODE' => '郵遞區號：',
  'LBL_COUNTRY' => '國家：',
  'LBL_DESCRIPTION_INFORMATION' => '描述資訊',
  'LBL_ADDRESS_INFORMATION' => '*Address Information',
  'LBL_DESCRIPTION' => '描述：',
  'LBL_CONTACT_ROLE' => '角色：',
  'LBL_OPP_NAME' => '機會名稱：',
  'LBL_IMPORT_VCARD' => 'Import vCard',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new contact by importing a vCard from your file system.',
  'LBL_DUPLICATE' => 'Possible Duplicate Contacts',
  'MSG_DUPLICATE' => 'Creating this contact may potentialy create a duplicate contact. You may either select a contact from the list below or you may click on Create New Contact to continue creating a new contact with the previously entered data.',
  'LNK_CONTACT_LIST' => 'Contacts',
  'LNK_IMPORT_VCARD' => 'Create From vCard',
  'LNK_NEW_CONTACT' => '新增聯絡人',
  'LNK_NEW_ACCOUNT' => '新增公司',
  'LNK_NEW_OPPORTUNITY' => '新增機會',
  'LNK_NEW_CASE' => '新增事件',
  'LNK_NEW_NOTE' => '新增備註',
  'LNK_NEW_CALL' => '新增電話記錄',
  'LNK_NEW_EMAIL' => '新增電子郵件',
  'LNK_NEW_MEETING' => '新增會議',
  'LNK_NEW_TASK' => '新增任務',
  'LNK_NEW_APPOINTMENT' => 'Create Appointment',
  'NTC_DELETE_CONFIRMATION' => '你確定要刪除這個記錄?',
  'NTC_REMOVE_CONFIRMATION' => '你確定要將聯絡人從這個事件中刪除嗎?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => '你確定要將此記錄從直接報告人處刪除嗎?',
  'ERR_DELETE_RECORD' => '必須指定記錄編號才能刪除公司.',
  'NTC_COPY_PRIMARY_ADDRESS' => '將主地址內容複製到備用地址',
  'NTC_COPY_ALTERNATE_ADDRESS' => '將備用地址複製到主地址',
  'LBL_SALUTATION' => 'Salutation',
  'LBL_YAHOO_ID' => 'Yahoo! ID：',
);


?>