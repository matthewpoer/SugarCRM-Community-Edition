<?PHP
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

// $Id: upgradesql.php,v 1.12 2005/01/25 02:54:21 andrew Exp $
/*
	require_once('modules/Administration/Administration.php');
	$administration = new Administration();
	$administration->retrieveSettings('info');
	if(!isset($administration->settings) || !isset($administration->settings['info_sugar_version'])){
	echo $mod_strings['LBL_UPGRADE_DB_BEGIN'].'<br>';
	$filename = 'modules/Administration/UpgradeSQL/2.0.x_to_2.5.sql';
	$handle = fopen($filename,'r');
	$contents = fread($handle, filesize($filename));
	fclose($handle);
	require_once('include/database/PearDatabase.php');
	$lastsemi = strrpos($contents,';') ;
	$contents = substr($contents, 0, $lastsemi);
	$queries = split(';', $contents);
	$db = new PearDatabase();
	foreach($queries as $query){
		if(!empty($query)){
			echo $query.';<br>';
			$db->query($query.';', true, $mod_strings['LBL_UPGRADE_DB_FAIL'].'<br>');
		}
	}
}
	echo $mod_strings['LBL_UPGRADE_DB_COMPLETE'].'<br>';
*/
?>
