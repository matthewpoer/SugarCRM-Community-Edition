<?php
	// $Id: sugar_version.php,v 1.31.2.1 2005/03/04 23:06:14 andrew Exp $
	$sugar_version = '2.5.1a';
?>
