<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: javascript.php,v 1.13 2005/02/25 02:39:19 julian Exp $
 * Description:  Creates the runtime database connection.
 ********************************************************************************/
class javascript{
	var $formname = 'form';
	var $script = "<script>\n";
	var $sugarbean = null;
	function setFormName($name){
		$this->formname = $name;
	}

	function javascript(){
		global $app_strings;
		$this->script .= "requiredTxt = '{$app_strings['ERR_MISSING_REQUIRED_FIELDS']}';\n";

	}
	function setSugarBean(&$sugar){
		$this->sugarbean = $sugar;
	}

	function addRequiredFields($prefix=''){
			if(isset($this->sugarbean->required_fields)){
				foreach($this->sugarbean->required_fields as $field=>$value){
					$this->addField($field,'true', $prefix);
				}
			}
	}


	function addField($field,$required, $prefix=''){
		if(empty($required)){
			if(isset($this->sugarbean->required_fields[$field])){
					$required = 'true';
			}else $required = 'false';
		}
		$this->addFieldGeneric($field,$this->sugarbean->field_name_map[$field]['type'],$this->sugarbean->field_name_map[$field]['vname'],$required,$prefix );


	}

	function addFieldGeneric($field, $type,$displayName, $required, $prefix=''){
		$this->script .= "addToValidate('".$this->formname."', '".$prefix.$field."', '".$type . "', $required,'".translate($displayName) . "' );\n";
	}

	function addAllFields($prefix){
		foreach($this->sugarbean->field_name_map as $field=>$value){
			if(isset($this->sugarbean->required_fields[$field])){
					$required = 'true';
			}else $required = 'false';
			$this->addField($field, $required, $prefix);
		}
	}

	function getScript(){
		return $this->script . "</script>";
	}






}
?>
