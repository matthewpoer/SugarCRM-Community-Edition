<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * 
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and 
 * (ii) the SugarCRM copyright notice 
 * in the same form as they appear in the distribution.  See full license for requirements.
 * 
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/sugarcrm/install/3confirmConfig.php,v 1.21 2004/10/24 20:06:42 clint Exp $
 * Description:  Executes a step in the installation process.
 ********************************************************************************/

if (isset($_REQUEST['db_host_name'])) $db_host_name 	= $_REQUEST['db_host_name'];
if (isset($_REQUEST['db_user_name'])) $db_user_name 	= $_REQUEST['db_user_name'];
if (isset($_REQUEST['db_password'])) $db_password 		= $_REQUEST['db_password'];
if (isset($_REQUEST['db_name'])) $db_name  				= $_REQUEST['db_name'];
if (isset($_REQUEST['db_drop_tables'])) $db_drop_tables = $_REQUEST['db_drop_tables'];
if (isset($_REQUEST['site_URL'])) $site_URL 			= $_REQUEST['site_URL'];
if (isset($_REQUEST['admin_email'])) $admin_email 		= $_REQUEST['admin_email'];
if (isset($_REQUEST['admin_password'])) $admin_password = $_REQUEST['admin_password'];
if (isset($_REQUEST['cache_dir'])) $cache_dir           = $_REQUEST['cache_dir'];
if (isset($_REQUEST['root_directory'])) $root_directory = $_REQUEST['root_directory']; 

?>
<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * 
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and 
 * (ii) the SugarCRM copyright notice 
 * in the same form as they appear in the distribution.  See full license for requirements.
 * 
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/sugarcrm/install/3confirmConfig.php,v 1.21 2004/10/24 20:06:42 clint Exp $
 * Description:  Executes a step in the installation process.
 ********************************************************************************/

//get php configuration settings.  requires elaborate parsing of phpinfo() output
ob_start();
phpinfo(INFO_GENERAL);    
$string = ob_get_contents();
ob_end_clean();    

$pieces = explode("<h2", $string);
$settings = array();
foreach($pieces as $val)
{
   preg_match("/<a name=\"module_([^<>]*)\">/", $val, $sub_key);
   preg_match_all("/<tr[^>]*>
									   <td[^>]*>(.*)<\/td>
									   <td[^>]*>(.*)<\/td>/Ux", $val, $sub);
   preg_match_all("/<tr[^>]*>
									   <td[^>]*>(.*)<\/td>
									   <td[^>]*>(.*)<\/td>
									   <td[^>]*>(.*)<\/td>/Ux", $val, $sub_ext);
   foreach($sub[0] as $key => $val) {
		if (preg_match("/Configuration File \(php.ini\) Path /", $val)) { 
	   		$val = preg_replace("/Configuration File \(php.ini\) Path /", '', $val);
			$phpini = strip_tags($val);
	   	}
   }
   
}
?> 
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Sugar Sales Setup Wizard: Step 3</title>
<link rel="stylesheet" href="install/install.css" type="text/css" />
</head>
<body>
<table cellspacing="0" cellpadding="0" border="0" align="center" class="shell">
<tr>
    <th width="400">Step 3: Confirm System Configuration</th>
	<th width="200"><a href="http://www.sugarcrm.com" target="_blank"><img src="include/images/sugarcrm_logo.gif" alt="" width="150" height="29" border="0" align="right"></a></th>
</tr>
<tr>
    <td colspan="2" width="600">	
<p>Please review the configuration information below...</p>

<table width="100%" cellpadding="0" cellspacing="0" border="0" class="StyleDottedHr">
              <tr>
  			   <th colspan="2"  >Database Configuration</th>
              </tr>
			  <tr>
               <td><b>Host Name</b></td>
               <td align="left" >: <?php if (isset($db_host_name)) echo "$db_host_name"; ?></td>
              </tr>
              <tr>
               <td><b>MySQL User Name</b></td>
               <td align="left" >: <?php if (isset($db_user_name)) echo "$db_user_name"; ?></td>
              </tr>
              <tr>
               <td ><b>MySQL Password</b></td>
               <td align="left" >: <?php if (isset($db_password)) echo ereg_replace('.', '*', $db_password); ?></td>
              </tr>
              <tr>
               <td ><b>MySQL Database Name</b></td>
               <td align="left" >: <?php if (isset($db_name)) echo "$db_name"; ?></td>
              </tr>
              <tr>
               <td ><b>Drop Existing Tables</b></td>
               <td align="left" >: 
			   <?php if (isset($db_drop_tables) && $db_drop_tables == true) echo "True"; else echo "False"; ?>
				</td>
			  </tr>

			  <tr>
  			   <th colspan="2"  >Site Configuration</th>
              </tr>
              <tr>
               <td ><b>URL</b></td>
               <td align="left" >: <?php if (isset($site_URL)) echo $site_URL; ?></td>
              </tr>
              <tr>
               <td ><b>Path</b></td>
               <td align="left" >: <?php if (isset($root_directory)) echo $root_directory; ?></td>
              </tr>
              <tr>
               <td ><b>Cache Path</b></td>
               <td align="left" >: <?php if (isset($cache_dir)) echo $root_directory.'\\'.$cache_dir; ?></td>
              </tr>
              <tr>
               <td ><b>Admin Password</b></td>
               <td align="left" >: <?php if (isset($admin_password)) echo ereg_replace('.', '*', $admin_password); ?></td>
              </tr>
              <tr>
               <td ><b>Admin Email Address</b></td>
               <td align="left" >: <?php if (isset($admin_email)) echo $admin_email; ?></td>
              </tr>

    	      
			</table>

		    			<form action="install.php" method="post" name="form" id="form">
			<input type="hidden" name="file" value="4createConfigFile.php">
<!-- TODO Clint 4/28 - Add support for creating the database as well -->
<!--			 Also create database <?php if (isset($db_name)) echo "$db_name"; ?>? -->
<!--			 <input type="checkbox" class="dataInput" name="db_create" value="1" /> -->
			 <p align="right"><b>Also populate demo data?</b>  <input type="checkbox" class="checkbox"  name="db_populate" value="1"></p>

 <input type="hidden"  name="db_host_name" value="<?php if (isset($db_host_name)) echo "$db_host_name"; ?>" />
             <input type="hidden"  name="db_user_name" value="<?php if (isset($db_user_name)) echo "$db_user_name"; ?>" />
             <input type="hidden"  name="db_password" value="<?php if (isset($db_password)) echo "$db_password"; ?>" />
             <input type="hidden"  name="db_name" value="<?php if (isset($db_name)) echo "$db_name"; ?>" />
             <input type="hidden"  name="db_drop_tables" value="<?php if (isset($db_drop_tables)) echo "$db_drop_tables"; ?>" />
             <input type="hidden"  name="site_URL" value="<?php if (isset($site_URL)) echo "$site_URL"; ?>" />
             <input type="hidden"  name="root_directory" value="<?php if (isset($root_directory)) echo "$root_directory"; ?>" />
             <input type="hidden"  name="admin_email" value="<?php if (isset($admin_email)) echo "$admin_email"; ?>" />
             <input type="hidden"  name="admin_password" value="<?php if (isset($admin_password)) echo "$admin_password"; ?>" />
			 <input type="hidden"  name="cache_dir" value="<?php if (isset($cache_dir)) echo $cache_dir; ?>" />


	</td>
</tr>
<tr>
	<td align="right" colspan="2">
	<hr>
	<table cellspacing="0" cellpadding="0" border="0" class="stdTable">
		<tr>
		    <td><input class="button" type="button" name="cancel" value="Cancel"  onclick="window.close();"/>&nbsp;&nbsp;&nbsp;&nbsp;<input class="button" type="button" name="back" value="Back"  onclick="history.back()"/></td><td><input class="button" type="submit" name="next" value="Next" />
				</form></td>
		</tr>
	</table>
	</td>
</tr>
</table>

<br>

</body>
</html>




