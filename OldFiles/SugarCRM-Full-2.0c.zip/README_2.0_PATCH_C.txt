Sugar Sales v2.0 Patch C
November 2, 2004

-=Upgrade Steps=-
To upgrade from Sugar Sales v2.0:
1. Copy the files in this directory to your Sugar Sales web root
2. Login to the application as an admin user
3. Click "Admin" in the top right to go to the admin console
4. Click Upgrade
5. Click Upgrade Teams

You have now successfully upgraded to Sugar Sales v2.0 Patch C

Enjoy!
The Sugar Team


-=Fixes=-
This patch includes the following reported bugs as well as other fixes.  
For further details on these reported issues, please see:
http://sourceforge.net/tracker/?group_id=107819&atid=648812

1055962 No line breaks in "Description" field (DetailView)     
1055679 Contacts DetailView e-mail fields (mailto: blank or missing)   
1055631 Default config settings not loaded if User table exists
1054733 Leads designation error
1054560 Problem with Currency Calculation on Dashboard and Home
1054408 Mashed screen displays 
1054392 Meeting assignments wrong on home page 
1053370 JS error in Import Step 2      
1053367 JS error in Import     
1050210 SQL error when attempting to select contact from opportunity   
1048080 html_entity_decode() undefined in < PHP 4.3    
1047454 set_focus error
1047429 Accounts with a single quote display &quot in app      
1047394 $site_URL used in file.php     
1047393 Error in Contacts Import       
1047371 Fix popups where passed in account name has a single quote     
1046333 Cyrillic windows-1251 is also garbaged 
1044542 Non ISO-8859-1 data displayed as garbage since 1.5c    
1041914 Downloads don't work over SSL  
1041348 Amount label of opportunity edit view not translated   
1041342 << Back link of print view erroneous   
1041338 Account: can be assigned an previously assigned opportunity    
1041337 Meetings Close column header name - Missing translation
1041332 HTML escaping not in graph labels      
1041029 Some terms not translated in Status column     
1041024 Intl. characters displayed incorrectly from popup selector     
1041015 Entering ' into popup search field causes SQL error    
1040871 Call duration incorrectly displayed    
1040401 Missing file in full 1.5d release (zip file)   
1038460 Last Viewed    
1038436 Apostrophe in accounts' name   
1037889 Account link   
1037632 Mailto links not created       
1036839 Business Card Entry should add items to tracker
1036836 Quick entry form button does not follow standard spacing       
1036633 Cancel on Case edit view doesn't work  
1036631 Clicking on Account in Top Opportunities       
1033693 Some Translation Bugs  
1031310 SQL error when associating contact with task   



-=Modified Files=-
The following files were modified for Patch C:
./data/SugarBean.php
./export.php
./include/javascript/sugar.js
./include/ListView/ListView.php
./include/phpmailer/class.phpmailer.php
./include/replacePngTags.php
./include/time.php
./include/utils.php
./index.php
./install/5createTables.php
./modules/Accounts/Account.php
./modules/Accounts/DetailView.html
./modules/Accounts/DetailView.php
./modules/Accounts/ListView.html
./modules/Accounts/Menu.php
./modules/Accounts/Popup_picker.html
./modules/Accounts/Popup_picker.php
./modules/Accounts/SubPanelViewMemberAccount.html
./modules/Activities/Menu.php
./modules/Activities/OpenListView.html
./modules/Activities/OpenListView.php
./modules/Activities/SubPanelView.html
./modules/Activities/SubPanelView.php
./modules/Activities/SubPanelViewContacts.html
./modules/Administration/index.php
./modules/Administration/language/en_us.lang.php
./modules/Administration/Upgrade.php
./modules/Calls/Call.php
./modules/Calls/CallFormBase.php
./modules/Calls/DetailView.php
./modules/Calls/EditView.html
./modules/Calls/language/en_us.lang.php
./modules/Calls/ListView.html
./modules/Calls/Menu.php
./modules/Calls/SubPanelViewInvitees.html
./modules/Cases/DetailView.php
./modules/Cases/EditView.html
./modules/Cases/ListView.html
./modules/Cases/Menu.php
./modules/Cases/Popup_picker.html
./modules/Cases/SubPanelView.html
./modules/Contacts/BusinessCard.php
./modules/Contacts/ContactFormBase.php
./modules/Contacts/DetailView.html
./modules/Contacts/DetailView.php
./modules/Contacts/EditView.html
./modules/Contacts/ListView.html
./modules/Contacts/Menu.php
./modules/Contacts/Popup.php
./modules/Contacts/Popup_picker.html
./modules/Contacts/SubPanelView.html
./modules/Contacts/SubPanelViewAccounts.html
./modules/Contacts/SubPanelViewCase.html
./modules/Contacts/SubPanelViewContact.html
./modules/Contacts/SubPanelViewDirectReport.html
./modules/Contacts/SubPanelViewOpportunity.html
./modules/Currencies/ListView.html
./modules/Dashboard/Chart_lead_source_by_outcome.php
./modules/Dashboard/Chart_my_pipeline_by_sales_stage.php
./modules/Dashboard/Chart_outcome_by_month.php
./modules/Dashboard/Chart_pipeline_by_lead_source.php
./modules/Dashboard/Chart_pipeline_by_sales_stage.php
./modules/Dashboard/language/en_us.lang.php
./modules/Emails/EditView.html
./modules/Emails/Forms.php
./modules/Emails/ListView.html
./modules/Emails/Menu.php
./modules/Emails/SubPanelViewRecipients.html
./modules/Home/About.php
./modules/Import/ImportAccount.php
./modules/Import/ImportContact.php
./modules/Import/ImportOpportunity.php
./modules/Import/ImportStep1.html
./modules/Import/ImportStep4.php
./modules/Import/index.php
./modules/Import/language/en_us.lang.php
./modules/Leads/ConvertLead.php
./modules/Leads/DetailView.php
./modules/Leads/Lead.php
./modules/Leads/LeadFormBase.php
./modules/Leads/ListView.html
./modules/Leads/Menu.php
./modules/Leads/Popup.php
./modules/Leads/Popup_picker.html
./modules/Leads/SubPanelView.html
./modules/Meetings/DetailView.php
./modules/Meetings/EditView.html
./modules/Meetings/language/en_us.lang.php
./modules/Meetings/ListView.html
./modules/Meetings/Meeting.php
./modules/Meetings/MeetingFormBase.php
./modules/Meetings/Menu.php
./modules/Meetings/SubPanelViewInvitees.html
./modules/Notes/ListView.html
./modules/Notes/Menu.php
./modules/Notes/SubPanelView.html
./modules/Opportunities/Charts.php
./modules/Opportunities/DetailView.html
./modules/Opportunities/DetailView.php
./modules/Opportunities/EditView.html
./modules/Opportunities/EditView.php
./modules/Opportunities/ListView.html
./modules/Opportunities/ListViewTop.html
./modules/Opportunities/Menu.php
./modules/Opportunities/Opportunity.php
./modules/Opportunities/OpportunityFormBase.php
./modules/Opportunities/Popup.php
./modules/Opportunities/Popup_picker.html
./modules/Opportunities/SubPanelView.html
./modules/Tasks/DetailView.php
./modules/Tasks/EditView.html
./modules/Tasks/Forms.php
./modules/Tasks/ListView.html
./modules/Tasks/Menu.php
./modules/Tasks/Task.php
./modules/Users/DetailView.php
./modules/Users/EditView.html
./modules/Users/ListView.html
./modules/Users/Login.php
./modules/Users/Menu.php
./modules/Users/Popup_picker.html
./themes/Love/header.html
./themes/Love/images/attachment.png
./themes/Love/layout_utils.php
./themes/Love/style.css
./themes/Retro/header.html
./themes/Retro/images/attachment.png
./themes/Retro/layout_utils.php
./themes/Retro/style.css
./themes/Sugar/header.html
./themes/Sugar/header.php
./themes/Sugar/images/attachment.png
./themes/Sugar/layout_utils.php
./themes/Sugar/style.css
