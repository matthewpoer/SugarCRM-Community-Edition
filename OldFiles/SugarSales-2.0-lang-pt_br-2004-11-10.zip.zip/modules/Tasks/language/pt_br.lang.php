<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/modules/Accounts/Account.php,v 1.92 2004/11/10 22:27:36 clint Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Tarefas',
  'LBL_TASK' => 'Tarefas: ',
  'LBL_MODULE_TITLE' => ' Tarefas: Principal',
  'LBL_SEARCH_FORM_TITLE' => ' Pesquisar Tarefas',
  'LBL_LIST_FORM_TITLE' => ' Lista de Tarefas',
  'LBL_NEW_FORM_TITLE' => ' Nova Tarefa',
  'LBL_NEW_FORM_SUBJECT' => 'Assunto:',
  'LBL_NEW_FORM_DUE_DATE' => 'Data Devida:',
  'LBL_NEW_FORM_DUE_TIME' => 'Hora Devida:',
  'LBL_NEW_TIME_FORMAT' => '(24:00)',
  'LBL_LIST_CLOSE' => 'Encerrar',
  'LBL_LIST_SUBJECT' => 'Assunto',
  'LBL_LIST_CONTACT' => 'Contato',
  'LBL_LIST_RELATED_TO' => 'Relacionada a',
  'LBL_LIST_DUE_DATE' => 'Data Devida',
  'LBL_LIST_DUE_TIME' => 'Hora Devida',
  'LBL_SUBJECT' => 'Assunto:',
  'LBL_STATUS' => 'Situa��o:',
  'LBL_DUE_DATE' => 'Data Devida:',
  'LBL_PRIORITY' => 'Prioridade:',
  'LBL_COLON' => ':',
  'LBL_DUE_DATE_AND_TIME' => 'Data & Hora Devidas:',
  'DATE_FORMAT' => '(aaaa-mm-dd 24:00)',
  'LBL_NONE' => 'nada',
  'LBL_CONTACT' => 'Contato:',
  'LBL_PHONE' => 'Fone:',
  'LBL_EMAIL' => 'Email:',
  'LBL_DESCRIPTION_INFORMATION' => 'Informa��o de Descri��o',
  'LBL_DESCRIPTION' => 'Descri��o:',
  'LBL_NAME' => 'Nome:',
  'LBL_CONTACT_NAME' => 'Nome do Contato: ',
  'LBL_LIST_COMPLETE' => 'Completar:',
  'LBL_LIST_STATUS' => 'Situa��o:',
  'ERR_DELETE_RECORD' => 'Um n�mero de registro deve ser especificado para excluir a tarefa.',
  'ERR_INVALID_HOUR' => 'Por favor informe uma hora entre 00:00 e 24:00',
  'LBL_DEFAULT_STATUS' => 'N�o Iniciada',
  'LBL_DEFAULT_PRIORITY' => 'M�dio',
  'LNK_NEW_CALL' => 'Nova Chamada',
  'LNK_NEW_MEETING' => 'Nova Reuni�o',
  'LNK_NEW_TASK' => 'Nova Tarefa',
  'LNK_NEW_NOTE' => 'Nova Nota',
  'LNK_NEW_EMAIL' => 'Novo Email',
  'LNK_CALL_LIST' => 'Calls',
  'LNK_MEETING_LIST' => 'Meetings',
  'LNK_TASK_LIST' => 'Tasks',
  'LNK_NOTE_LIST' => 'Notes',
  'LNK_EMAIL_LIST' => 'Emails',
  'LNK_VIEW_CALENDAR' => 'Today',
  'LNK_NEW_CONTACT' => 'Novo Contato',
  'LNK_NEW_ACCOUNT' => 'Nova Conta',
  'LNK_NEW_OPPORTUNITY' => 'Nova Oportunidade',
  'LNK_NEW_CASE' => 'Novo Caso',
);


?>