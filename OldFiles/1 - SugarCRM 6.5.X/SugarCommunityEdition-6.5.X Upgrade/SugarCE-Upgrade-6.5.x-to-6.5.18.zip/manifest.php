<?php
// created: 2014-09-23 12:56:59
$manifest = array (
  'acceptable_sugar_flavors' => 
  array (
    0 => 'CE',
  ),
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
      0 => '6.5.0',
      1 => '6.5.1',
      2 => '6.5.2',
      3 => '6.5.3',
      4 => '6.5.4',
      5 => '6.5.5',
      6 => '6.5.6',
      7 => '6.5.7',
      8 => '6.5.8',
      9 => '6.5.9',
      10 => '6.5.10',
      11 => '6.5.11',
      12 => '6.5.12',
      13 => '6.5.13',
      14 => '6.5.14',
      15 => '6.5.15',
      16 => '6.5.16',
      17 => '6.5.17',
    ),
    'regex_matches' => 
    array (
    ),
  ),
  'author' => 'SugarCRM, Inc.',
  'copy_files' => 
  array (
    'from_dir' => 'SugarCE-Upgrade-6.5.x-to-6.5.18',
    'to_dir' => '',
    'force_copy' => 
    array (
    ),
  ),
  'description' => '',
  'icon' => '',
  'is_uninstallable' => false,
  'offline_client_applicable' => true,
  'name' => 'SugarCE',
  'published_date' => '2014-09-23 12:56:59',
  'type' => 'patch',
  'version' => '6.5.18',
  'flavor' => 'CE',
);
?>
