<?php
// created: 2013-08-25 23:06:36
$manifest = array (
  'acceptable_sugar_flavors' => 
  array (
    0 => 'CE',
  ),
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
      0 => '6.4.0',
      10 => '6.4.1',
      11 => '6.4.2',
      12 => '6.4.3',
      13 => '6.4.4',
      14 => '6.4.5',
      15 => '6.4.6',
    ),
    'regex_matches' => 
    array (
    ),
  ),
  'author' => 'SugarCRM, Inc.',
  'copy_files' => 
  array (
    'from_dir' => 'SugarCE-Upgrade-6.4.x-to-6.5.15',
    'to_dir' => '',
    'force_copy' => 
    array (
    ),
  ),
  'description' => '',
  'icon' => '',
  'is_uninstallable' => false,
  'offline_client_applicable' => true,
  'name' => 'SugarCE',
  'published_date' => '2013-08-25 23:06:36',
  'type' => 'patch',
  'version' => '6.5.15',
);
?>
