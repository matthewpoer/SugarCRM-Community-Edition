<?php
// created: 2013-01-29 23:07:48
$manifest = array (
  'acceptable_sugar_flavors' => 
  array (
    0 => 'CE',
  ),
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
      0 => '6.5.0',
      10 => '6.5.1',
      11 => '6.5.2',
      12 => '6.5.3',
      13 => '6.5.4',
      14 => '6.5.5',
      15 => '6.5.6',
      16 => '6.5.7',
      17 => '6.5.8',
      18 => '6.5.9',
    ),
    'regex_matches' => 
    array (
    ),
  ),
  'author' => 'SugarCRM, Inc.',
  'copy_files' => 
  array (
    'from_dir' => 'SugarCE-Upgrade-6.5.x-to-6.5.10',
    'to_dir' => '',
    'force_copy' => 
    array (
    ),
  ),
  'description' => '',
  'icon' => '',
  'is_uninstallable' => false,
  'offline_client_applicable' => true,
  'name' => 'SugarCE',
  'published_date' => '2013-01-29 23:07:48',
  'type' => 'patch',
  'version' => '6.5.10',
);
?>
