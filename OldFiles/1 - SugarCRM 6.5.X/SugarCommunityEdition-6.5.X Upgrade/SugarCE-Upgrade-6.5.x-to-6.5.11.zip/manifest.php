<?php
// created: 2013-02-27 14:10:19
$manifest = array (
  'acceptable_sugar_flavors' => 
  array (
    0 => 'CE',
  ),
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
      0 => '6.5.0',
      10 => '6.5.1',
      11 => '6.5.10',
      12 => '6.5.2',
      13 => '6.5.3',
      14 => '6.5.4',
      15 => '6.5.5',
      16 => '6.5.6',
      17 => '6.5.7',
      18 => '6.5.8',
      19 => '6.5.9',
    ),
    'regex_matches' => 
    array (
    ),
  ),
  'author' => 'SugarCRM, Inc.',
  'copy_files' => 
  array (
    'from_dir' => 'SugarCE-Upgrade-6.5.x-to-6.5.11',
    'to_dir' => '',
    'force_copy' => 
    array (
    ),
  ),
  'description' => '',
  'icon' => '',
  'is_uninstallable' => false,
  'offline_client_applicable' => true,
  'name' => 'SugarCE',
  'published_date' => '2013-02-27 14:10:19',
  'type' => 'patch',
  'version' => '6.5.11',
);
?>
