<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Tasks/language/en_us.lang.php,v 1.10 2004/08/04 17:48:27 sugarjacob Exp $
 * Description:  Defines the English language pack for this module.
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_MODULE_NAME'=>'任務',
'LBL_TASK'=>'任務: ',
'LBL_MODULE_TITLE'=>' 任務: 首頁',
'LBL_SEARCH_FORM_TITLE'=>' 搜尋任務',
'LBL_LIST_FORM_TITLE'=>' 任務列表',
'LBL_NEW_FORM_TITLE'=>' 新增任務',

'LBL_NEW_FORM_SUBJECT'=>'主題：',
'LBL_NEW_FORM_DUE_DATE'=>'結束日期：',
'LBL_NEW_FORM_DUE_TIME'=>'結束時間：',
'LBL_NEW_TIME_FORMAT'=>'(24:00)',

'LBL_LIST_CLOSE'=>'結束',
'LBL_LIST_SUBJECT'=>'主題',
'LBL_LIST_CONTACT'=>'聯絡人',
'LBL_LIST_RELATED_TO'=>'相關於',
'LBL_LIST_DUE_DATE'=>'結束日期',
'LBL_LIST_DUE_TIME'=>'結束時間',

'LBL_SUBJECT'=>'主題：',
'LBL_STATUS'=>'主題：',
'LBL_DUE_DATE'=>'到期日期：',
'LBL_PRIORITY'=>'優先等級：',
'LBL_COLON'=>'：',
'LBL_DUE_DATE_AND_TIME'=>'結束日期與時間：',
'DATE_FORMAT'=>'(yyyy-mm-dd 24:00)',
'LBL_NONE'=>'空白',
'LBL_PRIORITY'=>'優先等級：',
'LBL_CONTACT'=>'聯絡人：',
'LBL_PHONE'=>'電話：',
'LBL_EMAIL'=>'電子郵件：',
'LBL_DESCRIPTION_INFORMATION'=>'描述資訊',
'LBL_DESCRIPTION'=>'描述：',
'LBL_NAME'=>'姓名：',
'LBL_CONTACT_NAME'=>'聯絡名: ',
'LBL_LIST_COMPLETE'=>'完成：',
'LBL_LIST_STATUS'=>'狀態：',
'ERR_DELETE_RECORD'=>"必須指定記錄編號才能刪除機會.",
'ERR_INVALID_HOUR'=>'請輸入 0 至 24 之間的小時數',
'LBL_DEFAULT_STATUS'=>'尚未開始',
'LBL_DEFAULT_PRIORITY'=>'中等',

'LNK_NEW_CONTACT'=>'新增聯絡人',
'LNK_NEW_ACCOUNT'=>'新增公司',
'LNK_NEW_OPPORTUNITY'=>'新增機會',
'LNK_NEW_CASE'=>'新增事件',
'LNK_NEW_NOTE'=>'新增備註',
'LNK_NEW_CALL'=>'新增電話記錄',
'LNK_NEW_EMAIL'=>'新增電子郵件',
'LNK_NEW_MEETING'=>'新增會議',
'LNK_NEW_TASK'=>'新增任務',
);

?>