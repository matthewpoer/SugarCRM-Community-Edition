<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Activities/language/en_us.lang.php,v 1.7 2004/08/03 08:59:02 sugarclint Exp $
 * Description:  Defines the English language pack for the Account module.
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_OPEN_ACTIVITIES'=>'Attività Aperte',
'LBL_HISTORY'=>'Storico',
'LBL_UPCOMING'=>"Le mie prossime attività",
'LBL_TODAY'=>'per ',

'LBL_NEW_TASK_BUTTON_TITLE'=>'Nuovo Task [Alt+N]',
'LBL_NEW_TASK_BUTTON_KEY'=>'N',
'LBL_NEW_TASK_BUTTON_LABEL'=>'Nuovo Task',
'LBL_SCHEDULE_MEETING_BUTTON_TITLE'=>'Pianifica Meeting[Alt+M]',
'LBL_SCHEDULE_MEETING_BUTTON_KEY'=>'M',
'LBL_SCHEDULE_MEETING_BUTTON_LABEL'=>'Pianifica Meeting',
'LBL_SCHEDULE_CALL_BUTTON_TITLE'=>'Pianifica Chiamata[Alt+C]',
'LBL_SCHEDULE_CALL_BUTTON_KEY'=>'C',
'LBL_SCHEDULE_CALL_BUTTON_LABEL'=>'Pianifica Chiamata',
'LBL_NEW_NOTE_BUTTON_TITLE'=>'Nuova [Alt+T]',
'LBL_NEW_NOTE_BUTTON_KEY'=>'T',
'LBL_NEW_NOTE_BUTTON_LABEL'=>'Nuova Nota',
'LBL_TRACK_EMAIL_BUTTON_TITLE'=>'Traccia Email [Alt+K]',
'LBL_TRACK_EMAIL_BUTTON_KEY'=>'K',
'LBL_TRACK_EMAIL_BUTTON_LABEL'=>'Traccia Email',

'LBL_LIST_CLOSE'=>'Chiuso',
'LBL_LIST_STATUS'=>'Stato',
'LBL_LIST_CONTACT'=>'Contatto',
'LBL_LIST_RELATED_TO'=>'Relativo a',
'LBL_LIST_DUE_DATE'=>'Data prevista',
'LBL_LIST_DATE'=>'Data',
'LBL_LIST_SUBJECT'=>'Soggetto',
'LBL_LIST_LAST_MODIFIED'=>'Ultima modifica',

'LNK_NEW_CONTACT'=>'Nuovo Contatto',
'LNK_NEW_ACCOUNT'=>'Nuovo Cliente',
'LNK_NEW_OPPORTUNITY'=>'Nuova Opportunità',
'LNK_NEW_CASE'=>'Nuovo Ticket Supporto',
'LNK_NEW_NOTE'=>'Nuova Nota',
'LNK_NEW_CALL'=>'Nuova Chiamata',
'LNK_NEW_EMAIL'=>'Nuova Email',
'LNK_NEW_MEETING'=>'Nuovo Meeting',
'LNK_NEW_TASK'=>'Nuovo Task',
'ERR_DELETE_RECORD'=>"Devi specificare un numero record per eliminare il cliente.",
'NTC_NONE_SCHEDULED'=>'Niente di pianificato.',
);

?>