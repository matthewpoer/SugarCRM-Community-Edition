<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Dashboard/language/en_us.lang.php,v 1.4 2004/08/03 07:43:16 sugarclint Exp $
 * Description:  Defines the English language pack for the Account module.
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_SALES_STAGE_FORM_TITLE'=>'Totale in Portafoglio per Stadio di Vendita',
'LBL_SALES_STAGE_FORM_DESC'=>'Mostra il totale cumulativo di opportunità nello stadio di vendita selezionato per gli utenti selezionati quando la data di chiusura attesa è nel range di date specificato.',
'LBL_MONTH_BY_OUTCOME'=>'Pipeline per mese per esito',
'LBL_MONTH_BY_OUTCOME_DESC'=>'Mostra il totale cumulativo di opportunità per mese per esito per gli utenti selezionati quando la data di chiusura attesa è nel range di date specificato. L\'esito è specificato in base al valore della fase di vendita "Chiusa vinta", "Chiusa persa" o altro valore.',
'LBL_LEAD_SOURCE_FORM_TITLE'=>'Totale in Portafoglio per Fonte Lead',
'LBL_LEAD_SOURCE_FORM_DESC'=>'Mostra il totale cumulativo di opportunità per le fonti selezionate per gli utenti selezionati.',
'LBL_LEAD_SOURCE_BY_OUTCOME'=>'Tutte le opportunità per fonte per esito',
'LBL_LEAD_SOURCE_BY_OUTCOME_DESC'=>'Mostra il totale cumulativo di opportunità per fonte per esito per gli utenti selezionati quando la data di chiusura attesa è nel range di date specificato. L\'esito è specificato in base al valore della fase di vendita "Chiusa vinta", "Chiusa persa" o altro valore.',
'LBL_PIPELINE_FORM_TITLE_DESC'=>'Mostra il totale cumulativo di opportunità per stadio di vendita quando la data di chiusura attesa è nel range di date specificato.',
'LBL_DATE_RANGE'=>'Il range di date è',
'LBL_DATE_RANGE_TO'=>'a',
'ERR_NO_OPPS'=>'Per favore crea quanche opportunità per vedere il grafico delle opportunità .',
'LBL_TOTAL_PIPELINE'=>'Totale in Portafoglio ',
'LBL_OPP_SIZE'=>'Volume in KEur.',
'NTC_NO_LEGENDS'=>'Nessuno',
'LBL_LEAD_SOURCE_OTHER'=>'Altro',
'LBL_EDIT'=>'Modifica',
'LBL_REFRESH'=>'Ricalcola',
'LBL_CREATED_ON'=>'Ultima esecuzione il ',
'LBL_OPPS_IN_STAGE'=>'opportunità nello stadio di vendita è',
'LBL_OPPS_IN_LEAD_SOURCE'=>'opportunità per la fonte è',
'LBL_OPPS_OUTCOME'=>'opportunità per esito è',
'LBL_USERS'=>'Utenti:',
'LBL_SALES_STAGES'=>'Fase di vendita:',
'LBL_LEAD_SOURCES'=>'Fonte del lead:',
'LBL_DATE_START'=>'Data di inizio:',
'LBL_DATE_END'=>'Data di fine:',

'LNK_NEW_CONTACT'=>'Nuovo Contatto',
'LNK_NEW_ACCOUNT'=>'Nuovo Cliente',
'LNK_NEW_OPPORTUNITY'=>'Nuova Opportunità ',
'LNK_NEW_CASE'=>'Nuovo Ticket Supporto',
'LNK_NEW_NOTE'=>'Nuova Nota',
'LNK_NEW_CALL'=>'Nuova Chiamata',
'LNK_NEW_EMAIL'=>'Nuova Email',
'LNK_NEW_MEETING'=>'Nuova Riunione',
'LNK_NEW_TASK'=>'Nuovo Task',
);

?>