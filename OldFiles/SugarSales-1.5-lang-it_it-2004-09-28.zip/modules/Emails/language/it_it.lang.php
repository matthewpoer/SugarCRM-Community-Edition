<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Emails/language/en_us.lang.php,v 1.10 2004/08/03 07:43:17 sugarclint Exp $
 * Description:  Defines the English language pack for the Account module.
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_MODULE_NAME'=>'Email',
'LBL_MODULE_TITLE'=>'Email: Home',
'LBL_SEARCH_FORM_TITLE'=>'Cerca Email',
'LBL_LIST_FORM_TITLE'=>'Lista Email',
'LBL_NEW_FORM_TITLE'=>'Scrivi Email',

'LBL_LIST_SUBJECT'=>'Soggetto',
'LBL_LIST_CONTACT'=>'Contatto',
'LBL_LIST_RELATED_TO'=>'Relativo a',
'LBL_LIST_DATE'=>"Data d'invio",
'LBL_LIST_TIME'=>"Ora d'invio",

'ERR_DELETE_RECORD'=>"Devi specificare un numero record per eliminare il cliente.",
'LBL_DATE_SENT'=>"Data d'invio:",
'LBL_SUBJECT'=>'Soggetto:',
'LBL_BODY'=>'Corpo del messaggio:',
'LBL_DATE_AND_TIME'=>"Data & Ora di invio:",
'LBL_DATE'=>"Data d'invio:",
'LBL_TIME'=>"Ora d'invio:",
'LBL_SUBJECT'=>'Soggetto:',
'LBL_BODY'=>'Corpo del messaggio:',
'LBL_CONTACT_NAME'=>' Nome Contatto: ',
'LBL_EMAIL'=>'Email:',  
'LBL_COLON'=>':',

'LNK_NEW_CONTACT'=>'Nuovo Contatto',
'LNK_NEW_ACCOUNT'=>'Nuovo Cliente',
'LNK_NEW_OPPORTUNITY'=>'Nuova Opportunità',
'LNK_NEW_CASE'=>'Nuovo Ticket Supporto',
'LNK_NEW_NOTE'=>'Nuova Nota',
'LNK_NEW_CALL'=>'Nuova Chiamata',
'LNK_NEW_EMAIL'=>'Nuova Email',
'LNK_NEW_MEETING'=>'Nuova Riunione',
'LNK_NEW_TASK'=>'Nuovo Task',
'NTC_REMOVE_INVITEE'=>'Sei sicuro di voler rimuovere questo destinatario dall\'email?',
'LBL_INVITEE'=>'Destinatari',
);

?>