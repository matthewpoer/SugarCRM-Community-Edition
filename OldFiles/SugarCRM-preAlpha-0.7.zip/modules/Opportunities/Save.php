<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1
 * ("License"); You may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Opportunities/Save.php,v 1.2 2004/06/06 02:23:28 sugarjacob Exp $
 * Description:  TODO: To be written.
 ********************************************************************************/

require_once('modules/Opportunities/Opportunity.php');
require_once('logging.php');

$local_log =& LoggerManager::getLogger('index');

$local_log->fatal("Root of detail view");

$focus = new Opportunity();

$focus->retrieve($_REQUEST['record']);

foreach($focus->column_fields as $field)
{
	if(isset($_REQUEST[$field]))
	{
		$value = $_REQUEST[$field];
		$focus->$field = $value;
	}
}

foreach($focus->additional_column_fields as $field)
{
	if(isset($_REQUEST[$field]))
	{
		$value = $_REQUEST[$field];
		$focus->$field = $value;
	}
}

// send them to the edit screen.
if(isset($_REQUEST['record']) && $_REQUEST['record'] != "")
{
    $recordID = $_REQUEST['record'];
}

$focus->save();
$recordID = $focus->id;

$local_log->debug("Saved record with id of ".$recordID);

header("Location: index.php?action=DetailView&module=Opportunities&record=$recordID");
?>