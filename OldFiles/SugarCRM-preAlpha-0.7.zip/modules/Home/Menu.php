<?php 
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1
 * ("License"); You may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Home/Menu.php,v 1.2 2004/06/06 02:23:28 sugarjacob Exp $
 * Description: TODO:  To be written.
 ********************************************************************************/

$module_menu = Array(
	Array("index.php?module=DeletedItems&action=ListView", "Deleted Items"),
	Array("index.php?module=Contacts&action=EditView", "New Contact"),
	Array("index.php?module=Accounts&action=EditView", "New Account"),
	Array("index.php?module=Leads&action=EditView", "New Lead"),
	Array("index.php?module=Opportunities&action=EditView", "New Opportunity"),
	Array("index.php?module=Quotes&action=EditView", "New Quote"),
	Array("index.php?module=Tasks&action=EditView", "New Task")
	);

?>