<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1
 * ("License"); You may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/index.php,v 1.3 2004/06/06 02:23:26 sugarjacob Exp $
 * Description: Main file and starting point for the application.  Calls the 
 * theme header and footer files defined for the user as well as the module as 
 * defined by the input parameters.
 ********************************************************************************/
 
if (!is_file('config.php')) {
    header("Location: install.php");
    exit();
}

require_once('config.php');
require_once('logging.php');
global $currentModule;

if($calculate_response_time) $startTime = microtime();

$log =& LoggerManager::getLogger('index');

$log->info("current module is $currentModule ");	

$log->debug($_REQUEST);

$skipHeaders=false;
$skipFooters=false;

//define default home pages for each module
foreach ($moduleList as $mod) {
	$moduleDefaultFile[$mod] = "modules/".$currentModule."/index.php";
}

if(isset($_REQUEST['action']) && isset($_REQUEST['module']))
{
	$log->info("About to take action ".$_REQUEST['action']);
	// We have an action.
	$action = $_REQUEST['action']; 
	$log->debug("in $action");
	if(ereg("^Save", $action) || ereg("^Delete", $action) || ereg("^Popup", $action))
	{
		$skipHeaders=true;
		if(ereg("^Popup", $action))
			$skipFooters=true;
	}
	
	$currentModuleFile = 'modules/'.$_REQUEST['module'].'/'.$action.'.php';
	$currentModule = $_REQUEST['module'];
}
elseif(isset($_REQUEST['module']))
{
	$currentModule = $_REQUEST['module'];
	$currentModuleFile = $moduleDefaultFile[$currentModule];
}
else {
    // use $default_module and $default_action as set in config.php
    // Redirect to the correct module with the correct action.  We need the URI to include these fields.
    header("Location: index.php?action=$default_action&module=$default_module");
    exit();
}

$log->info("current page is $currentModuleFile");	

//TODO Clint 4/30 - Need to replace this hardcoded reference to the Admin user with the upcoming
//					multi-user functionality.
require_once("modules/Users/User.php");
$current_user = new User();
$current_user->retrieve('1');
$log->debug('Current user is: '.$current_user->user_name);

if ($current_user->theme !== "") $theme = $current_user->theme;
else $theme = $default_theme;

//Used for current record focus
$focus = "";

//If DetailView, set focus to record passed in
if($action == "DetailView")
{
	if(!isset($_REQUEST['record']))
		die("A record number must be specified to view details.");

	// If we are going to a detail form, load up the record now.
	// Use the record to track the viewing.
	// todo - Have a record of modules and thier primary object names.
	switch($currentModule)
	{
		case 'Contacts':
			require_once("modules/$currentModule/Contact.php");
			$focus = new Contact();
			break;
		case 'Accounts':
			require_once("modules/$currentModule/Account.php");
			$focus = new Account();
			break;
		case 'Opportunities':
			require_once("modules/$currentModule/Opportunity.php");
			$focus = new Opportunity();
			break;
	}
	
	$focus->retrieve($_REQUEST['record']);
	
	$focus->track_view($current_user->id, $currentModule);
}	

if(!$skipHeaders) {
	include('themes/'.$theme.'/header.php');
	echo "<!-- startprint -->";
}
else {
		$log->debug("skipping headers");
}

include($currentModuleFile);

echo "<!-- stopprint -->";

if(!$skipFooters)
	include('themes/'.$theme.'/footer.php');

if($calculate_response_time)
{
    $endTime = microtime();

    $deltaTime = microtime_diff($startTime, $endTime);
    echo('&nbsp;Server response time: '.$deltaTime.' seconds.<BR />');
}

?>