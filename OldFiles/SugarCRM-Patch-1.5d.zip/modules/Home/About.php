<?php
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version 1.1.2
* ("License"); You may not use this file except in compliance with the
* License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
* Software distributed under the License is distributed on an  "AS IS"  basis,
* WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
* the specific language governing rights and limitations under the License.
* The Original Code is:  SugarCRM Open Source
* The Initial Developer of the Original Code is SugarCRM, Inc.
* Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
* All Rights Reserved.
* Contributor(s): ______________________________________.
********************************************************************************/

//NOTE: Under the Sugar Public License referenced above, you are required to leave in all copyright statements in both
//the code and end-user application.

global $sugar_version;
?>
<table align="left" cellpadding="3" cellspacing="3"><tr><td>
<table width=425 border="0" cellpadding="0" cellspacing="3"><tr>
<td align="left"><IMG src="include/images/sugarsales_lg.gif" alt="Sugar Sales"></td>
</tr><tr>
<td align="left"><font size='3'><b>Version <?php echo $sugar_version; ?></b></font></td>
</tr><tr>
</tr></table>
<table border="0" cellpadding="0" cellspacing="0"><tr>
<td>Copyright &copy; 2004 <A href="http://www.sugarcrm.com" target="_blank">SugarCRM Inc.</A> All Rights Reserved. <A href="http://www.sugarcrm.com/SPL" target="_blank">View License Agreement</A></td>
</tr><tr>
<td>SugarCRM<FONT size=1>TM</FONT> and Sugar Sales<FONT size=1>TM</FONT> are trademarks of SugarCRM Inc. <A href="http://www.sugarcrm.com/trademark" target="_blank">View Trademark Guidelines</A></td>
</tr></table>
<P></P>
<TABLE class=MsoTableGrid cellSpacing=3 cellPadding=3 border=0>
  <TBODY>
    <TR>
      <TD vAlign=top nowrap><B>SugarCRM Inc.</B><BR>
        10080 North Wolfe Road<BR>
        Suite SW3-303<BR>
		Cupertino, CA 95014 USA</TD>
      <TD vAlign=top nowrap><P><B>Contact Information</B><BR>
Web: <A href="http://www.sugarcrm.com" target="_blank">http://www.sugarcrm.com</A><BR>
Email: <A href="mailto:support@sugarcrm.com">support@sugarcrm.com</A> | <A href="sales@sugarcrm.com">sales@sugarcrm.com</A><BR>
Phone: +1 408.873.9872<BR>
          <BR>
    </TD></TR>
    <TR>
      <TD vAlign=top width=180 nowrap><B>Team Members</B><BR>
		  <LI>John Roberts</LI>
          <LI>Clint Oram</LI>
          <LI>Jacob Taylor</LI>
          <LI>Josh Stein</LI>
          <LI>Tara Smith</LI>
          <LI>Julian Ostrow</LI>
          <LI>Robert Rangel</LI>
          <LI>Lam Huynh</LI>
          <LI>Majed Itani</LI>
          <LI>Dave Murphy</LI></TD>
      <TD vAlign=top width=360><B>Silicon Valley Corporate Office</B>
	<IMG src="include/images/corp_office.jpg">
	</TD>
    </TR>
  </TBODY>
</TABLE>


<B>Thanks to the following developers for their code contributions to this release:</B>
<LI>Olaf Kock of Abstrakt GmbH and Controll-IT GmbH�- Contributed a security review of Sugar Sales.</LI>
<LI>Pascal Brunel of Synolia.com � Contributed an integration the Spiffy calendar widget, French localization and some minor code enhancements.</LI>
<LI>Xavier Dutoit of Sydesy Ltd - Contributed the file upload feature in Notes, an integration with the DHTML calendar widget and some minor code enhancements.</LI>

<P>
<TABLE cellpadding="0" cellspacing="0"><TR>
<TD align="left" colspan=2><strong>Special thanks to the following advisors:</strong></Td>
</tr><tr>
<td valign="top"><LI>Phil Grisier</LI>
<LI>Mary Coleman</LI>
<LI>Raj Rao</LI>
<LI>Rand Bradley</LI>
</TD><TD valign="top">
<LI>Andrew Aitken</LI>
<LI>Mark Radcliffe</LI>
<LI>Laura Merling </LI>
</TD></TR>
</TABLE>

<P>
<B>Source Code</B>
<LI>Sugar Sales - The world's most popular sales force automation application created by SugarCRM Inc. (<A href="http://www.sugarcrm.com" target="_blank">http://www.sugarcrm.com</A>)</LI>
<LI>XTemplate - A template engine for PHP created by Barnab�s Debreceni (<A href="http://sourceforge.net/projects/xtpl" target="_blank">http://sourceforge.net/projects/xtpl</A>)</LI>
<LI>JpGraph - An object-oriented graph library for PHP created by Johan Persson (<a href="http://www.aditus.nu/jpgraph" target="_blank">http://www.aditus.nu/jpgraph</a>)</LI>
<LI>Log4php - A PHP port of Log4j, the most popular Java logging framework, created by Ceki G�lc� (<a href="http://www.vxr.it/log4php" target="_blank">http://www.vxr.it/log4php</a>)</LI>
<LI>NuSOAP - A set of PHP classes that allow developers to create and consume web services created by NuSphere Corporation and Dietrich Ayala (<a href="http://dietrich.ganx4.com/nusoap" target="_blank">http://dietrich.ganx4.com/nusoap</a>)</LI>
<LI>JS Calendar - A calendar for entering dates created by Mihai Bazon (<a href="http://www.dynarch.com/mishoo/calendar.epl" target="_blank">http://www.dynarch.com/mishoo/calendar.epl</a>)</LI>
</td></tr></table>