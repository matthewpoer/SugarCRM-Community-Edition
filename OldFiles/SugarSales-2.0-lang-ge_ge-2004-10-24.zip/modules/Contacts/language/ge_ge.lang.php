<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/include/language/en_us.lang.php,v 1.89 2004/10/25 02:32:20 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Kontakte',
  'LBL_INVITEE' => 'Rapportiert direkt an',
  'LBL_MODULE_TITLE' => 'Kontakte: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Kontakt suchen',
  'LBL_LIST_FORM_TITLE' => 'Liste der Kontakte',
  'LBL_NEW_FORM_TITLE' => 'Neuer Kontakt',
  'LBL_CONTACT_OPP_FORM_TITLE' => 'Kontakt-Auftrag:',
  'LBL_CONTACT' => 'Kontakt:',
  'LBL_BUSINESSCARD' => 'Business Card',
  'LBL_LIST_NAME' => 'Namen',
  'LBL_LIST_LAST_NAME' => 'Nachnamen',
  'LBL_LIST_CONTACT_NAME' => 'Kontakt',
  'LBL_LIST_TITLE' => 'Funktion',
  'LBL_LIST_ACCOUNT_NAME' => 'Kunde',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email',
  'LBL_LIST_OTHER_EMAIL_ADDRESS' => 'Other Email',
  'LBL_LIST_PHONE' => 'Telefon',
  'LBL_LIST_CONTACT_ROLE' => 'Funktion',
  'LBL_LIST_FIRST_NAME' => 'First Name',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_email2' => 'LBL_LIST_OTHER_EMAIL_ADDRESS',
//END DON'T CONVERT
  'LBL_EXISTING_CONTACT' => 'Used an existing contact',
  'LBL_CREATED_CONTACT' => 'Created a new contact',
  'LBL_EXISTING_ACCOUNT' => 'Used an existing account',
  'LBL_CREATED_ACCOUNT' => 'Created a new account',
  'LBL_CREATED_CALL' => 'Created a new call',
  'LBL_CREATED_MEETING' => 'Created a new meeting',
  'LBL_ADDMORE_BUSINESSCARD' => 'Add another business card',
  'LBL_ADD_BUSINESSCARD' => 'Create From Business Card',
  'LBL_NAME' => 'Namen:',
  'LBL_CONTACT_NAME' => 'Kontakt:',
  'LBL_CONTACT_INFORMATION' => 'Kontakt Informationen',
  'LBL_FIRST_NAME' => 'Vornamen:',
  'LBL_OFFICE_PHONE' => 'Telefon Gesch�ft:',
  'LBL_ACCOUNT_NAME' => 'Kunde:',
  'LBL_ANY_PHONE' => 'Weiteres Telefon:',
  'LBL_PHONE' => 'Telephon:',
  'LBL_LAST_NAME' => 'Nachnamen:',
  'LBL_MOBILE_PHONE' => 'Mobile:',
  'LBL_HOME_PHONE' => 'Privat:',
  'LBL_LEAD_SOURCE' => 'Herkunft:',
  'LBL_OTHER_PHONE' => 'Weiteres Telefon:',
  'LBL_FAX_PHONE' => 'Fax:',
  'LBL_TITLE' => 'Titel:',
  'LBL_DEPARTMENT' => 'Abteilung:',
  'LBL_BIRTHDATE' => 'Geburtstag:',
  'LBL_EMAIL_ADDRESS' => 'Email:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Weitere Email:',
  'LBL_ANY_EMAIL' => 'Weitere Email:',
  'LBL_REPORTS_TO' => 'Rapportiert an:',
  'LBL_ASSISTANT' => 'Assistent:',
  'LBL_ASSISTANT_PHONE' => 'Assistent Telefon:',
  'LBL_DO_NOT_CALL' => 'Nicht anrufen:',
  'LBL_EMAIL_OPT_OUT' => 'Email Opt Out:',
  'LBL_PRIMARY_ADDRESS' => 'Gesch�fts Adresse:',
  'LBL_ALTERNATE_ADDRESS' => 'Weitere Adresse:',
  'LBL_ANY_ADDRESS' => 'Weitere Adresse:',
  'LBL_CITY' => 'Ort:',
  'LBL_STATE' => 'Bundesland:',
  'LBL_POSTAL_CODE' => 'PLZ:',
  'LBL_COUNTRY' => 'Land:',
  'LBL_DESCRIPTION_INFORMATION' => 'Zus�tzliche Informationen',
  'LBL_ADDRESS_INFORMATION' => 'Adresse',
  'LBL_DESCRIPTION' => 'Bemerkungen:',
  'LBL_CONTACT_ROLE' => 'Rolle:',
  'LBL_OPP_NAME' => 'Auftrag:',
  'LBL_IMPORT_VCARD' => 'Import vCard',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new contact by importing a vCard from your file system.',
  'LBL_DUPLICATE' => 'Possible Duplicate Contacts',
  'MSG_DUPLICATE' => 'Creating this contact may potentialy create a duplicate contact. You may either select a contact from the list below or you may click on Create New Contact to continue creating a new contact with the previously entered data.',
  'LNK_CONTACT_LIST' => 'Contacts',
  'LNK_IMPORT_VCARD' => 'Create From vCard',
  'LNK_NEW_CONTACT' => 'Neuer Kontakt',
  'LNK_NEW_ACCOUNT' => 'Neuer Kunde',
  'LNK_NEW_OPPORTUNITY' => 'Neuer Auftrag',
  'LNK_NEW_CASE' => 'Neue Anfrage',
  'LNK_NEW_NOTE' => 'Neue Notiz',
  'LNK_NEW_CALL' => 'Neues Telefonat',
  'LNK_NEW_EMAIL' => 'Neue Email',
  'LNK_NEW_MEETING' => 'Neuer Termin',
  'LNK_NEW_TASK' => 'Neue Aufgabe',
  'LNK_NEW_APPOINTMENT' => 'Create Appointment',
  'NTC_DELETE_CONFIRMATION' => 'Wollen Sie diesen Eintrag wirklich l�schen?',
  'NTC_REMOVE_CONFIRMATION' => 'Wollen Sie diesen Kontakt wirklich von diesem Bedarf entfernen?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Wollen Sie diesen Eintrag wirklich von einen direkten Report entfernen?',
  'ERR_DELETE_RECORD' => 'Ein Eintrag muss ausgew�hlt sein um ein Kontakt zu l�schen.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Kopiere gesch�fts Adresse zu weitere Adresse',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Kopiere weitere Adresse zu gesch�fts Adresse',
  'LBL_SALUTATION' => 'Salutation',
  'LBL_YAHOO_ID' => 'Yahoo! ID:',
);


?>