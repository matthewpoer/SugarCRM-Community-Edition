<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/include/language/en_us.lang.php,v 1.89 2004/10/25 02:32:20 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Benutzer',
  'LBL_MODULE_TITLE' => 'Benutzer: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Benutzer Suchen',
  'LBL_LIST_FORM_TITLE' => 'Liste der Benutzer',
  'LBL_NEW_FORM_TITLE' => 'Neuer Benutzer',
  'LBL_USER' => 'Benutzer:',
  'LBL_LOGIN' => 'Login',
  'LBL_RESET_PREFERENCES' => 'Zur�cksetzen auf Standardeinstellungen',
  'LBL_TIME_FORMAT' => 'Time Format:',
  'LBL_CURRENCY' => 'Currency:',
  'LBL_LIST_NAME' => 'Namen',
  'LBL_LIST_LAST_NAME' => 'Nachnamen',
  'LBL_LIST_USER_NAME' => 'Benutzernamen',
  'LBL_LIST_DEPARTMENT' => 'Abteilung',
  'LBL_LIST_EMAIL' => 'Email',
  'LBL_LIST_PRIMARY_PHONE' => 'Prim�re Telefon',
  'LBL_LIST_ADMIN' => 'Admin',
  'LBL_NEW_USER_BUTTON_TITLE' => 'Neuer Benutzer [Alt+N]',
  'LBL_NEW_USER_BUTTON_LABEL' => 'Neuer Benutzer',
  'LBL_NEW_USER_BUTTON_KEY' => 'N',
  'LBL_ERROR' => 'Error:',
  'LBL_PASSWORD' => 'Passwort:',
  'LBL_USER_NAME' => 'Benutzernamen:',
  'LBL_FIRST_NAME' => 'Vornamen:',
  'LBL_LAST_NAME' => 'Nachnamen:',
  'LBL_USER_SETTINGS' => 'Benutzer Einstellungen',
  'LBL_THEME' => 'Layout:',
  'LBL_LANGUAGE' => 'Sprache:',
  'LBL_ADMIN' => 'Administrator:',
  'LBL_USER_INFORMATION' => 'Benutzer Informationen',
  'LBL_OFFICE_PHONE' => 'Telefon Gesch�ft:',
  'LBL_REPORTS_TO' => 'Rapportiert an:',
  'LBL_OTHER_PHONE' => 'Andere:',
  'LBL_OTHER_EMAIL' => 'Weitere Email:',
  'LBL_NOTES' => 'Notizen:',
  'LBL_DEPARTMENT' => 'Abteilung:',
  'LBL_STATUS' => 'Status:',
  'LBL_TITLE' => 'Funktion:',
  'LBL_ANY_PHONE' => 'Weiteres Telefon:',
  'LBL_ANY_EMAIL' => 'Weitere Email:',
  'LBL_ADDRESS' => 'Addresse:',
  'LBL_CITY' => 'Ort:',
  'LBL_STATE' => 'Bundesland:',
  'LBL_POSTAL_CODE' => 'PLZ:',
  'LBL_COUNTRY' => 'Land:',
  'LBL_NAME' => 'Namen:',
  'LBL_MOBILE_PHONE' => 'Mobile:',
  'LBL_OTHER' => 'Andere:',
  'LBL_FAX' => 'Fax:',
  'LBL_EMAIL' => 'Email:',
  'LBL_HOME_PHONE' => 'Telefon Privat:',
  'LBL_ADDRESS_INFORMATION' => 'Adress Informationen',
  'LBL_PRIMARY_ADDRESS' => 'Prim�re Adresse:',
  'LBL_CHANGE_PASSWORD_BUTTON_TITLE' => 'Passwort �ndern [Alt+P]',
  'LBL_CHANGE_PASSWORD_BUTTON_KEY' => 'P',
  'LBL_CHANGE_PASSWORD_BUTTON_LABEL' => 'Passwort �ndern',
  'LBL_LOGIN_BUTTON_TITLE' => 'Login [Alt+L]',
  'LBL_LOGIN_BUTTON_KEY' => 'L',
  'LBL_LOGIN_BUTTON_LABEL' => 'Login',
  'LBL_CHANGE_PASSWORD' => 'Passwort �ndern',
  'LBL_OLD_PASSWORD' => 'Altes Passwort:',
  'LBL_NEW_PASSWORD' => 'Neues Passwort:',
  'LBL_CONFIRM_PASSWORD' => 'Passwort best�tigen:',
  'ERR_ENTER_OLD_PASSWORD' => 'Bitte bisheriges Passwort eingeben.',
  'ERR_ENTER_NEW_PASSWORD' => 'Bitte neues Passwort eingeben.',
  'ERR_ENTER_CONFIRMATION_PASSWORD' => 'Bitte neues Passwort wiederholen.',
  'ERR_REENTER_PASSWORDS' => 'Bitte neues Passwort erneut eingeben. Das \\"new password\\" und \\"confirm password\\" stimmen nicht miteinander �berein .',
  'ERR_INVALID_PASSWORD' => 'Sie m�ssen einen g�ltigen Benutzernamen und ein g�ltiges Passwort angeben.',
  'ERR_PASSWORD_CHANGE_FAILED_1' => '�nderung des Benutzer Passwortes ist fehlgeschlagen f�r ',
  'ERR_PASSWORD_CHANGE_FAILED_2' => ' fehlgeschlagen.  Das neue Passwort muss eingegeben werden.',
  'ERR_PASSWORD_INCORRECT_OLD' => 'Das alte Passwort f�r den Benutzer $this->user_name. Passwort Informationen bitte erneut eingeben.',
  'ERR_USER_NAME_EXISTS_1' => 'Der Benutzernamen ',
  'ERR_USER_NAME_EXISTS_2' => ' existiert bereits. Benutzernamen m�ssen eindeutig sein.',
  'ERR_LAST_ADMIN_1' => 'Der Benutzernamen ',
  'ERR_LAST_ADMIN_2' => ' ist der letzte Benutzer mit Admin Berechtigung. Mindestens 1 Benutzer muss Admin Berechtigungen besitzen.',
  'LNK_NEW_USER' => 'New User',
  'LNK_USER_LIST' => 'Users',
  'ERR_DELETE_RECORD' => 'Ein Eintrag muss ausgew�hlt sein um einen Benutzer zu l�schen.',
  'LBL_RECEIVE_NOTIFICATIONS' => 'Assignment Notification:',
  'LBL_RECEIVE_NOTIFICATIONS_TEXT' => 'Receive an e-mail notification when a record is assigned to you.',
  'LBL_ADMIN_TEXT' => 'Grants administrator privileges to this user',
  'LBL_TIME_FORMAT_TEXT' => 'Set the display format for time stamps',
  'LBL_GRIDLINE' => 'Show Gridlines:',
  'LBL_GRIDLINE_TEXT' => 'Controls gridlines on detail views',
  'LBL_CURRENCY_TEXT' => 'Select the default currency',
  'LBL_YAHOO_ID' => 'Yahoo ID:',
  'LNK_NEW_CONTACT' => 'Neuer Kontakt',
  'LNK_NEW_ACCOUNT' => 'Neuer Kunde',
  'LNK_NEW_OPPORTUNITY' => 'Neuer Auftrag',
  'LNK_NEW_CASE' => 'Neue Anfrage',
  'LNK_NEW_NOTE' => 'Neue Notiz',
  'LNK_NEW_CALL' => 'Neues Telefonat',
  'LNK_NEW_EMAIL' => 'Neue Email',
  'LNK_NEW_MEETING' => 'Neuer Termin',
  'LNK_NEW_TASK' => 'Neue Aufgabe',
);


?>