<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.2 2004/10/29 15:59:25 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Dashboard',
  'LBL_MODULE_TITLE' => 'Dashboard: Home',
  'LBL_SALES_STAGE_FORM_TITLE' => 'Total Funil por Est�gio da Venda',
  'LBL_SALES_STAGE_FORM_DESC' => 'Mostra totais aculumados das oportunidades por est�gios de vendas selecionados, de usu�rios selecionados, dentro de um per�odo previsto.',
  'LBL_MONTH_BY_OUTCOME' => 'Funil por M�s por Resultado',
  'LBL_MONTH_BY_OUTCOME_DESC' => 'Mostra totais acumulados das oportunidades por m�s e resultado para usu�rios selecionados, onde a data prevista estiver dentro de um per�odo. Resultado � baseado no est�gio de vendas.',
  'LBL_LEAD_SOURCE_FORM_TITLE' => 'Total Funil por Fonte da Oportunidade',
  'LBL_LEAD_SOURCE_FORM_DESC' => 'Mostra totais acumulados das oportunidade por fonte da oportunidade para usu�rios selecionados.',
  'LBL_LEAD_SOURCE_BY_OUTCOME' => 'Todas Oportunidades por Fonte por Resultado',
  'LBL_LEAD_SOURCE_BY_OUTCOME_DESC' => 'Mostra totais acumulados das oportunidades por fonte, resultado e usu�rios selecionados, onda a data prevista estiver dentro de um per�odo. Resultado � baseado no est�gio de vendas.',
  'LBL_PIPELINE_FORM_TITLE_DESC' => 'Mostra totais acumulados das oportunidades por est�gio de vendas selecionado para suas oportunidades onde a data prevista estiver dentro de um per�odo.',
  'LBL_DATE_RANGE' => 'Intervalo datas �',
  'LBL_DATE_RANGE_TO' => 'at�',
  'ERR_NO_OPPS' => 'Por favor crie algumas Oportunidades para ver o gr�fico de Oporunidades.',
  'LBL_TOTAL_PIPELINE' => 'Total do Funil � ',
  'LBL_ALL_OPPORTUNITIES' => 'Valor total de todas oportunidade � ',
  'LBL_OPP_SIZE' => 'Tamanho da Oportunidade em R$1K',
  'LBL_OPP_THOUSANDS' => 'K',
  'NTC_NO_LEGENDS' => 'Nada',
  'LBL_LEAD_SOURCE_OTHER' => 'Outro',
  'LBL_EDIT' => 'Editar',
  'LBL_REFRESH' => 'Atualizar',
  'LBL_CREATED_ON' => '�ltima execu��o ',
  'LBL_OPPS_IN_STAGE' => 'oportunidades cujo est�gio de vendas �',
  'LBL_OPPS_IN_LEAD_SOURCE' => 'oportunidades cuja a fonte �',
  'LBL_OPPS_OUTCOME' => 'oportunidades cujo resultado �',
  'LBL_USERS' => 'Usu�rios',
  'LBL_SALES_STAGES' => 'Est�gio Vendas',
  'LBL_LEAD_SOURCES' => 'Fonte da Oportunidade',
  'LBL_DATE_START' => 'Data In�cio',
  'LBL_DATE_END' => 'Data Fim',
  'LNK_NEW_CONTACT' => 'Novo Contato',
  'LNK_NEW_ACCOUNT' => 'Nova Conta',
  'LNK_NEW_OPPORTUNITY' => 'Nova Oportunidade',
  'LNK_NEW_QUOTE' => 'Create Quote',
  'LNK_NEW_LEAD' => 'Create Lead',
  'LNK_NEW_CASE' => 'Novo Caso',
  'LNK_NEW_NOTE' => 'Nova Nota',
  'LNK_NEW_CALL' => 'Nova Chamada',
  'LNK_NEW_MEETING' => 'Nova Reuni�o',
  'LNK_NEW_TASK' => 'Nova Tarefa',
  'LNK_NEW_EMAIL' => 'Novo Email',
);


?>