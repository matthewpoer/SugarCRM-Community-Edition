<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.2 2004/10/29 15:59:25 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Tablero',
  'LBL_MODULE_TITLE' => 'Tablero: Inicio',
  'LBL_SALES_STAGE_FORM_TITLE' => 'Estado de ventas',
  'LBL_SALES_STAGE_FORM_DESC' => 'Muestra el acumulado de las oportunidades por los estados de venta y usuarios seleccionados donde la fecha esperada de cierre este entre el rango especificado.',
  'LBL_MONTH_BY_OUTCOME' => 'Acumulado por mes y resultado',
  'LBL_MONTH_BY_OUTCOME_DESC' => 'Muestra el acumulado de las oportunidades por mes y resultado para los usuarios seleccionados donde la fecha esperada de cierre este entre el rango especificado.  El resltaodo se basa en el estado de la venta bien sea Cerrado con �xito, Cerrado con fracaso, o cualquier otro valor.',
  'LBL_LEAD_SOURCE_FORM_TITLE' => 'Todas las oportunidades por origen',
  'LBL_LEAD_SOURCE_FORM_DESC' => 'Muestra el acumulado de las oportunidades por origen para los usuarios seleccionados.',
  'LBL_LEAD_SOURCE_BY_OUTCOME' => 'Todas las oportunidades por origen y resultado',
  'LBL_LEAD_SOURCE_BY_OUTCOME_DESC' => 'Muestra el acumulado de las oportunidades por origen y monto para los usuarios y origen seleccionados donde la fecha esperada de cierre este entre el rango especificado.  El resltaodo se basa en el estado de la venta bien sea Cerrado con �xito, Cerrado con fracaso, o cualquier otro valor.',
  'LBL_PIPELINE_FORM_TITLE_DESC' => 'Muestra montos acumulados por estado de ventas seleccionado para sus oportundiades donde la fecha esperada de cierre este entre el rango especificado.',
  'LBL_DATE_RANGE' => 'Rango de fechas es',
  'LBL_DATE_RANGE_TO' => 'a',
  'ERR_NO_OPPS' => 'Porfavor crear alguna oportunidade para ver las graficas de oportunidades.',
  'LBL_TOTAL_PIPELINE' => 'El total de la gr�fica es ',
  'LBL_ALL_OPPORTUNITIES' => 'El monto total de todas las oportunidades es ',
  'LBL_OPP_SIZE' => 'Tama�o de oportunidade en $1K',
  'LBL_OPP_THOUSANDS' => 'K',
  'NTC_NO_LEGENDS' => 'Ningun',
  'LBL_LEAD_SOURCE_OTHER' => 'Otro',
  'LBL_EDIT' => 'Editar',
  'LBL_REFRESH' => 'Refrescar',
  'LBL_CREATED_ON' => 'Ultima ejecuci�n el ',
  'LBL_OPPS_IN_STAGE' => 'oportunidades donde el estado de ventas es',
  'LBL_OPPS_IN_LEAD_SOURCE' => 'oportunidades donde el origen es',
  'LBL_OPPS_OUTCOME' => 'oportunidades donde el resultado es',
  'LBL_USERS' => 'Usuarios:',
  'LBL_SALES_STAGES' => 'Estado de ventas:',
  'LBL_LEAD_SOURCES' => 'Origen:',
  'LBL_DATE_START' => 'Fecha Inicio:',
  'LBL_DATE_END' => 'Fecha Fin:',
  'LNK_NEW_CONTACT' => 'Crear Contacto',
  'LNK_NEW_ACCOUNT' => 'Crear Cuenta',
  'LNK_NEW_OPPORTUNITY' => 'Crear Oportunidad',
  'LNK_NEW_QUOTE' => 'Crear Cotizaci�n',
  'LNK_NEW_LEAD' => 'Crear Cliente',
  'LNK_NEW_CASE' => 'Crear Caso',
  'LNK_NEW_NOTE' => 'Crear Nota',
  'LNK_NEW_CALL' => 'Crear Llamada',
  'LNK_NEW_MEETING' => 'Crear Reuni�n',
  'LNK_NEW_TASK' => 'Crear Tarea',
);


?>