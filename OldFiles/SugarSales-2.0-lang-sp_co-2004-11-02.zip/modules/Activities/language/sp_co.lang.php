<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.2 2004/10/29 15:59:25 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Actividades',
  'LBL_MODULE_TITLE' => 'Actividades: Inicio',
  'LBL_SEARCH_FORM_TITLE' => 'Buscar Actividades',
  'LBL_LIST_FORM_TITLE' => 'Lista de Actividades',
  'LBL_LIST_SUBJECT' => 'Asunto',
  'LBL_LIST_CONTACT' => 'Contacto',
  'LBL_LIST_RELATED_TO' => 'Relacionado a',
  'LBL_LIST_DATE' => 'Fecha',
  'LBL_LIST_TIME' => 'Hora Inicio',
  'LBL_LIST_CLOSE' => 'Cerrar',
  'LBL_SUBJECT' => 'Asunto:',
  'LBL_STATUS' => 'Estado:',
  'LBL_LOCATION' => 'Localizaci�n:',
  'LBL_DATE_TIME' => 'Fecha y Hora de Inicio:',
  'LBL_DATE' => 'Fecha de Inicio:',
  'LBL_TIME' => 'Hora de Inicio:',
  'LBL_DURATION' => 'Duraci�n:',
  'LBL_HOURS_MINS' => '(horas/minutos)',
  'LBL_CONTACT_NAME' => 'Nombre del Contacto: ',
  'LBL_MEETING' => 'Reuni�n:',
  'LBL_DESCRIPTION_INFORMATION' => 'Informaci�n Descriptiva',
  'LBL_DESCRIPTION' => 'Descripci�n:',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'Planeada',
  'LNK_NEW_CALL' => 'Crear Llamada',
  'LNK_NEW_MEETING' => 'Crear Reuni�n',
  'LNK_NEW_TASK' => 'Crear Tarea',
  'LNK_NEW_NOTE' => 'Crear Nota',
  'LNK_NEW_EMAIL' => 'Crear Email',
  'LNK_CALL_LIST' => 'Llamadas',
  'LNK_MEETING_LIST' => 'Reuniones',
  'LNK_TASK_LIST' => 'Tareas',
  'LNK_NOTE_LIST' => 'Notas',
  'LNK_EMAIL_LIST' => 'Emails',
  'ERR_DELETE_RECORD' => 'Un numero de registro debe ser seleccionado para borrar la cuenta.',
  'NTC_REMOVE_INVITEE' => 'Esta seguro de quitar este invitado de la reuni�n?',
  'LBL_INVITEE' => 'Invitados',
  'LBL_LIST_DIRECTION' => 'Direcci�n',
  'LBL_DIRECTION' => 'Direcci�n',
  'LNK_NEW_APPOINTMENT' => 'Nueva Sita',
  'LNK_VIEW_CALENDAR' => 'Hoy',
  'LBL_OPEN_ACTIVITIES' => 'Actividades Abiertas',
  'LBL_HISTORY' => 'Historial',
  'LBL_UPCOMING' => 'Mis Pr�ximas Actividades',
  'LBL_TODAY' => 'hasta ',
  'LBL_NEW_TASK_BUTTON_TITLE' => 'Crear Tarea [Alt+N]',
  'LBL_NEW_TASK_BUTTON_KEY' => 'N',
  'LBL_NEW_TASK_BUTTON_LABEL' => 'Crear Tarea',
  'LBL_SCHEDULE_MEETING_BUTTON_TITLE' => 'Programar Reuni�n [Alt+M]',
  'LBL_SCHEDULE_MEETING_BUTTON_KEY' => 'M',
  'LBL_SCHEDULE_MEETING_BUTTON_LABEL' => 'Programar Reuni�n',
  'LBL_SCHEDULE_CALL_BUTTON_TITLE' => 'Programar Llamada [Alt+C]',
  'LBL_SCHEDULE_CALL_BUTTON_KEY' => 'C',
  'LBL_SCHEDULE_CALL_BUTTON_LABEL' => 'Programar Llamada',
  'LBL_NEW_NOTE_BUTTON_TITLE' => 'Crear Nota [Alt+T]',
  'LBL_NEW_NOTE_BUTTON_KEY' => 'T',
  'LBL_NEW_NOTE_BUTTON_LABEL' => 'Crear Nota',
  'LBL_TRACK_EMAIL_BUTTON_TITLE' => 'Guardar Email [Alt+K]',
  'LBL_TRACK_EMAIL_BUTTON_KEY' => 'K',
  'LBL_TRACK_EMAIL_BUTTON_LABEL' => 'Guardar Email',
  'LBL_LIST_STATUS' => 'Estado',
  'LBL_LIST_DUE_DATE' => 'Fecha L�mite',
  'LBL_LIST_LAST_MODIFIED' => 'Ultimas Modificaciones',
  'NTC_NONE_SCHEDULED' => 'Nada Programado.',
);


?>