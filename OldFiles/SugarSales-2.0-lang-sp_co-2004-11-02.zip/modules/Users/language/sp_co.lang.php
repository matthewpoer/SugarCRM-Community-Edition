<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.2 2004/10/29 15:59:25 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Usuarios',
  'LBL_MODULE_TITLE' => 'Usuarios: Inicio',
  'LBL_SEARCH_FORM_TITLE' => 'Buscar Usuarios',
  'LBL_LIST_FORM_TITLE' => 'Usuarios',
  'LBL_NEW_FORM_TITLE' => 'Nuevo Usuario',
  'LBL_USER' => 'Usuarios:',
  'LBL_LOGIN' => 'Login',
  'LBL_RESET_PREFERENCES' => 'Volver a preferencias preestablecidas',
  'LBL_TIME_FORMAT' => 'Formato de hora:',
  'LBL_CURRENCY' => 'Moneda:',
  'LBL_LIST_NAME' => 'Nombre',
  'LBL_LIST_LAST_NAME' => 'Apellido',
  'LBL_LIST_USER_NAME' => 'Nombre de Usuario',
  'LBL_LIST_DEPARTMENT' => 'Departamento',
  'LBL_LIST_EMAIL' => 'Email',
  'LBL_LIST_PRIMARY_PHONE' => 'Tel�fono Principal',
  'LBL_LIST_ADMIN' => 'Admin',
  'LBL_NEW_USER_BUTTON_TITLE' => 'Nuevo Usuario [Alt+N]',
  'LBL_NEW_USER_BUTTON_LABEL' => 'Nuevo Usuario',
  'LBL_NEW_USER_BUTTON_KEY' => 'N',
  'LBL_ERROR' => 'Error:',
  'LBL_PASSWORD' => 'Calve:',
  'LBL_USER_NAME' => 'Nombre de Usuario:',
  'LBL_FIRST_NAME' => 'Nombre:',
  'LBL_LAST_NAME' => 'Apellido:',
  'LBL_USER_SETTINGS' => 'Configuraci�n de Usuario',
  'LBL_THEME' => 'Tema:',
  'LBL_LANGUAGE' => 'Lenguaje:',
  'LBL_ADMIN' => 'Administrador:',
  'LBL_USER_INFORMATION' => 'Informaci�n de Usuario',
  'LBL_OFFICE_PHONE' => 'Tel�fono Oficina:',
  'LBL_REPORTS_TO' => 'Reporta a:',
  'LBL_OTHER_PHONE' => 'Otro:',
  'LBL_OTHER_EMAIL' => 'Otro Email:',
  'LBL_NOTES' => 'Notas:',
  'LBL_DEPARTMENT' => 'Departamento:',
  'LBL_STATUS' => 'Estatus:',
  'LBL_TITLE' => 'Cargo:',
  'LBL_ANY_PHONE' => 'Otro Tel�fono:',
  'LBL_ANY_EMAIL' => 'Otro Email:',
  'LBL_ADDRESS' => 'Direcci�n:',
  'LBL_CITY' => 'Ciudad:',
  'LBL_STATE' => 'Estado:',
  'LBL_POSTAL_CODE' => 'C�digo Postal:',
  'LBL_COUNTRY' => 'Pa�s:',
  'LBL_NAME' => 'Nombre:',
  'LBL_MOBILE_PHONE' => 'Celular:',
  'LBL_OTHER' => 'Otro:',
  'LBL_FAX' => 'Fax:',
  'LBL_EMAIL' => 'Email:',
  'LBL_HOME_PHONE' => 'Tel�fono Casa:',
  'LBL_ADDRESS_INFORMATION' => 'Informacion Localizaci�n',
  'LBL_PRIMARY_ADDRESS' => 'Direcci�n Principal:',
  'LBL_CHANGE_PASSWORD_BUTTON_TITLE' => 'Cambiar clave [Alt+P]',
  'LBL_CHANGE_PASSWORD_BUTTON_KEY' => 'P',
  'LBL_CHANGE_PASSWORD_BUTTON_LABEL' => 'Cambiar clave',
  'LBL_LOGIN_BUTTON_TITLE' => 'Login [Alt+L]',
  'LBL_LOGIN_BUTTON_KEY' => 'L',
  'LBL_LOGIN_BUTTON_LABEL' => 'Login',
  'LBL_CHANGE_PASSWORD' => 'Cambiar clave',
  'LBL_OLD_PASSWORD' => 'Clave antigua:',
  'LBL_NEW_PASSWORD' => 'Clave nueva:',
  'LBL_CONFIRM_PASSWORD' => 'Confirmar clave:',
  'ERR_ENTER_OLD_PASSWORD' => 'Porfavor ingrese su vieja clave.',
  'ERR_ENTER_NEW_PASSWORD' => 'Porfavor ingrese su nueva clave.',
  'ERR_ENTER_CONFIRMATION_PASSWORD' => 'Porfavor ingrese su confirmaci�n de clave.',
  'ERR_REENTER_PASSWORDS' => 'Porfavor reingrese clave.  La \\"nueva clave\\" y \\"confirmaci�n de clave\\" no coincide.',
  'ERR_INVALID_PASSWORD' => 'Usted debe especificar un usuario y calve validos.',
  'ERR_PASSWORD_CHANGE_FAILED_1' => 'Cambio de clave fallo por ',
  'ERR_PASSWORD_CHANGE_FAILED_2' => ' fallo.  La nueva clave debe ser colocada.',
  'ERR_PASSWORD_INCORRECT_OLD' => 'Clave antigua incorrecta para el usuario $this->user_name. Reingrese la clave.',
  'ERR_USER_NAME_EXISTS_1' => 'El usuario ',
  'ERR_USER_NAME_EXISTS_2' => ' existe.  No se permiten usuarios duplicados.<br>Cambie el nombre de usuario por uno nuevo.',
  'ERR_LAST_ADMIN_1' => 'El usuario ',
  'ERR_LAST_ADMIN_2' => ' es el �ltimo usuario Administrador.  Al menos un usuario debe ser Administrador.<br>Seleccione los parametros del usuario Administrador.',
  'LNK_NEW_USER' => 'Nuevo Usuario',
  'LNK_USER_LIST' => 'Usuarios',
  'ERR_DELETE_RECORD' => 'Un n�mero de registro debe ser especificado para borrar la cuenta.',
  'LBL_RECEIVE_NOTIFICATIONS' => 'Notificaci�n de asignaci�n:',
  'LBL_RECEIVE_NOTIFICATIONS_TEXT' => 'Recivir una notificaci�n por e-mail cuando un registro sea asignado a usted.',
  'LBL_ADMIN_TEXT' => 'Dar privilegios de Administrador a este usuario',
  'LBL_TIME_FORMAT_TEXT' => 'Colocar formato a las marcas de tiempo',
  'LBL_GRIDLINE' => 'Ver grilla:',
  'LBL_GRIDLINE_TEXT' => 'Controlar grilla en vistas detalladas',
  'LBL_CURRENCY_TEXT' => 'Seleccionar moneda por defecto',
);


?>