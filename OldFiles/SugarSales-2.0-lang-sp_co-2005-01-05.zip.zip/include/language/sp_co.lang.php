<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/modules/Accounts/Account.php,v 1.92 2004/11/10 22:27:36 clint Exp $
 * Description:
 ********************************************************************************/

$app_list_strings = array (
  'moduleList' => 
  array (
//to translate, only modify the right value in each key/value pair
    'Home' => 'Inicio',
//e.g. auf Deutsch 'Contacts'=>'Contakten',
    'Dashboard' => 'Tablero',
    'Contacts' => 'Contactos',
    'Accounts' => 'Cuentas',
    'Opportunities' => 'Oportunidades',
    'Cases' => 'Casos',
    'Notes' => 'Notas',
    'Calls' => 'Llamadas',
    'Emails' => 'Emails',
    'Meetings' => 'Reuniones',
    'Tasks' => 'Tareas',
    'Calendar' => 'Calendario',
    'Leads' => 'Candidatos',
    'Activities' => 'Actividades',
  ),
  'account_type_dom' => 
  array (
    '' => '',
    'Analyst' => 'Analista',
    'Competitor' => 'Competencia',
    'Customer' => 'Cliente',
    'Integrator' => 'Integrador',
    'Investor' => 'Inversionista',
  //e.g. en fran�ais 'Analyst'=>'Analyste',
    'Partner' => 'Socio',
    'Press' => 'Prensa',
    'Prospect' => 'Prospecto',
    'Reseller' => 'Revendedor',
    'Other' => 'Otro',
  ),
  'industry_dom' => 
  array (
    '' => '',
    'Apparel' => 'Vestuario',
    'Banking' => 'Banca',
    'Biotechnology' => 'Biotecnolog�a',
    'Chemicals' => 'Quimicos',
    'Communications' => 'Comunicaciones',
  //e.g. en espa�ol 'Apparel'=>'Ropa',
    'Construction' => 'Construcci�n',
    'Consulting' => 'Consultor�a',
    'Education' => 'Educaci�n',
    'Electronics' => 'Electr�nica',
    'Energy' => 'Energ�a',
    'Engineering' => 'Ingenier�a',
    'Entertainment' => 'Entretenimiento',
    'Environmental' => 'Medioambiente',
    'Finance' => 'Financiero',
    'Food & Beverage' => 'Alimentos y Bebidas',
    'Government' => 'Gubernamental',
    'Healthcare' => 'Salud',
    'Hospitality' => 'Caridad',
    'Insurance' => 'Seguros',
    'Machinery' => 'Maquinaria',
    'Manufacturing' => 'Manufacuras',
    'Media' => 'Medios de Communicaci�n',
    'Not For Profit' => 'Sin �nimo de lucro',
    'Recreation' => 'Recreaci�n',
    'Retail' => 'Vetas pormenor',
    'Shipping' => 'Envios',
    'Technology' => 'Tecnolog�a',
    'Telecommunications' => 'Telecomunicaciones',
    'Transportation' => 'Transporte',
    'Utilities' => 'Servicios p�blicos',
    'Other' => 'Otro',
  ),
  'lead_source_dom' => 
  array (
    '' => '',
    'Cold Call' => 'Llamada',
    'Existing Customer' => 'Cliente Existente',
    'Self Generated' => 'Auto Generada',
    'Employee' => 'Empleado',
    'Partner' => 'Socio',
    'Public Relations' => 'Relaciones Publicas',
    'Direct Mail' => 'Correo Directo',
    'Conference' => 'Conferencia',
    'Trade Show' => 'Feria',
    'Web Site' => 'P�gina Web',
    'Word of mouth' => 'Referido',
    'Other' => 'Otro',
  ),
  'opportunity_type_dom' => 
  array (
    '' => '',
    'Existing Business' => 'Negocio Existente',
    'New Business' => 'Nuevo Negocio',
  ),
  'opportunity_relationship_type_default_key' => 'Primary Decision Maker',
  'opportunity_relationship_type_dom' => 
  array (
    '' => '',
    'Primary Decision Maker' => 'Principal Tomador de Decision',
    'Business Decision Maker' => 'Decisi�n de Negocio',
    'Business Evaluator' => 'Evaluaci�n de Negocio',
    'Technical Decision Maker' => 'Decisi�n Tecnica',
//       it is the key for the default opportunity_relationship_type_dom value
    'Technical Evaluator' => 'Evaluaci�n Tecnica',
    'Executive Sponsor' => 'Patrocinador',
    'Influencer' => 'Influencia',
    'Other' => 'Otro',
  ),
  'case_relationship_type_default_key' => 'Primary Contact',
  'case_relationship_type_dom' => 
  array (
    '' => '',
    'Primary Contact' => 'Contacto Principal',
    'Alternate Contact' => 'Contacto Alterno',
  ),
  'sales_stage_dom' => 
//       it is the key for the default case_relationship_type_dom value
  array (
    'Prospecting' => 'Prospecto',
    'Qualification' => 'Calificaci�n',
    'Needs Analysis' => 'Necesita an�lisis',
    'Value Proposition' => 'Proposici�n de valor',
    'Id. Decision Makers' => 'Toma decisi�n',
    'Perception Analysis' => 'Analisis de percepci�n',
    'Proposal/Price Quote' => 'Propuesta/Cotiaci�n',
    'Negotiation/Review' => 'Negociacio�n/Revisi�n',
    'Closed Won' => 'Ganado',
    'Closed Lost' => 'Perdido',
  ),
  'activity_dom' => 
  array (
    'Call' => 'Llamada',
    'Meeting' => 'Reuni�n',
    'Task' => 'Tarea',
    'Email' => 'Email',
    'Note' => 'Nota',
  ),
  'salutation_dom' => 
  array (
    '' => '',
    'Mr.' => 'Sr.',
    'Ms.' => 'Sra.',
    'Mrs.' => 'Srta.',
    'Dr.' => 'Dr.',
    'Prof.' => 'Prof.',
  ),
  'task_priority_dom' => 
  array (
    'High' => 'Alto',
    'Medium' => 'Medio',
    'Low' => 'Bajo',
  ),
  'task_status_dom' => 
  array (
    'Not Started' => 'No Iniciado',
    'In Progress' => 'En Progreso',
    'Completed' => 'Completado',
    'Pending Input' => 'Entrada Pendiente',
    'Deferred' => 'Aplazado',
  ),
  'meeting_status_dom' => 
  array (
    'Planned' => 'Planeado',
    'Held' => 'Realizado',
    'Not Held' => 'No Realizado',
  ),
  'call_status_dom' => 
  array (
    'Planned' => 'Planeado',
    'Held' => 'Realizada',
    'Not Held' => 'No Realizada',
  ),
  'call_direction_dom' => 
  array (
    'Inbound' => 'Entrante',
    'Outbound' => 'Saliente',
  ),
  'lead_status_dom' => 
  array (
    '' => '',
    'New' => 'Nuevo',
    'Assigned' => 'Asignado',
    'In Process' => 'En Proceso',
    'Converted' => 'Convertido',
    'Recycled' => 'Reciclado',
    'Dead' => 'Muerto',
  ),
  'lead_status_noblank_dom' => 
  array (
    'New' => 'Nuevo',
    'Assigned' => 'Asignado',
    'In Process' => 'En Proceso',
    'Converted' => 'Convertido',
    'Recycled' => 'Reciclado',
    'Dead' => 'Muerto',
  ),
  'case_status_default_key' => 'New',
  'case_status_dom' => 
  array (
    'New' => 'Nuevo',
    'Assigned' => 'Asignado',
    'Closed' => 'Cerrado',
    'Pending Input' => 'Entrada Pendiente',
    'Rejected' => 'Rechazado',
//       it is the key for the default case_status_dom value
  ),
  'case_priority_default_key' => 'P2',
  'case_priority_dom' => 
  array (
    'P1' => 'Alto',
    'P2' => 'Medio',
    'P3' => 'Bajo',
  ),
  'user_status_dom' => 
  array (
    'Active' => 'Activo',
    'Inactive' => 'Inactivo',
  ),
  'record_type_default_key' => 'Accounts',
  'record_type_display' => 
  array (
    'Accounts' => 'Cuentas',
    'Opportunities' => 'Oportunidades',
    'Cases' => 'Casos',
    'Leads' => 'Candidatos',
  ),
//       it is the key for the default record_type_module value
  'notifymail_sendtype' => 
  array (
    'sendmail' => 'sendmail',
    'SMTP' => 'SMTP',
  ),
);

$app_strings = array (
  'LBL_CHARSET' => 'ISO-8859-1',
  'LBL_BROWSER_TITLE' => 'SugarCRM - CRM Comercial de Codigo Abierto',
  'LBL_MY_ACCOUNT' => 'Mi Cuenta',
  'LBL_ADMIN' => 'Admin',
  'LBL_LOGOUT' => 'Salir',
  'LBL_SEARCH' => 'Buscar',
  'LBL_LAST_VIEWED' => 'Recientes',
  'NTC_WELCOME' => 'Bienvenido',
  'NTC_SUPPORT_SUGARCRM' => 'Soporte el preyecto SugarCRM de codigo abierto con una donaci�n a travez de PayPal - es r�pido, gratis y seguro!',
  'NTC_NO_ITEMS_DISPLAY' => 'ninguno',
  'LBL_ALT_HOT_KEY' => 'Alt+',
  'LBL_SAVE_BUTTON_TITLE' => 'Grabar [Alt+S]',
  'LBL_EDIT_BUTTON_TITLE' => 'Editar [Alt+E]',
  'LBL_EDIT_BUTTON' => 'Editar',
  'LBL_DUPLICATE_BUTTON_TITLE' => 'Duplicar [Alt+U]',
  'LBL_DUPLICATE_BUTTON' => 'Duplicar',
  'LBL_DELETE_BUTTON_TITLE' => 'Borrar [Alt+D]',
  'LBL_DELETE_BUTTON' => 'Borrar',
  'LBL_NEW_BUTTON_TITLE' => 'Crear [Alt+N]',
  'LBL_CHANGE_BUTTON_TITLE' => 'Cambiar [Alt+G]',
  'LBL_CANCEL_BUTTON_TITLE' => 'Cancelar [Alt+X]',
  'LBL_SEARCH_BUTTON_TITLE' => 'Buscar [Alt+Q]',
  'LBL_CLEAR_BUTTON_TITLE' => 'Limpiar [Alt+C]',
  'LBL_SELECT_BUTTON_TITLE' => 'Seleccionar [Alt+T]',
  'LBL_SAVE_BUTTON_KEY' => 'S',
  'LBL_EDIT_BUTTON_KEY' => 'E',
  'LBL_DUPLICATE_BUTTON_KEY' => 'U',
  'LBL_DELETE_BUTTON_KEY' => 'D',
  'LBL_NEW_BUTTON_KEY' => 'N',
  'LBL_CHANGE_BUTTON_KEY' => 'G',
  'LBL_CANCEL_BUTTON_KEY' => 'X',
  'LBL_SEARCH_BUTTON_KEY' => 'Q',
  'LBL_CLEAR_BUTTON_KEY' => 'C',
  'LBL_SELECT_BUTTON_KEY' => 'T',
  'LBL_SAVE_BUTTON_LABEL' => 'Grabar',
  'LBL_EDIT_BUTTON_LABEL' => 'Editar',
  'LBL_DUPLICATE_BUTTON_LABEL' => 'Duplicar',
  'LBL_DELETE_BUTTON_LABEL' => 'Borrar',
  'LBL_NEW_BUTTON_LABEL' => 'Crear',
  'LBL_CHANGE_BUTTON_LABEL' => 'Cambiar',
  'LBL_CANCEL_BUTTON_LABEL' => 'Cancelar',
  'LBL_SEARCH_BUTTON_LABEL' => 'Buscar',
  'LBL_CLEAR_BUTTON_LABEL' => 'Limpiar',
  'LBL_NEXT_BUTTON_LABEL' => 'Siguiente',
  'LBL_SELECT_BUTTON_LABEL' => 'Seleccionar',
  'LBL_SELECT_CONTACT_BUTTON_TITLE' => 'Seleccionar Contacto [Alt+T]',
  'LBL_SELECT_CONTACT_BUTTON_KEY' => 'T',
  'LBL_VIEW_PDF_BUTTON_LABEL' => 'Ver PDF',
  'LBL_VIEW_PDF_CONTACT_BUTTON_TITLE' => 'Ver PDF [Alt+P]',
  'LBL_VIEW_PDF_CONTACT_BUTTON_KEY' => 'P',
  'LBL_SELECT_CONTACT_BUTTON_LABEL' => 'Seleccionar Contacto',
  'LBL_SELECT_USER_BUTTON_TITLE' => 'Seleccionar Usuario [Alt+U]',
  'LBL_SELECT_USER_BUTTON_KEY' => 'U',
  'LBL_SELECT_USER_BUTTON_LABEL' => 'Seleccionar Usuario',
  'LBL_CREATE_BUTTON_LABEL' => 'Crear',
  'LBL_SHORTCUTS' => 'Atajo',
  'LBL_LIST_NAME' => 'Nombre',
  'LBL_LIST_USER_NAME' => 'Nombre de Usuario',
  'LBL_LIST_EMAIL' => 'Email',
  'LBL_LIST_PHONE' => 'Tel�fono',
  'LBL_LIST_CONTACT_NAME' => 'Nombre del Contacto',
  'LBL_LIST_CONTACT_ROLE' => 'Rol del Contacto',
  'LBL_LIST_ACCOUNT_NAME' => 'Nombre de la Cuenta',
  'LBL_USER_LIST' => 'Lista de Usuarios',
  'LBL_CONTACT_LIST' => 'Lista de Contactos',
  'LBL_RELATED_RECORDS' => 'Registors Relacionados',
  'LBL_MASS_UPDATE' => 'Actualizacion Masiva',
  'LNK_ADVANCED_SEARCH' => 'Avanzada',
  'LNK_BASIC_SEARCH' => 'Basica',
  'LNK_EDIT' => 'editar',
  'LNK_REMOVE' => 'remover',
  'LNK_DELETE' => 'borrar',
  'LNK_LIST_START' => 'Inicio',
  'LNK_LIST_NEXT' => 'Siguiente',
  'LNK_LIST_PREVIOUS' => 'Previo',
  'LNK_LIST_END' => 'Fin',
  'LBL_LIST_OF' => 'de',
  'LBL_OR' => 'O',
  'LNK_PRINT' => 'Imprimir',
  'LNK_HELP' => 'Ayuda',
  'LNK_ABOUT' => 'Acerca',
  'NTC_REQUIRED' => 'Indica un campo requerido',
  'LBL_REQUIRED_SYMBOL' => '*',
  'LBL_CURRENCY_SYMBOL' => '$',
  'LBL_PERCENTAGE_SYMBOL' => '%',
  'LBL_THOUSANDS_SYMBOL' => 'K',
  'NTC_DATE_FORMAT' => '(yyyy-mm-dd)',
  'NTC_TIME_FORMAT' => '(24:00)',
  'NTC_DATE_TIME_FORMAT' => '(yyyy-mm-dd 24:00)',
  'NTC_DELETE_CONFIRMATION' => 'Esta seguro de querer borrar este registro?',
  'ERR_DELETE_RECORD' => 'Un numero de registro debe ser especificado para borrar el contacto.',
  'ERR_CREATING_TABLE' => 'Error creando tabla: ',
  'ERR_CREATING_FIELDS' => 'Error llenando campos de detalles adicionales: ',
  'ERR_MISSING_REQUIRED_FIELDS' => 'Faltan campos requeridos:',
  'ERR_INVALID_EMAIL_ADDRESS' => 'direcci�n de email no v�lida.',
  'ERR_INVALID_DATE_FORMAT' => 'El formato de la fecha debe ser: yyyy-mm-dd',
  'ERR_INVALID_MONTH' => 'Porfavor ingrese un mes v�lido.',
  'ERR_INVALID_DAY' => 'Porfavor ingrese un d�a v�lido.',
  'ERR_INVALID_YEAR' => 'Porfavor ingrese un a�o v�lido (4 digitos).',
  'ERR_INVALID_DATE' => 'Porfavor ingrese una fecha v�lida.',
  'ERR_INVALID_HOUR' => 'Porfavor ingrese una hora v�lida.',
  'ERR_INVALID_TIME' => 'Porfavor ingrese una hora v�lida.',
  'ERR_INVALID_AMOUNT' => 'Porfavor ingrese un monto v�lido.',
  'NTC_CLICK_BACK' => 'Porfavor regrese en el browser y arregle el error.',
  'LBL_LIST_ASSIGNED_USER' => 'Usuario',
  'LBL_ASSIGNED_TO' => 'Asignado a:',
  'LBL_DATE_MODIFIED' => 'Ultima Modificaci�n:',
  'LBL_DATE_ENTERED' => 'Creado:',
  'LBL_CURRENT_USER_FILTER' => 'Solo mis items:',
  'NTC_LOGIN_MESSAGE' => 'Porfavor ingrese su usuario y password.',
  'LBL_NONE' => '--Ninguno--',
  'LBL_BACK' => 'Regresar',
  'LBL_IMPORT' => 'Importar',
  'LBL_EXPORT' => 'Exportar',
  'LBL_EXPORT_ALL' => 'Exportar Todo',
  'LBL_SAVE_NEW_BUTTON_TITLE' => 'Grabar y Crear Nuevo [Alt+V]',
  'LBL_SAVE_NEW_BUTTON_KEY' => 'V',
  'LBL_SAVE_NEW_BUTTON_LABEL' => 'Grabar y Crear Nuevo',
  'LBL_NAME' => 'Nombre',
  'LBL_SUBJECT' => 'Asunto',
);


?>