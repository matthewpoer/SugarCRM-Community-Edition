<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/modules/Accounts/Account.php,v 1.92 2004/11/10 22:27:36 clint Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Casos',
  'LBL_MODULE_TITLE' => 'Casos: Inicio',
  'LBL_SEARCH_FORM_TITLE' => 'Buscar Caso',
  'LBL_LIST_FORM_TITLE' => 'Lista de Casos',
  'LBL_NEW_FORM_TITLE' => 'Nuevo Caso',
  'LBL_CONTACT_CASE_TITLE' => 'Contacto-Caso:',
  'LBL_SUBJECT' => 'Asunto:',
  'LBL_CASE' => 'Caso:',
  'LBL_CASE_NUMBER' => 'Numero de Caso:',
  'LBL_NUMBER' => 'Numero:',
  'LBL_STATUS' => 'Estado:',
  'LBL_PRIORITY' => 'Prioridad:',
  'LBL_ACCOUNT_NAME' => 'Nombre de la Cuenta:',
  'LBL_DESCRIPTION' => 'Descripci�n:',
  'LBL_CONTACT_NAME' => 'Nombre del Contacto:',
  'LBL_CASE_SUBJECT' => 'Asunto del Caso:',
  'LBL_CONTACT_ROLE' => 'Rol:',
  'LBL_LIST_NUMBER' => 'Num.',
  'LBL_LIST_SUBJECT' => 'Asunto',
  'LBL_LIST_ACCOUNT_NAME' => 'Nombre Cuenta',
  'LBL_LIST_STATUS' => 'Estado',
  'LBL_LIST_PRIORITY' => 'Prioridad',
  'LBL_LIST_LAST_MODIFIED' => 'Ultimas Modificaciones',
  'LBL_INVITEE' => 'Contactos',
  'LNK_NEW_CASE' => 'Crear Caso',
  'LNK_CASE_LIST' => 'Casos',
  'NTC_REMOVE_INVITEE' => 'Esta usted seguro de querer remover este contacto del caso?',
  'ERR_DELETE_RECORD' => 'Un numero de registro debe ser seleccionado para borrar la cuenta.',
);


?>