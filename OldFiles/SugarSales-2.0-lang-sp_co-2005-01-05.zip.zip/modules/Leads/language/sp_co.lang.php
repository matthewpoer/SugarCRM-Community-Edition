<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/modules/Accounts/Account.php,v 1.92 2004/11/10 22:27:36 clint Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Candidatos',
  'LBL_INVITEE' => 'Reportan',
  'LBL_MODULE_TITLE' => 'Candidatos: Inicio',
  'LBL_SEARCH_FORM_TITLE' => 'Buscar Candidato',
  'LBL_LIST_FORM_TITLE' => 'Lista Candidatos',
  'LBL_NEW_FORM_TITLE' => 'Nuevo Candidato',
  'LBL_CONTACT_OPP_FORM_TITLE' => 'Candidato-Oportunidad:',
  'LBL_CONTACT' => 'Candidato:',
  'LBL_BUSINESSCARD' => 'Convertir Candidato',
  'LBL_LIST_NAME' => 'Nombre',
  'LBL_LIST_LAST_NAME' => 'Apellido',
  'LBL_LIST_CONTACT_NAME' => 'Candidato',
  'LBL_LIST_TITLE' => 'Cargo',
  'LBL_LIST_ACCOUNT_NAME' => 'Nombre Cuenta',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email',
  'LBL_LIST_PHONE' => 'Tel�fono',
  'LBL_LIST_CONTACT_ROLE' => 'Rol',
  'LBL_LIST_FIRST_NAME' => 'Nombre',
  'LBL_LIST_REFERED_BY' => 'Referrido por',
  'LBL_LIST_LEAD_SOURCE' => 'Origen',
  'LBL_LIST_STATUS' => 'Estatus',
  'LBL_LIST_DATE_ENTERED' => 'Fecha creaci�n',
  'LBL_LIST_LEAD_SOURCE_DESCRIPTION' => 'Descripci�n Origen',
  'LBL_LIST_MY_LEADS' => 'Mis Candidatos',
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_account_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_email2' => 'LBL_LIST_EMAIL_ADDRESS',
  'LBL_EXISTING_CONTACT' => 'Contacto exitente',
  'LBL_CREATED_CONTACT' => 'Crear nuevo contacto',
  'LBL_EXISTING_OPPORTUNITY' => 'Oportunidad existente',
  'LBL_CREATED_OPPORTUNITY' => 'Crear nueva oportunidad',
//END DON'T CONVERT
  'LBL_EXISTING_ACCOUNT' => 'Cuenta existente',
  'LBL_CREATED_ACCOUNT' => 'Crear nueva cuenta',
  'LBL_CREATED_CALL' => 'Crear nueva llamada',
  'LBL_CREATED_MEETING' => 'Crear nueva reuni�n',
  'LBL_BACKTOLEADS' => 'Volver a candidatos',
  'LBL_CONVERTLEAD' => 'Convertir candidatos',
  'LBL_NAME' => 'Nombre:',
  'LBL_CONTACT_NAME' => 'Nombre:',
  'LBL_CONTACT_INFORMATION' => 'Informaci�n',
  'LBL_FIRST_NAME' => 'Nombre:',
  'LBL_OFFICE_PHONE' => 'Tel�fono Oficina:',
  'LBL_ACCOUNT_NAME' => 'Nombre Cuenta:',
  'LBL_OPPORTUNITY_NAME' => 'Nombre Oportunidad:',
  'LBL_OPPORTUNITY_AMOUNT' => 'Monto Oportunidad:',
  'LBL_ANY_PHONE' => 'Otro Tel�fono:',
  'LBL_PHONE' => 'Tel�fono:',
  'LBL_LAST_NAME' => 'Apellido:',
  'LBL_MOBILE_PHONE' => 'Celular:',
  'LBL_HOME_PHONE' => 'Casa:',
  'LBL_LEAD_SOURCE' => 'Origen:',
  'LBL_STATUS' => 'Estatus:',
  'LBL_LEAD_SOURCE_DESCRIPTION' => 'descripci�n origen:',
  'LBL_STATUS_DESCRIPTION' => 'Descripci�n estatus:',
  'LBL_OTHER_PHONE' => 'Otro tel�fono:',
  'LBL_FAX_PHONE' => 'Fax:',
  'LBL_TITLE' => 'Cargo:',
  'LBL_DEPARTMENT' => 'Departamento:',
  'LBL_EMAIL_ADDRESS' => 'Email:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Otro Email:',
  'LBL_ANY_EMAIL' => 'Otro Email:',
  'LBL_REPORTS_TO' => 'Reporta a:',
  'LBL_DO_NOT_CALL' => 'No Llamar:',
  'LBL_EMAIL_OPT_OUT' => 'Enviar Email:',
  'LBL_PRIMARY_ADDRESS' => 'Direcci�n Principal:',
  'LBL_ALTERNATE_ADDRESS' => 'Otra Direcci�n:',
  'LBL_ANY_ADDRESS' => 'Otra Direcci�n:',
  'LBL_REFERED_BY' => 'Referdio por:',
  'LBL_CITY' => 'Ciudad:',
  'LBL_STATE' => 'Estado:',
  'LBL_POSTAL_CODE' => 'C�digo Postal:',
  'LBL_COUNTRY' => 'Pa�s:',
  'LBL_DESCRIPTION_INFORMATION' => 'Informaci�n Descriptiva',
  'LBL_ADDRESS_INFORMATION' => 'Informaci�n Localizaci�n',
  'LBL_DESCRIPTION' => 'Descripci�n:',
  'LBL_CONTACT_ROLE' => 'Rol:',
  'LBL_OPP_NAME' => 'Nombre Oportunidad:',
  'LBL_IMPORT_VCARD' => 'Importar vCard',
  'LNK_IMPORT_VCARD' => 'Crear Desde vCard',
  'LBL_IMPORT_VCARDTEXT' => 'Automaticamente crear nuevo candidato importando la vCard desde su sistema de archivo.',
  'LBL_DUPLICATE' => 'Candidatos similares',
  'MSG_DUPLICATE' => 'Candidatos similares han sido encontrados. Porfavor seleccione cualquier candidato que desee asosiar con el registro que va a crear con esta conversion. Una vez hecho, porfavor seleccione siguiente.',
  'LBL_ADD_BUSINESSCARD' => 'Adicionar Tarjeta',
  'LNK_NEW_APPOINTMENT' => 'Crear Cita',
  'LNK_NEW_LEAD' => 'Crear Candidato',
  'LNK_LEAD_LIST' => 'Candidatos',
  'NTC_DELETE_CONFIRMATION' => 'Esta seguro de querer borrar este registro?',
  'NTC_REMOVE_CONFIRMATION' => 'Esta seguro de querer remover este candidato de este caso?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Esta seguro de querer remover este registro como reporte directo?',
  'ERR_DELETE_RECORD' => 'Un numero de registro debe ser especificado para borrar el candidato.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Copiar direcci�n principal a direcci�n alterna',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Copiar direcci�n alterna a direcci�n principal',
  'LNK_NEW_CONTACT' => 'Crear Contacto',
  'LNK_NEW_NOTE' => 'Crear Nota',
  'LNK_NEW_ACCOUNT' => 'Crear Cuenta',
  'LNK_NEW_OPPORTUNITY' => 'Crear Oportunidad',
  'LNK_SELECT_ACCOUNT' => 'Seleccionar Cuenta',
  'LBL_SALUTATION' => 'Saludo',
  'NTC_OPPORTUNITY_REQUIRES_ACCOUNT' => 'Creating an opportunity requires an account.\\n Please either create a new one or select an existing one.',
);


?>