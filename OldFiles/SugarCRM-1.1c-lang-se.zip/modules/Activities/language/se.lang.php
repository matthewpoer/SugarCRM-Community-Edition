<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Activities/language/se.lang.php,v 1.0 2004/08/06 17:48:19 sugarjacob Exp $
 * Description:  Defines the Swedish language pack for the Activity module.
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_OPEN_ACTIVITIES'=>'�ppna Aktiviteter',
'LBL_HISTORY'=>'Historia',
'LBL_UPCOMING'=>"Kommande Aktiviteter",
'LBL_TODAY'=>'till ',

'LBL_NEW_TASK_BUTTON_TITLE'=>'Ny uppgift [Alt+N]',
'LBL_NEW_TASK_BUTTON_KEY'=>'N',
'LBL_NEW_TASK_BUTTON_LABEL'=>'Ny uppgift',
'LBL_SCHEDULE_MEETING_BUTTON_TITLE'=>'Boka M�te [Alt+M]',
'LBL_SCHEDULE_MEETING_BUTTON_KEY'=>'M',
'LBL_SCHEDULE_MEETING_BUTTON_LABEL'=>'Boka M�te',
'LBL_SCHEDULE_CALL_BUTTON_TITLE'=>'Boka Samtal [Alt+C]',
'LBL_SCHEDULE_CALL_BUTTON_KEY'=>'C',
'LBL_SCHEDULE_CALL_BUTTON_LABEL'=>'Boka Samtal',
'LBL_NEW_NOTE_BUTTON_TITLE'=>'Ny Anteckning [Alt+T]',
'LBL_NEW_NOTE_BUTTON_KEY'=>'T',
'LBL_NEW_NOTE_BUTTON_LABEL'=>'Ny Anteckning',
'LBL_TRACK_EMAIL_BUTTON_TITLE'=>'F�lj upp Epost [Alt+K]',
'LBL_TRACK_EMAIL_BUTTON_KEY'=>'K',
'LBL_TRACK_EMAIL_BUTTON_LABEL'=>'F�lj upp Epost',

'LBL_LIST_CLOSE'=>'Avsluta',
'LBL_LIST_STATUS'=>'Status',
'LBL_LIST_CONTACT'=>'Kontakt',
'LBL_LIST_RELATED_TO'=>'Relaterad till',
'LBL_LIST_DUE_DATE'=>'Avslutsdatum',
'LBL_LIST_DATE'=>'Datum',
'LBL_LIST_SUBJECT'=>'�rende',
'LBL_LIST_LAST_MODIFIED'=>'Senast Uppdaterad',

'LNK_NEW_CONTACT'=>'Ny Kontakt',
'LNK_NEW_ACCOUNT'=>'Nytt F�retag',
'LNK_NEW_OPPORTUNITY'=>'Ny Aff�r',
'LNK_NEW_CASE'=>'Nytt �rende',
'LNK_NEW_NOTE'=>'Ny Anteckning',
'LNK_NEW_CALL'=>'Nytt Samtal',
'LNK_NEW_EMAIL'=>'Nytt Epost',
'LNK_NEW_MEETING'=>'Nytt M�te',
'LNK_NEW_TASK'=>'Ny Uppgift',
'ERR_DELETE_RECORD'=>"Ett Post nummer m�ste anges f�r att radera F�retaget.",

//New strings for 1.1c.  These still need to be translated.
'NTC_NONE_SCHEDULED'=>'None scheduled.',
);

?>