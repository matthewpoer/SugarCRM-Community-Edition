<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Dashboard/language/se.lang.php,v 1.0 2004/08/06 marcomExp $
 * Description:  Defines the Swedish language pack for the Dashboard module.
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_SALES_STAGE_FORM_TITLE'=>'Total Pipeline Utifr�n S�lj Fas',
'LBL_LEAD_SOURCE_FORM_TITLE'=>'Total Pipeline Utifr�n K�lla',
'ERR_NO_OPPS'=>'Skapa n�gra Aff�rer f�r att se Aff�rsdiagram.',
'LBL_TOTAL_PIPELINE'=>'Total Pipeline �r',
'LBL_OPP_SIZE'=>'Aff�rsstorlek i $1K',
'NTC_NO_LEGENDS'=>'Ingen',

'LNK_NEW_CONTACT'=>'Ny Kontakt',
'LNK_NEW_ACCOUNT'=>'Nytt F�retag',
'LNK_NEW_OPPORTUNITY'=>'Ny Aff�r',
'LNK_NEW_CASE'=>'Nytt �rende',
'LNK_NEW_NOTE'=>'Ny Anteckning',
'LNK_NEW_CALL'=>'Nytt Samtal',
'LNK_NEW_EMAIL'=>'Ny Epost',
'LNK_NEW_MEETING'=>'Nytt M�te',
'LNK_NEW_TASK'=>'Ny Uppgift',
);

?>