<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Notes/language/se.lang.php,v 1.0 2004/08/06 marcom Exp $
 * Description:  Defines the Swedish language pack for the Notes module.
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_MODULE_NAME'=>'Anteckningar',
'LBL_MODULE_TITLE'=>'Anteckningar : Hem',
'LBL_SEARCH_FORM_TITLE'=>'S�k Anteckning',
'LBL_LIST_FORM_TITLE'=>'Lista Anteckningar',
'LBL_NEW_FORM_TITLE'=>'Ny Anteckning',

'LBL_LIST_SUBJECT'=>'�mne',
'LBL_LIST_CONTACT_NAME'=>'Kontakt Namn',
'LBL_LIST_RELATED_TO'=>'Relaterad till',
'LBL_LIST_DATE_MODIFIED'=>'Senast Uppdaterad',

'LBL_NOTE'=>'Anteckning:',
'LBL_NOTE_SUBJECT'=>'Anteckning �mne:',
'LBL_CONTACT_NAME'=>'Kontaktnamn:',
'LBL_PHONE'=>'Telefon:',
'LBL_SUBJECT'=>'�mne:',
'LBL_CLOSE'=>'Avslutad:',
'LBL_RELATED_TO'=>'Relaterad till:',
'LBL_DATE_MODIFIED'=>'Senast Uppdaterad:',
'LBL_EMAIL_ADDRESS'=>'Epostadress:',
'LBL_COLON'=>':',

'LNK_NEW_CONTACT'=>'Ny Kontakt',
'LNK_NEW_ACCOUNT'=>'Nytt F�retag',
'LNK_NEW_OPPORTUNITY'=>'Ny Aff�r',
'LNK_NEW_CASE'=>'Nytt �rende',
'LNK_NEW_NOTE'=>'Ny Anteckning',
'LNK_NEW_CALL'=>'Nytt Samtal',
'LNK_NEW_EMAIL'=>'Ny Epost',
'LNK_NEW_MEETING'=>'Nytt M�te',
'LNK_NEW_TASK'=>'Ny Uppgift',
'ERR_DELETE_RECORD'=>"Ett Post nummer m�ste anges f�r att radera F�retaget.",
);

?>