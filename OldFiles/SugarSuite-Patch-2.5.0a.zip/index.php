<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/cvsroot/sugarcrm/index.php,v 1.144 2005/01/25 21:44:52 julian Exp $
 * Description: Main file and starting point for the application.  Calls the
 * theme header and footer files defined for the user as well as the module as
 * defined by the input parameters.
 ********************************************************************************/

if (substr(phpversion(), 0, 1) == "5") {
	ini_set("zend.ze1_compatibility_mode", "1");
}

require_once("include/utils.php");

// Allow for the session information to be passed via the URL for printing.
if(isset($_REQUEST['PHPSESSID']))
{
	session_id($_REQUEST['PHPSESSID']);
}

function insert_charset_header()
{
global $app_strings, $default_charset;
$charset = $default_charset;

if(isset($app_strings['LBL_CHARSET']))
{
	$charset = $app_strings['LBL_CHARSET'];
}
header('Content-Type: text/html; charset='.$charset);
}

insert_charset_header();

if (!is_file('config.php')) {
    header("Location: install.php");
    exit();
}
require_once('config.php');

// load up the config_override.php file.  This is used to provide default user settings
if (is_file('config_override.php'))
{
	require_once('config_override.php');
}

if (!empty($session_dir)) {
	session_save_path($session_dir);
}

session_start();

clean_incoming_data();

// Detecting WAP Browsers
$wapBrowsers = array("Palm","BlackBerry","Windows CE");
function search_array($needles,$haystack) {
	$found=false;
	foreach ($needles as $key => $needle) {
		if (!(strpos($haystack,$needle)===false)) {
			$found=$needle;
			break;
		}
	}
	return $found;
}

if (isset($_SERVER['HTTP_USER_AGENT'])) {
	if ( search_array($wapBrowsers,$_SERVER['HTTP_USER_AGENT'])==false) {
		$wapDetected = false;
	} else {
		$wapDetected = true;
		if(!empty($_REQUEST['html'])){
			$_REQUEST['html'] = 'Wap'.$_REQUEST['html'];
			$_POST['html'] = 'Wap'.$_REQUEST['html'];
			$_GET['html'] = 'Wap'.$_REQUEST['html'];
		}
	}
}
else {
	$wapDetected = false;
}

if (!empty($_REQUEST['cancel_redirect'])) {
	if (!empty($_REQUEST['return_action'])) {
		$_REQUEST['action'] = $_REQUEST['return_action'];
		$_POST['action'] = $_REQUEST['return_action'];
		$_GET['action'] = $_REQUEST['return_action'];
	}
	if (!empty($_REQUEST['return_module'])) {
		$_REQUEST['module'] = $_REQUEST['return_module'];
		$_POST['module'] = $_REQUEST['return_module'];
		$_GET['module'] = $_REQUEST['return_module'];
	}
	if (!empty($_REQUEST['return_id'])) {
		$_REQUEST['id'] = $_REQUEST['return_id'];
		$_POST['id'] = $_REQUEST['return_id'];
		$_GET['id'] = $_REQUEST['return_id'];
	}
}

if(isset($_REQUEST['action']))
{
	if ($wapDetected == true) {


		$action = "Wap".$_REQUEST['action'];
	} else {
		$action = $_REQUEST['action'];
	}
}
else {
	$action = "";
}

if(isset($_REQUEST['module']))
{
	$module = $_REQUEST['module'];
}
else {
	$module = "";
}

$user_unique_key = (isset($_SESSION['unique_key'])) ? $_SESSION['unique_key'] : "";
$server_unique_key = (isset($unique_key)) ? $unique_key : "";

if (($user_unique_key != $server_unique_key) && ($action != "Authenticate") && ($action != "Login") && (!isset($_SESSION['login_error']))) {
	if ($wapDetected) {
		$action = "WapLogin";
	}
	else {
		$action = "Login";
	}

	$module = "Users";
	$_REQUEST['action'] = $action;
	$_REQUEST['module'] = $module;
}

require_once('include/modules.php');


if (!isset($dbconfig['db_host_name'])) {
    header("Location: install.php");
    exit();
}

require_once('include/logging.php');

require_once('modules/Users/User.php');
global $currentModule, $moduleList;

require_once('modules/Administration/Administration.php');
global $system_config;
$system_config = new Administration();
$system_config->retrieveSettings('system');
if($calculate_response_time) $startTime = microtime();

if (isset($simple_log))
{
	$log = new SimpleLog();
}
else
{
	$log =& LoggerManager::getLogger('index');
}
if (isset($_REQUEST['PHPSESSID'])) $log->debug("****Starting for session ".$_REQUEST['PHPSESSID']);
else $log->debug("****Starting for new session");

// We use the REQUEST_URI later to construct dynamic URLs.  IIS does not pass this field
// to prevent an error, if it is not set, we will assign it to ''
if(!isset($_SERVER['REQUEST_URI']))
{
	$_SERVER['REQUEST_URI'] = '';
}

// Check to see if there is an authenticated user in the session.
if(isset($_SESSION["authenticated_user_id"]))
{
	$log->debug("We have an authenticated user id: ".$_SESSION["authenticated_user_id"]);
}
else if(isset($action) && isset($module) && ($action=="Authenticate" ||$action=="WapAuthenticate")  && $module=="Users")
{
	$log->debug("We are authenticating user now");
}
else
{
	$log->debug("The current user does not have a session.  Going to the login page");
	if ($wapDetected==true) {
		$action = "WapLogin";
	} else {
		$action = "Login";
	}
	$module = "Users";
	$_REQUEST['action'] = $action;
	$_REQUEST['module'] = $module;
}

$log->debug($_REQUEST);

$skipHeaders=false;
$skipFooters=false;

if(!empty($action) && !empty($module))
{
	$log->info("About to take action ".$action);
	$log->debug("in $action");
	if(ereg("^Save", $action) || ereg("^Delete", $action) || ereg("^Popup", $action) || ereg("^ChangePassword", $action) || ereg("^Authenticate", $action) || ereg("^Logout", $action) || ereg("^Export",$action))
	{
		$skipHeaders=true;
		if(ereg("^Popup", $action) || ereg("^ChangePassword", $action) || ereg("^Export", $action))
			$skipFooters=true;
	}
	if((isset($_REQUEST['from']) && $_REQUEST['from']=='ImportVCard') || ! empty($_REQUEST['to_pdf']) ){
		$skipHeaders=true;
		$skipFooters=true;
	}
	if($action == 'BusinessCard' || $action == 'ConvertLead'|| $action == 'Save'){
		header( "Expires: Mon, 20 Dec 1998 01:00:00 GMT" );
   		header( "Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT" );
    	header( "Cache-Control: no-cache, must-revalidate" );
    	header( "Pragma: no-cache" );
	}

	if ( $action == "Import" &&
		isset($_REQUEST['step']) &&
		$_REQUEST['step'] == '4'  )
	{
		$skipHeaders=true;
		$skipFooters=true;
	}


	$currentModuleFile = 'modules/'.$module.'/'.$action.'.php';
	$currentModule = $module;
}
elseif(!empty($module))
{
	$currentModule = $module;
	$currentModuleFile = $moduleDefaultFile[$currentModule];
}
else {
    // use $default_module and $default_action as set in config.php
    // Redirect to the correct module with the correct action.  We need the URI to include these fields.
    header("Location: index.php?action=$default_action&module=$default_module");
    exit();
}

$export_module = $currentModule;

$log->info("current page is $currentModuleFile");
$log->info("current module is $currentModule ");
//define default home pages for each module
foreach ($moduleList as $mod) {
	$moduleDefaultFile[$mod] = "modules/".$currentModule."/index.php";
}

// for printing
$GLOBALS['request_string'] = "";

foreach ($_GET as $key => $val) {
	if (is_array($val)) {
		foreach ($val as $k => $v) {
			$GLOBALS['request_string'] .= "{$key}[{$k}]=" . urlencode($v) . "&";
		}
	}
	else {
		$GLOBALS['request_string'] .= "{$key}=" . urlencode($val) . "&";
	}
}

$GLOBALS['request_string'] .= "&print=true";
// end printing

$current_user = new User();

if(isset($_SESSION['authenticated_user_id']))
{
	$result = $current_user->retrieve($_SESSION['authenticated_user_id']);
	if($result == null)
	{
		session_destroy();
	    header("Location: index.php?action=Login&module=Users");
	}

	$log->debug('Current user is: '.$current_user->user_name);
}

if(isset($_SESSION['authenticated_user_theme']) && $_SESSION['authenticated_user_theme'] != '')
{
	$theme = $_SESSION['authenticated_user_theme'];
}
else
{
	if ($wapDetected==true) {
	$theme = "Wap";
	} else {
	$theme = $default_theme;
	}
}
$log->debug('Current theme is: '.$theme);

//Used for current record focus
$focus = "";

// if the language is not set yet, then set it to the default language.
if(isset($_SESSION['authenticated_user_language']) && $_SESSION['authenticated_user_language'] != '')
{
	$current_language = $_SESSION['authenticated_user_language'];
}
else
{
	$current_language = $default_language;
}
$log->debug('current_language is: '.$current_language);

//set module and application string arrays based upon selected language
$app_strings = return_application_language($current_language);
$app_list_strings = return_app_list_strings_language($current_language);
if ($wapDetected == true) {
$mod_strings = return_module_language("Wap_".$current_language, $currentModule);
} else {
$mod_strings = return_module_language($current_language, $currentModule);
}

//TODO: Clint - this key map needs to be moved out of $app_list_strings since it never gets translated.
//              best to just have an upgrade script that changes the parent_type column from Account to Accounts, etc.
$app_list_strings['record_type_module'] = array('Contact'=>'Contacts', 'Account'=>'Accounts', 'Opportunity'=>'Opportunities', 'Case'=>'Cases', 'Note'=>'Notes', 'Call'=>'Calls', 'Email'=>'Emails', 'Meeting'=>'Meetings', 'Task'=>'Tasks', 'Lead'=>'Leads','Bug'=>'Bugs',



);

//If DetailView, set focus to record passed in
if($action == "DetailView")
{
	if(!isset($_REQUEST['record']))
		die("A record number must be specified to view details.");

	// If we are going to a detail form, load up the record now.
	// Use the record to track the viewing.
	// todo - Have a record of modules and thier primary object names.
	$entity = $beanList[$currentModule];
	require_once($beanFiles[$entity]);
	$focus = new $entity();

	$result = $focus->retrieve($_REQUEST['record']);

	if($result)
	{
		// Only track a viewing if the record was retrieved.
		$focus->track_view($current_user->id, $currentModule);
	}
}

// set user, theme and language cookies so that login screen defaults to last values
if (isset($_SESSION['authenticated_user_id'])) {
	$log->debug("setting cookie ck_login_id_20 to ".$_SESSION['authenticated_user_id']);
	setcookie('ck_login_id_20', $_SESSION['authenticated_user_id'], time() + 86400*90);
}
if (isset($_SESSION['authenticated_user_theme'])) {
	$log->debug("setting cookie ck_login_theme_20 to ".$_SESSION['authenticated_user_theme']);
	setcookie('ck_login_theme_20', $_SESSION['authenticated_user_theme'], time() + 86400*90);
}
if (isset($_SESSION['authenticated_user_language'])) {
	$log->debug("setting cookie ck_login_language_20 to ".$_SESSION['authenticated_user_language']);
	setcookie('ck_login_language_20', $_SESSION['authenticated_user_language'], time() + 86400*90);
}
ob_start();
if ($wapDetected == false && empty($_REQUEST['to_pdf'])) {
	echo '<script  src="include/javascript/sugar.js"></script>';
	echo '<link rel="stylesheet" type="text/css" media="all" href="jscalendar/calendar-win2k-cold-1.css">';
	echo '<script type="text/javascript" src="jscalendar/calendar.js"></script>';
	echo '<script type="text/javascript" src="jscalendar/lang/calendar-en.js"></script>';
	echo '<script type="text/javascript" src="jscalendar/calendar-setup.js"></script>';
}
//skip headers for popups, deleting, saving, importing and other actions
if(!$skipHeaders) {


	$log->debug("including headers");

	if (!is_file('themes/'.$theme.'/header.php')) {
		$theme = $default_theme;
	}
	if (!is_file('themes/'.$theme.'/header.php')) {
		sugar_die("Invalid theme specified");
	}

	include('themes/'.$theme.'/header.php');

	// Only print the errors for admin users.
	if(is_admin($current_user))
	{
		if(is_dir('install'))
		{
			echo '<p class="error">Warning: The "install" directory needs to be renamed to prevent the installation from being run again.</p>';
		}

		if(is_writable('config.php'))
		{
			echo '<p class="error">Warning: The config.php file needs to be read-only for security purposes.</p>';
		}

		if(isset($_SESSION['administrator_error']))
		{
			// Only print DB errors once otherwise they will still look broken
			// after they are fixed.
			echo $_SESSION['administrator_error'];
		}

		unset($_SESSION['administrator_error']);
	}

	echo "<!-- crmprint -->";
}
else {
		$log->debug("skipping headers");
}

include($currentModuleFile);

if(!$skipFooters) {
	echo "<!-- crmprint -->";
	include('themes/'.$theme.'/footer.php');

if ($wapDetected == false) {
echo "<table cellpadding='0' cellspacing='0' width='100%' border='0'><tr><td align='center' class='copyRight'>";
// Under the Sugar Public License referenced above, you are required to leave in all copyright statements in both
// the code and end-user application.
if($calculate_response_time)
{
    $endTime = microtime();

    $deltaTime = microtime_diff($startTime, $endTime);
    echo('Server response time: '.$deltaTime.' seconds.<br>');
}
echo("&copy; 2005 <a href='http://www.sugarcrm.com' target='_blank'  class='copyRightLink'>SugarCRM Inc.</a> All Rights Reserved.<br>");


// Under the Sugar Public License referenced above, you are required to leave in all copyright statements in both
// the code and end-user application as well as the the powered by image. You can not change the url or the image below  .
echo "<A href='http://www.sugarcrm.com' target='_blank'><img style='margin-top: 2px' border='0' width='106' height='23' src='include/images/poweredby_sugarcrm.png' alt='Powered By SugarCRM'></a>\n";
// End Required Image
echo "</td></tr></table>\n";
echo "</body></html>";
}
}

if (!function_exists("ob_get_clean")) {
   function ob_get_clean() {
       $ob_contents = ob_get_contents();
       ob_end_clean();
       return $ob_contents;
   }
}

if (isset($_GET['print'])) {
	$page_str = ob_get_clean();
	$page_arr = explode("<!-- crmprint -->", $page_str);
	include("phprint.php");
}


if (isset($log_memory_usage) && ($log_memory_usage === TRUE) && function_exists("memory_get_usage")) {
	$fp = @fopen("memory_usage.log", "ab");
	@fwrite($fp, "Usage: " . memory_get_usage() . " - module: " . (isset($module) ? $module : "<none>") . " - action: " . (isset($action) ? $action : "<none>") . "\n");
	@fclose($fp);
}
?>
