<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

// $Id: 4performSetup.php,v 1.66 2005/01/25 00:45:35 andrew Exp $

$suicide = true;
if(isset($install_script))
{
   if($install_script)
   {
      $suicide = false;
   }
}

if($suicide)
{
   // mysterious suicide note
   die('Unable to process script directly.');
}

set_time_limit(90);

// This file will load the configuration settings from session data,
// write to the config file, and execute any necessary database steps.

   require_once('include/utils.php');

   $setup_db_host_name = $_SESSION['setup_db_host_name'];
   $setup_db_sugarsales_user = $_SESSION['setup_db_sugarsales_user'];
   $setup_db_sugarsales_password = $_SESSION['setup_db_sugarsales_password'];
   $setup_db_database_name = $_SESSION['setup_db_database_name'];
   $setup_db_drop_tables = $_SESSION['setup_db_drop_tables'];
   $setup_db_create_database = $_SESSION['setup_db_create_database'];
   $setup_db_pop_demo_data = $_SESSION['setup_db_pop_demo_data'];
   $setup_site_url = $_SESSION['setup_site_url'];
   $setup_site_admin_password = $_SESSION['setup_site_admin_password'];
   $setup_db_create_database = $_SESSION['setup_db_create_database'];
   $setup_db_create_sugarsales_user = $_SESSION['setup_db_create_sugarsales_user'];
   $setup_db_admin_user_name = $_SESSION['setup_db_admin_user_name'];
   $setup_db_admin_password = $_SESSION['setup_db_admin_password'];

   if($_SESSION['setup_site_custom_session_path'])
   {
      $setup_site_session_path = $_SESSION['setup_site_session_path'];
   }
   else
   {
      $setup_site_session_path = '';
   }

   if($_SESSION['setup_site_specify_guid'])
   {
      $setup_site_guid = $_SESSION['setup_site_guid'];
   }
   else
   {
      $setup_site_guid = md5(create_guid());
   }

   $cache_dir = 'cache/';

   // flush after each output so the user can see the progress in real-time
   ob_implicit_flush();

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
   <meta http-equiv="Content-Script-Type" content="text/javascript">
   <meta http-equiv="Content-Style-Type" content="text/css">
   <title>SugarCRM Setup Wizard: Step 4</title>
   <link rel="stylesheet" href="install/install.css" type="text/css" />
   <script type="text/javascript" src="install/installCommon.js"></script>
</head>
<body>
<table cellspacing="0" cellpadding="0" border="0" align="center" class="shell">
<tr>
   <th width="400" height="30">Step 4: Perform Setup</th>
   <th width="200" height="30" style="text-align: right;"><a href="http://www.sugarcrm.com" target=
      "_blank"><IMG src="include/images/sugarcrm_login.png" width="120" height="19" alt="SugarCRM" border="0"></a></th>
</tr>
<tr>
   <td colspan="2" width="600">

<?php
   echo 'Creating the config file...';
   if (is_file('config.php'))
   {
      $is_writable = is_writable('config.php');
   }
   else
   {
      $is_writable = is_writable('.');
   }

   $config = "<?php \n";
   $config .= "\$sugar_version = '".$setup_sugar_version."';\n\n";
   $config .= "/* Database configuration\n";
   $config .= "      db_host_name:     MySQL Database Hostname\n";
   $config .= "      db_user_name:     MySQL Username\n";
   $config .= "      db_password:      MySQL Password\n";
   $config .= "      db_name:       MySQL Database Name\n*/\n";
   $config .= "\$dbconfig['db_host_name'] =  '".addslashes($setup_db_host_name)."';\n";
   $config .= "\$dbconfig['db_user_name'] =  '".addslashes($setup_db_sugarsales_user)."';\n";
   $config .= "\$dbconfig['db_password'] =   '".addslashes($setup_db_sugarsales_password)."';\n";
   $config .= "\$dbconfig['db_name'] =    '".addslashes($setup_db_database_name)."';\n";
   $config .= "\$dbconfig['db_type'] = 'mysql';\n\n";
   $config .= "\$dbconfigoption['persistent'] = true;\n";
   $config .= "\$dbconfigoption['autofree'] = false;\n";
   $config .= "\$dbconfigoption['debug'] = 0;\n";
   $config .= "\$dbconfigoption['seqname_format'] = '%s_seq';\n";
   $config .= "\$dbconfigoption['portability'] = 0;\n";
   $config .= "\$dbconfigoption['ssl'] = false;\n\n";
   $config .= "\$host_name = '".$setup_db_host_name."';\n\n";
   $config .= "\$site_URL = '".$setup_site_url."';\n\n";
   $config .= "\$cache_dir = '$cache_dir';\n";
   $config .= "\$tmp_dir = '" . ($cache_dir . "xml/") . "';\n";
   $config .= "\$import_dir = '" . ($cache_dir . "import/") . "';\n";
   $config .= "\$session_dir = '" . $setup_site_session_path . "';\n\n";
   $config .= "\$unique_key = '" . $setup_site_guid . "';\n\n";
   $config .= "// Maximum file size for uploaded files (in bytes)\n";
   $config .= "\$upload_maxsize = 3000000;\n";
   $config .= "\$upload_dir = '" . ($cache_dir . "upload/") . "';\n";
   $config .= "// Files with one of these extensions will have '.txt' appended to their filename on upload\n";
   $config .= "\$upload_badext = array('php', 'php3', 'php4', 'php5', 'pl', 'cgi', 'py', 'asp', 'cfm', 'js', 'vbs', 'html', 'htm');\n\n";
   $config .= "// This is the full path to the include directory including the trailing slash\n";
   $config .= "\$list_max_entries_per_page = '20';\n\n";
   $config .= "\$history_max_viewed = '10';\n\n";
   $config .= "\$log_memory_usage = FALSE;\n\n";
   $config .= "//define list of menu tabs\n";
   $config .= "//\$moduleList defined in include/modules.php as of SugarCRM v2.0\n\n";
   $config .= "// Map Sugar language codes to jscalendar language codes\n";
   $config .= "// Unimplemented until jscalendar language files are fixed\n";
   $config .= "// \$cal_codes = array('en_us'=>'en', 'ja'=>'jp', 'sp_ve'=>'sp', 'it_it'=>'it', 'tw_zh'=>'zh', 'pt_br'=>'pt', 'se'=>'sv', 'cn_zh'=>'zh', 'ge_ge'=>'de', 'ge_ch'=>'de', 'fr'=>'fr');\n\n";
   $config .= "\$default_module = 'Home';\n";
   $config .= "\$default_action = 'index';\n\n";
   $config .= "//set default theme\n";
   $config .= "\$default_theme = 'Sugar';\n\n";
   $config .= "// If true, the time to compose each page is placed in the browser.\n";
   $config .= "\$calculate_response_time = true;\n";
   $config .= "// Default Username - The default text that is placed initially in the login form for user name.\n";
   $config .= "\$default_user_name = '';\n";
   $config .= "// Default Password - The default text that is placed initially in the login form for password.\n";
   $config .= "\$default_password = '';\n";
   $config .= "// Create default user - If true, a user with the default username and password is created.\n";
   $config .= "\$create_default_user = false;\n";
   $config .= "\$default_user_is_admin = false;\n";
   $config .= "// disable persistent connections - If your MySQL/PHP configuration does not support persistent connections set this to true to avoid a large performance slowdown\n";
   $config .= "\$disable_persistent_connections = ".return_session_value_or_default('disable_persistent_connections', 'false').";\n";
   $config .= "// Defined languages available.  The key must be the language file prefix.  E.g. 'en_us' is the prefix for every 'en_us.lang.php' file. \n";

   $language_value = "Array('en_us'=>'US English',)";
   if (isset($_SESSION['language_keys']) && isset($_SESSION['language_values']))
   {
      $language_value = 'Array(';
      $language_keys = explode(',', urldecode($_SESSION['language_keys']));
      $language_values = explode(',', urldecode($_SESSION['language_values']));

      $size = count($language_keys);
      for($i = 0; $i < $size; $i += 1)
      {
         $language_value .= "'$language_keys[$i]'=>'$language_values[$i]',";
      }

      $language_value .= ')';
   }

   $config .= "\$languages = $language_value;\n";
   $config .= "// Default charset if the language specific character set is not found.\n";
   $config .= "\$default_charset = '".return_session_value_or_default('default_charset', 'ISO-8859-1')."';\n";
   $config .= "// Default language in case all or part of the user's language pack is not available.\n";
   $config .= "\$default_language = '".return_session_value_or_default('default_language', 'en_us')."';\n";
   $config .= "// Translation String Prefix - This will add the language pack name to every translation string in the display.\n";
   $config .= "\$translation_string_prefix = ".return_session_value_or_default('translation_string_prefix', 'false').";\n";
   $config .= "// cache rss feeds for 3 hours:\n";
   $config .= "\$RSS_CACHE_TIME = '".return_session_value_or_default('rss_cache_time', '10800')."';\n";
   $config .= "// if true, export link removed from all list views.  overrides \$admin_export_only.\n";
   $config .= "\$disable_export = false;\n";
   $config .= "// if true, export link available only for admin users\n";
   $config .= "\$admin_export_only = false;\n";
   $config .= <<<EOQ
\$timeFormats = array('H:i'=>'23:00', 'h:ia'=>'11:00pm', 'h:iA'=>'11:00PM', 'H.i'=>'23.00', 'h.ia'=>'11.00pm', 'h.iA'=>'11.00PM');
\$defaultTimeFormat = 'H:i';
\$dateFormats = array('Y-m-d'=>'2006-12-23', 'm-d-Y'=>'12-23-2006', 'Y/m/d'=>'2006/12/23', 'm/d/Y'=>'12/23/2006');
\$defaultDateFormat = 'Y-m-d';
\$requireAccounts = true;
EOQ;
$config .= "\n?>";

if ($is_writable && ($config_file = @ fopen("config.php", "w"))) {
	fputs($config_file, $config, strlen($config));
	fclose($config_file);
	echo 'done<br>';
}
else {
	echo 'failed<br>';
	echo "<p>Cannot write to the <span class=stop>config.php</span> file.</p>\n";
	echo "<p>You can continue this installation by manually creating the config.php file and pasting the configuration information below into the config.php file.  However, you <strong>must </strong>create the config.php file before you continue to the next step.  </p>\n";
	echo  "<TEXTAREA  rows=\"15\" cols=\"80\">".$config."</TEXTAREA>";
	echo "<p>Did you remember to create the config.php file?</p>";
}

// TABLE STUFF **************************

   // create the SugarCRM database
   if($setup_db_create_database)
   {
      echo "Creating the database $setup_db_database_name on $setup_db_host_name...";
      $link = @mysql_connect($setup_db_host_name, $setup_db_admin_user_name,
                             $setup_db_admin_password);
      $query = 'create database ' . $setup_db_database_name;
      @mysql_unbuffered_query($query, $link);
      mysql_close($link);
      echo 'done<br>';
   }

   // create the SugarCRM database user
   if($setup_db_create_sugarsales_user)
   {
      echo 'Creating the db username and password...';
      $link = @mysql_connect($setup_db_host_name, $setup_db_admin_user_name,
                             $setup_db_admin_password);
      $query = <<< HEREDOC_END
grant select, insert, update, delete on $setup_db_database_name.*
to "$setup_db_sugarsales_user"@"$setup_db_host_name"
identified by '$setup_db_sugarsales_password';
HEREDOC_END;

      if(!@mysql_unbuffered_query($query, $link))
      {
         $errno = mysql_errno();
         $error = mysql_error();
      }

      $query = <<< HEREDOC_END
set password for "$setup_db_sugarsales_user"@"$setup_db_host_name"
 = old_password('$setup_db_sugarsales_password');
HEREDOC_END;
      if(!@mysql_unbuffered_query($query, $link))
      {
         $errno = mysql_errno();
         $error = mysql_error();
      }
      mysql_close($link);
      echo 'done<br>';
   }

   $new_tables = 0;
   $new_config = 0;
   $new_report = 0;

   require_once('include/logging.php');
   require_once('data/Tracker.php');
   require_once('include/utils.php');
   require_once('include/modules.php');

   global $beanFiles;
   foreach ($beanFiles as $bean => $file)
   {
      require_once($file);
   }

   // load up the config_override.php file.  This is used to provide default user settings
   if (is_file("config_override.php"))
   {
      require_once("config_override.php");
   }

   $db = new PearDatabase();
   $db->setUserName($setup_db_admin_user_name);
   $db->setUserPassword($setup_db_admin_password);
   $log = & LoggerManager::getLogger('create_table');

   //Drop old tables if table exists and told to drop it
   function drop_table_install(&$focus)
   {
      global $log, $db;

      $result = $db->requireSingleResult("SHOW TABLES LIKE '".$focus->table_name."'");
      if (!empty($result))
      {
         $focus->drop_tables();
         $log->info("Dropped old ".$focus->table_name." table.");
         return 1;
      }
      else
      {
         $log->info("Did not need to drop old ".$focus->table_name." table.  It doesn't exist.");
         return 0;
      }
   }

   // Creating new tables if they don't exist.
   function create_table_install(&$focus)
   {
      global $log, $db;

      $result = $db->query("SHOW TABLES LIKE '".$focus->table_name."'");
      if ($db->getRowCount($result) == 0)
      {
         $focus->create_tables();
         $log->info("Created ".$focus->table_name." table.");
         return 1;
      }
      else
      {
         $log->info("Table ".$focus->table_name." already exists.");
         return 0;
      }
   }

   function create_default_users()
   {
      global $log, $db;
      global $setup_site_admin_password;
      global $create_default_user;
      global $default_user_name;
      global $default_password;
      global $default_user_is_admin;

      //Create default admin user
      $user = new User();
      $user->id = 1;
      $user->new_with_id = true;
      $user->last_name = 'Administrator';
      $user->user_name = 'admin';
      $user->title = "Administrator";
      $user->status = 'Active';
      $user->is_admin = 'on';
      $user->user_password = $user->encrypt_password($setup_site_admin_password);
      $user->user_hash = strtolower(md5($setup_site_admin_password));
      $user->email = '';
      $user->save();
      $feed = new Feed();
      $feed->createRSSHomePage($user->id);


      // We need to change the admin user to a fixed id of 1.
      // $query = "update users set id='1' where user_name='$user->user_name'";
      // $result = $db->query($query, true, "Error updating admin user ID: ");

      $log->info("Created ".$user->table_name." table. for user $user->id");

      if ($create_default_user)
      {
         $default_user = new User();
         $default_user->last_name = $default_user_name;
         $default_user->user_name = $default_user_name;
         $default_user->status = 'Active';
         if (isset($default_user_is_admin) && $default_user_is_admin) $default_user->is_admin = 'on';
         $default_user->user_password = $default_user->encrypt_password($default_password);
         $default_user->user_hash = strtolower(md5($default_password));
         $default_user->save();
         $feed->createRSSHomePage($user->id);
      }
   }

   function set_admin_password($password)
   {
      global $db;
      global $log;

      $user = new User();
      $encrypted_password = $user->encrypt_password($password);
      $user_hash = strtolower(md5($password));

      $query = "update users set user_password='$encrypted_password', user_hash='$user_hash' where id='1'";
      $db->query($query);
   }

   function insert_default_settings()
   {
      global $log;
      global $db;
      global $setup_sugar_version;

      $db->query("INSERT INTO config (category, name, value) VALUES ('notify', 'fromaddress', 'sugar@example.com')");
      $db->query("INSERT INTO config (category, name, value) VALUES ('notify', 'fromname', 'SugarCRM')");
      $db->query("INSERT INTO config (category, name, value) VALUES ('notify', 'send_by_default', '1')");
      $db->query("INSERT INTO config (category, name, value) VALUES ('notify', 'on', '0')");
      $db->query("INSERT INTO config (category, name, value) VALUES ('mail', 'smtpserver', 'localhost')");
      $db->query("INSERT INTO config (category, name, value) VALUES ('mail', 'smtpport', '25')");
      $db->query("INSERT INTO config (category, name, value) VALUES ('mail', 'sendtype', 'sendmail')");
      $db->query("INSERT INTO config (category, name, value) VALUES ('mail', 'smtpuser', '')");
      $db->query("INSERT INTO config (category, name, value) VALUES ('mail', 'smtppass', '')");
      $db->query("INSERT INTO config (category, name, value) VALUES ('mail', 'smtpauth_req', '0')");
      $db->query("INSERT INTO config (category, name, value) VALUES ('info', 'sugar_version', '" . $setup_sugar_version . "')");
      $db->query("INSERT INTO config (category, name, value) VALUES ('MySettings', 'tab', '')");
   }


   // start of the table creation stuff

   $startTime = microtime();

   $focus = 0;

   foreach ($beanFiles as $bean => $file)
   {
      $focus = new $bean();
      global $setup_db_admin_user_name;
      global $setup_db_admin_password;

      $focus->db->setUserName($setup_db_admin_user_name);
      $focus->db->setUserPassword($setup_db_admin_password);

      if ($setup_db_drop_tables)
      {
         echo "Dropping table ". $focus->table_name ." if exists...";
         $existed = drop_table_install($focus);

         if ($existed)
         {
            echo 'done<br>';
         }
         else
         {
            echo 'skipped (not found)<br>';
         }
      }

      echo "Creating the table ". $focus->table_name."...";

      if(create_table_install($focus))
      {
         echo 'done<br>';
         if ($bean == "User")
         {
            $new_tables = 1;
         }
         if ($bean == "Administration" )
         {
            $new_config = 1;
         }






      }
      else
      {
         echo "skipped (already exists)<br>\n";
      }
   }


   if ($new_config)
   {
      echo 'Inserting default settings...';
      insert_default_settings();
      echo 'done<br>';
   }

   if ($new_tables)
   {
      echo 'Creating default users...';
      create_default_users();
      echo 'done<br>';
   }
   else
   {
      echo "Setting site admin password...";
      $db->setUserName($setup_db_sugarsales_user);
      $db->setUserPassword($setup_db_sugarsales_password);
      set_admin_password($setup_site_admin_password);
      echo 'done<br>';
   }










   // populating the db with seed data
   if ($setup_db_pop_demo_data)
   {
      echo 'Populating the database tables with demo data (this may take a little while)...';
      include("install/populateSeedData.php");
      echo 'done<br>';
   }

	echo 'Making config file read-only to secure the system...';
	@chmod('./config.php', 0444);
	if(is_writable('./config.php'))
	{
		echo 'failed<br>';
		echo '<p><b>Please make your config.php file read-only for security purposes.</b></p>';
	}
	else
	{
		echo 'done<br>';
	}

	echo '<p><b>Please rename your install directory to prevent unintended re-installations.</b></p>';

   $endTime = microtime();
   $deltaTime = microtime_diff($startTime, $endTime);
?>
<p>The setup of SugarCRM <?php echo $setup_sugar_version; ?> is now complete.</p>
<hr>
Total time: <?php echo $deltaTime; ?> seconds.<br />
<?php
   if(function_exists('memory_get_usage'))
   {
      echo 'Approximate memory used: ' . memory_get_usage() . ' bytes.<br />';
   }
?>
<hr>

<p>Your system is now installed and configured for use.  You will need
to log in for the first time using the "admin" user name and the password
you entered in step 3.</p>

<?php
   $fp = @fsockopen("www.sugarcrm.com", 80, $errno, $errstr, 3);
   if (!$fp)
   {
      echo "<p><b>We could not detected an internet connection.</b> When you do have a connection, please visit <a href=\"http://www.sugarcrm.com/home/index.php?option=com_extended_registration&task=register\">http://www.sugarcrm.com/home/index.php?option=com_extended_registration&task=register</a> to register with SugarCRM. By letting us know a little bit about how your company plans to use SugarCRM, we can ensure we are always delivering the right application for your business needs.</p>";
   }
?>
	</td>
</tr>
<tr>
<td align="right" colspan="2">
<hr>
<table cellspacing="0" cellpadding="0" border="0" class="stdTable">
<tr>
<td>

<?php
   if ($fp)
   {
      @fclose($fp);
?>
     <form action="install.php" method="post" name="form" id="form">
     <input type="hidden" name="current_step" value="4">
     <table cellspacing="0" cellpadding="0" border="0" class="stdTable">
       <tr>
         <td><input class="button" type="button" onclick="window.open('http://www.sugarcrm.com/forums/');" value="Help" /></td>
         <td><input class="button" type="submit" name="goto" value="Back" /></td>
         <td><input class="button" type="submit" name="goto" value="Next" /></td>
       </tr>
     </table>
     </form>
<?php
   } else {
?>
     <table cellspacing="0" cellpadding="0" border="0" class="stdTable">
       <tr>
         <td><input class="button" type="button" onclick="showHelp(4);" value="Help" /></td>
         <td><form action="install.php" method="post" name="form" id="form">
             <input type="hidden" name="current_step" value="4">
             <input class="button" type="submit" name="goto"
                    value="Back" /></form></td>
         <td><form action="index.php" method="post" name="formFinish"
                   id="formFinish">
             <input type="hidden" name="default_user_name" value="admin" />
             <input class="button" type="submit" name="next"
                    value="Finish" /></form></td>
       </tr>
     </table>
<?php
   }
?>
</td>
</tr>
</table>
</td>
</tr>
</table>
<br>
</body>
</html>

