-- MSSQL upgrade script for Sugar 5.0.0 to 5.2.0

--
-- TABLES modified from 500 to 520
--
-- import maps
ALTER TABLE import_maps alter column name varchar(254);
ALTER TABLE import_maps add enclosure varchar(1) NOT NULL;
ALTER TABLE import_maps add delimiter varchar(1) default ',' NOT NULL;
ALTER TABLE import_maps add default_values image;
ALTER TABLE users_last_import add import_module varchar(36) NULL ;

ALTER TABLE emails add flagged bit NULL ;
ALTER TABLE emails add reply_to_status bit NULL ;
ALTER TABLE email_cache alter column senddate datetime NULL;

ALTER TABLE emails_text add reply_to_addr varchar(255) NULL;

-- ALTER TABLE fields_meta_data  alter column default_value varchar(255) NULL;
ALTER TABLE fields_meta_data add importable varchar(255) NULL;

-- inbound email
ALTER TABLE inbound_email alter column mailbox text NOT NULL;
-- project task
 ALTER TABLE project_task add  status varchar(255)  NULL;
 ALTER TABLE project_task add  order_number int default '1';
 ALTER TABLE project_task add  task_number int  default NULL;
 ALTER TABLE project_task add  estimated_effort int  default NULL;
 ALTER TABLE project_task add  utilization int default '100';

ALTER TABLE accounts alter column account_type varchar(50)  NULL ;
ALTER TABLE accounts alter column industry varchar(50)  NULL ;

-- tracker table changes

ALTER TABLE tracker add monitor_id varchar(36) NULL;
CREATE NONCLUSTERED INDEX idx_tracker_monitor_id ON tracker(monitor_id);





ALTER TABLE tracker add deleted bit default '0' NULL;
ALTER TABLE tracker alter column session_id varchar(36) NULL;

CREATE TABLE calls_leads (
    id varchar(36)  NOT NULL ,
    call_id varchar(36)  NULL ,
    lead_id varchar(36)  NULL ,
    required varchar(1)  DEFAULT '1' NULL ,
    accept_status varchar(25)  DEFAULT 'none' NULL ,
    date_modified datetime  NULL ,
    deleted bit  DEFAULT '0' NOT NULL  ,
    PRIMARY KEY (id)
) ;
CREATE NONCLUSTERED INDEX idx_lead_call_call ON calls_leads(call_id);
CREATE NONCLUSTERED INDEX idx_lead_call_lead ON calls_leads(lead_id);
CREATE NONCLUSTERED INDEX idx_call_lead ON calls_leads(call_id, lead_id);

CREATE TABLE meetings_leads (
	id varchar(36)  NOT NULL ,
	meeting_id varchar(36)  NULL ,
	lead_id varchar(36)  NULL ,
	required varchar(1)  DEFAULT '1' NULL ,
	accept_status varchar(25)  DEFAULT 'none' NULL ,
	date_modified datetime  NULL ,
	deleted bit  DEFAULT '0' NOT NULL  ,
	PRIMARY KEY (id)
);
CREATE NONCLUSTERED INDEX idx_lead_meeting_meeting ON meetings_leads(meeting_id);
CREATE NONCLUSTERED INDEX idx_lead_meeting_lead ON meetings_leads(lead_id);
CREATE NONCLUSTERED INDEX idx_meeting_lead ON meetings_leads(meeting_id, lead_id);




















































































--
-- Table structure for table sugarfeed
--

CREATE TABLE sugarfeed (
	id varchar(36) NOT NULL,
	name varchar(255) NULL,
	date_entered datetime NULL,
	date_modified datetime NULL,
	modified_user_id varchar(36) NULL,
	created_by varchar(36) NULL,
	description varchar(255) NULL,
	deleted bit DEFAULT '0' NULL,



	assigned_user_id varchar(36) NULL,
	related_module varchar(100) NULL,
	related_id varchar(36) NULL,
	link_url varchar(255) NULL,
	link_type varchar(30) NULL  
); 

ALTER TABLE sugarfeed ADD CONSTRAINT pk_sugarfeed PRIMARY KEY (id) create index sgrfeed_date on sugarfeed ( date_entered, 



deleted 
);

