<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1
 * ("License"); You may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Dashboard/index.php,v 1.2 2004/06/10 02:13:10 sugarclint Exp $
 * Description:  Main file for the Home module.
 ********************************************************************************/

global $theme;
$theme_path="themes/".$theme."/";
$image_path=$theme_path."images/";
require_once($theme_path.'layout_utils.php');
require_once('modules/Opportunities/Opportunity.php');

$list_form=new XTemplate ('modules/Opportunities/ListViewTop.html');
$list_form->assign("THEME", $theme);
$list_form->assign("IMAGE_PATH", $image_path);
$list_form->assign("MODULE_NAME", $current_module);

$opp = new Opportunity();
$where = "";
$opp_list = $opp->get_full_list("amount DESC, date_closed DESC", $where);



//build pipeline by sales stage data
foreach ($opp_list as $record) {
	if (is_null($sum[$record->sales_stage])) $sum[$record->sales_stage] = 0;
	if (isset($record->amount))	$sum[$record->sales_stage] = $sum[$record->sales_stage] + $record->amount;  
	$log->debug("record->amount is '$record->amount' and record->sales_stage is '$record->sales_stage' and sum[$record->sales_stage] is ".$sum[$record->sales_stage]); 
}

$datax =& $opp->sales_stage_dom;
$datay = Array();
foreach ($opp->sales_stage_dom as $stage) {
	array_push($datay, $sum[$stage]/1000);
}

//pipeline($datax,$datay); 
$flat_array1 = urlencode(implode(",",$datax));
$flat_array2 = urlencode(implode(",",$datay));

//build pipeline by lead source data
$total = 0;
foreach ($opp_list as $record) {
	if (is_null($sum[$record->lead_source])) $sum[$record->lead_source] = 0;
	if (isset($record->amount))	{
		$sum[$record->lead_source] = $sum[$record->lead_source] + ($record->amount/1000);  
		$total = $total + ($record->amount/1000);
	}
	$log->debug("record->amount is '$record->amount' and record->lead_source is '$record->lead_source' and sum[$record->lead_source] is ".$sum[$record->lead_source]); 
}

$legends =& $opp->lead_source_dom;
$legends[array_search('', $legends)] = 'None'; 

$data= Array();
foreach ($opp->lead_source_dom as $lead_source) {
	//$percent = $sum[$lead_source]/$total;
	array_push($data, $sum[$lead_source]);
}					

//pipeline_by_lead_source($data,$legends, $title);
$data_string = urlencode(implode(",", $data));
$legends_string = urlencode(implode(",", $legends));

$title = urlencode("Total Pipeline is \$".$total."K");
$subtitle= urlencode("Opportunity size in $1K");

?>
<table align="left" cellpadding="5" cellspacing="5" border="0">
<tr>
<td rowspan="2" valign="top">
	<?php echo get_left_form_header("My Pipeline");
    echo "<img src='graph.php?module=Opportunities&action=Charts&graph=pipeline&flat_array1=".$flat_array1."&flat_array2=".$flat_array2."&title=".$title."&subtitle=".$subtitle."' border=0 align=top>\n";
	echo get_left_form_footer();?></td>
<td valign="top">
	<?php 
	echo get_left_form_header("My Pipeline By Lead Source");
    echo "<img src='graph.php?module=Opportunities&action=Charts&graph=pipeline_by_lead_source&flat_array1=".$flat_array1."&flat_array2=".$flat_array2."&title=&subtitle=".$subtitle."' border=0 align=top>\n";
   	?>
	</td></tr></table>
	<?php echo get_form_footer();?>
</td>
</tr><tr>		

</tr>
</table>
