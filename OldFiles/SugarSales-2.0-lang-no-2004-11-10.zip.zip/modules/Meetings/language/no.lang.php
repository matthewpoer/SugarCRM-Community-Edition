<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/modules/Accounts/Account.php,v 1.92 2004/11/10 22:27:36 clint Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'M&oslash;ter',
  'LBL_MODULE_TITLE' => 'M&oslash;ter : Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'S&oslash;k M&oslash;te',
  'LBL_LIST_FORM_TITLE' => 'M&oslash;teliste',
  'LBL_NEW_FORM_TITLE' => 'Avtal M&oslash;te',
  'LBL_LIST_SUBJECT' => 'Vedr&oslash;rende',
  'LBL_LIST_CONTACT' => 'Kontakt Navn',
  'LBL_LIST_RELATED_TO' => 'Relatert til',
  'LBL_LIST_DATE' => 'Start Dato',
  'LBL_LIST_TIME' => 'Start Tid',
  'LBL_LIST_CLOSE' => 'Close',
  'LBL_SUBJECT' => 'Vedr&oslash;rende: ',
  'LBL_STATUS' => 'Status:',
  'LBL_LOCATION' => 'Sted:',
  'LBL_DATE_TIME' => 'Start Dato & Tid:',
  'LBL_DATE' => 'Start Dato:',
  'LBL_TIME' => 'Start Tid:',
  'LBL_DURATION' => 'Varighet',
  'LBL_HOURS_MINS' => '(timer/minutter)',
  'LBL_CONTACT_NAME' => 'Kontakt Navn: ',
  'LBL_MEETING' => 'M&oslash;te:',
  'LBL_DESCRIPTION_INFORMATION' => 'Beskrivelse',
  'LBL_DESCRIPTION' => 'Beskrivelse:',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'Planlagt',
  'LNK_NEW_CALL' => 'Ny Samtale',
  'LNK_NEW_MEETING' => 'Nytt M&oslash;te',
  'LNK_NEW_TASK' => 'Ny Oppgave',
  'LNK_NEW_NOTE' => 'Nytt Notat',
  'LNK_NEW_EMAIL' => 'Ny Epost',
  'LNK_CALL_LIST' => 'Calls',
  'LNK_MEETING_LIST' => 'Meetings',
  'LNK_TASK_LIST' => 'Tasks',
  'LNK_NOTE_LIST' => 'Notes',
  'LNK_EMAIL_LIST' => 'Emails',
  'LNK_VIEW_CALENDAR' => 'Today',
  'ERR_DELETE_RECORD' => 'Et Postnummer skal oppgis for &aring; slette m&oslash;det.',
  'NTC_REMOVE_INVITEE' => 'Er du sikker p&aring; &aring; slette den inviterte fra M&oslash;te?',
  'LBL_INVITEE' => 'Inviterte',
  'LNK_NEW_APPOINTMENT' => 'Create Appointment',
  'LNK_NEW_CONTACT' => 'Ny Kontakt',
  'LNK_NEW_ACCOUNT' => 'Ny Virksomhet',
  'LNK_NEW_OPPORTUNITY' => 'Ny Salgs Mulighet',
  'LNK_NEW_CASE' => 'Ny Sak',
);


?>