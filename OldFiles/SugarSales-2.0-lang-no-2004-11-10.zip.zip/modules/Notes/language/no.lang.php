<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/modules/Accounts/Account.php,v 1.92 2004/11/10 22:27:36 clint Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Notater',
  'LBL_MODULE_TITLE' => 'Notater : Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'S&oslash;k Notater',
  'LBL_LIST_FORM_TITLE' => 'Vis Notater',
  'LBL_NEW_FORM_TITLE' => 'Nytt Notat',
  'LBL_LIST_SUBJECT' => 'Vedr&oslash;rende',
  'LBL_LIST_CONTACT_NAME' => 'Kontakt Navn',
  'LBL_LIST_RELATED_TO' => 'Relatert til',
  'LBL_LIST_DATE_MODIFIED' => 'Sist Oppdatert',
  'LBL_LIST_FILENAME' => 'Vedlegg',
  'LBL_NOTE' => 'Notat:',
  'LBL_NOTE_SUBJECT' => 'Notat vedr&oslash;rende:',
  'LBL_CONTACT_NAME' => 'Kontaktnavn:',
  'LBL_PHONE' => 'Telefon:',
  'LBL_SUBJECT' => 'Vedr&oslash;rende:',
  'LBL_FILENAME' => 'Vedlegg:',
  'LBL_CLOSE' => 'Afslutet:',
  'LBL_RELATED_TO' => 'Relatert til:',
  'LBL_EMAIL_ADDRESS' => 'Emailadresse:',
  'LBL_COLON' => ':',
  'LNK_NEW_NOTE' => 'Nytt Notat',
  'LNK_NOTE_LIST' => 'Notes',
  'ERR_DELETE_RECORD' => 'Et Postnummer skal oppgis for &aring; slette Virksomheten.',
  'LNK_NEW_CALL' => 'Ny Samtale',
  'LNK_NEW_MEETING' => 'Nytt M&oslash;te',
  'LNK_NEW_TASK' => 'Ny Oppgave',
  'LNK_NEW_EMAIL' => 'Ny Epost',
  'LNK_CALL_LIST' => 'Calls',
  'LNK_MEETING_LIST' => 'Meetings',
  'LNK_TASK_LIST' => 'Tasks',
  'LNK_EMAIL_LIST' => 'Emails',
  'LNK_NEW_CONTACT' => 'Ny Kontakt',
  'LNK_NEW_ACCOUNT' => 'Ny Virksomhet',
  'LNK_NEW_OPPORTUNITY' => 'Ny Salgs Mulighet',
  'LNK_NEW_CASE' => 'Ny Sak',
);


?>