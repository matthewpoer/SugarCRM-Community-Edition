/**
 * EditView javascript for Email
 *
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */

// $Id: EditView.js,v 1.3.4.4 2005/10/07 19:09:54 chris Exp $

var uploads_arr=new Array();
var uploads_count_map=new Object();
var uploads_count = -1;
var current_uploads_id = -1;

function fill_form(type, error_text)
{

if(type == 'out' && document.EditView.to_addrs.value  == '' &&
	document.EditView.cc_addrs.value  == '' &&
	document.EditView.bcc_addrs.value  == '')
{
alert(error_text);
return false;
}

var the_form = document.EditView;
var inputs = the_form.getElementsByTagName('input');

//  this detects if browser needs the following hack or not..
if (inputs.length > 0)
{
	// no need to appendChild to EditView to get file uploads to work
	return check_form('EditView');
}

if (! check_form('EditView'))
{
return false;
}

return true;

}

function setLabels(uploads_arr)
{

}

function deleteFile(index)
{
 var elem = document.getElementById('file'+index);
 elem.style.display='none';
}

                                                                                                              
function addFile()
{

 for(var i=0;i<10;i++)
 {
  var elem = document.getElementById('file'+i);
  if(elem.style.display == 'none')
	{
  	elem.style.display='block';
		break;
	}
 }

}



//following varaibles store references to input fields grouped with the clicked email selection button (select).
var current_contact = '';
var current_contact_id = '';
var current_contact_email = '';
var current_contact_name = '';

//this function appends the selected email address to the aggregated email address fields.
function set_current_parent(id,email,name,value)
{
        current_contact_id.value += id+";";
        current_contact_email.value += email+";";
        current_contact_name.value += name+";";

	if ( current_contact.value != '')
	{
        	current_contact.value += "; ";
	}
	
	current_contact.value += name + " <" + email + ">";
//	current_contact.value += value;
}

function set_email_return(popup_reply_data)
{
	var name_to_value_array = popup_reply_data.name_to_value_array;
	
	var id = name_to_value_array.id;
	var email = name_to_value_array.email1;
	var name = name_to_value_array.name;
	var value = name_to_value_array.email_and_name1;
	
	set_current_parent(id, email, name, value);
}

//create references to input fields associated with the select email address button. Clicked button is passed as the parameter
//to the function. 
function button_change_onclick(obj)
{
  var prefix = 'to_';
	if( obj.name.match(/^cc_/i))
	{
    prefix = 'cc_';
	} 
  else if( obj.name.match(/^bcc_/i))
	{
    prefix = 'bcc_';
	}
	for (var i = 0; i < obj.form.length;i++)
	{
		child = obj.form[i];
		if( child.name.indexOf(prefix) != 0)
		{
			continue;
		}

		if( child.name.match(/addrs_emails$/i))
		{
			current_contact_email = child;
		}
		else if ( child.name.match(/addrs_ids$/i))
		{
        		current_contact_id = child;
		}
		else if ( child.name.match(/addrs_names$/i))
		{
		        current_contact_name = child;
		}
		else if ( child.name.match(/addrs$/i))
		{
			current_contact = child;
		}

	}

	var filter = '';
	if ( document.EditView.parent_type.value  == 'Accounts' &&
		typeof(document.EditView.parent_name.value ) != 'undefined' &&
		document.EditView.parent_name.value != '')
	{
		filter = "&form_submit=false&query=true&account_name=" + escape(document.EditView.parent_name.value);
	}

	var popup_request_data =
	{
		"call_back_function" : "set_email_return",
		"form_name" : "EditView",
		"field_to_name_array" :
		{
			"id" : "id",
			"email1" : "email1",
			"name" : "name",
			"email_and_name1" : "email_and_name1"
		}
	};

	filter += "&html=Email_picker";
	return open_popup("Contacts",600,400,filter,true,false,popup_request_data);
}

//this function clear the value stored in the aggregated email address fields(nodes). it relies on the references set by the button_change_onclick method
function clear_email_addresses() {
	
	if (current_contact != '') {
		current_contact.value = '';
	}
	if (current_contact_id != '') {
		current_contact_id.value = '';
	}
	if (current_contact_email != '') {
		current_contact_email.value = '';
	}
	if (current_contact_name != '') {
		current_contact_name.value = '';
	}
}

function toggle_textarea(obj)
{
 if (obj.checked == true)
 {
	var the_div = document.getElementById('text_div').style.display = 'block';
 } else
 {
	document.getElementById('text_div').style.display = 'none';
 }
}

var append = true;

function fill_email(id)
{

 if (id == '')
 {
        // query based on template, contact_id0,related_to
        if ( ! append )
        {
                document.EditView.name.value  = '';
                document.EditView.description.value = '';
                document.EditView.description_html.value = '';
        }
        return;
 }


 call_json_method('EmailTemplates','retrieve','record='+id,'email_template_object',appendEmailTemplateJSON);
}

function appendEmailTemplateJSON()
{
 // query based on template, contact_id0,related_to
 if ( append )
 {
  document.EditView.name.value += decodeURI(json_objects['email_template_object']['fields']['subject']);
  document.EditView.description.value += decodeURI(json_objects['email_template_object']['fields']['body']).replace(/<BR>/ig, '\n');

  document.EditView.description_html.value += decodeURI(encodeURI(json_objects['email_template_object']['fields']['body_html'])).replace(/<BR>/ig, '\n');
	if ( typeof( html_editor ) != 'undefined')
	{
  html_editor.insertHTML(decodeURI(encodeURI(json_objects['email_template_object']['fields']['body_html'])));
	}
 }
 else
 {
  document.EditView.name.value = decodeURI(json_objects['email_template_object']['fields']['subject']);
  document.EditView.description.value = decodeURI(json_objects['email_template_object']['fields']['body']).replace(/<BR>/ig, '\n');
  document.EditView.description_html.value = decodeURI(json_objects['email_template_object']['fields']['body_html']);
	if ( typeof( html_editor ) != 'undefined')
	{
  	html_editor.insertHTML(decodeURI(json_objects['email_template_object']['fields']['body_html']));
	}
 }

}
