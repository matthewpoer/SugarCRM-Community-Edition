<?php
// $Id: sugar_version.php,v 1.44.2.2 2005/10/20 22:10:37 andrew Exp $
$sugar_version      = '3.5.1b';
$sugar_db_version   = '3.5.1';
$sugar_flavor       = 'OS';
?>
