<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/include/language/en_us.lang.php,v 1.89 2004/10/25 02:32:20 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => '�¼�',
  'LBL_MODULE_TITLE' => '�¼�: ��ҳ',
  'LBL_SEARCH_FORM_TITLE' => '�����¼�',
  'LBL_LIST_FORM_TITLE' => '�¼��б�',
  'LBL_NEW_FORM_TITLE' => '�½��¼�',
  'LBL_CONTACT_CASE_TITLE' => '��ϵ��-�¼�:',
  'LBL_SUBJECT' => '����:',
  'LBL_CASE' => '�¼�:',
  'LBL_CASE_NUMBER' => '�¼����:',
  'LBL_NUMBER' => '���:',
  'LBL_STATUS' => '״̬:',
  'LBL_PRIORITY' => 'Priority:',
  'LBL_ACCOUNT_NAME' => '��˾����:',
  'LBL_DESCRIPTION' => '����:',
  'LBL_CONTACT_NAME' => '��ϵ������:',
  'LBL_CASE_SUBJECT' => '�¼�����:',
  'LBL_CONTACT_ROLE' => '��ɫ:',
  'LBL_LIST_NUMBER' => '���',
  'LBL_LIST_SUBJECT' => '����',
  'LBL_LIST_ACCOUNT_NAME' => '��˾����',
  'LBL_LIST_STATUS' => '״̬',
  'LBL_LIST_PRIORITY' => 'Priority',
  'LBL_LIST_LAST_MODIFIED' => '�����޸�',
  'LBL_INVITEE' => '*Contacts',
  'LNK_NEW_CASE' => '�½��¼�',
  'LNK_CASE_LIST' => 'Cases',
  'NTC_REMOVE_INVITEE' => '*Are you sure you want to remove this contact from the case?',
  'ERR_DELETE_RECORD' => '����ָ����¼�Ų���ɾ����˾.',
  'LNK_NEW_CONTACT' => '�½���ϵ��',
  'LNK_NEW_ACCOUNT' => '�½���˾',
  'LNK_NEW_OPPORTUNITY' => '�½�����',
  'LNK_NEW_NOTE' => '�½���ע',
  'LNK_NEW_CALL' => '�½��绰��¼',
  'LNK_NEW_EMAIL' => '�½�����',
  'LNK_NEW_MEETING' => '�½���̸',
  'LNK_NEW_TASK' => '�½�����',
);


?>