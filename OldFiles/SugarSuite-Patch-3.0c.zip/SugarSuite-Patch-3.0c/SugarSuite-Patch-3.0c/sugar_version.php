<?php
	// $Id: sugar_version.php,v 1.34.2.4 2005/05/17 22:04:10 bob Exp $
	$sugar_version = '3.0c';
?>
