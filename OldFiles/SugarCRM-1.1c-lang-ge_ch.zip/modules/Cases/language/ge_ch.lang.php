<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Cases/language/ge_ch.lang.php, v 1.01 2004/08/09 09:48:58 erich.althaus@creative-solutions.ch $
 * Description:  Defines the Swiss German language pack 
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_MODULE_NAME'=>'Bedarf',
'LBL_MODULE_TITLE'=>'Bedarf: Home',
'LBL_SEARCH_FORM_TITLE'=>'Bedarf suchen',
'LBL_LIST_FORM_TITLE'=>'Bedarfs Liste',
'LBL_NEW_FORM_TITLE'=>'Neuer Bedarf',
'LBL_CONTACT_CASE_TITLE'=>'Kontakt Bedarf:',

'LBL_SUBJECT'=>'Titel:',
'LBL_CASE'=>'Bedarf:',
'LBL_CASE_NUMBER'=>'Nummer:',
'LBL_NUMBER'=>'Nummer:',
'LBL_STATUS'=>'Status:',
'LBL_ACCOUNT_NAME'=>'Kunde:',
'LBL_DESCRIPTION'=>'Beschreibung:',
'LBL_CONTACT_NAME'=>'Kontakt:',
'LBL_CASE_SUBJECT'=>'Titel:',
'LBL_CONTACT_ROLE'=>'Rolle:',

'LBL_LIST_NUMBER'=>'Num.',
'LBL_LIST_SUBJECT'=>'Titel',
'LBL_LIST_ACCOUNT_NAME'=>'Kunde',
'LBL_LIST_STATUS'=>'Status',
'LBL_LIST_LAST_MODIFIED'=>'Zuletzt ge�ndert',

'LNK_NEW_CONTACT'=>'Neuer Kontakt',
'LNK_NEW_ACCOUNT'=>'Neuer Kunde',
'LNK_NEW_OPPORTUNITY'=>'Neuer Auftrag',
'LNK_NEW_CASE'=>'Neuer Bedarf',
'LNK_NEW_NOTE'=>'Neue Notiz',
'LNK_NEW_CALL'=>'Neues Telefonat',
'LNK_NEW_EMAIL'=>'Neue Email',
'LNK_NEW_MEETING'=>'Neuer Termin',
'LNK_NEW_TASK'=>'Neue Pendenz',
'ERR_DELETE_RECORD'=>"Ein Eintrag muss ausgew�hlt sein um ein Bedarf zu l�schen.",
);

?>