<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Contacts/language/ge_ch.lang.php, v 1.01 2004/08/09 erich.althaus@creative-solutions.ch $
 * Description:  Defines the Swiss German language pack 
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_MODULE_NAME'=>'Kontakte',
'LBL_DIRECT_REPORTS_FORM_NAME'=>'Direkter Report',
'LBL_MODULE_TITLE'=>'Kontakte: Home',
'LBL_SEARCH_FORM_TITLE'=>'Kontakt suchen',
'LBL_LIST_FORM_TITLE'=>'Kontakt Liste',
'LBL_NEW_FORM_TITLE'=>'Neuer Kontakt',
'LBL_CONTACT_OPP_FORM_TITLE'=>'Kontakt-Auftrag:',
'LBL_CONTACT'=>'Kontakt:',

'LBL_LIST_NAME'=>'Namen',
'LBL_LIST_LAST_NAME'=>'Nachnamen',
'LBL_LIST_CONTACT_NAME'=>'Kontakt',
'LBL_LIST_TITLE'=>'Titel',
'LBL_LIST_ACCOUNT_NAME'=>'Kunde',
'LBL_LIST_EMAIL_ADDRESS'=>'Email',
'LBL_LIST_PHONE'=>'Telefon',
'LBL_LIST_CONTACT_ROLE'=>'Funktion',

'LBL_NAME'=>'Namen:',
'LBL_CONTACT_NAME'=>'Kontakt:',
'LBL_CONTACT_INFORMATION'=>'Kontakt Informationen',
'LBL_FIRST_NAME'=>'Vornamen:',
'LBL_OFFICE_PHONE'=>'Telefon Gesch�ft:',
'LBL_ACCOUNT_NAME'=>'Kunde:',
'LBL_ANY_PHONE'=>'Weiteres Telefon:',
'LBL_PHONE'=>'Telephon:',
'LBL_LAST_NAME'=>'Nachnamen:',
'LBL_MOBILE_PHONE'=>'Mobile:',
'LBL_HOME_PHONE'=>'Privat:',
'LBL_LEAD_SOURCE'=>'Herkunft:',
'LBL_OTHER_PHONE'=>'Weiteres Telefon:',
'LBL_FAX_PHONE'=>'Fax:',
'LBL_TITLE'=>'Titel:',
'LBL_DEPARTMENT'=>'Abteilung:',
'LBL_BIRTHDATE'=>'Geburtstag:',
'LBL_EMAIL_ADDRESS'=>'Email:',
'LBL_OTHER_EMAIL_ADDRESS'=>'Weitere Email:',
'LBL_ANY_EMAIL'=>'Weitere Email:',
'LBL_REPORTS_TO'=>'Rapportiert an:',
'LBL_ASSISTANT'=>'Assistent:',
'LBL_YAHOO_ID'=>'Yahoo! ID:',
'LBL_ASSISTANT_PHONE'=>'Assistent Telefon:',
'LBL_DO_NOT_CALL'=>'Nicht anrufen:',
'LBL_EMAIL_OPT_OUT'=>'Email Opt Out:',
'LBL_PRIMARY_ADDRESS'=>'Prim�re Adresse:',
'LBL_ALTERNATE_ADDRESS'=>'Weitere Adresse:',
'LBL_ANY_ADDRESS'=>'Weitere Adresse:',
'LBL_CITY'=>'Ort:',
'LBL_STATE'=>'Kanton:',
'LBL_POSTAL_CODE'=>'PLZ:',
'LBL_COUNTRY'=>'Land:',
'LBL_DESCRIPTION_INFORMATION'=>'Zus�tzliche Informationen',
'LBL_DESCRIPTION'=>'Bemerkungen:',
'LBL_CONTACT_ROLE'=>'Rolle:',
'LBL_OPP_NAME'=>'Auftrag:',

'LNK_NEW_CONTACT'=>'Neuer Kontakt',
'LNK_NEW_ACCOUNT'=>'Neuer Kunde',
'LNK_NEW_OPPORTUNITY'=>'Neuer Auftrag',
'LNK_NEW_CASE'=>'Neuer Bedarf',
'LNK_NEW_NOTE'=>'Neue Notiz',
'LNK_NEW_CALL'=>'Neues Telefonat',
'LNK_NEW_EMAIL'=>'Neue Email',
'LNK_NEW_MEETING'=>'Neuer Termin',
'LNK_NEW_TASK'=>'Neue Pendenz',
'ERR_DELETE_RECORD'=>"Ein Eintrag muss ausgew�hlt sein um ein Kontakt zu l�schen.",
'NTC_DELETE_CONFIRMATION'=>'Wollen Sie diesen Eintrag wirklich l�schen?',
'NTC_REMOVE_CONFIRMATION'=>'Wollen Sie diesen Kontakt wirklich von diesem Bedarf entfernen?',
'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION'=>'Wollen Sie diesen Eintrag wirklich von einen direkten Report entfernen?',
'NTC_REMOVE_OPP_CONFIRMATION'=>'Wollen Sie diesen Kontakt wirklich von diesem Auftrag entfernen?',

//New to SugarCRM 1.1c.
'NTC_COPY_PRIMARY_ADDRESS'=>'Kopiere prim�re Adresse zu weitere Adresse',
'NTC_COPY_ALTERNATE_ADDRESS'=>'Kopiere weitere Adresse zu pim�rer Adresse',

);

?>