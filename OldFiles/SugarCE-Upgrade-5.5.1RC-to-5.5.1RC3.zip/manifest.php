<?php
// created: 2010-03-08 16:03:34
$manifest = array (
  'acceptable_sugar_flavors' => 
  array (
    0 => 'CE',
  ),
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '5\\.5\\.1',
    ),
  ),
  'author' => 'SugarCRM, Inc.',
  'copy_files' => 
  array (
    'from_dir' => 'SugarCE-Upgrade-5.5.1RC-to-5.5.1RC3',
    'to_dir' => '',
    'force_copy' => 
    array (
    ),
  ),
  'description' => '',
  'icon' => '',
  'is_uninstallable' => false,
  'offline_client_applicable' => true,
  'name' => 'SugarCE',
  'published_date' => '2010-03-08 16:03:34',
  'type' => 'patch',
  'version' => '5.5.1RC3',
);
?>
