<?php
// created: 2009-03-02 14:32:22
$manifest = array (
  'acceptable_sugar_flavors' => 
  array (
    0 => 'OS',
  ),
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '4\\.5\\.1[l|m]',
    ),
  ),
  'author' => 'SugarCRM, Inc.',
  'copy_files' => 
  array (
    'from_dir' => 'SugarOS-Delta-4.5.1m',
    'to_dir' => '',
    'force_copy' => 
    array (
    ),
  ),
  'description' => '',
  'icon' => '',
  'is_uninstallable' => false,
  'offline_client_applicable' => true,
  'name' => 'SugarOS',
  'published_date' => '2009-03-02 14:32:22',
  'type' => 'patch',
  'version' => '4.5.1m',
);
?>
