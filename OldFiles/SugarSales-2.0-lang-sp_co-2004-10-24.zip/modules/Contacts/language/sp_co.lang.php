<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/include/language/en_us.lang.php,v 1.89 2004/10/25 02:32:20 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Contactos',
  'LBL_INVITEE' => '*Direct Reports',
  'LBL_MODULE_TITLE' => 'Contactos: Inicio',
  'LBL_SEARCH_FORM_TITLE' => 'B�squeda Contactos',
  'LBL_LIST_FORM_TITLE' => ' Lista Contactos',
  'LBL_NEW_FORM_TITLE' => 'Nuevo Contacto',
  'LBL_CONTACT_OPP_FORM_TITLE' => 'Oportunidad-Contacto:',
  'LBL_CONTACT' => 'Contacto:',
  'LBL_BUSINESSCARD' => 'Business Card',
  'LBL_LIST_NAME' => 'Nombre',
  'LBL_LIST_LAST_NAME' => 'Apellido',
  'LBL_LIST_CONTACT_NAME' => 'Nombre Contacto',
  'LBL_LIST_TITLE' => 'T�tulo',
  'LBL_LIST_ACCOUNT_NAME' => 'Nombre Cuenta',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email',
  'LBL_LIST_OTHER_EMAIL_ADDRESS' => 'Other Email',
  'LBL_LIST_PHONE' => 'Tel�fono',
  'LBL_LIST_CONTACT_ROLE' => 'Rol',
  'LBL_LIST_FIRST_NAME' => 'First Name',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_email2' => 'LBL_LIST_OTHER_EMAIL_ADDRESS',
//END DON'T CONVERT
  'LBL_EXISTING_CONTACT' => 'Used an existing contact',
  'LBL_CREATED_CONTACT' => 'Created a new contact',
  'LBL_EXISTING_ACCOUNT' => 'Used an existing account',
  'LBL_CREATED_ACCOUNT' => 'Created a new account',
  'LBL_CREATED_CALL' => 'Created a new call',
  'LBL_CREATED_MEETING' => 'Created a new meeting',
  'LBL_ADDMORE_BUSINESSCARD' => 'Add another business card',
  'LBL_ADD_BUSINESSCARD' => 'Create From Business Card',
  'LBL_NAME' => 'Nombre:',
  'LBL_CONTACT_NAME' => 'Nombre Contacto:',
  'LBL_CONTACT_INFORMATION' => 'Informaci�n Contacto',
  'LBL_FIRST_NAME' => 'Nombre:',
  'LBL_OFFICE_PHONE' => 'Tel�fono Oficina:',
  'LBL_ACCOUNT_NAME' => 'Nombre Cuenta:',
  'LBL_ANY_PHONE' => 'Cualquier Tel�fono:',
  'LBL_PHONE' => 'Tel�fono:',
  'LBL_LAST_NAME' => 'Apellido:',
  'LBL_MOBILE_PHONE' => 'Celular:',
  'LBL_HOME_PHONE' => 'Inicio:',
  'LBL_LEAD_SOURCE' => 'Fuente L�der:',
  'LBL_OTHER_PHONE' => 'Otro Tel�fono:',
  'LBL_FAX_PHONE' => 'Fax:',
  'LBL_TITLE' => 'T�tulo:',
  'LBL_DEPARTMENT' => 'Departamento:',
  'LBL_BIRTHDATE' => 'Cumplea�os:',
  'LBL_EMAIL_ADDRESS' => 'Email:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Otro Email:',
  'LBL_ANY_EMAIL' => 'Cualquier Email:',
  'LBL_REPORTS_TO' => 'Reporta A:',
  'LBL_ASSISTANT' => 'Asistente:',
  'LBL_ASSISTANT_PHONE' => 'Tel�fono Asistente:',
  'LBL_DO_NOT_CALL' => 'No Llamar:',
  'LBL_EMAIL_OPT_OUT' => 'Email Opt Out:',
  'LBL_PRIMARY_ADDRESS' => 'Direcci�n Primaria:',
  'LBL_ALTERNATE_ADDRESS' => 'Otra Direcci�n:',
  'LBL_ANY_ADDRESS' => 'Cualquier Direcci�n:',
  'LBL_CITY' => 'Ciudad:',
  'LBL_STATE' => 'Estado:',
  'LBL_POSTAL_CODE' => 'C�digo Postal:',
  'LBL_COUNTRY' => 'Pa�s:',
  'LBL_DESCRIPTION_INFORMATION' => 'Informaci�n Descriptiva',
  'LBL_ADDRESS_INFORMATION' => '*Address Information',
  'LBL_DESCRIPTION' => 'Descripci�n:',
  'LBL_CONTACT_ROLE' => 'Rol:',
  'LBL_OPP_NAME' => 'Nombre Oportunidad:',
  'LBL_IMPORT_VCARD' => 'Import vCard',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new contact by importing a vCard from your file system.',
  'LBL_DUPLICATE' => 'Possible Duplicate Contacts',
  'MSG_DUPLICATE' => 'Creating this contact may potentialy create a duplicate contact. You may either select a contact from the list below or you may click on Create New Contact to continue creating a new contact with the previously entered data.',
  'LNK_CONTACT_LIST' => 'Contacts',
  'LNK_IMPORT_VCARD' => 'Create From vCard',
  'LNK_NEW_CONTACT' => 'Nuevo Contacto',
  'LNK_NEW_ACCOUNT' => 'Nueva Cuenta',
  'LNK_NEW_OPPORTUNITY' => 'Nueva Oportunidad',
  'LNK_NEW_CASE' => 'Nuevo Caso',
  'LNK_NEW_NOTE' => 'Nueva Nota',
  'LNK_NEW_CALL' => 'Nueva Llamada',
  'LNK_NEW_EMAIL' => 'Nuevo Email',
  'LNK_NEW_MEETING' => 'Nueva Reuni�n',
  'LNK_NEW_TASK' => 'Nueva Tarea',
  'LNK_NEW_APPOINTMENT' => 'Create Appointment',
  'NTC_DELETE_CONFIRMATION' => '�Est� seguro de que quiere borrar este registro?',
  'NTC_REMOVE_CONFIRMATION' => '�Est� seguro que desea borrar este contacto de este caso?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => '�Est� seguro que desea borrar este registro como reporte directo?',
  'ERR_DELETE_RECORD' => 'sp_sp Un n�mero de registro debe ser especificado para borrar el contacto.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Copiar direcci�n primaria a la direcci�n alterna',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Copiar direcci�n alterna a la direcci�n primaria',
  'LBL_SALUTATION' => 'Salutation',
  'LBL_YAHOO_ID' => 'Yahoo! ID:',
);


?>