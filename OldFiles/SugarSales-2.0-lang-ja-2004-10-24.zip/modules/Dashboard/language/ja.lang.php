<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/include/language/en_us.lang.php,v 1.89 2004/10/25 02:32:20 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Dashboard',
  'LBL_MODULE_TITLE' => 'Dashboard: Home',
  'LBL_SALES_STAGE_FORM_TITLE' => '���k�X�e�[�W�ʔ���\\��',
  'LBL_SALES_STAGE_FORM_DESC' => 'Shows cumulative opportunity amounts by selected sales stages for selected users where the expected closed date is within the specificed date range.',
  'LBL_MONTH_BY_OUTCOME' => '���ʌ��ʕʔ���\\��',
  'LBL_MONTH_BY_OUTCOME_DESC' => 'Shows cumulative opportunity amounts by month by outcome for selected users where the expected closed date is within the specificed date range.  Outcome is based on whether the sales stage is Closed Won, Closed Lost or any other value.',
  'LBL_LEAD_SOURCE_FORM_TITLE' => '�������ʏ��k',
  'LBL_LEAD_SOURCE_FORM_DESC' => 'Shows cumulative opportunity amounts by selected lead source for selected users.',
  'LBL_LEAD_SOURCE_BY_OUTCOME' => '�������ʌ��ʕʏ��k',
  'LBL_LEAD_SOURCE_BY_OUTCOME_DESC' => 'Shows cumulative opportunity amounts by selected lead source by outcome for selected users where the expected closed date is within the specificed date range.  Outcome is based on whether the sales stage is Closed Won, Closed Lost or any other value.',
  'LBL_PIPELINE_FORM_TITLE_DESC' => 'Shows cumulative amounts by selected sales stages for your opportunities where the expected closed date is within the specificed date range.',
  'LBL_DATE_RANGE' => 'Date range is',
  'LBL_DATE_RANGE_TO' => 'to',
  'ERR_NO_OPPS' => 'Please create some Opportunities to see Opportunity graphs.',
  'LBL_TOTAL_PIPELINE' => 'Pipeline total is ',
  'LBL_ALL_OPPORTUNITIES' => 'Total amount of all opportunities is ',
  'LBL_OPP_SIZE' => 'Opportunity size in Y1K',
  'NTC_NO_LEGENDS' => 'None',
  'LBL_LEAD_SOURCE_OTHER' => 'Other',
  'LBL_EDIT' => '�ҏW',
  'LBL_REFRESH' => '�X�V',
  'LBL_CREATED_ON' => '�쐬����',
  'LBL_OPPS_IN_STAGE' => 'opportunities where sales stage is',
  'LBL_OPPS_IN_LEAD_SOURCE' => 'opportunities where lead source is',
  'LBL_OPPS_OUTCOME' => 'opportunities where outcome is',
  'LBL_USERS' => '���[�U:',
  'LBL_SALES_STAGES' => '���k�X�e�[�W:',
  'LBL_LEAD_SOURCES' => '������:',
  'LBL_DATE_START' => '�J�n��:',
  'LBL_DATE_END' => '�I����:',
  'LNK_NEW_CONTACT' => '�S���ҍ쐬',
  'LNK_NEW_ACCOUNT' => '�ڋq�쐬',
  'LNK_NEW_OPPORTUNITY' => '���k�쐬',
  'LNK_NEW_QUOTE' => 'Create Quote',
  'LNK_NEW_LEAD' => 'Create Lead',
  'LNK_NEW_CASE' => '����쐬',
  'LNK_NEW_NOTE' => '�m�[�g�쐬',
  'LNK_NEW_CALL' => '�R�[���쐬',
  'LNK_NEW_MEETING' => '�~�[�e�B���O�쐬',
  'LNK_NEW_TASK' => '�^�X�N�쐬',
  'LNK_NEW_EMAIL' => '���[���쐬',
);


?>