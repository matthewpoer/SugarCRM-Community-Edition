<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.2 2004/10/29 15:59:25 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Kontakter',
  'LBL_INVITEE' => '*Direct Reports',
  'LBL_MODULE_TITLE' => 'Kontakter : Hem',
  'LBL_SEARCH_FORM_TITLE' => 'S�k Kontakt',
  'LBL_LIST_FORM_TITLE' => 'Kontaktlista',
  'LBL_NEW_FORM_TITLE' => 'Ny Kontakt',
  'LBL_CONTACT_OPP_FORM_TITLE' => 'Kontakt-Aff�r:',
  'LBL_CONTACT' => 'Kontakt:',
  'LBL_BUSINESSCARD' => 'Business Card',
  'LBL_LIST_NAME' => 'Namn',
  'LBL_LIST_LAST_NAME' => 'Efternamn',
  'LBL_LIST_CONTACT_NAME' => 'Kontaktnamn',
  'LBL_LIST_TITLE' => 'Titel',
  'LBL_LIST_ACCOUNT_NAME' => 'F�retagsnamn',
  'LBL_LIST_EMAIL_ADDRESS' => 'Epost',
  'LBL_LIST_OTHER_EMAIL_ADDRESS' => 'Other Email',
  'LBL_LIST_PHONE' => 'Telefon',
  'LBL_LIST_CONTACT_ROLE' => 'Roll',
  'LBL_LIST_FIRST_NAME' => 'First Name',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_email2' => 'LBL_LIST_OTHER_EMAIL_ADDRESS',
//END DON'T CONVERT
  'LBL_EXISTING_CONTACT' => 'Used an existing contact',
  'LBL_CREATED_CONTACT' => 'Created a new contact',
  'LBL_EXISTING_ACCOUNT' => 'Used an existing account',
  'LBL_CREATED_ACCOUNT' => 'Created a new account',
  'LBL_CREATED_CALL' => 'Created a new call',
  'LBL_CREATED_MEETING' => 'Created a new meeting',
  'LBL_ADDMORE_BUSINESSCARD' => 'Add another business card',
  'LBL_ADD_BUSINESSCARD' => 'Create From Business Card',
  'LBL_NAME' => 'Namn:',
  'LBL_CONTACT_NAME' => 'Kontakt Namn:',
  'LBL_CONTACT_INFORMATION' => 'Kontakt Information',
  'LBL_FIRST_NAME' => 'F�rnamn:',
  'LBL_OFFICE_PHONE' => 'F�retagstelefon:',
  'LBL_ACCOUNT_NAME' => 'F�retagsnamn:',
  'LBL_ANY_PHONE' => 'Telefon:',
  'LBL_PHONE' => 'Telefon:',
  'LBL_LAST_NAME' => 'Efternamn:',
  'LBL_MOBILE_PHONE' => 'Mobiltelefon:',
  'LBL_HOME_PHONE' => 'Hem:',
  'LBL_LEAD_SOURCE' => 'K�lla:',
  'LBL_OTHER_PHONE' => '�vrig Telefon:',
  'LBL_FAX_PHONE' => 'Fax:',
  'LBL_TITLE' => 'Titel:',
  'LBL_DEPARTMENT' => 'Avdelning:',
  'LBL_BIRTHDATE' => 'F�delsedatum:',
  'LBL_EMAIL_ADDRESS' => 'Epost:',
  'LBL_OTHER_EMAIL_ADDRESS' => '�vrig Epost:',
  'LBL_ANY_EMAIL' => 'Epost:',
  'LBL_REPORTS_TO' => 'Rapporterar Till:',
  'LBL_ASSISTANT' => 'Assistent:',
  'LBL_ASSISTANT_PHONE' => 'Assistent Telefon:',
  'LBL_DO_NOT_CALL' => 'Ring Ej:',
  'LBL_EMAIL_OPT_OUT' => 'Epost Opt Out:',
  'LBL_PRIMARY_ADDRESS' => 'Prim�r Adress:',
  'LBL_ALTERNATE_ADDRESS' => '�vrig Adress:',
  'LBL_ANY_ADDRESS' => 'Adress:',
  'LBL_CITY' => 'Ort:',
  'LBL_STATE' => 'Stat:',
  'LBL_POSTAL_CODE' => 'Postnummer:',
  'LBL_COUNTRY' => 'Land:',
  'LBL_DESCRIPTION_INFORMATION' => 'Beskrivning',
  'LBL_ADDRESS_INFORMATION' => '*Address Information',
  'LBL_DESCRIPTION' => 'Beskrivning:',
  'LBL_CONTACT_ROLE' => 'Roll:',
  'LBL_OPP_NAME' => 'Aff�r Namn:',
  'LBL_IMPORT_VCARD' => 'Import vCard',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new contact by importing a vCard from your file system.',
  'LBL_DUPLICATE' => 'Possible Duplicate Contacts',
  'MSG_DUPLICATE' => 'Creating this contact may potentialy create a duplicate contact. You may either select a contact from the list below or you may click on Create New Contact to continue creating a new contact with the previously entered data.',
  'LNK_CONTACT_LIST' => 'Contacts',
  'LNK_IMPORT_VCARD' => 'Create From vCard',
  'LNK_NEW_CONTACT' => 'Ny Kontakt',
  'LNK_NEW_ACCOUNT' => 'Nytt F�retag',
  'LNK_NEW_OPPORTUNITY' => 'Ny Aff�r',
  'LNK_NEW_CASE' => 'Nytt �rende',
  'LNK_NEW_NOTE' => 'Ny Anteckning',
  'LNK_NEW_CALL' => 'Nytt Samtal',
  'LNK_NEW_EMAIL' => 'Ny Epost',
  'LNK_NEW_MEETING' => 'Nytt M�te',
  'LNK_NEW_TASK' => 'Ny Uppgift',
  'LNK_NEW_APPOINTMENT' => 'Create Appointment',
  'NTC_DELETE_CONFIRMATION' => '�r du s�ker p� att du vill radera denna Post?',
  'NTC_REMOVE_CONFIRMATION' => '�r du s�ker p� att du vill ta bort denna Kontakt fr�n detta �rende?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => '�r du s�ker p� att du vill ta bort denna Post som direktrapporterande?',
  'ERR_DELETE_RECORD' => 'Ett Post nummer m�ste anges f�r att radera denna Kontakt.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Copy primary address to alternate address',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Copy alternate address to primary address',
  'LBL_SALUTATION' => 'Salutation',
  'LBL_YAHOO_ID' => 'Yahoo! ID:',
);


?>