<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.2 2004/10/29 15:59:25 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'F�retag',
  'LBL_MODULE_TITLE' => 'F�retag : Hem',
  'LBL_SEARCH_FORM_TITLE' => 'S�k F�retag',
  'LBL_LIST_FORM_TITLE' => 'F�retagslista',
  'LBL_NEW_FORM_TITLE' => 'Nytt F�retag',
  'LNK_NEW_CONTACT' => 'Ny Kontakt',
  'LNK_NEW_ACCOUNT' => 'Nytt F�retag',
  'LNK_NEW_OPPORTUNITY' => 'Ny Aff�r',
  'LNK_NEW_CASE' => 'Nytt �rende',
  'LNK_NEW_NOTE' => 'Ny Anteckning',
  'LNK_NEW_CALL' => 'Nytt Samtal',
  'LNK_NEW_EMAIL' => 'Ny Epost',
  'LNK_NEW_MEETING' => 'Nytt M�te',
  'LNK_NEW_TASK' => 'Ny Uppgift',
  'ERR_DELETE_RECORD' => 'Ett Post nummer m�ste anges f�r att radera F�retaget.',
);


?>