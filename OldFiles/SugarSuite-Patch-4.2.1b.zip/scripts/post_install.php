<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**
 * This script executes after the files are copied during the install.
 *
 * LICENSE: The contents of this file are subject to the SugarCRM Professional
 * End User License Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/EULA.  By installing or using this file, You have
 * unconditionally agreed to the terms and conditions of the License, and You
 * may not use this file except in compliance with the License.  Under the
 * terms of the license, You shall not, among other things: 1) sublicense,
 * resell, rent, lease, redistribute, assign or otherwise transfer Your
 * rights to the Software, and 2) use the Software for timesharing or service
 * bureau purposes such as hosting the Software for commercial gain and/or for
 * the benefit of a third party.  Use of the Software may be subject to
 * applicable fees and any use of the Software without first paying applicable
 * fees is strictly prohibited.  You do not have the right to remove SugarCRM
 * copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2005 SugarCRM, Inc.; All Rights Reserved.
 */

// $Id: post_install.php,v 1.25.2.8.2.4 2006/06/16 03:09:36 ajay Exp $

function _run_sql_file( $filename ){
    if( !is_file( $filename ) ){
        print( "Could not find file: $filename <br>" );
        return( false );
    }

    $fh         = fopen( $filename,'r' );
    $contents   = fread( $fh, filesize($filename) );
    fclose( $fh );

    $lastsemi   = strrpos( $contents, ';') ;
    $contents   = substr( $contents, 0, $lastsemi );
    $queries    = split( ';', $contents );
    $db         = & PearDatabase::getInstance();

	foreach( $queries as $query ){
        $query=trim($query);
		if( !empty($query) && strlen($query) > 10) { // make sure we got a real query
			$GLOBALS['log']->fatal( "Sending query: $query ;<br>" );
			if($db->dbType == 'oci8')
			{




			}
			else
			{
				$query_result = $db->query( $query.';', true,
					"An error has occured while performing db query.  See log file for details.<br>" );
			}
		}
	}

	return( true );
}


































function post_install()
{
	global $unzip_dir;
	global $sugar_config;
	global $sugar_version;

	$log =& $GLOBALS['log'];
	$log->fatal('Entered post_install function.');
	$self_dir = "$unzip_dir/scripts";

	echo "<p><strong>Upgrading the database to version 4.2.1...</strong></p>\n";
	$log->fatal('Upgrading the database to version 4.2.1');

	if($sugar_config['dbconfig']['db_type'] == 'oci8')
	{














	}
	else
	{
		if (substr($sugar_version,0,5) == "4.0.1")
		{
			echo "<p><strong>Running SQL file 401_to_421_mysql.sql...</strong></p>\n";
			$log->fatal('Running SQL file 401_to_421_mysql.sql');
			$sql_run_result = _run_sql_file("$self_dir/401_to_421_mysql.sql");
		}
		else if (substr($sugar_version,0,5) == "4.2.0")
		{
			echo "<p><strong>Running SQL file 420_to_421_mysql.sql...</strong></p>\n";
			$log->fatal('Running SQL file 420_to_421_mysql.sql');
			$sql_run_result = _run_sql_file("$self_dir/420_to_421_mysql.sql");
		}
	}

	if (substr($sugar_version,0,5) == "4.0.1"){
		require_once("$unzip_dir/scripts/file_patcher.php");
		require_once("$unzip_dir/scripts/upgrade_email.php");

		echo "<p><b>Fixing Slot tags for inputs.</b></p>\n";
		$log->info('Fixing Slot tags for inputs.');
		fix_slot_tags();
	
		echo "<p><b>Implementing javascript/css versioning</b></p>\n";
		$log->info('Implementing javascript/css versioning');
		apply_js_versioning();

		echo "<p><b>Upgrading Email</b></p>\n";
		$log->info('Upgrading Email');
		upgrade_email();
		$sugar_config['default_number_grouping_seperator'] = ',';
		$sugar_config['default_decimal_seperator'] = '.';
	
	// serialize the existing themes in the session, 4.2 expects these to be seralized.
		if(isset($_SESSION['avail_themes'])) 
			$_SESSION['avail_themes'] = serialize($_SESSION['avail_themes']);
	}

	echo "<p><strong>Finished.</strong></p>\n";
	//sugar_die('splat!');
}
?>
