<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/sugarcrm/modules/Administration/index.php,v 1.35 2004/10/28 06:49:59 lam Exp $
 * Description: TODO:  To be written.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

global $app_strings;
global $app_list_strings;
global $mod_strings;
global $theme;
global $currentModule;
global $gridline;
global $current_user;

$theme_path="themes/".$theme."/";
$image_path=$theme_path."images/";

require_once($theme_path.'layout_utils.php');
require_once('include/logging.php');

$log = LoggerManager::getLogger('administration');

if (!is_admin($current_user)) sugar_die("Unauthorized access to administration.");

echo "<p>" . get_module_title($mod_strings['LBL_MODULE_NAME'], $mod_strings['LBL_MODULE_TITLE'], true) . "</p>";
?>

<style type="text/css">
.tabDetailViewDL2 {
text-align: left;
}

</style>
<P>
<?php echo get_form_header($mod_strings['LBL_ADMINISTRATION_HOME_TITLE'],'',false); ?>
<table width="100%" cellpadding="0" cellspacing="<?php echo $gridline;?>" border="0" class="tabDetailView2">
<tr>
	<td  width="20%" class="tabDetailViewDL2" nowrap><img src="<?php echo $image_path;?>Administration.png" alt="<?php echo $mod_strings['LBL_CONFIGURE_SETTINGS_TITLE']; ?>" border="0" align="absmiddle">&nbsp;<a href="./index.php?module=Administration&action=ConfigureSettings"  class="tabDetailViewDL2Link"><?php echo $mod_strings['LBL_CONFIGURE_SETTINGS_TITLE']; ?></a></td>
	<td align="left" width="30%" class="tabDetailViewDF2"><?php echo $mod_strings['LBL_CONFIGURE_SETTINGS']; ?></td>
	<td  width="20%" class="tabDetailViewDL2"><img src="<?php echo $image_path;?>Upgrade.png" alt="<?php echo $mod_strings['LBL_UPGRADE_TITLE']; ?>" border="0" align="absmiddle">&nbsp;<a href="./index.php?module=Administration&action=Upgrade" class="tabDetailViewDL2Link"><?php echo $mod_strings['LBL_UPGRADE_TITLE']; ?></a></td>
	<td align="left" width="30%" class="tabDetailViewDF2"><?php echo $mod_strings['LBL_UPGRADE']; ?></td>
</tr>
<tr>
	<td   class="tabDetailViewDL2"><img src="<?php echo $image_path;?>Users.png" alt="<?php echo $mod_strings['LBL_MANAGE_USERS_TITLE']; ?>" border="0" align="absmiddle">&nbsp;<a href="./index.php?module=Users&action=ListView" class="tabDetailViewDL2Link"><?php echo $mod_strings['LBL_MANAGE_USERS_TITLE']; ?></a></td>
	<td align="left"  class="tabDetailViewDF2"><?php echo $mod_strings['LBL_MANAGE_USERS']; ?></td>




</tr>
<tr>
	<td   class="tabDetailViewDL2"><img src="<?php echo $image_path;?>Currencies.png" alt="<?php echo $mod_strings['LBL_MANAGE_CURRENCIES']; ?>" border="0" align="absmiddle">&nbsp;<a href="./index.php?module=Currencies&action=index" class="tabDetailViewDL2Link"><?php echo $mod_strings['LBL_MANAGE_CURRENCIES']; ?></a></td>
	<td align="left"  class="tabDetailViewDF2" ><?php echo $mod_strings['LBL_CURRENCY']; ?></td>
	<td   class="tabDetailViewDL2">&nbsp;</td>
	<td align="left"  class="tabDetailViewDF2" >&nbsp;</td>
	</tr>
</table>

</P>




























