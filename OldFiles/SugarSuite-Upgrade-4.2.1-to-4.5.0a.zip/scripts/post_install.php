<?php
global $sugar_version;
if(substr($sugar_version,0,5) == "4.0.1")
{
    if(empty($GLOBALS['sugarEntry']))
        $GLOBALS['sugarEntry'] = true;
}
else if(!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');

}
/**
 * This script executes after the files are copied during the install.
 *
 * LICENSE: The contents of this file are subject to the SugarCRM Professional
 * End User License Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/EULA.  By installing or using this file, You have
 * unconditionally agreed to the terms and conditions of the License, and You
 * may not use this file except in compliance with the License.  Under the
 * terms of the license, You shall not, among other things: 1) sublicense,
 * resell, rent, lease, redistribute, assign or otherwise transfer Your
 * rights to the Software, and 2) use the Software for timesharing or service
 * bureau purposes such as hosting the Software for commercial gain and/or for
 * the benefit of a third party.  Use of the Software may be subject to
 * applicable fees and any use of the Software without first paying applicable
 * fees is strictly prohibited.  You do not have the right to remove SugarCRM
 * copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2005 SugarCRM, Inc.; All Rights Reserved.
 */
// $Id: post_install.php,v 1.54 2006/09/07 01:18:23 roger Exp $

require_once(clean_path($unzip_dir.'/scripts/upgrade_utils.php'));





















/**
 * code to transfer user preferences to the new method
 */
function do_repair_user_preferences() {
    $db =& PearDatabase::getInstance();

    $display = '';

    // check if this fix has been applied already
    $query = "SELECT id, user_preferences FROM users WHERE status='Active'";
    $data = $db->query($query);

    while($row = $db->fetchByAssoc($data)) {
        $guid = create_guid();
         
        $today = date('Y-m-d H:i:s');
        $query = "INSERT INTO user_preferences (id, category, assigned_user_id, contents, date_entered, date_modified)" .
        		"VALUES ('{$guid}', 'global', '{$row['id']}', '{$row['user_preferences']}', '{$today}',  '{$today}')";
        $db->query($query);
    }

    return true;
}

function replace_tiagara_with_yahoo_tree() {
    _logThis("BEGIN: Upgrading Custom EditView.html for ProductTemplates modules");
    
    if(file_exists("modules/ProductTemplates/EditView.html")) {
        $file = @fopen("modules/ProductTemplates/EditView.html", 'r');
        if (is_resource($file)) {
            $contents = fread($file, filesize("modules/ProductTemplates/EditView.html")); 
            fclose($file);

            $contents=str_replace("<input name='parent_node_id' type=\"hidden\" value='{PARENT_NODE_ID}'>","",$contents);
            $contents=str_replace("node_id","category_id",$contents); 
            $contents=str_replace("NODE_ID","CATEGORY_ID",$contents);
    
            //write file back out
            $file = @fopen("modules/ProductTemplates/EditView.html", 'w');
            if (is_resource($file)) {
                fwrite($file, $contents);
                fclose($file);
            } else {
            _logThis("*** Skipping upgrade of Editview.html, not enough permissions.");      
            }        
        } else {
            _logThis("*** Skipping upgrade of Editview.html, not enough permissions.");      
        }
    } else {
        _logThis("Editview.html not customized.");      
    }
    _logThis("END: Upgrading Custom EditView.html for ProductTemplates modules");
}


function post_install() {
	global $unzip_dir;
	global $sugar_config;
	global $sugar_version;
	global $_SESSION;

	_logThis('Entered post_install function.');
	$self_dir = "$unzip_dir/scripts";

	if(substr($sugar_version,0,5) == "4.0.1") {
		require_once("$unzip_dir/scripts/file_patcher.php");
		require_once("$unzip_dir/scripts/upgrade_email.php");

		_logThis('Fixing Slot tags for inputs.');
		fix_slot_tags();
	
		_logThis('Implementing javascript/css versioning');
		apply_js_versioning();

		_logThis('Upgrading Email');
		upgrade_email();
		$sugar_config['default_number_grouping_seperator'] = ',';
		$sugar_config['default_decimal_seperator'] = '.';
	
		// serialize the existing themes in the session, 4.5 expects these to be seralized.
		if(isset($_SESSION['avail_themes'])) {
			$_SESSION['avail_themes'] = serialize($_SESSION['avail_themes']);
		}
	}
	
	///////////////////////////////////////////////////////////////////////////
	////	PUT DATABASE UPGRADE SCRIPT HANDLING HERE
	$new_sugar_version = getUpgradeVersion();
	$origVersion = substr(preg_replace("/[^0-9]/", "", $sugar_version),0,3);
	$destVersion = substr(preg_replace("/[^0-9]/", "", $new_sugar_version),0,3);
	
	// This flag is determined by the preflight check in the installer
	if(!isset($_SESSION['schema_change']) || /* pre-4.5.0 upgrade wizard */
		$_SESSION['schema_change'] == 'sugar') {
		_logThis("Upgrading the database from {$origVersion} to version {$destVersion}");
		$schemaFileName = $origVersion."_to_".$destVersion;
		
		// cn: use this til i get back
		if(substr($sugar_version,0,5) == "4.0.1") {
			if($sugar_config['dbconfig']['db_type'] == 'oci8') {









			} else {
				_logThis("Running SQL file 401_to_450_mysql.sql");
				$schemaFile = "$self_dir/401_to_450_mysql.sql";
				if(is_file($schemaFile)) {
					$sql_run_result = _run_sql_file($schemaFile);
				} else {
					logThis("*** ERROR: Schema change script [{$schemaFile}] could not be found!");
				}
			}
		} elseif(substr($sugar_version,0,5) == "4.2.1") {
			if($sugar_config['dbconfig']['db_type'] == 'oci8') {









			} else {
				_logThis("Running SQL file 421_to_450_mysql.sql");
				$schemaFile = "$self_dir/421_to_450_mysql.sql";
				if(is_file($schemaFile)) {
					$sql_run_result = _run_sql_file($schemaFile);
				} else {
					logThis("*** ERROR: Schema change script [{$schemaFile}] could not be found!");
				}
			}
		}
	} else {
		_logThis('*** Skipping Schema Change Scripts - Admin opted to run queries manually and should have done so by now.');
	}
	////	END SCHEMA CHANGE UPGRADE SCRIPTS
	///////////////////////////////////////////////////////////////////////////

	///////////////////////////////////////////////////////////////////////////
	////	UPDATE USER PREFERENCES
	do_repair_user_preferences(); // needs to run AFTER the new table is created.
	
	///////////////////////////////////////////////////////////////////////////
	////	FIX INBOUND EMAIL PASSWORDS
	if(!isset($sugar_config['disc_client']) || $sugar_config['disc_client'] != true){
        require_once("$unzip_dir/scripts/upgrade_inbound_email.php");
        fixInboundEmail();
    }
	
	///////////////////////////////////////////////////////////////////////////
	////	DROP USER_PASSWORD COLUMN
	updateUserPasswordColumn();
	
	///////////////////////////////////////////////////////////////////////////
	////	PRO/ENT ONLY FINAL TOUCHES



	
	///////////////////////////////////////////////////////////////////////////
	////	REPAIR CUSTOMIZED SEARCH FORMS
	require_once("$unzip_dir/scripts/upgradeSearchForm.php");
	upgradeSearchForms();
	
    replace_tiagara_with_yahoo_tree();
    
	///////////////////////////////////////////////////////////////////////////
	////	FINALIZE VERSION UPDATES
	upgradeDbAndFileVersion($new_sugar_version);
}
?>
