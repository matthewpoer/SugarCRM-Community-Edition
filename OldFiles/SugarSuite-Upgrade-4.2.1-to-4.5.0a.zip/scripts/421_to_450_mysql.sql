-- MySQL upgrade script for Sugar 4.2.0 to 4.5.0dev 
-- $Id: 421_to_450_mysql.sql,v 1.21 2006/08/16 00:23:24 chris Exp $

--
-- NEW TABLES
--






















--
-- SAVED_SEARCH
--
CREATE TABLE `saved_search` (
  `id` varchar(36) NOT NULL default '',
  `name` varchar(150) default NULL,
  `search_module` varchar(150) default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  `date_entered` datetime NOT NULL default '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL default '0000-00-00 00:00:00',
  `assigned_user_id` varchar(36) default NULL,



  `contents` text,
  `description` text,
  PRIMARY KEY  (`id`),
  KEY `idx_desc` (`name`,`deleted`)) DEFAULT CHARSET=utf8;

-- session
CREATE TABLE `session_active` (
   `id` varchar(36) NOT NULL default '',
   `session_id` varchar(100) default NULL,
   `last_request_time` datetime default NULL,
   `session_type` varchar(100) default NULL,
   `is_violation` tinyint(1) default '0',
   `num_active_sessions` int(11) default '0',
   `date_entered` datetime default NULL,
   `date_modified` datetime default NULL,
   `deleted` tinyint(1) NOT NULL default '0',
   PRIMARY KEY  (`id`),
   UNIQUE KEY `idx_session_id` (`session_id`)) DEFAULT CHARSET=utf8;

-- Table structure for table `session_history`
 CREATE TABLE `session_history` (
   `id` varchar(36) NOT NULL default '',
   `session_id` varchar(100) default NULL,
   `date_entered` datetime default NULL,
   `date_modified` datetime default NULL,
   `last_request_time` datetime default NULL,
   `session_type` varchar(100) default NULL,
   `is_violation` tinyint(1) default '0',
   `num_active_sessions` int(11) default '0',
   `deleted` tinyint(1) NOT NULL default '0',
   PRIMARY KEY  (`id`)) DEFAULT CHARSET=utf8;

--
-- USER_PREFERENCES
--
CREATE TABLE `user_preferences` (
  `id` varchar(36) NOT NULL default '',
  `category` varchar(50) default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  `date_entered` datetime NOT NULL default '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL default '0000-00-00 00:00:00',
  `assigned_user_id` varchar(36) default NULL,
  `contents` text,
  PRIMARY KEY  (`id`),
  KEY `idx_userprefnamecat` (`assigned_user_id`,`category`)) DEFAULT CHARSET=utf8;



















--
-- EXISTING TABLES ------------------------------------------------------------------------
--

-- 
-- CONTACTS
--
ALTER TABLE `contacts` CHANGE COLUMN `do_not_call` `do_not_call` varchar(3) default '0';
ALTER TABLE `contacts` CHANGE COLUMN `email_opt_out` `email_opt_out` varchar(3) default '0';
ALTER TABLE `contacts` ADD COLUMN `portal_password` varchar(32) NULL AFTER `portal_active`;


-- 
-- CURRENCIES
--

ALTER TABLE `currencies` CHANGE COLUMN `iso4217` `iso4217` varchar(3) NOT NULL default '';







































--
-- DOCUMENTS
--

ALTER TABLE `documents` CHANGE COLUMN `mail_merge_document` `mail_merge_document` varchar(3) default 'off';


--
-- EMAIL_TEMPLATES
--

ALTER TABLE `email_templates` CHANGE COLUMN `published` `published` varchar(3) default NULL;


--
-- EMAILS
--
ALTER TABLE `emails` ADD COLUMN `raw_source` text AFTER `mailbox_id`; 

--
-- FIELDS_META_DATA
--
ALTER TABLE `fields_meta_data` ADD COLUMN `help` varchar(255) default NULL AFTER `label`;
ALTER TABLE `fields_meta_data` CHANGE COLUMN `ext1` `ext1` varchar(255) default '';
ALTER TABLE `fields_meta_data` CHANGE COLUMN `ext2` `ext2` varchar(255) default '';
ALTER TABLE `fields_meta_data` CHANGE COLUMN `ext3` `ext3` varchar(255) default '';
ALTER TABLE `fields_meta_data` ADD COLUMN `ext4` text AFTER `ext3`;
ALTER TABLE `fields_meta_data` ADD COLUMN `duplicate_merge` smallint default 0 AFTER `ext4`;













--
-- IMPORT_MAPS
--
ALTER TABLE `import_maps` CHANGE COLUMN `is_published` `is_published` varchar(3) NOT NULL default 'no';

-- 
-- LEADS
--
ALTER TABLE `leads` CHANGE COLUMN `do_not_call` `do_not_call` varchar(3) default '0';
ALTER TABLE `leads` CHANGE COLUMN `email_opt_out` `email_opt_out` varchar(3) default '0';



-- 
-- PROSPECTS
--
ALTER TABLE `prospects` CHANGE COLUMN `do_not_call` `do_not_call` varchar(3) default '0';
ALTER TABLE `prospects` CHANGE COLUMN `email_opt_out` `email_opt_out` varchar(3) default '0';






















--
-- USER
--
ALTER TABLE `users` CHANGE COLUMN `user_name` `user_name` varchar(60) default NULL;
ALTER TABLE `users` ADD COLUMN `authenticate_id` varchar(100) default NULL AFTER `user_hash`;
ALTER TABLE `users` ADD COLUMN `sugar_login` tinyint(1) default '1' AFTER `authenticate_id`;
UPDATE `users` SET is_admin = '1' WHERE is_admin = 'on';
UPDATE `users` SET is_admin = '0' WHERE is_admin != '1';
ALTER TABLE `users` CHANGE COLUMN `is_admin` `is_admin` tinyint(1) default '0';
ALTER TABLE `users` CHANGE COLUMN `receive_notifications` `receive_notifications` tinyint(1) default '1';



















--
-- insert a row for notify into config --------------------------------------------------------------
--

INSERT INTO `config` (`category`, `name`, `value`)
VALUES ('notify', 'send_from_assigning_user', '0');

