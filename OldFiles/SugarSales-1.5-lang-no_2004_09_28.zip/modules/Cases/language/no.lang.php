<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Cases/language/no.lang.php,v 1.0 2004/09/27 HHN Exp $
 * Description:  Defines the Norwegian language pack for the Saker module.
 ********************************************************************************/

$mod_strings = Array(
'LBL_MODULE_NAME'=>'Saker',
'LBL_MODULE_TITLE'=>'Sak : Hjem',
'LBL_SEARCH_FORM_TITLE'=>'S&oslash;k Saker',
'LBL_LIST_FORM_TITLE'=>'Saksliste',
'LBL_NEW_FORM_TITLE'=>'Ny Sak',
'LBL_CONTACT_CASE_TITLE'=>'Kontakt-Sak:',

'LBL_SUBJECT'=>'Sak:',
'LBL_CASE'=>'Sak:',
'LBL_CASE_NUMBER'=>'Casenummer:',
'LBL_NUMBER'=>'Nummer:',
'LBL_STATUS'=>'Status:',
'LBL_ACCOUNT_NAME'=>'Virksomhet:',
'LBL_DESCRIPTION'=>'Beskrivelse:',
'LBL_CONTACT_NAME'=>'Kontakt Navn:',
'LBL_CASE_SUBJECT'=>'Sak overskrift:',
'LBL_CONTACT_ROLE'=>'Rolle:',

'LBL_LIST_NUMBER'=>'Num.',
'LBL_LIST_SUBJECT'=>'Rubrik',
'LBL_LIST_ACCOUNT_NAME'=>'Virksomhet',
'LBL_LIST_STATUS'=>'Status',
'LBL_LIST_LAST_MODIFIED'=>'Sist Oppdatert',

'LNK_NEW_CONTACT'=>'Ny Kontakt',
'LNK_NEW_ACCOUNT'=>'Ny Virksomhet',
'LNK_NEW_OPPORTUNITY'=>'Ny Salgs Mulighet',
'LNK_NEW_CASE'=>'Ny Sak',
'LNK_NEW_NOTE'=>'Nytt Notat',
'LNK_NEW_CALL'=>'Ny Samtale',
'LNK_NEW_EMAIL'=>'Ny Epost',
'LNK_NEW_MEETING'=>'Nytt M&oslash;te',
'LNK_NEW_TASK'=>'Ny Oppgave',
'ERR_DELETE_RECORD'=>"Et Postnummer skal oppgis for &aring; slette Virksomheten.",
'LBL_INVITEE'=>'Kontakter',
'NTC_REMOVE_INVITEE'=>'Er du sikker p&aring; &aring; slette denne Kontakten fra saken?',
);

?>