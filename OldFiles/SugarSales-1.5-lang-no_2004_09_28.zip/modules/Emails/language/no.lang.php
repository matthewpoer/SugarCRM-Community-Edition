<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/emails/language/no.lang.php,v 1.0 2004/09/27 HHN Exp $
 * Description:  Defines the Norwegian language pack for the Epost module.
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_MODULE_NAME'=>'Epost',
'LBL_MODULE_TITLE'=>'Epost : Hjem',
'LBL_SEARCH_FORM_TITLE'=>'S&oslash;k Epost',
'LBL_LIST_FORM_TITLE'=>'Epost liste',
'LBL_NEW_FORM_TITLE'=>'Oppf&oslash;lgings Epost',

'LBL_LIST_SUBJECT'=>'Vedr&oslash;rende',
'LBL_LIST_CONTACT'=>'Kontakt',
'LBL_LIST_RELATED_TO'=>'Relatert til',
'LBL_LIST_DATE'=>'Sendt Dato',
'LBL_LIST_TIME'=>'Sendt Tid',

'ERR_DELETE_RECORD'=>"Et Postnummer skal oppgis for &aring; slette Virksomheten.",
'LBL_DATE_SENT'=>'Sendt Dato:',
'LBL_SUBJECT'=>'Vedr&oslash;rende:',
'LBL_BODY'=>'Innhold:',
'LBL_DATE_AND_TIME'=>'Sendt Dato & Tid:',
'LBL_DATE'=>'Sendt Dato:',
'LBL_TIME'=>'Sendt Tid:',
'LBL_SUBJECT'=>'Vedr&oslash;rende:',
'LBL_BODY'=>'Innhold:',
'LBL_CONTACT_NAME'=>' Kontakt Navn: ',
'LBL_EMAIL'=>'Epost:',  
'LBL_COLON'=>':',

'LNK_NEW_CONTACT'=>'Ny Kontakt',
'LNK_NEW_ACCOUNT'=>'Ny Virksomhet',
'LNK_NEW_OPPORTUNITY'=>'Ny Salgs Mulighet',
'LNK_NEW_CASE'=>'Nytt Sak',
'LNK_NEW_NOTE'=>'Nytt Notat',
'LNK_NEW_CALL'=>'Ny Samtale',
'LNK_NEW_EMAIL'=>'Ny Epost',
'LNK_NEW_MEETING'=>'Nytt M&oslash;te',
'LNK_NEW_TASK'=>'Ny Oppgave',
'NTC_REMOVE_INVITEE'=>'Er du sikker p&aring; &aring; slette denne mottakeren fra Epost?',
'LBL_INVITEE'=>'Mottakere',
);

?>