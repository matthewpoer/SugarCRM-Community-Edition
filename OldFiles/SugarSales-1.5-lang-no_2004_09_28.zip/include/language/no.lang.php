<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/include/language/no.lang.php,v 1.0 2004/09/27 HHN Exp $
 * Description:  Defines the Norwegian language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$app_strings = Array(
'LNK_ABOUT'=>'Om oss',

'LBL_DATE_MODIFIED'=>'Sist endret:',
'LBL_DATE_ENTERED'=>'Opprettet:',

'LBL_BACK'=>'Tilbake',
'LBL_IMPORT'=>'Importer',
'LBL_EXPORT'=>'Eksporter',

'LBL_BROWSER_TITLE'=>'SugarCRM - Kommersiell Open Source CRM',
'LBL_MY_ACCOUNT'=>'Min Konto',
'LBL_ADMIN'=>'Admin',
'LBL_LOGOUT'=>'Logg ut',
'LBL_SEARCH'=>' S&oslash;k',
'LBL_LAST_VIEWED'=>'Siste info',
'NTC_WELCOME'=>'Velkommen',
'NTC_SUPPORT_SUGARCRM'=>"St&oslash;tt SugarCRM open source prosjektet med en donation via PayPal - det er hurtig, gratis og sikkert!",
'NTC_NO_ITEMS_DISPLAY'=>'ingenting',
'LBL_ALT_HOT_KEY'=>'Alt+',

'LBL_SAVE_BUTTON_TITLE'=>'Lagre [Alt+S]',
'LBL_EDIT_BUTTON_TITLE'=>'Rediger [Alt+E]',
'LBL_EDIT_BUTTON'=>'Rediger',
'LBL_DUPLICATE_BUTTON_TITLE'=>'Kopier [Alt+U]',
'LBL_DUPLICATE_BUTTON'=>'Kopier',
'LBL_DELETE_BUTTON_TITLE'=>'Slett [Alt+D]',
'LBL_DELETE_BUTTON'=>'Slett',
'LBL_NEW_BUTTON_TITLE'=>'Ny [Alt+N]',
'LBL_CHANGE_BUTTON_TITLE'=>'Endre [Alt+G]',
'LBL_CANCEL_BUTTON_TITLE'=>'Avbryt [Alt+X]',
'LBL_SEARCH_BUTTON_TITLE'=>'S&oslash;k [Alt+Q]',
'LBL_CLEAR_BUTTON_TITLE'=>'Slett [Alt+C]',
'LBL_SELECT_BUTTON_TITLE'=>'Velg [Alt+T]',
'LBL_SAVE_BUTTON_KEY'=>'S',
'LBL_EDIT_BUTTON_KEY'=>'E',
'LBL_DUPLICATE_BUTTON_KEY'=>'U',
'LBL_DELETE_BUTTON_KEY'=>'D',
'LBL_NEW_BUTTON_KEY'=>'N',
'LBL_CHANGE_BUTTON_KEY'=>'G',
'LBL_CANCEL_BUTTON_KEY'=>'X',
'LBL_SEARCH_BUTTON_KEY'=>'Q',
'LBL_CLEAR_BUTTON_KEY'=>'C',
'LBL_SELECT_BUTTON_KEY'=>'T',
'LBL_SAVE_BUTTON_LABEL'=>'Lagre',
'LBL_EDIT_BUTTON_LABEL'=>'Rediger',
'LBL_DUPLICATE_BUTTON_LABEL'=>'Kopier',
'LBL_DELETE_BUTTON_LABEL'=>'Slett',
'LBL_NEW_BUTTON_LABEL'=>'Ny',
'LBL_CHANGE_BUTTON_LABEL'=>'Endre',
'LBL_CANCEL_BUTTON_LABEL'=>'Avbryt',
'LBL_SEARCH_BUTTON_LABEL'=>' S&oslash;k',
'LBL_CLEAR_BUTTON_LABEL'=>'Slett',
'LBL_SELECT_BUTTON_LABEL'=>'Velg',

'LNK_ADVANCED_SEARCH'=>'Avansert',
'LNK_BASIC_SEARCH'=>'Enkel',
'LNK_EDIT'=>'rediger',
'LNK_REMOVE'=>'fjern',
'LNK_DELETE'=>'Slett',
'LNK_LIST_START'=>'Start',
'LNK_LIST_NEXT'=>'Neste',
'LNK_LIST_PREVIOUS'=>'Forrige',
'LNK_LIST_END'=>'Stopp',
'LBL_LIST_OF'=>'av',
'LNK_PRINT'=>'Skriv ut',
'LNK_HELP'=>'Hjelp',

'NTC_REQUIRED'=>'Markerer obligatoriske felt',
'LBL_REQUIRED_SYMBOL'=>'*',
'LBL_CURRENCY_SYMBOL'=>'Kr.',
'LBL_THOUSANDS_SYMBOL'=>'K',
'NTC_DATE_FORMAT'=>'(&aring;&aring;&aring;&aring;-mm-dd)',
'NTC_TIME_FORMAT'=>'(24:00)',
'NTC_DATE_TIME_FORMAT'=>'(&aring;&aring;&aring;&aring;-mm-dd 24:00)',
'NTC_DELETE_CONFIRMATION'=>'Er du sikker p&aring; at du vil slette denne oppf&oslash;ringen?',
'ERR_DELETE_RECORD'=>'Et oppf&oslash;rings nr kreves for &aring; slette den aktuelle kontakten.',
'ERR_CREATING_TABLE'=>'Feil ved opprettelse av tabellen: ',
'ERR_CREATING_FIELDS'=>'Feil ved utfylling av ekstra detaljert informasjon: ',
'ERR_MISSING_REQUIRED_FIELDS'=>'Obligatorisk felt mangler:',
'ERR_INVALID_EMAIL_ADDRESS'=>'er ikke en gyldig epostadresse.',
'ERR_INVALID_DATE_FORMAT'=>'Datoformatet skal v&aelig;re : &aring;&aring;&aring;&aring;-mm-dd',
'ERR_INVALID_MONTH'=>'Angi gyldig m&aring;ned.',
'ERR_INVALID_DAY'=>'Angi gyldig dato.',
'ERR_INVALID_YEAR'=>'Angi gyldig &aring;rstall med 4 cifre.',
'ERR_INVALID_DATE'=>'Angi gyldig dato.',
'ERR_INVALID_HOUR'=>'Angi gyldig time.',
'ERR_INVALID_TIME'=>'Angi gyldig klokkeslett.',
'NTC_CLICK_BACK'=>'Klikk p&aring; tilbake knappen og korriger opplysningene.',
'LBL_LIST_ASSIGNED_USER'=>'Tildelt',
'LBL_ASSIGNED_TO'=>'Tildelt:',
'LBL_CURRENT_USER_FILTER'=>'Vis kun de opplysningene som er tildelt meg:',

//New strings for 1.1c.  These still need to be translated.
'LBL_SELECT_CONTACT_BUTTON_TITLE'=>'Velg kontakt [Alt+T]',
'LBL_SELECT_CONTACT_BUTTON_KEY'=>'T',
'LBL_SELECT_CONTACT_BUTTON_LABEL'=>'Velg kontakt',
'LBL_SELECT_USER_BUTTON_TITLE'=>'Velg bruker [Alt+U]',
'LBL_SELECT_USER_BUTTON_KEY'=>'U',
'LBL_SELECT_USER_BUTTON_LABEL'=>'Velg bruker',
'LBL_USER_LIST'=>'Bruker liste',
'LBL_CONTACT_LIST'=>'Kontakt liste',
'LBL_LIST_NAME'=>'Navn',
'LBL_LIST_USER_NAME'=>'Bruker Navn',
'LBL_LIST_EMAIL'=>'epost',
'LBL_LIST_PHONE'=>'Tlf',
'LBL_LIST_CONTACT_NAME'=>'Kontakt Navn',
'LBL_LIST_ACCOUNT_NAME'=>'Virksomhet Navn',
'NTC_LOGIN_MESSAGE'=>"Vennligst logg inn.",
'LBL_NONE'=>'--Null--',
'LBL_CHARSET'=>'ISO-8859-1',
);

//the left value is the key stored in the db and the right value is the display value
//to translate, only modify the right value in each key/value pair
$app_list_strings = Array(
//e.g. auf Deutsch 'Contacts'=>'Kontakter',
'moduleList' => Array('Home'=>'Hjem'
				, 'Dashboard'=>'Oversikt'
				, 'Contacts'=>'Kontakter'
				, 'Accounts'=>'Virksomhet'
				, 'Opportunities'=>'Salgs Muligheter'
				, 'Cases'=>'Saker'
				, 'Notes'=>'Notater & Vedlegg'
				, 'Calls'=>'Samtaler'
				, 'Emails'=>'Eposter'
				, 'Meetings'=>'M&oslash;ter'
				, 'Tasks'=>'Oppgaver'),

//e.g. en fran�ais 'Analyst'=>'Analytiker',
'account_type_dom' => Array(''=>''
		, 'Analyst'=>'Analytiker'
		, 'Integrator'=>'Integrator'
		, 'Investor'=>'Investor'
		, 'Competitor'=>'Konkurrent'
		, 'Customer'=>'Kunde'
		, 'Prospect'=>'Kundeemne'
		, 'Partner'=>'Partner'
		, 'Press'=>'Presse'
		, 'Reseller'=>'Forhandler'
		, 'Andre'=>'Annet'
		),

'industry_dom' => Array(''=>''
		, 'Banking'=>'Bank'
		, 'Apparel'=>'Kl&aelig;r og t&oslash;y'
		, 'Biotechnology'=>'Bioteknologi'
		, 'Electronics'=>'Elektronikk'
		, 'Energy'=>'Energi'
		, 'Finance'=>'Finans'
		, 'Shipping'=>'Frakt'
		, 'Insurance'=>'Forsikring'
		, 'Retail'=>'Handel'
		, 'Hospitality'=>'Hotel/Restaurant'
		, 'Healthcare'=>'Helse'
		, 'Not For Profit'=>'Non profit'
		, 'Engineering'=>'Ingeni&oslash;rer'
		, 'Chemicals'=>'Kjemikalie'
		, 'Communications'=>'Kommunikasjon'
		, 'Consulting'=>'Konsult'
		, 'Construction'=>'Konstruksjon'
		, 'Food & Beverage'=>'Mat og drikke'
		, 'Machinery'=>'Maskinteknikk'
		, 'Media'=>'Media'
		, 'Environmental'=>'Milj&oslash;'
		, 'Government'=>'Offentlig forvaltning'
		, 'Entertainment'=>'Underholdning'
		, 'Education'=>'Uddannelse'
		, 'Manufacturing'=>'Produsent'
		, 'Technology'=>'Teknologi'
		, 'Telecommunications'=>'Telekommunikasjon'
		, 'Transportation'=>'Transport'
		, 'Recreation'=>'Turisme/reiser'
		, 'Utilities'=>'Verkt&oslash;y'
		, 'Andre'=>'Annet'
		),

'lead_source_dom' => Array(''=>''
		, 'Cold Call'=>'Uinteressert'
		, 'Existing Customer'=>'Eksisterende kunde'
		, 'Self Generated'=>'Personlig'
		, 'Employee'=>'Ansatt'
		, 'Partner'=>'Partner'
		, 'Public Relations'=>'Public Relations'
		, 'Direct Mail'=>'Direct Mail'
		, 'Conference'=>'Konferanse'
		, 'Trade Show'=>'Messe'
		, 'Web Site'=>'Internet Side'
		, 'Word of mouth'=>'Muntlig'
		, 'Andre'=>'Annet'
		),

'opportunity_type_dom' => Array(''=>''
		, 'Existing Business'=>'Eksisterende forretning'
		, 'New Business'=>'Ny forretning'
		),

//Note:  do not translate opportunity_relationship_type_default_key
//       it is the key for the default opportunity_relationship_type_dom value
'opportunity_relationship_type_default_key' => 'Primary Decision Maker',
'opportunity_relationship_type_dom' => Array(''=>''
		, 'Primary Decision Maker'=>'Prim&aelig;r beslutningstaker'
		, 'Business Decision Maker'=>'Forretningsmessig beslutningstaker'
		, 'Business Evaluator'=>'Forretningsmessig evaluator'
		, 'Technical Decision Maker'=>'Teknisk beslutningstaker'
		, 'Technical Evaluator'=>'Teknisk evaluator'
		, 'Executive Sponsor'=>'Ledelse'
		, 'Influencer'=>'Person med innflytelse'
		, 'Other'=>'Annet'
		),

//Note:  do not translate case_relationship_type_default_key
//       it is the key for the default case_relationship_type_dom value
'case_relationship_type_default_key' => 'Primary Contact',
'case_relationship_type_dom' => Array(''=>''
		, 'Primary Contact'=>'Prim&aelig;r kontakt'
		, 'Alternate Contact'=>'Alternativ kontakt'
		),

'sales_stage_dom' => Array('Prospecting'=>'Prospektering'
		, 'Qualification'=>'Kvalifikasjon'
		, 'Needs Analysis'=>'Analyse n&oslash;dvendig'
		, 'Value Proposition'=>'Foresl&aring; verdi'
		, 'Id. Decision Makers'=>'Identifiser beslutningstaker'
		, 'Perception Analysis'=>'Analyser oppfattelse'
		, 'Proposal/Price Quote'=>'Tilbud'
		, 'Negotiation/Review'=>'Forhandling/oppdatering'
		, 'Closed Won'=>'Avsluttet vunnet'
		, 'Closed Lost'=>'Avsluttet tapt'
		),

'salutation_dom' => Array(''=>''
		, 'Mr.'=>'Hr'
		, 'Ms.'=>'Fr&oslash;ken'
		, 'Mrs.'=>'Fru'
		, 'Dr.'=>'Dr.'
		, 'Prof.'=>'Prof.'
		),

'task_priority_dom' => Array('High'=>'H&oslash;y'
		, 'Medium'=>'Medium'
		, 'Low'=>'Lav'
		),

'task_status_dom' => Array('Not Started'=>'Ikke p&aring;begynt'
		, 'In Progress'=>'Aktiv'
		, 'Completed'=>'Avsluttet'
		, 'Pending Input'=>'Venter p&aring; opplysninger'
		, 'Deferred'=>'Kansellert'
		),

'meeting_status_dom' => Array('Planned'=>'Planlagt'
		, 'Held'=>'Fullf&oslash;rt'
		, 'Not Held'=>'Ikke Fullf&oslash;rt'
		),

'call_status_dom' => Array('Planned'=>'Planlagt'
		, 'Held'=>'Fullf&oslash;rt'
		, 'Not Held'=>'Ikke Fullf&oslash;rt'
		),

//Note:  do not translate case_status_default_key
//       it is the key for the default case_status_dom value
'case_status_default_key' => 'New',
'case_status_dom' => Array('New'=>'Ny'
		, 'Assigned'=>'Tildelt'
		, 'Closed'=>'Avsluttet'
		, 'Pending Input'=>'Venter p&aring; opplysninger'
		, 'Rejected'=>'Avslag'
		),

'user_status_dom' => Array('Active'=>'Aktiv'
		, 'Inactive'=>'Inaktiv'
		),

//Note:  do not translate record_type_default_key
//       it is the key for the default record_type_module value
'record_type_default_key' => 'Accounts',
'record_type_display' => array('Accounts' => 'Virksomhet',
		'Opportunities' => 'Mulighet',
		'Cases' => 'Sak'),

);

?>