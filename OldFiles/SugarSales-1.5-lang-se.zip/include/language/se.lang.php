<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/include/language/en_us.lang.php,v 1.23 2004/08/04 17:48:18 sugarjacob Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$app_strings = Array(
'LNK_ABOUT'=>'*About',

'LBL_DATE_MODIFIED'=>'*Last Modified:',
'LBL_DATE_ENTERED'=>'*Created:',

'LBL_BACK'=>'*Back',
'LBL_IMPORT'=>'*Import',
'LBL_EXPORT'=>'*Export',

'LBL_BROWSER_TITLE'=>'SugarCRM - Commercial Open Source CRM',
'LBL_MY_ACCOUNT'=>'Mitt Konto',
'LBL_ADMIN'=>'Admin',
'LBL_LOGOUT'=>'Logga ut',
'LBL_SEARCH'=>'S�k',
'LBL_LAST_VIEWED'=>'Senaste info',
'NTC_WELCOME'=>'V�lkommen',
'NTC_SUPPORT_SUGARCRM'=>"Support the SugarCRM open source project with a donation through PayPal - it's fast, free and secure!",
'NTC_NO_ITEMS_DISPLAY'=>'ingenting',
'LBL_ALT_HOT_KEY'=>'Alt+',

'LBL_SAVE_BUTTON_TITLE'=>'Spara [Alt+S]',
'LBL_EDIT_BUTTON_TITLE'=>'Redigera [Alt+E]',
'LBL_EDIT_BUTTON'=>'Redigera',
'LBL_DUPLICATE_BUTTON_TITLE'=>'Duplicera [Alt+U]',
'LBL_DUPLICATE_BUTTON'=>'Duplicera',
'LBL_DELETE_BUTTON_TITLE'=>'Radera [Alt+D]',
'LBL_DELETE_BUTTON'=>'Radera',
'LBL_NEW_BUTTON_TITLE'=>'Nytt [Alt+N]',
'LBL_CHANGE_BUTTON_TITLE'=>'�ndra [Alt+G]',
'LBL_CANCEL_BUTTON_TITLE'=>'Avbryt [Alt+X]',
'LBL_SEARCH_BUTTON_TITLE'=>'S�k [Alt+Q]',
'LBL_CLEAR_BUTTON_TITLE'=>'Radera [Alt+C]',
'LBL_SELECT_BUTTON_TITLE'=>'V�lj [Alt+T]',
'LBL_SAVE_BUTTON_KEY'=>'S',
'LBL_EDIT_BUTTON_KEY'=>'E',
'LBL_DUPLICATE_BUTTON_KEY'=>'U',
'LBL_DELETE_BUTTON_KEY'=>'D',
'LBL_NEW_BUTTON_KEY'=>'N',
'LBL_CHANGE_BUTTON_KEY'=>'G',
'LBL_CANCEL_BUTTON_KEY'=>'X',
'LBL_SEARCH_BUTTON_KEY'=>'Q',
'LBL_CLEAR_BUTTON_KEY'=>'C',
'LBL_SELECT_BUTTON_KEY'=>'T',
'LBL_SAVE_BUTTON_LABEL'=>'Spara',
'LBL_EDIT_BUTTON_LABEL'=>'Redigera',
'LBL_DUPLICATE_BUTTON_LABEL'=>'Duplicera',
'LBL_DELETE_BUTTON_LABEL'=>'Radera',
'LBL_NEW_BUTTON_LABEL'=>'Nytt',
'LBL_CHANGE_BUTTON_LABEL'=>'�ndra',
'LBL_CANCEL_BUTTON_LABEL'=>'Avbryt',
'LBL_SEARCH_BUTTON_LABEL'=>'S�k',
'LBL_CLEAR_BUTTON_LABEL'=>'Radera',
'LBL_SELECT_BUTTON_LABEL'=>'V�lj',

'LNK_ADVANCED_SEARCH'=>'Avancerad',
'LNK_BASIC_SEARCH'=>'Enkel',
'LNK_EDIT'=>'redigera',
'LNK_REMOVE'=>'ta bort',
'LNK_DELETE'=>'radera',
'LNK_LIST_START'=>'Start',
'LNK_LIST_NEXT'=>'N�sta',
'LNK_LIST_PREVIOUS'=>'F�reg�ende',
'LNK_LIST_END'=>'Slut',
'LBL_LIST_OF'=>'av',
'LNK_PRINT'=>'Skriv ut',
'LNK_HELP'=>'Hj�lp',

'NTC_REQUIRED'=>'Markerar obligatoriska f�lt',
'LBL_REQUIRED_SYMBOL'=>'*',
'LBL_CURRENCY_SYMBOL'=>'$',
'LBL_THOUSANDS_SYMBOL'=>'K',
'NTC_DATE_FORMAT'=>'(����-mm-dd)',
'NTC_TIME_FORMAT'=>'(24:00)',
'NTC_DATE_TIME_FORMAT'=>'(����-mm-dd 24:00)',
'NTC_DELETE_CONFIRMATION'=>'�r du s�ker p� att du vill radera denna post?',
'ERR_DELETE_RECORD'=>'Ett post nr kr�vs f�r att radera det aktuella kontakten.',
'ERR_CREATING_TABLE'=>'Fel vid skapande av tabellen: ',
'ERR_CREATING_FIELDS'=>'Fel vid ifyllnad av extra detaljerad information: ',
'ERR_MISSING_REQUIRED_FIELDS'=>'Obligatoriska f�lt saknas:',
'ERR_INVALID_EMAIL_ADDRESS'=>'�r inte en giltig epostadress.',
'ERR_INVALID_DATE_FORMAT'=>'Datumformatet m�ste vara : ����-mm-dd',
'ERR_INVALID_MONTH'=>'Ange en giltig m�nad.',
'ERR_INVALID_DAY'=>'Ange ett giltigt datum.',
'ERR_INVALID_YEAR'=>'Ange ett giltigt �rtal med 4 siffror.',
'ERR_INVALID_DATE'=>'Ange ett giltigt datum.',
'ERR_INVALID_HOUR'=>'Ange en giltig timme.',
'ERR_INVALID_TIME'=>'Ange ett giltigt klockslag.',
'NTC_CLICK_BACK'=>'Klicka p� bak�tknappen och korrigera uppgifterna.',
'LBL_LIST_ASSIGNED_USER'=>'Tilldelad till',
'LBL_ASSIGNED_TO'=>'Tilldelat till:',
'LBL_CURRENT_USER_FILTER'=>'Visa endast de uppgifter som �r tilldelade till mig:',

//New strings for 1.1c.  These still need to be translated.
'LBL_SELECT_CONTACT_BUTTON_TITLE'=>'Select Contact [Alt+T]',
'LBL_SELECT_CONTACT_BUTTON_KEY'=>'T',
'LBL_SELECT_CONTACT_BUTTON_LABEL'=>'Select Contact',
'LBL_SELECT_USER_BUTTON_TITLE'=>'Select User [Alt+U]',
'LBL_SELECT_USER_BUTTON_KEY'=>'U',
'LBL_SELECT_USER_BUTTON_LABEL'=>'Select User',
'LBL_USER_LIST'=>'User List',
'LBL_CONTACT_LIST'=>'Contact List',
'LBL_LIST_NAME'=>'Name',
'LBL_LIST_USER_NAME'=>'User Name',
'LBL_LIST_EMAIL'=>'Email',
'LBL_LIST_PHONE'=>'Phone',
'LBL_LIST_CONTACT_NAME'=>'Contact Name',
'LBL_LIST_ACCOUNT_NAME'=>'Account Name',
'NTC_LOGIN_MESSAGE'=>"Please login to the application.",
'LBL_NONE'=>'--None--',
'LBL_CHARSET'=>'ISO-8859-1',
);

//the left value is the key stored in the db and the right value is the display value
//to translate, only modify the right value in each key/value pair
$app_list_strings = Array(
//e.g. auf Deutsch 'Contacts'=>'Contakten',
'moduleList' => Array('Home'=>'Hem'
				, 'Dashboard'=>'Dashboard'
				, 'Contacts'=>'Kontakter'
				, 'Accounts'=>'F�retag'
				, 'Opportunities'=>'Aff�rer'
				, 'Cases'=>'�renden'
				, 'Notes'=>'Notes & Attachments'
				, 'Calls'=>'Samtal'
				, 'Emails'=>'Epost'
				, 'Meetings'=>'M�ten'
				, 'Tasks'=>'Uppgifter'),

//e.g. en fran�ais 'Analyst'=>'Analyste',
'account_type_dom' => Array(''=>''
		, 'Analyst'=>'Analytiker'
		, 'Integrator'=>'Integrat�r'
		, 'Investor'=>'Investerare'
		, 'Competitor'=>'Konkurrent'
		, 'Customer'=>'Kund'
		, 'Prospect'=>'Kund�mne'
		, 'Partner'=>'Partner'
		, 'Press'=>'Press'
		, 'Reseller'=>'�terf�rs�ljare'
		, 'Other'=>'�vrigt'
		),

//e.g. en espa�ol 'Apparel'=>'Ropa',
'industry_dom' => Array(''=>''
		, 'Banking'=>'Bank'
		, 'Apparel'=>'Bekl�dnadsindustri'
		, 'Biotechnology'=>'Bioteknologi'
		, 'Electronics'=>'Elektronik'
		, 'Energy'=>'Energi'
		, 'Finance'=>'Finans'
		, 'Shipping'=>'Frakt'
		, 'Insurance'=>'F�rs�kring'
		, 'Retail'=>'Handel'
		, 'Hospitality'=>'Hotell/Restaurang'
		, 'Healthcare'=>'H�lsov�rd'
		, 'Not For Profit'=>'Ideell verksamhet'
		, 'Engineering'=>'Ingenj�rskonst'
		, 'Chemicals'=>'Kemikalie'
		, 'Communications'=>'Kommunikation'
		, 'Consulting'=>'Konsulting'
		, 'Construction'=>'Konstruktion'
		, 'Food & Beverage'=>'Livsmedel'
		, 'Machinery'=>'Maskinteknik'
		, 'Media'=>'Media'
		, 'Environmental'=>'Milj�'
		, 'Government'=>'Offentlig f�rvaltning'
		, 'Entertainment'=>'Underh�llning'
		, 'Education'=>'Utbildning'
		, 'Manufacturing'=>'Tillverkande'
		, 'Technology'=>'Teknologi'
		, 'Telecommunications'=>'Telekommunikationer'
		, 'Transportation'=>'Transport'
		, 'Recreation'=>'Turism/resor'
		, 'Utilities'=>'Utilities'
		, 'Other'=>'�vrigt'
		),

'lead_source_dom' => Array(''=>''
		, 'Cold Call'=>'Ointresserad'
		, 'Existing Customer'=>'Befintlig kund'
		, 'Self Generated'=>'Personlig'
		, 'Employee'=>'Anst�lld'
		, 'Partner'=>'Partner'
		, 'Public Relations'=>'Public Relations'
		, 'Direct Mail'=>'Direct Mail'
		, 'Conference'=>'Konferens'
		, 'Trade Show'=>'M�ssa'
		, 'Web Site'=>'Web Site'
		, 'Word of mouth'=>'Muntligen'
		, 'Other'=>'�vrigt'
		),

'opportunity_type_dom' => Array(''=>''
		, 'Existing Business'=>'Befintlig aff�r'
		, 'New Business'=>'Ny aff�r'
		),

//Note:  do not translate opportunity_relationship_type_default_key
//       it is the key for the default opportunity_relationship_type_dom value
'opportunity_relationship_type_default_key' => 'Primary Decision Maker',
'opportunity_relationship_type_dom' => Array(''=>''
		, 'Primary Decision Maker'=>'Huvudsaklig beslutsfattare'
		, 'Business Decision Maker'=>'Aff�rsm�ssig beslutsfattare'
		, 'Business Evaluator'=>'Aff�rsm�ssig utv�rderare'
		, 'Technical Decision Maker'=>'Teknisk beslutsfattare'
		, 'Technical Evaluator'=>'Teknisk utv�rderare'
		, 'Executive Sponsor'=>'Ledningsfinansi�r'
		, 'Influencer'=>'Person med inflytande'
		, 'Other'=>'�vrigt'
		),

//Note:  do not translate case_relationship_type_default_key
//       it is the key for the default case_relationship_type_dom value
'case_relationship_type_default_key' => 'Primary Contact',
'case_relationship_type_dom' => Array(''=>''
		, 'Primary Contact'=>'Huvusaklig kontakt'
		, 'Alternate Contact'=>'Alternativ kontakt'
		),

'sales_stage_dom' => Array('Prospecting'=>'Prospektering'
		, 'Qualification'=>'Kvalifikation'
		, 'Needs Analysis'=>'Analys beh�vs'
		, 'Value Proposition'=>'F�rsl� v�rde'
		, 'Id. Decision Makers'=>'Identifiera beslutsfattare'
		, 'Perception Analysis'=>'Analysera genomslag'
		, 'Proposal/Price Quote'=>'Offert'
		, 'Negotiation/Review'=>'F�rhandling/uppdatering'
		, 'Closed Won'=>'Avslutad vunnen'
		, 'Closed Lost'=>'Avslutad f�rlorad'
		),

'salutation_dom' => Array(''=>''
		, 'Mr.'=>'Herr'
		, 'Ms.'=>'Fr�ken'
		, 'Mrs.'=>'Fru'
		, 'Dr.'=>'Dr.'
		, 'Prof.'=>'Prof.'
		),

'task_priority_dom' => Array('High'=>'H�g'
		, 'Medium'=>'Medium'
		, 'Low'=>'L�g'
		),

'task_status_dom' => Array('Not Started'=>'Ej p�b�rjad'
		, 'In Progress'=>'Aktiv'
		, 'Completed'=>'Avslutad'
		, 'Pending Input'=>'V�ntar p� uppgifter'
		, 'Deferred'=>'Uppskjuten'
		),

'meeting_status_dom' => Array('Planned'=>'Planerad'
		, 'Held'=>'Genomf�rd'
		, 'Not Held'=>'Ej genomf�rd'
		),

'call_status_dom' => Array('Planned'=>'Planerad'
		, 'Held'=>'Genomf�rd'
		, 'Not Held'=>'Ej genomf�rd'
		),

//Note:  do not translate case_status_default_key
//       it is the key for the default case_status_dom value
'case_status_default_key' => 'New',
'case_status_dom' => Array('New'=>'Nytt'
		, 'Assigned'=>'Tilldelat'
		, 'Closed'=>'Avslutat'
		, 'Pending Input'=>'V�ntar p� uppgifter'
		, 'Rejected'=>'Avslag'
		),

'user_status_dom' => Array('Active'=>'Aktiv'
		, 'Inactive'=>'Inaktiv'
		),

//Note:  do not translate record_type_default_key
//       it is the key for the default record_type_module value
'record_type_default_key' => 'Accounts',
'record_type_display' => array('Accounts' => '*Account',
		'Opportunities' => '*Opportunity',
		'Cases' => '*Case'),

);

?>