<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Users/language/se.lang.php,v 1.0 2004/08/06 marcom Exp $
 * Description:  Defines the Swedish language pack for the Users module.
 ********************************************************************************/

$mod_strings = Array(
'LBL_MODULE_NAME'=>'Anv�ndare',
'LBL_MODULE_TITLE'=>'Anv�ndare : Hem',
'LBL_SEARCH_FORM_TITLE'=>'S�k Anv�ndare',
'LBL_LIST_FORM_TITLE'=>'Anv�ndarlista',
'LBL_NEW_FORM_TITLE'=>'Ny Anv�ndare',
'LBL_USER'=>'Anv�ndare:',
'LBL_LOGIN'=>'Login',

'LBL_LIST_NAME'=>'Namn',
'LBL_LIST_LAST_NAME'=>'Efternamn',
'LBL_LIST_USER_NAME'=>'Anv�ndarnamn',
'LBL_LIST_DEPARTMENT'=>'Avdelning',
'LBL_LIST_EMAIL'=>'Epost',
'LBL_LIST_PRIMARY_PHONE'=>'Huvudtelefon',
'LBL_LIST_ADMIN'=>'Admin',

'LBL_NEW_USER_BUTTON_TITLE'=>'Ny Anv�ndare [Alt+N]',
'LBL_NEW_USER_BUTTON_LABEL'=>'Ny Anv�ndare',
'LBL_NEW_USER_BUTTON_KEY'=>'N',

'LBL_ERROR'=>'Fel:',
'LBL_PASSWORD'=>'L�senord:',
'LBL_USER_NAME'=>'Anv�ndarnamn:',
'LBL_FIRST_NAME'=>'F�rnamn:',
'LBL_LAST_NAME'=>'Efternamn:',
'LBL_YAHOO_ID'=>'Yahoo ID:',
'LBL_USER_SETTINGS'=>'Anv�ndarinst�llningar',
'LBL_THEME'=>'Tema:',
'LBL_LANGUAGE'=>'Spr�k:',
'LBL_ADMIN'=>'Admin:',
'LBL_USER_INFORMATION'=>'Anv�ndarinformation',
'LBL_OFFICE_PHONE'=>'F�retagstelefon:',
'LBL_REPORTS_TO'=>'Rapporterar till:',
'LBL_OTHER_PHONE'=>'�vrigt:',
'LBL_OTHER_EMAIL'=>'Annan Epost:',
'LBL_NOTES'=>'Anteckningar:',
'LBL_DEPARTMENT'=>'Avdelning:',
'LBL_STATUS'=>'Status:',
'LBL_TITLE'=>'Titel:',
'LBL_ANY_PHONE'=>'Telefon:',
'LBL_ANY_EMAIL'=>'Epost:',
'LBL_ADDRESS'=>'Adress:',
'LBL_CITY'=>'Ort:',
'LBL_STATE'=>'Stat:',
'LBL_POSTAL_CODE'=>'Postnummer:',
'LBL_COUNTRY'=>'Land:',
'LBL_NAME'=>'Namn:',
'LBL_USER_SETTINGS'=>'Anv�ndarinst�llningar',
'LBL_USER_INFORMATION'=>'Anv�ndarinformation',
'LBL_MOBILE_PHONE'=>'Mobiltelefon:',
'LBL_OTHER'=>'�vrigt:',
'LBL_FAX'=>'Fax:',
'LBL_EMAIL'=>'Epost:',
'LBL_HOME_PHONE'=>'Hemtelefon:',
'LBL_ADDRESS_INFORMATION'=>'Adress Information',
'LBL_PRIMARY_ADDRESS'=>'Huvudsaklig Adress:',

'LBL_CHANGE_PASSWORD_BUTTON_TITLE'=>'�ndra l�senord[Alt+P]',
'LBL_CHANGE_PASSWORD_BUTTON_KEY'=>'P',
'LBL_CHANGE_PASSWORD_BUTTON_LABEL'=>'�ndra l�senord',
'LBL_LOGIN_BUTTON_TITLE'=>'Login [Alt+L]',
'LBL_LOGIN_BUTTON_KEY'=>'L',
'LBL_LOGIN_BUTTON_LABEL'=>'Login',

'LBL_CHANGE_PASSWORD'=>'�ndra l�senord',
'LBL_OLD_PASSWORD'=>'Gammalt l�senord:',
'LBL_NEW_PASSWORD'=>'Nytt l�senord:',
'LBL_CONFIRM_PASSWORD'=>'Bekr�fta l�senord:',
'ERR_ENTER_OLD_PASSWORD'=>'Ange gammalt l�senord.',
'ERR_ENTER_NEW_PASSWORD'=>'Ange nytt l�senord.',
'ERR_ENTER_CONFIRMATION_PASSWORD'=>'Bekr�fta l�senord.',
'ERR_REENTER_PASSWORDS'=>'Ange l�senord p� nytt.  The \"new password\" and \"confirm password\" values do not match.',
'ERR_INVALID_PASSWORD'=>'Du m�ste ange ett giltigt anv�ndarnamn och l�senord.',
'ERR_PASSWORD_CHANGE_FAILED_1'=>'�ndring av l�senord misslyckades f�r ',
'ERR_PASSWORD_CHANGE_FAILED_2'=>' misslyckades. Det nya l�senorde m�ste anges.',
'ERR_PASSWORD_INCORRECT_OLD'=>'Felaktigt gammal l�senord f�r anv�ndaren $this->user_name. Ange l�senord p� nytt.',
'ERR_USER_NAME_EXISTS_1'=>'Anv�ndarnamnet ',
'ERR_USER_NAME_EXISTS_2'=>' finns redan. Duplikat av anv�ndarnamn �r inte till�tet.<br>Ange unikt anv�ndarnamn.',
'ERR_LAST_ADMIN_1'=>'Anv�ndarnamnet ',
'ERR_LAST_ADMIN_2'=>' �r den senaste Administrat�ren.  �tminstone en anv�ndare m�ste ha Administrat�rsbeh�righet.<br>Kontrollera Admin anv�ndarinst�llningarna.',

'LNK_NEW_CONTACT'=>'Ny Kontakt',
'LNK_NEW_ACCOUNT'=>'Nytt F�retag',
'LNK_NEW_OPPORTUNITY'=>'Ny Aff�r',
'LNK_NEW_CASE'=>'Nytt �rende',
'LNK_NEW_NOTE'=>'Ny Anteckning',
'LNK_NEW_CALL'=>'Nytt Samtal',
'LNK_NEW_EMAIL'=>'Ny Epost',
'LNK_NEW_MEETING'=>'Nytt M�te',
'LNK_NEW_TASK'=>'Ny Uppgift',
'ERR_DELETE_RECORD'=>"Ett Post Nummer m�ste anges f�r att radera F�retaget.",

'LBL_RESET_PREFERENCES'=>'*Reset To Default Preferences',
);

?>