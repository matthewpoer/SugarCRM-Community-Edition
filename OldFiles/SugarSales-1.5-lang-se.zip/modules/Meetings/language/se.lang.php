<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Meetings/language/se.lang.php,v 1.0 2004/08/06 marcom Exp $
 * Description:  Defines the Swedish language pack for the Meetings module.
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_MODULE_NAME'=>'M�ten',
'LBL_MODULE_TITLE'=>'M�ten : Hem',
'LBL_SEARCH_FORM_TITLE'=>'S�k M�te',
'LBL_LIST_FORM_TITLE'=>'M�teslista',
'LBL_NEW_FORM_TITLE'=>'Boka M�te',

'LBL_LIST_SUBJECT'=>'�mne',
'LBL_LIST_CONTACT'=>'Kontakt Namn',
'LBL_LIST_RELATED_TO'=>'Relaterad till',
'LBL_LIST_DATE'=>'Start Datum',
'LBL_LIST_TIME'=>'Start Tid',

'LBL_SUBJECT'=>'�mne:',
'LBL_STATUS'=>'Status:',
'LBL_LOCATION'=>'Plats:',
'LBL_DATE_TIME'=>'Start Datum & Tid:',
'LBL_DATE'=>'Start Datum:',
'LBL_TIME'=>'Start Tid:',
'LBL_DURATION'=>'Varaktighet:',
'LBL_HOURS_MINS'=>'(timmar/minuter)',
'LBL_SUBJECT'=>'�mne: ',
'LBL_CONTACT_NAME'=>'Kontakt Namn: ',
'LBL_MEETING'=>'M�te:',
'LBL_DESCRIPTION_INFORMATION'=>'Beskrivning',
'LBL_DESCRIPTION'=>'Beskrivning:',
'LBL_COLON'=>':',
'LBL_DEFAULT_STATUS'=>'Planerat',

'LNK_NEW_CONTACT'=>'Ny Kontakt',
'LNK_NEW_ACCOUNT'=>'Nytt F�retag',
'LNK_NEW_OPPORTUNITY'=>'Ny Aff�r',
'LNK_NEW_CASE'=>'Nytt �rende',
'LNK_NEW_NOTE'=>'Ny Anteckning',
'LNK_NEW_CALL'=>'Nytt Samtal',
'LNK_NEW_EMAIL'=>'Ny Epost',
'LNK_NEW_MEETING'=>'Nytt M�te',
'LNK_NEW_TASK'=>'Ny Uppgift',
'ERR_DELETE_RECORD'=>"Ett Post nummer m�ste anges f�r att radera m�tet.",

//New strings for 1.1c.  These still need to be translated.
'LBL_LIST_CLOSE'=>'Close',
'NTC_REMOVE_INVITEE'=>'Are you sure you want to remove this invitee from the meeting?',
'LBL_INVITEE'=>'Invitees',
);

?>