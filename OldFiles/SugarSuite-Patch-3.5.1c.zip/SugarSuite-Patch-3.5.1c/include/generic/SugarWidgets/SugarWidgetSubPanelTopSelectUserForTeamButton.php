<?php
/**
 * SugarWidgetSubPanelTopSelectButton
 *
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */

// $Id: SugarWidgetSubPanelTopSelectUserForTeamButton.php,v 1.1.2.1 2005/10/26 00:01:02 jli Exp $

require_once('include/generic/SugarWidgets/SugarWidgetSubPanelTopButton.php');

class SugarWidgetSubPanelTopSelectUserForTeamButton extends SugarWidgetSubPanelTopButton {
	function SugarWidgetSubPanelTopSelectUserForTeamButton() {
	}

	function display(&$widget_data) {
		global $app_strings;		

		$focus = $widget_data['focus'];

		$popup_request_data = array(
			'call_back_function' => 'set_return_and_save',
			'form_name' => 'DetailView',
			'field_to_name_array' => array(
				'id' => 'user_id',
			),
		);
		
		$encoded_popup_request_data = $this->_create_json_encoded_popup_request($popup_request_data);
		
		$button  = "<form action='index.php'>\n";
		$button .= "<input type='hidden' name='record' value=''>\n";
		$button .= "<input type='hidden' name='module' value='Teams'>\n";
		$button .= "<input type='hidden' name='action' value='AddUserToTeam'>\n";
		$button .= "<input type='hidden' name='team_id' value='{$focus->id}'>\n";
		$button .= "<input type='hidden' name='return_module' value='Teams'>\n";
		$button .= "<input type='hidden' name='return_action' value='DetailView'>\n";
		$button .= "<input type='hidden' name='return_id' value='{$focus->id}'>\n";
		$button .= "<input title='".$app_strings['LBL_SELECT_BUTTON_TITLE']
				."' accessKey='".$app_strings['LBL_SELECT_BUTTON_KEY']
				."' type='button' class='button' value='  ".$app_strings['LBL_SELECT_BUTTON_LABEL']
				."  ' name='button' onclick='open_popup(\"Users\", 600, 400, \"\", true, true, {$encoded_popup_request_data});'>\n";
		$button .= "</form>\n";
		
		return $button;
	}
}
?>
