Sugar Suite v3.5.1c
November 2, 2005

-=Overview=-
Our goal continues to be to build the customer relationship management system 
that you have always wanted, so your input is vital. Based on your input we have 
provided important bug fixes in 3.5.1c that continue to enhance the stability of 
Sugar Suite.

One item of particular note in 3.5.1c is a resolution to a problem with Sugar Suite�s 
handling of Daylight Savings Time (DST). It is important to upgrade to patch 3.5.1c 
in order for task, meeting and call records to properly display the due date.  See 
below for details.

To share ideas with the Sugar Community, ask questions, find answers and submit 
feedback, please visit our Sugar Forums at http://www.sugarcrm.com/forums.

Check out http://www.sugarcrm.com for more details on acquiring the Sugar Suite,
the latest product roadmap, support forums, detailed product information and 
much more.  We hope you find this a useful tool for building your business.

Enjoy! 
The Sugar Team  

--------------------------------------------------------------------------------
3.5.1c
--------------------------------------------------------------------------------
Note:	To install 3.5.1c, you must first have 3.5.1, 3.5.1a or 3.5.1b installed.  
Then use the Upgrade Wizard in the Admin console to apply the 3.5.1c patch.

Note:   Please read through the 3.5.1b release notes below as all notes apply to 
3.5.1c as well.

Fixed:   The user's time was not being properly calculated in timezones
         east of GMT that observe Daylight Savings. [2582]


--------------------------------------------------------------------------------
3.5.1b
--------------------------------------------------------------------------------
Note:	To install 3.5.1b, you must first have 3.5.1 or 3.5.1a installed.  Then 
use the Upgrade Wizard in the Admin console to apply the 3.5.1b patch.

Note:  In Sugar Suite 3.5.0, the storing of dates was changed to always store using
UTC or otherwise known as GMT date/time.  However, the algorithm for Daylight 
Savings Time did not accurately correct for tasks, calls or meeting due dates that 
were scheduled to be due accross a daylight savings time boundry.  We have changed 
the algorithm to correctly take the user's Daylight Savings preference and timezone 
into account.  

This issue only applies to Sugar Suite 3.5.0 and 3.5.1.

Install this patch on your system.  Once it is installed, you will need to go 
to the Admin console and click on Repair to apply the Daylight Savings Time fix.  
On this screen you will:
1) Optionally set the timezone for all users.  If the admin does not set the timezone, 
   for all users, each user will select his timezone the next time he logs in.
2) Update all task, call and meeting due dates to accurately reflect 
   Daylight Savings Time.  While this step is optional, it is highly recommended that 
   you do this step.  
3) Implement the new Daylight Savings algorithm.








Fixed:	Sugar Suite does not correctly handle Daylight Savings Time. [2463]

Fixed: 	Cannot alter Required or Audit fields in Edit Custom Fields. [2462]

Fixed:	Sugar Plug-in for Outlook fails to perform a Calendar Sync in certain conditions 
	involving a change of servers. [2494]

Fixed:	Clicking Accept/Decline/Tentative on Activity types causes an error to appear. [2406]

Fixed:	Accepting a Call or Meeting email invitation causes an error. [2452]

Fixed:	My Pipeline on Home module does not account for non-standard date formats. [2440]

Fixed:	Dashboard Pipeline by Month shows YYYY-MM instead of actual months. [2441]






















--------------------------------------------------------------------------------
3.5.1a
--------------------------------------------------------------------------------
Note:   To install 3.5.1a, you must first have 3.5.1 installed.  Then use the 
        Upgrade Wizard in the Admin section to apply the 3.5.1a patch.

Note:   Admin users need to log out after "Clear Chart Data Cache" and "Rebuild 
        .htaccess file" scripts are run through Repair section, in order for the 
        Warning messages to disappear.

Fixed:  Status and Type fields were not being parsed through app_list_strings 
        for ListViews. [2289, 2291]

Fixed:  Parent type, parent_id, parent_name, account_name and account_id were 
        not properly populated in subpanels. [2290]

Fixed:  Selecting a second template in an HTML email was not handled properly. 
        [2292]

Fixed:  Related records were not always being fetched from the database 
        correctly. [2299]

Fixed:  Creating a new Contact from an Account DetailView did not auto-populate 
        the Account's address and phone data. [2300]

Fixed:  Translated strings were not available for non-US English Dashboard edit 
        function. [2302]

Fixed:  Reports To field is not immediately displayed for Employees after 
        selecting. [2304]

Fixed:  Email notifications for Calls used GMT time instead of user's time zone 
        preference. [2311]

Fixed:  Line lengths of more than 998 characters in Emails produced unwanted ! 
        characters. [2315]

Fixed:  Updating License Management blanked out other system-wide config table 
        settings. [2320]

Fixed:  Custom fields of type dropdown now check for existence of a key before 
        trying to extract its value.  Result was "Undefined index" notices for 
        SugarBean.php [2321]

Fixed:  Standard dropdown fields displayed keys instead of values in ListViews. 
        [2322]

Fixed:  The Assigned To field was missing from the Project Tasks subpanel. 
        [2323]

Fixed:  Filtering shared calendars resulted in a "Bad data passed in; Return to
        Home" error. [2336]

Fixed:  Scheduling Meetings and Calls did not display free/busy information at 
        the correct times due to GMT offset. [2340]

Fixed:  Default character set header was always sent to browser, regardless of 
        language pack.  Affected Czech, Japanese, Russian, and Traditional 
        Chinese language packs. [2341]

Fixed:  Demo data now uses @example.com instead of @company.com. [2350]

New:    Added a "Send Queued Campaign Emails" button to the Mass Email Manager, 
        allowing admin users to invoke emailmandelivery.php through Sugar, if 
        crontabs are not available. [2354]

Fixed:  Saved emails displayed the wrong date. [2355]

Fixed:  Subpanels did not display Contact full names if either the first or last 
        name was empty. [2356]

Fixed:  Sugar Plug-in for Outlook uses Sugar server time to check for conflicts 
        instead of local Outlook user's time. [2357]

Fixed:  Edited changes in an email were not included when archiving an email 
        through the Sugar Plug-in for Outlook. [2363, 2365]

Fixed:  "Error calling json server" when searching for a Contact while 
        scheduling a Call. [2366]

Fixed:  Contacts ListViews did not include Assigned To as a Mass Update option. 
        [2370]

Fixed:  Change Log popup was not picking up CSS style properly. [2375]

Fixed:  Quotation marks in a Notes DetailView appeared as ' or ". [2376]

Fixed:  Associating emails to Contacts caused Undefined Index errors in the 
        History subpanel. [2379]

Fixed:  Users with non-default date format preferences could not use Dashboard 
        graphs. [2383]











