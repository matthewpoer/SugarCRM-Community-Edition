<?php
// $Id: sugar_version.php,v 1.44.2.3 2005/11/01 23:47:02 andrew Exp $
$sugar_version      = '3.5.1c';
$sugar_db_version   = '3.5.1';
$sugar_flavor       = 'OS';
?>
