<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/include/language/en_us.lang.php,v 1.89 2004/10/25 02:32:20 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Brugere',
  'LBL_MODULE_TITLE' => 'Brugere : Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'S�g Bruger',
  'LBL_LIST_FORM_TITLE' => 'Brugerliste',
  'LBL_NEW_FORM_TITLE' => 'Ny Bruger',
  'LBL_USER' => 'Bruger:',
  'LBL_LOGIN' => 'Login',
  'LBL_RESET_PREFERENCES' => 'Reset til standard instillinger',
  'LBL_TIME_FORMAT' => 'Time Format:',
  'LBL_CURRENCY' => 'Currency:',
  'LBL_LIST_NAME' => 'Navn',
  'LBL_LIST_LAST_NAME' => 'Efternavn',
  'LBL_LIST_USER_NAME' => 'Brugernavn',
  'LBL_LIST_DEPARTMENT' => 'Afdeling',
  'LBL_LIST_EMAIL' => 'Email',
  'LBL_LIST_PRIMARY_PHONE' => 'Prim�r Telefon',
  'LBL_LIST_ADMIN' => 'Admin',
  'LBL_NEW_USER_BUTTON_TITLE' => 'Ny Bruger [Alt+N]',
  'LBL_NEW_USER_BUTTON_LABEL' => 'Ny Bruger',
  'LBL_NEW_USER_BUTTON_KEY' => 'N',
  'LBL_ERROR' => 'Fejl:',
  'LBL_PASSWORD' => 'Password:',
  'LBL_USER_NAME' => 'Brugernavn:',
  'LBL_FIRST_NAME' => 'Fornavn:',
  'LBL_LAST_NAME' => 'Efternavn:',
  'LBL_USER_SETTINGS' => 'Brugerindstillinger',
  'LBL_THEME' => 'Tema:',
  'LBL_LANGUAGE' => 'Sprog:',
  'LBL_ADMIN' => 'Admin:',
  'LBL_USER_INFORMATION' => 'Brugerinformation',
  'LBL_OFFICE_PHONE' => 'Firmatelefon:',
  'LBL_REPORTS_TO' => 'Rapporterer til:',
  'LBL_OTHER_PHONE' => 'Anden Tlf.:',
  'LBL_OTHER_EMAIL' => 'Anden Email:',
  'LBL_NOTES' => 'Bem�rkninger:',
  'LBL_DEPARTMENT' => 'Afdeling:',
  'LBL_STATUS' => 'Status:',
  'LBL_TITLE' => 'Titel:',
  'LBL_ANY_PHONE' => 'Telefon:',
  'LBL_ANY_EMAIL' => 'Email:',
  'LBL_ADDRESS' => 'Adresse:',
  'LBL_CITY' => 'By:',
  'LBL_STATE' => 'Stat:',
  'LBL_POSTAL_CODE' => 'Postnr:',
  'LBL_COUNTRY' => 'Land:',
  'LBL_NAME' => 'Navn:',
  'LBL_MOBILE_PHONE' => 'Mobiltelefon:',
  'LBL_OTHER' => 'Andet:',
  'LBL_FAX' => 'Fax:',
  'LBL_EMAIL' => 'Email:',
  'LBL_HOME_PHONE' => 'Hjemmetelefon:',
  'LBL_ADDRESS_INFORMATION' => 'Adresse Information',
  'LBL_PRIMARY_ADDRESS' => 'Prim�r Adresse:',
  'LBL_CHANGE_PASSWORD_BUTTON_TITLE' => '�ndre password[Alt+P]',
  'LBL_CHANGE_PASSWORD_BUTTON_KEY' => 'P',
  'LBL_CHANGE_PASSWORD_BUTTON_LABEL' => '�ndre password',
  'LBL_LOGIN_BUTTON_TITLE' => 'Login [Alt+L]',
  'LBL_LOGIN_BUTTON_KEY' => 'L',
  'LBL_LOGIN_BUTTON_LABEL' => 'Login',
  'LBL_CHANGE_PASSWORD' => '�ndre password',
  'LBL_OLD_PASSWORD' => 'Gammelt password:',
  'LBL_NEW_PASSWORD' => 'Nyt password:',
  'LBL_CONFIRM_PASSWORD' => 'Bekr�ft password:',
  'ERR_ENTER_OLD_PASSWORD' => 'Angiv gammelt password.',
  'ERR_ENTER_NEW_PASSWORD' => 'Angiv nyt password.',
  'ERR_ENTER_CONFIRMATION_PASSWORD' => 'Bekr�ft password.',
  'ERR_REENTER_PASSWORDS' => 'Angiv password igen.  The \\"new password\\" and \\"confirm password\\" values do not match.',
  'ERR_INVALID_PASSWORD' => 'Du skal indtaste et gyldigt brugernavn og password.',
  'ERR_PASSWORD_CHANGE_FAILED_1' => '�ndring af password mislykkedes for ',
  'ERR_PASSWORD_CHANGE_FAILED_2' => ' mislykkedes. Det nye password skal angives.',
  'ERR_PASSWORD_INCORRECT_OLD' => 'Forkert gammelt password for bruger $this->user_name. Indtast password igen.',
  'ERR_USER_NAME_EXISTS_1' => 'Brugernavnet ',
  'ERR_USER_NAME_EXISTS_2' => ' finde allerede. Ens brugernavne er ikke tilladt.<br>Indtast unikt brugernavn.',
  'ERR_LAST_ADMIN_1' => 'Brugernavnet ',
  'ERR_LAST_ADMIN_2' => ' er den eneste Administrator.  Mindst en bruger skal have Administratorrettigheder.<br>Kontroller Admin brugerindstillingerne.',
  'LNK_NEW_USER' => 'New User',
  'LNK_USER_LIST' => 'Users',
  'ERR_DELETE_RECORD' => 'Et Postnummer skal angives for at slette Firmaet.',
  'LBL_RECEIVE_NOTIFICATIONS' => 'Assignment Notification:',
  'LBL_RECEIVE_NOTIFICATIONS_TEXT' => 'Receive an e-mail notification when a record is assigned to you.',
  'LBL_ADMIN_TEXT' => 'Grants administrator privileges to this user',
  'LBL_TIME_FORMAT_TEXT' => 'Set the display format for time stamps',
  'LBL_GRIDLINE' => 'Show Gridlines:',
  'LBL_GRIDLINE_TEXT' => 'Controls gridlines on detail views',
  'LBL_CURRENCY_TEXT' => 'Select the default currency',
  'LBL_YAHOO_ID' => 'Yahoo ID:',
  'LNK_NEW_CONTACT' => 'Ny Kontakt',
  'LNK_NEW_ACCOUNT' => 'Nyt Firma',
  'LNK_NEW_OPPORTUNITY' => 'Ny Mulig Forretning',
  'LNK_NEW_CASE' => 'Ny Sag',
  'LNK_NEW_NOTE' => 'Ny Bem�rkning',
  'LNK_NEW_CALL' => 'Ny Samtale',
  'LNK_NEW_EMAIL' => 'Ny Email',
  'LNK_NEW_MEETING' => 'Nyt M�de',
  'LNK_NEW_TASK' => 'Ny Opgave',
);


?>