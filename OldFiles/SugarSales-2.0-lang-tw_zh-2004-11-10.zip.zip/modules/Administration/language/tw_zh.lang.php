<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/modules/Accounts/Account.php,v 1.92 2004/11/10 22:27:36 clint Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => '系統管理',
  'LBL_MODULE_TITLE' => '系統管理: 首頁',
  'LBL_NEW_FORM_TITLE' => 'Create Account',
  'LNK_NEW_USER' => 'Create User',
  'ERR_DELETE_RECORD' => '必須指定記錄編號才能刪除公司.',
  'LBL_CONFIGURE_SETTINGS_TITLE' => 'Configure Settings',
  'LBL_CONFIGURE_SETTINGS' => 'Configure system-wide settings',
  'LBL_UPGRADE_TITLE' => 'Upgrade',
  'LBL_UPGRADE' => 'Upgrade Sugar Sales',
  'LBL_MANAGE_USERS_TITLE' => 'User Management',
  'LBL_MANAGE_USERS' => 'Manage user accounts and passwords',
  'LBL_ADMINISTRATION_HOME_TITLE' => 'System Administration',
  'LBL_NOTIFY_TITLE' => 'E-mail Notification Options',
  'LBL_NOTIFY_FROMADDRESS' => '"From" Address:',
  'LBL_MAIL_SMTPSERVER' => 'SMTP Server:',
  'LBL_MAIL_SMTPPORT' => 'SMTP Port:',
  'LBL_MAIL_SENDTYPE' => 'Mail Transfer Agent:',
  'LBL_MAIL_SMTPUSER' => 'SMTP Username:',
  'LBL_MAIL_SMTPPASS' => 'SMTP Password:',
  'LBL_MAIL_SMTPAUTH_REQ' => 'Use SMTP Authentication?',
  'LBL_NOTIFY_SEND_BY_DEFAULT' => 'Send notifications by default?',
  'LBL_NOTIFY_SUBJECT' => 'E-mail subject:',
  'LBL_NOTIFY_ON' => 'Notifications on?',
  'LBL_NOTIFY_FROMNAME' => '"From" Name:',
  'LBL_CURRENCY' => 'Setup Currencies and Currency Rates',
  'LBL_MANAGE_CURRENCIES' => 'Currencies',
  'LBL_MANAGE_OPPORTUNITIES' => 'Opportunities',
  'LBL_UPGRADE_CURRENCY' => 'Upgrade currency amounts in ',
  'LNK_NEW_CONTACT' => '新增聯絡人',
  'LNK_NEW_ACCOUNT' => '新增公司',
  'LNK_NEW_OPPORTUNITY' => '新增機會',
  'LNK_NEW_CASE' => '新增事件',
  'LNK_NEW_NOTE' => '新增備註',
  'LNK_NEW_CALL' => '新增電話記錄',
  'LNK_NEW_EMAIL' => '新增電子郵件',
  'LNK_NEW_MEETING' => '新增會議',
  'LNK_NEW_TASK' => '新增任務',
);


?>