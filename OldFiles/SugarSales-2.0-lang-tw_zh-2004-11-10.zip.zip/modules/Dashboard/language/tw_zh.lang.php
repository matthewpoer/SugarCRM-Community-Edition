<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/modules/Accounts/Account.php,v 1.92 2004/11/10 22:27:36 clint Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Dashboard',
  'LBL_MODULE_TITLE' => 'Dashboard: Home',
  'LBL_SALES_STAGE_FORM_TITLE' => '銷售階段分布',
  'LBL_SALES_STAGE_FORM_DESC' => '*Shows cumulative opportunity amounts by selected sales stages for selected users where the expected closed date is within the specificed date range.',
  'LBL_MONTH_BY_OUTCOME' => '*Pipeline By Month By Outcome',
  'LBL_MONTH_BY_OUTCOME_DESC' => '*Shows cumulative opportunity amounts by month by outcome for selected users where the expected closed date is within the specificed date range.  Outcome is based on whether the sales stage is Closed Won, Closed Lost or any other value.',
  'LBL_LEAD_SOURCE_FORM_TITLE' => '客戶來源分布',
  'LBL_LEAD_SOURCE_FORM_DESC' => '*Shows cumulative opportunity amounts by selected lead source for selected users.',
  'LBL_LEAD_SOURCE_BY_OUTCOME' => '*All Opportunities By Lead Source By Outcome',
  'LBL_LEAD_SOURCE_BY_OUTCOME_DESC' => '*Shows cumulative opportunity amounts by selected lead source by outcome for selected users where the expected closed date is within the specificed date range.  Outcome is based on whether the sales stage is Closed Won, Closed Lost or any other value.',
  'LBL_PIPELINE_FORM_TITLE_DESC' => '*Shows cumulative amounts by selected sales stages for your opportunities where the expected closed date is within the specificed date range.',
  'LBL_DATE_RANGE' => '*Date range is',
  'LBL_DATE_RANGE_TO' => '*to',
  'ERR_NO_OPPS' => '請新增機會，然後才能看見機會圖.',
  'LBL_TOTAL_PIPELINE' => '總處理數 ',
  'LBL_ALL_OPPORTUNITIES' => '*Total amount of all opportunities is ',
  'LBL_OPP_SIZE' => '以千為基本單位的機會數值 ',
  'LBL_OPP_THOUSANDS' => 'K',
  'NTC_NO_LEGENDS' => '空',
  'LBL_LEAD_SOURCE_OTHER' => '*Other',
  'LBL_EDIT' => '*Edit',
  'LBL_REFRESH' => '*Refresh',
  'LBL_CREATED_ON' => '*Last run on ',
  'LBL_OPPS_IN_STAGE' => '*opportunities where sales stage is',
  'LBL_OPPS_IN_LEAD_SOURCE' => '*opportunities where lead source is',
  'LBL_OPPS_OUTCOME' => '*opportunities where outcome is',
  'LBL_USERS' => '*Users',
  'LBL_SALES_STAGES' => '*Sales Stages',
  'LBL_LEAD_SOURCES' => '*Lead Sources',
  'LBL_DATE_START' => '*Begin Date',
  'LBL_DATE_END' => '*End Date',
  'LNK_NEW_CONTACT' => '新增聯絡人',
  'LNK_NEW_ACCOUNT' => '新增公司',
  'LNK_NEW_OPPORTUNITY' => '新增機會',
  'LNK_NEW_QUOTE' => 'Create Quote',
  'LNK_NEW_LEAD' => 'Create Lead',
  'LNK_NEW_CASE' => '新增事件',
  'LNK_NEW_NOTE' => '新增備註',
  'LNK_NEW_CALL' => '新增電話記錄',
  'LNK_NEW_MEETING' => '新增會議',
  'LNK_NEW_TASK' => '新增任務',
  'LNK_NEW_EMAIL' => '新增電子郵件',
);


?>