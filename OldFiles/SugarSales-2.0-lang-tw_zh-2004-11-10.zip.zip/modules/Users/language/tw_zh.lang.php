<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/modules/Accounts/Account.php,v 1.92 2004/11/10 22:27:36 clint Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => '帳號',
  'LBL_MODULE_TITLE' => '帳號: 首頁',
  'LBL_SEARCH_FORM_TITLE' => '搜尋帳號',
  'LBL_LIST_FORM_TITLE' => '帳號列表',
  'LBL_NEW_FORM_TITLE' => '新增帳號',
  'LBL_USER' => '帳號：',
  'LBL_LOGIN' => '登錄',
  'LBL_RESET_PREFERENCES' => '*Reset To Default Preferences',
  'LBL_TIME_FORMAT' => 'Time Format:',
  'LBL_CURRENCY' => 'Currency:',
  'LBL_LIST_NAME' => '姓名',
  'LBL_LIST_LAST_NAME' => '名',
  'LBL_LIST_USER_NAME' => '帳號姓名',
  'LBL_LIST_DEPARTMENT' => '部門',
  'LBL_LIST_EMAIL' => '電子郵件',
  'LBL_LIST_PRIMARY_PHONE' => '主電話',
  'LBL_LIST_ADMIN' => '系統管理',
  'LBL_NEW_USER_BUTTON_TITLE' => '新增帳號 [Alt+N]',
  'LBL_NEW_USER_BUTTON_LABEL' => '新增帳號',
  'LBL_NEW_USER_BUTTON_KEY' => 'N',
  'LBL_ERROR' => '錯誤：',
  'LBL_PASSWORD' => '密碼：',
  'LBL_USER_NAME' => '帳號名稱：',
  'LBL_FIRST_NAME' => '姓：',
  'LBL_LAST_NAME' => '名：',
  'LBL_USER_SETTINGS' => '帳號設置',
  'LBL_THEME' => '風格：',
  'LBL_LANGUAGE' => '語言：',
  'LBL_ADMIN' => '系統管理：',
  'LBL_USER_INFORMATION' => '帳號資訊',
  'LBL_OFFICE_PHONE' => '辦公電話：',
  'LBL_REPORTS_TO' => '報告給：',
  'LBL_OTHER_PHONE' => '其它：',
  'LBL_OTHER_EMAIL' => '其它電子郵件：',
  'LBL_NOTES' => '備註：',
  'LBL_DEPARTMENT' => '部門：',
  'LBL_STATUS' => '狀態：',
  'LBL_TITLE' => '職務：',
  'LBL_ANY_PHONE' => '任意電話：',
  'LBL_ANY_EMAIL' => '任意電子郵件：',
  'LBL_ADDRESS' => '地址：',
  'LBL_CITY' => '城市：',
  'LBL_STATE' => '省份：',
  'LBL_POSTAL_CODE' => '郵遞區號：',
  'LBL_COUNTRY' => '國家：',
  'LBL_NAME' => '姓名：',
  'LBL_MOBILE_PHONE' => '移動電話：',
  'LBL_OTHER' => '其它：',
  'LBL_FAX' => '傳真：',
  'LBL_EMAIL' => '電子郵件：',
  'LBL_HOME_PHONE' => '家庭電話：',
  'LBL_ADDRESS_INFORMATION' => '地址資訊',
  'LBL_PRIMARY_ADDRESS' => '主地址：',
  'LBL_CHANGE_PASSWORD_BUTTON_TITLE' => '修改密碼 [Alt+P]',
  'LBL_CHANGE_PASSWORD_BUTTON_KEY' => 'P',
  'LBL_CHANGE_PASSWORD_BUTTON_LABEL' => '修改密碼',
  'LBL_LOGIN_BUTTON_TITLE' => '登錄 [Alt+L]',
  'LBL_LOGIN_BUTTON_KEY' => 'L',
  'LBL_LOGIN_BUTTON_LABEL' => '登錄',
  'LBL_CHANGE_PASSWORD' => '修改密碼',
  'LBL_OLD_PASSWORD' => '舊密碼：',
  'LBL_NEW_PASSWORD' => '新密碼：',
  'LBL_CONFIRM_PASSWORD' => '確認密碼：',
  'ERR_ENTER_OLD_PASSWORD' => '請輸入舊密碼.',
  'ERR_ENTER_NEW_PASSWORD' => '請輸入新密碼.',
  'ERR_ENTER_CONFIRMATION_PASSWORD' => '請再次輸入密碼驗證.',
  'ERR_REENTER_PASSWORDS' => '請重新輸入密碼.  \\"新密碼\\" 與 \\"驗證密碼\\" 值不相同.',
  'ERR_INVALID_PASSWORD' => '你必須使用合法的帳號名和密碼.',
  'ERR_PASSWORD_CHANGE_FAILED_1' => '帳號密碼更改失敗，因為',
  'ERR_PASSWORD_CHANGE_FAILED_2' => ' 失敗.  必須設定新密碼.',
  'ERR_PASSWORD_INCORRECT_OLD' => '帳號 $this->user_name 的舊密碼不對. 重新輸入密碼資訊.',
  'ERR_USER_NAME_EXISTS_1' => '帳號名',
  'ERR_USER_NAME_EXISTS_2' => ' 已經存在. 帳號名不能重復.<br>改變為唯一的帳號名.',
  'ERR_LAST_ADMIN_1' => '帳號名 ',
  'ERR_LAST_ADMIN_2' => ' 是最新的系統管理帳號.  至少要有一個系統管理帳號.<br>檢查系統管理帳號設置.',
  'LNK_NEW_USER' => 'New User',
  'LNK_USER_LIST' => 'Users',
  'ERR_DELETE_RECORD' => '必須指定記錄編號才能刪除公司.',
  'LBL_RECEIVE_NOTIFICATIONS' => 'Assignment Notification:',
  'LBL_RECEIVE_NOTIFICATIONS_TEXT' => 'Receive an e-mail notification when a record is assigned to you.',
  'LBL_ADMIN_TEXT' => 'Grants administrator privileges to this user',
  'LBL_TIME_FORMAT_TEXT' => 'Set the display format for time stamps',
  'LBL_GRIDLINE' => 'Show Gridlines:',
  'LBL_GRIDLINE_TEXT' => 'Controls gridlines on detail views',
  'LBL_CURRENCY_TEXT' => 'Select the default currency',
  'LBL_YAHOO_ID' => 'Yahoo ID：',
  'LNK_NEW_CONTACT' => '新增聯絡人',
  'LNK_NEW_ACCOUNT' => '新增公司',
  'LNK_NEW_OPPORTUNITY' => '新增機會',
  'LNK_NEW_CASE' => '新增事件',
  'LNK_NEW_NOTE' => '新增備註',
  'LNK_NEW_CALL' => '新增電話記錄',
  'LNK_NEW_EMAIL' => '新增電子郵件',
  'LNK_NEW_MEETING' => '新增會議',
  'LNK_NEW_TASK' => '新增任務',
);


?>