<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/modules/Accounts/Account.php,v 1.92 2004/11/10 22:27:36 clint Exp $
 * Description:
 ********************************************************************************/

$app_list_strings = array (
  'moduleList' => 
  array (
//to translate, only modify the right value in each key/value pair
    'Home' => '首頁',
//e.g. auf Deutsch 'Contacts'=>'Contakten',
    'Dashboard' => '概要',
    'Contacts' => '聯絡人',
    'Accounts' => '公司',
    'Opportunities' => '機會',
    'Cases' => '事件',
    'Notes' => 'Notes & Attachments',
    'Calls' => '電話',
    'Emails' => '電子郵件',
    'Meetings' => '會議',
    'Tasks' => '任務',
    'Calendar' => 'Calendar',
    'Leads' => 'Leads',
    'Activities' => 'Activities',
  ),
  'account_type_dom' => 
  array (
    '' => '',
    'Analyst' => '分析者',
    'Competitor' => '競爭者',
    'Customer' => '顧客',
    'Integrator' => '整合者',
    'Investor' => '投資者',
  //e.g. en fran�ais 'Analyst'=>'Analyste',
    'Partner' => '合作伙伴',
    'Press' => '出版商',
    'Prospect' => '勘探者',
    'Reseller' => '批發商',
    'Other' => '其它',
  ),
  'industry_dom' => 
  array (
    '' => '',
    'Apparel' => '服裝',
    'Banking' => '銀行',
    'Biotechnology' => '生物技術',
    'Chemicals' => '化學化工',
    'Communications' => '通訊',
  //e.g. en espa�ol 'Apparel'=>'Ropa',
    'Construction' => '建築',
    'Consulting' => '咨詢',
    'Education' => '教育',
    'Electronics' => '電子',
    'Energy' => '能源',
    'Engineering' => '工程設計',
    'Entertainment' => '文化',
    'Environmental' => '環境保護',
    'Finance' => '金融',
    'Food & Beverage' => '飲料食品',
    'Government' => '政府機構',
    'Healthcare' => '衛生保健',
    'Hospitality' => '醫療機構',
    'Insurance' => '保險',
    'Machinery' => '機械',
    'Manufacturing' => '生產企業',
    'Media' => '醫藥',
    'Not For Profit' => '非贏利機構',
    'Recreation' => '娛樂',
    'Retail' => '零售',
    'Shipping' => '海運',
    'Technology' => '技術',
    'Telecommunications' => '電信',
    'Transportation' => '運輸',
    'Utilities' => '公用事業',
    'Other' => '其它',
  ),
  'lead_source_dom' => 
  array (
    '' => '',
    'Cold Call' => '意外來訪',
    'Existing Customer' => '現有客戶',
    'Self Generated' => '自己生成',
    'Employee' => '員工',
    'Partner' => '合作者',
    'Public Relations' => '公共關系',
    'Direct Mail' => '直郵',
    'Conference' => '會議',
    'Trade Show' => '展覽',
    'Web Site' => '網站',
    'Word of mouth' => '他人介紹',
    'Other' => '其它',
  ),
  'opportunity_type_dom' => 
  array (
    '' => '',
    'Existing Business' => '已有生意',
    'New Business' => '新生意',
  ),
  'opportunity_relationship_type_default_key' => '主要決策者',
  'opportunity_relationship_type_dom' => 
  array (
    '' => '',
    'Primary Decision Maker' => '主要決策人',
    'Business Decision Maker' => '財務決策人',
    'Business Evaluator' => '財務評估人',
    'Technical Decision Maker' => '技術決策人',
//       it is the key for the default opportunity_relationship_type_dom value
    'Technical Evaluator' => '技術評估人',
    'Executive Sponsor' => '主管助理',
    'Influencer' => '影響者',
    'Other' => '其它',
  ),
  'case_relationship_type_default_key' => '主要聯絡人',
  'case_relationship_type_dom' => 
  array (
    '' => '',
    'Primary Contact' => '主要聯絡人',
    'Alternate Contact' => '輔助聯絡人',
  ),
  'sales_stage_dom' => 
//       it is the key for the default case_relationship_type_dom value
  array (
    'Prospecting' => '探察',
    'Qualification' => '資格合格',
    'Needs Analysis' => '需要分析',
    'Value Proposition' => '價值陳述',
    'Id. Decision Makers' => '辯識決策者',
    'Perception Analysis' => '感覺分析',
    'Proposal/Price Quote' => '建議/出價',
    'Negotiation/Review' => '談判/回顧',
    'Closed Won' => '談成結束',
    'Closed Lost' => '未成結束',
  ),
  'activity_dom' => 
  array (
    'Call' => 'Call',
    'Meeting' => 'Meeting',
    'Task' => 'Task',
    'Email' => 'Email',
    'Note' => 'Note',
  ),
  'salutation_dom' => 
  array (
    '' => '',
    'Mr.' => '先生.',
    'Ms.' => '小姐.',
    'Mrs.' => '女士.',
    'Dr.' => '博士.',
    'Prof.' => '教授.',
  ),
  'task_priority_dom' => 
  array (
    'High' => '高',
    'Medium' => '中',
    'Low' => '低',
  ),
  'task_status_dom' => 
  array (
    'Not Started' => '尚未開始',
    'In Progress' => '處理之中',
    'Completed' => '完成',
    'Pending Input' => '等待輸入',
    'Deferred' => '延期',
  ),
  'meeting_status_dom' => 
  array (
    'Planned' => '已約定',
    'Held' => '掛起',
    'Not Held' => '未掛起',
  ),
  'call_status_dom' => 
  array (
    'Planned' => '已約定',
    'Held' => '掛起',
    'Not Held' => '未掛起',
  ),
  'call_direction_dom' => 
  array (
    'Inbound' => 'Inbound',
    'Outbound' => 'Outbound',
  ),
  'lead_status_dom' => 
  array (
    '' => '',
    'New' => 'New',
    'Assigned' => 'Assigned',
    'In Process' => 'In Process',
    'Converted' => 'Converted',
    'Recycled' => 'Recycled',
    'Dead' => 'Dead',
  ),
  'lead_status_noblank_dom' => 
  array (
    'New' => 'New',
    'Assigned' => 'Assigned',
    'In Process' => 'In Process',
    'Converted' => 'Converted',
    'Recycled' => 'Recycled',
    'Dead' => 'Dead',
  ),
  'case_status_default_key' => 'New',
  'case_status_dom' => 
  array (
    'New' => '新增',
    'Assigned' => '已分配',
    'Closed' => '結束',
    'Pending Input' => '等待輸入',
    'Rejected' => '拒絕',
//       it is the key for the default case_status_dom value
  ),
  'case_priority_default_key' => 'P2',
  'case_priority_dom' => 
  array (
    'P1' => 'High',
    'P2' => 'Medium',
    'P3' => 'Low',
  ),
  'user_status_dom' => 
  array (
    'Active' => '有效',
    'Inactive' => '無效',
  ),
  'record_type_default_key' => 'Accounts',
  'record_type_display' => 
  array (
    'Accounts' => '*Account',
    'Opportunities' => '*Opportunity',
    'Cases' => '*Case',
    'Leads' => 'Lead',
  ),
//       it is the key for the default record_type_module value
  'notifymail_sendtype' => 
  array (
    'sendmail' => 'sendmail',
    'SMTP' => 'SMTP',
  ),
);

$app_strings = array (
  'LBL_CHARSET' => 'UTF-8',
  'LBL_BROWSER_TITLE' => 'SugarCRM - 商業開放原始碼CRM',
  'LBL_MY_ACCOUNT' => '我的帳戶',
  'LBL_ADMIN' => '系統管理',
  'LBL_LOGOUT' => '退出',
  'LBL_SEARCH' => '搜尋',
  'LBL_LAST_VIEWED' => '最新查看',
  'NTC_WELCOME' => '歡迎',
  'NTC_SUPPORT_SUGARCRM' => '透過 PayPal 捐贈支持 SugarCRM 開源項目 - 一個快速，免費和安全的 CRM 項目!',
  'NTC_NO_ITEMS_DISPLAY' => '沒有要顯示的內容',
  'LBL_ALT_HOT_KEY' => 'Alt+',
  'LBL_SAVE_BUTTON_TITLE' => '保存 [Alt+S]',
  'LBL_EDIT_BUTTON_TITLE' => '編輯 [Alt+E]',
  'LBL_EDIT_BUTTON' => '編輯',
  'LBL_DUPLICATE_BUTTON_TITLE' => '複製 [Alt+U]',
  'LBL_DUPLICATE_BUTTON' => '複製',
  'LBL_DELETE_BUTTON_TITLE' => '刪除 [Alt+D]',
  'LBL_DELETE_BUTTON' => '刪除',
  'LBL_NEW_BUTTON_TITLE' => '新增 [Alt+N]',
  'LBL_CHANGE_BUTTON_TITLE' => '修改 [Alt+G]',
  'LBL_CANCEL_BUTTON_TITLE' => '取消 [Alt+X]',
  'LBL_SEARCH_BUTTON_TITLE' => '搜尋 [Alt+Q]',
  'LBL_CLEAR_BUTTON_TITLE' => '清除 [Alt+C]',
  'LBL_SELECT_BUTTON_TITLE' => '選擇 [Alt+T]',
  'LBL_SAVE_BUTTON_KEY' => 'S',
  'LBL_EDIT_BUTTON_KEY' => 'E',
  'LBL_DUPLICATE_BUTTON_KEY' => 'U',
  'LBL_DELETE_BUTTON_KEY' => 'D',
  'LBL_NEW_BUTTON_KEY' => 'N',
  'LBL_CHANGE_BUTTON_KEY' => 'G',
  'LBL_CANCEL_BUTTON_KEY' => 'X',
  'LBL_SEARCH_BUTTON_KEY' => 'Q',
  'LBL_CLEAR_BUTTON_KEY' => 'C',
  'LBL_SELECT_BUTTON_KEY' => 'T',
  'LBL_SAVE_BUTTON_LABEL' => '保存',
  'LBL_EDIT_BUTTON_LABEL' => '編輯',
  'LBL_DUPLICATE_BUTTON_LABEL' => '複製',
  'LBL_DELETE_BUTTON_LABEL' => '刪除',
  'LBL_NEW_BUTTON_LABEL' => '新增',
  'LBL_CHANGE_BUTTON_LABEL' => '修改',
  'LBL_CANCEL_BUTTON_LABEL' => '取消',
  'LBL_SEARCH_BUTTON_LABEL' => '搜尋',
  'LBL_CLEAR_BUTTON_LABEL' => '清除',
  'LBL_NEXT_BUTTON_LABEL' => 'Next',
  'LBL_SELECT_BUTTON_LABEL' => '選擇',
  'LBL_SELECT_CONTACT_BUTTON_TITLE' => '選擇聯絡人 [Alt+T]',
  'LBL_SELECT_CONTACT_BUTTON_KEY' => 'T',
  'LBL_VIEW_PDF_BUTTON_LABEL' => 'View PDF',
  'LBL_VIEW_PDF_CONTACT_BUTTON_TITLE' => 'View PDF [Alt+P]',
  'LBL_VIEW_PDF_CONTACT_BUTTON_KEY' => 'P',
  'LBL_SELECT_CONTACT_BUTTON_LABEL' => '選擇聯絡人',
  'LBL_SELECT_USER_BUTTON_TITLE' => '選擇使用者 [Alt+U]',
  'LBL_SELECT_USER_BUTTON_KEY' => 'U',
  'LBL_SELECT_USER_BUTTON_LABEL' => '選擇使用者',
  'LBL_CREATE_BUTTON_LABEL' => 'Create',
  'LBL_SHORTCUTS' => 'Shortcuts',
  'LBL_LIST_NAME' => '名稱',
  'LBL_LIST_USER_NAME' => '使用者名稱',
  'LBL_LIST_EMAIL' => 'Email',
  'LBL_LIST_PHONE' => '電話',
  'LBL_LIST_CONTACT_NAME' => '聯絡人',
  'LBL_LIST_CONTACT_ROLE' => 'Contact Role',
  'LBL_LIST_ACCOUNT_NAME' => '帳號',
  'LBL_USER_LIST' => '使用者清單',
  'LBL_CONTACT_LIST' => '聯絡人清單',
  'LBL_RELATED_RECORDS' => 'Related Records',
  'LBL_MASS_UPDATE' => 'Mass Update',
  'LNK_ADVANCED_SEARCH' => '高級搜尋',
  'LNK_BASIC_SEARCH' => '基本搜尋',
  'LNK_EDIT' => '編輯',
  'LNK_REMOVE' => '刪除',
  'LNK_DELETE' => '刪除',
  'LNK_LIST_START' => '開始',
  'LNK_LIST_NEXT' => '下頁',
  'LNK_LIST_PREVIOUS' => '上頁',
  'LNK_LIST_END' => '最後',
  'LBL_LIST_OF' => '之',
  'LBL_OR' => 'OR',
  'LNK_PRINT' => '列印',
  'LNK_HELP' => '幫助',
  'LNK_ABOUT' => '*About',
  'NTC_REQUIRED' => '符號中的內容不能空白',
  'LBL_REQUIRED_SYMBOL' => '*',
  'LBL_CURRENCY_SYMBOL' => '?',
  'LBL_PERCENTAGE_SYMBOL' => '%',
  'LBL_THOUSANDS_SYMBOL' => 'K',
  'NTC_DATE_FORMAT' => '(yyyy-mm-dd)',
  'NTC_TIME_FORMAT' => '(24:00)',
  'NTC_DATE_TIME_FORMAT' => '(yyyy-mm-dd 24:00)',
  'NTC_DELETE_CONFIRMATION' => '確定要刪除這個記錄嗎?',
  'ERR_DELETE_RECORD' => '欲刪除聯絡人記錄，必須有相應的記錄編號.',
  'ERR_CREATING_TABLE' => '新增表時發生錯誤: ',
  'ERR_CREATING_FIELDS' => '添入附加細節內容時發生錯誤: ',
  'ERR_MISSING_REQUIRED_FIELDS' => '缺少需要的內容：',
  'ERR_INVALID_EMAIL_ADDRESS' => 'email 地址非法.',
  'ERR_INVALID_DATE_FORMAT' => '日期格式必須為: yyyy-mm-dd',
  'ERR_INVALID_MONTH' => '請輸入合法的月份.',
  'ERR_INVALID_DAY' => '請輸入合法的日子.',
  'ERR_INVALID_YEAR' => '請輸入合法的四位年份數字.',
  'ERR_INVALID_DATE' => '請輸入合法的日期.',
  'ERR_INVALID_HOUR' => '請輸入合法的小時.',
  'ERR_INVALID_TIME' => '請輸入合法的時間.',
  'ERR_INVALID_AMOUNT' => 'Please enter a valid amount.',
  'NTC_CLICK_BACK' => '請按返回退回，並糾正錯誤.',
  'LBL_LIST_ASSIGNED_USER' => '分配給：',
  'LBL_ASSIGNED_TO' => '分配給：',
  'LBL_DATE_MODIFIED' => '*Last Modified:',
  'LBL_DATE_ENTERED' => '*Created:',
  'LBL_CURRENT_USER_FILTER' => '與己相關：',
  'NTC_LOGIN_MESSAGE' => '請登入應用程式',
  'LBL_NONE' => '-- 無 --',
  'LBL_BACK' => '*Back',
  'LBL_IMPORT' => '*Import',
  'LBL_EXPORT' => '*Export',
  'LBL_EXPORT_ALL' => 'Export All',
  'LBL_SAVE_NEW_BUTTON_TITLE' => 'Save & Create New [Alt+V]',
  'LBL_SAVE_NEW_BUTTON_KEY' => 'V',
  'LBL_SAVE_NEW_BUTTON_LABEL' => 'Save & Create New',
  'LBL_NAME' => 'Name',
  'LBL_SUBJECT' => 'Subject',
);


?>