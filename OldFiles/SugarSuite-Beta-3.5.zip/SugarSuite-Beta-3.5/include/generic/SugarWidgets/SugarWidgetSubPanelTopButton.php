<?php
/**
 * SugarWidgetSubPanelTopButton
 *
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */

// $Id: SugarWidgetSubPanelTopButton.php,v 1.10 2005/07/31 23:53:24 jacob Exp $

require_once('include/generic/SugarWidgets/SugarWidget.php');

class SugarWidgetSubPanelTopButton extends SugarWidget
{
    var $module;
	var $title;
	var $access_key;
	var $form_value;
	var $additional_form_fields;

//todojt rename defines to layout defs and make it a member variable instead of passing it multiple layers with extra copying.
	
	/** Take the keys for the strings and look them up.  Module is literal, the rest are label keys
	*/
	function SugarWidgetSubPanelTopButton($module='', $title='', $access_key='', $form_value='')
	{
		global $app_strings;

		if(is_array($module))
		{
			// it is really the class details from the mapping
			$class_details =& $module;
			
			// If keys were passed into the constructor, translate them from keys to values.
			if(!empty($class_details['module']))
				$this->module = $class_details['module'];
			if(!empty($class_details['title']))
				$this->title = $app_strings[$class_details['title']];
			if(!empty($class_details['access_key']))
				$this->access_key = $app_strings[$class_details['access_key']];
			if(!empty($class_details['form_value']))
				$this->form_value = translate($class_details['form_value'], $this->module);
			if(!empty($class_details['additional_form_fields']))
				$this->additional_form_fields = $class_details['additional_form_fields'];
		}
		else
		{
			$this->module = $module;
		
			// If keys were passed into the constructor, translate them from keys to values.
			if(!empty($title))
				$this->title = $app_strings[$title];
			if(!empty($access_key))
				$this->access_key = $app_strings[$access_key];
			if(!empty($form_value))
				$this->form_value = translate($form_value, $module);
		}
	}
	
	function &_get_form($defines, $additionalFormFields = null)
	{
		global $app_strings,$currentModule;

		// Create the additional form fields with real values if they were not passed in
		if(empty($additionalFormFields) && $this->additional_form_fields)
		{
			foreach($this->additional_form_fields as $key=>$value)
			{
				if(!empty($defines['focus']->$value))
				{
					$additionalFormFields[$key] = $defines['focus']->$value;
				}
				else
				{
					$additionalFormFields[$key] = '';
				}
			}
		}
		
		if(!empty($this->module))
		{
			$defines['child_module_name'] = $this->module;
		}
		else
		{
			$defines['child_module_name'] = $defines['module'];
		}

		$defines['parent_bean_name'] = get_class( $defines['focus']);

		$button  = "<form border='0' action='index.php' method='post' name='form' id='form".$defines['child_module_name']."'>\n";

		//module_button is used to override the value of module name
		$button.="<input type='hidden' name='module' value='".$defines['child_module_name']."'>\n";
		$button .= "<input type='hidden' name='".strtolower($defines['parent_bean_name'])."_id' value='".$defines['focus']->id."'>\n";

		if (isset($defines['focus']->name)) $button .= "<input type='hidden' name='".strtolower($defines['parent_bean_name'])."_name' value='".$defines['focus']->name."'>";

		$button .= "<input type='hidden' name='return_module' value='".$currentModule."'>\n";
		$button .= "<input type='hidden' name='return_action' value='".$defines['action']."'>\n";
		$button .= "<input type='hidden' name='return_id' value='".$defines['focus']->id."'>\n";

		// default additional form fields for parent_type, parent_name and parent_id if they are not specified
		if(empty($additionalFormFields['parent_type']))
		{
			$additionalFormFields['parent_type'] = $defines['focus']->module_dir;
        }
        if(empty($additionalFormFields['parent_name']))
        {
			$additionalFormFields['parent_name'] = $defines['focus']->name;
        }
        if(empty($additionalFormFields['parent_id']))
        {
			$additionalFormFields['parent_id'] = $defines['focus']->id;
        }
        
        $button .= "<input type='hidden' name='action' value='EditView'>\n";

        // fill in additional form fields for all but action
        foreach($additionalFormFields as $key => $value)
        {
            if($key != 'action')
            {
                $button .= "<input type='hidden' name='$key' value='".$value."'>\n";
            }
        }

		return $button;
	}

	/** This default function is used to create the HTML for a simple button */
	function &display($defines, $additionalFormFields = null)
	{
		global $app_strings;
		
		$button = $this->_get_form($defines, $additionalFormFields);
		$button .= "<input title='$this->title' accesskey='$this->access_key' class='button' type='submit' name='button' value='  $this->form_value  ' />\n</form>";
		return $button;
	}
	
}
?>
