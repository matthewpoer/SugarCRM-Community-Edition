<?php
/**
 * SugarWidgetSubPanelTopCreateNoteButton
 *
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */

// $Id: SugarWidgetSubPanelTopSummaryButton.php,v 1.2 2005/07/31 23:53:24 jacob Exp $

require_once('include/generic/SugarWidgets/SugarWidgetSubPanelTopButton.php');
require_once('include/JSON.php');

class SugarWidgetSubPanelTopSummaryButton extends SugarWidgetSubPanelTopButton
{
	function display($defines)
	{
		global $app_strings;
        global $currentModule;

        $popup_request_data = array(
		'call_back_function' => 'set_return',
		'form_name' => 'EditView',
		'field_to_name_array' => array(),
		);

        $json = new JSON(JSON_LOOSE_TYPE);
        $encoded_popup_request_data = $json->encode($popup_request_data);

		$title = $app_strings['LBL_ACCUMULATED_HISTORY_BUTTON_TITLE'];
		$accesskey = $app_strings['LBL_ACCUMULATED_HISTORY_BUTTON_KEY'];
		$value = $app_strings['LBL_ACCUMULATED_HISTORY_BUTTON_LABEL'];
        $id = $defines['focus']->id;

		$button = $this->_get_form($defines);
		$button .= "<input title='$title' accesskey='$accesskey' class='button' type='button' name='button' value='  $value  ' onclick='open_popup(\"Activities\", \"600\", \"400\", \"&record=$id&module_name=$currentModule\", true, false, $encoded_popup_request_data);'/>\n";
		$button .= "</form>";
		return $button;
	}
}
?>
