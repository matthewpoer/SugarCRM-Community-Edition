<?php
/**
 * SugarWidgetField
 *
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */

// $Id: SugarWidgetField.php,v 1.17 2005/08/01 05:44:26 andrew Exp $

require_once('include/generic/SugarWidgets/SugarWidget.php');

class SugarWidgetField extends SugarWidget
{
	function & getSubClass($layout_def)
	{
		if (! empty($layout_def['type']))
		{
/*
                    if ( $layout_def['name'] == 'first_name' ||
                                $layout_def['name'] == 'last_name' ||
                                $layout_def['name'] == 'name' ||
                                 $layout_def['name'] == 'subject' )
                        {
				$layout_def['type'] = 'name';
                        }
*/

			$subclass_name=get_class($this).$layout_def['type'];
	
			return $this->layout_manager->getClassFromWidgetDef($layout_def);
		} else {
			return $this;
		}
	}

 
 function &display($layout_def)
 {
//print $layout_def['start_link_wrapper']."===";
	$obj = & $this->getSubClass($layout_def);

	$context = $this->layout_manager->getAttribute('context');//_ppd($context);
	$func_name = 'display'.$context;

	if ( ! empty($context) && method_exists($obj,$func_name))
	{
		return  $obj->$func_name($layout_def);
	} else
	{
		return 'display not found:'.$func_name;
	}
 }

 function &query($layout_def)
 {
	$obj = $this->getSubClass($layout_def);

	$context = $this->layout_manager->getAttribute('context');;
	$func_name = 'query'.$context;

	if ( ! empty($context) && method_exists($obj,$func_name))
	{
		return  $obj->$func_name($layout_def);
	} else
	{
		return '';
	}
 }

 function &_get_full_column_name($layout_def)
 {
	return $layout_def['table_alias'].".".$layout_def['name'];
 }

 function &_get_column_alias($layout_def)
 {
	$alias_arr = array();

	if ( ! empty($layout_def['name']) && $layout_def['name']=='count')
	{
		return 'count';
	}

	if ( ! empty($layout_def['table_alias']))
	{
		array_push($alias_arr,$layout_def['table_alias']);
	}


	if ( ! empty($layout_def['group_function']))
	{
		array_push($alias_arr,$layout_def['group_function']);
	}

	if ( ! empty($layout_def['name']))
	{
		array_push($alias_arr,$layout_def['name']);
	}

	return implode("_",$alias_arr);
 }

 function &_get_column_select($layout_def)
 {
		$alias = '';
		$endalias = '';
	if ( ! empty($layout_def['group_function']) )
	{
		$endalias = ')';
		$alias .= $layout_def['group_function']."(";
	}
	if ( ! empty($layout_def['table_alias']))
	{
		$alias .= $layout_def['table_alias'].".".$layout_def['name'];
	
	}else if (! empty($layout_def['name'])) {
		$alias = $layout_def['name'];
	} else {
		$alias .= "*";
	}
	$alias .= $endalias;
	return $alias;
 }

 function &querySelect(&$layout_def)
 {
			return $this->_get_column_select($layout_def)." ".$this->_get_column_alias($layout_def)."\n";
 }

 function &queryGroupBy($layout_def)
 {
		if (! empty($layout_def['group_function']))
		{
			return $layout_def['group_function']."(".$layout_def['table_alias'].".".$layout_def['name'].") \n";
			return $this->_get_column_alias($layout_def)."\n";
		} else {
			return $layout_def['table_alias'].".".$layout_def['name']." \n";
		}
 }

 function &queryOrderBy($layout_def)
 {
			$order_by = $layout_def['table_alias'].".".$layout_def['name'];
			
			if ( empty($layout_def['sort_dir']) || $layout_def['sort_dir'] == 'a')
			{
				return $order_by." ASC";
			} else {
				return $order_by." DESC";
			}
 }

 function &queryFilter($layout_def)
 {
//print "FILTER:".$layout_def['qualifier_name'];
	$method_name = "queryFilter".$layout_def['qualifier_name'];
	return $this->$method_name($layout_def);
 }

 function &displayDetailLabel(&$layout_def)
 {
 
		return '';
 }

 function &displayDetail($layout_def)
 {
 
		return '';
 }
	function &displayHeaderCellPlain($layout_def)
	{
		$module_name = $this->layout_manager->getAttribute('module_name');
		$header_cell_text = '';
		$key = '';
		  	 
		if(!empty($layout_def['label']))
		{
			$header_cell_text = $layout_def['label'] ;
		}
		elseif(!empty($layout_def['vname']))
		{
			$key = $layout_def['vname'];
			 
			if(empty($key))
			{
				$header_cell_text = $layout_def['name'];
			}
			else
			{
				$header_cell_text = translate($key, $module_name);
			}
		}
		return $header_cell_text;
	}

	function & displayHeaderCell($layout_def)
	{
		require_once("include/ListView/ListView.php");
	                                                                                                 
		//$module_name = $this->layout_manager->getAttribute('module_name');
		// don't show sort links if name isn't defined
		$no_sort = $this->layout_manager->getAttribute('no_sort');
		if(empty($layout_def['name']) || ! empty($no_sort))
		{
			return $layout_def['label'];
		}
	
                                                                                                
		$sort_by ='';
		if ( ! empty($layout_def['table_key']) && ! empty($layout_def['name']) )
		{
			$sort_by = $layout_def['table_key'].":".$layout_def['name'];
		}
		else
		{
			return $this->displayHeaderCellPlain($layout_def);
		}

		$start = $this->layout_manager->getAttribute('start_link_wrapper');
		$end = $this->layout_manager->getAttribute('end_link_wrapper');

		$start = empty($start) ? '': $start;
		$end = empty($end) ? '': $end;

		$header_cell = "<a class=\"listViewThLinkS1\" href=\"".$start.$sort_by.$end."\">";
		$header_cell .= $this->displayHeaderCellPlain($layout_def);
		$header_cell .= "</a>";
		
		$arrow_start = ListView::getArrowStart($this->layout_manager->getAttribute('image_path'));
		$arrow_end = ListView::getArrowEnd($this->layout_manager->getAttribute('image_path'));
		                                                                                              
		$imgArrow = '';
		
		if (isset($layout_def['sort']))
		{
			$imgArrow = $layout_def['sort'];
		}
		$header_cell .= ' ' . $arrow_start.$imgArrow.$arrow_end;
		 
		return $header_cell;
	}

	function & displayList($layout_def)
	{
		return $this->displayListPlain($layout_def);
	}

	function & displayListPlain($layout_def)
	{
		$value = '';
		$key = '';
		
		if(isset($layout_def['varname']))
		{
			$key = strtoupper($layout_def['varname']);
		}
		else
		{
			$key = $this->_get_column_alias($layout_def);
			$key = strtoupper($key);
		}
		
		if(isset($layout_def['fields'][$key]))
		{
			$value = $layout_def['fields'][$key];
		}
		                                                                                                   
		return $value; 
	}

	function  & displayEditLabel($layout_def)
	{
		return '';
	}

	function & displayEdit($layout_def)
	{
		return '';
	}

	function  &displaySearchLabel($layout_def)
	{
		return '';
	}

	function &displaySearch($layout_def)
	{
		return '';
	}
}
?>
