<?php
/**
 * SugarWidgetSubPanelTopSelectButton
 *
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */

// $Id: SugarWidgetSubPanelTopSelectButton.php,v 1.9 2005/08/01 11:08:23 robert Exp $

require_once('include/generic/SugarWidgets/SugarWidgetSubPanelTopButton.php');

class SugarWidgetSubPanelTopSelectButton extends SugarWidgetSubPanelTopButton
{

	function SugarWidgetSubPanelTopSelectButton()
	{
	}

	function display(&$defines)
	{
		
		global $app_strings;
		$button  = $this->_get_form($defines);
		$selectName = 'LBL_SELECT_BUTTON';
		$module_name = $defines['popup_module'];//'Contacts';  // $defines['module_name']?
		$bean_name = 'subpanel';  // $defines['bean_name']?

		$child_field = $defines['popup_module'];
		//$child_field = strtolower($defines['popup_module']);
        $link_field_name=strtolower($defines['popup_module']);		
		if (isset($defines['popup_link'])) {
        	$link_field_name=strtolower($defines['popup_link']);
		}
		$bean_field_name="subpanel_id";


    $return_module = $_REQUEST['module'];
    $return_action = 'SubPanelViewer';
    $return_id = $_REQUEST['record'];
    //$linked_field = strtolower($child_field);

    $return_url = "index.php?module=$return_module&action=$return_action&subpanel=$module_name&record=$return_id&sugar_body_only=1";
    $return_url = urlencode($return_url);


                                                                                                   
		$button .= "<input id='select_button' title='".$app_strings[$selectName.'_TITLE']
			."' accessyKey='".$app_strings[$selectName.'_KEY']
			."' type='button' class='button' value='".$app_strings[$selectName.'_LABEL']
			."' name='button'  onclick='current_popup_window = window.open_popup(\"".$module_name."\", 600, 400, \"\",false,false,{\"call_back_function\":\"set_return_and_save_background\",\"form_name\":\"DetailView\",\"field_to_name_array\":{\"id\":\"".$bean_field_name."\"},\"passthru_data\":{\"child_field\":\"".$child_field."\",\"return_url\":\"{$return_url}\",\"link_field_name\":\"".$link_field_name."\",\"module_name\":\"".$module_name."\"}});'/>\n";
		return $button;

	}
}
?>
