<?php
/**
 * LayoutManager
 *
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */

// $Id: LayoutManager.php,v 1.15 2005/08/01 11:46:02 clint Exp $

require_once('include/generic/SugarWidgets/SugarWidgetSubPanelTopButton.php');

class LayoutManager
{
	var $defs = array();
	var $widget_prefix = 'SugarWidget';

	function LayoutManager()
	{
		// set a sane default for context
		$this->defs['context'] = 'Detail';
	}	

	function setAttribute($key,$value)
	{
		$this->defs[$key] = $value;
	}	

	function setAttributePtr($key,&$value)
	{
		$this->defs[$key] = & $value;
	}	

	function &getAttribute($key)
	{
		if ( isset($this->defs[$key]))
		{
			return $this->defs[$key];
		} else {
			return null;
		}
	}	

	// Take the class name from the widget definition and use the class to look it up
	function &getClassFromWidgetDef($widget_def)
	{
		static $class_map = array(
			'SugarWidgetSubPanelTopCreateButton' => array(
				'title'=>'LBL_NEW_BUTTON_TITLE',
				'access_key'=>'LBL_NEW_BUTTON_KEY',
				'form_value'=>'LBL_NEW_BUTTON_LABEL'
				),
			'SugarWidgetSubPanelTopScheduleMeetingButton' => array(
				'module'=>'Meetings',
				'title'=>'LBL_NEW_BUTTON_TITLE',
				'access_key'=>'LBL_NEW_BUTTON_KEY',
				'form_value'=>'LNK_NEW_MEETING'
				),
			'SugarWidgetSubPanelTopScheduleCallButton' => array(
				'module'=>'Calls',
				'title'=>'LBL_NEW_BUTTON_TITLE',
				'access_key'=>'LBL_NEW_BUTTON_KEY',
				'form_value'=>'LNK_NEW_CALL'
				),
			'SugarWidgetSubPanelTopCreateTaskButton' => array(
				'module'=>'Tasks',
				'title'=>'LBL_NEW_BUTTON_TITLE',
				'access_key'=>'LBL_NEW_BUTTON_KEY',
				'form_value'=>'LNK_NEW_TASK'
				),
			'SugarWidgetSubPanelTopCreateNoteButton' => array(
				'module'=>'Notes',
				'title'=>'LBL_NEW_BUTTON_TITLE',
				'access_key'=>'LBL_NEW_BUTTON_KEY',
				'form_value'=>'LNK_NEW_NOTE'
				),
			'SugarWidgetSubPanelTopArchiveEmailButton' => array(
				'module'=>'Emails',
				'title'=>'LBL_NEW_BUTTON_TITLE',
				'access_key'=>'LBL_NEW_BUTTON_KEY',
				'form_value'=>'LNK_NEW_EMAIL'
				),
			'SugarWidgetSubPanelTopCreateContactAccountButton' => array(
				'module'=>'Contacts',
				'title'=>'LBL_NEW_BUTTON_TITLE',
				'access_key'=>'LBL_NEW_BUTTON_KEY',
				'form_value'=>'LBL_NEW_BUTTON_LABEL',
        		'additional_form_fields' => array(
        			'primary_address_street' => 'shipping_address_street',
					'primary_address_city' => 'shipping_address_city',
					'primary_address_state' => 'shipping_address_state',
					'primary_address_country' => 'shipping_address_country',
					'primary_address_postalcode' => 'shipping_address_postalcode',
					'to_email_addrs' => 'email1'
					)
				),
			'SugarWidgetSubPanelTopCreateAccountNameButton' => array(
				'module'=>'Cases',
				'title'=>'LBL_NEW_BUTTON_TITLE',
				'access_key'=>'LBL_NEW_BUTTON_KEY',
				'form_value'=>'LBL_NEW_BUTTON_LABEL',
        		'additional_form_fields' => array(
        			'account_id' => 'account_id',
					'account_name' => 'account_name',
					)
				),
			'SugarWidgetSubPanelTopCreateContact' => array(
				'module'=>'Contacts',
				'title'=>'LBL_NEW_BUTTON_TITLE',
				'access_key'=>'LBL_NEW_BUTTON_KEY',
				'form_value'=>'LBL_NEW_BUTTON_LABEL',
        		'additional_form_fields' => array(
        			'account_id' => 'account_id',
					'account_name' => 'account_name',
					)
				),

			'SugarWidgetSubPanelTopComposeEmailButton' => array(
				'module'=>'Emails',
				'title'=>'LBL_COMPOSE_EMAIL_BUTTON_TITLE',
				'access_key'=>'LBL_COMPOSE_EMAIL_BUTTON_KEY',
				'form_value'=>'LBL_COMPOSE_EMAIL_BUTTON_LABEL',
        		'additional_form_fields' => array(
        			'to_email_addrs' => 'email1',
					)
				),

/*			

			'SugarWidgetSubPanelTopCreateButton' => array(
				'module'=>'',
				'title'=>'',
				'access_key'=>'',
				'form_value'=>''
				),
*/

		);			

		
		
		
		if(!empty($widget_def['widget_class']))
		{
			$class_name = $this->widget_prefix.$widget_def['widget_class'];
		}
		else 
		{
			// Default the class to SugarWidgetField
			$class_name = $this->widget_prefix.'Field';
		}
		
		// Check to see if this is one of the known class mappings.
		if(!empty($class_map[$class_name]))
		{
			return new SugarWidgetSubPanelTopButton($class_map[$class_name]);
		}			

		// At this point, we have a class name and we do not have a valid class defined.
		if(!class_exists($class_name))
		{
			
			// The class does not exist.  Try including it.
			require_once('include/generic/SugarWidgets/'.$class_name.'.php');
			
			if(!class_exists($class_name))
			{
				// If we still do not have a class, oops....
				die("LayoutManager: Class not found:".$class_name);
			}
		}
		
		return new $class_name($this); // cache disabled $this->getClassFromCache($class_name);
	}

	function widgetDisplay($widget_def)
	{
		$theclass = & $this->getClassFromWidgetDef($widget_def);
		return $theclass->display($widget_def);
	}	

	function widgetQuery($widget_def)
	{
		$theclass = & $this->getClassFromWidgetDef($widget_def);
		return $theclass->query($widget_def);
	}

}
?>
