<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
require_once('include/ListView/ListView.php');

class DetailView extends ListView {
	
	var $list_row_count = null;
	
	function DetailView(){
		parent::ListView();
		
		global $theme, $app_strings, $image_path, $currentModule;
		$this->local_theme = $theme;
		$this->local_app_strings = &$app_strings;
	}
	
	function processSugarBean($html_varName, $seed, $offset, $isfirstview = 0){
		global $row_count;
		global $next_offset;
		global $previous_offset;
		global $list_view_row_count;
		global $current_offset;
		if($offset < 0){
			$offset = 0;
		}
		
		$this->populateQueryWhere($isfirstview);
		
		//$orderby = $this->getSessionVariable($html_varName, "ORDER_BY");
		$this->query_orderby = $this->getSessionVariable($html_varName, "ORDER_BY_DETAIL");
		
		$current_offset = $this->getOffset($html_varName);
		$response = $seed->get_detail($this->query_orderby, $this->query_where, $offset);
		$object = $response['list'];


		$row_count = $response['row_count'];
		$next_offset = $response['next_offset'];
		$previous_offset = $response['previous_offset'];
		$list_view_row_count = $row_count;
		$this->setListViewRowCount($row_count);

		return $object;
	}
	
	function populateQueryWhere($isfirstview){
		if($isfirstview == 1){
			$this->query_where = $this->getSessionVariable("query", "where");
			//SETTING QUERY FOR LATER USE
			$this->setSessionVariable("QUERY_DETAIL", "where", $this->query_where);
		}
		else{
			$this->query_where = $this->getSessionVariable("QUERY_DETAIL", "where");
		}
	}
	
	function processListNavigation( $xtpl, $html_varName, $current_offset){
		global $image_path, $export_module, $sugar_config, $current_user;
		
		$row_count = $this->getListViewRowCount();
		if($current_offset == 0){
			return; 
		}
		else if($current_offset < 0){
			$current_offset = 1;
		}
		else if($current_offset > $row_count){
			$current_offset = $row_count;	
		}
		
		$next_offset = $current_offset + 1;
		$previous_offset = $current_offset - 1;
		
			if(!isset($this->base_URL)){
				$this->base_URL = $_SERVER['PHP_SELF'];
				if(empty($this->base_URL)){
					$this->base_URL = 'index.php';
				}
			
				/*fixes an issue with 
				deletes when doing a search*/
				foreach($_GET as $name=>$value){
					if(!empty($value)){
						if($name != $this->getSessionVariableName($html_varName,"ORDER_BY") && $name != "offset" && substr_count($name, "ORDER_BY")==0 && $name!="isfirstview"){
							if (is_array($value)) {
								foreach($value as $valuename=>$valuevalue){
									$this->base_URL	.= "&{$name}[]=".$valuevalue;
								}
							} else {
								if(substr_count( $this->base_URL, '?') > 0){
									$this->base_URL	.= "&$name=$value";
								}else{
									$this->base_URL	.= "?$name=$value";
								}
							}
						}
					}
				}

				if($_SERVER['REQUEST_METHOD'] == 'POST'){
					$this->base_URL .= '?';
					if(isset($_REQUEST['action'])) $this->base_URL .= '&action='.$_REQUEST['action'];
					if(isset($_REQUEST['record'])) $this->base_URL .= '&record='.$_REQUEST['record'];
					if(isset($_REQUEST['module'])) $this->base_URL .= '&module='.$_REQUEST['module'];
				}
				$this->base_URL .= "&offset=";
			}
			$start_URL = $this->base_URL."1";
			$current_URL = $this->base_URL.$current_offset;
			$previous_URL  = $this->base_URL.$previous_offset;
			$next_URL  = $this->base_URL.$next_offset;
			$end_URL  = $this->base_URL.$row_count;
			$list_URL = $this->base_URL.'&action=index&module='.$_REQUEST['module'];
			$current_page = floor($current_offset / $this->records_per_page) * $this->records_per_page;
			
			//if(0 != $this->getOffset($html_varName)){
			//	$list_URL .= '&'.$this->getSessionVariableName($html_varName,"offset").'='.$this->getOffset($html_varName);
			$list_URL .= '&'.$this->getSessionVariableName($html_varName,"offset").'='.$current_page;
			//}

			if(1 == $current_offset){
				$start_link = get_image($image_path."start_off","alt='".$this->local_app_strings['LNK_LIST_START']."'  border='0' align='absmiddle'")."&nbsp;".$this->local_app_strings['LNK_LIST_START'];
				
				$previous_link = get_image($image_path."previous_off","alt='".$this->local_app_strings['LNK_LIST_PREVIOUS']."'  border='0' align='absmiddle'")."&nbsp;".$this->local_app_strings['LNK_LIST_PREVIOUS'];
			}else{
				$start_link = "<a href=\"$start_URL\" class=\"tabDetailViewDFLink\">".get_image($image_path."start","alt='".$this->local_app_strings['LNK_LIST_START']."'  border='0' align='absmiddle'")."</a>&nbsp;<a href=\"$start_URL\" class=\"tabDetailViewDFLink\">".$this->local_app_strings['LNK_LIST_START']."</a>";
				if(0 != $current_offset){
				$previous_link = "<a href=\"$previous_URL\" class=\"tabDetailViewDFLink\">".get_image($image_path."previous","alt='".$this->local_app_strings['LNK_LIST_PREVIOUS']."'  border='0' align='absmiddle'")."</a>&nbsp;<a href=\"$previous_URL\" class=\"tabDetailViewDFLink\">".$this->local_app_strings['LNK_LIST_PREVIOUS']."</a>";
				}
				else {
					$previous_link = get_image($image_path."previous_off","alt='".$this->local_app_strings['LNK_LIST_PREVIOUS']."'  border='0' align='absmiddle'")."&nbsp;".$this->local_app_strings['LNK_LIST_PREVIOUS'];
				}
			}


			if($row_count <= $current_offset){
				$end_link = $this->local_app_strings['LNK_LIST_END']."&nbsp;".get_image($image_path."end_off","alt='".$this->local_app_strings['LNK_LIST_END']."'  border='0' align='absmiddle'");
				$next_link = $this->local_app_strings['LNK_LIST_NEXT']."&nbsp;".get_image($image_path."next_off","alt='".$this->local_app_strings['LNK_LIST_NEXT']."'  border='0' align='absmiddle'");
			}
			else{
				$end_link = "<a href=\"$end_URL\" class=\"tabDetailViewDFLink\">".$this->local_app_strings['LNK_LIST_END']."</a>&nbsp;<a href=\"$end_URL\" class=\"tabDetailViewDFLink\">".get_image($image_path."end","alt='".$this->local_app_strings['LNK_LIST_END']."'  border='0' align='absmiddle'")."</a>";
				$next_link = "<a href=\"$next_URL\" class=\"tabDetailViewDFLink\">".$this->local_app_strings['LNK_LIST_NEXT']."</a>&nbsp;<a href=\"$next_URL\" class=\"tabDetailViewDFLink\">".get_image($image_path."next","alt='".$this->local_app_strings['LNK_LIST_NEXT']."'  border='0' align='absmiddle'")."</a>";
			}
			
			$list_link = "<a href=\"$list_URL\" class=\"tabDetailViewDFLink\">".$this->local_app_strings['LNK_LIST_RETURN']."&nbsp;</a>";
			

			$html_text = "";
			$html_text .= "<tr>\n";
			$html_text .= "<td COLSPAN=\"20\" style='padding: 0px;' class=\"listViewPaginationTdS1\">\n";
			$html_text .= "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\"><tr><td align=\"left\"></td>\n";
			$html_text .= "<td nowrap align='right' class='tabDetailViewDL'>".$list_link."&nbsp;&nbsp;&nbsp;&nbsp;".$start_link."&nbsp;&nbsp;".$previous_link."&nbsp;&nbsp;<span class='tabDetailViewDL'>(".$current_offset." ".$this->local_app_strings['LBL_LIST_OF']." ".$row_count.")</span>&nbsp;&nbsp;".$next_link."&nbsp;&nbsp;".$end_link."</td></tr></table>\n";
			$html_text .= "</td>\n";
			$html_text .= "</tr>\n";
			$xtpl->assign("PAGINATION",$html_text);

			//$this->xTemplate->parse($xtemplateSection.".list_nav_row");
	}
	
		
	function setListViewRowCount($count)
	{
		$this->list_row_count = $count;	
	}
	
	function getListViewRowCount()
	{
		return $this->list_row_count;
	}

	}
?>
