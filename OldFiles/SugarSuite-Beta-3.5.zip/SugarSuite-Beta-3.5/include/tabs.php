<?php
/**
 * SugarWidgetTabs
 *
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */
 
// $Id: tabs.php,v 1.4 2005/07/25 10:11:58 andrew Exp $

require_once('include/generic/SugarWidgets/SugarWidget.php');

class SugarWidgetTabs extends SugarWidget
{
 var $tabs;
 var $current_key;

 function SugarWidgetTabs(&$tabs,$current_key,$jscallback)
 {
   $this->tabs = $tabs;
   $this->current_key = $current_key;
   $this->jscallback = $jscallback;
 }

 function display()
 {
	global $image_path;
	$IMAGE_PATH = $image_path;
	ob_start();
?>
<script>
var keys = [ <?php 
$tabs_count = count($this->tabs);
for($i=0; $i < $tabs_count;$i++) 
{
 $tab = $this->tabs[$i];
 echo "\"".$tab['key']."\""; 
 if ($tabs_count > ($i + 1))
 {
   echo ",";
 }
}
?>]; 

function selectTabCSS(key)
{
  var tds = ['left','middle','right'];

  for( var i=0; i<keys.length;i++)
  {
   var theclass = 'otherTab';

 if ( key == keys[i])
 {
   theclass = 'currentTab';
 }
   for( var j=0; j<tds.length;j++)
   {
  	document.getElementById('tab_td_'+tds[j]+'_'+keys[i]).style.backgroundImage = 'url(<?php echo $IMAGE_PATH; ?>'+theclass+'_'+tds[j]+'.gif )';
  	document.getElementById('tab_td_'+tds[j]+'_'+keys[i]).className = theclass;
   }
  	document.getElementById('tab_link_'+keys[i]).className = theclass;
  }
    <?php echo $this->jscallback;?>(key);
}
</script>
<table cellspacing="0" cellpadding="0" border="0" width="100%">
<tr height="20">
<td style="padding-left:7px; background-image :url(<?php echo $IMAGE_PATH; ?>emptyTabSpace.gif);">&nbsp;</td>
<?php 
	foreach ($this->tabs as $tab)
	{
		$TITLE = $tab['title'];
		$TAB_CLASS = "otherTab";
		if ( $this->current_key == $tab['key'])
		{
			$TAB_CLASS = "currentTab";
		}
		$LINK = "<a id=\"tab_link_".$tab['key']."\" class=\"".$TAB_CLASS."\" href=\"javascript:selectTabCSS('{$tab['link']}');\">$TITLE</a>";

?>
<td>
	<table cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color: #E5E5E5;">
	<tr height="20">
	<td id="tab_td_left_<?php echo $tab['key'];?>" style="background-image : url(<?php echo $IMAGE_PATH; ?><?php echo $TAB_CLASS; ?>_left.gif);" ><img src="include/images/blank.gif" width="8" height="1" border="0" alt="<?php echo $TITLE; ?>"></td>
	<td id="tab_td_middle_<?php echo $tab['key'];?>" style="background-image : url(<?php echo $IMAGE_PATH; ?><?php echo $TAB_CLASS; ?>_middle.gif);" class="<?php echo $TAB_CLASS; ?>" nowrap><?php echo $LINK; ?></td>
	<td id="tab_td_right_<?php echo $tab['key'];?>" style="background-image : url(<?php echo $IMAGE_PATH; ?><?php echo $TAB_CLASS; ?>_right.gif);"><img src="include/images/blank.gif" width="8" height="1" border="0" alt="<?php echo $TITLE; ?>"></td>
	<td style="background-image : url(<?php echo $IMAGE_PATH; ?>emptyTabSpace.gif);"></td>
	<td style="background-image : url(<?php echo $IMAGE_PATH; ?>emptyTabSpace.gif);"><img src="include/images/blank.gif" width="1" height="1" border="0" alt=""></td>
	</tr>
   </table>
</td>
<?php
	}
?>
<td width="100%" style="background-image : url(<?php echo $IMAGE_PATH; ?>emptyTabSpace.gif);"><img src="include/images/blank.gif" width="1" height="1" border="0" alt=""></td>
</tr>
</table>
<?php 
	$ob_contents = ob_get_contents();
        ob_end_clean();
        return $ob_contents;
	}
}
?>
