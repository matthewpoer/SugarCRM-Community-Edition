// $Id: popup_helper.js,v 1.5 2005/08/01 11:08:23 robert Exp $


function handle_response(result)
{
	if(result && (result.status == 'success' || result.status == 'clear'))
	{
		eval("var request_data = " + window.document.forms['popup_query_form'].request_data.value);
		var passthru_data = Object();
		if(typeof(request_data.passthru_data) != 'undefined')
		{
			passthru_data = request_data.passthru_data;
		}
		var form_name = request_data.form_name;
		var field_to_name_array = request_data.field_to_name_array;
		var call_back_function = eval("window.opener." + request_data.call_back_function);
		
		var array_contents = Array();

		for(var the_key in field_to_name_array)
		{
			if(the_key != 'toJSON')
			{
				var the_name = field_to_name_array[the_key];
				var the_value = '';
				
				if(result.status == 'success')
				{
					the_value = result.record.fields[the_key];
				}
				array_contents.push('"' + the_name + '":"' + the_value + '"');
			}
		}

		eval("var name_to_value_array = {" + array_contents.join(",") + "}");
//	passthru_data['thewindow']= window;
		var result_data = {"form_name":form_name,"name_to_value_array":name_to_value_array,"passthru_data":passthru_data};
		var close_popup = window.opener.get_close_popup();
		
		call_back_function(result_data);

		if(close_popup)
		{
			window.close();
		}
		else
		{
			// TODO: need to close for now because a page refresh loses the request_data
		//	window.close();
		}

	}
	else
	{
		alert("Unable to retrieve record.");
	}
}

function send_back(module, id)
{
	if(module == '' && id == '')
	{
		/* no id given, so that must imply: clear the fields */
		handle_response({"status":"clear"});
	}
	else
	{
		query = {"module":module,"record":id};
		the_result = global_rpcClient.call_method('retrieve',query,true);
		handle_response(the_result);
	}
}
