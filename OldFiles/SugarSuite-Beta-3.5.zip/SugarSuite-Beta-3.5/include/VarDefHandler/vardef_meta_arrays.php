<?php

//holds various filter arrays for displaying vardef dropdowns
//You can add your own if you would like

$vardef_meta_array = array (

	'standard_display' => array(	
		'inclusion' =>	array(
		//end inclusion
		),			
		'exclusion' =>	array(	
			'type' => array('id'),
			'reportable' => false		
		//end exclusion
		),	
		'inc_override' => array(
			'type' => array('team_list'),	
		//end inc_override
		),	
		'ex_override' => array(
		//end ex_override
		)
	//end standard_display	
	),	

	'normal_trigger' => array(
		'inclusion' =>	array(
		//end inclusion
		),	
		'exclusion' =>	array(	
			'type' => array('id', 'link', 'datetime', 'date'),
			'reportable' => false,
		//end exclusion
		),
		
		'inc_override' => array(
			'type' => array('team_list'),
		//end inc_override
		),
		'ex_override' => array(
			'name' => 'team_name',
		//end ex_override
		)
	
	//end normal_trigger
	),
		'time_trigger' => array(
		'inclusion' =>	array(
		//end inclusion
		),	
		'exclusion' =>	array(	
			'type' => array('id', 'link'),
			'reportable' => true,
		//end exclusion
		),
		
		'inc_override' => array(
			'name' => array('team_id'),
		//end inc_override
		),
		'ex_override' => array(
		//end ex_override
		)
	
	//end time_trigger
	),		
	'action_filter' => array(
		'inclusion' =>	array(
		//end inclusion
		),	
		'exclusion' =>	array(	
			'type' => array('id', 'link', 'datetime', 'assigned_user_name'),
			'reportable' => false,
		//end exclusion
		),
		
		'inc_override' => array(
			'type' => array('team_list'),
			'name' => array('assigned_user_id'),
		//end inc_override
		),
		'ex_override' => array(
			'name' => 'team_name',
		//end ex_override
		)
	
	//end action_filter
	),
	'rel_filter' => array(
		'inclusion' =>	array(
			'type' => array('link'),
		//end inclusion
		),	
		'exclusion' =>	array(	
		//end exclusion
		),
		
		'inc_override' => array(
		//end inc_override
		),
		'ex_override' => array(
			'link_type' => 'one',
			'name' => 'users',
		//end ex_override
		)
	
	//end rel_filter
	),	
);

?>
