<?PHP
/*
 * The last parmeter should be used to specify parameters for oracle. it also acts has a complete override
 * for the additional_parameters array.
 */
function db_convert($string, $type, $additional_parameters=array(),$additional_parameters_oracle_only=array()){
	global $sugar_config;
	
	//converts the paramters array into a comma delimited string.
	$additional_parameters_string='';
	foreach ($additional_parameters as $value) {
		$additional_parameters_string.=",".$value;
	}
	$additional_parameters_string_oracle_only='';
	foreach ($additional_parameters_oracle_only as $value) {
		$additional_parameters_string_oracle_only.=",".$value;
	}
	
	if($sugar_config['dbconfig']['db_type']== "mysql"){
		switch($type){
			case 'today': return "CURDATE()";	
			case 'left': return "LEFT($string".$additional_parameters_string.")";
			case 'date_format': return "DATE_FORMAT($string".$additional_parameters_string.")";
		}
		return "$string";
	}else if($sugar_config['dbconfig']['db_type']== "oci8"){













	}
	return "$string";
}

function from_db_convert($string, $type){

	global $sugar_config;
	if($sugar_config['dbconfig']['db_type']== "mysql"){
		return $string;
	}else if($sugar_config['dbconfig']['db_type']== "oci8"){






	}
	return $string;
	
	
}

$toHTML = array(
	'"' => '&quot;',
	'<' => '&lt;',
	'>' => '&gt;',
	'& ' => '&amp; ',
	"'" =>  '&#039;',

);

function to_html($string, $encode=true){
	global $toHTML;
	
	if($encode && is_string($string)){//$string = htmlentities($string, ENT_QUOTES);
	$string = str_replace(array_keys($toHTML), array_values($toHTML), $string);
	}
	return $string;
}


function from_html($string, $encode=true){
	global $toHTML;
	//if($encode && is_string($string))$string = html_entity_decode($string, ENT_QUOTES);
	if($encode && is_string($string)){
		$string = str_replace(array_values($toHTML), array_keys($toHTML), $string);
	}
	return $string;
}

function run_sql_file( $filename ){
    if( !is_file( $filename ) ){
        print( "Could not find file: $filename <br>" );
        return( false );
    }

    require_once('include/database/PearDatabase.php');

    $fh         = fopen( $filename,'r' );
    $contents   = fread( $fh, filesize($filename) );
    fclose( $fh );

    $lastsemi   = strrpos( $contents, ';') ;
    $contents   = substr( $contents, 0, $lastsemi );
    $queries    = split( ';', $contents );
    $db         =& PearDatabase::getInstance();

    foreach( $queries as $query ){
        if( !empty($query) ){
            print( "Sending query: $query ;<br>" );
            $db->query( $query.';', true, "An error has occured while running.<br>" );
        }
    }
    return( true );
}
?>
