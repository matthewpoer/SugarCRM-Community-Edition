/**
 * SubPanelTiles javascript file
 *
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */
 
// $Id: SubPanelTiles.js,v 1.10 2005/08/01 11:08:23 robert Exp $

var request_id = 0;
var current_child_field = '';
var current_subpanel_url = '';
var child_field_loaded = new Object();
var request_map = new Object();
var current_popup_window ;

function get_module_name()
{
	return window.document.forms['DetailView'].elements['module'].value;
}

function get_record_id()
{
	return window.document.forms['DetailView'].elements['record'].value;
}

function save_finished(args)
{
	//alert("function save_finished, request:"+args.request_id);
	var child_field = request_map[args.request_id];
	delete (child_field_loaded[child_field] );
	showSubPanel(child_field);
}

function set_return_and_save_background(popup_reply_data)
{
	var form_name = popup_reply_data.form_name;
	var name_to_value_array = popup_reply_data.name_to_value_array;
	var passthru_data = popup_reply_data.passthru_data;
//  current_popup_window = passthru_data.thewindow;

	// construct the POST request
	var query_array =  new Array();
	for (var the_key in name_to_value_array)
	{
		if(the_key == 'toJSON')
		{
			/* just ignore */
		}
		else
		{
			query_array.push(the_key+"="+name_to_value_array[the_key]);
		}
	}
  
	var module = get_module_name();
	var id = get_record_id();
	  
	query_array.push('value=DetailView');
	query_array.push('module='+module);
	query_array.push('http_method=get');
	query_array.push('return_module='+module);
	query_array.push('return_id='+id);
	query_array.push('return_url='+escape(passthru_data['return_url']));
	query_array.push('record='+id);
	query_array.push('isDuplicate=false');
	query_array.push('action=Save2');
	query_array.push('subpanel_field_name='+escape(passthru_data['link_field_name']));
	query_array.push('subpanel_module_name='+escape(passthru_data['module_name']));
	
	
	var query_string = query_array.join('&');
	request_map[request_id] = passthru_data['child_field'];

	var returnstuff = http_fetch_sync('index.php',query_string);
	request_id++;
  got_data(returnstuff);

}

function got_data(args)
{
 var test = current_popup_window;
 if (typeof(current_popup_window) != 'undefined')
 {
   current_popup_window.close();
 }
	var list_subpanel = document.getElementById('list_subpanel_'+request_map[args.request_id]);
	var subpanel = document.getElementById('subpanel_'+request_map[args.request_id]);
	var child_field = request_map[args.request_id];
	list_subpanel.innerHTML='';
	list_subpanel.innerHTML=args.responseText;
	child_field_loaded[child_field] = 1;
	subpanel.style.display = 'inline';
	set_div_cookie(subpanel.cookie_name, 'inline');

	if (current_child_field != '' && child_field != current_child_field)
	{
		hideSubPanel(current_child_field);
	}
	
	current_child_field = child_field;
}

function showSubPanel(child_field,url,force_load)
{
	if ( typeof(force_load) == 'undefined')
	{
		force_load = false;
	}
	
	if (typeof (url) != 'undefined')
	{
		delete(child_field_loaded[child_field]);
	}

	if (force_load || typeof( child_field_loaded[child_field] ) == 'undefined')
	{
		if (! force_load)
		{
			// don't show 'loading..' for now, because it makes the page scroll annoyingly
			//var loading_panel = document.getElementById('loading_panel');
			//loading_panel.style.display = 'block';
		}
	
//alert("REQUESTID:"+request_id);
	
		request_map[request_id] = child_field;
		if ( typeof (url) == 'undefined')
		{
			var module = get_module_name();
			var id = get_record_id();
			url = 'index.php?sugar_body_only=1&module='+module+'&subpanel='+child_field+'&action=SubPanelViewer&inline=1&record='+id;
		}

		if ( url.indexOf('http://') != 0  && url.indexOf('https://') != 0)
		{
			url = ''+url;
		}

		current_subpanel_url = url;
	//	http_fetch_async(url,got_data,request_id++);
	var returnstuff = http_fetch_sync(url);
	request_id++;
  got_data(returnstuff);
	}
	else
	{
		var subpanel = document.getElementById('subpanel_'+child_field);
		subpanel.style.display = 'inline';
		
		set_div_cookie(subpanel.cookie_name, 'inline');

		if (current_child_field != '' && child_field != current_child_field)
		{
			hideSubPanel(current_child_field);
		}

		current_child_field = child_field;
	}
}

function hideSubPanel(child_field)
{
	var subpanel = document.getElementById('subpanel_'+child_field);
	subpanel.style.display = 'none';
	set_div_cookie(subpanel.cookie_name, 'none');
}
var sub_cookie_name = get_module_name() + '_divs';
var temp = Get_Cookie(sub_cookie_name);
var div_cookies = new Array();

if(temp && typeof(temp) != 'undefined'){
	div_cookies = get_sub_cookies(temp);
}
function set_div_cookie(name, display){
	div_cookies[name] = display;
	Set_Cookie(sub_cookie_name, subs_to_cookie(div_cookies), 3000, false, false,false);
}


function local_open_popup(name, width, height,arg1, arg2, arg3, params)
{
	return open_popup(name, width, height,arg1,arg2,arg3, params);
}
