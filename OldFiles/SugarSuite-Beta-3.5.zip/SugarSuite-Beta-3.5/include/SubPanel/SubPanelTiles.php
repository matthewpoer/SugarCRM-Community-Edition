<?php
/**
 * SubPanelTiles
 *
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */

// $Id: SubPanelTiles.php,v 1.30 2005/07/31 18:31:00 jacob Exp $

require_once('include/SubPanel/SubPanel.php');

class SubPanelTiles
{
	var $id;
	var $module;
	var $focus;
	var $start_on_field;
	var $layout_manager;
	var $layout_def_key;
	var $show_tabs = false;

	var $hidden_tabs=array(); //consumer of this class can array of tabs that should be hidden. the tab name
							//should be the array.
	
	function SubPanelTiles(&$focus, $layout_def_key)
	{
		$this->focus = $focus;
		$this->id = $focus->id;
		$this->module = $focus->module_dir;
		$this->linked_fields = $this->focus->get_linked_fields();
		$this->layout_def_key = $layout_def_key;
	}

	function display()
	{

		global $modListHeader;
		
		if (! isset($this->linked_fields) || count($this->linked_fields) == 0)
		{
			return '';
		}
		ob_start();
?>
<script type="text/javascript" src="include/javascript/popup_parent_helper.js"></script>
<script type="text/javascript" src="include/SubPanel/SubPanelTiles.js"></script>
<?php 
		
		$subpanel_setup = SubPanel::get_subpanel_setup($this->module);
		$linked_fields = $this->linked_fields;
		$tabs = array();
		$used_linked_fields = array();
		
		$div_cookies = get_sub_cookies($this->focus->module_dir . '_divs');
		foreach($subpanel_setup as $subpanel_tab_info) 
		{
			if (!array_key_exists($subpanel_tab_info['source_module'],$this->hidden_tabs)) {
				if(!empty($subpanel_tab_info['default_allow']) or array_key_exists($subpanel_tab_info['source_module'], $modListHeader)) {
	
					$subpanel_define = SubPanel::getSubPanelDefine($this->module, $subpanel_tab_info['source_module']);
					$subpanel_title_key = $subpanel_define['subpanel_title'];
					$subpanel_title = translate($subpanel_title_key, $subpanel_tab_info['source_module']);
					$tabs[] = array(
						'title' => translate($subpanel_title),
						'link' => $subpanel_tab_info['source_module'],
						'key' => $subpanel_tab_info['source_module'],
						'layout_def' => $subpanel_define,
					);
				}
			}
		}
		// TODO: redo the above foreach to loop thru the tabs we need more intelligently
		
		
		$current_key = '';
			if (! empty($this->show_tabs))
			{
				require_once('include/tabs.php');
    		$tab_panel = new SugarWidgetTabs($tabs, $current_key, 'showSubPanel');
				echo get_form_header('Related', '', false);
				echo "<br />" . $tab_panel->display();
			}
		
		foreach ($tabs as $tab) 
		{	 
				$display= 'none';
			$div_display = 'inline';
			$opp_display = 'none';
			$cookie_name =   $tab['link'] . '_v';
		if(isset($div_cookies[$cookie_name])){
			$div_display = 	$div_cookies[$cookie_name];
			
		}
		if($div_display == 'none'){
			$opp_display  = 'inline';
		}
			if (empty($this->show_tabs))
			{
				$max_min = "<div align='right'>";
 		 		$max_min .= "<span style=\"display: $opp_display\"  id=\"show_link_".$tab['key']."\"><a href='#' class='utilsLink' onclick=\"javascript:current_child_field = '".$tab['key']."';showSubPanel('".$tab['key']."');document.getElementById('show_link_".$tab['key']."').style.display='none';document.getElementById('hide_link_".$tab['key']."').style.display='';return false;\"><img src=\"themes/Sugar/images/advanced_search.gif\" border=\"0\">&nbsp;" . translate('LBL_SHOW') . "</a></span>";

				$max_min .= "<span id=\"hide_link_".$tab['key']."\" style=\"display: $div_display\"><a href='#' class='utilsLink' onclick=\"javascript:hideSubPanel('".$tab['key']."');document.getElementById('hide_link_".$tab['key']."').style.display='none';document.getElementById('show_link_".$tab['key']."').style.display='';return false;\"><img src=\"themes/Sugar/images/basic_search.gif\" border=\"0\">&nbsp;" . translate('LBL_HIDE') . "</a></span>";
				$max_min .= "</div>";
				echo get_form_header( $tab['title'], $max_min, false);
			}
 	
?>
<div cookie_name="<?php echo $cookie_name; ?>" id="subpanel_<?php echo $tab['link']; ?>" style="display:<?php echo $div_display;?>">
<script>document.getElementById("subpanel_<?php echo $tab['link']; ?>" ).cookie_name="<?php echo $cookie_name; ?>";</script>
<?php echo $this->get_buttons($tab); ?>
<?php
if($div_display != 'none'){
include_once('include/SubPanel/SubPanel.php');
$subpanel_object = new SubPanel($this->module, $_REQUEST['record'], $tab['key']);
$subpanel_object->setTemplateFile('include/SubPanel/SubPanelDynamic.html');
}
?>
<div id="list_subpanel_<?php echo $tab['link']; ?>"><?php if($div_display != 'none'){$subpanel_object->display(); }?></div>

</div>

<?php } ?>
</body>

<?php
		$ob_contents = ob_get_contents();
		ob_end_clean();
		return $ob_contents;
	}


	function getLayoutManager()
	{
		require_once('include/generic/LayoutManager.php');
	  if ( $this->layout_manager == null)
	  {
	    $this->layout_manager = new LayoutManager();
	  }
	  return $this->layout_manager;
	}


	function get_buttons(&$linked_field)
	{
		$layout_manager =& $this->getLayoutManager();
		$subpanel_def = $linked_field['layout_def'];
		$widget_contents = '<table cellpadding="0" cellspacing="0"><tr>';
		foreach($subpanel_def['top_buttons'] as $top_button)
		{
			$top_button['focus'] = $this->focus;
			$top_button['action'] = $_REQUEST['action'];
			$top_button['module'] = $linked_field['key'];
			$widget_contents .= '<td style="padding-right: 2px; padding-bottom: 2px;">'; 

			if(!empty($top_button['widget_class']))
			{
				$widget_contents .= $layout_manager->widgetDisplay($top_button);
			}
			else
			{
				$widget_contents .= "widget_class not defined for top subpanel buttons";
			}
			
			$widget_contents .= '</td>';
		}
		
		$widget_contents .= '</tr></table>';
		return $widget_contents;
	}
}
?>
