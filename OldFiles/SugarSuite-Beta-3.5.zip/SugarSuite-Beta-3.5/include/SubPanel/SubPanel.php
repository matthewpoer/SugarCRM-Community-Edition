<?php
/**
 * Generic sub-panel class
 *
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */

// $Id: SubPanel.php,v 1.26 2005/08/01 10:17:34 andrew Exp $

require_once('XTemplate/xtpl.php');
require_once("data/Tracker.php");
require_once('include/ListView/ListView.php');
require_once('upgrade/dir_inc.php');
require_once('include/utils/file_utils.php');
require_once('include/SubPanel/registered_layout_defs.php');

class SubPanel
{
	var $hideNewButton = false;
	var $subpanel_id;
	var $parent_record_id;
	var $parent_module;  // the name of the parent module
	var $parent_bean;  // the instantiated bean of the parent
	var $template_file;
	var $linked_fields;
	var $action = 'DetailView';
	var $show_select_button = true;
	var $subpanel_define = null;  // contains the layout_def.php
	var $subpanel_data = array();

	function SubPanel($module, $record_id, $subpanel_id)
	{
		global $theme, $beanList, $beanFiles, $focus;
	
		$this->subpanel_id = $subpanel_id;
		$this->parent_record_id = $record_id; 
		$this->parent_module = $module; 

		$this->parent_bean =& $focus;
		$result =& $focus;

		if(empty($result))
		{
			$parent_bean_name = $beanList[$module];
			$parent_bean_file = $beanFiles[$parent_bean_name];
			require_once($parent_bean_file);
			$this->parent_bean =& new $parent_bean_name();
			$result =& $this->parent_bean->retrieve($this->parent_record_id);
		}
		
		if($record_id!='fab4' && $result == null)
		{
			sugar_die("Error retrieving record.  You may not be authorized to view this record.");
		}
		
		$this->subpanel_define = $this->getSubPanelDefine($module, $subpanel_id);
		
		$linked_fields = $this->parent_bean->get_linked_fields();
		$subpanel_data = array();
		foreach($this->subpanel_define['list_fields'] as $key => $value)
		{
			$lower_key = strtolower($key);
			$bean_name = $beanList[$key];

			if(empty($value['list_query_shortcut']))
			{
				if(empty($value['linked_field_key']))
				{
					$subpanel_data[$key] = $linked_fields[$lower_key];
				}
				else
				{
					$subpanel_data[$key] = $linked_fields[$value['linked_field_key']];
				}
			}
			else
			{
				$subpanel_data[$key] = array();
				$subpanel_data[$key]['list_query_shortcut'] = $value['list_query_shortcut'];
			}

			require_once($beanFiles[$bean_name]);//_ppd($linked_fields);
			$bean = new $bean_name();
			$bean->force_load_details = true;
			$subpanel_data[$key]['module'] = $key;
			$subpanel_data[$key]['list_fields'] = $value; 
			//add_type_attribute();
			$subpanel_data[$key]['focus'] = $bean;
		}
		
		$this->subpanel_data = $subpanel_data;
	}

	function setTemplateFile($template_file)
	{
		$this->template_file = $template_file;
	}
	
	function setBeanList(&$value){
		$this->bean_list =$value;
	}
	
	function setHideNewButton($value){
		$this->hideNewButton = $value;
	}
	
	
	function getHeaderText( $currentModule){
	}


	function ProcessSubPanelListView($xTemplatePath, &$mod_strings)
	{
		global $app_strings;
		global $image_path;
		global $current_user;
		global $sugar_config;
		
		$ListView = new ListView();
		$ListView->initNewXTemplate($xTemplatePath,$mod_strings);
		$ListView->xTemplateAssign("RETURN_URL", "&return_module=".$this->parent_module."&return_action=DetailView&return_id=".$this->parent_bean->id);
		$ListView->xTemplateAssign("RELATED_MODULE", $this->parent_module);  // TODO: what about unions?
		$ListView->xTemplateAssign("RECORD_ID", $this->parent_bean->id);
		$ListView->xTemplateAssign("EDIT_INLINE_PNG", get_image($image_path.'edit_inline','align="absmiddle" alt="'.$app_strings['LNK_EDIT'].'" border="0"'));
		$ListView->xTemplateAssign("DELETE_INLINE_PNG", get_image($image_path.'delete_inline','align="absmiddle" alt="'.$app_strings['LNK_DELETE'].'" border="0"'));
		$ListView->xTemplateAssign("REMOVE_INLINE_PNG", get_image($image_path.'delete_inline','align="absmiddle" alt="'.$app_strings['LNK_REMOVE'].'" border="0"'));
		$header_text= '';
	
		if(is_admin($current_user) && $_REQUEST['module'] != 'DynamicLayout' && !empty($_SESSION['editinplace']))
		{	
			$exploded = explode('/', $xTemplatePath);
			$file_name = $exploded[sizeof($exploded) - 1];
			$mod_name =  $exploded[sizeof($exploded) - 2];
			$header_text= "&nbsp;<a href='index.php?action=index&module=DynamicLayout&from_action=$file_name&from_module=$mod_name&mod_lang="
				.$_REQUEST['module']."'>".get_image($image_path."EditLayout","border='0' alt='Edit Layout' align='bottom'")."</a>";
		}
		$ListView->setHeaderTitle('');
		$ListView->setHeaderText('');

		ob_start();

		$ListView->is_dynamic = true;
		$ListView->records_per_page = $sugar_config['list_max_entries_per_subpanel'] + 0;
			$ListView->start_link_wrapper = "javascript:showSubPanel('".$this->subpanel_id."','";
			$ListView->subpanel_id = $this->subpanel_id;
			$ListView->end_link_wrapper = "',true);";
		if(!empty($_REQUEST['inline']))
		{
		}
		// TODO: have this handle the union
		//$ListView->loadListFieldDefs($this->subpanel_define['list_fields'], $this->subpanel_data);
		$where = '';
//		$ListView->setQuery($where, '', '', $this->child_field);
		$ListView->setQuery($where, '', '', '');
		$ListView->show_export_button = false;
		$ListView->process_dynamic_listview($this->subpanel_id, $this->parent_bean, $this->subpanel_data);
		$ob_contents = ob_get_contents();
		ob_end_clean();
		return $ob_contents;
	}

	function display()
	{
		$timedate = new TimeDate();
		global $mod_strings;
		global $app_strings;
		global $app_list_strings;
		global $gridline,$theme;
		global $beanList;
		global $beanFiles;
		global $current_language;
                                                                                                     
		require_once('themes/'.$theme.'/layout_utils.php');
		$image_path = 'themes/'.$theme.'/images/';

// TODO: uncomment when things are working.		
//		$local_mod_strings = return_module_language($current_language, $this->child_module_name);
//		$result_array = array_merge($mod_strings,$local_mod_strings);
		$result_array = array();
		$return_string = $this->ProcessSubPanelListView($this->template_file,$result_array);

		print $return_string;
	}
       
	function getModulesWithSubpanels()
	{
		global $beanList;
		$dir = dir('modules');
		$modules = array();
		while($entry = $dir->read())
		{
			if(file_exists('modules/' . $entry . '/layout_defs.php'))
			{
				$modules[$entry] = $entry;	
			}	
		}
		return $modules;
	}
  
  function getLinkedModules($module){
  		global $beanList, $beanFiles;
  		if(!isset($beanList[$module])){
  			return array();
  		}
  			
  		$class = $beanList[$module];
  		require_once($beanFiles[$class]);
  		$mod =& new $class();
  		return $mod->get_linked_fields();
  }
  
  //saves overrides for defs
  function saveSubPanelDefOverride($focus, $child_bean_name, $subsection, $override){
  		global $layout_defs, $beanList;
  		if(file_exists('modules/'. $focus->module_dir . '/layout_defs.php')){
  		
  				require('modules/'. $focus->module_dir . '/layout_defs.php');
  				$class = get_class($focus);
  				
  				
  				$section = 'custom_subpanel_defines';
  				$custom = true;
  				
  				$array = array();
  				if($custom){
  					$name = "layout_defs['$class']['$section']['$child_bean_name']['$subsection']";
  				}else{
  					$name = "layout_defs['$class']['$section']['$subsection']";	
  				}
  				mkdir_recursive('custom/Extension/modules/'. $focus->module_dir . '/Ext/LayoutDefs', true);
  				write_array_to_file( $name, $override, 'custom/Extension/modules/'. $focus->module_dir . "/Ext/LayoutDefs/$class.$section.$child_bean_name.$subsection.php" );
  				require_once('ModuleInstall/ModuleInstaller.php');
  				$moduleInstaller = new ModuleInstaller();
  				$moduleInstaller->merge_files('Ext/LayoutDefs/', 'layout_defs.override.php');
  				include('custom/modules/'. $focus->module_dir . '/Ext/LayoutDefs/layout_defs.override.php');	
  				
  		}
  		
  }
  
	function get_subpanel_setup($module)
	{
		$subpanel_setup = '';
		$layout_defs = get_layout_defs();
		
		if(!empty($layout_defs) && !empty($layout_defs[$module]['subpanel_setup']))
      {
      	$subpanel_setup = $layout_defs[$module]['subpanel_setup'];
      }
      
      return $subpanel_setup;
	}
  
	/**
	 * Retrieve the subpanel definition from the registered layout_defs arrays.
	 */
	function getSubPanelDefine($module, $subpanel_id)
	{
		$default_subpanel_define = SubPanel::_get_default_subpanel_define($module, $subpanel_id);
		$custom_subpanel_define = SubPanel::_get_custom_subpanel_define($module, $subpanel_id);

		$subpanel_define = array_merge($default_subpanel_define, $custom_subpanel_define);	
		
		if(empty($subpanel_define))
		{
			print('Could not load subpanel definition for: ' . $subpanel_id);
		}
		     
		return $subpanel_define;
	}

	function _get_custom_subpanel_define($module, $subpanel_id)
	{
		$ret_val = array();
		
		if($subpanel_id != '')
		{
			$layout_defs = get_layout_defs();
			
			if(!empty($layout_defs[$module]['custom_subpanel_defines'][$subpanel_id]))
			{
				$ret_val = $layout_defs[$module]['custom_subpanel_defines'][$subpanel_id];
			}
		}
		
		return $ret_val;
	}

	function _get_default_subpanel_define($module, $subpanel_id)
	{
		$ret_val = array();
		
		if($subpanel_id != '')
		{
	  		$layout_defs = get_layout_defs();

			if(!empty($layout_defs[$subpanel_id]['default_subpanel_define']))
			{
				$ret_val = $layout_defs[$subpanel_id]['default_subpanel_define'];
			}
		}
		
		return $ret_val;
	}
}
?>
