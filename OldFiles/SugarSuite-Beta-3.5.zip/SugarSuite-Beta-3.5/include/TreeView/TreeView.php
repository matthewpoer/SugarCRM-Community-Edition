<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: TreeView.php,v 1.2 2005/07/23 00:30:33 ajay Exp $
 * Description:  generic list view class.
 ********************************************************************************/
require_once('include/logging.php');

class TreeView {

var $seed_object;
var $exist_parent_id;
var $exist_node_id;
var $new_level;
var $max_depth;
var $walk_array;
var $disabled_flag;
var $disable_alert;

var $exist_parent_node_id;

	//var $tree_table = "category_tree";
	//var $category_table = "product_categories";		
	//var $product_table = "product_templates";
	//var $routing_table = "lead_routing_classes";
	//var $user_table = "users";
	//var $root_title;

	////////////////////configuration variables///////////////////////

	var $show_products = "true";				//show products when selecting a parent category
												//always show products otherwise
	var $tree_type;								//what is requesting the tree?

	

	///////////////////end configuration variables////////////////////

function TreeView($seed_object){
	
	$this->seed_object = $seed_object;
	$this->disable_alert = $this->seed_object->get_disable_alert();
	
if (file_exists('include/TreeView/treeview_override.php'))
{
	include('include/TreeView/treeview_override.php');
}


//end function TreeView
}

function init_tree($tree_type, $exist_parent_node_id="", $exist_node_id=""){

	global $theme;
	
	//General Declarations
	$image_path = 'themes/'.$theme.'/images/';
	$this->exist_parent_node_id = $exist_parent_node_id;
	$this->exist_node_id = "$exist_node_id";

	$this->tree_dir = "cache/Trees/";
	
	$this->tree_type = $tree_type;
	
//end function init_category_tree
}

function get_tree_script($tpl_file){

$tree_script = "	
			document.cookie = 'tree_' + 1 + '_state=;'
			document.cookie = 'tree_' + 1 + '_selected=;'
			var SPECIALTY_TREE = new tree (TREE_ITEMS, ".$tpl_file.", 1);
			
			function addhandler(o_item){
				return true;
				request_tree(o_item.n_uid);	
			}
			function request_tree(n_uid, dis_flag){
				document.request_tree_form.treeid.value=n_uid;
				document.request_tree_form.dis_flag.value=dis_flag;
				setTimeout('document.request_tree_form.submit()',100);
			}
			
			document.write('<iframe style=\"visibility:hidden;position:absolute;left:200px;top:-10px\" width=90 height=90 frameborder=\"0\" name=\"treeiframe\" id=\"treeiframe\" src=\"tree_level.php?parentid=0&tree_type={$this->tree_type}&root_id={$this->seed_object->root_id}&module={$this->seed_object->module_dir}\"></iframe>');
	";
	
	return $tree_script;

//end function get_tree_script
}


function get_tree($exist_parent_id="", $new_level="", $max_depth="", $disabled_flag="0",$parent_ids_array=array()){
	
	if($new_level==""){
		$this->new_level = "TREE_ITEMS";
	} else {
		$this->new_level = $new_level;	
	}
	
	$this->max_depth = $max_depth;
	$this->exist_parent_id = $exist_parent_id;
	$this->disabled_flag = $disabled_flag;
	$tree_contents = $this->grow_branches_and_leafs($parent_ids_array);

	return $tree_contents;
	
//end function get_category_tree_test
}

function grow_branches_and_leafs($parent_ids_array=array()){

	//generate branches and leafs

	//grow branches & leafs
	if(!isset($this->exist_parent_id)) $this->exist_parent_id = "";
	if(!isset($this->max_depth)) $this->max_depth = "1";
	$tree_contents = $this->traverse_tree($this->exist_parent_id, "", "0", $this->max_depth, $this->new_level,$parent_ids_array);

	//return the string with the branches and leafs
	return $tree_contents;

//end function grow_branches_and_leafs
}

function traverse_tree($parent_node_id, $flag="", $depth="", $max_depth="1", $var_name="",$parent_ids_array=array()){
if(!isset($parent_node_id)) $parent_node_id="";
	if ($depth == 0){
		if($parent_node_id=="") echo "var ".$var_name." = [ ['".$this->seed_object->branch_jscript_map[$this->tree_type]['tree_title']."', 0, {'fn':0, 'st':1}, \n"; //prepare JS var record
		if($parent_node_id!="") echo "var ".$var_name." = [ \n"; //prepare JS var record
	}	
	
	
	
  	//if this is the start of the growth, then set the initial tree contents
	if(!isset($tree_contents)) $tree_contents = "";
	
		$query = $this->seed_object->tree_query($parent_node_id,$parent_ids_array);	
		$result =$this->seed_object->db->query($query,true, "Error Traversing Tree");
		if($this->seed_object->db->getRowCount($result) > 0){
			
			// We have some branches and leafs (Categories and Products.
			while ($row = $this->seed_object->db->fetchByAssoc($result)) {
				
				if(!$var_name) $tree_contents .= ',';	//comma logic (JS var name is also comma flag)
				$var_name = 0;			//drop flag
				
				$node_id = $row['node_id'];				
				//check circular logic for CatCat
		   
				//add either category or product node information $childnode
				if($row['type']==$this->seed_object->branch_type){
					//defines how to show the node, as folder or not
					$folder = "1";
					$branch_name = $row['name'];
					
					$disable = $this->seed_object->branch_jscript_map[$this->tree_type]['disable'];
											
					if(isset($this->exist_node_id) && $this->exist_node_id==$node_id){
						$state = "1";
						$special_css = ", 's8':'selected'";
						$disable_flag = ", 'df':'0'";
					} else {
						$state = "0";
						$special_css = "";
						$disable_flag = ", 'df':'0'";
					}
					
					$javascript_url = $this->get_javascript_url("Branch", $branch_name, $node_id, $disable, $row['self_id']);

					
					
					
					//This will check for circular logic and overwrite previous settings
					
					
					//check to see if the disabled flag needs to be set to 0
					if(isset($this->disabled_flag)
					&& $this->disabled_flag=="1"
					&& $row['parent_node_id'] == $this->exist_parent_node_id){
					
						$this->disabled_flag = 0;
					}
					
					
					if(
						(isset($disable) && $disable=="Y" && $this->exist_node_id == $row['parent_node_id'])
						||
						(isset($this->disabled_flag) && $this->disabled_flag=="1")
						||
						(isset($disable) && $disable=="Y" && $this->exist_node_id == $node_id)
					){
						$special_css = ", 's0':'disabled', 's4':'disabled', 's8':'disabled', 's12':'disabled'";
						$disable_flag = ", 'df':'1'";
						$javascript_url = $this->disable_alert;
						
						//Set the disabled flag if this is a static pull
						if($max_depth=="99"){
							$this->disabled_flag = 1;
						}
					}

					$tree_contents .= "['".$branch_name."', \"$javascript_url\", {'id':$node_id, 'fn':$folder, 'st':$state $special_css $disable_flag} \n"; 
					
					if($folder=="1"){
						
						if($depth<$max_depth || isset($this->walk_array[$node_id])){
							$tree_contents .= $this->traverse_tree($node_id, $flag, $depth+1, $max_depth, $var_name);
						}
					}
					
					
				}
				if($row['type']==$this->seed_object->leaf_type){
					//defines how to show the node, as folder or not
					$disable = $this->seed_object->leaf_jscript_map[$this->tree_type]['disable'];
					$folder = "0";
					$leaf_name = $row['name'];
					$special_css = "";
					
					if(isset($this->exist_node_id) && $this->exist_node_id==$node_id){
						$special_css = ", 's0':'selected'";
					}
					
					
					$javascript_url = $this->get_javascript_url("Leaf", $leaf_name, $node_id, $disable, $row['self_id']);
									
					if(isset($disable) && $disable=="Y"){
						$special_css = ", 's0':'disabled', 's4':'disabled', 's8':'disabled', 's12':'disabled'";
						$javascript_url = "";
					}
					
					
					$tree_contents .= "['$leaf_name', \"$javascript_url\", {'id':$node_id, 'fn':$folder $special_css} \n"; 
				}
		
				$tree_contents .= "] \n"; //end item's record				
		
			//end while loop		
			}
		
		//end if there are rows
		}
		
			if($depth == 0){
			if($parent_node_id==""){
				$tree_contents .= "] \n ];"; //end JS var record
			}
			if($parent_node_id!=""){
				$tree_contents .= "];"; //end JS var record
			}
		}
		
  
return $tree_contents;
 
//end function traverse_tree 
}  

function get_javascript_url($type, $name, $node_id, $disable, $self_id){

	if($type=="Branch"){
		$str = $this->seed_object->branch_jscript_map[$this->tree_type]['function'];					

		eval("\$str = \"$str\";");
		return "$str";		
					
					
	//end if type is (branch)
	}
					
	if($type=="Leaf"){
					
		$str = $this->seed_object->leaf_jscript_map[$this->tree_type]['function'];
		
		eval("\$str = \"$str\";");
		return "$str";
		
	//end if type is (leaf)
	}
		
				
//end function get_javascript_url
}


function seal_walked_tree($tree){
	
	$sealed = "";

	foreach ($this->walk_array as $value){	
		if(isset($value) && $value!=0) $sealed .= "confirmopen (".$value.", ".$tree."); \n";
	//end foreach
	}
	
	return $sealed;
//end function seal_walked_tree
}

function walk_tree($node_id){
	
	unset($this->walk_array);
	$this->walk_array[$node_id] = $node_id;
	$this->walk_tree_recursive($node_id);
	$this->walk_array = array_reverse($this->walk_array, true);
	
//end function walk_tree	
}	


function walk_tree_recursive($node_id){
	
	$query = "select parent_node_id from ".$this->seed_object->tree_table." WHERE node_id='$node_id'";	
	$result =$this->seed_object->db->query($query,true, "Error Traversing Tree");
	
		if($this->seed_object->db->getRowCount($result) > 0){
		// We have some branches and leafs (Categories and Products.
	
		$row = $this->seed_object->db->fetchByAssoc($result);	
		
		$this->walk_array[$row['parent_node_id']] = $row['parent_node_id'];
	
			if(isset($row['parent_node_id']) && $row['parent_node_id']!=0 && $row['parent_node_id']!=""){
				
				$this->walk_tree_recursive($row['parent_node_id']);
			}

		//end if a row exists
		}	
		
//end function walk_tree_recursive
}



//////////////tree regrow function///////////////////////
//rebuilds tree after imports and if the tree breaks.  You can run this from the admin area

function regrow_tree($all, $part="1", $no_display=""){
	
//part 1 DELETE
	
if($part=="1" || $all=="Y"){
	
	//clear category_tree table
	$delete_query = "DELETE FROM ".$this->seed_object->tree_table."";
	$result =$this->seed_object->db->query($delete_query,true, "Regrowing Tree - Error: Failed to chop down tree");
	if(!empty($result) && empty($no_display)) echo "Success: Regrowing Tree - Chopped down tree<br>";


//end part 1
}	
	
	
//setup variables
$branchleaf_query = null;
$parent_node_query = null;

if($part=="2" || $all=="Y"){
	//select branches from branch table
	$select_query = "	SELECT ".$this->seed_object->branch_array['id']."
						FROM ".$this->seed_object->branch_array['table']."
						WHERE deleted='0'";

		$result =$this->seed_object->db->query($select_query,true, "Regrowing Tree - Error: Failed to select branches");
		if($this->seed_object->db->getRowCount($result) > 0){
			$row = $this->seed_object->db->fetchByAssoc($result);
			$branchleaf_query .= "	INSERT INTO ".$this->seed_object->tree_table."
									(self_id, type)
									VALUES ('".$row[$this->seed_object->branch_array['id']]."', '".$this->seed_object->branch_type."')";
		}

		if($this->seed_object->db->getRowCount($result) > 0)
		{
			// We have some branches
			while ($row = $this->seed_object->db->fetchByAssoc($result)) {

				$branchleaf_query .= ", ('".$row[$this->seed_object->branch_array['id']]."', '".$this->seed_object->branch_type."')";

			//end while
			}
		if(!empty($result) && empty($no_display)) echo "Success: Regrowing Tree - Selected Branches<br>";
		}
		
	//execute branchleaf query
	if(isset($branchleaf_query)){
		$result =$this->seed_object->db->query($branchleaf_query,true, "Regrowing Tree - Error: Failed to grow branches");
		if(!empty($result) && empty($no_display)) echo "Success: Regrowing Tree - Grew Branches and Leafs<br>";
	}
		
		
//end part 2
}

if($part=="3" || $all=="Y"){

//Only do part 3 if there are leafs in this tree
if(isset($this->seed_object->leaf_array)){
	
$branchleaf_query = null;	

	//select leafs from leaf tables
	$select_query = "	SELECT ".$this->seed_object->tree_table.".node_id AS parent_node_id,
						".$this->seed_object->leaf_array['table'].".".$this->seed_object->leaf_array['id']." AS id
						FROM ".$this->seed_object->leaf_array['table']."
						LEFT JOIN ".$this->seed_object->tree_table."
						ON ".$this->seed_object->leaf_array['table'].".".$this->seed_object->leaf_array['parent_field']."= ".$this->seed_object->tree_table.".self_id
						WHERE ".$this->seed_object->leaf_array['table'].".deleted='0'
					";

		$result =$this->seed_object->db->query($select_query,true, "Regrowing Tree - Error: Failed to select leafs");
		if($this->seed_object->db->getRowCount($result) > 0){
			$row = $this->seed_object->db->fetchByAssoc($result);
			if(!isset($branchleaf_query)) {
				$branchleaf_query .= "	INSERT INTO ".$this->seed_object->tree_table." (self_id, type, parent_node_id)
										VALUES ('".$row[$this->seed_object->leaf_array['id']]."', '".$this->seed_object->leaf_type."','".$row['parent_node_id']."')";
			} else {
				$branchleaf_query .= ", ('".$row[$this->seed_object->leaf_array['id']]."', '".$this->seed_object->leaf_type."','".$row['parent_node_id']."')";
			}	
		}
		
		
		if($this->seed_object->db->getRowCount($result) > 0)
		{
			// We have some leafs
			while ($row = $this->seed_object->db->fetchByAssoc($result)) {

				$branchleaf_query .= ", ('".$row[$this->seed_object->leaf_array['id']]."', '".$this->seed_object->leaf_type."','".$row['parent_node_id']."')";

			//end while
			}
		if(!empty($result) && empty($no_display)) echo "Success: Regrowing Tree - Selected Leafs<br>";
		}

	//execute branchleaf query
	if(isset($branchleaf_query)){
		$result =$this->seed_object->db->query($branchleaf_query,true, "Regrowing Tree - Error: Failed to grow leafs");
		if(!empty($result) && empty($no_display)) echo "Success: Regrowing Tree - Grew Branches and Leafs<br>";
	
	}
	

//end if to do part 3 if leafs are in this tree
}	
	
//end part 3
}

if($part=="4" || $all=="Y"){
	
	//update the category tree with the parent_node information
	

	//branch parent node information
	$select_query = "	SELECT ".$this->seed_object->tree_table.".node_id
						AS parent_node_id, ".$this->seed_object->branch_array['table'].".".$this->seed_object->branch_array['id']." AS id
						FROM ".$this->seed_object->branch_array['table']."
						LEFT JOIN ".$this->seed_object->tree_table."
						ON ".$this->seed_object->branch_array['table'].".".$this->seed_object->branch_array['parent_field']." = ".$this->seed_object->tree_table.".self_id
						WHERE ".$this->seed_object->branch_array['table'].".deleted='0'
					";		
					
	$result =$this->seed_object->db->query($select_query,true, "Regrowing Tree - Error: Failed to select branch parents");
		if($this->seed_object->db->getRowCount($result) > 0)
		{
			// We have some branches
			while ($row = $this->seed_object->db->fetchByAssoc($result)) {
				if($row['parent_node_id']==""){
					$parent_node_id = "0";
				} else {
					$parent_node_id = "$row[parent_node_id]";
				}
				$parent_node_query = "	UPDATE ".$this->seed_object->tree_table."
										SET parent_node_id='$parent_node_id'
										WHERE self_id='$row[id]' ";
				$result2 =$this->seed_object->db->query($parent_node_query,true, "Rebuilding Tree - Error: Building Parent Branches");
				
			//end while
			}
		if(!empty($result2) && empty($no_display)) echo "Success: Regrowing Tree - Growing Parent Branches...<br>";
		}
		
		if(!empty($result2) && empty($no_display)) echo "Success: Regrowing Tree - Finished Growing Tree<br>";

	 	if( empty($no_display)) echo "Success: Tree Process Finished<br><BR>";
		

//end part 4
}

return $part;
	 
//end function regrow_category_tree
}

function upgrade_tree(){
		require_once('include/database/PearDatabase.php');
		$db = new PearDatabase();

      $result = $db->query("DROP TABLE IF EXISTS ".$this->seed_object->tree_table."",true, "Chopping Tree - Error: Dropping Table");

         $query = $this->seed_object->create_tree_query();
		 $db->query($query,true,"Error creating table: ".$this->seed_object->tree_table."");
         return 1;

///end function upgrade_tree
}


//end class TreeView
}

?>
