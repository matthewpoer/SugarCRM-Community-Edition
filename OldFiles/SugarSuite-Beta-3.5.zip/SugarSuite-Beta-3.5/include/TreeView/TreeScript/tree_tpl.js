/*
	Feel free to use your custom icons for the tree. Make sure they are all of the same size.
	If you don't use some keys you can just remove them from this config
*/

var TREE_TPL = {

	// general
	'target':'_self',	// name of the frame links will be opened in
							// other possible values are:
							// _blank, _parent, _search, _self and _top
	// icons - root	
	'icon_48':'include/TreeView/TreeScript/icons/folder.gif',   // root icon normal
	'icon_52':'include/TreeView/TreeScript/icons/folder.gif',   // root icon selected
	'icon_56':'include/TreeView/TreeScript/icons/folder.gif',   // root icon opened
	'icon_60':'include/TreeView/TreeScript/icons/folder.gif',   // root icon selected opened

	// icons - node	
	'icon_16':'include/TreeView/TreeScript/icons/folder.gif', // node icon normal
	'icon_20':'include/TreeView/TreeScript/icons/folderopen.gif', // node icon selected
	'icon_24':'include/TreeView/TreeScript/icons/folderopen.gif', // node icon opened
	'icon_28':'include/TreeView/TreeScript/icons/folderopen.gif', // node icon selected opened

	'icon_80':'include/TreeView/TreeScript/icons/folderover.gif', // mouseovered node icon normal
	'icon_88':'include/TreeView/TreeScript/icons/folderopenover.gif',

	// icons - leaf
	'icon_0':'include/TreeView/TreeScript/icons/page.gif', // leaf icon normal
	'icon_4':'include/TreeView/TreeScript/icons/pagesel.gif', // leaf icon selected
	'icon_64':'include/TreeView/TreeScript/icons/pagesel.gif', // leaf icon selected
	
	// icons - junctions	
	'icon_2':'include/TreeView/TreeScript/icons/joinbottom.gif', // junction for leaf
	'icon_3':'include/TreeView/TreeScript/icons/join.gif',       // junction for last leaf
	'icon_18':'include/TreeView/TreeScript/icons/plusbottom.gif', // junction for closed node
	'icon_19':'include/TreeView/TreeScript/icons/plus.gif',       // junctioin for last closed node
	'icon_26':'include/TreeView/TreeScript/icons/minusbottom.gif',// junction for opened node
	'icon_27':'include/TreeView/TreeScript/icons/minus.gif',      // junctioin for last opended node

	// icons - misc
	'icon_e':'include/TreeView/TreeScript/icons/empty.gif', // empty image
	'icon_l':'include/TreeView/TreeScript/icons/line.gif',  // vertical line
	
	// styles - root
	'style_48':'mout', // normal root caption style
	'style_52':'mout', // selected root catption style
	'style_56':'mout', // opened root catption style
	'style_60':'mout', // selected opened root catption style
	'style_112':'mover', // mouseovered normal root caption style
	'style_116':'mover', // mouseovered selected root catption style
	'style_120':'mover', // mouseovered opened root catption style
	'style_124':'mover', // mouseovered selected opened root catption style
	
	// styles - node
	'style_16':'t0ic', // normal node caption style
	'style_20':'t0ic', // selected node catption style
	'style_24':'t0ic', // opened node catption style
	'style_28':'t0ic', // selected opened node catption style
	'style_80':'t0io', // mouseovered normal node caption style
	'style_84':'t0io', // mouseovered selected node catption style
	'style_88':'t0io', // mouseovered opened node catption style
	'style_92':'t0io', // mouseovered selected opened node catption style

	// styles - leaf
	'style_0':'t1io', // normal leaf caption style
	'style_4':'t1io', // selected leaf catption style
	'style_64':'t1ic', // mouseovered normal leaf caption style
	'style_68':'t1ic', // mouseovered selected leaf catption style
	'onItemOpen':'request_level'
	
	// make sure there is no comma after the last key-value pair
};
