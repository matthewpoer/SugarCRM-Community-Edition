
function request_level(o_item){	

	if (!B_DOM) return true;
	if(o_item.b_complete) return true;

//	window.alert('depth='+o_item.n_depth);
	var parents = new Array();
	
	if (o_item.n_depth >  0 ) {
		var currentitem=o_item;		
		do {
			//window.alert(currentitem.a_config[2]['id']);
			parents.push(currentitem.a_config[2]['id']);					
		
			//make parent the current item.
			currentitem=currentitem.o_parent;
		} while ((currentitem != null) && currentitem.n_depth > 0)
	} 

	if(!B_REQUEST){
	    B_ACTIVE = false;
		O_FRAME.request_level(o_item.o_root.n_id,o_item.a_config[2]['id'], o_item.a_config[2]['df'], parents);
		WARCH_DOG_TIMER = setTimeout('reset_tree('+o_item.o_root.n_id+');',5000);
		B_REQUEST = true;
	}
}

function frameok (o_frame){
		if(!o_frame) return;		
		if(!O_FRAME) O_FRAME = o_frame;	
		
		if(!B_ACTIVE && B_REQUEST && o_frame.window.parentid && o_frame.window.treeid && o_frame.window.new_level && o_frame.window.new_level.length) {
			var o_tree = TREES[o_frame.window.treeid];
			var o_level = o_frame.window.new_level;
			
			if(!o_tree) return;

			var a_parent = o_tree.find_item_by_key('id', o_frame.window.parentid);
			
			if(a_parent[0] && !a_parent[0].b_complete) {
				for(var j=0;j<o_level.length;j++)
				a_parent[0].add(o_level[j]);
				a_parent[0].b_complete = true;
				a_parent[0].open();
			}
		}
		//O_FRAME.window.history.back();
		reset_tree();
	};

function reset_tree(){
	if(WARCH_DOG_TIMER) clearTimeout(WARCH_DOG_TIMER);
	WARCH_DOG_TIMER = 0;
	B_ACTIVE = true;
	B_REQUEST = false;
}

O_FRAME = null;
WARCH_DOG_TIMER = 0;
B_ACTIVE = true;
B_REQUEST = false;

function expand_all (n_index, n_depth) {
	var o_tree = TREES[n_index ? n_index : 0];
	if (!o_tree)
		alert("Tree is not initialized yet");
	var a_nodes = o_tree.a_nodes;
	for (var i = 0; i< a_nodes.length; i++)
		if (n_depth == null || a_nodes[i].n_depth <= n_depth)
			a_nodes[i].open(0, 1);
	o_tree.ndom_refresh();
}

/* collapses nodes of the tree
	n_index - zero based index of the tree on the pate
                  if omited then applied to first tree (n_index==0)
	n_depth - zero based level to which the tree with be collapsed
	          if omitted the tree will collapsed to second level (n_depth==1)
 */
function collapse_all (n_index, n_depth) {
	var o_tree = TREES[n_index ? n_index : 0];
	if (!n_depth) n_depth = 1;
	if (!o_tree)
		alert("Tree is not initialized yet");
	var a_nodes = o_tree.a_nodes;
	for (var i = a_nodes.length - 1; i >= 0; i--)
		if (a_nodes[i].n_depth >= n_depth && a_nodes[i].open)
			a_nodes[i].open(1, 1);
	o_tree.ndom_refresh();
}

function confirmopen (id, o_tree){
	
var a_parent = o_tree.find_item_by_key('id', id);
a_parent[0].b_complete = true;
a_parent[0].open();
}	


function openItemById (id, o_tree) {
    // find item with specified caption

    var a_item = o_tree.find_item_by_key('id', id);

    for(var n=0; n < a_item.length; n++) {
	o_item=a_item[n];
	// collect info about all item's parents
	var n_id = o_item.n_id,
		n_depth = o_item.n_depth,
		a_index = o_item.o_root.a_index,
		a_parents = [o_item];

	while (n_depth) {
		if (a_index[n_id].n_depth < n_depth) {
			a_parents[a_parents.length] = a_index[n_id];
			n_depth--;
		}
		n_id--;
	}
		
	// open all parents starting from root
	for (var i = a_parents.length-1; i >= 0; i--){
	   // check if node or root
	   if (a_parents[i].n_state & 48){
	      a_parents[i].open();
	   }
    
	//end for
	}
	
	}
}

function expand_all (n_index, n_depth) {
	var o_tree = TREES[n_index ? n_index : 0];
	if (!o_tree)
		alert("Tree is not initialized yet");
	var a_nodes = o_tree.a_nodes;
	for (var i = 0; i< a_nodes.length; i++)
		if (n_depth == null || a_nodes[i].n_depth <= n_depth)
			a_nodes[i].open(0, 1);
	o_tree.ndom_refresh();
}
