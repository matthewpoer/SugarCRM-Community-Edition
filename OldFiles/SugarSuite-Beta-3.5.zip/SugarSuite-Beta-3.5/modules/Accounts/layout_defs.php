<?php
/**
 * Layout definition for Accounts
 *
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */

// $Id: layout_defs.php,v 1.35 2005/08/01 02:08:53 ajay Exp $

$layout_defs['Accounts'] = array(
	// list of what Subpanels to show in the DetailView 
	'subpanel_setup' => array(
		array(
			'source_module' => 'Activities',
			'default_allow' => true,
		),
		array(
			'source_module' => 'History',
			'default_allow' => true,
		),
		array(
			'source_module' => 'Contacts',
		),
		array(
			'source_module' => 'Opportunities',
		),
		array(
			'source_module' => 'Leads',
		),
		array(
			'source_module' => 'Cases',
		),
		array(
			'source_module' => 'Products',
		),
		array(
			'source_module' => 'Quotes',
		),
		array(
			'source_module' => 'Accounts',
		),
		array(
			'source_module' => 'Bugs',
		),
		array(
			'source_module' => 'Project',
		),
	),
	// default subpanel provided by this SugarBean
	'default_subpanel_define' => array(
		'subpanel_title' => 'LBL_DEFAULT_SUBPANEL_TITLE',
		'top_buttons' => array(
			array('widget_class' => 'SubPanelTopCreateButton'),
			array('widget_class' => 'SubPanelTopSelectButton', 'popup_module' => 'Accounts'),
		),
		'list_fields' => array(
			'Accounts' => array(
				'linked_field_key' => 'accounts',
				'columns' => array(
					array(
			 		 	'name' => 'name',
			 		 	'vname' => 'LBL_LIST_ACCOUNT_NAME',
						'widget_class' => 'SubPanelDetailViewLink',
						'width' => '45%',
					),
					array(
			 		 	'name' => 'billing_address_city',
			 		 	'vname' => 'LBL_LIST_CITY',
						'width' => '27%',
					),
					array(
			 		 	'name' => 'phone_office',
			 		 	'vname' => 'LBL_LIST_PHONE',
						'width' => '20%',
					),
					array(
			 		 	'name' => 'nothing',
						'widget_class' => 'SubPanelEditButton',
			 		 	'module' => 'Accounts',
						'width' => '4%',
					),
					array(
			 		 	'name' => 'nothing',
						'widget_class' => 'SubPanelRemoveButton',
						'linked_field' => 'accounts',
			 		 	'module' => 'Accounts',
						'width' => '4%',
					),
				),
				'where' => '',
				'order_by' => 'tasks.date_start',
			),
		),
	),
	'custom_subpanel_defines' => array(
		'Accounts' => array(
			'subpanel_title' => 'LBL_MEMBER_ORG_FORM_TITLE',
			'top_buttons' => array(
				array('widget_class' => 'SubPanelTopCreateButton'),
				array('widget_class' => 'SubPanelTopSelectButton', 'popup_module' => 'Accounts'),
			),
			'list_fields' => array(
				'Accounts' => array(
					'linked_field_key' => 'members',
					'columns' => array(
						array(
				 		 	'name' => 'name',
				 		 	'vname' => 'LBL_LIST_ACCOUNT_NAME',
							'widget_class' => 'SubPanelDetailViewLink',
							'width' => '45%',
						),
						array(
				 		 	'name' => 'billing_address_city',
				 		 	'vname' => 'LBL_LIST_CITY',
							'width' => '27%',
						),
						array(
				 		 	'name' => 'phone_office',
				 		 	'vname' => 'LBL_LIST_PHONE',
							'width' => '20%',
						),
						array(
				 		 	'name' => 'nothing',
							'widget_class' => 'SubPanelEditButton',
				 		 	'module' => 'Accounts',
							'width' => '4%',
						),
						array(
				 		 	'name' => 'nothing',
							'widget_class' => 'SubPanelRemoveButton',
							'linked_field' => 'accounts',
				 		 	'module' => 'Accounts',
							'width' => '4%',
						),
					),
					'where' => '',
					'order_by' => 'tasks.date_start',
				),
			),
		),
		'Products' => array(
			'subpanel_title' => 'LBL_PRODUCTS_TITLE',
			'top_buttons' => array(
				array('widget_class' => 'SubPanelTopCreateButton'),
				array('widget_class' => 'SubPanelTopSelectButton', 'popup_module' => 'Products'),
			),
		'list_fields' => array(
			'Products' => array(
				'list_query_shortcut' => 'get_products_query',
				'columns' => array(
					array(
		 		 		'name' => 'status',
		 		 		'vname' => 'LBL_LIST_STATUS',
						'width' => '8%',
					),
					array(
		 		 		'name' => 'name',
		 		 		'vname' => 'LBL_LIST_NAME',
						'widget_class' => 'SubPanelDetailViewLink',
						'width' => '28%',
					),					
					array(
		 		 		'name' => 'account_name',
		 		 		'vname' => 'LBL_LIST_ACCOUNT_NAME',
						'widget_class' => 'SubPanelDetailViewLink',
			 		 	'target_record_key' => 'account_id',
			 		 	'target_module' => 'Accounts',
		 		 		'module' => 'Accounts',
						'width' => '15%',
					),
					array(
		 		 		'name' => 'contact_name',
		 		 		'vname' => 'LBL_LIST_CONTACT_NAME',
						'widget_class' => 'SubPanelDetailViewLink',
			 		 	'target_record_key' => 'contact_id',
			 		 	'target_module' => 'Contacts',
		 		 		'module' => 'Contacts',
						'width' => '15%',
					),
					array(
		 		 		'name' => 'date_purchased',
		 		 		'vname' => 'LBL_LIST_DATE_PURCHASED',
						'width' => '10%',
					),
					array(
		 		 		'name' => 'discount_price',
		 		 		'vname' => 'LBL_LIST_DISCOUNT_PRICE',
						'width' => '10%',
					),					
					array(
		 		 		'name' => 'date_support_expires',
		 		 		'vname' => 'LBL_LIST_SUPPORT_EXPIRES',
						'width' => '10%',
					),					
					array(
			 		 	'name' => 'nothing',
						'widget_class' => 'SubPanelEditButton',
			 		 	'module' => 'Products',
		 		 		'width' => '4%',
					),
				),
			),
		),			
	  ),
      'Contacts' => array(
      		'subpanel_title' => 'LBL_DEFAULT_SUBPANEL_TITLE',
		'top_buttons' => array(
			array('widget_class' => 'SubPanelTopCreateContactAccountButton'),
			array('widget_class' => 'SubPanelTopSelectButton', 'popup_module' => 'Contacts'),
		),
		'list_fields' => array(
			'Contacts' => array(
				'columns' => array(
					array(
						'name' => 'first_name',
			 		 	'usage' => 'query_only',
					),
					array(
						'name' => 'last_name',
			 		 	'usage' => 'query_only',
					),
					array(
						'name' => 'name',
						'vname' => 'LBL_LIST_NAME',
						'widget_class' => 'SubPanelDetailViewLink',
			 		 	'module' => 'Contacts',
		 		 		'width' => '23%',
					),
					array(
			 		 	'name' => 'account_name',
			 		 	'module' => 'Accounts',
			 		 	'target_record_key' => 'account_id',
			 		 	'target_module' => 'Accounts',
						'widget_class' => 'SubPanelDetailViewLink',
			 		 	'vname' => 'LBL_LIST_ACCOUNT_NAME',
		 		 		'width' => '22%',
					),
					array(
						'name'=>'email1',
						'vname' => 'LBL_LIST_EMAIL',
						'widget_class' => 'SubPanelEmailLink',
		 		 		'width' => '30%',
					),
					array (
						'name' => 'phone_home',
						'vname' => 'LBL_LIST_PHONE',
		 		 		'width' => '15%',
					),
					array(
			 		 	'name' => 'nothing',
						'widget_class' => 'SubPanelEditButton',
			 		 	'module' => 'Contacts',
		 		 		'width' => '5%',
					),
					array(
			 		 	'name' => 'nothing',
						'widget_class' => 'SubPanelRemoveButton',
						'linked_field' => 'contacts',
			 		 	'module' => 'Contacts',
		 		 		'width' => '5%',
					),
				),
			),
		),
        ),
   ),
);
?>
