<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.2 2004/10/29 15:59:25 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Saker',
  'LBL_MODULE_TITLE' => 'Sak : Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'S&oslash;k Saker',
  'LBL_LIST_FORM_TITLE' => 'Saksliste',
  'LBL_NEW_FORM_TITLE' => 'Ny Sak',
  'LBL_CONTACT_CASE_TITLE' => 'Kontakt-Sak:',
  'LBL_SUBJECT' => 'Sak:',
  'LBL_CASE' => 'Sak:',
  'LBL_CASE_NUMBER' => 'Casenummer:',
  'LBL_NUMBER' => 'Nummer:',
  'LBL_STATUS' => 'Status:',
  'LBL_PRIORITY' => 'Priority:',
  'LBL_ACCOUNT_NAME' => 'Virksomhet:',
  'LBL_DESCRIPTION' => 'Beskrivelse:',
  'LBL_CONTACT_NAME' => 'Kontakt Navn:',
  'LBL_CASE_SUBJECT' => 'Sak overskrift:',
  'LBL_CONTACT_ROLE' => 'Rolle:',
  'LBL_LIST_NUMBER' => 'Num.',
  'LBL_LIST_SUBJECT' => 'Rubrik',
  'LBL_LIST_ACCOUNT_NAME' => 'Virksomhet',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_LIST_PRIORITY' => 'Priority',
  'LBL_LIST_LAST_MODIFIED' => 'Sist Oppdatert',
  'LBL_INVITEE' => 'Kontakter',
  'LNK_NEW_CASE' => 'Ny Sak',
  'LNK_CASE_LIST' => 'Cases',
  'NTC_REMOVE_INVITEE' => 'Er du sikker p&aring; &aring; slette denne Kontakten fra saken?',
  'ERR_DELETE_RECORD' => 'Et Postnummer skal oppgis for &aring; slette Virksomheten.',
  'LNK_NEW_CONTACT' => 'Ny Kontakt',
  'LNK_NEW_ACCOUNT' => 'Ny Virksomhet',
  'LNK_NEW_OPPORTUNITY' => 'Ny Salgs Mulighet',
  'LNK_NEW_NOTE' => 'Nytt Notat',
  'LNK_NEW_CALL' => 'Ny Samtale',
  'LNK_NEW_EMAIL' => 'Ny Epost',
  'LNK_NEW_MEETING' => 'Nytt M&oslash;te',
  'LNK_NEW_TASK' => 'Ny Oppgave',
);


?>