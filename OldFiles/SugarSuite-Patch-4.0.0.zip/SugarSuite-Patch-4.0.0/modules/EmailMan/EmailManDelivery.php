<?PHP
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
require_once('modules/EmailMan/EmailMan.php');
require_once('modules/Users/User.php');
require_once('include/phpmailer/class.phpmailer.php');
require_once("modules/Administration/Administration.php");
if (isset($_REQUEST['send_all']) && $_REQUEST['send_all']== true) {
	$send_all= true;
}
else  {
	$send_all=false; //if set to true email delivery will continue..to run until all email have been delivered.
}
$mail = new PHPMailer();
$admin = new Administration();
$admin->retrieveSettings();
if (isset($admin->settings['massemailer_campaign_emails_per_run'])) {
	$max_emails_per_run=$admin->settings['massemailer_campaign_emails_per_run'];
}
if (empty($max_emails_per_run)) {
	$max_emails_per_run=500;//default
}

$emailsPerSecond = 10;
if ($admin->settings['mail_sendtype'] == "SMTP") {
	$mail->Host = $admin->settings['mail_smtpserver'];
	$mail->Port = $admin->settings['mail_smtpport'];	
	

	if ($admin->settings['mail_smtpauth_req']) {
		$mail->SMTPAuth = TRUE;
		$mail->Username = $admin->settings['mail_smtpuser'];
		$mail->Password = $admin->settings['mail_smtppass'];
	}
	$mail->Mailer   = "smtp";
	$mail->SMTPKeepAlive = true;
} else {
	$mail->mailer='sendmail'; 
}

$mail->From     = "no-reply@example.com";
$mail->FromName = "no-reply";

$campaign_id=null;
if (isset($_REQUEST['campaign_id']) && !empty($_REQUEST['campaign_id'])) {
	$campaign_id=$_REQUEST['campaign_id'];
}

$db = & PearDatabase::getInstance();
$emailman = new EmailMan();

$select_query =" SELECT *";
$select_query.=" FROM $emailman->table_name";
$select_query.=" WHERE send_date_time <= '". gmdate('Y-m-d H:i:s') . "'";
$select_query.=" AND (in_queue ='0' OR ( in_queue ='1' AND in_queue_date <= '" .gmdate('Y-m-d H:i:s', strtotime("-1 day"))."'))"; 
if (!empty($campaign_id)) {
	$select_query.=" AND campaign_id='{$campaign_id}'";
}
$select_query.=" ORDER BY user_id, list_id";

do {
	$no_items_in_queue=true;	
	
	$result = $db->limitQuery($select_query,0,$max_emails_per_run);
	
	if(isset($current_user)){
		$temp_user = $current_user;
	}	
	$current_user = new User();
	$startTime = microtime();
	
	while($row = $db->fetchByAssoc($result)){
		$no_items_in_queue=false;	
		
		//fetch user that scheduled the campaign.
		if($row['user_id'] != $current_user->id){
			$current_user->retrieve($row['user_id']);
		}
	
		foreach($row as $name=>$value){
			$emailman->$name = $value;
		}
	
		if(!$emailman->sendEmail($mail)){
			emaillog("FAILURE:");		
		} else {
		 	emaillog("SUCCESS:");	
		 }
	
		emaillog($emailman->toString());
		if($mail->isError()){
			emaillog($mail->ErrorInfo);
		 }
	}

	$send_all=$send_all?!$no_items_in_queue:$send_all;
	
}while ($send_all == true);


if ($admin->settings['mail_sendtype'] == "SMTP") {
	$mail->SMTPClose();
}
if(isset($temp_user)){
	$current_user = $temp_user;	
}

if (isset($_REQUEST['return_module']) && isset($_REQUEST['return_action']) && isset($_REQUEST['return_id'])) {
		header("Location: index.php?module={$_REQUEST['return_module']}&action={$_REQUEST['return_action']}&record={$_REQUEST['return_id']}"); 	
} else {
	/* this will be triggered when manually sending off Email campaigns from the
	 * Mass Email Queue Manager.
 	*/
	if(isset($_POST['manual'])) {
		header("Location: index.php?module=EmailMan&action=index"); 
	}
}
function emaillog($text){
	if(!empty($_REQUEST['verbose'])){
		echo $text . '<br>';
	}
	$GLOBALS['log']->info($text);
}
?>
