<?PHP

include_once('config.php');
require_once('log4php/LoggerManager.php');
require_once('include/database/PearDatabase.php');
require_once('modules/Users/User.php');
require_once('include/modules.php');
require_once('include/utils.php');

clean_special_arguments();
if (!empty($_REQUEST['remove'])) clean_string($_REQUEST['remove'], "STANDARD");
if (!empty($_REQUEST['from'])) clean_string($_REQUEST['from'], "STANDARD");

require_once('modules/ACL/ACLController.php');
require_once('modules/Campaigns/utils.php');
$GLOBALS['log'] = LoggerManager::getLogger('removeme');
if(!empty($_REQUEST['identifier'])) {

	$keys=log_campaign_activity($_REQUEST['identifier'],'removed');
	if (!empty($keys)) {

		$id = $keys['target_id'];
		$module = trim($keys['target_type']);
		$class = $beanList[$module];
		require_once($beanFiles[$class]);
		$mod = new $class();
		$db = & PearDatabase::getInstance();

		$id = $db->quote($id);
		//no opt out for users.
		if(ereg('^[0-9A-Za-z\-]*$', $id) && $module != 'Users'){
			$query = "UPDATE $mod->table_name SET email_opt_out='on' WHERE id ='$id'";
			$status=$db->query($query);
			if($status){
				echo "*";
			}
		}
		//	record this activity in the campaing log table..
		echo "You have elected to opt out and to no longer receive emails.";
	}
}
sugar_cleanup();
?>
