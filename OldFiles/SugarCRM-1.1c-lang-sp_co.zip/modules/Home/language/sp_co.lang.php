<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Hernan Lopez M - hsoft@ati-ltda.com
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Home/language/sp_ve.lang.php,v 1.7 2004/08/29 13:18:25 stratofun Exp $
 * Description:  Defines the Spanish language pack
 ********************************************************************************/

$mod_strings = Array(
'LBL_NEW_FORM_TITLE'=>'Nuevo Contacto',
'LBL_FIRST_NAME'=>'Nombre:',
'LBL_LAST_NAME'=>'Apellido:',
'LBL_LIST_LAST_NAME'=>'Apellido',
'LBL_PHONE'=>'Tel�fono:',
'LBL_EMAIL_ADDRESS'=>'Email:',

'LBL_PIPELINE_FORM_TITLE'=>'Mi Portafolio',
'LBL_TOTAL_PIPELINE'=>'Total Portafolio es ',
'LBL_OPP_SIZE'=>'Tama�o Oportunidad en $x1.000',

'LNK_NEW_CONTACT'=>'Nuevo Contacto',
'LNK_NEW_ACCOUNT'=>'Nueva Cuenta',
'LNK_NEW_OPPORTUNITY'=>'Nueva Oportunidad',
'LNK_NEW_CASE'=>'Nuevo Caso',
'LNK_NEW_NOTE'=>'Nueva Nota',
'LNK_NEW_CALL'=>'Nueva Llamada',
'LNK_NEW_EMAIL'=>'Nuevo Email',
'LNK_NEW_MEETING'=>'Nueva Reuni�n',
'LNK_NEW_TASK'=>'Nueva Tarea',

'ERR_ONE_CHAR'=>'Por favor indique al menos un n�mero o letra para su b�squeda ...',

'LBL_OPEN_TASKS'=>'Mis Tareas Pendientes',
);

?>