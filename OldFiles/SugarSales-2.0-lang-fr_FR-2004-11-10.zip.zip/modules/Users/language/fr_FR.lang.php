<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/modules/Accounts/Account.php,v 1.92 2004/11/10 22:27:36 clint Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Utilisateurs',
  'LBL_MODULE_TITLE' => 'Utilisateurs: Accueil',
  'LBL_SEARCH_FORM_TITLE' => 'Recherche d\'Utilisateurs',
  'LBL_LIST_FORM_TITLE' => 'liste des Utilisateurs',
  'LBL_NEW_FORM_TITLE' => 'Nouvel Utilisateur',
  'LBL_USER' => 'Utilisateurs:',
  'LBL_LOGIN' => 'Login',
  'LBL_RESET_PREFERENCES' => 'R�initialiser les pr�f�rences par d�faut',
  'LBL_TIME_FORMAT' => 'Time Format:',
  'LBL_CURRENCY' => 'Currency:',
  'LBL_LIST_NAME' => 'Nom',
  'LBL_LIST_LAST_NAME' => 'Nom',
  'LBL_LIST_USER_NAME' => 'Nom d\'utilisateur',
  'LBL_LIST_DEPARTMENT' => 'Division',
  'LBL_LIST_EMAIL' => 'Email',
  'LBL_LIST_PRIMARY_PHONE' => 'T�l�phone principal',
  'LBL_LIST_ADMIN' => 'Admin',
  'LBL_NEW_USER_BUTTON_TITLE' => 'Nouvel Utilisateur [Alt+N]',
  'LBL_NEW_USER_BUTTON_LABEL' => 'Nouvel Utilisateur',
  'LBL_NEW_USER_BUTTON_KEY' => 'N',
  'LBL_ERROR' => 'Erreure:',
  'LBL_PASSWORD' => 'Mot de passe:',
  'LBL_USER_NAME' => 'Nom d\'utilisateur:',
  'LBL_FIRST_NAME' => 'Pr�nom:',
  'LBL_LAST_NAME' => 'Nom:',
  'LBL_USER_SETTINGS' => 'param�tres utilisateur',
  'LBL_THEME' => 'Theme:',
  'LBL_LANGUAGE' => 'Langue:',
  'LBL_ADMIN' => 'Admin:',
  'LBL_USER_INFORMATION' => 'informations utilisateur',
  'LBL_OFFICE_PHONE' => 'T�l�phone bureau:',
  'LBL_REPORTS_TO' => 'Rend compte �:',
  'LBL_OTHER_PHONE' => 'Autre:',
  'LBL_OTHER_EMAIL' => 'Autre Email:',
  'LBL_NOTES' => 'Notes:',
  'LBL_DEPARTMENT' => 'D�partement:',
  'LBL_STATUS' => 'Statut:',
  'LBL_TITLE' => 'Civilit�:',
  'LBL_ANY_PHONE' => 'T�l�phne alternatif:',
  'LBL_ANY_EMAIL' => 'Email alternatif:',
  'LBL_ADDRESS' => 'Adresse:',
  'LBL_CITY' => 'Ville:',
  'LBL_STATE' => 'State:',
  'LBL_POSTAL_CODE' => 'Code Postal:',
  'LBL_COUNTRY' => 'Pays:',
  'LBL_NAME' => 'Nom:',
  'LBL_MOBILE_PHONE' => 'T�l�phone portable:',
  'LBL_OTHER' => 'Autre:',
  'LBL_FAX' => 'Fax:',
  'LBL_EMAIL' => 'Email:',
  'LBL_HOME_PHONE' => 'T�l�phone personnel:',
  'LBL_ADDRESS_INFORMATION' => 'Informations sur l\'adresse',
  'LBL_PRIMARY_ADDRESS' => 'Adresse principale:',
  'LBL_CHANGE_PASSWORD_BUTTON_TITLE' => 'Changer le mot de passe [Alt+P]',
  'LBL_CHANGE_PASSWORD_BUTTON_KEY' => 'P',
  'LBL_CHANGE_PASSWORD_BUTTON_LABEL' => 'Changer le mot de passe',
  'LBL_LOGIN_BUTTON_TITLE' => 'Login [Alt+L]',
  'LBL_LOGIN_BUTTON_KEY' => 'L',
  'LBL_LOGIN_BUTTON_LABEL' => 'Login',
  'LBL_CHANGE_PASSWORD' => 'Changer le mot de passe',
  'LBL_OLD_PASSWORD' => 'Ancien mot de passe:',
  'LBL_NEW_PASSWORD' => 'Nouveau mot de passe:',
  'LBL_CONFIRM_PASSWORD' => 'Confirmation mot de passe:',
  'ERR_ENTER_OLD_PASSWORD' => 'Merci de saisir votre ancien mot de passe.',
  'ERR_ENTER_NEW_PASSWORD' => 'Merci de saisir votre nouveau mot de passe.',
  'ERR_ENTER_CONFIRMATION_PASSWORD' => 'Merci de confirmer votre nouveau mot de passe.',
  'ERR_REENTER_PASSWORDS' => 'Merci de resaisir vos mots de passe.  Le \\"nouveau mot de passe\\" et \\"ancien mot de passe\\" ne correspondent pas.',
  'ERR_INVALID_PASSWORD' => 'Vous devez sp�cifier un nom d\'utilisateur et un mot de passe valides.',
  'ERR_PASSWORD_CHANGE_FAILED_1' => 'Echec du changement du mot de passe utilisateur pour ',
  'ERR_PASSWORD_CHANGE_FAILED_2' => ' Echou�.  Le nouveau mot de passe doit �tre renseign�.',
  'ERR_PASSWORD_INCORRECT_OLD' => 'Ancien mot de passe incorrecte pour le login $this->user_name. Merci de resaisir les informations de mot de passe.',
  'ERR_USER_NAME_EXISTS_1' => 'Le Login ',
  'ERR_USER_NAME_EXISTS_2' => ' existe d�j�.  La duplication de Login est interdite.<br>Merci de changer de Login.',
  'ERR_LAST_ADMIN_1' => 'Le Login ',
  'ERR_LAST_ADMIN_2' => ' est le dernier utilisateur administrateur.  Au moins un utilisateur doit �tre un utilisateur administrateur.<br>V�rifiez les param�tres administrateurt.',
  'LNK_NEW_USER' => 'New User',
  'LNK_USER_LIST' => 'Users',
  'ERR_DELETE_RECORD' => 'Un num�ro d\'enregistrement doit �tre sp�cifi� pour supprimer le compte.',
  'LBL_RECEIVE_NOTIFICATIONS' => 'Assignment Notification:',
  'LBL_RECEIVE_NOTIFICATIONS_TEXT' => 'Receive an e-mail notification when a record is assigned to you.',
  'LBL_ADMIN_TEXT' => 'Grants administrator privileges to this user',
  'LBL_TIME_FORMAT_TEXT' => 'Set the display format for time stamps',
  'LBL_GRIDLINE' => 'Show Gridlines:',
  'LBL_GRIDLINE_TEXT' => 'Controls gridlines on detail views',
  'LBL_CURRENCY_TEXT' => 'Select the default currency',
  'LBL_YAHOO_ID' => 'Identifiant Yahoo messenger:',
  'LNK_NEW_CONTACT' => 'Nouveau Contact',
  'LNK_NEW_ACCOUNT' => 'Nouveau Compte',
  'LNK_NEW_OPPORTUNITY' => 'Nouvelle Affaire',
  'LNK_NEW_CASE' => 'Nouveau Ticket',
  'LNK_NEW_NOTE' => 'Nouvelll Note',
  'LNK_NEW_CALL' => 'Nouvel Appel',
  'LNK_NEW_EMAIL' => 'Nouvel Email',
  'LNK_NEW_MEETING' => 'Nouveau Rendez-vous',
  'LNK_NEW_TASK' => 'Nouvelle T�che',
);


?>