<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/modules/Accounts/Account.php,v 1.92 2004/11/10 22:27:36 clint Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Tickets',
  'LBL_MODULE_TITLE' => 'Tickets: Accueil',
  'LBL_SEARCH_FORM_TITLE' => 'Recherche de Ticket',
  'LBL_LIST_FORM_TITLE' => 'Liste des Tickets',
  'LBL_NEW_FORM_TITLE' => 'Nouveau Ticket',
  'LBL_CONTACT_CASE_TITLE' => 'Contact-Ticket:',
  'LBL_SUBJECT' => 'sujet:',
  'LBL_CASE' => 'Ticket:',
  'LBL_CASE_NUMBER' => 'Num�ro du Ticket:',
  'LBL_NUMBER' => 'Num�ro:',
  'LBL_STATUS' => 'Statut:',
  'LBL_PRIORITY' => 'Priority:',
  'LBL_ACCOUNT_NAME' => 'Nom du Compte:',
  'LBL_DESCRIPTION' => 'Description:',
  'LBL_CONTACT_NAME' => 'Nom du Contact:',
  'LBL_CASE_SUBJECT' => 'Sujet du Ticket:',
  'LBL_CONTACT_ROLE' => 'R�le:',
  'LBL_LIST_NUMBER' => 'Num.',
  'LBL_LIST_SUBJECT' => 'sujet',
  'LBL_LIST_ACCOUNT_NAME' => 'Nom du Compte',
  'LBL_LIST_STATUS' => 'Statuts',
  'LBL_LIST_PRIORITY' => 'Priority',
  'LBL_LIST_LAST_MODIFIED' => 'Derni�re Modification',
  'LBL_INVITEE' => 'Contacts',
  'LNK_NEW_CASE' => 'Nouveau Ticket',
  'LNK_CASE_LIST' => 'Cases',
  'NTC_REMOVE_INVITEE' => 'Etes vous sur de vouloir supprimer ce contact du ticket ?',
  'ERR_DELETE_RECORD' => 'Un num�ro d\'enregistrement doit �tre sp�cifi� pour supprimer ce compte.',
  'LNK_NEW_CONTACT' => 'Nouveau Contact',
  'LNK_NEW_ACCOUNT' => 'Nouveau Compte',
  'LNK_NEW_OPPORTUNITY' => 'Nouvelle Affaire',
  'LNK_NEW_NOTE' => 'Nouvelle Note',
  'LNK_NEW_CALL' => 'Nouvel Appel',
  'LNK_NEW_EMAIL' => 'Nouvel Email',
  'LNK_NEW_MEETING' => 'Nouveau Rendez-vous',
  'LNK_NEW_TASK' => 'Nouvelle T�che',
);


?>