<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/modules/Accounts/Account.php,v 1.92 2004/11/10 22:27:36 clint Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Comptes',
  'LBL_MODULE_TITLE' => 'Comptes: Accueil',
  'LBL_SEARCH_FORM_TITLE' => 'Recherche de Compte',
  'LBL_LIST_FORM_TITLE' => 'Liste des Comptes',
  'LBL_NEW_FORM_TITLE' => 'Nouveau Compte',
  'LBL_MEMBER_ORG_FORM_TITLE' => 'Membre des Organisations',
  'LBL_LIST_ACCOUNT_NAME' => 'Nom du Compte',
  'LBL_LIST_CITY' => 'Ville',
  'LBL_LIST_WEBSITE' => 'Site web',
  'LBL_LIST_STATE' => 'Etat',
  'LBL_LIST_PHONE' => 'T�l�phone',
  'LBL_LIST_EMAIL_ADDRESS' => 'Adresse Email',
  'LBL_LIST_CONTACT_NAME' => 'Nom du Contact',
  'db_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_website' => 'LBL_LIST_WEBSITE',
  'db_billing_address_city' => 'LBL_LIST_CITY',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'LBL_ACCOUNT_INFORMATION' => 'Account Information',
  'LBL_ACCOUNT' => 'Compte:',
  'LBL_ACCOUNT_NAME' => 'Nom du Compte:',
//END DON'T CONVERT
  'LBL_PHONE' => 'T�l�phone:',
  'LBL_WEBSITE' => 'Site web:',
  'LBL_FAX' => 'Fax:',
  'LBL_TICKER_SYMBOL' => 'Symbole:',
  'LBL_OTHER_PHONE' => 'Autres T�l�phones:',
  'LBL_ANY_PHONE' => 'T�l�hphone alternatif:',
  'LBL_MEMBER_OF' => 'Membre de:',
  'LBL_EMAIL' => 'Email:',
  'LBL_EMPLOYEES' => 'Employ�s:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Autre Email:',
  'LBL_ANY_EMAIL' => 'Email alternatif:',
  'LBL_OWNERSHIP' => 'Propri�taire:',
  'LBL_RATING' => 'Note:',
  'LBL_INDUSTRY' => 'Activit�:',
  'LBL_SIC_CODE' => 'code NAF:',
  'LBL_TYPE' => 'Type:',
  'LBL_ANNUAL_REVENUE' => 'CA:',
  'LBL_ADDRESS_INFORMATION' => 'Adresse',
  'LBL_BILLING_ADDRESS' => 'Adresse de facturation:',
  'LBL_SHIPPING_ADDRESS' => 'Adresse de livraison:',
  'LBL_ANY_ADDRESS' => 'autre Adresse:',
  'LBL_CITY' => 'Ville:',
  'LBL_STATE' => 'Etat:',
  'LBL_POSTAL_CODE' => 'Code Postal:',
  'LBL_COUNTRY' => 'Pays:',
  'LBL_DESCRIPTION_INFORMATION' => 'Description',
  'LBL_DESCRIPTION' => 'Description:',
  'NTC_COPY_BILLING_ADDRESS' => 'Copier adresse de facturation sur adresse de livraison',
  'NTC_COPY_SHIPPING_ADDRESS' => 'Copier adresse de livraison sur adresse de facturation',
  'NTC_REMOVE_MEMBER_ORG_CONFIRMATION' => 'Etes vous sur de vouloir supprimer ces informations ?',
  'LBL_DUPLICATE' => 'Possible Duplicate Account',
  'MSG_DUPLICATE' => 'Creating this account may potentialy create a duplicate account. You may either select an account from the list below or you may click on Create New Account to continue creating a new account with the previously entered data.',
  'LNK_NEW_ACCOUNT' => 'Nouveau Compte',
  'LNK_ACCOUNT_LIST' => 'Accounts',
  'LBL_INVITEE' => 'Contacts',
  'ERR_DELETE_RECORD' => 'Un num�ro d\'enregistrement doit �tre sp�cifi� pour supprimer le compte.',
  'NTC_DELETE_CONFIRMATION' => 'Are you sure you want to delete this record?',
  'LNK_NEW_CONTACT' => 'Nouveau Contact',
  'LNK_NEW_OPPORTUNITY' => 'Nouvelle affaire',
  'LNK_NEW_CASE' => 'Nouveau Ticket',
  'LNK_NEW_NOTE' => 'Nouvelle Note',
  'LNK_NEW_CALL' => 'Nouvel Appel',
  'LNK_NEW_EMAIL' => 'Nouvel Email',
  'LNK_NEW_MEETING' => 'Nouveau Rendez-vous',
  'LNK_NEW_TASK' => 'Nouvelle T�che',
);


?>