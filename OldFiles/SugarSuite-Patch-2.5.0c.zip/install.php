<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

// $Id: install.php,v 1.56.2.1 2005/01/27 22:05:23 andrew Exp $

$setup_sugar_version = '2.5.0c';

if(!is_dir('install'))
{
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
   <meta http-equiv="Content-Style-Type" content="text/css">
   <title>SugarCRM Setup Wizard Locked</title>
   <link rel="stylesheet" href="install/install.css" type="text/css">
</head>

<body>
  <table cellspacing="0" cellpadding="0" border="0" align="center" class=
  "shell">
    <tr>
      <th width="400">SugarCRM Setup Wizard Locked</th>
	</tr>

    <tr>
	 	<td>
        <p>Your SugarCRM application has been secured to prevent you from
        running the installation again.  To allow yourself to run the
        installation again you must rename your installation directory
        back to 'install'.</p>

        <p>For installation help, please visit the SugarCRM <a href=
        "http://www.sugarcrm.com/forums/" target="_blank">support
        forums</a>.</p>
      </td>
    </tr>

    <tr>
      <td>
        <hr>
      </td>
    </tr>
  </table>
</body>
</html>

<?php
}
else
{

$install_script = true;

session_start();

if (substr(phpversion(), 0, 1) == "5")
{
   ini_set("zend.ze1_compatibility_mode", "1");
}

require_once('include/utils.php');

$current_language = 'en_us';

function stripslashes_checkstrings($value)
{
   if(is_string($value))
   {
      return stripslashes($value);
   }

   return $value;
}

if(get_magic_quotes_gpc() == 1)
{
   $_REQUEST = array_map("stripslashes_checkstrings", $_REQUEST);
   $_POST = array_map("stripslashes_checkstrings", $_POST);
   $_GET = array_map("stripslashes_checkstrings", $_GET);
}

$next_clicked = false;
$next_step = 0;

if(!empty($_REQUEST['goto']))
{
   switch($_REQUEST['goto'])
   {
   case 'Re-check':
      $next_step = $_REQUEST['current_step'];
      break;
   case 'Back':
      $next_step = $_REQUEST['current_step'] - 1;
      break;
   case 'Next':
   case 'Start':
      $next_step = $_REQUEST['current_step'] + 1;
      $next_clicked = true;
      break;
   }
}

// process the data posted
if($next_clicked)
{
   // store the submitted data because the 'Next' button was clicked
   switch($_REQUEST['current_step'])
   {
      case 2:
            $_SESSION['setup_db_host_name'] = $_REQUEST['setup_db_host_name'];
            $_SESSION['setup_db_database_name'] = $_REQUEST['setup_db_database_name'];
            $_SESSION['setup_db_create_database']
               = isset($_REQUEST['setup_db_create_database']) &&
                 $_REQUEST['setup_db_create_database'] == 'yes' ? true : false;
            $_SESSION['setup_db_sugarsales_user'] = $_REQUEST['setup_db_sugarsales_user'];
            $_SESSION['setup_db_create_sugarsales_user']
               = isset($_REQUEST['setup_db_create_sugarsales_user']) &&
                 $_REQUEST['setup_db_create_sugarsales_user'] == 'yes' ? true : false;
            $_SESSION['setup_db_sugarsales_password'] = $_REQUEST['setup_db_sugarsales_password'];
            $_SESSION['setup_db_sugarsales_password_retype'] = $_REQUEST['setup_db_sugarsales_password_retype'];
            $_SESSION['setup_db_drop_tables']
               = isset($_REQUEST['setup_db_drop_tables']) &&
                 $_REQUEST['setup_db_drop_tables'] == 'yes' ? true : false;
            $_SESSION['setup_db_pop_demo_data']
               = isset($_REQUEST['setup_db_pop_demo_data']) &&
                 $_REQUEST['setup_db_pop_demo_data'] == 'yes' ? true : false;
            $_SESSION['setup_db_admin_user_name'] = $_REQUEST['setup_db_admin_user_name'];
            $_SESSION['setup_db_admin_password'] = $_REQUEST['setup_db_admin_password'];
         break;
      case 3:
            $_SESSION['setup_site_url'] = $_REQUEST['setup_site_url'];
            $_SESSION['setup_site_admin_password'] = $_REQUEST['setup_site_admin_password'];
            $_SESSION['setup_site_admin_password_retype'] = $_REQUEST['setup_site_admin_password_retype'];
            $_SESSION['setup_site_custom_session_path']
               = isset($_REQUEST['setup_site_custom_session_path']) &&
                 $_REQUEST['setup_site_custom_session_path'] == 'yes' ? true : false;
            $_SESSION['setup_site_session_path'] = $_REQUEST['setup_site_session_path'];
            $_SESSION['setup_site_specify_guid']
               = isset($_REQUEST['setup_site_specify_guid']) &&
                 $_REQUEST['setup_site_specify_guid'] == 'yes' ? true : false;
            $_SESSION['setup_site_guid'] = $_REQUEST['setup_site_guid'];
         break;
   }
}

function validate_step_2()
{
   $errors = array();

   if($_SESSION['setup_db_host_name'] == '')
   {
      $errors[] = 'Host name cannot be blank.';
   }

   if($_SESSION['setup_db_database_name'] == '')
   {
      $errors[] = 'Database name cannot be blank.';
   }

   if($_SESSION['setup_db_sugarsales_user'] == '')
   {
      $errors[] = 'User name for SugarCRM cannot be blank.';
   }

   if($_SESSION['setup_db_create_sugarsales_user'] &&
      ($_SESSION['setup_db_sugarsales_password'] !=
      $_SESSION['setup_db_sugarsales_password_retype']))
   {
      $errors[] = 'Passwords for SugarCRM do not match.';
   }

   if($_SESSION['setup_db_sugarsales_user'] != '' &&
      !$_SESSION['setup_db_create_sugarsales_user'] &&
      ($_SESSION['setup_db_sugarsales_password'] ==
      $_SESSION['setup_db_sugarsales_password_retype']))
   {
      $link = @mysql_connect($_SESSION['setup_db_host_name'],
                             $_SESSION['setup_db_sugarsales_user'],
                             $_SESSION['setup_db_sugarsales_password']);
      if(!$link)
      {
         $errno = mysql_errno();
         $error = mysql_error();
         $errors[] = "SugarCRM database user name and/or password is invalid (Error $errno: $error).";
      }
   }

   if($_SESSION['setup_db_admin_user_name'] == '')
   {
      $errors[] = 'Database admin user name is required.';
   }

   if(!$_SESSION['setup_db_create_database'] &&
      $_SESSION['setup_db_host_name'] != '' &&
      $_SESSION['setup_db_sugarsales_user'] != '')
   {
      $link = @mysql_connect($_SESSION['setup_db_host_name'],
                             $_SESSION['setup_db_sugarsales_user'],
                             $_SESSION['setup_db_sugarsales_password']);
      if($link)
      {
         if($_SESSION['setup_db_database_name'] != '')
         {
            $db_selected = @mysql_select_db($_SESSION['setup_db_database_name'], $link);

            if(!$db_selected)
            {
               $errno = mysql_errno($link);
               $error = mysql_error($link);
               $errors[] = "Test connection to the database failed with the given configuration (Error $errno: $error).";
            }
         }

         mysql_close($link);
      }
      else
      {
         $errno = mysql_errno();
         $error = mysql_error();
         $errors[] = "SugarCRM database user name and/or password is invalid (Error $errno: $error).";
      }
   }

   if($_SESSION['setup_db_admin_user_name'] != '')
   {
      $link = @mysql_connect($_SESSION['setup_db_host_name'],
                             $_SESSION['setup_db_admin_user_name'],
                             $_SESSION['setup_db_admin_password']);
      
      if($link)
      {
         // database admin credentials are valid--can continue check on stuff
         // that depend on a valid database admin

         // check for existing database
         if($_SESSION['setup_db_create_database'] &&
            $_SESSION['setup_db_database_name'] != '')
         {
            $db_selected = @mysql_select_db($_SESSION['setup_db_database_name'], $link);
      
            if($db_selected)
            {
               $errors[] = "Database name already exists--cannot create another one with the same name.";
            }
         }

         // check for existing SugarCRM database user
         if($_SESSION['setup_db_create_sugarsales_user'] &&
            $_SESSION['setup_db_sugarsales_user'] != '')
         {
            $db_selected = mysql_select_db('mysql', $link);
            $user = $_SESSION['setup_db_sugarsales_user'];
            $query = "select count(*) from user where User='$user'";
            $result = mysql_unbuffered_query($query, $link);
            $row = mysql_fetch_row($result);

            if($row[0] == 1)
            {
               $errors[] = 'User name for SugarCRM already exists--cannot create another one with the same name.';
            }
            mysql_free_result($result);
         }
         mysql_close($link);

      }
      else
      {
         $errno = mysql_errno();
         $error = mysql_error();
         $errors[] = "Database admin user name and/or password is invalid (Error $errno: $error).";
      }
   }

   return $errors;
}

function validate_step_3()
{
   $errors = array();

   if($_SESSION['setup_site_url'] == '')
   {
      $errors[] = 'URL cannot be blank.';
   }

   if($_SESSION['setup_site_admin_password'] == '')
   {
      $errors[] = 'SugarCRM admin password cannot be blank.';
   }

   if($_SESSION['setup_site_admin_password'] !=
      $_SESSION['setup_site_admin_password_retype'])
   {
      $errors[] = 'Passwords for SugarCRM admin do not match.';
   }

   if($_SESSION['setup_site_custom_session_path'] &&
      $_SESSION['setup_site_session_path'] == '')
   {
      $errors[] = 'Session path is required if you wish to specify your own.';
   }

   if($_SESSION['setup_site_custom_session_path'] &&
      $_SESSION['setup_site_session_path'] != '')
   {
      if(is_dir($_SESSION['setup_site_session_path']))
      {
         if(!is_writable($_SESSION['setup_site_session_path']))
         {
            $errors[] = 'Session directory provided is not a writable directory.';
         }
      }
      else
      {
         $errors[] = 'Session directory provided is not a valid directory.';
      }
   }

   if($_SESSION['setup_site_specify_guid'] &&
      $_SESSION['setup_site_guid'] == '')
   {
      $errors[] = 'Application ID is required if you wish to specify your own.';
   }

   return $errors;
}

$validation_errors = array();

switch($next_step)
{
   case 0:
      $the_file = '0welcome.php';
      break;
   case 1:
      $the_file = '1checkSystem.php';
      break;
   case 2:
      $the_file = '2dbConfig.php';
      $_SESSION['step_1_submitted'] = $next_clicked;
      break;
   case 3:
      $validation_errors = validate_step_2();
      if(count($validation_errors) > 0)
      {
         $the_file = '2dbConfig.php';
      }
      else
      {
         $the_file = '3siteConfig.php';
      }
      $_SESSION['step_2_submitted'] = $next_clicked;
      break;
   case 4:
      $validation_errors = validate_step_3();
      if(count($validation_errors) > 0)
      {
         $the_file = '3siteConfig.php';
      }
      else
      {
         $the_file = '4performSetup.php';
      }
      $_SESSION['step_3_submitted'] = $next_clicked;
      break;
   case 5:
      $the_file = '5register.php';
      session_unset();
      break;
   default:
      $the_file = '0welcome.php';
      break;
}

$the_file = clean_string($the_file, 'FILE');

// change to require to get a good file load error message if the files is not available.
require('install/' . $the_file);
}
?>

