<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

// $Id: PearDatabase.php,v 1.63 2006/01/17 19:31:23 ajay Exp $

require_once('log4php/LoggerManager.php');
require_once('include/utils.php');

class PearDatabase{
	var $database = null;
	var $dieOnError = false;
	var $encode = true;
	var $dbType = null;
	var $dbHostName = null;
	var $dbName = null;
	var $dbOptions = null;
	var $userName=null;
	var $userPassword=null;
	var $query_time = 0;
	var $lastmysqlrow = -1;
	var $last_error = '';
	function &getInstance(){
			static $dbm;
			static $count;
			static $old_count;
			if(!isset($dbm)){
				$count++;
				$dbm = new PearDatabase();
				$dbm->resetSettings();
				$dbm->count_id = $count;
				$dbm->references = 0;
				
			}else{
				$old_count++;
				$dbm->references = $old_count;
			}
			
			return $dbm;
}
    function checkOCIError($obj){
        $err = ocierror($obj);
        if ($err != false){
            $result = false;
            print_r($err);
            $GLOBALS['log']->fatal("OCIError:".var_export($err, true));
            return true;
        }
        return false; 
    }

	function setDieOnError($value){
		$this->dieOnError = $value;
	}

	function setDatabaseType($type){
		$this->dbType = $type;
		if (empty($this->dbType)) $this->dbType='mysql';
	}

	function setUserName($name){
		$this->userName = $name;
	}

	function setOption($name, $value){
		if(isset($this->dbOptions))
			$this->dbOptions[$name] = $value;
		if(isset($this->database))
			$this->database->setOption($name, $value);
	}

	function setUserPassword($pass){
		$this->userPassword = $pass;
	}

	function setDatabaseName($db){
		$this->dbName = $db;
	}

	function setDatabaseHost($host){
		$this->dbHostName = $host;
	}

	function getDataSourceName(){
		return 	$this->dbType. "://".$this->userName.":".$this->userPassword."@". $this->dbHostName . "/". $this->dbName;
	}

	function checkError($msg='', $dieOnError=false){
		if($this->dbType == "mysql"){
			if (mysql_errno()){
    			if($this->dieOnError || $dieOnError){
             	 	$GLOBALS['log']->fatal("MySQL error ".mysql_errno().": ".mysql_error());	
    				sugar_die ($msg."MySQL error ".mysql_errno().": ".mysql_error());		
    			}else{
    				$this->last_error = $msg."MySQL error ".mysql_errno().": ".mysql_error();
    				$GLOBALS['log']->error("MySQL error ".mysql_errno().": ".mysql_error());	
    			}
            }
        }
        else if ($this->dbType == 'oci8') {















		}
        else{
			if(!isset($this->database)){
				$GLOBALS['log']->error("Database Is Not Connected");
				return true;
			}
			if(DB::isError($this->database)){
				
				if($this->dieOnError || $dieOnError){
					$GLOBALS['log']->fatal($msg.$this->database->getMessage());
					 sugar_die ($msg.$this->database->getMessage());	
				}else{
					$GLOBALS['log']->error($msg.$this->database->getMessage());		
				}
				return true;
			}
			return true;
		}
        return false;
	}

	/**
	* @desc This method is called by every method that runs a query.
	*	If slow query dumping is turned on and the query time is beyond
	*	the time limit, we will log the query. This function may do
	*	additional reporting or log in a different area in the future.
	*/
	function dump_slow_queries($query)
	{
		global $sugar_config;

		$do_the_dump = isset($sugar_config['dump_slow_queries']) ? $sugar_config['dump_slow_queries'] : 0;
		$slow_query_time_msec = isset($sugar_config['slow_query_time_msec']) ? $sugar_config['slow_query_time_msec'] : 5000;

		if($do_the_dump)
		{
			if($slow_query_time_msec < ($this->query_time * 1000))
			{
				// Then log both the query and the query time
				$GLOBALS['log']->fatal('Slow Query (time:'.$this->query_time."\n".$query);
			}
		}
	}

	/**
	* @return void
	* @desc checks if a connection exists if it does not it closes the connection
	 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc..
	 * All Rights Reserved..
	 * Contributor(s): ______________________________________..
	*/
	function checkConnection(){
			$this->last_error = '';
			if(!isset($this->database)) $this->connect();
	}

	/**
	 * Enter description here...
	 *
	 * @param unknown_type $sql
	 * @param unknown_type $dieOnError
	 * @param unknown_type $msg
	 * @param unknown_type $suppress
	 * @return appropriate type of result set
	 * @return false -- on error
	 */
	function query($sql, $dieOnError=false, $msg='', $suppress=false){
		global $sql_queries;
		$sql_queries++;
		$GLOBALS['log']->info('Query:' . $sql);
		$this->checkConnection();
		$this->query_time = microtime();
		if($this->dbType == "mysql"){
			if($suppress==true){








			} else {
				$result = mysql_query($sql);
			}
			$this->lastmysqlrow = -1; 	
        }
        else if ($this->dbType == "oci8") {
























		}
        else{
			$result = $this->database->query($sql);
		}
		$this->query_time = microtime_diff($this->query_time, microtime());
		$GLOBALS['log']->info('Query Execution Time:'.$this->query_time);

		$this->dump_slow_queries($sql);

		$this->checkError($msg.' Query Failed:' . $sql . '::', $dieOnError);
		return $result;
	}

	/**
	 * Return the results of the query with limits applied
	 *
	 * @param unknown_type $sql
	 * @param unknown_type $start
	 * @param unknown_type $count
	 * @param unknown_type $dieOnError
	 * @param unknown_type $msg
	 * @return appropriate result set type for the current database
	 * @return false -- on error
	 */
	function limitQuery($sql,$start,$count, $dieOnError=false, $msg=''){
		if ($start < 0) $start=0; 
		$GLOBALS['log']->debug(print_r(func_get_args(),true));
		
        $GLOBALS['log']->debug('Limit Query:' . $sql. ' Start: ' .$start . ' count: ' . $count);
        $this->lastsql = $sql;
		if($this->dbType == "mysql")
			return $this->query("$sql LIMIT $start,$count", $dieOnError, $msg);
        else if ($this->dbType == "oci8"){










		}

		$GLOBALS['log']->info('Limit Query:' . $sql. ' Start: ' .$start . ' count: ' . $count);
		$this->lastsql = $sql;

		$this->checkConnection();
		$this->query_time = microtime();
		$result = $this->database->limitQuery($sql,$start, $count);
		$this->query_time = microtime_diff($this->query_time, microtime());
		$GLOBALS['log']->info('Query Execution Time:'.$this->query_time);
		
		$this->dump_slow_queries($sql);

		$this->checkError($msg.' Query Failed:' . $sql . '::', $dieOnError);
		return $result;
	}

	function getOne($sql, $dieOnError=false, $msg=''){
		$GLOBALS['log']->info("Get One: . |$sql|");
		$this->checkConnection();
		if($this->dbType == "mysql"){
			$queryresult = $this->query($sql, $dieOnError, $msg);
            if (!$queryresult) $result = false;
			else $result = mysql_result($queryresult,0);
        }
        else if ($this->dbType == 'oci8'){













 		}
        else{
			$result = $this->database->getOne($sql);
		}
		$this->checkError($msg.' Get One Failed:' . $sql . '::', $dieOnError);
		return $result;
	}

	function getFieldsArray(&$result, $make_lower_case=false)
	{
		$field_array = array();

		if(! isset($result) || empty($result))
		{
			return 0;
		}

		if($this->dbType == "mysql")
		{
			$i = 0;
			while ($i < mysql_num_fields($result))
			{
   				$meta = mysql_fetch_field($result, $i);

   				if (!$meta)
				{
					return 0;
   				}

				array_push($field_array,$meta->name);

   				$i++;
			}
        } else if($this->dbType == "oci8") {
















		}else{
			$arr = tableInfo($result);
			foreach ($arr as $index=>$subarr)
			{
				array_push($field_array,$subarr['name']);
			}

		}

		return $field_array;

	}

	function getRowCount(&$result){
		if(isset($result) && !empty($result))
			if($this->dbType == "mysql"){
				return mysql_numrows($result);
	        } else if($this->dbType == "oci8"){






    		}else{
				 return $result->numRows();
			}
		return 0;

	}
	function getAffectedRowCount(&$result){
			if($this->dbType == "mysql"){
				return mysql_affected_rows();
	        } else if ($this->dbType == 'oci8'){





    		}
			else {
				return $result->affectedRows();
			}
		return 0;

	}
	//1:13 this method has been deprecated. becuase there is no way to get a rowcount in oracle
	//without doing a fetch.. use limitQuery instead.
	function requireSingleResult($sql, $dieOnError=false,$msg='', $encode=true){
			$result = $this->query($sql, $dieOnError, $msg);

			//$GLOBALS['log']->fatal("requireSingleResult result:$result");
			
            if ($this->dbType == "mysql"){
    			if($this->getRowCount($result ) == 1)
	       			return $result;
            }else if ($this->dbType == 'oci8'){





            }
			$GLOBALS['log']->error('Rows Returned:'. $this->getRowCount($result) .' No row or more than 1 row returned for '. $sql);
			return '';
	}



















	/**
	 * Retrieve rows from the result set.  If the result set is false do nothing.
	 *
	 * @param unknown_type $result
	 * @param unknown_type $rowNum
	 * @param unknown_type $encode
	 * @return unknown
	 */
    function fetchByAssoc(&$result, $rowNum = -1, $encode=true){
		if(isset($result) && $result && $rowNum < 0){
			if($this->dbType == "mysql"){
				$row = mysql_fetch_assoc($result);

				if($encode && $this->encode&& is_array($row))return array_map('to_html', $row);
				return $row;
			}
            else if ($this->dbType == 'oci8') {





            }
            return $row;
			//$row = $result->fetchRow(DB_FETCHMODE_ASSOC);	
		}
		if($this->dbType == "mysql"){
				if($this->getRowCount($result) > $rowNum){

					mysql_data_seek($result, $rowNum);
				}
				$this->lastmysqlrow = $rowNum;

				$row = mysql_fetch_assoc($result);

				if($encode && $this->encode && is_array($row))return array_map('to_html', $row);
				return $row;

		}
        else if($this->dbType == "oci8"){









        }
        $row = $result->fetchRow(DB_FETCHMODE_ASSOC, $rowNum);
        if($encode && $this->encode)return array_map('to_html', $row);
		return $row;
	}

	function getNextRow(&$result, $encode=true){
		if(isset($result)){
			$row = $result->fetchRow();
			if($encode && $this->encode&& is_array($row))return array_map('to_html', $row);
				return $row;

		}
		return null;
	}


	function getQueryTime(){
		return $this->query_time;
	}

	function connect($dieOnError = false){
		global $sugar_config;
		if($this->dbType == "mysql" && $sugar_config['dbconfigoption']['persistent'] == true){
			$this->database =@mysql_pconnect($this->dbHostName,$this->userName,$this->userPassword);
			@mysql_select_db($this->dbName) or sugar_die( "Unable to select database: " . mysql_error());
			if(!$this->database){
				$this->connection = mysql_connect($this->dbHostName,$this->userName,$this->userPassword) or sugar_die("Could not connect to server ".$this->dbHostName." as ".$this->userName.".".mysql_error());
				if($this->connection == false && $sugar_config['dbconfigoption']['persistent'] == true){
					$_SESSION['administrator_error'] = "<B>Severe Performance Degradation: Persistent Database Connections not working.  Please set \$sugar_config['dbconfigoption']['persistent'] to false in your config.php file</B>";
				}
			}
		}
        else if($this->dbType == "oci8" && $sugar_config['dbconfigoption']['persistent'] == true){
















        }
		else{
				display_stack_trace();
				 $this->database = DB::connect($this->getDataSourceName(), $this->dbOptions);
		}
		if($this->checkError('Could Not Connect:', $dieOnError))
			$GLOBALS['log']->info("connected to db");
			
        $GLOBALS['log']->info("Connect:".$this->database); 
                   
	}
	
	function PearDatabase(){
			global $currentModule;
			
			
	}
	

		
	function resetSettings(){
		global $sugar_config;

		$this->disconnect();
		
		$this->setDatabaseType($sugar_config['dbconfig']['db_type']);
		$this->setUserName($sugar_config['dbconfig']['db_user_name']);
		$this->setUserPassword($sugar_config['dbconfig']['db_password']);
		$this->setDatabaseHost( $sugar_config['dbconfig']['db_host_name']);
		$this->setDatabaseName($sugar_config['dbconfig']['db_name']);
		$this->dbOptions = $sugar_config['dbconfigoption'];
		if($this->dbType != "mysql"){



		    	require_once( 'DB.php' );



		}
	}

    function quote($string,$isLike=true){
        global $sugar_config;
        $string = from_html($string);
        if($sugar_config['dbconfig']['db_type'] == 'mysql'){
            $string = mysql_escape_string($string);
        } elseif ($sugar_config['dbconfig']['db_type'] == 'oci8') {
        		//do nothing
        	}
        	else {
        	if ($isLike) {
        		$string = strtr($string, array('_' => '\_', '%'=>'\%'));
        	}        		
        }
        return $string;
    }
	 /* Samething as quote, except for arrays.
	  */
	 function arrayQuote(&$array, $isLike=true) {
	 	for($i = 0; $i < count($array); $i++) 
	 		$array[$i] = PearDatabase::quote($array[$i]);
	 }
	 
    function disconnect() {
    
		if(isset($this->database)){
			if($this->dbType == "mysql"){
				mysql_close($this->database);
            } else if ($this->dbType == 'oci8'){



			}else{
				$this->database->disconnect();
			}
			unset($this->database);
        }
    }	
    
    function tableExists($tableName){
    
        $GLOBALS['log']->info("tableExists: $tableName");
        
        $this->checkConnection();

        if ($this->database){
            if ($this->dbType == 'mysql'){
                $result = $this->query("SHOW TABLES LIKE '".$tableName."'");
                return ($this->getRowCount($result) == 0) ? false : true;                
            }else if ($this->dbType == 'oci8') {






            }
        }
        return false;
    }
    
    /** 
     * Returns an array of table for this database
     * @return	$tables		an array of with table names
     * @return	false		if no tables found
     */
    function getTablesArray() {
    	global $sugar_config;
    	$GLOBALS['log']->debug('PearDatabase fetching table list');
    	
    	$this->checkConnection();
    	
    	if($this->database) {
    		$tables = array();
    		
    		if($this->dbType == 'mysql') {
    			$r = $this->query('SHOW TABLES');
				if(is_resource($r)) {
					while($a = $this->fetchByAssoc($r)) {
						$key = 'Tables_in_'.$sugar_config['dbconfig']['db_name'];
						$tables[] = $a[$key];
					}
					return $tables;
				}
    		} elseif($this->dbType == 'oci8') {





    		}
    		
    		
    		return false;
    	}
    	
    	return false; // no database available
    }
}
?>
