<?php
global $sugar_version;
if(substr($sugar_version,0,5) == "4.0.1")
{
    if(empty($GLOBALS['sugarEntry']))
        $GLOBALS['sugarEntry'] = true;
}
else if(!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');

}
/**
 * This script executes after the files are copied during the install.
 *
 * LICENSE: The contents of this file are subject to the SugarCRM Professional
 * End User License Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/EULA.  By installing or using this file, You have
 * unconditionally agreed to the terms and conditions of the License, and You
 * may not use this file except in compliance with the License.  Under the
 * terms of the license, You shall not, among other things: 1) sublicense,
 * resell, rent, lease, redistribute, assign or otherwise transfer Your
 * rights to the Software, and 2) use the Software for timesharing or service
 * bureau purposes such as hosting the Software for commercial gain and/or for
 * the benefit of a third party.  Use of the Software may be subject to
 * applicable fees and any use of the Software without first paying applicable
 * fees is strictly prohibited.  You do not have the right to remove SugarCRM
 * copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2005 SugarCRM, Inc.; All Rights Reserved.
 * 

 */

require_once('include/utils.php');
require_once('include/database/PearDatabase.php');
require_once('include/database/DBManager.php');
require_once('include/database/DBManagerFactory.php');

///////////////////////////////////////////////////////////////////////////////
////	HELPER FUNCTIONS
function checkDupe($db, $a, $tables, $columns) {
	$q = "	SELECT count(*) c FROM ".$tables[$a['parent_type']]." 
			WHERE email_id = '".$a['id']."' 
			AND ".$columns[$a['parent_type']]." = '".$a['parent_id']."'";
	$r = $db->query($q);
	$b = $db->fetchByAssoc($r);
	if($b['c'] > 0) {
		//_pp('dupe');
		return true;
	} else {
		//_pp('no dupe');
		return false;
	}
}
////	END HELPERS
///////////////////////////////////////////////////////////////////////////////

function upgrade_email() {
	$GLOBALS['log'] = LoggerManager :: getLogger('SugarCRM');
	$db = & PearDatabase :: getInstance();
	$dbmann = DBManager :: getInstance();

	$tables = array(
		'Accounts'	=> 'emails_accounts',
		'Bugs'		=> 'emails_bugs',
		'Cases'		=> 'emails_cases',
		'Contacts'	=> 'emails_contacts',
		'Leads'		=> 'emails_leads',
		'Opportunities' => 'emails_opportunities',
		'ProjectTask' => 'emails_project_tasks',
		'Project'	=> 'emails_projects',
		'Prospects'	=> 'emails_prospects',



		'Users'		=> 'emails_users',
	);
	$columns = array(
		'Accounts'	=> 'account_id',
		'Bugs'		=> 'bug_id',
		'Cases'		=> 'case_id',
		'Contacts'	=> 'contact_id',
		'Leads'		=> 'lead_id',
		'Opportunities' => 'opportunity_id',
		'ProjectTask' => 'task_id',
		'Project'	=> 'project_id',
		'Prospects'	=> 'prospect_id',



		'Users'		=> 'user_id',
	);

	$skipDupeCheckTables = array(
		'Bugs',
		'Project',
		'ProjectTask',
		'Prospects',



	); 

	////	CORE QUERY
	$mainQuery = "SELECT e.id, e.parent_type, e.parent_id FROM emails e WHERE (e.parent_type IS NOT NULL AND e.parent_id IS NOT NULL)";
	if($db->dbType == 'mysql') $mainQuery .= " AND (e.parent_type != '' AND e.parent_id != '')";
	$r = $db->query($mainQuery);

	//echo $mainQuery;

	while($a = $db->fetchByAssoc($r)) {
		$dupe = false;
		if(!empty($a['parent_type'])) {
			if(!in_array($a['parent_type'], $skipDupeCheckTables)) {
				$dupe = checkDupe($db, $a, $tables, $columns);
			}
			
			if($dupe) {
				//echo "got a dupe, skipping";
				continue;
			} else {
				$insertQuery = 
					"INSERT INTO ".$tables[$a['parent_type']]." 
						(	id, 
							email_id, 
							".$columns[$a['parent_type']].", 
							date_modified
						)
					VALUES 
						(	'".create_guid()."', 
							'".$a['id']."', 
							'".$a['parent_id']."', 
							 ".db_convert("'".date('Y-m-d H:i:s')."'", 'datetime')."
						)";

				$db->query($insertQuery);
				//echo $insertQuery; 
			}
		} else {
			//echo "parent empty";
		}
	}
}

?>
