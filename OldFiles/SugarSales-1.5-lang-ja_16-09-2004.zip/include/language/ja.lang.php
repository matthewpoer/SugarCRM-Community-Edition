<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Shuntaro Tokokawa stokokaw@yahoo.co.jp
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/include/language/ja.lang.php,v 1.27 2004/08/08 22:53:04 sugarclint Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$app_strings = Array(
'LNK_ABOUT'=>'���i�ɂ���',

'LBL_DATE_MODIFIED'=>'�ŏI�X�V��:',
'LBL_DATE_ENTERED'=>'�쐬��:',

'LBL_BACK'=>'�߂�',
'LBL_IMPORT'=>'�C���|�[�g',
'LBL_EXPORT'=>'�G�N�X�|�[�g',

'LBL_CHARSET'=>'Shift_JIS',
'LBL_BROWSER_TITLE'=>'SugarCRM - �I�[�v���E�\�[�X CRM',
'LBL_MY_ACCOUNT'=>'�A�J�E���g',
'LBL_ADMIN'=>'�Ǘ�',
'LBL_LOGOUT'=>'���O�A�E�g',
'LBL_SEARCH'=>'����',
'LBL_LAST_VIEWED'=>'�Q�Ɨ���',
'NTC_WELCOME'=>'�悤����',
'NTC_SUPPORT_SUGARCRM'=>"Support the SugarCRM open source project with a donation through PayPal - it's fast, free and secure!",
'NTC_NO_ITEMS_DISPLAY'=>'����܂���',
'LBL_ALT_HOT_KEY'=>'Alt+',

'LBL_SAVE_BUTTON_TITLE'=>'�ۑ� [Alt+S]',
'LBL_EDIT_BUTTON_TITLE'=>'�ҏW [Alt+E]',
'LBL_EDIT_BUTTON'=>'�ҏW',
'LBL_DUPLICATE_BUTTON_TITLE'=>'�R�s�[ [Alt+U]',
'LBL_DUPLICATE_BUTTON'=>'�R�s�[',
'LBL_DELETE_BUTTON_TITLE'=>'�폜 [Alt+D]',
'LBL_DELETE_BUTTON'=>'�폜',
'LBL_NEW_BUTTON_TITLE'=>'�V�K [Alt+N]',
'LBL_CHANGE_BUTTON_TITLE'=>'�ύX[Alt+G]',
'LBL_CANCEL_BUTTON_TITLE'=>'��� [Alt+X]',
'LBL_SEARCH_BUTTON_TITLE'=>'���� [Alt+Q]',
'LBL_CLEAR_BUTTON_TITLE'=>'���� [Alt+C]',
'LBL_SELECT_BUTTON_TITLE'=>'�I�� [Alt+T]',
'LBL_SAVE_BUTTON_KEY'=>'S',
'LBL_EDIT_BUTTON_KEY'=>'E',
'LBL_DUPLICATE_BUTTON_KEY'=>'U',
'LBL_DELETE_BUTTON_KEY'=>'D',
'LBL_NEW_BUTTON_KEY'=>'N',
'LBL_CHANGE_BUTTON_KEY'=>'G',
'LBL_CANCEL_BUTTON_KEY'=>'X',
'LBL_SEARCH_BUTTON_KEY'=>'Q',
'LBL_CLEAR_BUTTON_KEY'=>'C',
'LBL_SELECT_BUTTON_KEY'=>'T',
'LBL_SAVE_BUTTON_LABEL'=>'�ۑ�',
'LBL_EDIT_BUTTON_LABEL'=>'�ҏW',
'LBL_DUPLICATE_BUTTON_LABEL'=>'�R�s�[',
'LBL_DELETE_BUTTON_LABEL'=>'�폜',
'LBL_NEW_BUTTON_LABEL'=>'�V�K',
'LBL_CHANGE_BUTTON_LABEL'=>'�ύX',
'LBL_CANCEL_BUTTON_LABEL'=>'���',
'LBL_SEARCH_BUTTON_LABEL'=>'����',
'LBL_CLEAR_BUTTON_LABEL'=>'����',
'LBL_SELECT_BUTTON_LABEL'=>'�I��',
'LBL_SELECT_CONTACT_BUTTON_TITLE'=>'�S���� �I�� [Alt+T]',
'LBL_SELECT_CONTACT_BUTTON_KEY'=>'T',
'LBL_SELECT_CONTACT_BUTTON_LABEL'=>'�S���� �I��',
'LBL_SELECT_USER_BUTTON_TITLE'=>'���[�U �I�� [Alt+U]',
'LBL_SELECT_USER_BUTTON_KEY'=>'U',
'LBL_SELECT_USER_BUTTON_LABEL'=>'���[�U �I��',

'LBL_LIST_NAME'=>'���O',
'LBL_LIST_USER_NAME'=>'���[�U��',
'LBL_LIST_EMAIL'=>'���[��',
'LBL_LIST_PHONE'=>'�d�b',
'LBL_LIST_CONTACT_NAME'=>'�S���Җ�',
'LBL_LIST_ACCOUNT_NAME'=>'�ڋq��',
'LBL_USER_LIST'=>'���[�U ���X�g',
'LBL_CONTACT_LIST'=>'�S���� ���X�g',

'LNK_ADVANCED_SEARCH'=>'�g��',
'LNK_BASIC_SEARCH'=>'��{',
'LNK_EDIT'=>'�ҏW',
'LNK_REMOVE'=>'�͂���',
'LNK_DELETE'=>'�폜',
'LNK_LIST_START'=>'�ŏ�',
'LNK_LIST_NEXT'=>'��',
'LNK_LIST_PREVIOUS'=>'�O',
'LNK_LIST_END'=>'�Ō�',
'LBL_LIST_OF'=>'of',
'LNK_PRINT'=>'���',
'LNK_HELP'=>'�w���v',

'NTC_REQUIRED'=>'�K�{����',
'LBL_REQUIRED_SYMBOL'=>'*',
'LBL_CURRENCY_SYMBOL'=>'JPY',
'LBL_THOUSANDS_SYMBOL'=>'K',
'NTC_DATE_FORMAT'=>'(yyyy-mm-dd)',
'NTC_TIME_FORMAT'=>'(24:00)',
'NTC_DATE_TIME_FORMAT'=>'(yyyy-mm-dd 24:00)',
'NTC_DELETE_CONFIRMATION'=>'Are you sure you want to delete this record?',
'ERR_DELETE_RECORD'=>'A record number must be specified to delete the contact.',
'ERR_CREATING_TABLE'=>'Error creating table: ',
'ERR_CREATING_FIELDS'=>'Error filling in additional detail fields: ',
'ERR_MISSING_REQUIRED_FIELDS'=>'Missing required fields:',
'ERR_INVALID_EMAIL_ADDRESS'=>'not a valid email address.',
'ERR_INVALID_DATE_FORMAT'=>'The date format must be: yyyy-mm-dd',
'ERR_INVALID_MONTH'=>'Please enter a valid month.',
'ERR_INVALID_DAY'=>'Please enter a valid day.',
'ERR_INVALID_YEAR'=>'Please enter a valid 4 digit year.',
'ERR_INVALID_DATE'=>'Please enter a valid date.',
'ERR_INVALID_HOUR'=>'Please enter a valid hour.',
'ERR_INVALID_TIME'=>'Please enter a valid time.',
'NTC_CLICK_BACK'=>'Please click the browser back button and fix the error.',
'LBL_LIST_ASSIGNED_USER'=>'������',
'LBL_ASSIGNED_TO'=>'������:',
'LBL_CURRENT_USER_FILTER'=>'�����̃A�C�e���̂�:',
'NTC_LOGIN_MESSAGE'=>"�A�v���P�[�V�����Ƀ��O�C�����ĉ�����",
'LBL_NONE'=>'--None--',
'LBL_EXPORT_ALL'=>'Export All',
);

//the left value is the key stored in the db and the right value is the display value
//to translate, only modify the right value in each key/value pair
$app_list_strings = Array(
//e.g. auf Deutsch 'Contacts'=>'Contakten',
'moduleList' => Array('Home'=>'�z�[��'
				, 'Dashboard'=>'�_�b�V���{�[�h'
				, 'Contacts'=>'�S����'
				, 'Accounts'=>'�ڋq'
				, 'Opportunities'=>'���k'
				, 'Cases'=>'����'
				, 'Notes'=>'�m�[�g���Y�t'
				, 'Calls'=>'�R�[��'
				, 'Emails'=>'���[��'
				, 'Meetings'=>'�~�[�e�B���O'
				, 'Tasks'=>'�^�X�N'),

//e.g. en fran�ais 'Analyst'=>'Analyste',
'account_type_dom' => Array(''=>''
		, 'Analyst'=>'Analyst'
		, 'Competitor'=>'Competitor'
		, 'Customer'=>'Customer'
		, 'Integrator'=>'Integrator'
		, 'Investor'=>'Investor'
		, 'Partner'=>'Partner'
		, 'Press'=>'Press'
		, 'Prospect'=>'Prospect'
		, 'Reseller'=>'Reseller'
		, 'Other'=>'Other'
		),

//e.g. en espa�ol 'Apparel'=>'Ropa',
'industry_dom' => Array(''=>''
		, 'Apparel'=>'Apparel'
		, 'Banking'=>'Banking'
		, 'Biotechnology'=>'Biotechnology'
		, 'Chemicals'=>'Chemicals'
		, 'Communications'=>'Communications'
		, 'Construction'=>'Construction'
		, 'Consulting'=>'Consulting'
		, 'Education'=>'Education'
		, 'Electronics'=>'Electronics'
		, 'Energy'=>'Energy'
		, 'Engineering'=>'Engineering'
		, 'Entertainment'=>'Entertainment'
		, 'Environmental'=>'Environmental'
		, 'Finance'=>'Finance'
		, 'Food & Beverage'=>'Food & Beverage'
		, 'Government'=>'Government'
		, 'Healthcare'=>'Healthcare'
		, 'Hospitality'=>'Hospitality'
		, 'Insurance'=>'Insurance'
		, 'Machinery'=>'Machinery'
		, 'Manufacturing'=>'Manufacturing'
		, 'Media'=>'Media'
		, 'Not For Profit'=>'Not For Profit'
		, 'Recreation'=>'Recreation'
		, 'Retail'=>'Retail'
		, 'Shipping'=>'Shipping'
		, 'Technology'=>'Technology'
		, 'Telecommunications'=>'Telecommunications'
		, 'Transportation'=>'Transportation'
		, 'Utilities'=>'Utilities'
		, 'Other'=>'Other'
		),

'lead_source_dom' => Array(''=>''
		, 'Cold Call'=>'Cold Call'
		, 'Existing Customer'=>'Existing Customer'
		, 'Self Generated'=>'Self Generated'
		, 'Employee'=>'Employee'
		, 'Partner'=>'Partner'
		, 'Public Relations'=>'Public Relations'
		, 'Direct Mail'=>'Direct Mail'
		, 'Conference'=>'Conference'
		, 'Trade Show'=>'Trade Show'
		, 'Web Site'=>'Web Site'
		, 'Word of mouth'=>'Word of mouth'
		, 'Other'=>'Other'
		),

'opportunity_type_dom' => Array(''=>''
		, 'Existing Business'=>'Existing Business'
		, 'New Business'=>'New Business'
		),

//Note:  do not translate opportunity_relationship_type_default_key
//       it is the key for the default opportunity_relationship_type_dom value
'opportunity_relationship_type_default_key' => 'Primary Decision Maker',
'opportunity_relationship_type_dom' => Array(''=>''
		, 'Primary Decision Maker'=>'Primary Decision Maker'
		, 'Business Decision Maker'=>'Business Decision Maker'
		, 'Business Evaluator'=>'Business Evaluator'
		, 'Technical Decision Maker'=>'Technical Decision Maker'
		, 'Technical Evaluator'=>'Technical Evaluator'
		, 'Executive Sponsor'=>'Executive Sponsor'
		, 'Influencer'=>'Influencer'
		, 'Other'=>'Other'
		),

//Note:  do not translate case_relationship_type_default_key
//       it is the key for the default case_relationship_type_dom value
'case_relationship_type_default_key' => 'Primary Contact',
'case_relationship_type_dom' => Array(''=>''
		, 'Primary Contact'=>'���C�� �S����'
		, 'Alternate Contact'=>'�T�u �S����'
		),

'sales_stage_dom' => Array('Prospecting'=>'Prospecting'
		, 'Qualification'=>'Qualification'
		, 'Needs Analysis'=>'Needs Analysis'
		, 'Value Proposition'=>'Value Proposition'
		, 'Id. Decision Makers'=>'Id. Decision Makers'
		, 'Perception Analysis'=>'Perception Analysis'
		, 'Proposal/Price Quote'=>'Proposal/Price Quote'
		, 'Negotiation/Review'=>'Negotiation/Review'
		, 'Closed Won'=>'Closed Won'
		, 'Closed Lost'=>'Closed Lost'
		),

'salutation_dom' => Array(''=>''
		, 'Mr.'=>'Mr.'
		, 'Ms.'=>'Ms.'
		, 'Mrs.'=>'Mrs.'
		, 'Dr.'=>'Dr.'
		, 'Prof.'=>'Prof.'
		),

'task_priority_dom' => Array('High'=>'��'
		, 'Medium'=>'��'
		, 'Low'=>'��'
		),

'task_status_dom' => Array('Not Started'=>'�����{'
		, 'In Progress'=>'��ƒ�'
		, 'Completed'=>'����'
		, 'Pending Input'=>'�ۗ���'
		, 'Deferred'=>'����'
		),

'meeting_status_dom' => Array('Planned'=>'�\��'
		, 'Held'=>'�I��'
		, 'Not Held'=>'���'
		),

'call_status_dom' => Array('Planned'=>'�\��'
		, 'Held'=>'�I��'
		, 'Not Held'=>'���'
		),

//Note:  do not translate case_status_default_key
//       it is the key for the default case_status_dom value
'case_status_default_key' => 'New',
'case_status_dom' => Array('New'=>'New'
		, 'Assigned'=>'Assigned'
		, 'Closed'=>'Closed'
		, 'Pending Input'=>'Pending Input'
		, 'Rejected'=>'Rejected'
		),

'user_status_dom' => Array('Active'=>'�L��'
		, 'Inactive'=>'����'
		),

//Note:  do not translate record_type_default_key
//       it is the key for the default record_type_module value
'record_type_default_key' => 'Accounts',
'record_type_display' => array('Accounts' => '�ڋq',
		'Opportunities' => '���k',
		'Cases' => '����'),
);

?>