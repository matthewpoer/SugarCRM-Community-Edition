<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Contactpersonen',
  'LBL_INVITEE' => 'Rapporteert aan:',
  'LBL_MODULE_TITLE' => 'Contactpersonen: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Contactpersoon Zoeken',
  'LBL_LIST_FORM_TITLE' => 'Contactpersoon Lijst',
  'LBL_NEW_FORM_TITLE' => 'Nieuw Contactpersoon',
  'LBL_CONTACT_OPP_FORM_TITLE' => 'Contactpersoon - Kans:',
  'LBL_CONTACT' => 'Contactpersoon:',
  'LBL_BUSINESSCARD' => 'Business Card',
  'LBL_LIST_NAME' => 'Naam',
  'LBL_LIST_LAST_NAME' => 'Achter Naam',
  'LBL_LIST_CONTACT_NAME' => 'Contactpersoon Naam',
  'LBL_LIST_TITLE' => 'Aanhef',
  'LBL_LIST_ACCOUNT_NAME' => 'Bedrijf Naam',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email',
  'LBL_LIST_OTHER_EMAIL_ADDRESS' => 'Other Email',
  'LBL_LIST_PHONE' => 'Telefoon',
  'LBL_LIST_CONTACT_ROLE' => 'Rol',
  'LBL_LIST_FIRST_NAME' => 'First Name',
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_email2' => 'LBL_LIST_OTHER_EMAIL_ADDRESS',
  'LBL_EXISTING_CONTACT' => 'Used an existing contact',
  'LBL_CREATED_CONTACT' => 'Created a new contact',
  'LBL_EXISTING_ACCOUNT' => 'Used an existing account',
//END DON'T CONVERT
  'LBL_CREATED_ACCOUNT' => 'Created a new account',
  'LBL_CREATED_CALL' => 'Created a new call',
  'LBL_CREATED_MEETING' => 'Created a new meeting',
  'LBL_ADDMORE_BUSINESSCARD' => 'Add another business card',
  'LBL_ADD_BUSINESSCARD' => 'Create From Business Card',
  'LBL_NAME' => 'Naam:',
  'LBL_CONTACT_NAME' => 'Contactpersoon Naam:',
  'LBL_CONTACT_INFORMATION' => 'Contactpersoon Informatie',
  'LBL_FIRST_NAME' => 'Voor Naam:',
  'LBL_OFFICE_PHONE' => 'Telefoon Werk:',
  'LBL_ACCOUNT_NAME' => 'Bedrijf Naam:',
  'LBL_ANY_PHONE' => 'Alternatieve Telefoon:',
  'LBL_PHONE' => 'Telefoon:',
  'LBL_LAST_NAME' => 'Achter Naam:',
  'LBL_MOBILE_PHONE' => 'Mobiel:',
  'LBL_HOME_PHONE' => 'Prive:',
  'LBL_LEAD_SOURCE' => 'Bron contactpersoon:',
  'LBL_OTHER_PHONE' => 'Andere telefoon:',
  'LBL_FAX_PHONE' => 'Fax:',
  'LBL_PRIMARY_ADDRESS_STREET' => 'Primary Address Street:',
  'LBL_PRIMARY_ADDRESS_CITY' => 'Primary Address City:',
  'LBL_PRIMARY_ADDRESS_COUNTRY' => 'Primary Address Country:',
  'LBL_PRIMARY_ADDRESS_STATE' => 'Primary Address State:',
  'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'Primary Address Postal Code:',
  'LBL_ALT_ADDRESS_STREET' => 'Alternate Address Street:',
  'LBL_ALT_ADDRESS_CITY' => 'Alternate Address City:',
  'LBL_ALT_ADDRESS_COUNTRY' => 'Alternate Address Country:',
  'LBL_ALT_ADDRESS_STATE' => 'Alternate Address State:',
  'LBL_ALT_ADDRESS_POSTALCODE' => 'Alternate Address Postal Code:',
  'LBL_TITLE' => 'Titel:',
  'LBL_DEPARTMENT' => 'Afdeling:',
  'LBL_BIRTHDATE' => 'Verjaardag:',
  'LBL_EMAIL_ADDRESS' => 'Email:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Alternatieve Email:',
  'LBL_ANY_EMAIL' => 'Andere Email:',
  'LBL_REPORTS_TO' => 'Rapporteert aan:',
  'LBL_ASSISTANT' => 'Assistent:',
  'LBL_ASSISTANT_PHONE' => 'Assistent Telefoon:',
  'LBL_DO_NOT_CALL' => 'Niet Bellen!:',
  'LBL_EMAIL_OPT_OUT' => 'Email Opt Out:',
  'LBL_PRIMARY_ADDRESS' => 'Hoofd Adres:',
  'LBL_ALTERNATE_ADDRESS' => 'Alternatieve Adres:',
  'LBL_ANY_ADDRESS' => 'Ander Adres:',
  'LBL_CITY' => 'Plaats:',
  'LBL_STATE' => 'Provincie:',
  'LBL_POSTAL_CODE' => 'Postcode:',
  'LBL_COUNTRY' => 'Land:',
  'LBL_DESCRIPTION_INFORMATION' => 'Omschrijving Informatie',
  'LBL_ADDRESS_INFORMATION' => 'Adres Informatie',
  'LBL_DESCRIPTION' => 'Omschrijving:',
  'LBL_CONTACT_ROLE' => 'Rol:',
  'LBL_OPP_NAME' => 'Naam van Kans:',
  'LBL_IMPORT_VCARD' => 'Import vCard',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new contact by importing a vCard from your file system.',
  'LBL_DUPLICATE' => 'Possible Duplicate Contacts',
  'MSG_SHOW_DUPLICATES' => 'Creating this contact may potentialy create a duplicate contact. You may either click on Create Contact to continue creating this new contact with the previously entered data or you may click Cancel.',
  'MSG_DUPLICATE' => 'Creating this contact may potentialy create a duplicate contact. You may either select a contact from the list below or you may click on Create New Contact to continue creating a new contact with the previously entered data.',
  'LNK_CONTACT_LIST' => 'Contacts',
  'LNK_IMPORT_VCARD' => 'Create From vCard',
  'LNK_NEW_CONTACT' => 'Nieuw Contact',
  'LNK_NEW_ACCOUNT' => 'Nieuw Bedrijf',
  'LNK_NEW_OPPORTUNITY' => 'Nieuwe Kans',
  'LNK_NEW_CASE' => 'Nieuwe Zaak',
  'LNK_NEW_NOTE' => 'Nieuwe Notitie',
  'LNK_NEW_CALL' => 'Nieuw Telefoon Gesprek',
  'LNK_NEW_EMAIL' => 'Nieuwe Email',
  'LNK_NEW_MEETING' => 'Nieuwe Afspraak',
  'LNK_NEW_TASK' => 'Nieuwe Taak',
  'LNK_NEW_APPOINTMENT' => 'Create Appointment',
  'NTC_DELETE_CONFIRMATION' => 'Weet u zeker dat u dit record wilt verwijderen?',
  'NTC_REMOVE_CONFIRMATION' => 'Weet u zeker dat u deze contactpersoon wilt verwijderen van deze zaak?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Weet u zeker dat u dit record wilt verwijderen?',
  'ERR_DELETE_RECORD' => 'Er moet een record nummer worden gespecificeerd om dit contact te verwijderen.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Kopieer Hoofd Adres naar alternatieve adres',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Kopieer Alternatieve Adres naar Hoofd adres',
  'LBL_SALUTATION' => 'Salutation',
  'LBL_SAVE_CONTACT' => 'Save Contact',
  'LBL_YAHOO_ID' => 'Yahoo! ID:',
);


?>