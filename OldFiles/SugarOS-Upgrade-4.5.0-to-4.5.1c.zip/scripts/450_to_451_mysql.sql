-- MySQL upgrade script for Sugar 4.5.0 to 4.5.1

--
-- CHANGED TABLES
--

-- accounts
ALTER TABLE `accounts` ADD COLUMN `campaign_id` char(36) NULL AFTER `deleted`;

-- campaign_log
ALTER TABLE `campaign_log` ADD COLUMN `marketing_id` char(36) NULL AFTER `more_information`;
ALTER TABLE `campaign_log` CHANGE COLUMN `campaign_id` `campaign_id` char(36) NULL;

-- campaigns
ALTER TABLE `campaigns` ADD COLUMN `impressions` int(11) NULL default '0' AFTER `status`;
ALTER TABLE `campaigns` ADD COLUMN `frequency` varchar(25) NULL AFTER `content`;

-- contacts
ALTER TABLE `contacts` ADD COLUMN `campaign_id` char(36) NULL AFTER `invalid_email`;

-- emails
ALTER TABLE `emails` CHANGE `description` `description` longtext, CHANGE `description_html` `description_html` longtext, CHANGE `raw_source` `raw_source` longtext;

-- email_templates




ALTER TABLE `email_templates` ADD COLUMN `text_only` tinyint(1) default '0' AFTER `deleted`;

-- emails_contacts
ALTER TABLE `emails_contacts` ADD COLUMN `campaign_data` text NULL AFTER `date_modified`;

-- emails_leads
ALTER TABLE `emails_leads` ADD COLUMN `campaign_data` text NULL AFTER `date_modified`;

-- emails_prospects
ALTER TABLE `emails_prospects` ADD COLUMN `campaign_data` text NULL AFTER `date_modified`;

-- emails_users
ALTER TABLE `emails_users` ADD COLUMN `campaign_data` text NULL AFTER `date_modified`;

-- notes
ALTER TABLE `notes` ADD COLUMN `embed_flag` tinyint(1) NOT NULL default '0' AFTER `portal_flag`;

-- opportunities
ALTER TABLE `opportunities` ADD COLUMN `campaign_id` char(36) NULL AFTER `opportunity_type`;









-- prospects
ALTER TABLE `prospects` ADD COLUMN `campaign_id` char(36) NULL AFTER `account_name`;

-- user_preferences
ALTER TABLE `user_preferences` CHANGE COLUMN `assigned_user_id` `assigned_user_id` char(36) NOT NULL;






-- upgrade_history
ALTER TABLE `upgrade_history` ADD COLUMN `name` varchar(255) NULL AFTER `version`;
ALTER TABLE `upgrade_history` ADD COLUMN `description` text NULL AFTER `name`;
ALTER TABLE `upgrade_history` ADD COLUMN `id_name` varchar(255) NULL AFTER `description`;
ALTER TABLE `upgrade_history` ADD COLUMN `manifest` text NULL AFTER `id_name`;






