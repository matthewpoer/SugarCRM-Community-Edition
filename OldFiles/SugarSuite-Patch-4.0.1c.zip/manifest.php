<?php
// created: 2006-02-21 17:42:11
$manifest = array (
  'acceptable_sugar_flavors' => 
  array (
    0 => 'OS',
  ),
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '^4\\.0\\.1[ab]?$',
    ),
  ),
  'author' => 'SugarCRM, Inc.',
  'copy_files' => 
  array (
    'from_dir' => 'SugarSuite-Patch-4.0.1c',
    'to_dir' => '',
    'force_copy' => 
    array (
    ),
  ),
  'description' => 'Sugar 4.0.1c upgrade',
  'icon' => '',
  'is_uninstallable' => false,
  'name' => 'SugarSuite',
  'published_date' => '2006-02-21 17:42:11',
  'type' => 'patch',
  'version' => '4.0.1c',
);
?>
