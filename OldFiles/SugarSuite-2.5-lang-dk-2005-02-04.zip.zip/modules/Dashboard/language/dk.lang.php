<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Dashboard',
  'LBL_MODULE_TITLE' => 'Dashboard: Home',
  'LBL_SALES_STAGE_FORM_TITLE' => 'Total Pipeline udfra Salgsfase',
  'LBL_SALES_STAGE_FORM_DESC' => 'Viser accumuleret mulig forretningsbel�b pr. valgt salgsfase for valgte brugere hvor forventet lukningsdato ligger i specificeret datointerval.',
  'LBL_YEAR_BY_OUTCOME' => 'Pipeline By Month By Outcome',
  'LBL_MONTH_BY_OUTCOME_DESC' => 'Viser accumuleret mulig forretningsbel�b pr. md. pr. afkast for valgte brugere hvor forventet lukningsdato ligger i specificeret datointerval.  Afkast er baseret p� om hvorvidt salgsfasen er lukket vundet, lukket tabt eller hvilkensomhelst anden v�rdi.',
  'LBL_LEAD_SOURCE_FORM_TITLE' => 'Total Pipeline udfra Kilde',
  'LBL_LEAD_SOURCE_FORM_DESC' => 'Viser accumuleret mulig forretningsbel�b pr. lead kilde for valgte brugere.',
  'LBL_LEAD_SOURCE_BY_OUTCOME' => 'Alle mulige forretninger pr. lead kilde pr. afkast',
  'LBL_LEAD_SOURCE_BY_OUTCOME_DESC' => 'Viser accumuleret mulig forretningsbel�b pr. valgt lead kilde pr. afkast for valgte brugere hvor the forventet lukningsdato ligger i specificeret datointerval.  Afkast er baseret p� om hvorvidt salgsfasen er lukket vundet, lukket tabt eller hvilkensomhelst anden v�rdi.',
  'LBL_PIPELINE_FORM_TITLE_DESC' => 'Viser accumuleret mulig forretningsbel�b pr. valgt salgsfase for mulige forretninger hvor forventet lukningsdato ligger i specificeret datointerval.',
  'LBL_DATE_RANGE' => 'Dato interval er',
  'LBL_DATE_RANGE_TO' => 'til',
  'ERR_NO_OPPS' => 'Lav nogle Forretninger f�r du kan se Forretningsdiagram.',
  'LBL_TOTAL_PIPELINE' => 'Total i Pipeline er: ',
  'LBL_ALL_OPPORTUNITIES' => 'Total bel�b for alle mulige forretninger er ',
  'LBL_OPP_SIZE' => 'Maalestok er 1K',
  'LBL_OPP_THOUSANDS' => 'K',
  'NTC_NO_LEGENDS' => 'Ingen',
  'LBL_LEAD_SOURCE_OTHER' => 'Andet',
  'LBL_EDIT' => 'Ret',
  'LBL_REFRESH' => 'Opdat�r',
  'LBL_CREATED_ON' => 'Sidst k�rt  ',
  'LBL_OPPS_WORTH' => 'opportunities worth',
  'LBL_OPPS_IN_STAGE' => 'mulige forretninger hvor salgsfase er',
  'LBL_OPPS_IN_LEAD_SOURCE' => 'mulige forretninger hvor lead kilde er',
  'LBL_OPPS_OUTCOME' => 'mulige forretninger hvor afkast er',
  'LBL_ROLLOVER_DETAILS' => 'Rollover a bar for details.',
  'LBL_ROLLOVER_WEDGE_DETAILS' => 'Rollover a wedge for details.',
  'LBL_USERS' => 'Brugere',
  'LBL_SALES_STAGES' => 'Salgsfaser',
  'LBL_LEAD_SOURCES' => 'Lead kilder',
  'LBL_DATE_START' => 'Start Dato',
  'LBL_DATE_END' => 'Slut Dato',
  'LBL_YEAR' => 'Year:',
  'LNK_NEW_CONTACT' => 'Ny Kontakt',
  'LNK_NEW_ACCOUNT' => 'Nyt Firma',
  'LNK_NEW_OPPORTUNITY' => 'Ny Mulig Forretning',
  'LNK_NEW_QUOTE' => 'Create Quote',
  'LNK_NEW_LEAD' => 'Create Lead',
  'LNK_NEW_CASE' => 'Ny Sag',
  'LNK_NEW_NOTE' => 'Ny Bem�rkning',
  'LNK_NEW_CALL' => 'Ny Samtale',
  'LNK_NEW_MEETING' => 'Nyt M�de',
  'LNK_NEW_TASK' => 'Ny Opgave',
  'LNK_NEW_ISSUE' => 'Report Bug',
  'LBL_MONTH_BY_OUTCOME' => 'Pipeline pr. md. pr. afkast',
  'LNK_NEW_EMAIL' => 'Ny Email',
);


?>