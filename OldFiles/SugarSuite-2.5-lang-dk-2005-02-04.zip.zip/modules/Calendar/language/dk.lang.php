<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Calendar',
  'LBL_MODULE_TITLE' => 'Calendar',
  'LNK_NEW_CALL' => 'Lave opringning',
  'LNK_NEW_MEETING' => 'Lave M�de',
  'LNK_NEW_APPOINTMENT' => 'Aftale',
  'LNK_NEW_TASK' => 'Lave opgave',
  'LNK_CALL_LIST' => 'Opringninger',
  'LNK_MEETING_LIST' => 'M�der',
  'LNK_TASK_LIST' => 'Opgaver',
  'LNK_VIEW_CALENDAR' => 'I dag',
  'LBL_MONTH' => 'M�ned',
  'LBL_DAY' => 'Dag',
  'LBL_YEAR' => '�r',
  'LBL_WEEK' => 'Uge',
  'LBL_PREVIOUS_MONTH' => 'Sidste M�ned',
  'LBL_PREVIOUS_DAY' => 'Foreg�ende dag',
  'LBL_PREVIOUS_YEAR' => 'Foreg�ende �r',
  'LBL_PREVIOUS_WEEK' => 'Foreg�ende uge',
  'LBL_NEXT_MONTH' => 'N�ste m�ned',
  'LBL_NEXT_DAY' => 'N�ste dag',
  'LBL_NEXT_YEAR' => 'N�ste �r',
  'LBL_NEXT_WEEK' => 'N�ste uge',
  'LBL_AM' => 'AM',
  'LBL_PM' => 'PM',
  'LBL_SCHEDULED' => 'Planlagt',
  'LBL_BUSY' => 'Optaget',
  'LBL_CONFLICT' => 'Konflikt',
  'LBL_USER_CALENDARS' => 'Brugeres Kalender',
);

$mod_list_strings = array (
  'dom_cal_weekdays' => 
  array (
    0 => 'S�n',
    1 => 'Man',
    2 => 'Tir',
    3 => 'Ons',
    4 => 'Tor',
    5 => 'Fre',
    6 => 'L�r',
  ),
  'dom_cal_weekdays_long' => 
  array (
    0 => 'S�ndag',
    1 => 'Mandag',
    2 => 'Tirsdag',
    3 => 'Onsdag',
    4 => 'Torsdag',
    5 => 'Fredag',
    6 => 'L�rdag',
  ),
  'dom_cal_month' => 
  array (
    0 => '',
    1 => 'Jan',
    2 => 'Feb',
    3 => 'Mar',
    4 => 'Apr',
    5 => 'Maj',
    6 => 'Jun',
    7 => 'Jul',
    8 => 'Aug',
    9 => 'Sep',
    10 => 'Okt',
    11 => 'Nov',
    12 => 'Dec',
  ),
  'dom_cal_month_long' => 
  array (
    0 => '',
    1 => 'Januar',
    2 => 'Februar',
    3 => 'Marts',
    4 => 'April',
    5 => 'Maj',
    6 => 'Juni',
    7 => 'Juli',
    8 => 'August',
    9 => 'September',
    10 => 'Oktober',
    11 => 'November',
    12 => 'December',
  ),
);


?>