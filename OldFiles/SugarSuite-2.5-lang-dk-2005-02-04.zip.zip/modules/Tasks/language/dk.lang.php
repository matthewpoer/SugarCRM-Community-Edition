<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Opgaver',
  'LBL_TASK' => 'Opgaver: ',
  'LBL_MODULE_TITLE' => ' Opgaver : Hjem',
  'LBL_SEARCH_FORM_TITLE' => ' S�g Opgave',
  'LBL_LIST_FORM_TITLE' => ' Opgaveliste',
  'LBL_NEW_FORM_TITLE' => ' Ny Opgave',
  'LBL_NEW_FORM_SUBJECT' => 'Vedr�rende:',
  'LBL_NEW_FORM_DUE_DATE' => 'Slutdato:',
  'LBL_NEW_FORM_DUE_TIME' => 'Sluttid:',
  'LBL_NEW_TIME_FORMAT' => '(24:00)',
  'LBL_LIST_CLOSE' => 'Afslut',
  'LBL_LIST_SUBJECT' => 'Vedr�rende',
  'LBL_LIST_CONTACT' => 'Kontakt',
  'LBL_LIST_PRIORITY' => 'Priority',
  'LBL_LIST_RELATED_TO' => 'Relateret til',
  'LBL_LIST_DUE_DATE' => 'Slutdato',
  'LBL_LIST_DUE_TIME' => 'Sluttid',
  'LBL_SUBJECT' => 'Vedr�rende:',
  'LBL_STATUS' => 'Status:',
  'LBL_DUE_DATE' => 'Slutdato:',
  'LBL_DUE_TIME' => 'Due Time:',
  'LBL_PRIORITY' => 'Prioritet:',
  'LBL_COLON' => ':',
  'LBL_DUE_DATE_AND_TIME' => 'Slutdato og tid:',
  'LBL_START_DATE_AND_TIME' => 'Start Date & Time:',
  'LBL_START_DATE' => 'Start Date:',
  'LBL_START_TIME' => 'Start Time:',
  'DATE_FORMAT' => '(����-mm-dd 24:00)',
  'LBL_NONE' => 'ingen',
  'LBL_CONTACT' => 'Kontakt:',
  'LBL_PHONE' => 'Telefon:',
  'LBL_EMAIL' => 'Email:',
  'LBL_DESCRIPTION_INFORMATION' => 'Beskrivelse',
  'LBL_DESCRIPTION' => 'Beskrivelse:',
  'LBL_NAME' => 'Navn:',
  'LBL_CONTACT_NAME' => 'Kontakt Navn: ',
  'LBL_LIST_COMPLETE' => 'Slut:',
  'LBL_LIST_STATUS' => 'Status:',
  'LBL_DATE_DUE_FLAG' => 'No Due Date',
  'LBL_DATE_START_FLAG' => 'No Start Date',
  'ERR_DELETE_RECORD' => 'Et Postnummer skal angives for at slette Opgaven.',
  'ERR_INVALID_HOUR' => 'Angiv time mellem 0 og 24',
  'LBL_DEFAULT_STATUS' => 'Ej p�begyndt',
  'LBL_DEFAULT_PRIORITY' => 'Medium',
  'LBL_LIST_MY_TASKS' => 'My Open Tasks',
  'LNK_NEW_CALL' => 'Ny Samtale',
  'LNK_NEW_MEETING' => 'Nyt M�de',
  'LNK_NEW_TASK' => 'Ny Opgave',
  'LNK_NEW_NOTE' => 'Ny Bem�rkning',
  'LNK_NEW_EMAIL' => 'Ny Email',
  'LNK_CALL_LIST' => 'Calls',
  'LNK_MEETING_LIST' => 'Meetings',
  'LNK_TASK_LIST' => 'Tasks',
  'LNK_NOTE_LIST' => 'Notes',
  'LNK_EMAIL_LIST' => 'Emails',
  'LNK_VIEW_CALENDAR' => 'Today',
  'LBL_CONTACT_FIRST_NAME' => 'Contact First Name',
  'LBL_CONTACT_LAST_NAME' => 'Contact Last Name',
  'LNK_NEW_CONTACT' => 'Ny Kontakt',
  'LNK_NEW_ACCOUNT' => 'Nyt Firma',
  'LNK_NEW_OPPORTUNITY' => 'Ny Mulig Forretning',
  'LNK_NEW_CASE' => 'Ny Sag',
);


?>