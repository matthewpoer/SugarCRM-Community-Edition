<?php
	// $Id: sugar_version.php,v 1.31.2.6 2005/04/13 23:11:51 bob Exp $
	$sugar_version = '2.5.1d';
?>
