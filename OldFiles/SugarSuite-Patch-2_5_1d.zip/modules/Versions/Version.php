<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /var/cvsroot/sugarcrm/modules/Versions/Version.php,v 1.1 2005/02/12 02:54:35 majed Exp $
 * Description:
 ********************************************************************************/


include_once('config.php');
require_once('include/logging.php');
require_once('include/database/PearDatabase.php');
require_once('data/SugarBean.php');


require_once('include/utils.php');

class Version extends SugarBean {
	// Stored fields
	var $id;
	var $deleted;
	var $date_entered;
	var $date_modified;
	var $modified_user_id;
	var $created_by;
	var $created_by_name;
	var $modified_by_name;
	var $field_name_map;
	var $name;
	var $file_version;
	var $db_version;
	var $table_name = 'versions';

	var $object_name = "Versions";

	var $new_schema = true;

	var $column_fields = Array("id"
		,"name"
		,"file_version"
		,'db_version'
		,"date_entered"
		,"date_modified"
		,"modified_user_id"
		,"created_by"
		);
/*
	DO NOT DEPEND ON THIS THIS DATA STRUCTURE
	IT IS ONLY TEMPORARY AND MAY NOT BE SUPPORTED IN FUTURE RELEASES
*/
	var $field_defs = array(
		array("name"=>"name", "vname"=>"LBL_NAME","type"=>"varchar",'len'=>'255'),
		array("name"=>"file_version", "vname"=>"LBL_NAME","type"=>"varchar",'len'=>'255'),
		array("name"=>"db_version", "vname"=>"LBL_NAME","type"=>"varchar",'len'=>'255'),
        array('name'=>'date_entered','vname'=>'LBL_DATE_ENTERED','type'=>'date'),
        array('name'=>'date_modified','vname'=>'LBL_DATE_MODIFIED','type'=>'date'),
		array('name'=>'created_by','rname'=>'user_name',
			'id_name'=>'created_by','vname'=>'LBL_CREATED',
			'type'=>'created_by','table'=>'users',
			'isnull'=>'false'),
		array('name'=>'modified_user_id','rname'=>'user_name',
			'id_name'=>'modified_user_id','vname'=>'LBL_MODIFIED',
			'type'=>'modified_by_name','table'=>'users',
			'isnull'=>'false'),

		);


	// This is used to retrieve related fields from form posts.
	var $additional_column_fields = Array();

	


	// This is the list of fields that are in the lists.
	var $list_fields = array('id', 'name', 'file_version', 'db_version', );
	// This is the list of fields that are required
	var $required_fields =  array( );
	


	function Version() {

		$this->log = LoggerManager::getLogger('version');
		$this->db = new PearDatabase();
		foreach ($this->field_defs as $field)
		{
			$this->field_name_map[$field['name']] = $field;
		}



	}

	

	function create_tables () {
		$query =  "CREATE TABLE $this->table_name ( ";
		$query .= 'id             		char(36) NOT NULL';
		$query .= ',deleted bool 		NOT NULL default 0';
		$query .= ',date_entered 		datetime NOT NULL';
		$query .= ',date_modified 		datetime NOT NULL';
		$query .= ',modified_user_id 	char(36) NOT NULL';
		$query .=', created_by char(36)';
		$query .= ',name    			char(255) NOT NULL';
		$query .= ',file_version    			char(255) NOT NULL';
		$query .= ',db_version    			char(255) NOT NULL';
		$query .= ',KEY (id)';
		$query .= ',PRIMARY KEY (id)';
        $query .= ');';

		$this->db->query($query,true,"Error creating table: ");


		// Create the indexes
		$this->create_index("create index idx_version on $this->table_name (name, deleted)");
		require_once('modules/Versions/InstallDefaultVersions.php');
	}

	function drop_tables () {
		$query = 'DROP TABLE IF EXISTS '.$this->table_name;

		$this->db->query($query);
	}



	
	/**
		builds a generic search based on the query string using or
		do not include any $this-> because this is called on without having the class instantiated
	*/
	function build_generic_where_clause ($the_query_string) {
	$where_clauses = Array();
	$the_query_string = addslashes($the_query_string);
	array_push($where_clauses, "name like '$the_query_string%'");
	$the_where = "";
	foreach($where_clauses as $clause)
	{
		if($the_where != "") $the_where .= " or ";
		$the_where .= $clause;
	}


	return $the_where;
}


function is_expected_version($expected_version){
	foreach($expected_version as $name=>$val){
		if($this->$name != $val){
			return false;	
		}	
	}
	return true;
		
}

function get_profile(){
	return array('name'=> $this->name, 'file_version'=> $this->file_version, 'db_version'=>$this->db_version);	
}






}

?>
