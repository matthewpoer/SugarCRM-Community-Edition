<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/include/language/en_us.lang.php,v 1.89 2004/10/25 02:32:20 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Contatti',
  'LBL_INVITEE' => 'Direct Reports',
  'LBL_MODULE_TITLE' => 'Contatti: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Cerca un Contatto',
  'LBL_LIST_FORM_TITLE' => 'Elenco Contatti',
  'LBL_NEW_FORM_TITLE' => 'Nuovo Contatto',
  'LBL_CONTACT_OPP_FORM_TITLE' => 'Contatto-Opportunità :',
  'LBL_CONTACT' => 'Contatto:',
  'LBL_BUSINESSCARD' => 'Business Card',
  'LBL_LIST_NAME' => 'Nome',
  'LBL_LIST_LAST_NAME' => 'Cognome',
  'LBL_LIST_CONTACT_NAME' => 'Nome Contatto',
  'LBL_LIST_TITLE' => 'Funzione',
  'LBL_LIST_ACCOUNT_NAME' => 'Nome Cliente',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email',
  'LBL_LIST_OTHER_EMAIL_ADDRESS' => 'Other Email',
  'LBL_LIST_PHONE' => 'Telefono',
  'LBL_LIST_CONTACT_ROLE' => 'Ruolo',
  'LBL_LIST_FIRST_NAME' => 'First Name',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_email2' => 'LBL_LIST_OTHER_EMAIL_ADDRESS',
//END DON'T CONVERT
  'LBL_EXISTING_CONTACT' => 'Used an existing contact',
  'LBL_CREATED_CONTACT' => 'Created a new contact',
  'LBL_EXISTING_ACCOUNT' => 'Used an existing account',
  'LBL_CREATED_ACCOUNT' => 'Created a new account',
  'LBL_CREATED_CALL' => 'Created a new call',
  'LBL_CREATED_MEETING' => 'Created a new meeting',
  'LBL_ADDMORE_BUSINESSCARD' => 'Add another business card',
  'LBL_ADD_BUSINESSCARD' => 'Create From Business Card',
  'LBL_NAME' => 'Nome:',
  'LBL_CONTACT_NAME' => 'Nome Contatto:',
  'LBL_CONTACT_INFORMATION' => 'Informazioni sul Contatto ',
  'LBL_FIRST_NAME' => 'Nome:',
  'LBL_OFFICE_PHONE' => 'Telefono Ufficio:',
  'LBL_ACCOUNT_NAME' => 'Nome Cliente:',
  'LBL_ANY_PHONE' => 'Altro Telefono:',
  'LBL_PHONE' => 'Telefono:',
  'LBL_LAST_NAME' => 'Cognome:',
  'LBL_MOBILE_PHONE' => 'Telefono Cellulare:',
  'LBL_HOME_PHONE' => 'Telefono Personale:',
  'LBL_LEAD_SOURCE' => 'Fonte del lead:',
  'LBL_OTHER_PHONE' => 'Altro Telefono:',
  'LBL_FAX_PHONE' => 'Fax:',
  'LBL_TITLE' => 'Funzione:',
  'LBL_DEPARTMENT' => 'Divisione:',
  'LBL_BIRTHDATE' => 'Data di nascita:',
  'LBL_EMAIL_ADDRESS' => 'Email:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Altra Email:',
  'LBL_ANY_EMAIL' => 'Email alternativa:',
  'LBL_REPORTS_TO' => 'Riporta a:',
  'LBL_ASSISTANT' => 'Assistente:',
  'LBL_ASSISTANT_PHONE' => 'Telefono Assistente:',
  'LBL_DO_NOT_CALL' => 'Non chiamare:',
  'LBL_EMAIL_OPT_OUT' => 'Non inviare email:',
  'LBL_PRIMARY_ADDRESS' => 'Indirizzo principale:',
  'LBL_ALTERNATE_ADDRESS' => 'Altro Indirizzo:',
  'LBL_ANY_ADDRESS' => 'Indirizzo alternativo:',
  'LBL_CITY' => 'CittÃ :',
  'LBL_STATE' => 'Stato/Provincia:',
  'LBL_POSTAL_CODE' => 'C.A.P.:',
  'LBL_COUNTRY' => 'Nazione:',
  'LBL_DESCRIPTION_INFORMATION' => 'Descrizione',
  'LBL_ADDRESS_INFORMATION' => 'Address Information',
  'LBL_DESCRIPTION' => 'Descrizione:',
  'LBL_CONTACT_ROLE' => 'Ruolo:',
  'LBL_OPP_NAME' => 'Nome Opportunità :',
  'LBL_IMPORT_VCARD' => 'Import vCard',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new contact by importing a vCard from your file system.',
  'LBL_DUPLICATE' => 'Possible Duplicate Contacts',
  'MSG_DUPLICATE' => 'Creating this contact may potentialy create a duplicate contact. You may either select a contact from the list below or you may click on Create New Contact to continue creating a new contact with the previously entered data.',
  'LNK_CONTACT_LIST' => 'Contacts',
  'LNK_IMPORT_VCARD' => 'Create From vCard',
  'LNK_NEW_CONTACT' => 'Nuovo Contatto',
  'LNK_NEW_ACCOUNT' => 'Nuovo Cliente',
  'LNK_NEW_OPPORTUNITY' => 'Nuova Opportunità',
  'LNK_NEW_CASE' => 'Nuovo Ticket Supporto',
  'LNK_NEW_NOTE' => 'Nuova Nota',
  'LNK_NEW_CALL' => 'Nuova Chiamata',
  'LNK_NEW_EMAIL' => 'Nuova Email',
  'LNK_NEW_MEETING' => 'Nuova Riunione',
  'LNK_NEW_TASK' => 'Nuovo Task',
  'LNK_NEW_APPOINTMENT' => 'Create Appointment',
  'NTC_DELETE_CONFIRMATION' => 'Sei sicuro di voler eliminare questa registrazione ?',
  'NTC_REMOVE_CONFIRMATION' => 'Sei sicuro di voler eliminare questo contatto per questo ticket ?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Sei sicuro di voler eliminare questa registrazione come rapporto diretto ?',
  'ERR_DELETE_RECORD' => 'Devi specificare un numero record per eliminare il cliente.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Copia l\'indirizzo primario in quello alternativo',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Copia l\'indirizzo alternativo in quello primario',
  'LBL_SALUTATION' => 'Salutation',
  'LBL_DIRECT_REPORTS_FORM_NAME' => 'Rapporti Diretti',
  'LBL_YAHOO_ID' => 'Utenza Yahoo! messenger:',
  'NTC_REMOVE_OPP_CONFIRMATION' => 'Sei sicuro di voler eliminare questo contatto per questa opportunitÃ  ?',
);


?>