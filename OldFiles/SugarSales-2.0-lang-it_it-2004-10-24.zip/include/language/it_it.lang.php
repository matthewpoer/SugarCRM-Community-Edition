<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/include/language/en_us.lang.php,v 1.89 2004/10/25 02:32:20 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

//to translate, only modify the right value in each key/value pair
$app_list_strings = array (
//e.g. auf Deutsch 'Contacts'=>'Contakten',
  'moduleList' => 
  array (
    'Home' => 'Home',
    'Dashboard' => 'Tableau de bord',
    'Contacts' => 'Contatti',
    'Accounts' => 'Clienti',
    'Opportunities' => 'Opportunità ',
    'Cases' => 'Ticket Supporto',
    'Notes' => 'Note',
    'Calls' => 'Chiamata',
    'Emails' => 'Email',
    'Meetings' => 'Riunioni',
    'Tasks' => 'Task',
    'Calendar' => 'Calendar',
    'Leads' => 'Leads',
    'Activities' => 'Activities',
  ),
  'account_type_dom' => 
  array (
    '' => '',
    'Analyst' => 'Analista',
    'Competitor' => 'Concorrenza',
  //e.g. en fran�ais 'Analyst'=>'Analyste',
    'Customer' => 'Cliente',
    'Integrator' => 'Integratore',
    'Investor' => 'Investitore',
    'Partner' => 'Partner',
    'Press' => 'Stampa',
    'Prospect' => 'Prospect',
    'Reseller' => 'Rivenditore',
    'Other' => 'Altro',
  ),
  'industry_dom' => 
  array (
    '' => '',
    'Apparel' => 'Tessile',
    'Banking' => 'Banca',
  //e.g. en espa�ol 'Apparel'=>'Ropa',
    'Biotechnology' => 'Biotecnologie',
    'Chemicals' => 'Industria Chimica',
    'Communications' => 'Communicazioni',
    'Construction' => 'Construzioni',
    'Consulting' => 'Consulenza',
    'Education' => 'Educazione',
    'Electronics' => 'Informatica - Elettronica',
    'Energy' => 'Energia',
    'Engineering' => 'Ingenieria',
    'Entertainment' => 'Cultura-Stampa',
    'Environmental' => 'Ambiente',
    'Finance' => 'Finanza',
    'Food & Beverage' => 'Agro-alimentare',
    'Government' => 'Pubblica Amministratione',
    'Healthcare' => 'SanitÃ ',
    'Hospitality' => 'OspitalitÃ ',
    'Insurance' => 'Assicurazione',
    'Machinery' => 'Industria Compon.',
    'Manufacturing' => 'Industria Manifatt.',
    'Media' => 'Media',
    'Not For Profit' => 'Non Profit',
    'Recreation' => 'Ricreazione',
    'Retail' => 'Commercio Retail',
    'Shipping' => 'Trasporti e Logistica',
    'Technology' => 'Tecnologie',
    'Telecommunications' => 'Telecommunicazioni',
    'Transportation' => 'Viaggi e turismo',
    'Utilities' => 'Servizi e utility',
    'Other' => 'Altro',
  ),
  'lead_source_dom' => 
  array (
    '' => '',
    'Cold Call' => 'Chiamata a Freddo',
    'Existing Customer' => 'Cliente Esistente',
    'Self Generated' => 'Auto Generata',
    'Employee' => 'Impiegato',
    'Partner' => 'Partner',
    'Public Relations' => 'Pubbliche Relazioni',
    'Direct Mail' => 'Direct Mailing',
    'Conference' => 'Conferenza',
    'Trade Show' => 'Trade Show',
    'Web Site' => 'Sito web',
    'Word of mouth' => 'Segnalazione personale',
    'Other' => 'Altro',
  ),
  'opportunity_type_dom' => 
  array (
    '' => '',
    'Existing Business' => 'Business esistente',
    'New Business' => 'Nuovo affare',
  ),
  'opportunity_relationship_type_default_key' => 'Primary Decision Maker',
  'opportunity_relationship_type_dom' => 
  array (
    '' => '',
    'Primary Decision Maker' => 'Decision Maker Primario',
//       it is the key for the default opportunity_relationship_type_dom value
    'Business Decision Maker' => 'Decision Maker - business',
    'Business Evaluator' => 'Valutatore - Business',
    'Technical Decision Maker' => 'Decision Maker - Tecnico',
    'Technical Evaluator' => 'Valutatore - Tecnico',
    'Executive Sponsor' => 'Sponsor',
    'Influencer' => 'Esercita Influenza',
    'Other' => 'Altro',
  ),
  'case_relationship_type_default_key' => 'Contact Principal',
  'case_relationship_type_dom' => 
  array (
    '' => '',
    'Primary Contact' => 'Contatto Principale',
//       it is the key for the default case_relationship_type_dom value
    'Alternate Contact' => 'Contato Alternativo',
  ),
  'sales_stage_dom' => 
  array (
    'Prospecting' => 'Prospect',
    'Qualification' => 'Qualificazione',
    'Needs Analysis' => 'Analisi Bisogni',
    'Value Proposition' => 'Propos. Valore',
    'Id. Decision Makers' => 'Id. Decision Maker',
    'Perception Analysis' => 'Analisi Percezione',
    'Proposal/Price Quote' => 'Proposta Economica',
    'Negotiation/Review' => 'Negoziazione/Review',
    'Closed Won' => 'Chiuso Vinto',
    'Closed Lost' => 'Chiuso Perso',
  ),
  'activity_dom' => 
  array (
    'Call' => 'Call',
    'Meeting' => 'Meeting',
    'Task' => 'Task',
    'Email' => 'Email',
    'Note' => 'Note',
  ),
  'salutation_dom' => 
  array (
    '' => '',
    'Mr.' => 'Sig.',
    'Ms.' => 'Sig.na.',
    'Mrs.' => 'Sig.ra.',
    'Dr.' => 'Dr.',
    'Prof.' => 'Prof.',
  ),
  'task_priority_dom' => 
  array (
    'High' => 'Alto',
    'Medium' => 'Medio',
    'Low' => 'Basso',
  ),
  'task_status_dom' => 
  array (
    'Not Started' => 'Non Iniziato',
    'In Progress' => 'In Corso',
    'Completed' => 'Completato',
    'Pending Input' => 'In attesa di azione',
    'Deferred' => 'Rimandato',
  ),
  'meeting_status_dom' => 
  array (
    'Planned' => 'Pianificato',
    'Held' => 'Confermato',
    'Not Held' => 'Non Confermato',
  ),
  'call_status_dom' => 
  array (
    'Planned' => 'Pianificato',
    'Held' => 'Confermato',
    'Not Held' => 'Non Confermato',
  ),
  'call_direction_dom' => 
  array (
    'Inbound' => 'Inbound',
    'Outbound' => 'Outbound',
  ),
  'lead_status_dom' => 
  array (
    '' => '',
    'New' => 'New',
    'Assigned' => 'Assigned',
    'In Process' => 'In Process',
    'Converted' => 'Converted',
    'Recycled' => 'Recycled',
    'Dead' => 'Dead',
  ),
  'lead_status_noblank_dom' => 
  array (
    'New' => 'New',
    'Assigned' => 'Assigned',
    'In Process' => 'In Process',
    'Converted' => 'Converted',
    'Recycled' => 'Recycled',
    'Dead' => 'Dead',
  ),
  'case_status_default_key' => 'New',
  'case_status_dom' => 
  array (
    'New' => 'Nuovo',
    'Assigned' => 'Assegnato',
//       it is the key for the default case_status_dom value
    'Closed' => 'Chiuso',
    'Pending Input' => 'In attesa di azione',
    'Rejected' => 'Respinto',
  ),
  'case_priority_default_key' => 'P2',
  'case_priority_dom' => 
  array (
    'P1' => 'High',
    'P2' => 'Medium',
    'P3' => 'Low',
  ),
  'user_status_dom' => 
  array (
    'Active' => 'Attivo',
    'Inactive' => 'Inattivo',
  ),
  'record_type_default_key' => 'Accounts',
  'record_type_display' => 
  array (
    'Accounts' => 'Cliente',
    'Opportunities' => 'OpportunitÃ ',
//       it is the key for the default record_type_module value
    'Cases' => 'Ticket Supporto',
    'Leads' => 'Lead',
  ),
  'notifymail_sendtype' => 
  array (
    'sendmail' => 'sendmail',
    'SMTP' => 'SMTP',
  ),
);

$app_strings = array (
  'LBL_CHARSET' => 'UTF-8',
  'LBL_BROWSER_TITLE' => 'SugarCRM - CRM commerciale Open Source',
  'LBL_MY_ACCOUNT' => 'Il mio account',
  'LBL_ADMIN' => 'Amministra',
  'LBL_LOGOUT' => 'Logout',
  'LBL_SEARCH' => 'Cerca',
  'LBL_LAST_VIEWED' => 'Ultime visualizzazioni',
  'NTC_WELCOME' => 'Benvenuto',
  'NTC_SUPPORT_SUGARCRM' => 'Supporta il progetto open source SugarCRM con una donazione via PayPal - è rapido, gratuito e sicuro !',
  'NTC_NO_ITEMS_DISPLAY' => 'nessuno',
  'LBL_ALT_HOT_KEY' => 'Alt+',
  'LBL_SAVE_BUTTON_TITLE' => 'Salva [Alt+S]',
  'LBL_EDIT_BUTTON_TITLE' => 'Modifica [Alt+E]',
  'LBL_EDIT_BUTTON' => 'Modifica',
  'LBL_DUPLICATE_BUTTON_TITLE' => 'Duplica [Alt+U]',
  'LBL_DUPLICATE_BUTTON' => 'Duplica',
  'LBL_DELETE_BUTTON_TITLE' => 'Elimina [Alt+D]',
  'LBL_DELETE_BUTTON' => 'Elimina',
  'LBL_NEW_BUTTON_TITLE' => 'Nuovo [Alt+N]',
  'LBL_CHANGE_BUTTON_TITLE' => 'Cambia [Alt+G]',
  'LBL_CANCEL_BUTTON_TITLE' => 'Annulla [Alt+X]',
  'LBL_SEARCH_BUTTON_TITLE' => 'Cerca [Alt+Q]',
  'LBL_CLEAR_BUTTON_TITLE' => 'Annulla [Alt+C]',
  'LBL_SELECT_BUTTON_TITLE' => 'Seleziona [Alt+T]',
  'LBL_SAVE_BUTTON_KEY' => 'S',
  'LBL_EDIT_BUTTON_KEY' => 'E',
  'LBL_DUPLICATE_BUTTON_KEY' => 'U',
  'LBL_DELETE_BUTTON_KEY' => 'D',
  'LBL_NEW_BUTTON_KEY' => 'N',
  'LBL_CHANGE_BUTTON_KEY' => 'G',
  'LBL_CANCEL_BUTTON_KEY' => 'X',
  'LBL_SEARCH_BUTTON_KEY' => 'Q',
  'LBL_CLEAR_BUTTON_KEY' => 'C',
  'LBL_SELECT_BUTTON_KEY' => 'T',
  'LBL_SAVE_BUTTON_LABEL' => 'Salva',
  'LBL_EDIT_BUTTON_LABEL' => 'Modifica',
  'LBL_DUPLICATE_BUTTON_LABEL' => 'Duplica',
  'LBL_DELETE_BUTTON_LABEL' => 'Elimina',
  'LBL_NEW_BUTTON_LABEL' => 'Nuovo',
  'LBL_CHANGE_BUTTON_LABEL' => 'Modifica',
  'LBL_CANCEL_BUTTON_LABEL' => 'Annulla',
  'LBL_SEARCH_BUTTON_LABEL' => 'Cerca',
  'LBL_CLEAR_BUTTON_LABEL' => 'Annulla',
  'LBL_NEXT_BUTTON_LABEL' => 'Next',
  'LBL_SELECT_BUTTON_LABEL' => 'Seleziona',
  'LBL_SELECT_CONTACT_BUTTON_TITLE' => 'Seleziona contatto [Alt+T]',
  'LBL_SELECT_CONTACT_BUTTON_KEY' => 'T',
  'LBL_VIEW_PDF_BUTTON_LABEL' => 'View PDF',
  'LBL_VIEW_PDF_CONTACT_BUTTON_TITLE' => 'View PDF [Alt+P]',
  'LBL_VIEW_PDF_CONTACT_BUTTON_KEY' => 'P',
  'LBL_SELECT_CONTACT_BUTTON_LABEL' => 'Seleziona contatto',
  'LBL_SELECT_USER_BUTTON_TITLE' => 'Seleziona utente [Alt+U]',
  'LBL_SELECT_USER_BUTTON_KEY' => 'U',
  'LBL_SELECT_USER_BUTTON_LABEL' => 'Seleziona utente',
  'LBL_CREATE_BUTTON_LABEL' => 'Create',
  'LBL_SHORTCUTS' => 'Shortcuts',
  'LBL_LIST_NAME' => 'Nome',
  'LBL_LIST_USER_NAME' => 'Nome utente',
  'LBL_LIST_EMAIL' => 'Email',
  'LBL_LIST_PHONE' => 'Telefono',
  'LBL_LIST_CONTACT_NAME' => 'Nome contatto',
  'LBL_LIST_CONTACT_ROLE' => 'Contact Role',
  'LBL_LIST_ACCOUNT_NAME' => 'Nome cliente',
  'LBL_USER_LIST' => 'Lista utenti',
  'LBL_CONTACT_LIST' => 'Lista contatti',
  'LBL_RELATED_RECORDS' => 'Related Records',
  'LBL_MASS_UPDATE' => 'Mass Update',
  'LNK_ADVANCED_SEARCH' => 'Avanzata',
  'LNK_BASIC_SEARCH' => 'Normale',
  'LNK_EDIT' => 'modifica',
  'LNK_REMOVE' => 'elimina',
  'LNK_DELETE' => 'cancella',
  'LNK_LIST_START' => 'Inizio',
  'LNK_LIST_NEXT' => 'Successivo',
  'LNK_LIST_PREVIOUS' => 'Precedente',
  'LNK_LIST_END' => 'Fine',
  'LBL_LIST_OF' => 'di',
  'LBL_OR' => 'OR',
  'LNK_PRINT' => 'Stampa',
  'LNK_HELP' => 'Aiuto',
  'LNK_ABOUT' => 'Informazioni',
  'NTC_REQUIRED' => 'Indica un campo obbligatorio',
  'LBL_REQUIRED_SYMBOL' => '*',
  'LBL_CURRENCY_SYMBOL' => 'EUR.',
  'LBL_PERCENTAGE_SYMBOL' => '%',
  'LBL_THOUSANDS_SYMBOL' => 'K',
  'NTC_DATE_FORMAT' => '(aaaa-mm-jj)',
  'NTC_TIME_FORMAT' => '(24:00)',
  'NTC_DATE_TIME_FORMAT' => '(aaaa-mm-jj 24:00)',
  'NTC_DELETE_CONFIRMATION' => 'Sei sicuro di voler eliminare questo record ?',
  'ERR_DELETE_RECORD' => 'Deve essere specificato un numero record per eliminare il contatto.',
  'ERR_CREATING_TABLE' => 'Errore nella creazione della tabella: ',
  'ERR_CREATING_FIELDS' => 'Errore nell\'inserimento di dati aggiuntivi nei campi: ',
  'ERR_MISSING_REQUIRED_FIELDS' => 'Mancano i campi richiesti:',
  'ERR_INVALID_EMAIL_ADDRESS' => 'indirizzo email non valido.',
  'ERR_INVALID_DATE_FORMAT' => 'Il formato della data deve essere: aaaa-mm-jj',
  'ERR_INVALID_MONTH' => 'Prego inserisci un mese valido.',
  'ERR_INVALID_DAY' => 'Prego inserisci un giorno valido.',
  'ERR_INVALID_YEAR' => 'Prego inserisci un anno a 4 cifre valido.',
  'ERR_INVALID_DATE' => 'Prego inserisci una data valida.',
  'ERR_INVALID_HOUR' => 'Prego inserisci un\'ora valida.',
  'ERR_INVALID_TIME' => 'Prego inserisci un orario valido.',
  'ERR_INVALID_AMOUNT' => 'Please enter a valid amount.',
  'NTC_CLICK_BACK' => 'Prego utilizza il bottone "indietro" del browser e correggi il problema.',
  'LBL_LIST_ASSIGNED_USER' => 'Assegnato a ',
  'LBL_ASSIGNED_TO' => 'Assegnato a:',
  'LBL_DATE_MODIFIED' => 'Last Modified:',
  'LBL_DATE_ENTERED' => 'Created:',
  'LBL_CURRENT_USER_FILTER' => 'Solo i miei elementi:',
  'NTC_LOGIN_MESSAGE' => 'Prego fai login all\\\'applicazione.',
  'LBL_NONE' => '--Nessuno--',
  'LBL_BACK' => 'Indietro',
  'LBL_IMPORT' => 'Importa',
  'LBL_EXPORT' => 'Esporta',
  'LBL_EXPORT_ALL' => 'Esporta tutto',
  'LBL_SAVE_NEW_BUTTON_TITLE' => 'Save & Create New [Alt+V]',
  'LBL_SAVE_NEW_BUTTON_KEY' => 'V',
  'LBL_SAVE_NEW_BUTTON_LABEL' => 'Save & Create New',
  'LBL_NAME' => 'Name',
  'LBL_SUBJECT' => 'Subject',
);


?>