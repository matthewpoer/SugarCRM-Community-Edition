<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * 
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and 
 * (ii) the SugarCRM copyright notice 
 * in the same form as they appear in the distribution.  See full license for requirements.
 * 
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/sugarcrm/include/modules.php,v 1.23 2004/11/11 02:37:22 clint Exp $
 * Description:  Executes a step in the installation process.
 ********************************************************************************/

$moduleList = array();
// this list defines the modules shown in the top tab list of the app
$moduleList[] = 'Home';



$moduleList[] = 'Activities'; 

$moduleList[] = 'Contacts';
$moduleList[] = 'Accounts';
$moduleList[] = 'Leads';
$moduleList[] = 'Opportunities';



$moduleList[] = 'Cases';
$moduleList[] = 'Dashboard';




// this list defines all of the module names and bean names in the app
// to create a new module's bean class, add the bean definition here 
$beanList['Leads'] 			= 'Lead';
$beanList['Contacts'] 		= 'Contact';
$beanList['Accounts']		= 'Account';
$beanList['Opportunities']	= 'Opportunity';
$beanList['Cases']			= 'aCase';
$beanList['Notes']			= 'Note';
$beanList['Calls']			= 'Call';
$beanList['Emails']			= 'Email';
$beanList['Meetings']		= 'Meeting';
$beanList['Tasks']			= 'Task';
$beanList['Users']			= 'User';
$beanList['Trackers']		= 'Tracker';
$beanList['Import']			= 'ImportMap';
$beanList['Import_1']		= 'SugarFile';
$beanList['Import_2']		= 'UsersLastImport';
$beanList['Administration']	= 'Administration';















// this list defines all of the files that contain the SugarBean class definitions from $beanList
// to create a new module's bean class, add the file definition here 
$beanFiles['Lead'] 			= 'modules/Leads/Lead.php';
$beanFiles['Contact'] 		= 'modules/Contacts/Contact.php';
$beanFiles['Account']		= 'modules/Accounts/Account.php';
$beanFiles['Opportunity']	= 'modules/Opportunities/Opportunity.php';
$beanFiles['aCase']			= 'modules/Cases/Case.php';
$beanFiles['Note']			= 'modules/Notes/Note.php';
$beanFiles['Call']			= 'modules/Calls/Call.php';
$beanFiles['Email']			= 'modules/Emails/Email.php';
$beanFiles['Meeting']		= 'modules/Meetings/Meeting.php';
$beanFiles['Task']			= 'modules/Tasks/Task.php';
$beanFiles['User']			= 'modules/Users/User.php';
$beanFiles['Currency']			= 'modules/Currencies/Currency.php';
$beanFiles['Tracker']		= 'data/Tracker.php';
$beanFiles['ImportMap']		= 'modules/Import/ImportMap.php';
$beanFiles['SugarFile']		= 'modules/Import/SugarFile.php';
$beanFiles['UsersLastImport']= 'modules/Import/UsersLastImport.php';
$beanFiles['Administration']= 'modules/Administration/Administration.php';















if (file_exists('include/modules_override.php')) 
{
	include('include/modules_override.php');
}
?>
