<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/cvsroot/sugarcrm/include/logging.php,v 1.12 2004/10/24 20:06:42 clint Exp $
 * Description:  Kicks off log4php.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/
 
require_once('config.php');

define('LOG4PHP_DIR', 'log4php');
define('LOG4PHP_DEFAULT_INIT_OVERRIDE', true);

require_once(LOG4PHP_DIR.'/LoggerManager.php');
require_once(LOG4PHP_DIR.'/LoggerPropertyConfigurator.php');

if (! isset($simple_log) || $simple_log == false)
{
$config = new LoggerPropertyConfigurator();
$config->configure('log4php.properties');
}

class SimpleLog
{
        var $fp;
        function SimpleLog()
        {
                $this->fp = fopen("php://stderr", 'w') or die("Failed to open STDERR");
        }
        function info($string)
        {
                fwrite($this->fp, "info:[".strftime("%Y-%m-%d %T")."] $string\n")
                        or die("Failed to write to stderr");
        }
        function warn($string)
        {
                fwrite($this->fp, "warn:[".strftime("%Y-%m-%d %T")."] $string\n")
                        or die("Failed to write to stderr");
        }
        function debug($string)
        {
                fwrite($this->fp, "debug:[".strftime("%Y-%m-%d %T")."] $string\n")
                        or die("Failed to write to stderr");
        }
        function error($string)
        {
                fwrite($this->fp, "error:[".strftime("%Y-%m-%d %T")."] $string\n")
                        or die("Failed to write to stderr");
        }
        function fatal($string)
        {
                fwrite($this->fp, "fatal:[".strftime("%Y-%m-%d %T")."] $string\n")
                        or die("Failed to write to stderr");
		die($string);
        }
}

?>
