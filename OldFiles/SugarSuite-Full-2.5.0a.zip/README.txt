*************************************
* Sugar Suite January 2005 Release  * 
*************************************

Sugar v2.5.0a
January 25, 2005

------------------------------------------------------------------------
2.5.0a
------------------------------------------------------------------------
Fixed: not displaying only available tabs in user's Edit Tabs interface
Fixed: events do not show up in calendar if scheduled between 23:00 and 23:59
Fixed: events do not show up in calendar on second day of a 2 day long event
Fixed: custom fields do not work for Cases
Fixed: broken search when searching by assigned user
Fixed: date sorting is wrong for My Upcoming Activities when using different date formating
Fixed: all dates show up as red for My Upcoming Activities when using different data formating
Fixed: issues in installer
Fixed: removed beta code
Fixed: PNG images have been optimized
Fixed: "Other" query now works correctly for Opportunity list view
Fixed: Black bars showing up in Pipeline by Month by Outcome graph in international languages
Added: ability to save search parameters between pages
Added: import capabilities to notes






-=Overview=-
Customizing the application without needing to write any code, a new RSS reader, portal functionality for turning Sugar into
the single user interface for your business and much, much more.  The Sugar Team is excited to bring you the most feature-rich
release yet.  Not only have many new usability enhancements been added in this release, but a lot of work has gone on underneath
the covers to make Sugar an easier to customize and far more scalable system.

For businesses that rely on Sugar Sales as a mission-critical system, SugarCRM Inc. also provides Sugar Sales Professional which 
includes many more great features for your business.  Significant features include Quoting and Product Catalog for creating customer 
quotes, Reporting for tracking your business, Team Selling with Data Security for managing who can access records and an MS 
Outlook Plug-In for archiving emails.  Sugar Sales Professional also includes exemplary customer support, updates to new 
versions for a year and more.  

You can send us an email any time with your feedback at support@sugarcrm.com.  Our goal continues to be to build the customer 
relationship management system that you have always wanted, so your input is vital.

Check out http://www.sugarcrm.com for more details on acquiring Sugar Professional, the latest product roadmap, support forums, 
detailed product information and much more.  We hope you find this a useful tool for building your business.

Enjoy! 
The Sugar Team 


-=Included Features=-
An overview of the features in this release. 

Home Module: 
* Each user can now modify the tab list.
* My Upcoming Appointments 
* Now permits you to filter by today, tomorrow, this week, next week, this month and next month for greater flexibility in 
    managing how you view your appointments. 
* Now displays all open appointments prior to the filter date, not just those open appointments between today and the filter date. 
    This prevents you from forgetting previous open appointments.  
* The associated contact name and account name are now displayed when you mouse over the appointment name so that you don't have 
    to drill into each appointment to find this information. 
* My Open Cases and My Assigned Bugs have been added to the screen layout.
* One of the best kept secrets in Sugar, the "Enter Business Card" shortcut has been added to the Shortcuts area.  This feature 
  allows users to enter a new Contact, Account, Opportunity and follow-up Meeting all in one screen.
  Portal Module: 
* Add new tabs or individual user shortcuts to external web sites and applications.  Allows you to create a single enterprise 
  application.

Contacts Module: 
* Keep your data clean with checking for contact duplicates that now takes place when first creating a record-- the same duplicate 
  check that is performed when converting a lead or entering a business card. 

Accounts Module:  
* As with contacts, keep your data clean with a check for account duplicates that now takes place when first creating an account - 
  the same duplicate check that is performed when converting a lead or entering a business card. If a possible duplicate is found, 
  you are taken to a Show Duplicates screen. 

Activities Module:  
* When closing a task, meeting or call from the home tab, open activities sub-panel or activity list views, you are now taken to the 
  edit view screen so that you can enter notes before saving.  Allows you to quickly enter notes about the activity as you close it.

Dashboard:
* A new charting engine that generates more attractive charts and supports Far East and Cyrillic character sets. This Flash-based 
  plug-in is downloaded to the end user's browser, allowing data to be populated as the user watches while simultaneously decreasing  
  the server load. 

RSS Module:  
* You can now receive and view news feeds (RSS and ATOM) in this new module. Each user can manage their own set of favorites to be 
  displayed as My RSS News Feeds.

Bug Tracker Module: 
* To enhance the service management capabilities of the system, a software bug tracking module has been added, to manage the life 
  cycle of software bug reports. 

System Administration: 
* Customize fields in the application without directly modifying the source code.  Fields can be added, modified, removed or 
  reconfigured through a simple point-and-click administration tool.
* Modify dropdown values directly from the Admin screen.
* New configuration settings have been added to the system configuration file which can disable the Export capability for all users, 
  or for all users except those with Administrator capability.  
* You can now set your time and date display to new formats including day-month-year and 10:00am. 
* You can set your time zone and have all record time stamps displayed in your local time. 

