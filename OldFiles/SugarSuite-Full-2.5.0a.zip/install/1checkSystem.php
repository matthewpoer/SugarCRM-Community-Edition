<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

// $Id: 1checkSystem.php,v 1.60 2005/01/21 04:48:11 andrew Exp $

$suicide = true;
if(isset($install_script))
{
   if($install_script)
	{
		$suicide = false;
	}
}

if($suicide)
{
	// mysterious suicide note
	die('Unable to process script directly.');
}

// for keeping track of whether to enable/disable the 'Next' button
$error_found = false;

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
   <meta http-equiv="Content-Script-Type" content="text/javascript">
   <meta http-equiv="Content-Style-Type" content="text/css">
   <title>SugarCRM Setup Wizard: Step 1</title>
   <link rel="stylesheet" href="install/install.css" type="text/css">
   <script type="text/javascript" src="install/installCommon.js"></script>
</head>

<body>
  <table cellspacing="0" cellpadding="0" border="0" align="center" class=
  "shell">
    <tr>
      <th width="400">Step 1: System Check</th>
	  <th width="200" height="30" style="text-align: right;"><a href="http://www.sugarcrm.com" target=
      "_blank"><IMG src="include/images/sugarcrm_login.png" width="120" height="19" alt="SugarCRM" border="0"></a></th>
    </tr>

    <tr>
      <td colspan="2" width="600">
        <p>In order for your SugarCRM installation to function properly,
        please ensure all of the system check items listed below are green. If
        any are red, please take the necessary steps to fix them.</p>

        <table cellpadding="0" cellspacing="0" border="0" width="100%" class=
        "StyleDottedHr">
          <tr>
            <th align="left">Component</th>

            <th style="text-align: right;">Status</th>
          </tr>

          <tr>
            <td><b>PHP Version 4.2.x or newer</b></td>

            <td align="right"><?php
               $php_version = phpversion();
               if(str_replace(".", "", $php_version) < "420")
               {
                  echo "<b><span class=stop>Invalid version ($php_version) Installed</span></b>";
                  $error_found = true;
               }
               else
               {
                  echo "<b><span class=go>OK (ver $php_version)</span></b>";
               }
            ?></td>
          </tr>

          <tr>
            <td><strong>MySQL Database</strong></td>

            <td align="right"><?php
               if(function_exists('mysql_connect'))
               {
                  echo '<b><span class=go>OK</font></b>';
               }
               else
               {
                  echo '<b><span class=stop>Not Available</font></b>';
                  $error_found = true;
               }
            ?></td>
          </tr>

          <tr>
            <td><strong>XML Parsing</strong></td>

            <td align="right"><?php
               if(function_exists('xml_parser_create'))
               {
                  echo '<b><span class=go>OK</font></b>';
               }
               else
               {
                  echo '<b><span class=stop>Not Available</font></b>';
                  $error_found = true;
               }
            ?></td>
          </tr>

          <tr>
            <td><b>SugarCRM Configuration File (config.php)</b></td>

            <td align="right"><?php
               @chmod('./config.php', 0666);
               if(is_writable('./config.php'))
               {
                  echo '<b><span class=go>OK</font></b>';
               }
               else
               {
                  echo '<b><span class=stop>Not Writeable</font></b>';
                  $error_found = true;
               }
            ?></td>
          </tr>

          <tr>
            <td><b>Custom Directory</b></td>

            <td align="right"><?php
               @chmod('./custom', 0777);

               if(is_writable('./custom'))
               {
                  echo '<b><span class=go>OK</font></b>';
               }
               else
               {
                  echo '<b><span class=stop>Not Writeable</font></b>';
                  $error_found = true;
               }
            ?></td>
          </tr>

          <tr>
            <td><b>Data Sub-Directories</b></td>

            <td align="right"><?php
               @chmod('./data', 0777);
               @chmod('./data/upload', 0777);

               if(is_writable('./data') &&
                  is_writable('./data/upload'))
               {
                  echo '<b><span class=go>OK</font></b>';
               }
               else
               {
                  echo '<b><span class=stop>Not Writeable</font></b>';
                  $error_found = true;
               }
            ?></td>
          </tr>

          <tr>
            <td><b>Cache Sub-Directories</b></td>

            <td align="right"><?php
               @chmod('./cache/custom_fields', 0777);
               @chmod('./cache/dyn_lay', 0777);
               @chmod('./cache/images', 0777);
               @chmod('./cache/import', 0777);
               @chmod('./cache/layout', 0777);
               @chmod('./cache/pdf', 0777);
               @chmod('./cache/upload', 0777);
               @chmod('./cache/xml', 0777);

               if(is_writable('./cache/custom_fields') &&
                  is_writable('./cache/dyn_lay') &&
                  is_writable('./cache/images') &&
                  is_writable('./cache/import') &&
                  is_writable('./cache/layout') &&
                  is_writable('./cache/pdf') &&
                  is_writable('./cache/upload') &&
                  is_writable('./cache/xml'))
               {
                  echo '<b><span class=go>OK</font></b>';
               }
               else
               {
                  echo '<b><span class=stop>Not Writeable</font></b>';
                  $error_found = true;
               }
            ?></td>
          </tr>

          <?php
          $temp_dir = (isset($_ENV['TEMP'])) ? $_ENV['TEMP'] : "";
          $session_save_path = (session_save_path() === "") ? $temp_dir : session_save_path();
          ?>

          <tr>
            <td><b>Session Save Path (<?php echo $session_save_path; ?>)</b></td>

            <td align="right"><?php
               if(is_dir($session_save_path))
               {
                  if(is_writable($session_save_path))
                  {
                     echo '<b><span class=go>OK</font></b>';
                  }
                  else
                  {
                     echo '<b><span class=stop>Not Writeable</font></b>';
                     $error_found = true;
                  }
               }
               else
               {
                  echo '<b><span class=stop>Not A Valid Directory</font></b>';
                  $error_found = true;
               }
            ?></td>
          </tr>

<!--
          <tr>
            <td><b>PHP Memory Limit</b></td>

            <td align="right"><?php $memory_limit = ini_get('memory_limit'); ?></td>
          </tr>
-->
        </table>

        <div align="center" style="margin: 5px;">
          <i><b>Note:</b> Your php configuration file (php.ini) is located
          at:<br>
          <?php echo get_cfg_var("cfg_file_path"); ?></i>
        </div>
      </td>
    </tr>

    <tr>
      <td align="right" colspan="2">
        <hr>
        <form action="install.php" method="post" name="theForm" id="theForm">
        <input type="hidden" name="current_step" value="1">
        <table cellspacing="0" cellpadding="0" border="0" class="stdTable">
          <tr>
            <td><input class="button" type="button" onclick="window.open('http://www.sugarcrm.com/forums/');" value="Help" /></td>
            <td><input class="button" type="submit" name="goto" value="Re-check" /></td>
            <td><input class="button" type="submit" name="goto" value="Back" /></td>
            <td><input class="button" type="submit" name="goto" value="Next"
                 <?php if($error_found) { echo 'disabled="disabled"'; } ?> /></td>
          </tr>
        </table>
        </form>
      </td>
    </tr>
  </table><br>
</body>
</html>

