<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Dashboard/language/en_us.lang.php,v 1.18 2004/09/09 22:02:05 sugarclint Exp $
 * Description:  Defines the English language pack for the Account module.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_SALES_STAGE_FORM_TITLE'=>'���k�X�e�[�W�ʔ���\��',
'LBL_SALES_STAGE_FORM_DESC'=>'Shows cumulative opportunity amounts by selected sales stages for selected users where the expected closed date is within the specificed date range.',
'LBL_MONTH_BY_OUTCOME'=>'���ʌ��ʕʔ���\��',
'LBL_MONTH_BY_OUTCOME_DESC'=>'Shows cumulative opportunity amounts by month by outcome for selected users where the expected closed date is within the specificed date range.  Outcome is based on whether the sales stage is Closed Won, Closed Lost or any other value.',
'LBL_LEAD_SOURCE_FORM_TITLE'=>'�������ʏ��k',
'LBL_LEAD_SOURCE_FORM_DESC'=>'Shows cumulative opportunity amounts by selected lead source for selected users.',
'LBL_LEAD_SOURCE_BY_OUTCOME'=>'�������ʌ��ʕʏ��k',
'LBL_LEAD_SOURCE_BY_OUTCOME_DESC'=>'Shows cumulative opportunity amounts by selected lead source by outcome for selected users where the expected closed date is within the specificed date range.  Outcome is based on whether the sales stage is Closed Won, Closed Lost or any other value.',
'LBL_PIPELINE_FORM_TITLE_DESC'=>'Shows cumulative amounts by selected sales stages for your opportunities where the expected closed date is within the specificed date range.',
'LBL_DATE_RANGE'=>'Date range is',
'LBL_DATE_RANGE_TO'=>'to',
'ERR_NO_OPPS'=>'Please create some Opportunities to see Opportunity graphs.',
'LBL_TOTAL_PIPELINE'=>'Pipeline total is ',
'LBL_ALL_OPPORTUNITIES'=>'Total amount of all opportunities is ',
'LBL_OPP_SIZE'=>'Opportunity size in Y1K',
'NTC_NO_LEGENDS'=>'None',
'LBL_LEAD_SOURCE_OTHER'=>'Other',
'LBL_EDIT'=>'�ҏW',
'LBL_REFRESH'=>'�X�V',
'LBL_CREATED_ON'=>'�쐬����',
'LBL_OPPS_IN_STAGE'=>'opportunities where sales stage is',
'LBL_OPPS_IN_LEAD_SOURCE'=>'opportunities where lead source is',
'LBL_OPPS_OUTCOME'=>'opportunities where outcome is',
'LBL_USERS'=>'���[�U:',
'LBL_SALES_STAGES'=>'���k�X�e�[�W:',
'LBL_LEAD_SOURCES'=>'������:',
'LBL_DATE_START'=>'�J�n��:',
'LBL_DATE_END'=>'�I����:',

'LNK_NEW_CONTACT'=>'�S���ҍ쐬',
'LNK_NEW_ACCOUNT'=>'�ڋq�쐬',
'LNK_NEW_OPPORTUNITY'=>'���k�쐬',
'LNK_NEW_CASE'=>'����쐬',
'LNK_NEW_NOTE'=>'�m�[�g�쐬',
'LNK_NEW_CALL'=>'�R�[���쐬',
'LNK_NEW_EMAIL'=>'���[���쐬',
'LNK_NEW_MEETING'=>'�~�[�e�B���O�쐬',
'LNK_NEW_TASK'=>'�^�X�N�쐬',
);

?>