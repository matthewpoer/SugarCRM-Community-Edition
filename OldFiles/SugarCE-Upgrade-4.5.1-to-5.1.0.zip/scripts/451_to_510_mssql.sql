-- MSSQL upgrade script for Sugar 4.5.1 to 5.1.0

--
-- TABLES modified from 451 to 510
--
-- Moving outbound_email table to the top. Login has a dependency on it so it must be created.
CREATE TABLE [outbound_email] (
          [id] [varchar](36) NOT NULL,
          [name] [varchar](50) NOT NULL,
          [type] [varchar](6) NOT NULL default ('user'),
          [user_id] [varchar](36) NOT NULL,
          [mail_sendtype] [varchar](8) NOT NULL default ('sendmail'),
          [mail_smtpserver] [varchar](100)  NULL,
          [mail_smtpport] [int]  NULL,
          [mail_smtpuser] [varchar](100)  NULL,
          [mail_smtppass] [varchar](100)  NULL,
          [mail_smtpauth_req] [bit]  DEFAULT (0) NULL,
          [mail_smtpssl] [bit]  DEFAULT (0) NULL
);

ALTER TABLE [outbound_email] ADD CONSTRAINT [pk_outbound_email] PRIMARY KEY CLUSTERED  ([id]);
CREATE NONCLUSTERED INDEX [oe_user_id_idx] ON [outbound_email] ([id],[user_id]);


-- documents

ALTER TABLE [documents] DROP COLUMN [mail_merge_document];

-- project task
UPDATE [project_task] set [milestone_flag]='0' where [milestone_flag] in ('',null,'off');
UPDATE [project_task] set [milestone_flag]='1' where [milestone_flag] != '0';
ALTER TABLE [project_task]  alter column [milestone_flag] [bit];




























-- boolean and date-time

ALTER TABLE [email_marketing] alter column [date_start] [datetime];
UPDATE [email_marketing]  set [date_start] = [date_start]+' '+[time_start];
ALTER TABLE [email_marketing] drop column [time_start];
ALTER TABLE email_marketing ADD reply_to_name varchar(100)  NULL;
ALTER TABLE email_marketing ADD reply_to_addr varchar(100)  NULL;

-- More depending on database diffs between 451 and 500


ALTER TABLE [contacts] ALTER COLUMN [department] [varchar](255) NULL;
ALTER TABLE [contacts] ALTER COLUMN [title] [varchar] (100)  NULL;
ALTER TABLE [contacts] ALTER COLUMN [date_entered] [datetime]  NULL;
ALTER TABLE [contacts] ALTER COLUMN [date_modified] [datetime]  NULL;
ALTER TABLE contacts ALTER COLUMN primary_address_country varchar(255);
ALTER TABLE contacts ALTER COLUMN alt_address_country varchar(255);

CREATE NONCLUSTERED INDEX [idx_reports_to_id] ON [contacts] ([reports_to_id]);



CREATE NONCLUSTERED INDEX [idx_del_id_user] ON [contacts] ([deleted], [id], [assigned_user_id]);
UPDATE [contacts] set [do_not_call]='0' where [do_not_call] in ('',null,'off');
UPDATE [contacts] set [do_not_call]='1' where [do_not_call] !='0';
ALTER TABLE [contacts] ALTER COLUMN [do_not_call] [bit] NULL;
ALTER TABLE [contacts] ADD  DEFAULT ('0') FOR [do_not_call];
ALTER TABLE [contacts] ALTER COLUMN [deleted] [bit] NULL;
ALTER TABLE [contacts] ADD  DEFAULT ('0') FOR [deleted];




CREATE NONCLUSTERED INDEX [idx_contid_del_accid] ON [accounts_contacts] ([contact_id], [deleted], [account_id]);

ALTER TABLE [leads] ALTER COLUMN  [account_name] [varchar](255)  NULL ;
ALTER TABLE [leads] add [assistant] [varchar](75)  NULL;
ALTER TABLE [leads] add [assistant_phone] [varchar](25)  NULL;
ALTER TABLE [leads] ALTER COLUMN [date_entered] datetime  NULL;
ALTER TABLE [leads] ALTER COLUMN [date_modified] datetime  NULL;
DROP INDEX [idx_lead_last_first] ON [leads];
DROP INDEX [idx_lead_del_stat] ON [leads];
ALTER TABLE [leads] ALTER COLUMN [first_name] [varchar](100) NULL ;
ALTER TABLE [leads] ALTER COLUMN [last_name] [varchar](100);
ALTER TABLE leads ALTER COLUMN primary_address_country varchar(255);
ALTER TABLE leads ALTER COLUMN alt_address_country varchar(255);
CREATE NONCLUSTERED INDEX [idx_lead_del_stat] ON [leads] ([last_name],[status],[deleted],[first_name]);
CREATE NONCLUSTERED INDEX [idx_lead_last_first] ON [leads] ([last_name],[first_name],[deleted]);
CREATE NONCLUSTERED INDEX [idx_lead_acct_name_first] ON [leads] ([account_name],[deleted]);

UPDATE [leads] set [do_not_call]='0' where [do_not_call] in ('',null,'off');
UPDATE [leads] set [do_not_call]='1' where [do_not_call] != '0';
ALTER TABLE [leads] ALTER COLUMN  [do_not_call] [bit] NULL;
ALTER TABLE [leads] ADD  DEFAULT ('0') FOR [do_not_call];

ALTER TABLE [leads] ALTER COLUMN [deleted] [bit] NULL ;
ALTER TABLE [leads] ADD  DEFAULT ('0') FOR [deleted];

CREATE NONCLUSTERED INDEX [idx_del_user] ON [leads] ([deleted],[assigned_user_id]);





-- Additional script


ALTER TABLE [accounts] ALTER COLUMN [name] varchar(150);
ALTER TABLE [accounts] ALTER COLUMN date_entered datetime  NULL;
ALTER TABLE [accounts] ALTER COLUMN date_modified datetime  NULL;
ALTER TABLE [accounts] ALTER COLUMN [deleted] [bit] NULL;
ALTER TABLE [accounts] ADD  DEFAULT ('0') FOR [deleted];
ALTER TABLE [accounts] ALTER COLUMN [modified_user_id] varchar(36)  NULL ;
ALTER TABLE [accounts] ALTER COLUMN [billing_address_country] varchar(255);
ALTER TABLE [accounts] ALTER COLUMN [shipping_address_country] varchar(255);

DROP INDEX [idx_opp_name] ON [opportunities];
--ALTER TABLE [opportunities] ALTER COLUMN [name] varchar(50)  NOT NULL ;
CREATE NONCLUSTERED INDEX [idx_opp_name] ON [opportunities] ([name]);
ALTER TABLE [opportunities] ALTER COLUMN [amount_usdollar] [float];
ALTER TABLE [opportunities] ALTER COLUMN [date_entered] [datetime] NULL;
ALTER TABLE [opportunities] ALTER COLUMN [date_modified] [datetime] NULL;

ALTER TABLE [opportunities] ALTER COLUMN  [deleted] [bit] NULL;
ALTER TABLE [opportunities] ADD  DEFAULT ('0') FOR [deleted];

--ALTER TABLE [opportunities] ALTER COLUMN [date_closed] [datetime];
--ALTER TABLE [opportunities] ALTER COLUMN [sales_stage] [varchar] (25)  NOT NULL ;

UPDATE [cases] set name='Unspecified' where name is null;
DROP INDEX [idx_case_name] ON [cases];

ALTER TABLE [cases] ALTER COLUMN [name] varchar(255) NULL;
ALTER TABLE [cases] ALTER COLUMN [date_entered] [datetime] NULL;
ALTER TABLE [cases] ALTER COLUMN [date_modified] [datetime] NULL;
ALTER TABLE [cases] ALTER COLUMN [modified_user_id] varchar(36) NULL;

CREATE NONCLUSTERED INDEX [idx_case_name] ON [cases] ([name]);
ALTER TABLE [cases] add [type] [varchar](255)  NULL ;
ALTER TABLE [cases] add [work_log] [text]  NULL ;

ALTER TABLE [cases] ALTER COLUMN  [deleted] [bit] NULL;
ALTER TABLE [cases] ADD  DEFAULT ('0') FOR [deleted];




CREATE UNIQUE INDEX [casesnumk] ON [cases] ([case_number]);





ALTER TABLE bugs ALTER COLUMN date_entered datetime  NULL ;
ALTER TABLE bugs ALTER COLUMN date_modified datetime  NULL;
ALTER TABLE bugs ALTER COLUMN modified_user_id varchar(36)  NULL ;
ALTER TABLE bugs ALTER COLUMN deleted bit NULL;
ALTER TABLE [bugs] ADD  DEFAULT ('0') FOR [deleted];
CREATE UNIQUE INDEX [bugsnumk] ON [bugs] ([bug_number]);




CREATE NONCLUSTERED INDEX [idx_account_id] ON [cases]([account_id]);
CREATE NONCLUSTERED INDEX [idx_cases_stat_del] ON [cases] ([assigned_user_id], [status], [deleted]);

DROP INDEX [idx_note_name] ON [notes];
ALTER TABLE [notes] ALTER COLUMN [name] [varchar](255);
CREATE NONCLUSTERED INDEX [idx_note_name] ON [notes]([name]);
CREATE NONCLUSTERED INDEX [idx_eman_relid_reltype_id] ON [emailman] ([related_id], [related_type], [campaign_id]);

ALTER TABLE [calls] ALTER COLUMN [date_start] [datetime] NULL;
ALTER TABLE [calls] ALTER COLUMN [duration_minutes] [int]  NULL ;
ALTER TABLE [calls] ALTER COLUMN [date_entered] [datetime]  NULL ;
ALTER TABLE [calls] ALTER COLUMN [date_modified] [datetime]  NULL;

UPDATE [calls] set [date_start] = [date_start]+' '+[time_start];
ALTER TABLE [calls] drop column [time_start];

ALTER TABLE [calls] ALTER COLUMN  [deleted] [bit] NULL;
ALTER TABLE [calls] ADD  DEFAULT ('0') FOR [deleted];

DROP INDEX [idx_call_name] ON [calls];
--ALTER TABLE [calls] ALTER COLUMN [name] [varchar](50)  NOT NULL;
CREATE NONCLUSTERED INDEX [idx_call_name] ON [calls] ([name]);
CREATE NONCLUSTERED INDEX [idx_status] ON [calls] ([status]);
CREATE NONCLUSTERED INDEX [idx_calls_date_start] ON [calls] ([date_start]);





--ALTER TABLE [calls] ALTER COLUMN [duration_hours] [int];

--ALTER TABLE [calls] ALTER COLUMN [status] [varchar](25)  NOT NULL ;











ALTER TABLE [emails] add [date_sent] [datetime] NULL ;
ALTER TABLE [emails] ALTER COLUMN [message_id] [varchar](255) NULL;
UPDATE [emails] set [date_sent] = [date_start]+' '+[time_start];

ALTER TABLE emails add flagged bit NULL ;
ALTER TABLE emails add reply_to_status bit NULL ;


ALTER TABLE [meetings] ALTER COLUMN [date_start] [datetime];
UPDATE [meetings]  set [date_start] = [date_start]+' '+[time_start];
ALTER TABLE [meetings] drop column [time_start];
ALTER TABLE [meetings] ALTER COLUMN [date_entered] [datetime]  NULL;
ALTER TABLE [meetings] ALTER COLUMN [date_modified] [datetime]  NULL;

ALTER TABLE [meetings] ALTER COLUMN  [deleted] [bit] NULL;
ALTER TABLE [meetings] ADD  DEFAULT ('0') FOR [deleted];

CREATE NONCLUSTERED INDEX [idx_meet_stat_del] ON [meetings] ([assigned_user_id], [status], [deleted]);





ALTER TABLE [tasks] ALTER COLUMN [date_start] [datetime] NULL;
ALTER TABLE [tasks] ALTER COLUMN  [date_due] [datetime] NULL;
ALTER TABLE [tasks] ALTER COLUMN [date_entered] [datetime]  NULL;
ALTER TABLE [tasks] ALTER COLUMN [date_modified] [datetime]  NULL;

UPDATE [tasks] set [date_start] = [date_start]+' '+[time_start];
UPDATE [tasks] set [date_due]= [date_due]+' '+[time_due];
ALTER TABLE [tasks] drop column [time_start];
ALTER TABLE [tasks] drop column [time_due];

UPDATE [tasks] set [date_due_flag]='0' where [date_due_flag] in ('',null,'off');
UPDATE [tasks] set [date_due_flag]='1' where [date_due_flag] != '0';

UPDATE [tasks] set [date_start_flag]='0' where [date_start_flag] in ('',null,'off');
UPDATE [tasks] set [date_start_flag]='1' where [date_start_flag] != '0';

ALTER TABLE [tasks] ALTER COLUMN [date_start_flag] [bit] NULL ;
ALTER TABLE [tasks] ADD  DEFAULT ('1') FOR [date_start_flag];

ALTER TABLE [tasks] ALTER COLUMN [date_due_flag] [bit] NULL ;
ALTER TABLE [tasks] ADD  DEFAULT ('1') FOR [date_due_flag];

ALTER TABLE [tasks] ALTER COLUMN  [deleted] [bit] NULL;
ALTER TABLE [tasks] ADD  DEFAULT ('0') FOR [deleted];






CREATE NONCLUSTERED INDEX [idx_user_name] ON [users] (user_name,is_group,status,last_name,first_name,id);

--ALTER TABLE  [tasks] ALTER COLUMN [priority] [varchar](25)  NOT NULL;


ALTER TABLE [upgrade_history] add [enabled] [bit]  DEFAULT ('1') NULL ;
ALTER TABLE [campaigns] ALTER COLUMN [deleted] [bit] NULL ;
ALTER TABLE [campaigns] ADD DEFAULT ('0') FOR [deleted];
































--ALTER TABLE [documents] ALTER COLUMN [active_date] [datetime]  NOT NULL ;
UPDATE [prospects] set [do_not_call]='0' where [do_not_call] in ('',null,'off');
UPDATE [prospects] set [do_not_call]='1' where [do_not_call] != '0';
ALTER TABLE [prospects] ALTER COLUMN [do_not_call] [bit] NULL;
ALTER TABLE [prospects] ADD  DEFAULT ('0') FOR [do_not_call];
ALTER TABLE [prospects] ALTER COLUMN [title] [varchar] (100)  NULL;
ALTER TABLE prospects ALTER COLUMN date_entered datetime  NULL;
ALTER TABLE prospects ALTER COLUMN date_modified datetime  NULL ;
ALTER TABLE prospects ALTER COLUMN primary_address_country varchar(255);
ALTER TABLE prospects ALTER COLUMN alt_address_country varchar(255);


ALTER TABLE [fields_meta_data] add [vname] [varchar](255)  NULL ;
ALTER TABLE [fields_meta_data] add [comments] [varchar](255)  NULL ;
ALTER TABLE [fields_meta_data] add [type] [varchar](255)  NULL ;
ALTER TABLE [fields_meta_data] add [len] [int]  NULL ;
ALTER TABLE [fields_meta_data] add [required] [bit]  DEFAULT ('0') NULL ;
ALTER TABLE [fields_meta_data] add [massupdate] [bit]  DEFAULT ('0') NULL ;
ALTER TABLE [fields_meta_data] add [reportable] [bit]  DEFAULT ('1') NULL ;

CREATE NONCLUSTERED INDEX [idx_meta_cm_del] ON [fields_meta_data] ([custom_module], [deleted]);

ALTER TABLE [inbound_email] add [is_personal] [bit]  DEFAULT ('0') NOT NULL ;
ALTER TABLE [inbound_email] add [groupfolder_id] [varchar](36) NULL;
ALTER TABLE [inbound_email] ALTER COLUMN [stored_options] [text] NULL;

CREATE NONCLUSTERED INDEX [idx_oppid_del_accid] ON [accounts_opportunities] ([opportunity_id], [deleted], [account_id]);

ALTER TABLE [tracker] ALTER COLUMN [user_id] [varchar](36)  NULL ;
ALTER TABLE [tracker] ADD [action] [varchar](255)  NULL ;

ALTER TABLE [tracker] ALTER COLUMN [module_name] [varchar](255)  NULL ;
ALTER TABLE [tracker] ALTER COLUMN [item_id] [varchar](36)  NULL ;

ALTER TABLE [tracker] ADD [session_id] [int] NULL ;
ALTER TABLE [tracker] ADD [visible] [bit]  DEFAULT ('0') NULL;

UPDATE [tracker] set [visible]='1';

CREATE NONCLUSTERED INDEX [idx_tracker_iid] ON [tracker] ([item_id]);
CREATE NONCLUSTERED INDEX [idx_tracker_action] ON [tracker] ([action]);
CREATE NONCLUSTERED INDEX [idx_tracker_userid_vis_id] ON [tracker] ([user_id],[visible],[id]);
CREATE NONCLUSTERED INDEX [idx_tracker_userid_itemid_vis] ON [tracker]([user_id],[item_id],[visible]);


CREATE TABLE [email_addresses] (
                [id] [varchar](36) NOT NULL,
                [email_address] [varchar](255)  NOT NULL ,
                [email_address_caps] [varchar](255)  NOT NULL ,
                [invalid_email] [bit]  DEFAULT (0) NULL,
                [opt_out] [bit]  DEFAULT (0) NULL ,
                [date_created] [datetime]  NULL ,
                [date_modified] [datetime]  NULL ,
                [deleted] [bit]  DEFAULT (0) NULL
             );

ALTER TABLE [email_addresses] ADD CONSTRAINT [pk_email_addresses] PRIMARY KEY CLUSTERED ([id]);
CREATE NONCLUSTERED INDEX [idx_ea_caps_opt_out_invalid] ON [email_addresses] ([email_address_caps],[opt_out],[invalid_email]);
CREATE NONCLUSTERED INDEX [idx_ea_opt_out_invalid] ON [email_addresses] ([email_address],[opt_out],[invalid_email]);


CREATE TABLE [email_addr_bean_rel] (
              [id] [varchar](36) NOT NULL,
              [email_address_id] [varchar](36) NOT NULL,
              [bean_id] [varchar](36) NOT NULL,
              [bean_module] [varchar](25) NOT NULL,
              [primary_address] [bit] default (0) NULL,
              [reply_to_address] [bit] default (0) NULL,
              [date_created] [datetime] NULL,
              [date_modified] [datetime] NULL,
              [deleted] [bit] default (0) NULL

);
ALTER TABLE [email_addr_bean_rel] ADD CONSTRAINT [pk_email_addr_bean_rel] PRIMARY KEY CLUSTERED  ([id]);
CREATE NONCLUSTERED INDEX [idx_email_address_id] ON [email_addr_bean_rel] ([email_address_id]);
CREATE NONCLUSTERED INDEX [idx_bean_id] ON [email_addr_bean_rel] ([bean_id],[bean_module]);


CREATE TABLE [emails_text] (
              [email_id] [varchar](36) NOT NULL,
              [from_addr] [varchar](255) NULL,
              [to_addrs] [text] NULL,
              [cc_addrs] [text] NULL,
              [bcc_addrs] [text] NULL,
              [description] [text] NULL,
              [description_html] [text] NULL,
              [raw_source] [text] NULL,
              [deleted] [bit] default (0) NULL,
              [reply_to_addr] [varchar](255) NULL
);
ALTER TABLE [emails_text] ADD CONSTRAINT [pk_emails_text] PRIMARY KEY CLUSTERED  ([email_id]);
CREATE NONCLUSTERED INDEX [emails_textfromaddr] ON [emails_text] ([from_addr]);

CREATE TABLE [emails_beans] (
              [id] varchar(36) NOT NULL,
              [email_id] [varchar](36) NULL,
              [bean_id] [varchar](36)  NULL,
              [bean_module] [varchar](36) NULL,
              [campaign_data] [text] NULL,
              [date_modified] [datetime] NULL,
              [deleted] [bit] NOT NULL default (0),
);

ALTER TABLE [emails_beans] ADD CONSTRAINT [pk_emails_beans] PRIMARY KEY CLUSTERED  ([id]);
CREATE NONCLUSTERED INDEX [idx_emails_beans_bean_id] ON [emails_beans] ([bean_id]);
CREATE NONCLUSTERED INDEX [idx_emails_beans_email_bean] ON [emails_beans] ([email_id],[bean_id],[deleted]);


CREATE TABLE [emails_email_addr_rel] (
              [id] [varchar](36) NOT NULL,
              [email_id] [varchar](36) NOT NULL,
              [address_type] varchar(4) NOT NULL,
              [email_address_id] varchar(36) NOT NULL,
              [deleted] [bit] default (0) NULL,
);
ALTER TABLE [emails_email_addr_rel] ADD CONSTRAINT [pk_emails_email_addr_rel] PRIMARY KEY CLUSTERED  ([id]);
CREATE NONCLUSTERED INDEX [idx_eearl_email_id] ON [emails_email_addr_rel] ([email_id],[address_type]);
CREATE NONCLUSTERED INDEX [idx_eearl_address_id] ON [emails_email_addr_rel] ([email_address_id]);

CREATE TABLE [folders] (
            [id] [varchar](36) NOT NULL,
            [name] [varchar](25)  NOT NULL ,
            [parent_folder] [varchar](36)  NULL ,
            [has_child] [bit]  DEFAULT ('0') NULL ,
            [is_group] [bit]  DEFAULT ('0') NULL ,
            [is_dynamic] [bit]  DEFAULT ('0') NULL ,
            [dynamic_query] [text]  NULL ,
            [assign_to_id] [varchar](36)  NULL ,
            [folder_type] [varchar](25)  NULL ,



            [created_by] [varchar](36)  NOT NULL ,
            [modified_by] [varchar](36)  NOT NULL ,
            [deleted] [bit] DEFAULT ('0') NULL  ,
          ) ;
ALTER TABLE [folders] ADD CONSTRAINT [pk_folders] PRIMARY KEY CLUSTERED  ([id]);
CREATE NONCLUSTERED INDEX [idx_parent_folder] ON [folders]([parent_folder]);

CREATE TABLE [folders_subscriptions] (
                [id] [varchar](36)  NOT NULL ,
                [folder_id] [varchar](36)  NOT NULL ,
                [assigned_user_id] [varchar](36)  NOT NULL  ,
               );
ALTER TABLE [folders_subscriptions] ADD CONSTRAINT [pk_folders_subscriptions] PRIMARY KEY CLUSTERED  ([id]);
CREATE NONCLUSTERED INDEX [idx_folder_id_assigned_user_id] ON [folders_subscriptions]([folder_id],[assigned_user_id]);

CREATE TABLE [folders_rel] (
                [id] [varchar](36)  NOT NULL ,
                [folder_id] [varchar](36)  NOT NULL ,
                [polymorphic_module] [varchar](25)  NOT NULL ,
                [polymorphic_id] [varchar](36)  NOT NULL ,
                [deleted] [bit]  DEFAULT ('0') NULL  ,
               );
ALTER TABLE [folders_rel] ADD CONSTRAINT [pk_folders_rel] PRIMARY KEY CLUSTERED  ([id]);
CREATE NONCLUSTERED INDEX [idx_poly_module_poly_id] ON [folders_rel]([polymorphic_module],[polymorphic_id]);
CREATE NONCLUSTERED INDEX [idx_folders_rel_folder_id] ON [folders_rel]([folder_id]);

CREATE TABLE [address_book] (
                [assigned_user_id] [varchar](36)  NOT NULL ,
                [bean] [varchar](50)  NOT NULL ,
                [bean_id] [varchar](36)  NOT NULL  ,
              );
CREATE NONCLUSTERED INDEX [ab_user_bean_idx] ON [address_book]([assigned_user_id],[bean]);

















CREATE TABLE [inbound_email_cache_ts] (
                [id] varchar(255)  NOT NULL ,
                [ie_timestamp] [int] NOT NULL  ,
               );
ALTER TABLE [inbound_email_cache_ts] ADD CONSTRAINT [pk_inbound_email_cache_ts] PRIMARY KEY CLUSTERED  ([id]);


















CREATE NONCLUSTERED INDEX [idx_category_name] ON [acl_actions] ([category], [name]);

CREATE TABLE [email_cache](
	[ie_id] [varchar](36) NOT NULL,
	[mbox] [varchar](60) NOT NULL,
	[subject] [varchar](255) NULL,
	[fromaddr] [varchar](100) NULL,
	[toaddr] [varchar](255) NULL,
	[senddate] [datetime] NOT NULL,
	[message_id] [varchar](255) NULL,
	[mailsize] [int] NOT NULL,
	[imap_uid] [int] NOT NULL,
	[msgno] [int] NULL,
	[recent] [tinyint] NOT NULL,
	[flagged] [tinyint] NOT NULL,
	[answered] [tinyint] NOT NULL,
	[deleted] [tinyint] NOT NULL,
	[seen] [tinyint] NOT NULL,
	[draft] [tinyint] NOT NULL
);

CREATE NONCLUSTERED INDEX [idx_ie_id] ON [email_cache]([ie_id]);
CREATE NONCLUSTERED INDEX [idx_mail_date] ON [email_cache]([ie_id],[mbox],[senddate]);
CREATE NONCLUSTERED INDEX [idx_mail_from] ON [email_cache]([ie_id],[mbox],[fromaddr]);
CREATE NONCLUSTERED INDEX [idx_mail_subj] ON [email_cache] ([subject]);

-- MSSQL upgrade script for Sugar 5.0.0 to 5.1.0

--
-- TABLES modified from 500 to 510
--
-- import maps
ALTER TABLE import_maps alter column name varchar(254);
ALTER TABLE import_maps add enclosure varchar(1) NOT NULL;
ALTER TABLE import_maps add delimiter varchar(1) NOT NULL;
ALTER TABLE import_maps add default_values image;

-- inbound email
ALTER TABLE inbound_email alter column mailbox text NOT NULL;
-- project task
 ALTER TABLE project_task add  status varchar(255)  NULL;
 ALTER TABLE project_task add  order_number int default '1';
 ALTER TABLE project_task add  task_number int  NULL;
 ALTER TABLE project_task add  estimated_effort int  NULL;
 ALTER TABLE project_task add  utilization int default '100';

ALTER TABLE accounts alter column account_type varchar(50)  NULL ;
ALTER TABLE accounts alter column industry varchar(50)  NULL ;
-- tracker table changes

ALTER TABLE users_last_import add import_module varchar(36) NULL ;

-- ALTER TABLE fields_meta_data  alter column default_value varchar(255) NULL;
ALTER TABLE fields_meta_data add importable varchar(255) NULL;

ALTER TABLE tracker add monitor_id varchar(36) NULL;

ALTER TABLE tracker add deleted bit default '0' NULL;
ALTER TABLE tracker alter column session_id varchar(36) NULL;
CREATE NONCLUSTERED INDEX idx_tracker_monitor_id ON tracker(monitor_id);

CREATE TABLE calls_leads (
    id varchar(36)  NOT NULL ,
    call_id varchar(36)  NULL ,
    lead_id varchar(36)  NULL ,
    required varchar(1)  DEFAULT '1' NULL ,
    accept_status varchar(25)  DEFAULT 'none' NULL ,
    date_modified datetime  NULL ,
    deleted bit  DEFAULT '0' NOT NULL  ,
    PRIMARY KEY (id)
) ;
CREATE NONCLUSTERED INDEX idx_lead_call_call ON calls_leads(call_id);
CREATE NONCLUSTERED INDEX idx_lead_call_lead ON calls_leads(lead_id);
CREATE NONCLUSTERED INDEX idx_call_lead ON calls_leads(call_id, lead_id);

CREATE TABLE meetings_leads (
	id varchar(36)  NOT NULL ,
	meeting_id varchar(36)  NULL ,
	lead_id varchar(36)  NULL ,
	required varchar(1)  DEFAULT '1' NULL ,
	accept_status varchar(25)  DEFAULT 'none' NULL ,
	date_modified datetime  NULL ,
	deleted bit  DEFAULT '0' NOT NULL  ,
	PRIMARY KEY (id)
);
CREATE NONCLUSTERED INDEX idx_lead_meeting_meeting ON meetings_leads(meeting_id);
CREATE NONCLUSTERED INDEX idx_lead_meeting_lead ON meetings_leads(lead_id);
CREATE NONCLUSTERED INDEX idx_meeting_lead ON meetings_leads(meeting_id, lead_id);






















































































