<?php
// created: 2006-01-24 18:10:18
$manifest = array (
  'acceptable_sugar_flavors' => 
  array (
    0 => 'OS',
  ),
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '4\\.0\\.0',
    ),
  ),
  'author' => 'SugarCRM, Inc.',
  'copy_files' => 
  array (
    'from_dir' => 'SugarSuite-Patch-4.0.1',
    'to_dir' => '',
    'force_copy' => 
    array (
      0 => 'UpgradeWizard_prepare.php',
      1 => 'UpgradeWizard_commit.php',
      2 => 'DisplayWarnings.php',
    ),
  ),
  'description' => 'Upgrade patch for Sugar 4.0.1 performed in two steps',
  'icon' => '',
  'is_uninstallable' => false,
  'name' => 'SugarSuite',
  'published_date' => '2006-01-24 18:10:18',
  'type' => 'patch',
  'version' => '4.0.1',
);
?>
