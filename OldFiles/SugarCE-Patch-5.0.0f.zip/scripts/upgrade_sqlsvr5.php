
<?php
/**
 * This script executes after the files are copied during the install.
 *
 * LICENSE: The contents of this file are subject to the SugarCRM Professional
 * End User License Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/EULA.  By installing or using this file, You have
 * unconditionally agreed to the terms and conditions of the License, and You
 * may not use this file except in compliance with the License.  Under the
 * terms of the license, You shall not, among other things: 1) sublicense,
 * resell, rent, lease, redistribute, assign or otherwise transfer Your
 * rights to the Software, and 2) use the Software for timesharing or service
 * bureau purposes such as hosting the Software for commercial gain and/or for
 * the benefit of a third party.  Use of the Software may be subject to
 * applicable fees and any use of the Software without first paying applicable
 * fees is strictly prohibited.  You do not have the right to remove SugarCRM
 * copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2005 SugarCRM, Inc.; All Rights Reserved.
 *
 * $Id$
 */

require_once('include/utils.php');
require_once('include/database/PearDatabase.php');
require_once('include/database/DBManager.php');
require_once('include/database/DBManagerFactory.php');
require_once("include/entryPoint.php");
require_once("modules/Emails/Email.php");

function upgrade5_sqlsvr($return_query = false){
$email = new Email();
    $tabAndCols = array();
    $tabAndCols =array('documents' =>'mail_merge_document',
                       'tasks' =>array('date_start_flag',
					                   'date_due_flag',
					                   'deleted'),










                       'leads'=>array('do_not_call',
                        			  'deleted','invalid_email','email_opt_out'),
                       'contacts'=>	array('do_not_call',
                        			  		'deleted','invalid_email','email_opt_out'),
                       'accounts'=>'deleted',
                       'opportunities' =>'deleted',
                       'cases' => 'deleted',
                       'calls' => 'deleted',
                       'meetings' => 'deleted',
                       'bugs'  =>'deleted',
                       'campaigns'=>'deleted',
                       'prospects'=>array('do_not_call','invalid_email','email_opt_out'),
                       'fields_meta_data'=>'mass_update',
                       'project_task'=>array('order_number','utilization'));

    $q='';
    foreach($tabAndCols as $tab=>$col){
    	if(is_array($col)){
			foreach($col as $c){
				$res = query_Constraints($tab,$c);
				while($consts = $email->db->fetchByAssoc($res)){
					   $q .=' ALTER TABLE '.$tab.' DROP CONSTRAINT '.$consts['CONSTRAINT_NAME'].';';
			   }
			}
	    }
	    else{
			 //echo 'comes ere';
			 $res = query_Constraints($tab,$col);
			 while($consts = $email->db->fetchByAssoc($res)){
				  $q .=' ALTER TABLE '.$tab.' DROP CONSTRAINT '.$consts['CONSTRAINT_NAME'].';';
			 }
	     }
     }
    //echo 'proces '.$q;
    if($return_query){
    	return $q;
    }
    if($q != null){
	  $email->db->query($q);
	}
	return;
}

function query_Constraints($table_name,$column_name){
$email = new Email();
$q="with constraint_depends
	as
	(
		select c.TABLE_SCHEMA, c.TABLE_NAME, c.COLUMN_NAME, c.CONSTRAINT_NAME
		  from INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE as c
		 union all
		select s.name, o.name, c.name, d.name
		  from sys.default_constraints as d
		  join sys.objects as o
			on o.object_id = d.parent_object_id
		  join sys.columns as c
			on c.object_id = o.object_id and c.column_id = d.parent_column_id
		  join sys.schemas as s
			on s.schema_id = o.schema_id
   )
	select CONSTRAINT_NAME
	from constraint_depends
	where TABLE_NAME = '$table_name' and COLUMN_NAME = '$column_name'";

 //echo $q;
 return $email->db->query($q);
}
?>