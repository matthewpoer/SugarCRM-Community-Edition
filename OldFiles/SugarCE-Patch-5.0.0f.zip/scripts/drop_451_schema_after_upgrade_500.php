<?php
if(!defined('sugarEntry'))define('sugarEntry', true);

/**
 * This script executes after the files are copied during the install.
 *
 * LICENSE: The contents of this file are subject to the SugarCRM Professional
 * End User License Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/EULA.  By installing or using this file, You have
 * unconditionally agreed to the terms and conditions of the License, and You
 * may not use this file except in compliance with the License.  Under the
 * terms of the license, You shall not, among other things: 1) sublicense,
 * resell, rent, lease, redistribute, assign or otherwise transfer Your
 * rights to the Software, and 2) use the Software for timesharing or service
 * bureau purposes such as hosting the Software for commercial gain and/or for
 * the benefit of a third party.  Use of the Software may be subject to
 * applicable fees and any use of the Software without first paying applicable
 * fees is strictly prohibited.  You do not have the right to remove SugarCRM
 * copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2005 SugarCRM, Inc.; All Rights Reserved.
 *
 * $Id$
 */

require_once('include/utils.php');
require_once('include/database/PearDatabase.php');
require_once('include/database/DBManager.php');
require_once('include/database/DBManagerFactory.php');
require_once("include/entryPoint.php");
require_once("modules/Emails/Email.php");


function drop_preUpgardeSchema($return_query = false){
global $sugar_config;
$email = new Email();
$dropSchema = array(
				 'emails'        		  =>array('dropTable'=>false,
												  'columns' =>array('date_start','time_start','description','description_html','from_addr',
																	'from_name','to_addrs','to_addrs_ids','to_addrs_names','to_addrs_emails',
																	'cc_addrs','cc_addrs_ids','cc_addrs_names','cc_addrs_emails','reply_to_name','reply_to_addr',
																	'bcc_addrs','bcc_addrs_ids','bcc_addrs_names','bcc_addrs_emails','raw_source')
												  ),
				  'accounts_contacts'     =>array('dropTable'=>false,'indices'=>array('idx_acc_cont_acc','idx_acc_cont_cont')),
				  'emails_accounts'       =>array('dropTable'=>false,'indices'=>array('idx_acc_email_acc','idx_acc_email_email')),
				  'accounts_opportunities'=>array('dropTable'=>false,'indices'=>array('idx_acc_opp_acc','idx_acc_opp_opp','idx_a_o_opp_acc_del')),
				  'email_addresses'       =>array('dropTable'=>false,'indices'=>array('idx_email_address_opt_invalid')),
				  'emails_project_tasks'  =>array('dropTable'=>false,'indices'=>array('idx_ept_email','idx_ept_project_task')),
				  'meetings'  			  =>array('dropTable'=>false,'indices'=>array('idx_meetings_status_d','idx_meet_team_user_del','idx_notes_teamid')),
				  'project_task'	      =>array('dropTable'=>false,'columns'=>array('time_due','status','date_due','parent_id','order_number','task_number','depends_on_id','estimated_effort','utilization','time_start_backed')),
				  'fields_meta_data'	  =>array('dropTable'=>false,'columns'=>array('label','data_type','required_option','max_size','mass_update')),
				  'prospects'			  =>array('dropTable'=>false,'columns'=>array('email1','email2','invalid_email','email_opt_out')),
				  'contacts'			  =>array('dropTable'=>false,'columns'=>array('email1','email2','invalid_email','email_opt_out'),'indices'=>array('idx_contact_del_team','idx_cont_email1','idx_cont_email2')),
				  'leads'			 	  =>array('dropTable'=>false,'columns'=>array('email1','email2','invalid_email','email_opt_out'),'indices'=>array('idx_lead_email1','idx_lead_email2')),
				  'accounts'			  =>array('dropTable'=>false,'columns'=>array('email1','email2')),
				  'users'				  =>array('dropTable'=>false,'columns'=>array('email1','email2'),'indices'=>array('user_name_idx')),
				  'opportunities'		  =>array('dropTable'=>false,'columns' =>array('amount_backup')),
				  'cases'                 =>array('dropTable'=>false,'indices'=>array('idx_assigneduserid_status','idx_cases_teamid','idx_ass_sta_del')),
				  'calls'                 =>array('dropTable'=>false,'indices'=>array('idx_par_par_sta_del','idx_calls_status_d')),
				  'tracker'               =>array('dropTable'=>false,'indices'=>array('idx_userid','idx_userid_itemid','idx_tracker_action')),
				  'emails_accounts'  	  =>array('dropTable'=>true),
				  'emails_bugs'      	  =>array('dropTable'=>true),
				  'emails_cases'     	  =>array('dropTable'=>true),
				  'emails_contacts'  	  =>array('dropTable'=>true),
				  'emails_leads'     	  =>array('dropTable'=>true),
				  'emails_opportunities'  =>array('dropTable'=>true),
				  'emails_projects'       =>array('dropTable'=>true),
				  'emails_project_tasks'  =>array('dropTable'=>true),
				  'emails_prospects'      =>array('dropTable'=>true),
				  'emails_quotes'         =>array('dropTable'=>true),
				  'emails_tasks'          =>array('dropTable'=>true),
				  'emails_users'          =>array('dropTable'=>true),
				  'project_relation'      =>array('dropTable'=>true)
			);

    $dbType = $sugar_config['dbconfig']['db_type'];
    $returnAllQueries = '';
	foreach($dropSchema as $table => $tableArray) {
		if($dbType == 'mysql'){
			if(isset($tableArray['dropTable']) && $tableArray['dropTable']){
			  $qT ="DROP TABLE {$table}";
			  if($return_query){
			  	$returnAllQueries .=$qT.";";
			  }
			  else{
			  	$r = $email->db->query($qT, false);
			  }
			  echo 'Dropped Table '.$qT.'</br>';
			}
			else{
			  if(isset($tableArray['columns']) && $tableArray['columns'] != null){
			  	foreach($tableArray['columns'] as $column){
			  	 $qC = "ALTER TABLE {$table} DROP COLUMN {$column}";
			  	 if($return_query){
			  		$returnAllQueries .=$qC.";";
			  	 }
			  	 else{
			  	    $r = $email->db->query($qC, false);
			  	}
			   }
			  	//take the last column out
			  	//$qC = substr($qC, 0, strlen($qC)-1);
			  	//$r = $email->db->query($qC, false,'',true);
			  }
			  if(isset($tableArray['indices']) && $tableArray['indices'] != null){
                 foreach($tableArray['indices'] as $index){
			  	  $qI ="ALTER TABLE {$table} DROP INDEX {$index}";
                  if($return_query){
			  		$returnAllQueries .=$qI.";";
			  	  }
			  	  else{
                  $r = $email->db->query($qI, false);
			  	 }
                }
			  }
			}
	    }
	  	if($dbType == 'mssql'){
			if(isset($tableArray['dropTable']) && $tableArray['dropTable']){
			  //$qT= "IF EXISTS(SELECT 1 FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'{$table}') AND type = (N'U')) DROP TABLE {$table}";
			  $qT ="DROP TABLE {$table}";
			  if($return_query){
			  	 $returnAllQueries .=$qT.";";
			   }
			  else{
			  	 $r = $email->db->query($qT, false);
			  }
			}
			else{
			  if(isset($tableArray['columns']) && $tableArray['columns'] != null){
			  	//$qC = "ALTER TABLE {$table}"
			  	foreach($tableArray['columns'] as $column){
			  	 $qC = "ALTER TABLE {$table} DROP COLUMN {$column}";
			  	 if($return_query){
			  		$returnAllQueries .=$qC.";";
			  	 }
			  	 else{
			  	 	$r = $email->db->query($qC, false);
			  	 }
			  	}
			  	//take the last column out
			  	//$r = $email->db->query($qC, false);
			  }
			  if(isset($tableArray['indices']) && $tableArray['indices'] != null){
	            foreach($tableArray['indices'] as $index){
			  	  $qI ="DROP INDEX {$index} ON {$table}";
                  if($return_query){
			  		$returnAllQueries .=$qI.";";
			  	 }
			  	 else{
                    $r = $email->db->query($qI, false);
			  	 }
	            }
			  }
			  if(isset($tableArray['constraints']) && $tableArray['constraints'] != null){
			  	foreach($tableArray['constraints'] as $constraint){
			  	$qConst ="ALTER TABLE {$table} DROP CONSTRAINT {$constraint}";
			  	if($return_query){
			  		$returnAllQueries .=$qConst.";";
			  	 }
			  	 else{
			  		$r = $email->db->query($qConst, false);
			  	 }
			  }
			}
		  }
	    }
	   	if($dbType == 'oci8'){
			if(isset($tableArray['dropTable']) && $tableArray['dropTable']){
			  $qT ="DROP TABLE {$table} CASCADE CONSTRAINTS";
			  if($return_query){
			  	   $returnAllQueries .=$qT.";";
			  	}
			  	 else{
			  	   $r = $email->db->query($qT, false);
			  	}
			  echo 'Dropped Table '.$qT.'</br>';
			}
			else{
			  if(isset($tableArray['columns']) && $tableArray['columns'] != null){
			  	foreach($tableArray['columns'] as $column){
			  	 $qC = "ALTER TABLE {$table} DROP COLUMN {$column}";
			  	 if($return_query){
			  		$returnAllQueries .=$qC.";";
			  	 }
			  	 else{
			  	 	$r = $email->db->query($qC, false);
			  	 }
			  	}
			  }
			  if(isset($tableArray['indices']) && $tableArray['indices'] != null){
                 foreach($tableArray['indices'] as $index){
			  	  $qI ="DROP INDEX {$index}";
                 if($return_query){
			  		$returnAllQueries .=$qI.";";
			  	 }
			  	 else{
                  $r = $email->db->query($qI, false);
			  	 }
                }
			  }
			  if(isset($tableArray['constraints']) && $tableArray['constraints'] != null){
				foreach($tableArray['constraints'] as $constraint){
				  	$qConst .="ALTER TABLE {$table} DROP CONSTRAINT {$constraint}";
			  		if($return_query){
			  			$returnAllQueries .=$qConst.";";
			  	    }
			  	 else{
			  		 	$r = $email->db->query($qConst, false);
			  	   }
			     }
			  }
			}
	    }
	}

  if($return_query){
  	return $returnAllQueries;
  }
}
?>