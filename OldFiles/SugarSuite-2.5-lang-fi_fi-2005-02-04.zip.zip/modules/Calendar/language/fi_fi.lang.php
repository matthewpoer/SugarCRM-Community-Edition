<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Calendar',
  'LBL_MODULE_TITLE' => 'Calendar',
  'LNK_NEW_CALL' => 'Luo soitto',
  'LNK_NEW_MEETING' => 'Luo tapaaminen',
  'LNK_NEW_APPOINTMENT' => 'Luo tapaaminen',
  'LNK_NEW_TASK' => 'Luo teht�v�',
  'LNK_CALL_LIST' => 'Soitot',
  'LNK_MEETING_LIST' => 'Tapaamiset',
  'LNK_TASK_LIST' => 'Teht�v�t',
  'LNK_VIEW_CALENDAR' => 'T�n��n',
  'LBL_MONTH' => 'Kuukausi',
  'LBL_DAY' => 'P�iv�',
  'LBL_YEAR' => 'Vuosi',
  'LBL_WEEK' => 'Viikko',
  'LBL_PREVIOUS_MONTH' => 'Edellinen kuukausi',
  'LBL_PREVIOUS_DAY' => 'Edellinen p�iv�',
  'LBL_PREVIOUS_YEAR' => 'Edellinen vuosi',
  'LBL_PREVIOUS_WEEK' => 'Edellinen viikko',
  'LBL_NEXT_MONTH' => 'Seuraava kuukausi',
  'LBL_NEXT_DAY' => 'Seuraava p�iv�',
  'LBL_NEXT_YEAR' => 'Seuraava vuosi',
  'LBL_NEXT_WEEK' => 'Seuraava viikko',
  'LBL_AM' => 'AM',
  'LBL_PM' => 'PM',
  'LBL_SCHEDULED' => 'Aikataulutettu',
  'LBL_BUSY' => 'Varattu',
  'LBL_CONFLICT' => 'P��llekk�inen',
  'LBL_USER_CALENDARS' => 'K�ytt�jien kalenterit',
);

$mod_list_strings = array (
  'dom_cal_weekdays' => 
  array (
    0 => 'Su',
    1 => 'Ma',
    2 => 'Ti',
    3 => 'Ke',
    4 => 'To',
    5 => 'Pe',
    6 => 'La',
  ),
  'dom_cal_weekdays_long' => 
  array (
    0 => 'Sunnuntai',
    1 => 'Maanantai',
    2 => 'Tiistai',
    3 => 'Keskiviikko',
    4 => 'Torstai',
    5 => 'Perjantai',
    6 => 'Lauantai',
  ),
  'dom_cal_month' => 
  array (
    0 => '',
    1 => 'Tammi',
    2 => 'Helmi',
    3 => 'Maalis',
    4 => 'Huhti',
    5 => 'Touko',
    6 => 'Kes�',
    7 => 'Hein�',
    8 => 'Elo',
    9 => 'Syys',
    10 => 'Loka',
    11 => 'Marras',
    12 => 'Joulu',
  ),
  'dom_cal_month_long' => 
  array (
    0 => '',
    1 => 'Tammikuu',
    2 => 'Helmikuu',
    3 => 'Maaliskuu',
    4 => 'Huhtikuu',
    5 => 'Toukokuu',
    6 => 'Kes�kuu',
    7 => 'Hein�kuu',
    8 => 'Elokuu',
    9 => 'Syyskuu',
    10 => 'Lokakuu',
    11 => 'Marraskuu',
    12 => 'Joulukuu',
  ),
);


?>