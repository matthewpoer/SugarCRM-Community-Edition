<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Liidit',
  'LBL_INVITEE' => 'Raportoi suoraan',
  'LBL_MODULE_TITLE' => 'Leedit',
  'LBL_SEARCH_FORM_TITLE' => 'Hae liidi',
  'LBL_LIST_FORM_TITLE' => 'Liidilista',
  'LBL_NEW_FORM_TITLE' => 'Uusi liidi',
  'LBL_CONTACT_OPP_FORM_TITLE' => 'Liidi-mahdollisuus:',
  'LBL_CONTACT' => 'Liidi:',
  'LBL_BUSINESSCARD' => 'Muunna liidi',
  'LBL_LIST_NAME' => 'Nimi',
  'LBL_LIST_LAST_NAME' => 'Sukunimi',
  'LBL_LIST_CONTACT_NAME' => 'Liidin nimi',
  'LBL_LIST_TITLE' => 'Asema',
  'LBL_LIST_ACCOUNT_NAME' => 'Asiakas',
  'LBL_LIST_EMAIL_ADDRESS' => 'S�hk�posti',
  'LBL_LIST_PHONE' => 'Puhelin',
  'LBL_LIST_CONTACT_ROLE' => 'Rooli',
  'LBL_LIST_FIRST_NAME' => 'Etunimi',
  'LBL_LIST_REFERED_BY' => 'Viitattu kohteesta',
  'LBL_LIST_LEAD_SOURCE' => 'Liidin l�hde',
  'LBL_LIST_STATUS' => 'Tila',
  'LBL_LIST_DATE_ENTERED' => 'Luontip�iv�',
  'LBL_LIST_LEAD_SOURCE_DESCRIPTION' => 'Liidin l�hteen kuvaus',
  'LBL_LIST_MY_LEADS' => 'Omat liidit',
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_account_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_email2' => 'LBL_LIST_EMAIL_ADDRESS',
  'LBL_EXISTING_CONTACT' => 'K�yt� olemassaolevaa kontaktia',
  'LBL_CREATED_CONTACT' => 'Uusi kontakti luotu',
  'LBL_EXISTING_OPPORTUNITY' => 'K�ytti olemassaolevaa mahdollisuutta',
  'LBL_CREATED_OPPORTUNITY' => 'Uusi mahdollisuus luotu',
//END DON'T CONVERT
  'LBL_EXISTING_ACCOUNT' => 'K�ytti olemassaolevaa asiakasta',
  'LBL_CREATED_ACCOUNT' => 'Uusi asiakas luotu',
  'LBL_CREATED_CALL' => 'Uusi puhelinsoitto luotu',
  'LBL_CREATED_MEETING' => 'Uusi tapaaminen luotu',
  'LBL_BACKTOLEADS' => 'Takaisin liideihin',
  'LBL_CONVERTLEAD' => 'Muunna liidi',
  'LBL_NAME' => 'Nimi:',
  'LBL_CONTACT_NAME' => 'Liidin nimi:',
  'LBL_CONTACT_INFORMATION' => 'Liidin tiedot',
  'LBL_FIRST_NAME' => 'Etunimi:',
  'LBL_OFFICE_PHONE' => 'Toimiston puhelin:',
  'LBL_ACCOUNT_NAME' => 'Asiakas:',
  'LBL_OPPORTUNITY_NAME' => 'Mahdollisuuden nimi:',
  'LBL_OPPORTUNITY_AMOUNT' => 'Myyntimahdollisuuksien summa:',
  'LBL_ANY_PHONE' => 'Muu puhelin:',
  'LBL_PHONE' => 'Puhelin:',
  'LBL_LAST_NAME' => 'Sukunimi:',
  'LBL_MOBILE_PHONE' => 'Matkapuhelin:',
  'LBL_HOME_PHONE' => 'Koti:',
  'LBL_LEAD_SOURCE' => 'Liidin l�hde:',
  'LBL_STATUS' => 'Tila:',
  'LBL_LEAD_SOURCE_DESCRIPTION' => 'Liidin l�hteen kuvaus:',
  'LBL_STATUS_DESCRIPTION' => 'Tilan kuvaus:',
  'LBL_OTHER_PHONE' => 'Muu puhelin:',
  'LBL_FAX_PHONE' => 'Faksi:',
  'LBL_TITLE' => 'Asema:',
  'LBL_DEPARTMENT' => 'Osasto:',
  'LBL_EMAIL_ADDRESS' => 'S�hk�posti:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Muu s�hk�posti:',
  'LBL_ANY_EMAIL' => 'Muu s�hk�posti:',
  'LBL_REPORTS_TO' => 'Raportoi henkil�lle:',
  'LBL_DO_NOT_CALL' => '�l� soita:',
  'LBL_EMAIL_OPT_OUT' => 'Ei s�hk�postia:',
  'LBL_PRIMARY_ADDRESS' => 'Ensisijainen osoite:',
  'LBL_ALTERNATE_ADDRESS' => 'Muu osoite:',
  'LBL_ANY_ADDRESS' => 'Muu osoite:',
  'LBL_REFERED_BY' => 'Viitattu kohteesta:',
  'LBL_CITY' => 'Kaupunki:',
  'LBL_STATE' => 'Osavaltio:',
  'LBL_POSTAL_CODE' => 'Postinumero:',
  'LBL_COUNTRY' => 'Maa:',
  'LBL_DESCRIPTION_INFORMATION' => 'Kuvaus',
  'LBL_ADDRESS_INFORMATION' => 'Osoitetiedot',
  'LBL_DESCRIPTION' => 'Kuvaus:',
  'LBL_CONTACT_ROLE' => 'Rooli:',
  'LBL_OPP_NAME' => 'Mahdollisuuden nimi:',
  'LBL_IMPORT_VCARD' => 'Tuo vCard',
  'LNK_IMPORT_VCARD' => 'Luo vCard:n avulla',
  'LBL_IMPORT_VCARDTEXT' => 'Luo liidi automaattisesti tuomalla vCard-tiedosto.',
  'LBL_DUPLICATE' => 'Samankaltaisia liidej�',
  'MSG_DUPLICATE' => 'Samankaltaisia liidej� on l�ydetty. Valitse liidit jotka haluat liitt�� tietueisiin jotka luodaan t�m�n konversion aikana. Kun olet valmis, valitse seuraava',
  'LBL_ADD_BUSINESSCARD' => 'Lis�� k�yntikortti',
  'LNK_NEW_APPOINTMENT' => 'Luo tapaaminen',
  'LNK_NEW_LEAD' => 'Luo liidi',
  'LNK_LEAD_LIST' => 'Liidit',
  'NTC_DELETE_CONFIRMATION' => 'Haluatko poistaa t�m�n tietueen?',
  'NTC_REMOVE_CONFIRMATION' => 'Haluatko poistaa liidin palvelupyynn�st�?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Haluatko poistaa t�m�n tietueen suorana raporttina?',
  'ERR_DELETE_RECORD' => 'Poista liidi antamalla tietueen numero.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Kopioi ensisijainen osoite toissijaiseksi osoitteeksi',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Kopioi toissijainen osoite ensisijaiseksi osoitteeksi',
  'LNK_NEW_CONTACT' => 'Luo kontakti',
  'LNK_NEW_NOTE' => 'Luo muistio',
  'LNK_NEW_ACCOUNT' => 'Luo asiakas',
  'LNK_NEW_OPPORTUNITY' => 'Luo myyntimahdollisuus',
  'LNK_SELECT_ACCOUNT' => 'Valitse asiakas',
  'LBL_SALUTATION' => 'Tervehdys',
  'NTC_OPPORTUNITY_REQUIRES_ACCOUNT' => 'Myyntimahdollisuuden luonti vaatii asiakkaan.\\n Luo uusi tai valitse olemassaoleva asiakas.',
);


?>