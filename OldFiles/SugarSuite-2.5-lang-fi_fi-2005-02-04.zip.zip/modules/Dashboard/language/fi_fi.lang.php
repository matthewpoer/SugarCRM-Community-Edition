<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Johdon n�kym�',
  'LBL_MODULE_TITLE' => 'Johdon n�kym�:',
  'LBL_SALES_STAGE_FORM_TITLE' => 'Myyntiennuste myynnin tilan mukaan',
  'LBL_SALES_STAGE_FORM_DESC' => 'Kumulatiiviset myyntimahdollisuudet valittujen myynnin tilojen ja k�ytt�jien mukaan jossa oletettu p��t�sp�iv� on m��ritellyll� p�iv�m��r�alueella.',
  'LBL_YEAR_BY_OUTCOME' => 'Pipeline By Month By Outcome',
  'LBL_MONTH_BY_OUTCOME_DESC' => 'Kumulatiiviset myyntimahdollisuudet kuukausittain toteuman ja valittujen k�ytt�jien mukaan jossa oletettu p��t�sp�iv� on m��ritellyll� p�iv�m��r�alueella. Toteuman pohjana oleva myynnin tila on Voitettu, Menetetty tai jokin muu arvo.',
  'LBL_LEAD_SOURCE_FORM_TITLE' => 'Myyntimahdollisuudet liidin l�hteen mukaan',
  'LBL_LEAD_SOURCE_FORM_DESC' => 'Kumulatiiviset myyntimahdollisuudet valittujen k�ytt�jien ja valitun liidin l�hteen mukaan.',
  'LBL_LEAD_SOURCE_BY_OUTCOME' => 'Myyntimahdollisuudet liidin l�hteen ja toteuman mukaan',
  'LBL_LEAD_SOURCE_BY_OUTCOME_DESC' => 'Kumulatiiviset myyntimahdollisuudet kuukausittain toteuman ja valittujen k�ytt�jien mukaan jossa oletettu p��t�sp�iv� on m��ritellyll� p�iv�m��r�alueella. Toteuman pohjana oleva myynnin tila on Voitettu, Menetetty tai jokin muu arvo.',
  'LBL_PIPELINE_FORM_TITLE_DESC' => 'Kumulatiiviset myyntimahdollisuudet valittujen myynnin vaiheiden mukaan jossa oletettu p��t�sp�iv� on m��ritellyll� p�iv�m��r�alueella.',
  'LBL_DATE_RANGE' => 'P�iv�m��r�alue on',
  'LBL_DATE_RANGE_TO' => 'saakka',
  'ERR_NO_OPPS' => 'Luo myyntimahdollisuuksia n�hd�ksesi graafit.',
  'LBL_TOTAL_PIPELINE' => 'Myyntiennuste yhteens�',
  'LBL_ALL_OPPORTUNITIES' => 'Myyntimahdollisuudet yhteens� ',
  'LBL_OPP_SIZE' => 'Myyntimahdollisuuden koko',
  'LBL_OPP_THOUSANDS' => 'K',
  'NTC_NO_LEGENDS' => 'Ei mit��n',
  'LBL_LEAD_SOURCE_OTHER' => 'Muu',
  'LBL_EDIT' => 'Muokkaa',
  'LBL_REFRESH' => 'P�ivit�',
  'LBL_CREATED_ON' => 'Viimeksi suoritettu',
  'LBL_OPPS_WORTH' => 'opportunities worth',
  'LBL_OPPS_IN_STAGE' => 'myyntimahdollisuudet joissa myynnin tila on',
  'LBL_OPPS_IN_LEAD_SOURCE' => 'myyntimahdollisuudet joissa liidin l�hde on',
  'LBL_OPPS_OUTCOME' => 'mahdollisuudet joissa toteuma on',
  'LBL_ROLLOVER_DETAILS' => 'Rollover a bar for details.',
  'LBL_ROLLOVER_WEDGE_DETAILS' => 'Rollover a wedge for details.',
  'LBL_USERS' => 'K�ytt�j�t:',
  'LBL_SALES_STAGES' => 'Myynnin tilat:',
  'LBL_LEAD_SOURCES' => 'Liidin l�hteet:',
  'LBL_DATE_START' => 'Aloitusp�iv�:',
  'LBL_DATE_END' => 'Lopetusp�iv�:',
  'LBL_YEAR' => 'Year:',
  'LNK_NEW_CONTACT' => 'Luo kontakti',
  'LNK_NEW_ACCOUNT' => 'Luo asiakas',
  'LNK_NEW_OPPORTUNITY' => 'Luo myyntimahdollisuus',
  'LNK_NEW_QUOTE' => 'Luo tarjous',
  'LNK_NEW_LEAD' => 'Luo liidi',
  'LNK_NEW_CASE' => 'Luo palvelupyynt�',
  'LNK_NEW_NOTE' => 'Luo muistio',
  'LNK_NEW_CALL' => 'Luo puhelinsoitto',
  'LNK_NEW_MEETING' => 'Luo tapaaminen',
  'LNK_NEW_TASK' => 'Luo teht�v�',
  'LNK_NEW_ISSUE' => 'Report Bug',
  'LBL_MONTH_BY_OUTCOME' => 'Myyntiennuste kuukausittan toteuman mukaan',
);


?>