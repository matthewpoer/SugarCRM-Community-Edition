<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'K�ytt�j�t',
  'LBL_MODULE_TITLE' => 'K�ytt�j�t:',
  'LBL_SEARCH_FORM_TITLE' => 'Hae k�ytt�j�',
  'LBL_LIST_FORM_TITLE' => 'K�ytt�j�t',
  'LBL_NEW_FORM_TITLE' => 'Uusi k�ytt�j�',
  'LBL_USER' => 'K�ytt�j�t:',
  'LBL_LOGIN' => 'Kirjaudu',
  'LBL_RESET_PREFERENCES' => 'Palauta oletusasetukset',
  'LBL_TIME_FORMAT' => 'Aikamuotoilu:',
  'LBL_DATE_FORMAT' => 'Date Format:',
  'LBL_TIMEZONE' => 'Current Time:',
  'LBL_CURRENCY' => 'Valuutta:',
  'LBL_LIST_NAME' => 'Name',
  'LBL_LIST_LAST_NAME' => 'Sukunimi',
  'LBL_LIST_USER_NAME' => 'K�ytt�j�tunnus',
  'LBL_LIST_DEPARTMENT' => 'Osasto',
  'LBL_LIST_EMAIL' => 'S�hk�posti',
  'LBL_LIST_PRIMARY_PHONE' => 'Ensisijainen puhelin',
  'LBL_LIST_ADMIN' => 'Admin',
  'LBL_NEW_USER_BUTTON_TITLE' => 'Uusi k�ytt�j� [Alt+N]',
  'LBL_NEW_USER_BUTTON_LABEL' => 'Uusi k�ytt�j�',
  'LBL_NEW_USER_BUTTON_KEY' => 'N',
  'LBL_ERROR' => 'Virhe:',
  'LBL_PASSWORD' => 'Salasana:',
  'LBL_USER_NAME' => 'K�ytt�j�tunnus:',
  'LBL_FIRST_NAME' => 'Etunimi:',
  'LBL_LAST_NAME' => 'Sukunimi:',
  'LBL_USER_SETTINGS' => 'K�ytt�j�n asetukset',
  'LBL_THEME' => 'Sivumalli:',
  'LBL_LANGUAGE' => 'Kieli:',
  'LBL_ADMIN' => 'Yll�pit�j�:',
  'LBL_USER_INFORMATION' => 'K�ytt�j�n tiedot',
  'LBL_OFFICE_PHONE' => 'Toimiston puhelin:',
  'LBL_REPORTS_TO' => 'Raportoi henkil�lle:',
  'LBL_OTHER_PHONE' => 'Muu:',
  'LBL_OTHER_EMAIL' => 'Muu s�hk�posti:',
  'LBL_NOTES' => 'Muistiot:',
  'LBL_DEPARTMENT' => 'Osasto:',
  'LBL_STATUS' => 'Tila:',
  'LBL_TITLE' => 'Asema:',
  'LBL_ANY_PHONE' => 'Muu puhelin:',
  'LBL_ANY_EMAIL' => 'Muu s�hk�posti:',
  'LBL_ADDRESS' => 'Osoite:',
  'LBL_CITY' => 'Kaupunki:',
  'LBL_STATE' => 'Osavaltio:',
  'LBL_POSTAL_CODE' => 'Postinumero:',
  'LBL_COUNTRY' => 'Maa:',
  'LBL_NAME' => 'Name:',
  'LBL_MOBILE_PHONE' => 'K�sipuhelin:',
  'LBL_OTHER' => 'Muu:',
  'LBL_FAX' => 'Faksi:',
  'LBL_EMAIL' => 'Email:',
  'LBL_HOME_PHONE' => 'Kotipuhelin:',
  'LBL_ADDRESS_INFORMATION' => 'Osoitetiedot',
  'LBL_PRIMARY_ADDRESS' => 'Ensisijainen osoite:',
  'LBL_CHANGE_PASSWORD_BUTTON_TITLE' => 'Muuta salasana [Alt+P]',
  'LBL_CHANGE_PASSWORD_BUTTON_KEY' => 'P',
  'LBL_CHANGE_PASSWORD_BUTTON_LABEL' => 'Muuta salasana',
  'LBL_LOGIN_BUTTON_TITLE' => 'Kirjaudu [Alt+L]',
  'LBL_LOGIN_BUTTON_KEY' => 'L',
  'LBL_LOGIN_BUTTON_LABEL' => 'Kirjaudu',
  'LBL_CHANGE_PASSWORD' => 'Muuta salasana',
  'LBL_OLD_PASSWORD' => 'Vanha salasana:',
  'LBL_NEW_PASSWORD' => 'Uusi salasana:',
  'LBL_CONFIRM_PASSWORD' => 'Vahvista salasana:',
  'ERR_ENTER_OLD_PASSWORD' => 'Anna vanha salasana.',
  'ERR_ENTER_NEW_PASSWORD' => 'Anna uusi salasana.',
  'ERR_ENTER_CONFIRMATION_PASSWORD' => 'Vahvista salasana.',
  'ERR_REENTER_PASSWORDS' => 'Anna salasana uudelleen.  \\"Uusi salasana\\" ja \\"vahvista salasana\\" tiedot eiv�t t�sm��.',
  'ERR_INVALID_PASSWORD' => 'Anna k�ytt�j�tunnus ja salasana.',
  'ERR_PASSWORD_CHANGE_FAILED_1' => 'Salasanan vaihto ei onnistunut',
  'ERR_PASSWORD_CHANGE_FAILED_2' => ' ei onnistunut. Aseta uusi salasana.',
  'ERR_PASSWORD_INCORRECT_OLD' => 'Virheellinen salasana k�ytt�j�lle $this->user_name. Anna salasanat uudelleen.',
  'ERR_USER_NAME_EXISTS_1' => 'K�ytt�j�tunnus',
  'ERR_USER_NAME_EXISTS_2' => ' on jo k�yt�ss�. K�ytt�j�tunnuksen tulee olla yksil�llinen. <br>Valitse toinen k�ytt�j�tunnus.',
  'ERR_LAST_ADMIN_1' => 'K�ytt�j�tunnus',
  'ERR_LAST_ADMIN_2' => ' on viimeinen Admin k�ytt�j�. Ainakin yhden k�ytt�j�n tulee olla Admin k�ytt�j�.<br>Tarkista Admin-k�ytt�j�n asetukset.',
  'LNK_NEW_USER' => 'Luo k�ytt�j�',
  'LNK_USER_LIST' => 'K�ytt�j�t',
  'ERR_DELETE_RECORD' => 'Poista asiakas antamalla tietueen numero.',
  'LBL_RECEIVE_NOTIFICATIONS' => 'Muistutus teht�v�st�:',
  'LBL_RECEIVE_NOTIFICATIONS_TEXT' => 'L�het� muistutus s�hk�postilla kun teht�v� osoitetaan sinulle',
  'LBL_ADMIN_TEXT' => 'Antaa k�ytt�j�lle j�rjestelm�n yll�pit�j�n oikeudet',
  'LBL_TIME_FORMAT_TEXT' => 'P�iv�yksen muotoilu',
  'LBL_DATE_FORMAT_TEXT' => 'Set the display format for date stamps',
  'LBL_TIMEZONE_TEXT' => 'Set the current time',
  'LBL_GRIDLINE' => 'N�yt� ruudukko:',
  'LBL_GRIDLINE_TEXT' => 'S��telee taustaruudukkoa',
  'LBL_CURRENCY_TEXT' => 'Valitse oletusvaluutta',
  'LBL_DISPLAY_TABS' => 'Display Tabs',
  'LBL_HIDE_TABS' => 'Hide Tabs',
  'LBL_EDIT_TABS' => 'Edit Tabs',
  'LBL_CHOOSE_WHICH' => 'Choose which tabs are displayed',
);


?>