<?php
// created: 2009-06-04 19:14:16
$manifest = array (
  'acceptable_sugar_flavors' => 
  array (
    0 => 'OS',
  ),
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '4\\.5\\.1[m|n]',
    ),
  ),
  'author' => 'SugarCRM, Inc.',
  'copy_files' => 
  array (
    'from_dir' => 'SugarOS-for-Microsoft-Delta-4.5.1n',
    'to_dir' => '',
    'force_copy' => 
    array (
    ),
  ),
  'description' => '',
  'icon' => '',
  'is_uninstallable' => false,
  'offline_client_applicable' => true,
  'name' => 'SugarOS',
  'published_date' => '2009-06-04 19:14:16',
  'type' => 'patch',
  'version' => '4.5.1n',
);
?>
