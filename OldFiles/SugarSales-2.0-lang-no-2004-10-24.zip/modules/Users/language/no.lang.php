<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/include/language/en_us.lang.php,v 1.89 2004/10/25 02:32:20 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Brukere',
  'LBL_MODULE_TITLE' => 'Brukere : Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'S&oslash;k Bruker',
  'LBL_LIST_FORM_TITLE' => 'Brukerliste',
  'LBL_NEW_FORM_TITLE' => 'Ny Bruker',
  'LBL_USER' => 'Bruker:',
  'LBL_LOGIN' => 'Login',
  'LBL_RESET_PREFERENCES' => 'Reset To Default Preferences',
  'LBL_TIME_FORMAT' => 'Time Format:',
  'LBL_CURRENCY' => 'Currency:',
  'LBL_LIST_NAME' => 'Navn',
  'LBL_LIST_LAST_NAME' => 'Etternavn',
  'LBL_LIST_USER_NAME' => 'brukernavn',
  'LBL_LIST_DEPARTMENT' => 'Avdeling',
  'LBL_LIST_EMAIL' => 'Epost',
  'LBL_LIST_PRIMARY_PHONE' => 'Prim&aelig;r Telefon',
  'LBL_LIST_ADMIN' => 'Admin',
  'LBL_NEW_USER_BUTTON_TITLE' => 'Ny Bruker [Alt+N]',
  'LBL_NEW_USER_BUTTON_LABEL' => 'Ny Bruker',
  'LBL_NEW_USER_BUTTON_KEY' => 'N',
  'LBL_ERROR' => 'Feil:',
  'LBL_PASSWORD' => 'Passord:',
  'LBL_USER_NAME' => 'brukernavn:',
  'LBL_FIRST_NAME' => 'Fornavn:',
  'LBL_LAST_NAME' => 'Etternavn:',
  'LBL_USER_SETTINGS' => 'Brukerinnstillinger',
  'LBL_THEME' => 'Tema:',
  'LBL_LANGUAGE' => 'Spr&aring;k:',
  'LBL_ADMIN' => 'Admin:',
  'LBL_USER_INFORMATION' => 'Brukerinformasjon',
  'LBL_OFFICE_PHONE' => 'Firmatelefon:',
  'LBL_REPORTS_TO' => 'Rapporterer til:',
  'LBL_OTHER_PHONE' => 'Annen Tlf.:',
  'LBL_OTHER_EMAIL' => 'Annen Epost:',
  'LBL_NOTES' => 'Notater:',
  'LBL_DEPARTMENT' => 'Avdeling:',
  'LBL_STATUS' => 'Status:',
  'LBL_TITLE' => 'Tittel:',
  'LBL_ANY_PHONE' => 'Telefon:',
  'LBL_ANY_EMAIL' => 'Epost:',
  'LBL_ADDRESS' => 'Adresse:',
  'LBL_CITY' => 'By:',
  'LBL_STATE' => 'Fylke:',
  'LBL_POSTAL_CODE' => 'Postnr:',
  'LBL_COUNTRY' => 'Land:',
  'LBL_NAME' => 'Navn:',
  'LBL_MOBILE_PHONE' => 'Mobiltelefon:',
  'LBL_OTHER' => 'Annet:',
  'LBL_FAX' => 'Faks:',
  'LBL_EMAIL' => 'Epost:',
  'LBL_HOME_PHONE' => 'Hjemmetelefon:',
  'LBL_ADDRESS_INFORMATION' => 'Adresse Information',
  'LBL_PRIMARY_ADDRESS' => 'Prim&aelig;r Adresse:',
  'LBL_CHANGE_PASSWORD_BUTTON_TITLE' => 'Endre Passord[Alt+P]',
  'LBL_CHANGE_PASSWORD_BUTTON_KEY' => 'P',
  'LBL_CHANGE_PASSWORD_BUTTON_LABEL' => 'Endre Passord',
  'LBL_LOGIN_BUTTON_TITLE' => 'Login [Alt+L]',
  'LBL_LOGIN_BUTTON_KEY' => 'L',
  'LBL_LOGIN_BUTTON_LABEL' => 'Login',
  'LBL_CHANGE_PASSWORD' => 'Endre Passord',
  'LBL_OLD_PASSWORD' => 'Gammelt Passord:',
  'LBL_NEW_PASSWORD' => 'Nytt Passord:',
  'LBL_CONFIRM_PASSWORD' => 'Bekreft Passord:',
  'ERR_ENTER_OLD_PASSWORD' => 'Angi gammelt Passord.',
  'ERR_ENTER_NEW_PASSWORD' => 'Angi Nytt Passord.',
  'ERR_ENTER_CONFIRMATION_PASSWORD' => 'Bekreft Passord.',
  'ERR_REENTER_PASSWORDS' => 'Angi Passord igjen.  \\"Nytt Passord\\" og \\"bekreft Passord\\" stemte ikke.',
  'ERR_INVALID_PASSWORD' => 'Du m&aring; skrive et gyldig brukernavn og Passord.',
  'ERR_PASSWORD_CHANGE_FAILED_1' => 'Endring av Passord mislykktes for ',
  'ERR_PASSWORD_CHANGE_FAILED_2' => ' mislyktes. Det nye Passordet skal oppgis.',
  'ERR_PASSWORD_INCORRECT_OLD' => 'Forkort gammelt Passord for Bruker $this->user_name. Skriv Passord igjen.',
  'ERR_USER_NAME_EXISTS_1' => 'Brukernavnet ',
  'ERR_USER_NAME_EXISTS_2' => ' finnes allerede. Samme brukernavn er ikke tillat.<br>Skriv et unikt brukernavn.',
  'ERR_LAST_ADMIN_1' => 'Brukernavnet ',
  'ERR_LAST_ADMIN_2' => ' er den eneste Administrator.  Mindst en Bruker skal ha Administrator rettigheter.<br>Kontroller Admin bruker innstillingene.',
  'LNK_NEW_USER' => 'New User',
  'LNK_USER_LIST' => 'Users',
  'ERR_DELETE_RECORD' => 'Et Postnummer skal oppgis for &aring; slette Virksomheten.',
  'LBL_RECEIVE_NOTIFICATIONS' => 'Assignment Notification:',
  'LBL_RECEIVE_NOTIFICATIONS_TEXT' => 'Receive an e-mail notification when a record is assigned to you.',
  'LBL_ADMIN_TEXT' => 'Grants administrator privileges to this user',
  'LBL_TIME_FORMAT_TEXT' => 'Set the display format for time stamps',
  'LBL_GRIDLINE' => 'Show Gridlines:',
  'LBL_GRIDLINE_TEXT' => 'Controls gridlines on detail views',
  'LBL_CURRENCY_TEXT' => 'Select the default currency',
  'LBL_YAHOO_ID' => 'Yahoo ID:',
  'LNK_NEW_CONTACT' => 'Ny Kontakt',
  'LNK_NEW_ACCOUNT' => 'Ny Virksomhet',
  'LNK_NEW_OPPORTUNITY' => 'Ny Salgs Mulighet',
  'LNK_NEW_CASE' => 'Ny Sak',
  'LNK_NEW_NOTE' => 'Nytt Notat',
  'LNK_NEW_CALL' => 'Ny Samtale',
  'LNK_NEW_EMAIL' => 'Ny Epost',
  'LNK_NEW_MEETING' => 'Nytt M&oslash;te',
  'LNK_NEW_TASK' => 'Ny Oppgave',
);


?>