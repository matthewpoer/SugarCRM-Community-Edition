<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/include/language/en_us.lang.php,v 1.89 2004/10/25 02:32:20 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Virksomhet',
  'LBL_MODULE_TITLE' => 'Virksomhet: Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'S&oslash;k Virksomhet',
  'LBL_LIST_FORM_TITLE' => 'Liste virksomheter',
  'LBL_NEW_FORM_TITLE' => 'Ny Virksomhet',
  'LBL_MEMBER_ORG_FORM_TITLE' => 'Medlems Organisationer',
  'LBL_LIST_ACCOUNT_NAME' => 'Virksomhet',
  'LBL_LIST_CITY' => 'By',
  'LBL_LIST_WEBSITE' => 'Internett side',
  'LBL_LIST_STATE' => 'Fylke',
  'LBL_LIST_PHONE' => 'Telefon',
  'LBL_LIST_EMAIL_ADDRESS' => 'Epost Addresse',
  'LBL_LIST_CONTACT_NAME' => 'Kontakt Navn',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_website' => 'LBL_LIST_WEBSITE',
  'db_billing_address_city' => 'LBL_LIST_CITY',
//END DON'T CONVERT
  'LBL_ACCOUNT_INFORMATION' => 'oppf&oslash;ringen',
  'LBL_ACCOUNT' => 'Virksomhet:',
  'LBL_ACCOUNT_NAME' => 'Virksomhet:',
  'LBL_PHONE' => 'Telefon:',
  'LBL_WEBSITE' => 'Internett side:',
  'LBL_FAX' => 'Faks:',
  'LBL_TICKER_SYMBOL' => 'Ticker Symbol:',
  'LBL_OTHER_PHONE' => 'Annet Telefonnr:',
  'LBL_ANY_PHONE' => 'Telefon:',
  'LBL_MEMBER_OF' => 'Medlem av:',
  'LBL_EMAIL' => 'Epost:',
  'LBL_EMPLOYEES' => 'Ansatte:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Annen Epost:',
  'LBL_ANY_EMAIL' => 'Epost:',
  'LBL_OWNERSHIP' => 'Eier:',
  'LBL_RATING' => 'Vurdering:',
  'LBL_INDUSTRY' => 'Bransje:',
  'LBL_SIC_CODE' => 'SIC Kode:',
  'LBL_TYPE' => 'Type:',
  'LBL_ANNUAL_REVENUE' => 'Omsetning:',
  'LBL_ADDRESS_INFORMATION' => 'Adresse information',
  'LBL_BILLING_ADDRESS' => 'Faktura adresse:',
  'LBL_SHIPPING_ADDRESS' => 'Postadresse:',
  'LBL_ANY_ADDRESS' => 'Annen adresse:',
  'LBL_CITY' => 'By:',
  'LBL_STATE' => 'Fylke:',
  'LBL_POSTAL_CODE' => 'Postnummer:',
  'LBL_COUNTRY' => 'Land:',
  'LBL_DESCRIPTION_INFORMATION' => 'Beskrivelse',
  'LBL_DESCRIPTION' => 'Beskrivelse:',
  'NTC_COPY_BILLING_ADDRESS' => 'Kopier Faktura adresse til Postadresse',
  'NTC_COPY_SHIPPING_ADDRESS' => 'Kopier Postadresse til Faktura adresse',
  'NTC_REMOVE_MEMBER_ORG_CONFIRMATION' => 'Er du sikker p&aring; at du vil fjerne denne oppf&oslash;ringen som medlems organisasjon?',
  'LBL_DUPLICATE' => 'Possible Duplicate Account',
  'MSG_DUPLICATE' => 'Creating this account may potentialy create a duplicate account. You may either select an account from the list below or you may click on Create New Account to continue creating a new account with the previously entered data.',
  'LNK_NEW_ACCOUNT' => 'Ny Virksomhet',
  'LNK_ACCOUNT_LIST' => 'Accounts',
  'LBL_INVITEE' => 'Kontakter',
  'ERR_DELETE_RECORD' => 'Et Postnummer skal oppgis for &aring; slette Virksomheten.',
  'LNK_NEW_CONTACT' => 'Ny Kontakt',
  'LNK_NEW_OPPORTUNITY' => 'Ny Salgs Mulighet',
  'LNK_NEW_CASE' => 'Ny Sak',
  'LNK_NEW_NOTE' => 'Nytt Notat',
  'LNK_NEW_CALL' => 'Ny Samtale',
  'LNK_NEW_EMAIL' => 'Ny Epost',
  'LNK_NEW_MEETING' => 'Nytt M&oslash;te',
  'LNK_NEW_TASK' => 'Ny Oppgave',
);


?>