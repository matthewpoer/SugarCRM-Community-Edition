<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/include/language/en_us.lang.php,v 1.89 2004/10/25 02:32:20 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

//to translate, only modify the right value in each key/value pair
$app_list_strings = array (
//e.g. auf Deutsch 'Contacts'=>'Contakten',
  'moduleList' => 
  array (
    'Home' => 'Hjem',
    'Dashboard' => 'Oversikt',
    'Contacts' => 'Kontakter',
    'Accounts' => 'Virksomhet',
    'Opportunities' => 'Salgs Muligheter',
    'Cases' => 'Saker',
    'Notes' => 'Notater & Vedlegg',
    'Calls' => 'Samtaler',
    'Emails' => 'Eposter',
    'Meetings' => 'M&oslash;ter',
    'Tasks' => 'Oppgaver',
    'Calendar' => 'Calendar',
    'Leads' => 'Leads',
    'Activities' => 'Activities',
  ),
  'account_type_dom' => 
  array (
    '' => '',
    'Analyst' => 'Analytiker',
    'Competitor' => 'Konkurrent',
  //e.g. en fran�ais 'Analyst'=>'Analyste',
    'Customer' => 'Kunde',
    'Integrator' => 'Integrator',
    'Investor' => 'Investor',
    'Partner' => 'Partner',
    'Press' => 'Presse',
    'Prospect' => 'Kundeemne',
    'Reseller' => 'Forhandler',
    'Other' => 'Other',
    'Andre' => 'Annet',
  ),
  'industry_dom' => 
  array (
    '' => '',
    'Apparel' => 'Kl&aelig;r og t&oslash;y',
  //e.g. en espa�ol 'Apparel'=>'Ropa',
    'Banking' => 'Bank',
    'Biotechnology' => 'Bioteknologi',
    'Chemicals' => 'Kjemikalie',
    'Communications' => 'Kommunikasjon',
    'Construction' => 'Konstruksjon',
    'Consulting' => 'Konsult',
    'Education' => 'Uddannelse',
    'Electronics' => 'Elektronikk',
    'Energy' => 'Energi',
    'Engineering' => 'Ingeni&oslash;rer',
    'Entertainment' => 'Underholdning',
    'Environmental' => 'Milj&oslash;',
    'Finance' => 'Finans',
    'Food & Beverage' => 'Mat og drikke',
    'Government' => 'Offentlig forvaltning',
    'Healthcare' => 'Helse',
    'Hospitality' => 'Hotel/Restaurant',
    'Insurance' => 'Forsikring',
    'Machinery' => 'Maskinteknikk',
    'Manufacturing' => 'Produsent',
    'Media' => 'Media',
    'Not For Profit' => 'Non profit',
    'Recreation' => 'Turisme/reiser',
    'Retail' => 'Handel',
    'Shipping' => 'Frakt',
    'Technology' => 'Teknologi',
    'Telecommunications' => 'Telekommunikasjon',
    'Transportation' => 'Transport',
    'Utilities' => 'Verkt&oslash;y',
    'Other' => 'Other',
    'Andre' => 'Annet',
  ),
  'lead_source_dom' => 
  array (
    '' => '',
    'Cold Call' => 'Uinteressert',
    'Existing Customer' => 'Eksisterende kunde',
    'Self Generated' => 'Personlig',
    'Employee' => 'Ansatt',
    'Partner' => 'Partner',
    'Public Relations' => 'Public Relations',
    'Direct Mail' => 'Direct Mail',
    'Conference' => 'Konferanse',
    'Trade Show' => 'Messe',
    'Web Site' => 'Internet Side',
    'Word of mouth' => 'Muntlig',
    'Other' => 'Other',
    'Andre' => 'Annet',
  ),
  'opportunity_type_dom' => 
  array (
    '' => '',
    'Existing Business' => 'Eksisterende forretning',
    'New Business' => 'Ny forretning',
  ),
  'opportunity_relationship_type_default_key' => 'Primary Decision Maker',
  'opportunity_relationship_type_dom' => 
//       it is the key for the default opportunity_relationship_type_dom value
  array (
    '' => '',
    'Primary Decision Maker' => 'Prim&aelig;r beslutningstaker',
    'Business Decision Maker' => 'Forretningsmessig beslutningstaker',
    'Business Evaluator' => 'Forretningsmessig evaluator',
    'Technical Decision Maker' => 'Teknisk beslutningstaker',
    'Technical Evaluator' => 'Teknisk evaluator',
    'Executive Sponsor' => 'Ledelse',
    'Influencer' => 'Person med innflytelse',
    'Other' => 'Annet',
  ),
  'case_relationship_type_default_key' => 'Primary Contact',
  'case_relationship_type_dom' => 
//       it is the key for the default case_relationship_type_dom value
  array (
    '' => '',
    'Primary Contact' => 'Prim&aelig;r kontakt',
    'Alternate Contact' => 'Alternativ kontakt',
  ),
  'sales_stage_dom' => 
  array (
    'Prospecting' => 'Prospektering',
    'Qualification' => 'Kvalifikasjon',
    'Needs Analysis' => 'Analyse n&oslash;dvendig',
    'Value Proposition' => 'Foresl&aring; verdi',
    'Id. Decision Makers' => 'Identifiser beslutningstaker',
    'Perception Analysis' => 'Analyser oppfattelse',
    'Proposal/Price Quote' => 'Tilbud',
    'Negotiation/Review' => 'Forhandling/oppdatering',
    'Closed Won' => 'Avsluttet vunnet',
    'Closed Lost' => 'Avsluttet tapt',
  ),
  'activity_dom' => 
  array (
    'Call' => 'Call',
    'Meeting' => 'Meeting',
    'Task' => 'Task',
    'Email' => 'Email',
    'Note' => 'Note',
  ),
  'salutation_dom' => 
  array (
    '' => '',
    'Mr.' => 'Hr',
    'Ms.' => 'Fr&oslash;ken',
    'Mrs.' => 'Fru',
    'Dr.' => 'Dr.',
    'Prof.' => 'Prof.',
  ),
  'task_priority_dom' => 
  array (
    'High' => 'H&oslash;y',
    'Medium' => 'Medium',
    'Low' => 'Lav',
  ),
  'task_status_dom' => 
  array (
    'Not Started' => 'Ikke p&aring;begynt',
    'In Progress' => 'Aktiv',
    'Completed' => 'Avsluttet',
    'Pending Input' => 'Venter p&aring; opplysninger',
    'Deferred' => 'Kansellert',
  ),
  'meeting_status_dom' => 
  array (
    'Planned' => 'Planlagt',
    'Held' => 'Fullf&oslash;rt',
    'Not Held' => 'Ikke Fullf&oslash;rt',
  ),
  'call_status_dom' => 
  array (
    'Planned' => 'Planlagt',
    'Held' => 'Fullf&oslash;rt',
    'Not Held' => 'Ikke Fullf&oslash;rt',
  ),
  'call_direction_dom' => 
  array (
    'Inbound' => 'Inbound',
    'Outbound' => 'Outbound',
  ),
  'lead_status_dom' => 
  array (
    '' => '',
    'New' => 'New',
    'Assigned' => 'Assigned',
    'In Process' => 'In Process',
    'Converted' => 'Converted',
    'Recycled' => 'Recycled',
    'Dead' => 'Dead',
  ),
  'lead_status_noblank_dom' => 
  array (
    'New' => 'New',
    'Assigned' => 'Assigned',
    'In Process' => 'In Process',
    'Converted' => 'Converted',
    'Recycled' => 'Recycled',
    'Dead' => 'Dead',
  ),
  'case_status_default_key' => 'New',
  'case_status_dom' => 
//       it is the key for the default case_status_dom value
  array (
    'New' => 'Ny',
    'Assigned' => 'Tildelt',
    'Closed' => 'Avsluttet',
    'Pending Input' => 'Venter p&aring; opplysninger',
    'Rejected' => 'Avslag',
  ),
  'case_priority_default_key' => 'P2',
  'case_priority_dom' => 
  array (
    'P1' => 'High',
    'P2' => 'Medium',
    'P3' => 'Low',
  ),
  'user_status_dom' => 
  array (
    'Active' => 'Aktiv',
    'Inactive' => 'Inaktiv',
  ),
  'record_type_default_key' => 'Accounts',
  'record_type_display' => 
//       it is the key for the default record_type_module value
  array (
    'Accounts' => 'Virksomhet',
    'Opportunities' => 'Mulighet',
    'Cases' => 'Sak',
    'Leads' => 'Lead',
  ),
  'notifymail_sendtype' => 
  array (
    'sendmail' => 'sendmail',
    'SMTP' => 'SMTP',
  ),
);

$app_strings = array (
  'LBL_CHARSET' => 'UTF-8',
  'LBL_BROWSER_TITLE' => 'SugarCRM - Kommersiell Open Source CRM',
  'LBL_MY_ACCOUNT' => 'Min Konto',
  'LBL_ADMIN' => 'Admin',
  'LBL_LOGOUT' => 'Logg ut',
  'LBL_SEARCH' => ' S&oslash;k',
  'LBL_LAST_VIEWED' => 'Siste info',
  'NTC_WELCOME' => 'Velkommen',
  'NTC_SUPPORT_SUGARCRM' => 'St&oslash;tt SugarCRM open source prosjektet med en donation via PayPal - det er hurtig, gratis og sikkert!',
  'NTC_NO_ITEMS_DISPLAY' => 'ingenting',
  'LBL_ALT_HOT_KEY' => 'Alt+',
  'LBL_SAVE_BUTTON_TITLE' => 'Lagre [Alt+S]',
  'LBL_EDIT_BUTTON_TITLE' => 'Rediger [Alt+E]',
  'LBL_EDIT_BUTTON' => 'Rediger',
  'LBL_DUPLICATE_BUTTON_TITLE' => 'Kopier [Alt+U]',
  'LBL_DUPLICATE_BUTTON' => 'Kopier',
  'LBL_DELETE_BUTTON_TITLE' => 'Slett [Alt+D]',
  'LBL_DELETE_BUTTON' => 'Slett',
  'LBL_NEW_BUTTON_TITLE' => 'Ny [Alt+N]',
  'LBL_CHANGE_BUTTON_TITLE' => 'Endre [Alt+G]',
  'LBL_CANCEL_BUTTON_TITLE' => 'Avbryt [Alt+X]',
  'LBL_SEARCH_BUTTON_TITLE' => 'S&oslash;k [Alt+Q]',
  'LBL_CLEAR_BUTTON_TITLE' => 'Slett [Alt+C]',
  'LBL_SELECT_BUTTON_TITLE' => 'Velg [Alt+T]',
  'LBL_SAVE_BUTTON_KEY' => 'S',
  'LBL_EDIT_BUTTON_KEY' => 'E',
  'LBL_DUPLICATE_BUTTON_KEY' => 'U',
  'LBL_DELETE_BUTTON_KEY' => 'D',
  'LBL_NEW_BUTTON_KEY' => 'N',
  'LBL_CHANGE_BUTTON_KEY' => 'G',
  'LBL_CANCEL_BUTTON_KEY' => 'X',
  'LBL_SEARCH_BUTTON_KEY' => 'Q',
  'LBL_CLEAR_BUTTON_KEY' => 'C',
  'LBL_SELECT_BUTTON_KEY' => 'T',
  'LBL_SAVE_BUTTON_LABEL' => 'Lagre',
  'LBL_EDIT_BUTTON_LABEL' => 'Rediger',
  'LBL_DUPLICATE_BUTTON_LABEL' => 'Kopier',
  'LBL_DELETE_BUTTON_LABEL' => 'Slett',
  'LBL_NEW_BUTTON_LABEL' => 'Ny',
  'LBL_CHANGE_BUTTON_LABEL' => 'Endre',
  'LBL_CANCEL_BUTTON_LABEL' => 'Avbryt',
  'LBL_SEARCH_BUTTON_LABEL' => ' S&oslash;k',
  'LBL_CLEAR_BUTTON_LABEL' => 'Slett',
  'LBL_NEXT_BUTTON_LABEL' => 'Next',
  'LBL_SELECT_BUTTON_LABEL' => 'Velg',
  'LBL_SELECT_CONTACT_BUTTON_TITLE' => 'Velg kontakt [Alt+T]',
  'LBL_SELECT_CONTACT_BUTTON_KEY' => 'T',
  'LBL_VIEW_PDF_BUTTON_LABEL' => 'View PDF',
  'LBL_VIEW_PDF_CONTACT_BUTTON_TITLE' => 'View PDF [Alt+P]',
  'LBL_VIEW_PDF_CONTACT_BUTTON_KEY' => 'P',
  'LBL_SELECT_CONTACT_BUTTON_LABEL' => 'Velg kontakt',
  'LBL_SELECT_USER_BUTTON_TITLE' => 'Velg bruker [Alt+U]',
  'LBL_SELECT_USER_BUTTON_KEY' => 'U',
  'LBL_SELECT_USER_BUTTON_LABEL' => 'Velg bruker',
  'LBL_CREATE_BUTTON_LABEL' => 'Create',
  'LBL_SHORTCUTS' => 'Shortcuts',
  'LBL_LIST_NAME' => 'Navn',
  'LBL_LIST_USER_NAME' => 'Bruker Navn',
  'LBL_LIST_EMAIL' => 'epost',
  'LBL_LIST_PHONE' => 'Tlf',
  'LBL_LIST_CONTACT_NAME' => 'Kontakt Navn',
  'LBL_LIST_CONTACT_ROLE' => 'Contact Role',
  'LBL_LIST_ACCOUNT_NAME' => 'Virksomhet Navn',
  'LBL_USER_LIST' => 'Bruker liste',
  'LBL_CONTACT_LIST' => 'Kontakt liste',
  'LBL_RELATED_RECORDS' => 'Related Records',
  'LBL_MASS_UPDATE' => 'Mass Update',
  'LNK_ADVANCED_SEARCH' => 'Avansert',
  'LNK_BASIC_SEARCH' => 'Enkel',
  'LNK_EDIT' => 'rediger',
  'LNK_REMOVE' => 'fjern',
  'LNK_DELETE' => 'Slett',
  'LNK_LIST_START' => 'Start',
  'LNK_LIST_NEXT' => 'Neste',
  'LNK_LIST_PREVIOUS' => 'Forrige',
  'LNK_LIST_END' => 'Stopp',
  'LBL_LIST_OF' => 'av',
  'LBL_OR' => 'OR',
  'LNK_PRINT' => 'Skriv ut',
  'LNK_HELP' => 'Hjelp',
  'LNK_ABOUT' => 'Om oss',
  'NTC_REQUIRED' => 'Markerer obligatoriske felt',
  'LBL_REQUIRED_SYMBOL' => '*',
  'LBL_CURRENCY_SYMBOL' => 'Kr.',
  'LBL_PERCENTAGE_SYMBOL' => '%',
  'LBL_THOUSANDS_SYMBOL' => 'K',
  'NTC_DATE_FORMAT' => '(&aring;&aring;&aring;&aring;-mm-dd)',
  'NTC_TIME_FORMAT' => '(24:00)',
  'NTC_DATE_TIME_FORMAT' => '(&aring;&aring;&aring;&aring;-mm-dd 24:00)',
  'NTC_DELETE_CONFIRMATION' => 'Er du sikker p&aring; at du vil slette denne oppf&oslash;ringen?',
  'ERR_DELETE_RECORD' => 'Et oppf&oslash;rings nr kreves for &aring; slette den aktuelle kontakten.',
  'ERR_CREATING_TABLE' => 'Feil ved opprettelse av tabellen: ',
  'ERR_CREATING_FIELDS' => 'Feil ved utfylling av ekstra detaljert informasjon: ',
  'ERR_MISSING_REQUIRED_FIELDS' => 'Obligatorisk felt mangler:',
  'ERR_INVALID_EMAIL_ADDRESS' => 'er ikke en gyldig epostadresse.',
  'ERR_INVALID_DATE_FORMAT' => 'Datoformatet skal v&aelig;re : &aring;&aring;&aring;&aring;-mm-dd',
  'ERR_INVALID_MONTH' => 'Angi gyldig m&aring;ned.',
  'ERR_INVALID_DAY' => 'Angi gyldig dato.',
  'ERR_INVALID_YEAR' => 'Angi gyldig &aring;rstall med 4 cifre.',
  'ERR_INVALID_DATE' => 'Angi gyldig dato.',
  'ERR_INVALID_HOUR' => 'Angi gyldig time.',
  'ERR_INVALID_TIME' => 'Angi gyldig klokkeslett.',
  'ERR_INVALID_AMOUNT' => 'Please enter a valid amount.',
  'NTC_CLICK_BACK' => 'Klikk p&aring; tilbake knappen og korriger opplysningene.',
  'LBL_LIST_ASSIGNED_USER' => 'Tildelt',
  'LBL_ASSIGNED_TO' => 'Tildelt:',
  'LBL_DATE_MODIFIED' => 'Sist endret:',
  'LBL_DATE_ENTERED' => 'Opprettet:',
  'LBL_CURRENT_USER_FILTER' => 'Vis kun de opplysningene som er tildelt meg:',
  'NTC_LOGIN_MESSAGE' => 'Vennligst logg inn.',
  'LBL_NONE' => '--Null--',
  'LBL_BACK' => 'Tilbake',
  'LBL_IMPORT' => 'Importer',
  'LBL_EXPORT' => 'Eksporter',
  'LBL_EXPORT_ALL' => 'Export All',
  'LBL_SAVE_NEW_BUTTON_TITLE' => 'Save & Create New [Alt+V]',
  'LBL_SAVE_NEW_BUTTON_KEY' => 'V',
  'LBL_SAVE_NEW_BUTTON_LABEL' => 'Save & Create New',
  'LBL_NAME' => 'Name',
  'LBL_SUBJECT' => 'Subject',
);


?>