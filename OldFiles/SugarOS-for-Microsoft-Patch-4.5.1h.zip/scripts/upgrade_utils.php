<?php
global $sugar_version;
if(substr($sugar_version,0,5) == "4.0.1")
{
    if(empty($GLOBALS['sugarEntry']))
        $GLOBALS['sugarEntry'] = true;
}
else if(!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');

}
/**
 * This script executes after the files are copied during the install.
 *
 * LICENSE: The contents of this file are subject to the SugarCRM Professional
 * End User License Agreement("License") which can be viewed at
 * http://www.sugarcrm.com/EULA.  By installing or using this file, You have
 * unconditionally agreed to the terms and conditions of the License, and You
 * may not use this file except in compliance with the License.  Under the
 * terms of the license, You shall not, among other things: 1) sublicense,
 * resell, rent, lease, redistribute, assign or otherwise transfer Your
 * rights to the Software, and 2) use the Software for timesharing or service
 * bureau purposes such as hosting the Software for commercial gain and/or for
 * the benefit of a third party.  Use of the Software may be subject to
 * applicable fees and any use of the Software without first paying applicable
 * fees is strictly prohibited.  You do not have the right to remove SugarCRM
 * copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright(C) 2005 SugarCRM, Inc.; All Rights Reserved.
 * 

 */
 
require_once('include/database/PearDatabase.php');
require_once('include/database/DBManager.php');
///////////////////////////////////////////////////////////////////////////////
////	UPGRADE UTILS
/**
 * upgrade wizard logging
 */
function _logThis($entry) {
	if(function_exists('logThis')) {
		logThis($entry);
	} else {
	
		$log = clean_path(getcwd().'/upgradeWizard.log');
		// create if not exists
		if(!file_exists($log)) {
			$fp = fopen($log, 'w+'); // attempts to create file
			if(!is_resource($fp)) {
				$GLOBALS['log']->fatal('UpgradeWizard could not create the upgradeWizard.log file');
			}
		} else {
			$fp = fopen($log, 'a+'); // write pointer at end of file
			if(!is_resource($fp)) {
				$GLOBALS['log']->fatal('UpgradeWizard could not open/lock upgradeWizard.log file');
			}
		}
		
		$line = date('r').' [UpgradeWizard] - '.$entry."\n";
		
		if(fwrite($fp, $line) === false) {
			$GLOBALS['log']->fatal('UpgradeWizard could not write to upgradeWizard.log: '.$entry);
		}
		
		fclose($fp);
	}
}

/**
 * gets Upgrade version
 */
function getUpgradeVersion() {
	$version = '';
	
	if(isset($_SESSION['sugar_version_file']) && !empty($_SESSION['sugar_version_file']) && is_file($_SESSION['sugar_version_file'])) {
		// do an include because the variables will load locally, and it will only popuplate in here.
		include($_SESSION['sugar_version_file']);
		return $sugar_db_version;
	}
	
	return $version;
}

/**
 * update DB version and sugar_version.php
 */

function upgradeDbAndFileVersion($version) {
	if(!function_exists('updateVersions')) {
		require_once('modules/UpgradeWizard/uw_utils.php');
	}
	updateVersions($version);
}
////	END UPGRADE UTILS
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
////	SCHEMA CHANGE PRIVATE METHODS
function _run_sql_file($filename) {
	global $path;
	
    if(!is_file($filename)) {
    	_logThis("*** ERROR: Could not find file: {$filename}", $path);
        return(false);
    }

    $fh         = fopen($filename,'r');
    $contents   = fread($fh, filesize($filename));
    fclose($fh);

    $lastsemi   = strrpos($contents, ';') ;
    $contents   = substr($contents, 0, $lastsemi);
    $queries    = split(';', $contents);
    $db         = & PearDatabase::getInstance();

	foreach($queries as $query){
		if(!empty($query)){
			_logThis("Sending query: ".$query, $path);
			if($db->dbType == 'oci8') {



			} else {
				$query_result = $db->query($query.';', true, "An error has occured while performing db query.  See log file for details.<br>");
			}
		}
	}

	return(true);
}



























////	END SCHEMA CHANGE METHODS
///////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////
////	FIX THINGS IN UPGRADE FUNCTIONS
// BEGIN SUGARCRM ONLY
/**
 * creates global & private teams and adds users to them (meant for flavor
 * conversion upgrades
 */
function doTeams() {
	global $db;
	global $beanFiles;
	global $current_user;
	
	if(!class_exists('User')) {
		require_once('modules/Users/User.php');
	}
	if(!class_exists('Team')) {
		require_once('modules/Teams/Team.php');
	}
	if(!function_exists('get_user_array')) {
		require_once('include/utils.php');
	}
	
	// create Global team
	$global = new Team();
	$global->new_with_id = true;
	$global->id = '1';
	$global->name = 'Global';
	$global->description = 'Globally Visible';
	$global->created_by = '1';
	$global->modified_user_id = '1';
	$global->private = 0;
	$global->save();
	
	// get all users and add to global, then create new private teams for each
	$users = get_user_array();
	foreach($users as $id => $user) {
		if(empty($user))
			continue;
		// add to global
		$global->add_user_to_team($id);
		$q = "UPDATE team_memberships SET explicit_assign = 1 WHERE team_id='1' AND user_id='{$id}'";
		$db->query($q);
		
		// set default team to Global as well
		$q2 = "UPDATE users SET default_team = '1' WHERE id ='{$id}'";
		$db->query($q2);
		
		// create private team
		$privTeam = new Team();
		$privTeam->name = "({$user})";
		$privTeam->description = "Private Team for {$user}";
		$privTeam->private = 1;
		$privTeam->created_by = '1';
		$privTeam->modified_user_id = '1';
		$privTeam->save();
		$privTeam->add_user_to_team($id);
	}
	
	$current_user->default_team = '1';
	
	// modules - set team_id = 1
	if(empty($beanFiles)) {
		include('include/modules.php'); // provides beanfiles
	}
	foreach($beanFiles as $class => $classFile) {
		if(!class_exists($class)) {
			require_once($classFile);
		}
		$classVars = get_class_vars($class);
		
		if(array_key_exists('team_id', $classVars)) {
			$bean = new $class();
			$q = "UPDATE {$bean->table_name} SET team_id = '1'";
			$db->query($q);
		}
	}
}

function updateUserPasswordColumn() {
	global $db;
	global $path;
	
	_logThis('called updateUserPasswordColumn() - dropping unused user_password column', $path);

	$qIndex = '';
	$qColumn = '';
	
	if($db->dbType == 'mysql') {	
		$db->dbManager = &DBManagerFactory::getInstance();

		$idx = array();
		$allIndices = $db->dbManager->helper->get_indices('user_password');

		foreach($allIndices as $index) {
			$idx[] = strtolower($index);
		}

		if (in_array('user_password_idx', $idx)) {
			_logThis('Dropping INDEX USER_PASSWORD_IDX', $path);
			$qIndex = 'ALTER TABLE users DROP INDEX user_password_idx';
		}
		
		$qColumn = 'ALTER TABLE users DROP user_password';
	}
	














	
	// if the Index/Column queries are set, then run the queries
	if ($qIndex != '') {
		$db->query($qIndex);
		$db->query($qColumn);
	}	
}

/**
 * defines getFiles function for 421 upgrades for rebuilding dashlets
 */
if (substr($sugar_version,0,5) == "4.2.1" && !function_exists('getFiles')){
	function getFiles(&$arr, $dir, $pattern = null) { 
	    $contents = glob("{$dir}/*"); 
	    if(is_array($contents)) {
	        foreach($contents as $file) { 
	            if(is_dir($file)) {
	                getFiles($arr, $file, $pattern);
	            }
	            else {
	                if(empty($pattern)) $arr[] = $file;
	                else if(preg_match($pattern, $file)) 
	                $arr[] = $file;
	            }
	        }
	    }
	}
}

// END SUGARCRM ONLY
////	END FIX THINGS IN UPGRADE FUNCTIONS
///////////////////////////////////////////////////////////////////////////////
?>
