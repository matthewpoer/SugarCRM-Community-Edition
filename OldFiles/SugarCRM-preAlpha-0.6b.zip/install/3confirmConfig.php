<?php
/*********************************************************************************
 * The contents of this file are subject to the Mozilla Public License Version 1.1
 * ("License"); You may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at http://www.mozilla.org/MPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/install/3confirmConfig.php,v 1.1 2004/05/27 05:30:49 sugarjacob Exp $
 * Description:  Executes a step in the installation process.
 ********************************************************************************/

$db_host_name 	= $_REQUEST['db_host_name'];
$db_user_name 	= $_REQUEST['db_user_name'];
$db_password 	= $_REQUEST['db_password'];
$db_name  		= $_REQUEST['db_name'];
$db_drop_tables = $_REQUEST['db_drop_tables'];
$site_URL 		= $_REQUEST['site_URL'];
$admin_email 	= $_REQUEST['admin_email'];
$admin_password = $_REQUEST['admin_password'];
if (get_magic_quotes_gpc()) { $root_directory = stripslashes($_REQUEST['root_directory']); }
else { $root_directory = $_REQUEST['root_directory']; }

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>SugarCRM Open Source Installer: Step 3</title>
<link rel="stylesheet" href="install/install.css" type="text/css" />
</head>
<body leftMargin="0" topMargin="0" marginheight="0" marginwidth="0">
<table width="100%" border="0" cellpadding="5" cellspacing="0" class="formHeader"><tbody>
  <tr><td align="center"><IMG alt="SugarCRM" src="include/images/SUGAR.jpg"/></td></tr>
</tbody></table>
<P></P>
<table align="center" border="0" cellpadding="2" cellspacing="2" border="1" width="60%"><tbody><tr> 
   <tr>
      <td width="100%">
		<table width=100% cellpadding="0" cellspacing="0" border="0"><tbody><tr>
			  <td>
			   <table cellpadding="0" cellspacing="0" border="0"><tbody><tr>
				<td class="formHeader" vAlign="top" align="left" height="20"> 
				 <IMG height="5" src="include/images/left_arc.gif" width="5" border="0"></td>
				<td class="formHeader" vAlign="middle" align="left" noWrap width="100%" height="20">Step 3: Confirm System Configuration</td>
				<td  class="formHeader" vAlign="top" align="right" height="20">
				  <IMG height="5" src="include/images/right_arc.gif" width="5" border="0"></td>
				</tr></tbody></table>
			  </td>
			  <td width="100%" align="right">&nbsp;</td>
			  </tr><tr>
			  <td colspan="2" width="100%" class="formHeader"><IMG width="100%" height="2" src="include/images/blank.gif"></td>
			  </tr>
		</tbody></table>
	  </td>
          </tr>
          <tr>
            <td>
          <P>Please review the configuration information below... <P>
		    </td>
          </tr>
          <tr>
		    <td align="center">
			<table width="50%" cellpadding="2" border="0"><tbody>
              <tr>
  			   <td colspan="2" class="moduleTitle" noWrap>Database Configuration</td>
              </tr>
			  <tr>
               <td><strong>Host Name</strong></td>
               <td align="left" nowrap>: <font class="dataInput"><?php echo "$db_host_name"; ?></font></td>
              </tr>
              <tr>
               <td><strong>MySQL User Name</strong></td>
               <td align="left" nowrap>: <font class="dataInput"><?php echo "$db_user_name"; ?></font></td>
              </tr>
              <tr>
               <td noWrap><strong>MySQL Password</strong></td>
               <td align="left" nowrap>: <font class="dataInput"><?php echo "$db_password"; ?></font></td>
              </tr>
              <tr>
               <td noWrap><strong>MySQL Database Name</strong></td>
               <td align="left" nowrap>: <font class="dataInput"><?php echo "$db_name"; ?></font></td>
              </tr>
              <tr>
               <td noWrap><strong>Drop Existing Tables</strong></td>
               <td align="left" nowrap>: <font class="dataInput">
			   <?php if ($db_drop_tables == true) echo "True"; else echo "False"; ?>
				</font></td>
			  </tr>               
			<tr><td>&nbsp;</td></tr>
			  <tr>
  			   <td colspan="2" class="moduleTitle" noWrap>Site Configuration</td>
              </tr>
              <tr>
               <td noWrap><strong>URL</strong></td>
               <td align="left" nowrap>: <font class="dataInput"><?php echo "$site_URL"; ?></font></td>
              </tr>
              <tr>
               <td noWrap><strong>Path</strong></td>
               <td align="left" nowrap>: <font class="dataInput"><?php echo "$root_directory"; ?></font></td>
              </tr>
              <tr>
               <td noWrap><strong>Admin Email Address</strong></td>
               <td align="left" nowrap>: <font class="dataInput"><?php echo "$admin_email"; ?></font></td>
              </tr>
              <tr>
               <td noWrap><strong>Admin Password</strong></td>
               <td align="left" nowrap>: <font class="dataInput"><?php echo "$admin_password"; ?></font></td>
              </tr>

    	      </tbody>
			</table>
		  </td></tr>
          <tr><td align="center">
			<form action="install.php" method="post" name="form" id="form">
			 <input type="hidden" name="file" value="2setConfig.php">
             <input type="hidden" class="dataInput" name="db_host_name" value="<?php echo "$db_host_name"; ?>" />
             <input type="hidden" class="dataInput" name="db_user_name" value="<?php echo "$db_user_name"; ?>" />
             <input type="hidden" class="dataInput" name="db_password" value="<?php echo "$db_password"; ?>" />
             <input type="hidden" class="dataInput" name="db_name" value="<?php echo "$db_name"; ?>" />
             <input type="hidden" class="dataInput" name="db_drop_tables" value="<?php echo "$db_drop_tables"; ?>" />
             <input type="hidden" class="dataInput" name="site_URL" value="<?php echo "$site_URL"; ?>" />
             <input type="hidden" class="dataInput" name="root_directory" value="<?php echo "$root_directory"; ?>" />
             <input type="hidden" class="dataInput" name="admin_email" value="<?php echo "$admin_email"; ?>" />
             <input type="hidden" class="dataInput" name="admin_password" value="<?php echo "$admin_password"; ?>" />
			 <input class="button" type="submit" name="next" value="Change" /></td>
			</form>
		 </td></tr>
		 <tr><td>&nbsp;</td></tr>
		 <tr><td align="center">
			<form action="install.php" method="post" name="form" id="form">
			<input type="hidden" name="file" value="4createConfigFile.php">
<!-- TODO Clint 4/28 - Add support for creating the database as well -->
<!--			 Also create database <font class="dataInput"><?php echo "$db_name"; ?></font>? -->
<!--			 <input type="checkbox" class="dataInput" name="db_create" value="1" /> -->
			 Also populate demo data? 
			 <input type="checkbox" class="dataInput" name="db_populate" value="1"> 
			</td>
		 </tr>
		 <tr>
			<td align="right">
			 <input type="hidden" class="dataInput" name="db_host_name" value="<?php echo "$db_host_name"; ?>" />
             <input type="hidden" class="dataInput" name="db_user_name" value="<?php echo "$db_user_name"; ?>" />
             <input type="hidden" class="dataInput" name="db_password" value="<?php echo "$db_password"; ?>" />
             <input type="hidden" class="dataInput" name="db_name" value="<?php echo "$db_name"; ?>" />
             <input type="hidden" class="dataInput" name="db_drop_tables" value="<?php echo "$db_drop_tables"; ?>" />
             <input type="hidden" class="dataInput" name="site_URL" value="<?php echo "$site_URL"; ?>" />
             <input type="hidden" class="dataInput" name="root_directory" value="<?php echo "$root_directory"; ?>" />
             <input type="hidden" class="dataInput" name="admin_email" value="<?php echo "$admin_email"; ?>" />
             <input type="hidden" class="dataInput" name="admin_password" value="<?php echo "$admin_password"; ?>" />
			 <input class="button" type="submit" name="next" value="Create" />
			</td>
          </tr>
	</tbody></table>
</form>		
</body>
</html>