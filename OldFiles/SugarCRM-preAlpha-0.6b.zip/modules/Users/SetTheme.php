<?php
/*********************************************************************************
 * The contents of this file are subject to the Mozilla Public License Version 1.1
 * ("License"); You may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at http://www.mozilla.org/MPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Users/SetTheme.php,v 1.1 2004/05/27 05:30:55 sugarjacob Exp $
 * Description: Sets the theme for the current user.
 ********************************************************************************/

global $current_user;
global $theme;
require_once('logging.php');
require_once('modules/Users/User.php');

$log =& LoggerManager::getLogger('SetTheme');

function get_dirs($directory, $select_name, $selected = "") {
	global $log;
   if ($dir = @opendir($directory)) {
		while (($file = readdir($dir)) !== false) {
           if ($file != ".." && $file != "." && $file != "CVS" && $file != "Attic") {
			   if(is_dir($directory."/".$file)) {
				   if(!($file[0] == '.')) {
					   $filelist[] = $file;
				   }
			   }
		   }
	   }
	   closedir($dir);
   }
   echo "<select name=\"$select_name\">";
   if (is_array($filelist)) {
	   asort($filelist);
	   while (list ($key, $val) = each ($filelist)) {
		   echo "<option value=\"$val\"";
		   if ($selected == $val) {
			   echo " selected";
		   }
		   echo ">$val</option>";
	   }
   }
   echo "</select>";
}

$user = new User();

$log->debug("current theme is $theme");	
if (!is_dir ("./themes")) $log->debug("cannot access ./themes directory");	
else $log->debug("can access ./themes directory");

?>
<form action="index.php" method="post" name="form" id="form">
<input type="hidden" name="module" value="Users">
<input type="hidden" name="action" value="SaveCurrentUser">
<input type="hidden" name="id" value="<?php echo $current_user->id ?>">
<input type="hidden" name="user_name" value="<?php echo $current_user->user_name ?>">
Select your template:  
<?php echo get_dirs("./themes", "theme", $theme); ?>
</td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td align="center">
<input class="button" type="submit" name="submit" value="Save">

