<?php 
/*********************************************************************************
 * The contents of this file are subject to the Mozilla Public License Version 1.1
 * ("License"); You may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at http://www.mozilla.org/MPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Users/User.php,v 1.1 2004/05/27 05:30:55 sugarjacob Exp $
 * Description: TODO:  To be written.
 ********************************************************************************/

require_once('logging.php');
require_once('database/DatabaseConnection.php');
require_once('data/SugarBean.php');

// User is used to store customer information.
class User extends SugarBean {
	var $log;

	// Stored fields
	var $id;
	var $user_name;
	var $user_password;
	var $first_name;
	var $last_name;
	var $date_entered;
	var $notes;
	var $phone_home;
	var $phone_mobile;
	var $phone_work;
	var $email;
	var $address_street1;
	var $address_street2;
	var $address_city;
	var $address_state;
	var $address_zipcode;
	var $theme;
	var $title;
	var $department;

	var $table_name = "users";

	var $object_name = "User";

	var $column_fields = Array("id"
		,"user_name"
		,"user_password"
		,"first_name"
		,"last_name"
		,"notes"
		,"date_entered"
		,"title"
		,"department"
		,"phone_home"
		,"phone_mobile"
		,"phone_work"
		,"email"
		,"address_street1"
		,"address_street2"
		,"address_city"
		,"address_state"
		,"address_zipcode"
		,"theme"
		);

	var $encodeFields = Array("first_name", "last_name", "notes");

	var $default_order_by = "user_name";

	function User() {
		$this->log = LoggerManager::getLogger('user');
	}

	function create_tables () {
		$query = 'CREATE TABLE '.$this->table_name.' ( ';
		$query = $query.'id int( 11 ) NOT NULL auto_increment';
		$query = $query.', user_name text';
		$query = $query.', user_password text';
		$query = $query.', first_name text';
		$query = $query.', last_name text';
		$query = $query.', notes text';
		$query = $query.', date_entered timestamp( 14 ) NOT NULL';
		$query = $query.', title text';
		$query = $query.', department text';
		$query = $query.', phone_home text';
		$query = $query.', phone_mobile text';
		$query = $query.', phone_work text';
		$query = $query.', email text';
		$query = $query.', address_street1 text';
		$query = $query.', address_street2 text';
		$query = $query.', address_city text';
		$query = $query.', address_state text';
		$query = $query.', address_zipcode int(9)';
		$query = $query.', theme text';
		$query = $query.', PRIMARY KEY ( ID ) )';
	
		$this->log->info($query);
		
		mysql_query($query);

	//TODO Clint 4/27 - add exception handling logic here if the table can't be created.
	
	}

	function drop_tables () {
		$query = 'DROP TABLE IF EXISTS '.$this->table_name;

		$this->log->info($query);
			
		mysql_query($query);

	//TODO Clint 4/27 - add exception handling logic here if the table can't be dropped.

	}

	
}



?>
