<?
/*********************************************************************************
 * The contents of this file are subject to the Mozilla Public License Version 1.1
 * ("License"); You may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at http://www.mozilla.org/MPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Accounts/Account.php,v 1.1 2004/05/27 05:30:53 sugarjacob Exp $
 * Description:  Defines the Account SugarBean Account entity with the necessary
 * methods and variables.
 ********************************************************************************/

include_once('config.php');
require_once('logging.php');
require_once('database/DatabaseConnection.php');
require_once('data/SugarBean.php');
require_once('modules/Contacts/Contact.php');
require_once('modules/Opportunities/Opportunity.php');

// Account is used to store account information.
class Account extends SugarBean {
	var $log;

	// Stored fields
	var $annual_revenue;
	var $billing_address_street;
	var $billing_address_city;
	var $billing_address_state;
	var $billing_address_postalcode;
	var $date_entered; 
	var $description;
	var $email1;
	var $email2;
	var $employees;
	var $id;
	var $industry;
	var $name;
	var $ownership;
	var $parent_id;
	var $phone_alternate;
	var $phone_fax;
	var $phone_office;
	var $rating;
	var $shipping_address_street;
	var $shipping_address_city;
	var $shipping_address_state;
	var $shipping_address_country;
	var $shipping_address_postalcode;
	var $sic_code;
	var $ticker_symbol;
	var $account_type;
	var $website;

	var $table_name = "accounts";

	var $object_name = "Account";

	var $column_fields = Array(
		"annual_revenue", 
		"billing_address_street", 
		"billing_address_city", 
		"billing_address_state", 
		"billing_address_postalcode", 
		"billing_address_country", 
		"date_entered",  
		"description", 
		"email1", 
		"email2", 
		"employees", 
		"id",
		"industry", 
		"name", 
		"ownership", 
		"parent_id", 
		"phone_alternate", 
		"phone_fax", 
		"phone_office", 
		"rating", 
		"shipping_address_street", 
		"shipping_address_city", 
		"shipping_address_state",
		"shipping_address_postalcode",
		"shipping_address_country", 
		"sic_code", 
		"ticker_symbol", 
		"account_type", 
		"website");

	// This is used to retrieve related fields from form posts.
	var $additional_column_fields = Array();		
	
	// This is the list of fields that are in the lists.
	var $list_fields = Array('id', 'name', 'website', 'phone_office');	

	function Account() {
		$this->log = LoggerManager::getLogger('account');	
	}
	
	function create_tables () {
		$query = 'CREATE TABLE '.$this->table_name.' ( ';
		$query .='id int( 11 ) NOT NULL auto_increment';
		$query .=', date_entered timestamp( 14 ) NOT NULL'; 
		$query .=', name char(150)';
		$query .=', parent_id int';
		$query .=', account_type char(25)';
		$query .=', industry char(25)';
		$query .=', annual_revenue char(25)';
		$query .=', phone_fax char(25)';
		$query .=', billing_address_street char(150)';
		$query .=', billing_address_city char(100)';
		$query .=', billing_address_state char(100)';
		$query .=', billing_address_postalcode char(20)';
		$query .=', billing_address_country char(100)';
		$query .=', description text';
		$query .=', rating char(25)';
		$query .=', phone_office char(25)';
		$query .=', phone_alternate char(25)';
		$query .=', email1 char(100)';
		$query .=', email2 char(100)';
		$query .=', website char(255)';
		$query .=', ownership char(100)';
		$query .=', employees char(10)';
		$query .=', sic_code char(10)';
		$query .=', ticker_symbol char(10)';
		$query .=', shipping_address_street char(150)';
		$query .=', shipping_address_city char(100)';
		$query .=', shipping_address_state char(100)';
		$query .=', shipping_address_postalcode char(20)';
		$query .=', shipping_address_country char(100)';
		$query .=', deleted bool NOT NULL default 0';
		$query .=', PRIMARY KEY ( id ) )';
		
		$this->log->info($query);
		
		mysql_query($query);
	//TODO Clint 4/27 - add exception handling logic here if the table can't be created.

	}

	function drop_tables () {
		$query = 'DROP TABLE IF EXISTS '.$this->table_name;

		$this->log->info($query);
			
		mysql_query($query);

	//TODO Clint 4/27 - add exception handling logic here if the table can't be dropped.

	}

	function get_summary_text()
	{
		return $this->name;
	}	

	/** Returns a list of the associated contacts
	*/
	function get_contacts()
	{
		// First, get the list of IDs.
		$query = "SELECT contact_id as id from accounts_contacts where account_id='$this->id' AND deleted=0";

		return $this->build_related_list($query, new Contact());
	}

	/** Returns a list of the associated opportunities
	*/
	function get_opportunities()
	{
		// First, get the list of IDs.
		$query = "SELECT opportunity_id as id from accounts_opportunities where account_id='$this->id' AND deleted=0";
		
		return $this->build_related_list($query, new Opportunity());
	}
	
	function mark_relationships_deleted($id)
	{
		$query = "UPDATE accounts_contacts set deleted=1 where account_id=$id";
		mysql_query($query) or die("Error marking record deleted: ".mysql_error());

		$query = "UPDATE accounts_opportunities set deleted=1 where account_id=$id";
		mysql_query($query) or die("Error marking record deleted: ".mysql_error());
	}

}



?>