<?php
/*********************************************************************************
 * The contents of this file are subject to the Mozilla Public License Version 1.1
 * ("License"); You may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at http://www.mozilla.org/MPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Accounts/Popup.php,v 1.1 2004/05/27 05:30:53 sugarjacob Exp $
 * Description:  This file is used for all popups on this module
 * The popup_picker.html file is used for generating a list from which to find and 
 * choose one instance.
 ********************************************************************************/

global $theme;
require_once('modules/Accounts/Account.php');
require_once('themes/'.$theme.'/layout_utils.php');
require_once('logging.php');
require_once('XTemplate/xtpl.php');

global $list_max_entries_per_page;
global $urlPrefix;
global $currentModule;

$log = LoggerManager::getLogger('account');

$seedAccount = new Account();

$where = "";
if(isset($_REQUEST['query']))
{
	// we have a query
	$name = $_REQUEST['name'];
	$website = $_REQUEST['website'];
	$phone_office = $_REQUEST['phone_office'];

	$where_clauses = Array();

	if($name != "")
	{
		array_push($where_clauses, "name like '$name%'");
	}
	if($phone_office != "")
	{
		array_push($where_clauses, "phone_office like '$phone_office%'");
	}

	$where = "";
	foreach($where_clauses as $clause)
	{
		if($where != "")
		$where .= " and ";
		$where .= $clause;
	}

	$log->info("Here is the where clause for the list view: $where");

}

$current_offset = 0;
if(isset($_REQUEST['current_offset']))
    $current_offset = $_REQUEST['current_offset'];

$response = $seedAccount->get_list("name", $where, $current_offset);

$account_list = $response['list'];
$row_count = $response['row_count'];
$next_offset = $response['next_offset'];
$previous_offset = $response['previous_offset'];

$start_record = $current_offset + 1;

// Set the start row to 0 if there are no rows (adding one looks bad)
if($row_count == 0)
    $start_record = 0;

$end_record = $start_record + $list_max_entries_per_page;

// back up the the last page.
if($end_record > $row_count)
{
    $end_record = $row_count;
}

// Deterime the start location of the last page
$number_pages = floor(($row_count - 1)  / $list_max_entries_per_page);
$last_page_offset = $number_pages * $list_max_entries_per_page;
$contactList = $response['list'];
$row_count = $response['row_count'];
$next_offset = $response['next_offset'];
$previous_offset = $response['previous_offset'];

$start_record = $current_offset + 1;

// Set the start row to 0 if there are no rows (adding one looks bad)
if($row_count == 0)
    $start_record = 0;

$end_record = $start_record + $list_max_entries_per_page;

// back up the the last page.
if($end_record > $row_count)
{
    $end_record = $row_count;
}

// Deterime the start location of the last page
if($row_count == 0)
	$number_pages = 0;
else
	$number_pages = floor(($row_count - 1) / $list_max_entries_per_page);

$last_page_offset = $number_pages * $list_max_entries_per_page;


// Create the base URL without the current offset.
// Check to see if the current offset is already there
// If not, add it to the end.

// All of the other values should use a regular expression search
$base_URL = "http://".$_SERVER['HTTP_HOST'].$_SERVER['SCRIPT_NAME'] .'?'.$_SERVER['QUERY_STRING']."&current_offset=";
$start_URL = $base_URL."0";
$previous_URL  = $base_URL.$previous_offset;
$next_URL  = $base_URL.$next_offset;
$end_URL  = $base_URL.$last_page_offset;

$sort_URL_base = $base_URL.$current_offset."&sort_order=";

$log->debug("Offsets: (start, previous, next, last)(0, $previous_offset, $next_offset, $last_page_offset)");

if(0 == $current_offset)
    $start_link = "Start";
else
    $start_link = "<a href=\"$start_URL\" class=\"listFormHeaderLinks\">Start</a>";

if($previous_offset < 0)
    $previous_link = "Previous";
else
    $previous_link = "<a href=\"$previous_URL\" class=\"listFormHeaderLinks\">Previous</a>";

if($next_offset >= $end_record)
    $next_link = "Next";
else
    $next_link = "<a href=\"$next_URL\" class=\"listFormHeaderLinks\">Next</a>";

if($last_page_offset <= $current_offset)
    $end_link = "End";
else
    $end_link = "<a href=\"$end_URL\" class=\"listFormHeaderLinks\">End</a>";

    
    
    
    
    
    
    
$image_path = 'themes/'.$theme.'/images';    
    
////////////////////////////////////////////////////////    
// Start the output    
////////////////////////////////////////////////////////    
$form =new XTemplate ('modules/Accounts/Popup_picker.html');
$form->assign("THEME", $theme);
$form->assign("IMAGE_PATH", $image_path);
$form->assign("MODULE_NAME", $currentModule);
  
insert_popup_header($theme);
// Quick search.
?>

<form>

<?php 

echo get_form_header("Account Search", "", false); 

$form->parse("main.SearchHeader");
$form->out("main.SearchHeader");

echo get_form_footer();

$form->parse("main.SearchHeaderEnd");
$form->out("main.SearchHeaderEnd");

// Reset the sections that are already in the page so that they do not print again later.
$form->reset("main.SearchHeader");
$form->reset("main.SearchHeaderEnd");

// start the form before the form header to manage the gap
$button  = "<table cellspacing='0' cellpadding='1' border='0'><form border='0' action='index.php' method='post' name='form' id='form'>\n";
$button .= "<tr><td>&nbsp;</td>";
$button .= "<td><input title='Clear [Alt+C]' accessKey='C' class='button' LANGUAGE=javascript onclick=\"window.opener.document.EditView.account_name.value = '';window.opener.document.EditView.account_id.value = ''; window.close()\" type='submit' name='submit' value='  Clear  '>\n";
$button .= "</td></tr></form></table>\n";

// Stick the form header out there.
echo get_form_header("Account List", $button, false);

$oddRow = true;
foreach($account_list as $account)
{

    if($oddRow)
    {
        //todo move to themes
        $class = '"oddListRow"';
    }
    else
    {
        //todo move to themes
        $class = '"evenListRow"';
    }
    $oddRow = !$oddRow;

    $account_details = Array("ID"=>$account->id,
    	"NAME"=>$account->name,
    	"WEBSITE"=>$account->website);
	$form->assign("ACCOUNT", $account_details);
	$form->assign("CLASS", $class);
    $form->parse("main.row");	
}

$form->assign("START_RECORD", $start_record);
$form->assign("END_RECORD", $end_record);
$form->assign("RECORD_COUNT", $row_count);
$form->assign("START_LINK", $start_link);
$form->assign("PREVIOUS_LINK", $previous_link);
$form->assign("NEXT_LINK", $next_link);
$form->assign("END_LINK", $end_link);


$form->parse("main");
$form->out("main");

?>

	<tr><td COLSPAN=7><?php echo get_form_footer(); ?></td></tr>
</form>
	</table>
</td></tr></tbody></table>
</td></tr>

<?php insert_popup_footer(); ?>