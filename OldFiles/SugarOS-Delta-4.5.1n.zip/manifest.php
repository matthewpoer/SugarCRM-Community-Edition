<?php
// created: 2009-06-04 18:53:20
$manifest = array (
  'acceptable_sugar_flavors' => 
  array (
    0 => 'OS',
  ),
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '4\\.5\\.1[m|n]',
    ),
  ),
  'author' => 'SugarCRM, Inc.',
  'copy_files' => 
  array (
    'from_dir' => 'SugarOS-Delta-4.5.1n',
    'to_dir' => '',
    'force_copy' => 
    array (
    ),
  ),
  'description' => '',
  'icon' => '',
  'is_uninstallable' => false,
  'offline_client_applicable' => true,
  'name' => 'SugarOS',
  'published_date' => '2009-06-04 18:53:20',
  'type' => 'patch',
  'version' => '4.5.1n',
);
?>
