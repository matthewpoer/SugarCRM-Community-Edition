<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
// FILE SUGARCRM INT ONLY
$dictionary['WorkFlowSchedule'] = array('table' => 'workflow_schedules'
                               ,'fields' => array (
  'id' => 
  array (
    'name' => 'id',
    'vname' => 'LBL_NAME',
    'type' => 'id',
    'required' => true,
    'reportable'=>false,
  ),
   'deleted' => 
  array (
    'name' => 'deleted',
    'vname' => 'LBL_DELETED',
    'type' => 'bool',
    'required' => true,
    'default' => '0',
    'reportable'=>false,
  ),
   'date_entered' => 
  array (
    'name' => 'date_entered',
    'vname' => 'LBL_DATE_ENTERED',
    'type' => 'datetime',
    'required' => true,
  ),
  'date_modified' => 
  array (
    'name' => 'date_modified',
    'vname' => 'LBL_DATE_MODIFIED',
    'type' => 'datetime',
    'required' => true,
  ),
    'modified_user_id' => 
  array (
    'name' => 'modified_user_id',
    'rname' => 'user_name',
    'id_name' => 'modified_user_id',
    'vname' => 'LBL_ASSIGNED_TO',
    'type' => 'assigned_user_name',
    'table' => 'users',
    'isnull' => 'false',
    'dbType' => 'id',
    'required' => true,
    'default' => '',
    'reportable'=>true,
  ),
  'created_by' => 
  array (
    'name' => 'created_by',
    'rname' => 'user_name',
    'id_name' => 'modified_user_id',
    'vname' => 'LBL_ASSIGNED_TO',
    'type' => 'assigned_user_name',
    'table' => 'users',
    'isnull' => 'false',
    'dbType' => 'id'
  ),
  'date_expired' => 
  array (
    'name' => 'date_expired',
    'vname' => 'LBL_DATE_EXPIRED',
    'type' => 'datetime',
    'required' => true,
  ),
  'workflow_id' => 
  array (
    'name' => 'workflow_id',
    'type' => 'id',
    'required'=>false,
    'reportable'=>false,
  ),  
    'target_module' => 
  array (
    'name' => 'target_module',
    'vname' => 'LBL_TARGET_MODULE',
    'type' => 'varchar',
    'len' => '50',
    'required' => true,
    'default' => '',
  ),
    'bean_id' => 
  array (
    'name' => 'bean_id',
    'type' => 'id',
    'required'=>false,
    'reportable'=>false,
  ),  
)
                                                      , 'indices' => array (
       array('name' =>'schedule_k', 'type' =>'primary', 'fields'=>array('id')),
       array('name' =>'idx_schedule', 'type'=>'index', 'fields'=>array('workflow_id','deleted')),
                                                      )
                            );
?>
