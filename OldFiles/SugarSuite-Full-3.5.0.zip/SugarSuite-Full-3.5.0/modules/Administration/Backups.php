<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

require_once('upgrade/dir_inc.php');
require_once('include/utils/zip_utils.php');

$form_action = "index.php?module=Administration&action=Backups";

$backup_dir = "";
$backup_zip = "";
$run        = "confirm";
$input_disabled = "";

function processBackupForm(){
    global $backup_dir;
    global $backup_zip;
    global $input_disabled;
    global $run;
    $errors = array();

    // process "run" commands
    if( isset( $_REQUEST['run'] ) && ($_REQUEST['run'] != "") ){
        $run = $_REQUEST['run'];

        $backup_dir = $_REQUEST['backup_dir'];
        $backup_zip = $_REQUEST['backup_zip'];

        if( $run == "confirm" ){
            if( $backup_dir == "" ){
                $errors[] = "Backup directory must be specified.";
            }
            if( $backup_zip == "" ){
                $errors[] = "Backup filename must be specified.";
            }

            if( sizeof($errors) > 0 ){
                return( $errors );
            }

            if( !is_dir( $backup_dir ) ){
                if( !mkdir_recursive( $backup_dir ) ){
                    $errors[] = "Directory $backup_dir does not exist, and could not be created.";
                }
            }

            if( !is_writable( $backup_dir ) ){
                $errors[] = "Directory $backup_dir exists, but is not writable.";
            }

            if( is_file( "$backup_dir/$backup_zip" ) ){
                $errors[] = "The file $backup_zip already exists in directory $backup_dir.";
            }
            if( is_dir( "$backup_dir/$backup_zip" ) ){
                $errors[] = "$backup_zip already exists as a sub-directory of $backup_dir.";
            }

            if( sizeof( $errors ) == 0 ){
                $run = "confirmed";
                $input_disabled = "readonly";
            }
        }
        else if( $run == "confirmed" ){
            ini_set( "memory_limit", "-1" );
            ini_set( "max_execution_time", "0" );
            zip_dir( ".", "$backup_dir/$backup_zip" );
            $run = "done";
        }
    }
    return( $errors );
}

$errors = processBackupForm();

if( sizeof($errors) > 0 ){
    foreach( $errors as $error ){
        print( "<font color=\"red\">$error</font><br>" );
    }
}

if( $run == "done" ){
    $size = filesize( "$backup_dir/$backup_zip" );
    print( "Backup successfully stored as $backup_dir/$backup_zip ($size bytes).<br>\n" );
    print( "<a href=\"index.php?module=Administration&action=index\">Back to Admin Home</a>\n" );
}
else{
?>

    This purpose of this tool is to assist in creating backups of the Sugar application files.  Database backups
    should also be performed regularly.  Please refer to your database vendor's documentation for more information.
    <br>
    To backup your Sugar application files as a zip file, enter the following information:<br>
    <form action="<?php print( $form_action );?>" method="post">
    <table>
    <tr>
        <td>Directory:<br><i>Must be writable by Sugar</i></td>
        <td><input type="input" name="backup_dir" <?php print( $input_disabled );?> value="<?php print( $backup_dir );?>"/></td>
    </tr>
    <tr>
        <td>Filename:</td>
        <td><input type="input" name="backup_zip" <?php print( $input_disabled );?> value="<?php print( $backup_zip );?>"/></td>
    </tr>
    </table>
    <input type=hidden name="run" value="<?php print( $run );?>" />

<?php
    switch( $run ){
        case "confirm":
?>
            <input type="submit" value="Confirm Settings" />
<?php
            break;
        case "confirmed":
?>
            Settings confirmed.  Press backup to perform the backup.<br>
            <input type="submit" value="Run Backup" />
<?php
            break;
    }
?>

    </form>

<?php
}   // end if/else of $run options
$log->info( "Backups" );
?>
