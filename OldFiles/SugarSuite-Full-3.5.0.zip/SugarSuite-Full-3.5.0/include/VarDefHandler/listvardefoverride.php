<?PHP
//THIS IS TO FIX ANY VARDEFS IN CREATING LIST QUERIES (specifically relationships)
if(isset($this->field_defs['assigned_user_name'])){
	$this->field_defs['assigned_user_name'] =  array (
	    'name' => 'assigned_user_name',
	    'rname'=>'user_name',
	    'vname' => 'LBL_ASSIGNED_TO',
	    'type' => 'relate',
	    'reportable'=>false,
	    'source'=>'nondb',
	    'link'=>'assigned_user_link'
	  );
}
if(isset($this->field_defs['created_by'])){
	$this->field_defs['created_by'] =  array (
	    'name' => 'created_by',
	    'rname'=>'user_name',
	    'vname' => 'LBL_CREATED',
	    'type' => 'relate',
	    'reportable'=>false,
	    'source'=>'nondb',
	    'link'=>'created_by_link'
	  );
}
if(isset($this->field_defs['modified_user_id'])){
	$this->field_defs['modified_user_id'] =  array (
	    'name' => 'modified_user_id',
	    'rname'=>'user_name',
	    'vname' => 'LBL_MODIFIED',
	    'type' => 'relate',
	    'reportable'=>false,
	    'source'=>'nondb',
	    'link'=>'modified_user_link'
	  );
}




?>
