<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Opportunities/language/en_us.lang.php,v 1.10 2004/08/03 07:43:19 sugarclint Exp $
 * Description:  Defines the English language pack for the Account module.
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_MODULE_NAME'=>'Affaires',
'LBL_MODULE_TITLE'=>'Affaires: Accueil',
'LBL_SEARCH_FORM_TITLE'=>'Recherche Affaires',
'LBL_LIST_FORM_TITLE'=>'Liste des Affaires',
'LBL_OPPORTUNITY_NAME'=>"Nom de l'Affaire:",
'LBL_OPPORTUNITY'=>'Affaire:',
'LBL_NAME'=>"Nom de l'Affaire",

'LBL_LIST_OPPORTUNITY_NAME'=>'Affaire',
'LBL_LIST_ACCOUNT_NAME'=>'Nom du Compte',
'LBL_LIST_AMOUNT'=>'Montant',
'LBL_LIST_DATE_CLOSED'=>'Date de cl�ture',
'LBL_LIST_SALES_STAGE'=>'Phase de vente',

'LBL_OPPORTUNITY_NAME'=>"Nom de l'Affaire:",
'LBL_ACCOUNT_NAME'=>'Nom du Compte:',
'LBL_AMOUNT'=>'Montant:',
'LBL_DATE_CLOSED'=>'date de cl�ture:',
'LBL_TYPE'=>'Type:',
'LBL_NEXT_STEP'=>'prochaine �tape:',
'LBL_LEAD_SOURCE'=>'Source du Lead:',
'LBL_SALES_STAGE'=>'Phase de vente:',
'LBL_PROBABILITY'=>'Probabilit� (%):',
'LBL_DESCRIPTION'=>'Description:',

'LBL_NEW_FORM_TITLE'=>'Nouveau Compte',
'LNK_NEW_CONTACT'=>'Nouveau Contact',
'LNK_NEW_ACCOUNT'=>'Nouveau Compte',
'LNK_NEW_OPPORTUNITY'=>'Nouvelle Affaire',
'LNK_NEW_CASE'=>'Nouveau Ticket',
'LNK_NEW_NOTE'=>'Nouvelle Note',
'LNK_NEW_CALL'=>'Nouvel Appel',
'LNK_NEW_EMAIL'=>'Nouvel Email',
'LNK_NEW_MEETING'=>'Nouveau Rendez-vous',
'LNK_NEW_TASK'=>'Nouvelle T�che',

'ERR_DELETE_RECORD'=>"Un num�ro d'enregistrement doit �tre sp�cifi� pour supprimer l'affaire.",
'LBL_TOP_OPPORTUNITIES'=>"Top des Affaires",
);

?>