<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Emails/language/en_us.lang.php,v 1.10 2004/08/03 07:43:17 sugarclint Exp $
 * Description:  Defines the English language pack for the Account module.
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_MODULE_NAME'=>'Emails',
'LBL_MODULE_TITLE'=>'Emails: Accueil',
'LBL_SEARCH_FORM_TITLE'=>'Recherce Email',
'LBL_LIST_FORM_TITLE'=>'Liste des Emails',
'LBL_NEW_FORM_TITLE'=>'Suivi Email',

'LBL_LIST_SUBJECT'=>'Suject',
'LBL_LIST_CONTACT'=>'Contact',
'LBL_LIST_RELATED_TO'=>'Relatif �',
'LBL_LIST_DATE'=>"Date d'envoi",
'LBL_LIST_TIME'=>"Heure d'envoi",

'ERR_DELETE_RECORD'=>"Un num�ro d'enregistrement doit �tre sp�cifi� pour supprimer ce compte.",
'LBL_DATE_SENT'=>"Date d'envoi:",
'LBL_SUBJECT'=>'Suject:',
'LBL_BODY'=>'Corps du message:',
'LBL_DATE_AND_TIME'=>"Date & Heure d'envoi:",
'LBL_DATE'=>"Date d'envoi:",
'LBL_TIME'=>"Heure d'envoi:",
'LBL_SUBJECT'=>'Suject:',
'LBL_BODY'=>'Corps du message:',
'LBL_CONTACT_NAME'=>' Nom du Contact: ',
'LBL_EMAIL'=>'Email:',  
'LBL_COLON'=>':',

'LNK_NEW_CONTACT'=>'Nouveau Contact',
'LNK_NEW_ACCOUNT'=>'Nouveau Compte',
'LNK_NEW_OPPORTUNITY'=>'Nouvelle Affaire',
'LNK_NEW_CASE'=>'Nouveau Ticket',
'LNK_NEW_NOTE'=>'Nouvelle Note',
'LNK_NEW_CALL'=>'Nouvel Appel',
'LNK_NEW_EMAIL'=>'Nouvel Email',
'LNK_NEW_MEETING'=>'Nouveau Rendez-vous',
'LNK_NEW_TASK'=>'Nouvelle T�che',

//New to SugarCRM 1.1c.  Still need to be translated.
'NTC_REMOVE_INVITEE'=>'Are you sure you want to remove this recipient from the email?',
'LBL_INVITEE'=>'Recipients',
);

?>