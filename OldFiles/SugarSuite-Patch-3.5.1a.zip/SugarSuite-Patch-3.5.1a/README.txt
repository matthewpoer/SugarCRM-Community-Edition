Sugar Suite v3.5.1a
October 6, 2005

-=Overview=-
For a quick list of new features in Sugar Suite 3.5.1, check out the information
below.

Our goal continues to be to build the customer relationship management system 
that you have always wanted, so your input is vital.

To share ideas with the Sugar Community, ask questions, find answers and submit 
feedback, please visit our Sugar Forums at http://www.sugarcrm.com/forums.

Check out http://www.sugarcrm.com for more details on acquiring the Sugar Suite,
the latest product roadmap, support forums, detailed product information and 
much more.  We hope you find this a useful tool for building your business.

Enjoy! 
The Sugar Team  

--------------------------------------------------------------------------------
3.5.1a
--------------------------------------------------------------------------------
Note:   To install 3.5.1a, you must first have 3.5.1 installed.  Then use the 
        Upgrade Wizard in the Admin section to apply the 3.5.1a patch.

Note:   Admin users need to log out after "Clear Chart Data Cache" and "Rebuild 
        .htaccess file" scripts are run through Repair section, in order for the 
        Warning messages to disappear.

Fixed:  Status and Type fields were not being parsed through app_list_strings 
        for ListViews. [2289, 2291]

Fixed:  Parent type, parent_id, parent_name, account_name and account_id were 
        not properly populated in subpanels. [2290]

Fixed:  Selecting a second template in an HTML email was not handled properly. 
        [2292]

Fixed:  Related records were not always being fetched from the database 
        correctly. [2299]

Fixed:  Creating a new Contact from an Account DetailView did not auto-populate 
        the Account's address and phone data. [2300]

Fixed:  Translated strings were not available for non-US English Dashboard edit 
        function. [2302]

Fixed:  Reports To field is not immediately displayed for Employees after 
        selecting. [2304]

Fixed:  Email notifications for Calls used GMT time instead of user's time zone 
        preference. [2311]

Fixed:  Line lengths of more than 998 characters in Emails produced unwanted ! 
        characters. [2315]

Fixed:  Updating License Management blanked out other system-wide config table 
        settings. [2320]

Fixed:  Custom fields of type dropdown now check for existence of a key before 
        trying to extract its value.  Result was "Undefined index" notices for 
        SugarBean.php [2321]

Fixed:  Standard dropdown fields displayed keys instead of values in ListViews. 
        [2322]

Fixed:  The Assigned To field was missing from the Project Tasks subpanel. 
        [2323]

Fixed:  Filtering shared calendars resulted in a "Bad data passed in; Return to
        Home" error. [2336]

Fixed:  Scheduling Meetings and Calls did not display free/busy information at 
        the correct times due to GMT offset. [2340]

Fixed:  Default character set header was always sent to browser, regardless of 
        language pack.  Affected Czech, Japanese, Russian, and Traditional 
        Chinese language packs. [2341]

Fixed:  Demo data now uses @example.com instead of @company.com. [2350]

New:    Added a "Send Queued Campaign Emails" button to the Mass Email Manager, 
        allowing admin users to invoke emailmandelivery.php through Sugar, if 
        crontabs are not available. [2354]

Fixed:  Saved emails displayed the wrong date. [2355]

Fixed:  Subpanels did not display Contact full names if either the first or last 
        name was empty. [2356]

Fixed:  Sugar Plug-in for Outlook uses Sugar server time to check for conflicts 
        instead of local Outlook user's time. [2357]

Fixed:  Edited changes in an email were not included when archiving an email 
        through the Sugar Plug-in for Outlook. [2363, 2365]

Fixed:  "Error calling json server" when searching for a Contact while 
        scheduling a Call. [2366]

Fixed:  Contacts ListViews did not include Assigned To as a Mass Update option. 
        [2370]

Fixed:  Change Log popup was not picking up CSS style properly. [2375]

Fixed:  Quotation marks in a Notes DetailView appeared as ' or ". [2376]

Fixed:  Associating emails to Contacts caused Undefined Index errors in the 
        History subpanel. [2379]

Fixed:  Users with non-default date format preferences could not use Dashboard 
        graphs. [2383]











