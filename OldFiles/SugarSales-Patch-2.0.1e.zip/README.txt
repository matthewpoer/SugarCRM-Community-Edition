******************************
*SugarCRM Fall 2004 Release  * 
******************************

Sugar Sales v2.0.1e
January 3, 2005

------------------------------------------------------------------------
2.0.1e
------------------------------------------------------------------------
New: Calendar is now distributed with the open source distribution
Fix: E-mail notification func now handles HTML chars in from name/address
Fix: user_hash for default_user not created
Fix: miscellaneous security issues

------------------------------------------------------------------------
2.0.1d
------------------------------------------------------------------------
Fix: PDFs now stream over SSL in IE, filename now dynamic
Fix: miscellaneous security issues
Fix: Printing: array passed to urlencode() causes errors
Fix: attaching filenames with apostrophes fails
New theme: Shred!

------------------------------------------------------------------------
2.0.1c
------------------------------------------------------------------------
Fix: MySQL problem creating Note

------------------------------------------------------------------------
2.0.1b
------------------------------------------------------------------------
Fix: miscellaneous security issues
Fix: encoding bugs in export.php
Fix: print bugs in index.php
Fix: team sorting in various modules fails

------------------------------------------------------------------------------------------
2.0.1a
------------------------------------------------------------------------------------------
Fix: various security issues
Fix: parent_name not set
Fix: lead conversion issues
Fix: searching for leads by status fails
Fix: Accounts: search restricted to "my own items"
Fix: printing in Reports fails
Fix: not all contacts exported
Fix: extra probability field displayed
Fix: sorting in cases fails for some columns
Additional minor fixes were also included!

-=2.0.1 Maintenance Release=-
Sugar Sales v2.0.1 brings you a variety of fixes since the 2.0 release a few weeks back.  We 
recommend all production sites upgrade to the 2.0.1 release.

Keep finding those bugs!  :)
The Sugar Team 


-=Overview=-
A major facelift and a lot of great new functionality!  The Sugar Team is excited to bring you the 2.0 release.  As you can see, hiring a UI engineer has taken the application to a whole new level of usability and appeal.  Who else has a pink UI?  We're also pleased to bring you the Leads module and significant improvements to the Contact module with vCard support and a simplified way of entering a contact, account and appointment in the single "Create from Business Card" screen.

For businesses that rely on Sugar Sales as a mission-critical system, SugarCRM Inc. also provides Sugar Sales Professional which includes many more great features for your business.  Significant features include Quoting and Product Catalog for creating customer quotes, Reporting for tracking your business, Calendaring for easier viewing of your appointments, Team Selling with Data Security for managing who can access records and an MS Outlook Plug-In for archiving emails.  Sugar Sales Professional also includes exemplary customer support, updates to new versions for a year and more.  

You can send us an email any time with your feedback at contact@sugarcrm.com.  Our goal continues to be to build the sales automation system that you have always wanted, so your input is vital.

Check out http://www.sugarcrm.com for more details on acquiring Sugar Professional, the latest product roadmap, support forums, detailed product information and much more.  We hope you find this a useful tool for building your business.

Enjoy! 
The Sugar Team 


-=Included Features=-
An overview of the features in this release. 

Leads
New to 2.0, put standardized processes into practice to make sure all sales reps use the same, consistent lead qualification methodology. With the click of a button, quickly turn leads into opportunities. With the Sugar Sales Leads module, you can also easily manage rented lists and prospect data separate from your customer data.

Import and Export
Import contacts and accounts from CSV (comma separated values) files.  Users can also easily export data from the system to CSV files.

Opportunities
Sugar Sales provides a complete, yet easy-to-use Opportunities module.  From deal size to each contact�s role, from listing the competitors to tracking the lead source, sales reps can easily manage each sales opportunity to completion.  

Accounts & Contacts
With the Accounts & Contacts module, you can easily enter and update key account and contact information. Tracking and staying in touch with your customers is simply a click away. 

Activity & Task Management
Managing your customer interactions is at the heart of a sales automation application. Sugar Sales provides a simple and clean set of tools for quickly tracking tasks, phone calls, emails and meetings. 

Notes & Attachments
Easily keep notes on every contact, opportunity or account. New to v1.5, add file attachments to notes.  

Home Screen 
Focus on the right activities with a quick view of your top opportunities, pipeline, today's appointments and task list.

Dashboard 
A picture is always worth a thousand words.  With the dashboard module, you can graphically view how your opportunities breakdown by sales stage or industry.  New to v1.5, you can customize the charts to display the data you want.

Administration 
Easily manage all the users in the system, their passwords, user interface themes and more. 


-=Future Planned Features=-
What we're working on next. 

Internationalization 
Support for local and localized date and time display. 

Accounts & Contacts
Easily sync customer contact information between Sugar Sales and MS Outlook and Palm devices. 

Activity & Task Management
Plug-ins for PDAs and email applications that deliver a best-in-class open source solution for tracking key customer information in your PDA quickly and easily.

Notes & Attachments
Ability to enter HTML notes. Also provide for full-text searching across text or HTML notes as well as most file attachments.

Dashboard 
More dashboard charts including the ability to customize the charts by time ranges, deal size and more. 
