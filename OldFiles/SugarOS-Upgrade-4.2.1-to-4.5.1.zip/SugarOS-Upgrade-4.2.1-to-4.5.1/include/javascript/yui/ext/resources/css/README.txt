2006-11-21 jvs:
yui-ext.css contains all of the other css files combined and stripped of comments.

