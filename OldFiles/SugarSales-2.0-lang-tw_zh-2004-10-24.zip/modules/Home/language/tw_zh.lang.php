<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/include/language/en_us.lang.php,v 1.89 2004/10/25 02:32:20 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_NEW_FORM_TITLE' => '新增聯絡人',
  'LBL_FIRST_NAME' => '姓：',
  'LBL_LAST_NAME' => '名：',
  'LBL_LIST_LAST_NAME' => '姓',
  'LBL_PHONE' => '電話：',
  'LBL_EMAIL_ADDRESS' => '電子郵件：',
  'LBL_PIPELINE_FORM_TITLE' => '我的銷售數據',
  'LNK_NEW_CONTACT' => '新增聯絡人',
  'LNK_NEW_ACCOUNT' => '新增公司',
  'LNK_NEW_OPPORTUNITY' => '新增機會',
  'LNK_NEW_LEAD' => 'Create Lead',
  'LNK_NEW_CASE' => '新增事件',
  'LNK_NEW_NOTE' => '新增備註',
  'LNK_NEW_CALL' => '新增電話記錄',
  'LNK_NEW_EMAIL' => '新增電子郵件',
  'LNK_NEW_MEETING' => '新增會議',
  'LNK_NEW_TASK' => '新增任務',
  'ERR_ONE_CHAR' => '請至少輸入一個文字或者數字再搜尋 ...',
  'LBL_OPEN_TASKS' => '我要完成的任務',
);


?>