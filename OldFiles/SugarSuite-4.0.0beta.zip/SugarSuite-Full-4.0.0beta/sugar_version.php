<?php
// $Id: sugar_version.php,v 1.51 2005/12/01 18:40:02 andrew Exp $
$sugar_version      = '4.0.0beta';
$sugar_db_version   = '4.0.0beta';
$sugar_flavor       = 'OS';
?>
