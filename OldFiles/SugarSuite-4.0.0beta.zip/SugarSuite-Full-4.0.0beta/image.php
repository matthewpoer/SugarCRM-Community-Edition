<?PHP

include_once('config.php');
require_once('log4php/LoggerManager.php');
require_once('include/database/PearDatabase.php');
require_once('modules/Users/User.php');
require_once('include/modules.php');
require_once('include/utils.php');
require_once('modules/ACL/ACLController.php');
require_once('modules/Campaigns/utils.php');


$GLOBALS['log'] = LoggerManager::getLogger('image');
$GLOBALS['log']->debug('identifier from the imgae request is'.$_REQUEST['identifier']);
if(!empty($_REQUEST['identifier'])) {
	$keys=log_campaign_activity($_REQUEST['identifier'],'viewed');
}
sugar_cleanup();
Header("Content-Type: image/gif");
$fn=fopen("./include/images/blank.gif","r");
fpassthru($fn);
?>
