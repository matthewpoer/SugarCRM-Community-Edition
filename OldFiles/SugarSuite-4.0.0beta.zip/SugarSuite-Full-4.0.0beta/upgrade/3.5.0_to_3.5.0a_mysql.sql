












ALTER TABLE `document_revisions` MODIFY COLUMN `filename` varchar(255) NOT NULL default '';
ALTER TABLE `emails` MODIFY COLUMN `date_start` date default NULL;

DELETE FROM `config` where `category` = 'info' and `name` = 'sugar_version';
INSERT INTO config (category, name, value) VALUES ('info', 'sugar_version', '3.5.0');
