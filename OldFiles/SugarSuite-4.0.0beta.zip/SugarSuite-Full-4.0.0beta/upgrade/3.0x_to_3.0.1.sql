ALTER TABLE `opportunities` CHANGE `next_step` `next_step` VARCHAR( 100 );
ALTER TABLE `meetings` ADD `outlook_id` varchar(255);
ALTER TABLE `calls` ADD `outlook_id` varchar(255);








UPDATE `config` SET `value` = '3.0.1' WHERE `category` = 'info' AND `name` = 'sugar_version';
