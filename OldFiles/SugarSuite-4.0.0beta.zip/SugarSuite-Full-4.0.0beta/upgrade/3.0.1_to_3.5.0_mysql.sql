CREATE TABLE `accounts_audit` (
  `id` varchar(36) NOT NULL default '',
  `parent_id` varchar(36) NOT NULL default '',
  `date_created` datetime default NULL,
  `created_by` varchar(36) default NULL,
  `field_name` varchar(100) default NULL,
  `data_type` varchar(100) default NULL,
  `before_value_string` varchar(255) default NULL,
  `after_value_string` varchar(255) default NULL,
  `before_value_text` text,
  `after_value_text` text
);


ALTER TABLE `accounts_bugs` ADD `date_modified` datetime default NULL AFTER `bug_id`,
ADD INDEX `idx_account_bug` (`account_id`,`bug_id`);


ALTER TABLE `accounts_cases` ADD `date_modified` datetime default NULL AFTER `case_id`;


ALTER TABLE `accounts_contacts` ADD `date_modified` datetime default NULL AFTER `account_id`,
ADD INDEX `idx_account_contact` (`account_id`,`contact_id`);


ALTER TABLE `accounts_opportunities` ADD `date_modified` datetime default NULL AFTER `account_id`,
ADD INDEX `idx_account_opportunity` (`account_id`,`opportunity_id`);


ALTER TABLE `bugs` CHANGE COLUMN `number` `bug_number` INTEGER NOT NULL AUTO_INCREMENT,
DROP INDEX `number`,
ADD INDEX `bug_number` (`bug_number`);


CREATE TABLE `bugs_audit` (
  `id` varchar(36) NOT NULL default '',
  `parent_id` varchar(36) NOT NULL default '',
  `date_created` datetime default NULL,
  `created_by` varchar(36) default NULL,
  `field_name` varchar(100) default NULL,
  `data_type` varchar(100) default NULL,
  `before_value_string` varchar(255) default NULL,
  `after_value_string` varchar(255) default NULL,
  `before_value_text` text,
  `after_value_text` text
);


ALTER TABLE `calls_contacts` ADD `date_modified` datetime default NULL AFTER `accept_status`,
ADD INDEX `idx_call_contact` (`call_id`,`contact_id`);


ALTER TABLE `calls_users` ADD `date_modified` datetime default NULL AFTER `accept_status`,
ADD INDEX `idx_call_users` (`call_id`,`user_id`);


CREATE TABLE `campaigns_audit` (
  `id` varchar(36) NOT NULL default '',
  `parent_id` varchar(36) NOT NULL default '',
  `date_created` datetime default NULL,
  `created_by` varchar(36) default NULL,
  `field_name` varchar(100) default NULL,
  `data_type` varchar(100) default NULL,
  `before_value_string` varchar(255) default NULL,
  `after_value_string` varchar(255) default NULL,
  `before_value_text` text,
  `after_value_text` text
);


ALTER TABLE `cases` CHANGE COLUMN `number` `case_number` int(11) NOT NULL auto_increment,
DROP INDEX `number`,
ADD INDEX `case_number` (`case_number`);


CREATE TABLE `cases_audit` (
  `id` varchar(36) NOT NULL default '',
  `parent_id` varchar(36) NOT NULL default '',
  `date_created` datetime default NULL,
  `created_by` varchar(36) default NULL,
  `field_name` varchar(100) default NULL,
  `data_type` varchar(100) default NULL,
  `before_value_string` varchar(255) default NULL,
  `after_value_string` varchar(255) default NULL,
  `before_value_text` text,
  `after_value_text` text
);


ALTER TABLE `cases_bugs` ADD `date_modified` datetime default NULL AFTER `bug_id`,
ADD INDEX `idx_case_bug` (`case_id`,`bug_id`);


ALTER TABLE `config` MODIFY COLUMN `value` text;


CREATE TABLE `contacts_audit` (
  `id` varchar(36) NOT NULL default '',
  `parent_id` varchar(36) NOT NULL default '',
  `date_created` datetime default NULL,
  `created_by` varchar(36) default NULL,
  `field_name` varchar(100) default NULL,
  `data_type` varchar(100) default NULL,
  `before_value_string` varchar(255) default NULL,
  `after_value_string` varchar(255) default NULL,
  `before_value_text` text,
  `after_value_text` text
);


ALTER TABLE `contacts_bugs` ADD `date_modified` datetime default NULL AFTER `contact_role`,
ADD INDEX `idx_contact_bug` (`contact_id`,`bug_id`);


ALTER TABLE `contacts_cases` ADD `date_modified` datetime default NULL AFTER `contact_role`,
ADD INDEX `idx_contacts_cases` (`contact_id`,`case_id`);


CREATE TABLE `contacts_users` (
  `id` char(36) NOT NULL default '',
  `contact_id` char(36) default NULL,
  `user_id` char(36) default NULL,
  `date_modified` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `idx_con_users_con` (`contact_id`),
  KEY `idx_con_users_user` (`user_id`),
  KEY `idx_contacts_users` (`contact_id`,`user_id`)
);


ALTER TABLE `document_revisions` ADD `date_modified` datetime default NULL AFTER `deleted`;


ALTER TABLE `email_templates` ADD `body_html` text AFTER `body`;


ALTER TABLE `emails` ADD `description_html` text AFTER `description`;


ALTER TABLE `emails_accounts` ADD `date_modified` datetime default NULL AFTER `account_id`;


ALTER TABLE `emails_cases` ADD `date_modified` datetime default NULL AFTER `case_id`;


ALTER TABLE `emails_contacts` ADD `date_modified` datetime default NULL AFTER `contact_id`;


ALTER TABLE `emails_opportunities` ADD `date_modified` datetime default NULL AFTER `opportunity_id`;


ALTER TABLE `emails_users` ADD `date_modified` datetime default NULL AFTER `user_id`;


ALTER TABLE `fields_meta_data` ADD `date_modified` datetime default NULL AFTER `default_value`,
ADD `audited` tinyint(1) default '0' AFTER `deleted`;


CREATE TABLE `leads_audit` (
  `id` varchar(36) NOT NULL default '',
  `parent_id` varchar(36) NOT NULL default '',
  `date_created` datetime default NULL,
  `created_by` varchar(36) default NULL,
  `field_name` varchar(100) default NULL,
  `data_type` varchar(100) default NULL,
  `before_value_string` varchar(255) default NULL,
  `after_value_string` varchar(255) default NULL,
  `before_value_text` text,
  `after_value_text` text
);


ALTER TABLE `meetings_contacts` ADD `date_modified` datetime default NULL AFTER `accept_status`,
ADD INDEX `idx_meeting_contact` (`meeting_id`,`contact_id`);


ALTER TABLE `meetings_users` ADD `date_modified` datetime default NULL AFTER `accept_status`,
ADD INDEX `idx_meeting_users` (`meeting_id`,`user_id`);


CREATE TABLE `opportunities_audit` (
  `id` varchar(36) NOT NULL default '',
  `parent_id` varchar(36) NOT NULL default '',
  `date_created` datetime default NULL,
  `created_by` varchar(36) default NULL,
  `field_name` varchar(100) default NULL,
  `data_type` varchar(100) default NULL,
  `before_value_string` varchar(255) default NULL,
  `after_value_string` varchar(255) default NULL,
  `before_value_text` text,
  `after_value_text` text
);


ALTER TABLE `opportunities_contacts` ADD `date_modified` datetime default NULL AFTER `contact_role`,
ADD INDEX `idx_opportunities_contacts` (`opportunity_id`,`contact_id`);


ALTER TABLE `project_relation` ADD `date_modified` datetime NOT NULL default '0000-00-00 00:00:00' AFTER `deleted`;


CREATE TABLE `project_task_audit` (
  `id` varchar(36) NOT NULL default '',
  `parent_id` varchar(36) NOT NULL default '',
  `date_created` datetime default NULL,
  `created_by` varchar(36) default NULL,
  `field_name` varchar(100) default NULL,
  `data_type` varchar(100) default NULL,
  `before_value_string` varchar(255) default NULL,
  `after_value_string` varchar(255) default NULL,
  `before_value_text` text,
  `after_value_text` text
);


ALTER TABLE `prospect_list_campaigns` ADD `date_modified` datetime default NULL AFTER `campaign_id`,
ADD INDEX `idx_prospect_list_campaigns` (`prospect_list_id`,`campaign_id`);


ALTER TABLE `prospect_lists_prospects` ADD `date_modified` datetime default NULL AFTER `lead_id`;


CREATE TABLE `relationships` (
  `id` varchar(36) NOT NULL default '',
  `relationship_name` varchar(150) NOT NULL default '',
  `lhs_module` varchar(100) NOT NULL default '',
  `lhs_table` varchar(64) NOT NULL default '',
  `lhs_key` varchar(64) NOT NULL default '',
  `rhs_module` varchar(100) NOT NULL default '',
  `rhs_table` varchar(64) NOT NULL default '',
  `rhs_key` varchar(64) NOT NULL default '',
  `join_table` varchar(64) default NULL,
  `join_key_lhs` varchar(64) default NULL,
  `join_key_rhs` varchar(64) default NULL,
  `relationship_type` varchar(64) default NULL,
  `relationship_role_column` varchar(64) default NULL,
  `relationship_role_column_value` varchar(15) default NULL,
  `reverse` tinyint(1) default '0',
  `deleted` tinyint(1) default '0',
  PRIMARY KEY  (`id`),
  KEY `idx_rel_name` (`relationship_name`)
);


ALTER TABLE `roles_modules` ADD `date_modified` datetime default NULL AFTER `allow`;


ALTER TABLE `roles_users` ADD `date_modified` datetime default NULL AFTER `user_id`;


ALTER TABLE `tracker` ADD `date_modified` datetime default NULL AFTER `item_summary`;


CREATE TABLE `upgrade_history` (
  `id` varchar(36) NOT NULL default '',
  `filename` varchar(255) NOT NULL default '',
  `md5sum` varchar(32) NOT NULL default '',
  `type` varchar(30) NOT NULL default '',
  `status` varchar(50) NOT NULL default '',
  `version` varchar(10) NOT NULL default '',
  `date_entered` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `upgrade_history_md5_uk` (`md5sum`)
);


ALTER TABLE `users` MODIFY COLUMN `modified_user_id` VARCHAR(36),
MODIFY COLUMN `portal_only` tinyint(1) default '0';

ALTER TABLE `users_feeds` ADD `date_modified` datetime default NULL AFTER `rank`;












































































































ALTER TABLE `document_revisions` MODIFY COLUMN `filename` varchar(255) NOT NULL default '';

ALTER TABLE `emails` MODIFY COLUMN `date_start` date default NULL;
