<?php
// $Id: util_test.php,v 1.1 2005/10/11 00:05:41 andrew Exp $

chdir('..');
require_once('include/utils.php');

class UtilTestCase extends UnitTestCase
{
	function UtilTestCase()
	{
		$this->UnitTestCase('Utility function tests');
	}

	function setUp()
	{
	}

	function tearDown()
	{
	}

	function testStrBegin()
	{
		$result = str_begin('headoftheclass', 'head');
		$this->assertTrue($result);
	}

	function testStrEnd()
	{
		$result = str_end('backoftheline', 'line');
		$this->assertTrue($result);
	}

}

chdir('test');

?>
