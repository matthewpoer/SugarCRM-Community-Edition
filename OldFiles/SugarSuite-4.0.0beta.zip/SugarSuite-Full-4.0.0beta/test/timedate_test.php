<?php
// $Id: timedate_test.php,v 1.2 2005/10/18 22:31:38 andrew Exp $

chdir('..');
require_once('include/TimeDate.php');

class TimeDateTestCase extends UnitTestCase
{
	var $time_date;

	function TimeDateTestCase()
	{
		$this->UnitTestCase('TimeDate function tests');
	}

	function setUp()
	{
		$this->time_date = new TimeDate();
	}

	function tearDown()
	{
		unset($this->time_date);
	}

	function test_same_date_format()
	{
		$original_date = '2005-12-25';
		$original_format = 'Y-m-d';
		$new_format = $original_format;
		$expected_new_date = $original_date;

		$new_date = $this->time_date->swap_formats($original_date,
			$original_format, $new_format);

		$this->assertEqual($expected_new_date, $new_date,
			'Same date format not returned.');
	}

	function test_mdy_to_dmy()
	{
		$original_date = '12-25-2005';
		$original_format = 'm-d-Y';
		$new_format = 'd-m-Y';
		$expected_new_date = '25-12-2005';

		$new_date = $this->time_date->swap_formats($original_date,
			$original_format, $new_format);

		$this->assertEqual($expected_new_date, $new_date,
			"Convert from $original_format to $new_format failed.");
	}

	function test_same_datetime_format()
	{
		$original_date = '2005-12-25 12:55:35';
		$original_format = 'Y-m-d H:i:s';
		$new_format = $original_format;
		$expected_new_date = $original_date;

		$new_date = $this->time_date->swap_formats($original_date,
			$original_format, $new_format);

		$this->assertEqual($expected_new_date, $new_date,
			'Same datetime format not returned.');
	}

	function test_ymdhi_to_ymdhis()
	{
		$original_date = '2005-12-25 12:55';
		$original_format = 'Y-m-d H:i';
		$new_format = 'Y-m-d H:i:s';
		$expected_new_date = '2005-12-25 12:55:00';

		$new_date = $this->time_date->swap_formats($original_date,
			$original_format, $new_format);

		$this->assertEqual($expected_new_date, $new_date,
			"Convert from $original_format to $new_format failed.");
	}

	function test_ymdhi_to_ymdhia()
	{
		$original = '2005-12-25 13:55';
		$original_format = 'Y-m-d H:i';
		$new_format = 'Y-m-d h:ia';
		$expected = '2005-12-25 01:55pm';

		$new = $this->time_date->swap_formats($original,
			$original_format, $new_format);

		$this->assertEqual($expected, $new,
			"Convert from $original_format to $new_format failed.");
	}

	function test_date_combinations()
	{
		$orig_formats_and_dates = array(
			'Y-m-d' => '2006-12-23',
			'm-d-Y' => '12-23-2006',
			'd-m-Y' => '23-12-2006',
			'Y/m/d' => '2006/12/23',
			'm/d/Y' => '12/23/2006',
			'd/m/Y' => '23/12/2006');

		$new_formats_and_dates = $orig_formats_and_dates;

		foreach($orig_formats_and_dates as $orig_format => $orig_date)
		{
			foreach($new_formats_and_dates as $new_format => $expected_date)
			{
				$new_date = $this->time_date->swap_formats($orig_date,
					$orig_format, $new_format);

				$this->assertEqual($expected_date, $new_date,
					"Convert from $orig_format to $new_format failed.");

				if($expected_date != $new_date)
				{
					return;
				}
			}
		}
	}
}

chdir('test');

?>
