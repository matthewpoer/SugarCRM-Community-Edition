<?php
// $Id: index.php,v 1.1 2005/10/11 00:05:41 andrew Exp $

require_once('all_unit_tests.php');

?>
