<?php
// $Id: phpinfo.php,v 1.1 2005/10/10 22:49:45 andrew Exp $
phpinfo();
?>
