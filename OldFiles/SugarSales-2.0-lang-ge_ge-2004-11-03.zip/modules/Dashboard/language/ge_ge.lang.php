<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.2 2004/10/29 15:59:25 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => '�bersicht',
  'LBL_MODULE_TITLE' => '�bersicht: Home',
  'LBL_SALES_STAGE_FORM_TITLE' => 'Total Pipeline nach Verkaufsstufe',
  'LBL_SALES_STAGE_FORM_DESC' => 'Zeigt kumulierte Auftragssummen nach ausgew�hlter Verkaufsphase und ausgew�hlten Benutzern, bei welchen das erwartete Abschlussdatum im angegebenen Datumsbereich liegt.',
  'LBL_MONTH_BY_OUTCOME' => 'Offene Auftr�ge nach Monat und Ergebnis',
  'LBL_MONTH_BY_OUTCOME_DESC' => 'Zeigt kumulierte Auftragssummen pro Monat und Ergebnis von ausgew�hlten Benutzern, bei welchen das erwartete Abschlussdatum im angegebenen Datumsbereich liegt. Das Ergebnis ist abh�ngig davon, ob die Verkaufsphase gewonnen, verloren oder einen anderen Wert besitzt!',
  'LBL_LEAD_SOURCE_FORM_TITLE' => 'Total Pipeline nach Herkunft des Auftrages',
  'LBL_LEAD_SOURCE_FORM_DESC' => 'Zeigt kumulierte Auftragssummen nach gew�hlter Auftragsherkunft f�r ausgew�hlte Benutzer.',
  'LBL_LEAD_SOURCE_BY_OUTCOME' => 'Alle Auftr�ge nach Auftragsherkunft und Ergebnis',
  'LBL_LEAD_SOURCE_BY_OUTCOME_DESC' => 'Zeigt kumulierte Auftragssummen nach gew�hlter Auftragsherkunft und Ergebnis der gew�hlten Benutzer im angegebenen Datumsbereich. Das Ergebnis ist abh�ngig davon, ob die Verkaufsphase gewonnen, verloren oder einen anderen Wert besitzt!',
  'LBL_PIPELINE_FORM_TITLE_DESC' => 'Zeigt kumulierte Auftragssummen nach gew�hlter Verkaufsphase f�r Ihre Auftr�ge, bei welchen das erwartete Abschlussdatum im angegebenen Datumsbereich liegt.',
  'LBL_DATE_RANGE' => 'Datums Bereich von',
  'LBL_DATE_RANGE_TO' => 'bis',
  'ERR_NO_OPPS' => 'Sie m�ssen zuerst Auftr�ge erfassen um die Diagramme zu sehen.',
  'LBL_TOTAL_PIPELINE' => 'Total Pipeline ist ',
  'LBL_ALL_OPPORTUNITIES' => 'Gesamtbetrag aller Auftr�ge ist ',
  'LBL_OPP_SIZE' => 'Auftr�ge in 1000',
  'LBL_OPP_THOUSANDS' => 'K',
  'NTC_NO_LEGENDS' => 'Keine',
  'LBL_LEAD_SOURCE_OTHER' => 'Andere',
  'LBL_EDIT' => 'Bearbeiten',
  'LBL_REFRESH' => 'Aktualisieren',
  'LBL_CREATED_ON' => 'Zuletzt aktualisiert am ',
  'LBL_OPPS_IN_STAGE' => 'Auftr�ge, bei welchen die Verkaufsphase =',
  'LBL_OPPS_IN_LEAD_SOURCE' => 'Auftr�ge mit Auftragsherkunft =',
  'LBL_OPPS_OUTCOME' => 'Auftr�ge mit Auftragssumme =',
  'LBL_USERS' => 'Benutzer',
  'LBL_SALES_STAGES' => 'Verkaufsphasen',
  'LBL_LEAD_SOURCES' => 'Auftragsherkunft',
  'LBL_DATE_START' => 'Anfangs Datum',
  'LBL_DATE_END' => 'End Datum',
  'LNK_NEW_CONTACT' => 'Neuer Kontakt',
  'LNK_NEW_ACCOUNT' => 'Neuer Kunde',
  'LNK_NEW_OPPORTUNITY' => 'Neuer Auftrag',
  'LNK_NEW_QUOTE' => 'Neue Offerte',
  'LNK_NEW_LEAD' => 'Neuer Hinweis',
  'LNK_NEW_CASE' => 'Neue Anfrage',
  'LNK_NEW_NOTE' => 'Neue Notiz',
  'LNK_NEW_CALL' => 'Neues Telefonat',
  'LNK_NEW_MEETING' => 'Neuer Termin',
  'LNK_NEW_TASK' => 'Neue Aufgabe',
  'LNK_NEW_EMAIL' => 'Neue Email',
  'ERR_DELETE_RECORD' => 'Ein Eintrag muss ausgew�hlt sein um diesen zu l�schen.',
);


?>
