<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.2 2004/10/29 15:59:25 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Aktivit�ten',
  'LBL_MODULE_TITLE' => 'Aktivit�ten: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Aktivit�ten Suchen',
  'LBL_LIST_FORM_TITLE' => 'Aktivit�ten',
  'LBL_LIST_SUBJECT' => 'Titel',
  'LBL_LIST_CONTACT' => 'Kontakt',
  'LBL_LIST_RELATED_TO' => 'Verantwortlich',
  'LBL_LIST_DATE' => 'Datum',
  'LBL_LIST_TIME' => 'Start Time',
  'LBL_LIST_CLOSE' => 'Schliessen',
  'LBL_SUBJECT' => 'Titel:',
  'LBL_STATUS' => 'Status:',
  'LBL_LOCATION' => 'Ort:',
  'LBL_DATE_TIME' => 'Start Datum & Zeit:',
  'LBL_DATE' => 'Start Datum:',
  'LBL_TIME' => 'Start Zeit:',
  'LBL_DURATION' => 'Dauer:',
  'LBL_HOURS_MINS' => '(Stunden/Minuten)',
  'LBL_CONTACT_NAME' => 'Kontakt Namen: ',
  'LBL_MEETING' => 'Termin:',
  'LBL_DESCRIPTION_INFORMATION' => 'Beschreibung',
  'LBL_DESCRIPTION' => 'Beschreibung:',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'Geplant',
  'LNK_NEW_CALL' => 'Neues Telefonat',
  'LNK_NEW_MEETING' => 'Neuer Termin',
  'LNK_NEW_TASK' => 'Neue Aufgabe',
  'LNK_NEW_NOTE' => 'Neue Notiz',
  'LNK_NEW_EMAIL' => 'Neue Email',
  'LNK_CALL_LIST' => 'Anrufe',
  'LNK_MEETING_LIST' => 'Termine',
  'LNK_TASK_LIST' => 'Aufgaben',
  'LNK_NOTE_LIST' => 'Notizen',
  'LNK_EMAIL_LIST' => 'Emails',
  'ERR_DELETE_RECORD' => 'Ein Eintrag muss ausgew�hlt sein um eine Aktivit�t zu l�schen.',
  'NTC_REMOVE_INVITEE' => 'Sind Sie sicher das Sie diese eingeladene Person von dem Termin entfernen m�chten?',
  'LBL_INVITEE' => 'Eingeladen',
  'LBL_LIST_DIRECTION' => 'Richtung',
  'LBL_DIRECTION' => 'Richtung',
  'LNK_NEW_APPOINTMENT' => 'Neuer Termin',
  'LNK_VIEW_CALENDAR' => 'Heute',
  'LBL_OPEN_ACTIVITIES' => 'Offene Aktivit�ten',
  'LBL_HISTORY' => 'Verlauf',
  'LBL_UPCOMING' => 'Anstehende Aktivit�ten',
  'LBL_TODAY' => 'am ',
  'LBL_NEW_TASK_BUTTON_TITLE' => 'Neue Aufgabe [Alt+N]',
  'LBL_NEW_TASK_BUTTON_KEY' => 'N',
  'LBL_NEW_TASK_BUTTON_LABEL' => 'Neue Aufgabe',
  'LBL_SCHEDULE_MEETING_BUTTON_TITLE' => 'Termin eintragen [Alt+M]',
  'LBL_SCHEDULE_MEETING_BUTTON_KEY' => 'M',
  'LBL_SCHEDULE_MEETING_BUTTON_LABEL' => 'Termin eintragen',
  'LBL_SCHEDULE_CALL_BUTTON_TITLE' => 'Telefonat eintragen [Alt+C]',
  'LBL_SCHEDULE_CALL_BUTTON_KEY' => 'C',
  'LBL_SCHEDULE_CALL_BUTTON_LABEL' => 'Telefonat eintragen',
  'LBL_NEW_NOTE_BUTTON_TITLE' => 'Neue Notiz [Alt+T]',
  'LBL_NEW_NOTE_BUTTON_KEY' => 'T',
  'LBL_NEW_NOTE_BUTTON_LABEL' => 'Neue Notiz',
  'LBL_TRACK_EMAIL_BUTTON_TITLE' => 'Email verfolgen [Alt+K]',
  'LBL_TRACK_EMAIL_BUTTON_KEY' => 'K',
  'LBL_TRACK_EMAIL_BUTTON_LABEL' => 'Email verfolgen',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_LIST_DUE_DATE' => 'F�llig am',
  'LBL_LIST_LAST_MODIFIED' => 'Zuletzt ge�ndert',
  'NTC_NONE_SCHEDULED' => 'Keine Termine eingetragen.',
  'LNK_NEW_CONTACT' => 'Neuer Kontakt',
  'LNK_NEW_ACCOUNT' => 'Neuer Kunde',
  'LNK_NEW_OPPORTUNITY' => 'Neuer Auftrag',
  'LNK_NEW_CASE' => 'Neue Anfrage',
);


?>
