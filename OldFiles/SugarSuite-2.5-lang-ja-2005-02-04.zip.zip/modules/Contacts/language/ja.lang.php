<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => '�S����',
  'LBL_INVITEE' => '��i',
  'LBL_MODULE_TITLE' => '�S����: �z�[��',
  'LBL_SEARCH_FORM_TITLE' => '�S���Ҍ���',
  'LBL_LIST_FORM_TITLE' => '�S���҃��X�g',
  'LBL_NEW_FORM_TITLE' => '�S���ҍ쐬',
  'LBL_CONTACT_OPP_FORM_TITLE' => '���k�S����:',
  'LBL_CONTACT' => '�S����:',
  'LBL_BUSINESSCARD' => 'Business Card',
  'LBL_LIST_NAME' => '��',
  'LBL_LIST_LAST_NAME' => '��',
  'LBL_LIST_CONTACT_NAME' => '�S���Җ�',
  'LBL_LIST_TITLE' => '��E',
  'LBL_LIST_ACCOUNT_NAME' => '�ڋq��',
  'LBL_LIST_EMAIL_ADDRESS' => '���[��',
  'LBL_LIST_OTHER_EMAIL_ADDRESS' => 'Other Email',
  'LBL_LIST_PHONE' => '�d�b',
  'LBL_LIST_CONTACT_ROLE' => '����',
  'LBL_LIST_FIRST_NAME' => 'First Name',
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_email2' => 'LBL_LIST_OTHER_EMAIL_ADDRESS',
  'LBL_EXISTING_CONTACT' => 'Used an existing contact',
  'LBL_CREATED_CONTACT' => 'Created a new contact',
  'LBL_EXISTING_ACCOUNT' => 'Used an existing account',
//END DON'T CONVERT
  'LBL_CREATED_ACCOUNT' => 'Created a new account',
  'LBL_CREATED_CALL' => 'Created a new call',
  'LBL_CREATED_MEETING' => 'Created a new meeting',
  'LBL_ADDMORE_BUSINESSCARD' => 'Add another business card',
  'LBL_ADD_BUSINESSCARD' => 'Create From Business Card',
  'LBL_NAME' => '���O:',
  'LBL_CONTACT_NAME' => '�S���Җ�:',
  'LBL_CONTACT_INFORMATION' => '�S���ҏ��',
  'LBL_FIRST_NAME' => '��:',
  'LBL_OFFICE_PHONE' => '��Гd�b:',
  'LBL_ACCOUNT_NAME' => '�ڋq��:',
  'LBL_ANY_PHONE' => '�d�b:',
  'LBL_PHONE' => '�d�b:',
  'LBL_LAST_NAME' => '��:',
  'LBL_MOBILE_PHONE' => '�g�ѓd�b:',
  'LBL_HOME_PHONE' => '����d�b:',
  'LBL_LEAD_SOURCE' => '������:',
  'LBL_OTHER_PHONE' => '���̑��d�b:',
  'LBL_FAX_PHONE' => '�t�@�b�N�X:',
  'LBL_PRIMARY_ADDRESS_STREET' => 'Primary Address Street:',
  'LBL_PRIMARY_ADDRESS_CITY' => 'Primary Address City:',
  'LBL_PRIMARY_ADDRESS_COUNTRY' => 'Primary Address Country:',
  'LBL_PRIMARY_ADDRESS_STATE' => 'Primary Address State:',
  'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'Primary Address Postal Code:',
  'LBL_ALT_ADDRESS_STREET' => 'Alternate Address Street:',
  'LBL_ALT_ADDRESS_CITY' => 'Alternate Address City:',
  'LBL_ALT_ADDRESS_COUNTRY' => 'Alternate Address Country:',
  'LBL_ALT_ADDRESS_STATE' => 'Alternate Address State:',
  'LBL_ALT_ADDRESS_POSTALCODE' => 'Alternate Address Postal Code:',
  'LBL_TITLE' => '��E:',
  'LBL_DEPARTMENT' => '����:',
  'LBL_BIRTHDATE' => '�a����:',
  'LBL_EMAIL_ADDRESS' => '���[��:',
  'LBL_OTHER_EMAIL_ADDRESS' => '���̑����[��:',
  'LBL_ANY_EMAIL' => '���[��:',
  'LBL_REPORTS_TO' => '��i:',
  'LBL_ASSISTANT' => '�鏑:',
  'LBL_ASSISTANT_PHONE' => '�鏑�d�b:',
  'LBL_DO_NOT_CALL' => '�d�b�֎~:',
  'LBL_EMAIL_OPT_OUT' => 'Email Opt Out:',
  'LBL_PRIMARY_ADDRESS' => '���C���Z��:',
  'LBL_ALTERNATE_ADDRESS' => '�T�u�Z��:',
  'LBL_ANY_ADDRESS' => '�Z��:',
  'LBL_CITY' => '�s�撬��:',
  'LBL_STATE' => '�s���{��:',
  'LBL_POSTAL_CODE' => '�X�֔ԍ�:',
  'LBL_COUNTRY' => '��:',
  'LBL_DESCRIPTION_INFORMATION' => '�������',
  'LBL_ADDRESS_INFORMATION' => '�Z�����',
  'LBL_DESCRIPTION' => '����:',
  'LBL_CONTACT_ROLE' => '����:',
  'LBL_OPP_NAME' => '���k��:',
  'LBL_IMPORT_VCARD' => 'Import vCard',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new contact by importing a vCard from your file system.',
  'LBL_DUPLICATE' => 'Possible Duplicate Contacts',
  'MSG_SHOW_DUPLICATES' => 'Creating this contact may potentialy create a duplicate contact. You may either click on Create Contact to continue creating this new contact with the previously entered data or you may click Cancel.',
  'MSG_DUPLICATE' => 'Creating this contact may potentialy create a duplicate contact. You may either select a contact from the list below or you may click on Create New Contact to continue creating a new contact with the previously entered data.',
  'LNK_CONTACT_LIST' => 'Contacts',
  'LNK_IMPORT_VCARD' => 'Create From vCard',
  'LNK_NEW_CONTACT' => '�S���ҍ쐬',
  'LNK_NEW_ACCOUNT' => '�ڋq�쐬',
  'LNK_NEW_OPPORTUNITY' => '���k�쐬',
  'LNK_NEW_CASE' => '����쐬',
  'LNK_NEW_NOTE' => '�m�[�g�쐬',
  'LNK_NEW_CALL' => '�R�[���쐬',
  'LNK_NEW_EMAIL' => '���[���쐬',
  'LNK_NEW_MEETING' => '�~�[�e�B���O�쐬',
  'LNK_NEW_TASK' => '�^�X�N�쐬',
  'LNK_NEW_APPOINTMENT' => 'Create Appointment',
  'NTC_DELETE_CONFIRMATION' => 'Are you sure you want to delete this record?',
  'NTC_REMOVE_CONFIRMATION' => 'Are you sure you want to remove this contact from this case?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Are you sure you want to remove this record as a direct report?',
  'ERR_DELETE_RECORD' => 'en_us A record number must be specified to delete the contact.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Copy ���C���Z�� to �T�u�Z��',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Copy �T�u�Z�� to ���C���Z��',
  'LBL_SALUTATION' => 'Salutation',
  'LBL_SAVE_CONTACT' => 'Save Contact',
  'LBL_YAHOO_ID' => 'Yahoo! ID:',
);


?>