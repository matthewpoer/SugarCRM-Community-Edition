<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => '�ڋq',
  'LBL_MODULE_TITLE' => '�ڋq: �z�[��',
  'LBL_SEARCH_FORM_TITLE' => '�ڋq����',
  'LBL_LIST_FORM_TITLE' => '�ڋq���X�g',
  'LBL_NEW_FORM_TITLE' => '�ڋq�쐬',
  'LBL_MEMBER_ORG_FORM_TITLE' => '�q���',
  'LBL_BUG_FORM_TITLE' => 'Accounts',
  'LBL_LIST_ACCOUNT_NAME' => '�ڋq��',
  'LBL_LIST_CITY' => '�s�撬��',
  'LBL_LIST_WEBSITE' => 'WEB�T�C�g',
  'LBL_LIST_STATE' => '�s���{��',
  'LBL_LIST_PHONE' => '�d�b',
  'LBL_LIST_EMAIL_ADDRESS' => '���[���A�h���X',
  'LBL_LIST_CONTACT_NAME' => '�S���Җ�',
  'db_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_website' => 'LBL_LIST_WEBSITE',
  'db_billing_address_city' => 'LBL_LIST_CITY',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'LBL_ACCOUNT_INFORMATION' => 'Account Information',
  'LBL_ACCOUNT' => '�ڋq:',
  'LBL_ACCOUNT_NAME' => '�ڋq��:',
//END DON'T CONVERT
  'LBL_PHONE' => '�d�b:',
  'LBL_PHONE_ALT' => 'Alternate Phone:',
  'LBL_WEBSITE' => 'WEB�T�C�g:',
  'LBL_FAX' => '�t�@�b�N�X:',
  'LBL_TICKER_SYMBOL' => '�،��R�[�h:',
  'LBL_OTHER_PHONE' => '���̑��d�b:',
  'LBL_ANY_PHONE' => '�d�b:',
  'LBL_MEMBER_OF' => '�e���:',
  'LBL_PHONE_OFFICE' => 'Phone Office:',
  'LBL_PHONE_FAX' => 'Phone Fax:',
  'LBL_EMAIL' => '���[��:',
  'LBL_EMPLOYEES' => '�]�ƈ�:',
  'LBL_OTHER_EMAIL_ADDRESS' => '���̑����[��:',
  'LBL_ANY_EMAIL' => '���[��:',
  'LBL_OWNERSHIP' => '���L��:',
  'LBL_RATING' => '�i�t:',
  'LBL_INDUSTRY' => '�ƊE:',
  'LBL_SIC_CODE' => '�ƊE�R�[�h:',
  'LBL_TYPE' => '�^�C�v:',
  'LBL_ANNUAL_REVENUE' => '�N�Ԕ���:',
  'LBL_ADDRESS_INFORMATION' => '�Z�����',
  'LBL_BILLING_ADDRESS' => '������Z��:',
  'LBL_BILLING_ADDRESS_STREET' => 'Billing Address Street:',
  'LBL_BILLING_ADDRESS_CITY' => 'Billing Address City:',
  'LBL_BILLING_ADDRESS_STATE' => 'Billing Address State:',
  'LBL_BILLING_ADDRESS_POSTALCODE' => 'Billing Address Postal Code:',
  'LBL_BILLING_ADDRESS_COUNTRY' => 'Billing Address Country:',
  'LBL_SHIPPING_ADDRESS_STREET' => 'Shipping Address Street:',
  'LBL_SHIPPING_ADDRESS_CITY' => 'Shipping Address City:',
  'LBL_SHIPPING_ADDRESS_STATE' => 'Shipping Address State:',
  'LBL_SHIPPING_ADDRESS_POSTALCODE' => 'Shipping Address Postal Code:',
  'LBL_SHIPPING_ADDRESS_COUNTRY' => 'Shipping Address Country:',
  'LBL_SHIPPING_ADDRESS' => '�o�א�Z��:',
  'LBL_DATE_MODIFIED' => 'Date Modified:',
  'LBL_DATE_ENTERED' => 'Date Entered:',
  'LBL_ANY_ADDRESS' => '�Z��:',
  'LBL_CITY' => '�s�撬��:',
  'LBL_STATE' => '�s���{��:',
  'LBL_POSTAL_CODE' => '�X�֔ԍ�:',
  'LBL_COUNTRY' => '��:',
  'LBL_DESCRIPTION_INFORMATION' => '�������',
  'LBL_DESCRIPTION' => '����:',
  'NTC_COPY_BILLING_ADDRESS' => 'Copy ������Z�� to �o�א�Z��',
  'NTC_COPY_SHIPPING_ADDRESS' => 'Copy �o�א�Z�� to ������Z��',
  'NTC_REMOVE_MEMBER_ORG_CONFIRMATION' => 'Are you sure you want to remove this record as a member organization?',
  'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Are you sure you want to remove this record?',
  'LBL_DUPLICATE' => 'Possible Duplicate Account',
  'MSG_SHOW_DUPLICATES' => 'Creating this contact may potentialy create a duplicate contact. You may either click on Create Account to continue creating this new account with the previously entered data or you may click Cancel.',
  'MSG_DUPLICATE' => 'Creating this account may potentialy create a duplicate account. You may either select an account from the list below or you may click on Create New Account to continue creating a new account with the previously entered data.',
  'LNK_NEW_ACCOUNT' => '�ڋq�쐬',
  'LNK_ACCOUNT_LIST' => 'Accounts',
  'LBL_INVITEE' => '�S����',
  'ERR_DELETE_RECORD' => 'A record number must be specified to delete the account.',
  'NTC_DELETE_CONFIRMATION' => 'Are you sure you want to delete this record?',
  'LBL_SAVE_ACCOUNT' => 'Save Account',
  'LNK_NEW_CONTACT' => '�S���ҍ쐬',
  'LNK_NEW_OPPORTUNITY' => '���k�쐬',
  'LNK_NEW_CASE' => '����쐬',
  'LNK_NEW_NOTE' => '�m�[�g�쐬',
  'LNK_NEW_CALL' => '�R�[���쐬',
  'LNK_NEW_EMAIL' => '���[���쐬',
  'LNK_NEW_MEETING' => '�~�[�e�B���O�쐬',
  'LNK_NEW_TASK' => '�^�X�N�쐬',
);


?>