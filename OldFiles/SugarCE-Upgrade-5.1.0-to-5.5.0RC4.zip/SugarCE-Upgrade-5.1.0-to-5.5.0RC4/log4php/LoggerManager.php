<?php 
/*
 * The original class has been deprecated and replaced with include/SugarLogger/LoggerManager.php
 * This classs exists only for instances that are upgrading from previous versions of sugar.
 */
 
?>
