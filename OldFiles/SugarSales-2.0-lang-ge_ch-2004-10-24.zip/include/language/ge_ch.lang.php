<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/include/language/en_us.lang.php,v 1.89 2004/10/25 02:32:20 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

//to translate, only modify the right value in each key/value pair
$app_list_strings = array (
//e.g. auf Deutsch 'Contacts'=>'Contakten',
  'moduleList' => 
  array (
    'Home' => 'Home',
    'Dashboard' => '�bersicht',
    'Contacts' => 'Kontakte',
    'Accounts' => 'Kunden',
    'Opportunities' => 'Auftr�ge',
    'Cases' => 'Anfragen',
    'Notes' => 'Notizen & Dateien',
    'Calls' => 'Telefonate',
    'Emails' => 'Emails',
    'Meetings' => 'Termine',
    'Tasks' => 'Aufgaben',
    'Calendar' => 'Calendar',
    'Leads' => 'Leads',
    'Activities' => 'Activities',
  ),
  'account_type_dom' => 
  array (
    '' => '',
    'Analyst' => 'Analyst',
    'Competitor' => 'Mitbewerber',
  //e.g. en fran�ais 'Analyst'=>'Analyste',
    'Customer' => 'Kunde',
    'Integrator' => 'Integrator',
    'Investor' => 'Investor',
    'Partner' => 'Partner',
    'Press' => 'Presse',
    'Prospect' => 'Zuk�nftiger Kunde',
    'Reseller' => 'Wiederverk�ufer',
    'Other' => 'Andere',
  ),
  'industry_dom' => 
  array (
    '' => '',
    'Apparel' => 'Bekleidungsindustrie',
    'Banking' => 'Banken',
  //e.g. en espa�ol 'Apparel'=>'Ropa',
    'Biotechnology' => 'Biotechnologie',
    'Chemicals' => 'Chemie',
    'Communications' => 'Kommunikation',
    'Construction' => 'Konstruktion',
    'Consulting' => 'Beratung',
    'Education' => 'Ausbildung',
    'Electronics' => 'Elektronik',
    'Energy' => 'Energie',
    'Engineering' => 'Entwicklung',
    'Entertainment' => 'Unterhaltung',
    'Environmental' => 'Umwelt',
    'Finance' => 'Finanzen',
    'Food & Beverage' => 'Nahrungs- und Genussmittel',
    'Government' => 'Beh�rde',
    'Healthcare' => 'Gesundheit',
    'Hospitality' => 'Spital',
    'Insurance' => 'Versicherung',
    'Machinery' => 'Maschinenbau',
    'Manufacturing' => 'Herstellung von Waren',
    'Media' => 'Medien',
    'Not For Profit' => 'Non Profit Organisation',
    'Recreation' => 'Unterhaltung',
    'Retail' => 'Einzelhandel',
    'Shipping' => 'Spedition',
    'Technology' => 'Technologie',
    'Telecommunications' => 'Telekommunikation',
    'Transportation' => 'Transport',
    'Utilities' => 'Werkzeuge',
    'Other' => 'Andere',
  ),
  'lead_source_dom' => 
  array (
    '' => '',
    'Cold Call' => 'Kalt Aquise',
    'Existing Customer' => 'Bestehender Kunde',
    'Self Generated' => 'Selbst generierter Kunde',
    'Employee' => 'Mitarbeiter',
    'Partner' => 'Partner',
    'Public Relations' => 'Werbung',
    'Direct Mail' => 'Mailing',
    'Conference' => 'Konferenz',
    'Trade Show' => 'Messe',
    'Web Site' => 'Web Seite',
    'Word of mouth' => 'Mund zu Mund Propaganda',
    'Other' => 'Andere',
  ),
  'opportunity_type_dom' => 
  array (
    '' => '',
    'Existing Business' => 'Bestehendes Business',
    'New Business' => 'Neues Business',
  ),
  'opportunity_relationship_type_default_key' => 'Primary Decision Maker',
  'opportunity_relationship_type_dom' => 
  array (
    '' => '',
    'Primary Decision Maker' => 'Prim�rer Entscheidungstr�ger',
//       it is the key for the default opportunity_relationship_type_dom value
    'Business Decision Maker' => 'Business Entscheidungstr�ger',
    'Business Evaluator' => 'Evaluierende Person Business',
    'Technical Decision Maker' => 'Technischer Entscheidungstr�ger',
    'Technical Evaluator' => 'Evaluierende Person Technik',
    'Executive Sponsor' => 'Executive Sponsor',
    'Influencer' => 'Einflussreiche Person',
    'Other' => 'Andere',
  ),
  'case_relationship_type_default_key' => 'Primary Contact',
  'case_relationship_type_dom' => 
  array (
    '' => '',
    'Primary Contact' => 'Prim�rer Kontakt',
//       it is the key for the default case_relationship_type_dom value
    'Alternate Contact' => 'Alternativer Kontakt',
  ),
  'sales_stage_dom' => 
  array (
    'Prospecting' => 'Prospect',
    'Qualification' => 'Qualifikation',
    'Needs Analysis' => 'Ben�tigt Analyse',
    'Value Proposition' => 'Richtpreis Offerte',
    'Id. Decision Makers' => 'Id. Entscheider',
    'Perception Analysis' => 'Untersuchung',
    'Proposal/Price Quote' => 'Offerte',
    'Negotiation/Review' => 'Verhandlung/�berarbeitung',
    'Closed Won' => 'Gewonnen',
    'Closed Lost' => 'Verloren',
  ),
  'activity_dom' => 
  array (
    'Call' => 'Call',
    'Meeting' => 'Meeting',
    'Task' => 'Task',
    'Email' => 'Email',
    'Note' => 'Note',
  ),
  'salutation_dom' => 
  array (
    '' => '',
    'Mr.' => 'Hr.',
    'Ms.' => 'Fr.',
    'Mrs.' => 'Frl.',
    'Dr.' => 'Dr.',
    'Prof.' => 'Prof.',
  ),
  'task_priority_dom' => 
  array (
    'High' => 'Hoch',
    'Medium' => 'Mittel',
    'Low' => 'Niedrig',
  ),
  'task_status_dom' => 
  array (
    'Not Started' => 'Nicht angefangen',
    'In Progress' => 'In Bearbeitung',
    'Completed' => 'Abgeschlossen',
    'Pending Input' => 'R�ckmeldung ausstehend',
    'Deferred' => 'Zur�ckgestellt',
  ),
  'meeting_status_dom' => 
  array (
    'Planned' => 'In Planung',
    'Held' => 'Durchgef�hrt',
    'Not Held' => 'Nicht durchgef�hrt',
  ),
  'call_status_dom' => 
  array (
    'Planned' => 'In Planung',
    'Held' => 'Durchgef�hrt',
    'Not Held' => 'Nicht durchgef�hrt',
  ),
  'call_direction_dom' => 
  array (
    'Inbound' => 'Inbound',
    'Outbound' => 'Outbound',
  ),
  'lead_status_dom' => 
  array (
    '' => '',
    'New' => 'New',
    'Assigned' => 'Assigned',
    'In Process' => 'In Process',
    'Converted' => 'Converted',
    'Recycled' => 'Recycled',
    'Dead' => 'Dead',
  ),
  'lead_status_noblank_dom' => 
  array (
    'New' => 'New',
    'Assigned' => 'Assigned',
    'In Process' => 'In Process',
    'Converted' => 'Converted',
    'Recycled' => 'Recycled',
    'Dead' => 'Dead',
  ),
  'case_status_default_key' => 'New',
  'case_status_dom' => 
  array (
    'New' => 'Neu',
    'Assigned' => 'Zugewiesen',
//       it is the key for the default case_status_dom value
    'Closed' => 'Geschlossen',
    'Pending Input' => 'R�ckmeldung ausstehend',
    'Rejected' => 'Abgelehnt',
  ),
  'case_priority_default_key' => 'P2',
  'case_priority_dom' => 
  array (
    'P1' => 'High',
    'P2' => 'Medium',
    'P3' => 'Low',
  ),
  'user_status_dom' => 
  array (
    'Active' => 'Aktiv',
    'Inactive' => 'Inaktiv',
  ),
  'record_type_default_key' => 'Accounts',
  'record_type_display' => 
  array (
    'Accounts' => 'Kunde',
    'Opportunities' => 'Auftrag',
//       it is the key for the default record_type_module value
    'Cases' => 'Bedarf',
    'Leads' => 'Lead',
  ),
  'notifymail_sendtype' => 
  array (
    'sendmail' => 'sendmail',
    'SMTP' => 'SMTP',
  ),
);

$app_strings = array (
  'LBL_CHARSET' => 'ISO-8859-1',
  'LBL_BROWSER_TITLE' => 'SugarCRM - Commercial Open Source CRM',
  'LBL_MY_ACCOUNT' => 'Mein Konto',
  'LBL_ADMIN' => 'Admin',
  'LBL_LOGOUT' => 'Abmelden',
  'LBL_SEARCH' => 'Suchen',
  'LBL_LAST_VIEWED' => 'Zuletzt angesehen',
  'NTC_WELCOME' => 'Wilkommen',
  'NTC_SUPPORT_SUGARCRM' => 'Unterst�tze das SugarCRM open source projekt mit einer Spende �ber PayPal - schnell, gratis und sicher!',
  'NTC_NO_ITEMS_DISPLAY' => 'Keine Eintr�ge vorhanden',
  'LBL_ALT_HOT_KEY' => 'Alt+',
  'LBL_SAVE_BUTTON_TITLE' => 'Speichern [Alt+S]',
  'LBL_EDIT_BUTTON_TITLE' => 'Bearbeiten [Alt+E]',
  'LBL_EDIT_BUTTON' => 'Bearbeiten',
  'LBL_DUPLICATE_BUTTON_TITLE' => 'Duplizieren [Alt+U]',
  'LBL_DUPLICATE_BUTTON' => 'Duplizieren',
  'LBL_DELETE_BUTTON_TITLE' => 'L�schen [Alt+D]',
  'LBL_DELETE_BUTTON' => 'L�schen',
  'LBL_NEW_BUTTON_TITLE' => 'Neu [Alt+N]',
  'LBL_CHANGE_BUTTON_TITLE' => '�ndern [Alt+G]',
  'LBL_CANCEL_BUTTON_TITLE' => 'Abbrechen [Alt+X]',
  'LBL_SEARCH_BUTTON_TITLE' => 'Suchen [Alt+Q]',
  'LBL_CLEAR_BUTTON_TITLE' => 'Leeren [Alt+C]',
  'LBL_SELECT_BUTTON_TITLE' => 'Ausw�hlen [Alt+T]',
  'LBL_SAVE_BUTTON_KEY' => 'S',
  'LBL_EDIT_BUTTON_KEY' => 'E',
  'LBL_DUPLICATE_BUTTON_KEY' => 'U',
  'LBL_DELETE_BUTTON_KEY' => 'D',
  'LBL_NEW_BUTTON_KEY' => 'N',
  'LBL_CHANGE_BUTTON_KEY' => 'G',
  'LBL_CANCEL_BUTTON_KEY' => 'X',
  'LBL_SEARCH_BUTTON_KEY' => 'Q',
  'LBL_CLEAR_BUTTON_KEY' => 'C',
  'LBL_SELECT_BUTTON_KEY' => 'T',
  'LBL_SAVE_BUTTON_LABEL' => 'Speichern',
  'LBL_EDIT_BUTTON_LABEL' => 'Bearbeiten',
  'LBL_DUPLICATE_BUTTON_LABEL' => 'Duplizieren',
  'LBL_DELETE_BUTTON_LABEL' => 'L�schen',
  'LBL_NEW_BUTTON_LABEL' => 'Neu',
  'LBL_CHANGE_BUTTON_LABEL' => '�ndern',
  'LBL_CANCEL_BUTTON_LABEL' => 'Abbrechen',
  'LBL_SEARCH_BUTTON_LABEL' => 'Suchen',
  'LBL_CLEAR_BUTTON_LABEL' => 'Leeren',
  'LBL_NEXT_BUTTON_LABEL' => 'Next',
  'LBL_SELECT_BUTTON_LABEL' => 'Ausw�hlen',
  'LBL_SELECT_CONTACT_BUTTON_TITLE' => 'Kontakt ausw�hlen [Alt+T]',
  'LBL_SELECT_CONTACT_BUTTON_KEY' => 'T',
  'LBL_VIEW_PDF_BUTTON_LABEL' => 'View PDF',
  'LBL_VIEW_PDF_CONTACT_BUTTON_TITLE' => 'View PDF [Alt+P]',
  'LBL_VIEW_PDF_CONTACT_BUTTON_KEY' => 'P',
  'LBL_SELECT_CONTACT_BUTTON_LABEL' => 'Kontakt ausw�hlen',
  'LBL_SELECT_USER_BUTTON_TITLE' => 'Benutzer ausw�hlen [Alt+U]',
  'LBL_SELECT_USER_BUTTON_KEY' => 'U',
  'LBL_SELECT_USER_BUTTON_LABEL' => 'Benutzer ausw�hlen',
  'LBL_CREATE_BUTTON_LABEL' => 'Create',
  'LBL_SHORTCUTS' => 'Shortcuts',
  'LBL_LIST_NAME' => 'Namen',
  'LBL_LIST_USER_NAME' => 'Benutzer Namen',
  'LBL_LIST_EMAIL' => 'Email',
  'LBL_LIST_PHONE' => 'Telefon',
  'LBL_LIST_CONTACT_NAME' => 'Kontakt Name',
  'LBL_LIST_CONTACT_ROLE' => 'Contact Role',
  'LBL_LIST_ACCOUNT_NAME' => 'Kunde',
  'LBL_USER_LIST' => 'Benutzer Liste',
  'LBL_CONTACT_LIST' => 'Kontakt Liste',
  'LBL_RELATED_RECORDS' => 'Related Records',
  'LBL_MASS_UPDATE' => 'Mass Update',
  'LNK_ADVANCED_SEARCH' => 'Erweiterte Suche',
  'LNK_BASIC_SEARCH' => 'Einfache Suche',
  'LNK_EDIT' => 'edit',
  'LNK_REMOVE' => 'rem',
  'LNK_DELETE' => 'del',
  'LNK_LIST_START' => 'Start',
  'LNK_LIST_NEXT' => 'Vor',
  'LNK_LIST_PREVIOUS' => 'Zur�ck',
  'LNK_LIST_END' => 'Ende',
  'LBL_LIST_OF' => 'von',
  'LBL_OR' => 'OR',
  'LNK_PRINT' => 'Drucken',
  'LNK_HELP' => 'Hilfe',
  'LNK_ABOUT' => 'Info',
  'NTC_REQUIRED' => 'Pflichtfeld',
  'LBL_REQUIRED_SYMBOL' => '*',
  'LBL_CURRENCY_SYMBOL' => 'CHF ',
  'LBL_PERCENTAGE_SYMBOL' => '%',
  'LBL_THOUSANDS_SYMBOL' => 'K',
  'NTC_DATE_FORMAT' => '(yyyy-mm-dd)',
  'NTC_TIME_FORMAT' => '(24:00)',
  'NTC_DATE_TIME_FORMAT' => '(yyyy-mm-dd 24:00)',
  'NTC_DELETE_CONFIRMATION' => 'Wollen Sie diesen Eintrag wirklich l�schen?',
  'ERR_DELETE_RECORD' => 'Die Nummer eines Eintrages muss angegeben werde um einen Kontakt zu l�schen!',
  'ERR_CREATING_TABLE' => 'Fehler beim anlegen der Tabelle: ',
  'ERR_CREATING_FIELDS' => 'Fehler beim ausf�llen von zus�tzlichen Detail Feldern: ',
  'ERR_MISSING_REQUIRED_FIELDS' => 'Es wurden nicht alle Pflichtfelder ausgef�llt:',
  'ERR_INVALID_EMAIL_ADDRESS' => 'Keine g�ltige E-Mail Adresse.',
  'ERR_INVALID_DATE_FORMAT' => 'Das Datum muss in folgendem Format eingegeben werden: yyyy-dd-mm',
  'ERR_INVALID_MONTH' => 'Bitte einen g�ltigen Monat eingeben.',
  'ERR_INVALID_DAY' => 'Bitte einen g�ltigen Tag eingeben.',
  'ERR_INVALID_YEAR' => 'Bitte eine g�ltige Jahreszahl mit 4 Ziffern eingeben.',
  'ERR_INVALID_DATE' => 'Bitte ein g�ltiges Datum eingeben.',
  'ERR_INVALID_HOUR' => 'Bitte in der Uhrzeit eine g�ltige Stundenbezeichnung eingeben.',
  'ERR_INVALID_TIME' => 'Bitte eine g�ltige Uhrzeit eingeben.',
  'ERR_INVALID_AMOUNT' => 'Please enter a valid amount.',
  'NTC_CLICK_BACK' => 'Bitte den zur�ck Button des Browsers anklicken und den Fehler beheben.',
  'LBL_LIST_ASSIGNED_USER' => 'Zugewiesen zu',
  'LBL_ASSIGNED_TO' => 'Zugewiesen zu:',
  'LBL_DATE_MODIFIED' => 'Letzte �nderung:',
  'LBL_DATE_ENTERED' => 'Erstellt:',
  'LBL_CURRENT_USER_FILTER' => 'Zeige nur Eintr�ge welche mir zugewiesen sind:',
  'NTC_LOGIN_MESSAGE' => 'Loggen Sie sich in die Anwendung ein.',
  'LBL_NONE' => '--Keine--',
  'LBL_BACK' => 'Zur�ck',
  'LBL_IMPORT' => 'Importiere',
  'LBL_EXPORT' => 'Exportiere',
  'LBL_EXPORT_ALL' => 'Exportiere alle',
  'LBL_SAVE_NEW_BUTTON_TITLE' => 'Save & Create New [Alt+V]',
  'LBL_SAVE_NEW_BUTTON_KEY' => 'V',
  'LBL_SAVE_NEW_BUTTON_LABEL' => 'Save & Create New',
  'LBL_NAME' => 'Name',
  'LBL_SUBJECT' => 'Subject',
);


?>