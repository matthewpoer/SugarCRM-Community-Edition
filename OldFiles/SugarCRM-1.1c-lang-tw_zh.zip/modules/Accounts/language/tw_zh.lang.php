<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Accounts/language/en_us.lang.php,v 1.7 2004/08/04 17:48:19 sugarjacob Exp $
 * Description:  Defines the English language pack 
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_MODULE_NAME'=>'公司',
'LBL_MODULE_TITLE'=>'公司: 首頁',
'LBL_SEARCH_FORM_TITLE'=>'搜尋公司',
'LBL_LIST_FORM_TITLE'=>'公司列表',
'LBL_NEW_FORM_TITLE'=>'新增公司',
'LBL_MEMBER_ORG_FORM_TITLE'=>'成員單位',

'LBL_LIST_ACCOUNT_NAME'=>'公司名稱',
'LBL_LIST_CITY'=>'城市',
'LBL_LIST_WEBSITE'=>'網站',
'LBL_LIST_STATE'=>'省份',
'LBL_LIST_PHONE'=>'電話',

'LBL_ACCOUNT'=>'公司：',
'LBL_ACCOUNT_NAME'=>'公司名稱：',
'LBL_PHONE'=>'電話：',
'LBL_WEBSITE'=>'網站：',
'LBL_FAX'=>'傳真：',
'LBL_TICKER_SYMBOL'=>'傳票符號：',
'LBL_OTHER_PHONE'=>'其它電話：',
'LBL_ANY_PHONE'=>'任意電話：',
'LBL_MEMBER_OF'=>'成員：',
'LBL_EMAIL'=>'電子郵件：',
'LBL_EMPLOYEES'=>'員工：',
'LBL_OTHER_EMAIL_ADDRESS'=>'其它電子郵件：',
'LBL_ANY_EMAIL'=>'任意電子郵件：',
'LBL_OWNERSHIP'=>'所有者：',
'LBL_RATING'=>'評價：',
'LBL_INDUSTRY'=>'行業：',
'LBL_SIC_CODE'=>'SIC 編碼：',
'LBL_TYPE'=>'類型：',
'LBL_ANNUAL_REVENUE'=>'年收益：',
'LBL_ADDRESS_INFORMATION'=>'地址資訊',
'LBL_BILLING_ADDRESS'=>'開票地址：',
'LBL_SHIPPING_ADDRESS'=>'發貨地址：',
'LBL_ANY_ADDRESS'=>'任意地址：',
'LBL_CITY'=>'城市：',
'LBL_STATE'=>'省份：',
'LBL_POSTAL_CODE'=>'郵遞區號：',
'LBL_COUNTRY'=>'國家：',
'LBL_DESCRIPTION_INFORMATION'=>'描述資訊',
'LBL_DESCRIPTION'=>'描述：',
'NTC_COPY_BILLING_ADDRESS'=>'將開票地址複製到發貨地址',
'NTC_COPY_SHIPPING_ADDRESS'=>'將發貨地址複製到開票地址',
'NTC_REMOVE_MEMBER_ORG_CONFIRMATION'=>'你確定要刪除這個記錄嗎？',

'LNK_NEW_CONTACT'=>'新增聯絡人',
'LNK_NEW_ACCOUNT'=>'新增公司',
'LNK_NEW_OPPORTUNITY'=>'新增機會',
'LNK_NEW_CASE'=>'新增事件',
'LNK_NEW_NOTE'=>'新增備註',
'LNK_NEW_CALL'=>'新增電話記錄',
'LNK_NEW_EMAIL'=>'新增電子郵件',
'LNK_NEW_MEETING'=>'新增會議',
'LNK_NEW_TASK'=>'新增任務',
'ERR_DELETE_RECORD'=>"必須指定記錄編號才能刪除公司.",


);

?>