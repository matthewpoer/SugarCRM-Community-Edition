<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/**
 * SubPanelTiles
 *
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */
// $Id: SubPanelTiles.php,v 1.45.4.1 2006/04/14 23:39:44 majed Exp $

require_once('include/SubPanel/SubPanel.php');
require_once('include/SubPanel/SubPanelDefinitions.php');

class SubPanelTiles
{
	var $id;
	var $module;
	var $focus;
	var $start_on_field;
	var $layout_manager;
	var $layout_def_key;
	var $show_tabs = false;

	var $subpanel_definitions;
	
	var $hidden_tabs=array(); //consumer of this class can array of tabs that should be hidden. the tab name
							//should be the array.
	
	function SubPanelTiles(&$focus, $layout_def_key='', $layout_def_override = '')
	{
		$this->focus = $focus;
		$this->id = $focus->id;
		$this->module = $focus->module_dir;
		$this->layout_def_key = $layout_def_key;
		$this->subpanel_definitions=new SubPanelDefinitions($focus, $layout_def_key, $layout_def_override);
	}

	function display()
	{
		global $layout_edit_mode, $sugar_version, $sugar_config;
		if(isset($layout_edit_mode) && $layout_edit_mode){
			return;	
		}

		global $modListHeader;
		
		ob_start();

	echo '<script type="text/javascript" src="include/javascript/popup_parent_helper.js?s=' . $sugar_version . '&c=' . $sugar_config['js_custom_version'] . '"></script>';
	echo '<script type="text/javascript" src="include/SubPanel/SubPanelTiles.js?s=' . $sugar_version . '&c=' . $sugar_config['js_custom_version'] . '"></script>';
?>
<script>
if(document.DetailView != null && 
   document.DetailView.elements != null && 
   document.DetailView.elements.layout_def_key != null && 
   typeof document.DetailView.elements['layout_def_key'] != 'undefined'){
	document.DetailView.elements['layout_def_key'].value = '<?php echo $this->layout_def_key; ?>';
}
</script>
<?php 
		
		$tabs = array();
		$default_div_display = 'inline';
		if(!empty($sugar_config['hide_subpanels_on_login'])){
			if(!isset($_SESSION['visited_details'][$this->focus->module_dir])){
				setcookie($this->focus->module_dir . '_divs', '');
				unset($_COOKIE[$this->focus->module_dir . '_divs']);
				$_SESSION['visited_details'][$this->focus->module_dir] = true;
				
			}
			$default_div_display = 'none';
		}
		$div_cookies = get_sub_cookies($this->focus->module_dir . '_divs');
		
		
		//Display the group header. this section is executed only if the tabbed interface is being used.
		$current_key = '';
		if (! empty($this->show_tabs))
		{
			require_once('include/tabs.php');
    		$tab_panel = new SugarWidgetTabs($tabs, $current_key, 'showSubPanel');
			echo get_form_header('Related', '', false);
			echo "<br />" . $tab_panel->display();
		}
		
		//get all the tabs
		$tabs=$this->subpanel_definitions->get_available_tabs();//_ppd($tabs);
		foreach ($tabs as $key=>$tab) 
		{	 
			
			//load meta definition of the sub-panel.
			$thisPanel=$this->subpanel_definitions->load_subpanel($tab);
			
			$display= 'none';
			$div_display = $default_div_display;
			$cookie_name =   $tab . '_v';
			
			if(isset($div_cookies[$cookie_name])){
				$div_display = 	$div_cookies[$cookie_name];	
			}
			if(!empty($sugar_config['hide_subpanels'])){
				$div_display = 'none';
			}
			if($div_display == 'none'){
				$opp_display  = 'inline';
			}else{
				$opp_display  = 'none';
			}
			
			if (empty($this->show_tabs))
			{
				global $theme;
				$theme_path = "themes/" . $theme . "/";
				$image_path = $theme_path . "images/";
				$show_icon_html = get_image($image_path . 'advanced_search', 'alt="' . translate('LBL_SHOW') . '" border="0"');
				$hide_icon_html = get_image($image_path . 'basic_search', 'alt="' . translate('LBL_HIDE') . '" border="0"');
				$max_min = "<div align='right'>";
 		 		$max_min .= "<span id=\"show_link_".$tab."\" style=\"display: $opp_display\"><a href='#' class='utilsLink' onclick=\"current_child_field = '".$tab."';showSubPanel('".$tab."');document.getElementById('show_link_".$tab."').style.display='none';document.getElementById('hide_link_".$tab."').style.display='';return false;\">"
 		 			. translate('LBL_SHOW') . "&nbsp;" . $show_icon_html . "</a></span>";
				$max_min .= "<span id=\"hide_link_".$tab."\" style=\"display: $div_display\"><a href='#' class='utilsLink' onclick=\"hideSubPanel('".$tab."');document.getElementById('hide_link_".$tab."').style.display='none';document.getElementById('show_link_".$tab."').style.display='';return false;\">"
					. translate('LBL_HIDE') . "&nbsp;" . $hide_icon_html . "</a></span>";
				$max_min .= "</div>";
				echo "<a name=\"$tab\"> </a>";
				echo get_form_header( $thisPanel->get_title(), $max_min, false);
			}
 	
?>
<div cookie_name="<?php echo $cookie_name; ?>" id="subpanel_<?php echo $tab; ?>" style="display:<?php echo $div_display;?>">
<script>document.getElementById("subpanel_<?php echo $tab; ?>" ).cookie_name="<?php echo $cookie_name; ?>";</script>
<?php 

if($div_display != 'none'){
	echo "<script>markSubPanelLoaded('$tab');</script>";
	$old_contents = ob_get_contents();
	@ob_end_clean();
	
	ob_start();
	include_once('include/SubPanel/SubPanel.php');
	$subpanel_object = new SubPanel($this->module, $_REQUEST['record'], $tab,$thisPanel);
	$subpanel_object->setTemplateFile('include/SubPanel/SubPanelDynamic.html');
	$subpanel_object->display();
	$subpanel_data = ob_get_contents();
	@ob_end_clean();
	
	ob_start();
	echo $this->get_buttons($thisPanel,$subpanel_object->subpanel_query); 
	$buttons = ob_get_contents();
	@ob_end_clean();

	ob_start();
	echo $old_contents;
	echo $buttons;
}
?>
<div id="list_subpanel_<?php echo $tab; ?>"><?php if($div_display != 'none'){echo $subpanel_data; }?></div>

</div>

<?php } ?>

</body>

<?php
		$ob_contents = ob_get_contents();
		ob_end_clean();
		return $ob_contents;
	}


	function getLayoutManager()
	{
		require_once('include/generic/LayoutManager.php');
	  	if ( $this->layout_manager == null) {
	    	$this->layout_manager = new LayoutManager();
	  	}
	  	return $this->layout_manager;
	}

	function get_buttons($thisPanel,$panel_query=null)
	{
		$subpanel_def = $thisPanel->get_buttons();
		$layout_manager = $this->getLayoutManager();
		$widget_contents = '<table cellpadding="0" cellspacing="0"><tr>';
		foreach($subpanel_def as $widget_data)
		{
			$widget_data['query']=urlencode($panel_query);
			$widget_data['action'] = $_REQUEST['action'];
			$widget_data['module'] =  $thisPanel->get_inst_prop_value('module');
			$widget_data['focus'] = $this->focus;
			$widget_data['subpanel_definition'] = $thisPanel;
			$widget_contents .= '<td style="padding-right: 2px; padding-bottom: 2px;">' . "\n";

			if(empty($widget_data['widget_class']))
			{
				$widget_contents .= "widget_class not defined for top subpanel buttons";
			}
			else
			{
				$widget_contents .= $layout_manager->widgetDisplay($widget_data);
			}
			
			$widget_contents .= '</td>';
		}
		
		$widget_contents .= '</tr></table>';
		return $widget_contents;
	}
}
?>
