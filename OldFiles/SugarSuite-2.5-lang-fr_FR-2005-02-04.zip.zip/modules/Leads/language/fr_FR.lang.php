<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.4 2005/02/04 23:56:38 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Prospects',
  'LBL_INVITEE' => 'Subalternes',
  'LBL_MODULE_TITLE' => 'Prospects: accueil',
  'LBL_SEARCH_FORM_TITLE' => 'Prospect recherche',
  'LBL_LIST_FORM_TITLE' => 'Prospect liste',
  'LBL_NEW_FORM_TITLE' => 'Nouveau prospect',
  'LBL_CONTACT_OPP_FORM_TITLE' => 'Prospect-Opportunit�:',
  'LBL_CONTACT' => 'Prospect:',
  'LBL_BUSINESSCARD' => 'Convertir prospect',
  'LBL_LIST_NAME' => 'Nom',
  'LBL_LIST_LAST_NAME' => 'Pr�nom',
  'LBL_LIST_CONTACT_NAME' => 'Nom du prospect',
  'LBL_LIST_TITLE' => 'Titre',
  'LBL_LIST_ACCOUNT_NAME' => 'Nom du compte',
  'LBL_LIST_EMAIL_ADDRESS' => 'Em�l',
  'LBL_LIST_PHONE' => 'T�l�phone',
  'LBL_LIST_CONTACT_ROLE' => 'R�le',
  'LBL_LIST_FIRST_NAME' => 'Pr�nom',
  'LBL_LIST_REFERED_BY' => 'R�f�renc� par',
  'LBL_LIST_LEAD_SOURCE' => 'Source du prospect',
  'LBL_LIST_STATUS' => 'Statut',
  'LBL_LIST_DATE_ENTERED' => 'Date de cr�ation',
  'LBL_LIST_LEAD_SOURCE_DESCRIPTION' => 'Description de la source du prospect',
  'LBL_LIST_MY_LEADS' => 'Mes prospects',
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_account_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_email2' => 'LBL_LIST_EMAIL_ADDRESS',
  'LBL_EXISTING_CONTACT' => 'Utiliser un contact existant',
  'LBL_CREATED_CONTACT' => 'Cr�er un contact',
  'LBL_EXISTING_OPPORTUNITY' => 'Utiliser une opportunit� existante',
  'LBL_CREATED_OPPORTUNITY' => 'Cr�er une opportunit�',
//END DON'T CONVERT
  'LBL_EXISTING_ACCOUNT' => 'Utiliser un compte existant',
  'LBL_CREATED_ACCOUNT' => 'Cr�er un compte',
  'LBL_CREATED_CALL' => 'Cr�er un appel',
  'LBL_CREATED_MEETING' => 'Cr�er une r�union',
  'LBL_BACKTOLEADS' => 'Retour au prospect',
  'LBL_CONVERTLEAD' => 'Convertir un prospect',
  'LBL_NAME' => 'nom:',
  'LBL_CONTACT_NAME' => 'Nom du prospect:',
  'LBL_CONTACT_INFORMATION' => 'Information sur le prospect',
  'LBL_FIRST_NAME' => 'Pr�nom:',
  'LBL_OFFICE_PHONE' => 'T�l�phone (travail):',
  'LBL_ACCOUNT_NAME' => 'Nom du compte:',
  'LBL_OPPORTUNITY_NAME' => 'Nom d\'Opportunit�:',
  'LBL_OPPORTUNITY_AMOUNT' => 'Montant de l\'opportunit�:',
  'LBL_ANY_PHONE' => 'T�l�phone (autre):',
  'LBL_PHONE' => 'T�l�phone:',
  'LBL_LAST_NAME' => 'Nom:',
  'LBL_MOBILE_PHONE' => 'Mobile:',
  'LBL_HOME_PHONE' => 'maison:',
  'LBL_LEAD_SOURCE' => 'Source du prospect:',
  'LBL_STATUS' => 'Statut:',
  'LBL_LEAD_SOURCE_DESCRIPTION' => 'Description de la source du prospect:',
  'LBL_STATUS_DESCRIPTION' => 'Description du statut:',
  'LBL_OTHER_PHONE' => 'T�l�phone (autre):',
  'LBL_FAX_PHONE' => 'Fax:',
  'LBL_TITLE' => 'Titre:',
  'LBL_DEPARTMENT' => 'D�partment:',
  'LBL_EMAIL_ADDRESS' => 'Em�l:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Autre Em�l:',
  'LBL_ANY_EMAIL' => 'Autre Em�l:',
  'LBL_REPORTS_TO' => 'Rapporte �:',
  'LBL_DO_NOT_CALL' => 'Ne pas appeler:',
  'LBL_EMAIL_OPT_OUT' => 'Ne pas prospecter par m�l:',
  'LBL_PRIMARY_ADDRESS' => 'Adresse principale:',
  'LBL_ALTERNATE_ADDRESS' => 'Autre adresse:',
  'LBL_ANY_ADDRESS' => 'Autre adresse:',
  'LBL_REFERED_BY' => 'R�f�renc� par:',
  'LBL_CITY' => 'Ville:',
  'LBL_STATE' => 'Etat:',
  'LBL_POSTAL_CODE' => 'Code postal:',
  'LBL_COUNTRY' => 'Pays:',
  'LBL_DESCRIPTION_INFORMATION' => 'Information description',
  'LBL_ADDRESS_INFORMATION' => 'Information adresse',
  'LBL_DESCRIPTION' => 'Description:',
  'LBL_CONTACT_ROLE' => 'R�le:',
  'LBL_OPP_NAME' => 'Nom d\'opportunit�:',
  'LBL_IMPORT_VCARD' => 'Importer E-carte de visite',
  'LNK_IMPORT_VCARD' => 'Importer E-carte de visite',
  'LBL_IMPORT_VCARDTEXT' => 'Cr�er automatiquement un prospect par import d\'E-carte de visite.',
  'LBL_DUPLICATE' => 'Prospects similaire',
  'MSG_DUPLICATE' => 'Des prospects similaires ont �t� trouv�s. Merci de cocher les prospects que vous voulez associer avec l\'enregistrement qui sera cr�� � partir de cette conversion. Cliquer sur suivant lorsque vous aurez termin�',
  'LBL_ADD_BUSINESSCARD' => 'Ajouter une carte de visite',
  'LNK_NEW_APPOINTMENT' => 'Cr�er un rendez-vous',
  'LNK_NEW_LEAD' => 'Nouveau Prospect',
  'LNK_LEAD_LIST' => 'Prospects',
  'NTC_DELETE_CONFIRMATION' => 'Etes-vous sur de vouloir supprimer cet enregistrement?',
  'NTC_REMOVE_CONFIRMATION' => 'Etes-vous sur de vouloir supprimer ce prospect de ce ticket?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Etes-vous sur de vouloir supprimer ce report direct?',
  'ERR_DELETE_RECORD' => 'Un num�ro d\'enregistrement doit �tre fourni pour supprimer un prospect.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Copier l\'adresse principale vers l\'adresse secondaire',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Copier l\'adresse secondaire vers l\'adresse principale',
  'LNK_NEW_CONTACT' => 'Cr�er un contact',
  'LNK_NEW_NOTE' => 'Cr�er une note',
  'LNK_NEW_ACCOUNT' => 'Cr�er un compte',
  'LNK_NEW_OPPORTUNITY' => 'Cr�er une opportunit�',
  'LNK_SELECT_ACCOUNT' => 'S�lectionner un compte',
  'LBL_SALUTATION' => 'Salutation',
  'NTC_OPPORTUNITY_REQUIRES_ACCOUNT' => 'Cr�er une opportunit� n�cessite d\'avoir un compte.\\n Merci de cr�er un compte ou de s�lectionner un compte existant.',
);


?>