<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.4 2005/02/04 23:56:38 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Administration',
  'LBL_MODULE_TITLE' => 'Administration: Accueil',
  'LBL_NEW_FORM_TITLE' => 'Nouveau Compte',
  'LNK_NEW_USER' => 'Cr�er un utilisateur',
  'ERR_DELETE_RECORD' => 'Un num�ro d\'enregistrement doit �tre sp�cifi� pour supprimer ce compte.',
  'LBL_CONFIGURE_SETTINGS_TITLE' => 'Configurer le param�trage',
  'LBL_CONFIGURE_SETTINGS' => 'Configurer le param�trage',
  'LBL_UPGRADE_TITLE' => 'Mise � jour',
  'LBL_UPGRADE' => 'Mettre � jour Sugar Sales',
  'LBL_MANAGE_USERS_TITLE' => 'Gestion des utilisateurs',
  'LBL_MANAGE_USERS' => 'Gestion des comptes utilisateurs et des mots de passe',
  'LBL_ADMINISTRATION_HOME_TITLE' => 'Administration syst�me',
  'LBL_NOTIFY_TITLE' => 'Options de Notification Em�l',
  'LBL_NOTIFY_FROMADDRESS' => '"De" Adresse:',
  'LBL_MAIL_SMTPSERVER' => 'Serveur SMTP:',
  'LBL_MAIL_SMTPPORT' => 'Port SMTP:',
  'LBL_MAIL_SENDTYPE' => 'Agent de transfert d\'Em�l:',
  'LBL_MAIL_SMTPUSER' => 'Utilisateur SMTP:',
  'LBL_MAIL_SMTPPASS' => 'Mot de passe SMTP:',
  'LBL_MAIL_SMTPAUTH_REQ' => 'Utiliser l\'authentification SMTP?',
  'LBL_NOTIFY_SEND_BY_DEFAULT' => 'Envoyer les notifications par d�faut?',
  'LBL_NOTIFY_SUBJECT' => 'suject de l\'Em�l :',
  'LBL_NOTIFY_ON' => 'Notifications activ�?',
  'LBL_NOTIFY_FROMNAME' => '"De" Nom:',
  'LBL_CURRENCY' => 'Param�trage des devises et des taux de devises',
  'LBL_RELEASE' => 'Gestion des versions et de leur num�ros',
  'LBL_LAYOUT' => 'Ajoute, supprime, modifie les champs et l\'affichage des �crans et panneaux de l\'application',
  'LBL_MANAGE_CURRENCIES' => 'Devises',
  'LBL_MANAGE_RELEASES' => 'Versions',
  'LBL_MANAGE_LAYOUT' => 'Affichage des champs',
  'LBL_MANAGE_OPPORTUNITIES' => 'Opportunit�s',
  'LBL_UPGRADE_CURRENCY' => 'Mise � jour du montant de devise',
  'LBL_BACKUP' => 'Sauvegarde',
  'DESC_BACKUP' => 'Sauvegardez votre application Sugar et sa base de donn�es',
  'LBL_CUSTOMIZE_FIELDS' => 'Personnaliser les champs',
  'DESC_CUSTOMIZE_FIELDS' => 'Personnaliser les champs dans tous les langages disponibles',
  'LBL_DROPDOWN_EDITOR' => 'Editeur de liste d�roulante',
  'DESC_DROPDOWN_EDITOR' => 'Ajoute, supprime ou modifie les listes d�roulantes de l\'application',
  'LBL_IFRAME' => 'Portail',
  'DESC_IFRAME' => 'Ajoute des panneaux qui peuvent afficher n\'importe quel site web',
  'LBL_BUG_TITLE' => 'Suivi d\'incidents',
  'LBL_TIMEZONE' => 'Fuseau horaire',
  'LBL_STUDIO_TITLE' => 'Studio',
  'LBL_CONFIGURE_TABS' => 'Configure les onglets',
  'LBL_CHOOSE_WHICH' => 'Choisir quels onglets sont syst�matiquement affich�s',
  'LBL_DISPLAY_TABS' => 'Afficher les onglets',
  'LBL_HIDE_TABS' => 'Cacher les onglets',
  'LBL_EDIT_TABS' => 'Editer les onglets',
  'LBL_UPGRADE_DB_TITLE' => 'Mise � jour base de donn�es',
  'LBL_UPGRADE_DB' => 'Met � jour la base de donn�es de la version 2.0.x vers 2.5 ',
  'LBL_UPGRADE_DB_BEGIN' => 'D�but de mise � jour',
  'LBL_UPGRADE_DB_COMPLETE' => 'Mise � jour termin�e',
  'LBL_UPGRADE_DB_FAIL' => 'La mise � jour � �chou�e',
);


?>