<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.4 2005/02/04 23:56:38 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Em�ls',
  'LBL_MODULE_TITLE' => 'Em�ls: Accueil',
  'LBL_SEARCH_FORM_TITLE' => 'Recherche Em�l',
  'LBL_LIST_FORM_TITLE' => 'Liste des Em�ls',
  'LBL_NEW_FORM_TITLE' => 'Suivi Em�l',
  'LBL_LIST_SUBJECT' => 'Sujet',
  'LBL_LIST_CONTACT' => 'Contact',
  'LBL_LIST_RELATED_TO' => 'Relatif �',
  'LBL_LIST_DATE' => 'Date d\'envoi',
  'LBL_LIST_TIME' => 'Heure d\'envoi',
  'ERR_DELETE_RECORD' => 'Un num�ro d\'enregistrement doit �tre sp�cifi� pour supprimer ce compte.',
  'LBL_DATE_SENT' => 'Date d\'envoi:',
  'LBL_SUBJECT' => 'Sujet:',
  'LBL_BODY' => 'Corps du message:',
  'LBL_DATE_AND_TIME' => 'Date & heure d\'envoi:',
  'LBL_DATE' => 'Date d\'envoi:',
  'LBL_TIME' => 'Heure d\'envoi:',
  'LBL_CONTACT_NAME' => ' Nom du Contact: ',
  'LBL_EMAIL' => 'Em�l:',
  'LBL_COLON' => ':',
  'NTC_REMOVE_INVITEE' => 'Etes vous sur de vouloir supprimer ce destinataire pour ce m�l?',
  'LBL_INVITEE' => 'Destinataire',
  'LNK_NEW_CALL' => 'Nouvel Appel',
  'LNK_NEW_MEETING' => 'Nouveau Rendez-vous',
  'LNK_NEW_TASK' => 'Nouvelle T�che',
  'LNK_NEW_NOTE' => 'Nouvelle Note',
  'LNK_NEW_EMAIL' => 'Archiver un m�l',
  'LNK_CALL_LIST' => 'Appels',
  'LNK_MEETING_LIST' => 'R�unions',
  'LNK_TASK_LIST' => 'T�ches',
  'LNK_NOTE_LIST' => 'Notes',
  'LNK_EMAIL_LIST' => 'Em�ls',
  'LNK_VIEW_CALENDAR' => 'Aujourd\'hui',
  'LBL_Em�l' => 'Em�l:',
  'LNK_NEW_Em�l' => 'Nouvel Em�l',
  'LNK_Em�l_LIST' => 'Em�ls',
  'LNK_NEW_CONTACT' => 'Nouveau Contact',
  'LNK_NEW_ACCOUNT' => 'Nouveau Compte',
  'LNK_NEW_OPPORTUNITY' => 'Nouvelle Affaire',
  'LNK_NEW_CASE' => 'Nouveau Ticket',
);


?>