<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.4 2005/02/04 23:56:38 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Comptes',
  'LBL_MODULE_TITLE' => 'Comptes: accueil',
  'LBL_SEARCH_FORM_TITLE' => 'Recherche de compte',
  'LBL_LIST_FORM_TITLE' => 'Liste des comptes',
  'LBL_NEW_FORM_TITLE' => 'Nouveau compte',
  'LBL_MEMBER_ORG_FORM_TITLE' => 'Membre des Organisations',
  'LBL_BUG_FORM_TITLE' => 'comptes',
  'LBL_LIST_ACCOUNT_NAME' => 'Nom du compte',
  'LBL_LIST_CITY' => 'Ville',
  'LBL_LIST_WEBSITE' => 'Site web',
  'LBL_LIST_STATE' => 'Etat',
  'LBL_LIST_PHONE' => 'T�l�phone',
  'LBL_LIST_EMAIL_ADDRESS' => 'Adresse Em�l',
  'LBL_LIST_CONTACT_NAME' => 'Nom du Contact',
  'db_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_website' => 'LBL_LIST_WEBSITE',
  'db_billing_address_city' => 'LBL_LIST_CITY',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'LBL_ACCOUNT_INFORMATION' => 'Compte information',
  'LBL_ACCOUNT' => 'Compte:',
  'LBL_ACCOUNT_NAME' => 'Nom du compte:',
//END DON'T CONVERT
  'LBL_PHONE' => 'T�l�phone:',
  'LBL_PHONE_ALT' => 'T�l�phone (autre):',
  'LBL_WEBSITE' => 'Site web:',
  'LBL_FAX' => 'Fax:',
  'LBL_TICKER_SYMBOL' => 'Symbole:',
  'LBL_OTHER_PHONE' => 'Autres t�l�phones:',
  'LBL_ANY_PHONE' => 'T�l�phone (autre):',
  'LBL_MEMBER_OF' => 'Membre de:',
  'LBL_PHONE_OFFICE' => 'T�l�phone bureau:',
  'LBL_PHONE_FAX' => 'T�l�phone fax:',
  'LBL_EMAIL' => 'Em�l:',
  'LBL_EMPLOYEES' => 'Employ�s:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Autre Em�l:',
  'LBL_ANY_EMAIL' => 'Em�l alternatif:',
  'LBL_OWNERSHIP' => 'Propri�taire:',
  'LBL_RATING' => 'Note:',
  'LBL_INDUSTRY' => 'Activit�:',
  'LBL_SIC_CODE' => 'code NAF:',
  'LBL_TYPE' => 'Type:',
  'LBL_ANNUAL_REVENUE' => 'CA:',
  'LBL_ADDRESS_INFORMATION' => 'Adresse',
  'LBL_BILLING_ADDRESS' => 'Adresse de facturation:',
  'LBL_BILLING_ADDRESS_STREET' => 'Adresse de facturation rue:',
  'LBL_BILLING_ADDRESS_CITY' => 'Adresse de facturation ville:',
  'LBL_BILLING_ADDRESS_STATE' => 'Adresse de facturation �tat:',
  'LBL_BILLING_ADDRESS_POSTALCODE' => 'Adresse de facturation code postal:',
  'LBL_BILLING_ADDRESS_COUNTRY' => 'Adresse de facturation pays:',
  'LBL_SHIPPING_ADDRESS_STREET' => 'Adresse de livraison rue:',
  'LBL_SHIPPING_ADDRESS_CITY' => 'Adresse de livraison ville:',
  'LBL_SHIPPING_ADDRESS_STATE' => 'Adresse de livraison �tat:',
  'LBL_SHIPPING_ADDRESS_POSTALCODE' => 'Adresse de livraison code postal:',
  'LBL_SHIPPING_ADDRESS_COUNTRY' => 'Adresse de livraison pays:',
  'LBL_SHIPPING_ADDRESS' => 'Adresse de livraison:',
  'LBL_DATE_MODIFIED' => 'Date de modification:',
  'LBL_DATE_ENTERED' => 'Date de saisie:',
  'LBL_ANY_ADDRESS' => 'Autre adresse:',
  'LBL_CITY' => 'Ville:',
  'LBL_STATE' => 'Etat:',
  'LBL_POSTAL_CODE' => 'Code postal:',
  'LBL_COUNTRY' => 'Pays:',
  'LBL_DESCRIPTION_INFORMATION' => 'Description',
  'LBL_DESCRIPTION' => 'Description:',
  'NTC_COPY_BILLING_ADDRESS' => 'Copier adresse de facturation sur adresse de livraison',
  'NTC_COPY_SHIPPING_ADDRESS' => 'Copier adresse de livraison sur adresse de facturation',
  'NTC_REMOVE_MEMBER_ORG_CONFIRMATION' => 'Etes vous sur de vouloir supprimer ces informations ?',
  'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Etes vous sur de vouloir supprimer  cet enregistrement?',
  'LBL_DUPLICATE' => 'Compte en double?',
  'MSG_SHOW_DUPLICATES' => 'La cr�ation de ce contact peut induire un doublon. Vous pouvez soit cliquer sur cr�er un comptepour continuer la cr�ation de ce nouveau compte avec les donn�es saisies, soit cliquer sur annuler.',
  'MSG_DUPLICATE' => 'La cr�ation de ce compte peut induire un doublon. Vous pouvez soit s�lectionner un compte dans la liste ci-dessous ou cliquer sur le bouton cr�er un compte pour cr�er un compte avec les donn�es saisies.',
  'LNK_NEW_ACCOUNT' => 'Nouveau Compte',
  'LNK_ACCOUNT_LIST' => 'Comptes',
  'LBL_INVITEE' => 'Contacts',
  'ERR_DELETE_RECORD' => 'Un num�ro d\'enregistrement doit �tre sp�cifi� pour supprimer le compte.',
  'NTC_DELETE_CONFIRMATION' => 'Etes-vous de vouloir supprimer cet enregistrement?',
  'LBL_SAVE_ACCOUNT' => 'Enregistrer le compte',
  'LNK_NEW_CONTACT' => 'Nouveau Contact',
  'LNK_NEW_OPPORTUNITY' => 'Nouvelle affaire',
  'LNK_NEW_CASE' => 'Nouveau Ticket',
  'LNK_NEW_NOTE' => 'Nouvelle Note',
  'LNK_NEW_CALL' => 'Nouvel Appel',
  'LNK_NEW_EMAIL' => 'Nouvel Email',
  'LNK_NEW_MEETING' => 'Nouveau Rendez-vous',
  'LNK_NEW_TASK' => 'Nouvelle T�che',
);


?>