<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.4 2005/02/04 23:56:38 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Calendrier',
  'LBL_MODULE_TITLE' => 'Calendrier',
  'LNK_NEW_CALL' => 'Nouvel appel',
  'LNK_NEW_MEETING' => 'Nouvelle r�union',
  'LNK_NEW_APPOINTMENT' => 'Nouveau rendez-vous',
  'LNK_NEW_TASK' => 'Nouvelle t�che',
  'LNK_CALL_LIST' => 'Appels',
  'LNK_MEETING_LIST' => 'R�union',
  'LNK_TASK_LIST' => 'T�ches',
  'LNK_VIEW_CALENDAR' => 'Aujourd\'hui',
  'LBL_MONTH' => 'Mois',
  'LBL_DAY' => 'Jour',
  'LBL_YEAR' => 'Ann�e',
  'LBL_WEEK' => 'Semaine',
  'LBL_PREVIOUS_MONTH' => 'Mois pr�c�dent',
  'LBL_PREVIOUS_DAY' => 'Jour pr�c�dent',
  'LBL_PREVIOUS_YEAR' => 'Ann�e pr�c�dente',
  'LBL_PREVIOUS_WEEK' => 'Semaine pr�c�dente',
  'LBL_NEXT_MONTH' => 'Mois suivant',
  'LBL_NEXT_DAY' => 'Jour suivant',
  'LBL_NEXT_YEAR' => 'Ann�e suivante',
  'LBL_NEXT_WEEK' => 'Semaine suivante',
  'LBL_AM' => 'AM',
  'LBL_PM' => 'PM',
  'LBL_SCHEDULED' => 'Pr�vue',
  'LBL_BUSY' => 'Occupe',
  'LBL_CONFLICT' => 'Conflit',
  'LBL_USER_CALENDARS' => 'Calendrier utilisateur',
);

$mod_list_strings = array (
  'dom_cal_weekdays' => 
  array (
    0 => 'Dim',
    1 => 'Lun',
    2 => 'Mar',
    3 => 'Mer',
    4 => 'Jeu',
    5 => 'Ven',
    6 => 'Sam',
  ),
  'dom_cal_weekdays_long' => 
  array (
    0 => 'Dimanche',
    1 => 'Lundi',
    2 => 'Mardi',
    3 => 'Mercredi',
    4 => 'Jeudi',
    5 => 'Vendredi',
    6 => 'Samedi',
  ),
  'dom_cal_month' => 
  array (
    0 => '',
    1 => 'Jan',
    2 => 'F�v',
    3 => 'Mar',
    4 => 'Avr',
    5 => 'Mai',
    6 => 'Jui',
    7 => 'Jul',
    8 => 'Ao�',
    9 => 'Sep',
    10 => 'Oct',
    11 => 'Nov',
    12 => 'D�c',
  ),
  'dom_cal_month_long' => 
  array (
    0 => '',
    1 => 'Janvier',
    2 => 'F�vrier',
    3 => 'Mars',
    4 => 'Avril',
    5 => 'Mai',
    6 => 'Juin',
    7 => 'Juillet',
    8 => 'Ao�t',
    9 => 'Septembre',
    10 => 'Octobre',
    11 => 'Novembre',
    12 => 'D�cembre',
  ),
);


?>