<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.4 2005/02/04 23:56:38 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Suivi d\'incidents',
  'LBL_MODULE_TITLE' => 'Suivi d\'incidents: accueil',
  'LBL_SEARCH_FORM_TITLE' => 'Recherche d\'incident',
  'LBL_LIST_FORM_TITLE' => 'Liste d\'incidents',
  'LBL_NEW_FORM_TITLE' => 'Nouvel incident',
  'LBL_CONTACT_BUG_TITLE' => 'Contact:',
  'LBL_SUBJECT' => 'Sujet:',
  'LBL_BUG' => 'Incident:',
  'LBL_BUG_NUMBER' => 'Num�ro d\'incident:',
  'LBL_NUMBER' => 'Num�ro:',
  'LBL_STATUS' => 'Statut:',
  'LBL_PRIORITY' => 'Priorit�:',
  'LBL_DESCRIPTION' => 'Description:',
  'LBL_CONTACT_NAME' => 'Nom du contact:',
  'LBL_BUG_SUBJECT' => 'Sujet de l\'incident:',
  'LBL_CONTACT_ROLE' => 'R�le:',
  'LBL_LIST_NUMBER' => 'Num.',
  'LBL_LIST_SUBJECT' => 'Sujet',
  'LBL_LIST_STATUS' => 'Statut',
  'LBL_LIST_PRIORITY' => 'Priorit�',
  'LBL_LIST_RELEASE' => 'Version',
  'LBL_LIST_RESOLUTION' => 'R�solution',
  'LBL_LIST_LAST_MODIFIED' => 'Derni�re modification',
  'LBL_INVITEE' => 'Contacts',
  'LBL_TYPE' => 'Type:',
  'LBL_LIST_TYPE' => 'Type',
  'LBL_RESOLUTION' => 'R�solution:',
  'LBL_RELEASE' => 'Version:',
  'LNK_NEW_BUG' => 'Reporter un incident',
  'LNK_BUG_LIST' => 'Incidents',
  'NTC_REMOVE_INVITEE' => 'Etes-vous sur de vouloir supprimer ce contact de cet incident?',
  'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Etes-vous sur de vouloir supprimer cet incident de ce compte?',
  'ERR_DELETE_RECORD' => 'Un num�ro d\'enregistrement doit �tre fourni pour supprimer un incident.',
  'LBL_LIST_MY_BUGS' => 'Mes incidents',
  'LBL_LIST_EMAIL_ADDRESS' => 'Addresse Em�l',
  'LBL_LIST_CONTACT_NAME' => 'Nom du contact',
  'LBL_LIST_ACCOUNT_NAME' => 'Nom du compte',
  'LBL_LIST_PHONE' => 'T�l�phone',
  'NTC_DELETE_CONFIRMATION' => 'Etes-vous sur de vouloir supprimer ce contact de cet incident?',
  'bug_priority_default_key' => 'Moyen',
  'bug_priority_dom' => 
  array (
    'Urgent' => 'Urgent',
    'High' => 'Haut',
    'Medium' => 'Moyen',
    'Low' => 'Bas',
  ),
  'bug_resolution_default_key' => '',
  'bug_resolution_dom' => 
  array (
    '' => '',
    'Accepted' => 'Accept�',
    'Duplicate' => 'Dupliqu�',
    'Fixed' => 'R�solu',
    'Out of Date' => 'D�pass�',
    'Invalid' => 'Invalide',
    'Later' => 'Plus tard',
  ),
  'bug_status_default_key' => 'New',
  'bug_status_dom' => 
  array (
    'New' => 'Nouveau',
    'Assigned' => 'Assign�',
    'Closed' => 'Clos',
    'Pending' => 'En attente',
    'Rejected' => 'Rejet�',
  ),
  'bug_type_default_key' => 'Bug',
  'bug_type_dom' => 
  array (
    'Defect' => 'D�faut',
    'Feature' => 'Fonctionnel',
  ),
);


?>