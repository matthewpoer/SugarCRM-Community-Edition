<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.4 2005/02/04 23:56:38 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Affaires',
  'LBL_MODULE_TITLE' => 'Affaires: accueil',
  'LBL_SEARCH_FORM_TITLE' => 'Recherche Affaires',
  'LBL_LIST_FORM_TITLE' => 'Liste des Affaires',
  'LBL_OPPORTUNITY_NAME' => 'Nom de l\'affaire:',
  'LBL_OPPORTUNITY' => 'Affaire:',
  'LBL_NAME' => 'Nom de l\'affaire',
  'LBL_INVITEE' => 'Contacts',
  'LBL_LIST_OPPORTUNITY_NAME' => 'Affaire',
  'LBL_LIST_ACCOUNT_NAME' => 'Nom du compte',
  'LBL_LIST_AMOUNT' => 'Montant',
  'LBL_LIST_DATE_CLOSED' => 'Date de cl�ture',
  'LBL_LIST_SALES_STAGE' => 'Phase de vente',
  'db_sales_stage' => 'LBL_LIST_SALES_STAGE',
  'db_name' => 'LBL_NAME',
  'db_amount' => 'LBL_LIST_AMOUNT',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_date_closed' => 'LBL_LIST_DATE_CLOSED',
  'UPDATE' => 'Opportunit� - Mise � jour devises',
  'UPDATE_DOLLARAMOUNTS' => 'Mise � jour des montants en Dollar U.S.',
  'UPDATE_VERIFY' => 'V�rifier les montants',
//END DON'T CONVERT
  'UPDATE_VERIFY_TXT' => 'V�rifie que les montants dans les opportunit�s sont des nombres d�cimaux valides avec des chiffres(0-9) et la marque d�cimale(.)',
  'UPDATE_FIX' => 'correction des montants',
  'UPDATE_FIX_TXT' => 'Ceci va tenter de corriger les montants invalides en cr�ant un montant avec d�cimales. Tous les montants modifi�s sont pr�alablement sauvegard�s dans un champ nomm� amount_backup. Si vous relevez des anomalies � l\'issue du traitement, <b>NE</b> relancez <b>PAS</b> le traitement avant d\'avoir restaur� la sauvegarde.',
  'UPDATE_DOLLARAMOUNTS_TXT' => 'Mets � jour les montants des opportunit�s en Dollar U.S. en fonction des taux de devises. Cette valeur est utilis�e pour calculer les graphiques et la vue liste des montants de devises.',
  'UPDATE_CREATE_CURRENCY' => 'Cr�er une devise:',
  'UPDATE_VERIFY_FAIL' => 'La v�rification de l\'enregistrement � �chou�e:',
  'UPDATE_VERIFY_CURAMOUNT' => 'Montant actuel:',
  'UPDATE_VERIFY_FIX' => 'Lancer la correction donnera',
  'UPDATE_INCLUDE_CLOSE' => 'Inclure les enregistrements clos',
  'UPDATE_VERIFY_NEWAMOUNT' => 'Nouveau montant:',
  'UPDATE_VERIFY_NEWCURRENCY' => 'Nouvelle devise:',
  'UPDATE_DONE' => 'Fait',
  'UPDATE_BUG_COUNT' => 'Probl�mes trouv�s et tentatives de r�solution:',
  'UPDATE_BUGFOUND_COUNT' => 'Probl�mes trouv�s:',
  'UPDATE_COUNT' => 'Enregistrements mis � jour:',
  'UPDATE_RESTORE_COUNT' => 'Montants restaur�s:',
  'UPDATE_RESTORE' => 'Restaurer les montants',
  'UPDATE_RESTORE_TXT' => 'Restaurer les montants � partir des sauvegardes.',
  'UPDATE_FAIL' => 'Mise � jour impossible - ',
  'UPDATE_NULL_VALUE' => 'Montant NULL valorisation � 0 -',
  'UPDATE_MERGE' => 'Fusionner les devises',
  'UPDATE_MERGE_TXT' => 'Fusionner les devises en une seule devise. si vous notez plusieurs enregistrements pour une m�me devise, vous pouvez fusionner ces enregistrements. Ceci fusionnera aussi les devises dans tous les modules.',
  'LBL_ACCOUNT_NAME' => 'Nom du compte:',
  'LBL_AMOUNT' => 'Montant:',
  'LBL_CURRENCY' => 'Devise:',
  'LBL_DATE_CLOSED' => 'date de cl�ture:',
  'LBL_TYPE' => 'Type:',
  'LBL_NEXT_STEP' => 'prochaine �tape:',
  'LBL_LEAD_SOURCE' => 'Source du prospect:',
  'LBL_SALES_STAGE' => 'Phase de vente:',
  'LBL_PROBABILITY' => 'Probabilit� (%):',
  'LBL_DESCRIPTION' => 'Description:',
  'LBL_DUPLICATE' => 'Opportunit� en double?',
  'MSG_DUPLICATE' => 'La cr�ation de cette opportunit� peut induire une opportunit� en double. vous pouvez soit s�lectionner une opportunit� dans la liste ci-dessous ou cliquer sur le bouton cr�er une opportunit� pour cr�er une opportunit� avec les donn�es saisies.',
  'LBL_NEW_FORM_TITLE' => 'Nouveau Compte',
  'LNK_NEW_OPPORTUNITY' => 'Nouvelle Affaire',
  'LNK_OPPORTUNITY_LIST' => 'Opportunit�s',
  'ERR_DELETE_RECORD' => 'Un num�ro d\'enregistrement doit �tre sp�cifi� pour supprimer l\'affaire.',
  'LBL_TOP_OPPORTUNITIES' => 'Top des Affaires',
  'NTC_REMOVE_OPP_CONFIRMATION' => 'Etes vous sur de vouloir supprimer ce contact pour cette affaire ? ',
  'UPDATE_ISSUE_COUNT' => 'Probl�mes trouv�s et tentatives de r�solution:',
  'UPDATE_ISSUEFOUND_COUNT' => 'Probl�mes trouv�s:',
  'LNK_NEW_CONTACT' => 'Nouveau Contact',
  'LNK_NEW_ACCOUNT' => 'Nouveau Compte',
  'LNK_NEW_CASE' => 'Nouveau Ticket',
  'LNK_NEW_NOTE' => 'Nouvelle Note',
  'LNK_NEW_CALL' => 'Nouvel Appel',
  'LNK_NEW_EMAIL' => 'Nouvel Em�l',
  'LNK_NEW_MEETING' => 'Nouveau Rendez-vous',
  'LNK_NEW_TASK' => 'Nouvelle T�che',
);


?>