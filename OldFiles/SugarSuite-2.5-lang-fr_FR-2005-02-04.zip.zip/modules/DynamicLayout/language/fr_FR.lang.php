<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.4 2005/02/04 23:56:38 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_ADVANCED' => 'Avanc�:',
  'DESC_USING_LAYOUT_TITLE' => 'Utilisez l\'�diteur',
  'DESC_USING_LAYOUT_SHORTCUTS' => 'Raccourcis:',
  'DESC_USING_LAYOUT_TOOLBAR' => 'Barre d\'outils:',
  'DESC_USING_LAYOUT_EDIT_ROWS' => 'Editer les lignes:',
  'DESC_USING_LAYOUT_SELECT_FILE' => 'S�lectionner un fichier:',
  'DESC_USING_LAYOUT_EDIT_FIELDS' => 'Editer les champs:',
  'DESC_USING_LAYOUT_ADD_FIELD' => 'Ajouter un champ:',
  'DESC_USING_LAYOUT_REMOVE_ITEM' => 'Supprimer un �l�ment:',
  'DESC_USING_LAYOUT_DISPLAY_HTML' => 'Afficher le code HTML:',
  'DESC_USING_LAYOUT_BLK1' => 'L\'�diteur vous permet de r�organiser les champs, les tabulations et les panneaux pour personnaliser les �crans selon votre besoin. S�lectionnez d\'abord la vue de la page que vous voulez personnaliser via le raccorci �S�lectionner un fichier�.',
  'DESC_USING_LAYOUT_BLK2' => ' vous permet de s�lectionner une autre page � �diter; Les mises � jours sur la page courante sont perdues si vous ne sauvegardez pas. Si vous n\'�tes pas sur un fichier � �diter vous pouvez cocher la case "Editer"; ceci ajoutera une boite d\'�dition sur tous les endroits �ditables de l\'application. Naviguer dans l\'application jusqu\'� la page que vous souhaitez modifier, cliquer sur la case �diter et vous reviendrez dans le panneau d\'�dition pour ce fichier.',
  'DESC_USING_LAYOUT_BLK3' => ' D�placez et r�organisez le champs ou leurs descriptions. S�lectionnez l\'ic�ne du champ',
  'DESC_USING_LAYOUT_BLK4' => ' � c�t� du champ ou de la description que vous voulez d�placer, puis cliquez sur l\'ic�ne du champ � l\'endroit o� vous voulez le repositionner. Ceci d�placera le champ de son ancien emplacement vers le nouvel emplacement. S\'il y a d�j� un champ ou une description � l\'endroit souhait� les deux champs �changerons leurs positions. Le d�placement des sous panneaux ob�it aux m�mes r�gles. S�lectionner l\'ic�ne du sous panneau � d�placer puis l\'ic�ne de destination du sous panneau, les deux sous panneaux changeront d\'emplacement. Pour supprimer un champ ou un sous panneau de l\'�cran, d�placer le champ dans la boite � outils dans la barre de menu gauche.',
  'DESC_USING_LAYOUT_BLK5' => ' modifiez la vue pour pouvoir ajouter ou supprimer des lignes dans le panneau d�tails. Cliquer sur le + ajoute une ligne sous la ligne s�lectionn�e, cliquer sur le � supprime la ligne.',
  'DESC_USING_LAYOUT_BLK6' => 'La boite � outils est un espace de travail  pour ajouter des champs ou des descriptions dans un �cran, conserve temporairement les champs qui ont �t� supprim�s et les mets au rebut.',
  'DESC_USING_LAYOUT_BLK7' => ' ouvrir l\'�cran de s�lection de type de champ pour pr�ciser quel type de champ vous voulez ajouter et la description associ�e. Cliquer sur le bouton ajouter ins�re le nouveau champ et sa description dans la boite � outils. Vous pouvez alors s�lectionner l\'ic�ne de champ et positionner l\'ic�ne � l\'emplacement d�sir�.',
  'DESC_USING_LAYOUT_BLK8' => ' s�lectionnez l\'ic�ne du champ et cliquez sur le texte �D�placer les champs non d�sir�s ici�. Ceci d�posera le champ s�lectionn� dans la boite � outils.',
  'DESC_USING_LAYOUT_BLK9' => ' Affiche le code HTML de chaque champ. Cette action consommme beaucoup de temps CPU, il ne faut l\'utiliser qu\'en cas de besoin.',
  'DESC_USING_LAYOUT_BLK10' => 'Pour sauvegarder les modifications cliquer sur le bouton �Sauvegarder l\'affichage�. Pour annuler les modifications cliquez sur n\'importe quel panneau de l\'application.',
);


?>