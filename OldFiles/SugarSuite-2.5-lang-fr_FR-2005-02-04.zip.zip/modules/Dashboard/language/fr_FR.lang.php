<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.4 2005/02/04 23:56:38 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Tableau de bord',
  'LBL_MODULE_TITLE' => 'Tableau de bord: Accueil',
  'LBL_SALES_STAGE_FORM_TITLE' => 'Total du portefeuille par phases de vente',
  'LBL_SALES_STAGE_FORM_DESC' => 'Montre le montant des affaires cumul�es par phases de vente, pour les utilisateurs s�lectionn�s dont la date de cl�ture pr�vue de l\'affaire est comprise dans la plage sp�cifi�e.',
  'LBL_YEAR_BY_OUTCOME' => 'Pipeline par mois par r�sultat',
  'LBL_MONTH_BY_OUTCOME_DESC' => 'Montre le montant cumul� mensuel des affaires par r�sultats pour les utilisateurs s�lectionn�s dont la date de cl�ture pr�vue de l\'affaire est comprise dans la plage sp�cifi�e.',
  'LBL_LEAD_SOURCE_FORM_TITLE' => 'Total du portefeuille par source des prospects',
  'LBL_LEAD_SOURCE_FORM_DESC' => 'Montre le montant cumul� des affaires par source des prospects pour les utilisateurs s�lectionn�s.',
  'LBL_LEAD_SOURCE_BY_OUTCOME' => 'Toutes les affaires par source des prospects et r�sultat.',
  'LBL_LEAD_SOURCE_BY_OUTCOME_DESC' => 'Montre le montant cumul� des affaires par source des prospects et r�sultat pour les utilisateurs s�lectionn�s dont la date de cl�ture pr�vue de l\'affaire est comprise dans la plage sp�cifi�e. Le r�sultat est bas�  soit sur l\'affaire gagn�e, perdue ou tout autre valeur. ',
  'LBL_PIPELINE_FORM_TITLE_DESC' => 'Montre les montants cumul�s par phase de vente pour VOS affaires dont la date de cl�ture pr�vue de l\'affaire est comprise dans la plage sp�cifi�e.',
  'LBL_DATE_RANGE' => 'Date du',
  'LBL_DATE_RANGE_TO' => 'au',
  'ERR_NO_OPPS' => 'Merci de cr�er des affaires pour visualiser le graphique des Affaires.',
  'LBL_TOTAL_PIPELINE' => 'Total du portefeuille',
  'LBL_ALL_OPPORTUNITIES' => 'Le montant total de toutes les affaires est de ',
  'LBL_OPP_SIZE' => 'Total des affaires en KEuros',
  'LBL_OPP_THOUSANDS' => 'K',
  'NTC_NO_LEGENDS' => 'Aucun(e)',
  'LBL_LEAD_SOURCE_OTHER' => 'Autre',
  'LBL_EDIT' => 'Editer',
  'LBL_REFRESH' => 'Rafraichir',
  'LBL_CREATED_ON' => 'Dernier affichage le ',
  'LBL_OPPS_WORTH' => 'opportunit� dont le montant est',
  'LBL_OPPS_IN_STAGE' => 'Affaires dont la phase de vente est ',
  'LBL_OPPS_IN_LEAD_SOURCE' => 'Affaires ou la source du prospect est',
  'LBL_OPPS_OUTCOME' => 'Affaires dont le r�sultat est ',
  'LBL_ROLLOVER_DETAILS' => 'Passer la souris sur une barre pour avoir les d�tails.',
  'LBL_ROLLOVER_WEDGE_DETAILS' => 'Passer la souris sur un triangle pour avoir les d�tails.',
  'LBL_USERS' => 'Utilisateurs:',
  'LBL_SALES_STAGES' => 'Phases de vente:',
  'LBL_LEAD_SOURCES' => 'Sources du prospect:',
  'LBL_DATE_START' => 'Date de d�marrage:',
  'LBL_DATE_END' => 'Date de fin:',
  'LBL_YEAR' => 'Ann�e:',
  'LNK_NEW_CONTACT' => 'Nouveau Contact',
  'LNK_NEW_ACCOUNT' => 'Nouveau Compte',
  'LNK_NEW_OPPORTUNITY' => 'Nouvelle Affaire',
  'LNK_NEW_QUOTE' => 'Cr�er un devis',
  'LNK_NEW_LEAD' => 'Nouveau Prospect',
  'LNK_NEW_CASE' => 'Nouveau Ticket',
  'LNK_NEW_NOTE' => 'Nouvelle Note',
  'LNK_NEW_CALL' => 'Nouvel Appel',
  'LNK_NEW_MEETING' => 'Nouveau Rendez-vous',
  'LNK_NEW_TASK' => 'Nouvelle T�che',
  'LNK_NEW_ISSUE' => 'Nouvel Incident',
  'LBL_MONTH_BY_OUTCOME' => 'Portefeuille mensuel par r�sultats',
  'LNK_NEW_EMAIL' => 'Nouvel Em�l',
);


?>