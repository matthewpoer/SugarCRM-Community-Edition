<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Meetings/language/ge_ch.lang.php, v 1.5 2004/09/10 erich.althaus@creative-solutions.ch $
 * Description:  Defines the Swiss German language pack 
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_MODULE_NAME'=>'Termine',
'LBL_MODULE_TITLE'=>'Termine: Home',
'LBL_SEARCH_FORM_TITLE'=>'Termin Suchen',
'LBL_LIST_FORM_TITLE'=>'Termin Liste',
'LBL_NEW_FORM_TITLE'=>'Termin eintragen',

'LBL_LIST_SUBJECT'=>'Titel',
'LBL_LIST_CONTACT'=>'Kontakt',
'LBL_LIST_RELATED_TO'=>'Verantwortlich',
'LBL_LIST_DATE'=>'Start Datum',
'LBL_LIST_TIME'=>'Start Zeit',

'LBL_SUBJECT'=>'Titel:',
'LBL_STATUS'=>'Status:',
'LBL_LOCATION'=>'Ort:',
'LBL_DATE_TIME'=>'Start Datum & Zeit:',
'LBL_DATE'=>'Start Datum:',
'LBL_TIME'=>'Start Zeit:',
'LBL_DURATION'=>'Dauer:',
'LBL_HOURS_MINS'=>'(Stunden/Minuten)',
'LBL_SUBJECT'=>'Titel: ',
'LBL_CONTACT_NAME'=>'Kontakt: ',
'LBL_MEETING'=>'Meeting:',
'LBL_DESCRIPTION_INFORMATION'=>'Zus�tzliche Informationen',
'LBL_DESCRIPTION'=>'Bemerkungen:',
'LBL_COLON'=>':',
'LBL_DEFAULT_STATUS'=>'Geplant',

'LNK_NEW_CONTACT'=>'Neuer Kontakt',
'LNK_NEW_ACCOUNT'=>'Neuer Kunde',
'LNK_NEW_OPPORTUNITY'=>'Neuer Auftrag',
'LNK_NEW_CASE'=>'Neuer Bedarf',
'LNK_NEW_NOTE'=>'Neue Notiz',
'LNK_NEW_CALL'=>'Neues Telefonat',
'LNK_NEW_EMAIL'=>'Neue Email',
'LNK_NEW_MEETING'=>'Neuer Termin',
'LNK_NEW_TASK'=>'Neue Aufgabe',
'ERR_DELETE_RECORD'=>"Ein Eintrag muss ausgew�hlt sein um ein Termin zu l�schen.",

//New to SugarCRM 1.1c.
'LBL_LIST_CLOSE'=>'Schliessen',
'NTC_REMOVE_INVITEE'=>'Sind Sie sicher das Sie diese Person von dem Termin entfernen m�chten?',
'LBL_INVITEE'=>'Teilnehmer',

);

?>