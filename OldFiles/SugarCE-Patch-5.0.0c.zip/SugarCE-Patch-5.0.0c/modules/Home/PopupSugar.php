<!--
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/
/*********************************************************************************
 * Header: /cvsroot/sugarcrm/sugarcrm/modules/Products/ListView.html,v 1.4 2004/07/02 07:02:27 sugarclint Exp {APP.LBL_LIST_CURRENCY_SYM}
 ********************************************************************************/
-->

<body style="margin: 0px;">
<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
global $theme;
require_once('themes/'.$theme.'/layout_utils.php');
insert_popup_header($theme);

$sugarteam = array('John Roberts', 'Clint Oram', 'Jacob Taylor', 'Julian Ostrow', 'Lam Huynh', 'Majed Itani', "Nate D'Amico", 'Joey Parsons', 'Ajay Gupta','Jason Nassi', 'Russell Kojima', 'Andy Dreisch', 'Jeff Li',  'Roger Smith', 'Matt Heitzenroder',  'Manoj Jayadevan', 'Liliya Bederov',  'Sadek Baroudi', 'Yun-Ping Hsu', 'Rob Aagaard', 'Matt Fleeger', 'Franklin Liu', 'Jennifer Yim', 'Sujata Pamidi', 'Sharon Sim', 'Andrew Wu', 'Eddy Ramirez', 'Max Hwang', 'Lori Arce', 'Jenny Gonsalves', 'Brian Kilgore',  'Mitch Lieberman', 'Vineet Dhyani', 'Collin Lee', 'Reem Bazzari',  'Joey Chao', 'Tom Brennan', 'David Kosy', 'Ken Brill', 'Jeff Tichenor', 'Travis Swicegood', 'Tom Young', 'Chris Raffle', 'David Wheeler',  'Daniel Reverri',  'Samir Gandhi', 'Nithya Lakshmi Shunmugham', 'Navjeet Singh', 'Breno Gomes', 'Donald Wong', 'Jeff Carouth', 'Benjamin Soufflet', 'Carlota Sage' );
switch($_REQUEST['style']){
	case 'rev':
			$sugarteam = array_map('strrev', $sugarteam);
			break;
	case 'rand':
			shuffle($sugarteam);
			break;
	case 'dec':
			$sugarteam = array_reverse($sugarteam);
			break;
	case 'sort':
			 sort($sugarteam);
			 break;
	case 'rsort':
			 rsort($sugarteam);
			 break;
			 
}
$special = array("<br><br><b>Special Thanks To</b>",
					 "Josh Stein",
					 "Mary Coleman",
					 "Larry Augustin",
					 "Scott Sandell",
					 "<br><br><p>&copy; 2008 SugarCRM Inc. All Rights Reserved.");
$body =  "<p><b>Sugar Team Members</b></p>" . implode('<br>', $sugarteam) . implode('<br>', $special);
?>
<script>
	var user_notices = new Array();
	var delay = 25000
	var index = 0;
	var lastIndex = 0;
	var scrollerHeight=200
	var bodyHeight = ''
	var scrollSpeed = 1;
	var curTeam = 'all';
	var scrolling = true;


	


	function stopNotice(){
			scrolling = false;
	}
	function startNotice(){
			scrolling = true;
	}
	function scrollNotice(){

		if(scrolling){
		
		var body = document.getElementById('NOTICEBODY')
		var daddy = document.getElementById('daddydiv')

		if(parseInt(body.style.top) > bodyHeight *-1 ){

			body.style.top = (parseInt(body.style.top) - scrollSpeed) + 'px';

		}else{
			
			body.style.top =scrollerHeight + "px"
		}
		}

		setTimeout("scrollNotice()", 50);

	}
	function nextNotice(){



		body = document.getElementById('NOTICEBODY');
		if(scrolling){
				body.style.top = scrollerHeight/2 +'px'
				bodyHeight= parseInt(body.offsetHeight);
		}
				

		}
	


</script>
<div style="width: 300px; height: 400px; text-align: center; border:0; padding: 5px;">
<div id='daddydiv' style="position:relative;width=100%;height:350px;overflow:hidden">
<div id='NOTICEBODY' style="position:absolute;left:0px;top:0px;width:100%;z-index: 1; text-align: left;">
<?php echo $body; ?>
</div>
</div>
<script>
if(window.addEventListener){
	window.addEventListener("load", nextNotice, false);
	window.addEventListener("load", scrollNotice, false);
}else{
	window.attachEvent("onload", nextNotice);
	window.attachEvent("onload", scrollNotice);
}
</script>


