<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Hernan Lopez M - hsoft@ati-ltda.com
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/include/language/sp_co.lang.php,v 1.27 2004/08/29 13:05:04 stratofun Exp $
 * Description:  Defines the Spanish language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$app_strings = Array(
'LNK_ABOUT'=>'*About',

'LBL_DATE_MODIFIED'=>'*Last Modified:',
'LBL_DATE_ENTERED'=>'*Created:',

'LBL_BACK'=>'*Back',
'LBL_IMPORT'=>'*Import',
'LBL_EXPORT'=>'*Export',

'LBL_CHARSET'=>'ISO-8859-1',
'LBL_BROWSER_TITLE'=>'SugarCRM - CRM Comercial de Fuente Abierta',
'LBL_MY_ACCOUNT'=>'Mi Cuenta',
'LBL_ADMIN'=>'Administrador',
'LBL_LOGOUT'=>'Salir',
'LBL_SEARCH'=>'Buscar',
'LBL_LAST_VIEWED'=>'Ultima Visita',
'NTC_WELCOME'=>'Bienvenido',
'NTC_SUPPORT_SUGARCRM'=>"Soporte el proyecto de fuente abierta SugarCRM con una donaci�n a trav�s de PayPal - !es r�pido, gratis y seguro!",
'NTC_NO_ITEMS_DISPLAY'=>'ninguno',
'LBL_ALT_HOT_KEY'=>'Alt+',

'LBL_SAVE_BUTTON_TITLE'=>'Guardar [Alt+S]',
'LBL_EDIT_BUTTON_TITLE'=>'Editar [Alt+E]',
'LBL_EDIT_BUTTON'=>'Editar',
'LBL_DUPLICATE_BUTTON_TITLE'=>'Duplicar [Alt+U]',
'LBL_DUPLICATE_BUTTON'=>'Duplicar',
'LBL_DELETE_BUTTON_TITLE'=>'Borrar [Alt+D]',
'LBL_DELETE_BUTTON'=>'Borrar',
'LBL_NEW_BUTTON_TITLE'=>'Nuevo [Alt+N]',
'LBL_CHANGE_BUTTON_TITLE'=>'Cambiar [Alt+G]',
'LBL_CANCEL_BUTTON_TITLE'=>'Cancelar [Alt+X]',
'LBL_SEARCH_BUTTON_TITLE'=>'Buscar [Alt+Q]',
'LBL_CLEAR_BUTTON_TITLE'=>'Limpiar [Alt+C]',
'LBL_SELECT_BUTTON_TITLE'=>'Seleccionar [Alt+T]',
'LBL_SAVE_BUTTON_KEY'=>'S',
'LBL_EDIT_BUTTON_KEY'=>'E',
'LBL_DUPLICATE_BUTTON_KEY'=>'U',
'LBL_DELETE_BUTTON_KEY'=>'D',
'LBL_NEW_BUTTON_KEY'=>'N',
'LBL_CHANGE_BUTTON_KEY'=>'G',
'LBL_CANCEL_BUTTON_KEY'=>'X',
'LBL_SEARCH_BUTTON_KEY'=>'Q',
'LBL_CLEAR_BUTTON_KEY'=>'C',
'LBL_SELECT_BUTTON_KEY'=>'T',
'LBL_SAVE_BUTTON_LABEL'=>'Guardar',
'LBL_EDIT_BUTTON_LABEL'=>'Editar',
'LBL_DUPLICATE_BUTTON_LABEL'=>'Duplicar',
'LBL_DELETE_BUTTON_LABEL'=>'Borrar',
'LBL_NEW_BUTTON_LABEL'=>'Nuevo',
'LBL_CHANGE_BUTTON_LABEL'=>'Cambiar',
'LBL_CANCEL_BUTTON_LABEL'=>'Cancelar',
'LBL_SEARCH_BUTTON_LABEL'=>'Buscar',
'LBL_CLEAR_BUTTON_LABEL'=>'Limpiar',
'LBL_SELECT_BUTTON_LABEL'=>'Seleccionar',
'LBL_SELECT_CONTACT_BUTTON_TITLE'=>'Seleccionar Contacto [Alt+T]',
'LBL_SELECT_CONTACT_BUTTON_KEY'=>'T',
'LBL_SELECT_CONTACT_BUTTON_LABEL'=>'Seleccionar Contacto',
'LBL_SELECT_USER_BUTTON_TITLE'=>'Seleccionar Usuario [Alt+U]',
'LBL_SELECT_USER_BUTTON_KEY'=>'U',
'LBL_SELECT_USER_BUTTON_LABEL'=>'Seleccionar Usuario',

'LBL_LIST_NAME'=>'Nombre',
'LBL_LIST_USER_NAME'=>'Nombre Usuario',
'LBL_LIST_EMAIL'=>'Email',
'LBL_LIST_PHONE'=>'Tel�fono',
'LBL_LIST_CONTACT_NAME'=>'Nombre Contacto',
'LBL_LIST_ACCOUNT_NAME'=>'Nombre Cuenta',
'LBL_USER_LIST'=>'Lista Usuarios',
'LBL_CONTACT_LIST'=>'Lista Contactos',

'LNK_ADVANCED_SEARCH'=>'Avanzado',
'LNK_BASIC_SEARCH'=>'Basico',
'LNK_EDIT'=>'Editar',
'LNK_REMOVE'=>'Remover',
'LNK_DELETE'=>'Borrar',
'LNK_LIST_START'=>'Iniciar',
'LNK_LIST_NEXT'=>'Pr�ximo',
'LNK_LIST_PREVIOUS'=>'Anterior',
'LNK_LIST_END'=>'Fin',
'LBL_LIST_OF'=>'de',
'LNK_PRINT'=>'Imprimir',
'LNK_HELP'=>'Ayuda',

'NTC_REQUIRED'=>'Indica campo requerido',
'LBL_REQUIRED_SYMBOL'=>'*',
'LBL_CURRENCY_SYMBOL'=>'$',
'LBL_THOUSANDS_SYMBOL'=>'k',
'NTC_DATE_FORMAT'=>'(yyyy-mm-dd)',
'NTC_TIME_FORMAT'=>'(24:00)',
'NTC_DATE_TIME_FORMAT'=>'(yyyy-mm-dd 24:00)',
'NTC_DELETE_CONFIRMATION'=>'�Est� seguro de que desea borrar este registro?',
'ERR_DELETE_RECORD'=>'Un n�mero de registro debe ser indicado para borrar el contacto.',
'ERR_CREATING_TABLE'=>'Error creando tabla: ',
'ERR_CREATING_FIELDS'=>'Error llenando en campos de detalles adicionales: ',
'ERR_MISSING_REQUIRED_FIELDS'=>'Campos requeridos faltantes:',
'ERR_INVALID_EMAIL_ADDRESS'=>'no es un email v�lido.',
'ERR_INVALID_DATE_FORMAT'=>'El formato de la fecha debe ser: yyyy-mm-dd',
'ERR_INVALID_MONTH'=>'Por favor introduzca un mes v�lido.',
'ERR_INVALID_DAY'=>'Por favor introduzca un a�o v�lido.',
'ERR_INVALID_YEAR'=>'Por favor introduzca un a�o v�lido de 4 d�gitos.',
'ERR_INVALID_DATE'=>'Por favor introduzca una fecha v�lida.',
'ERR_INVALID_HOUR'=>'Por favor introduzca una hora v�lida.',
'ERR_INVALID_TIME'=>'Por favor introduzca una hora v�lida.',
'NTC_CLICK_BACK'=>'Por favor presione el bot�n anterior del navegador y corriga el error.',
'LBL_LIST_ASSIGNED_USER'=>'Asignado a',
'LBL_ASSIGNED_TO'=>'Asignado a:',
'LBL_CURRENT_USER_FILTER'=>'S�lo mis �tems:',
'NTC_LOGIN_MESSAGE'=>"Por favor ingrese a la aplicaci�n.",
'LBL_NONE'=>'--Ninguno--',
);

//the left value is the key stored in the db and the right value is the display value
//to translate, only modify the right value in each key/value pair
$app_list_strings = Array(
//e.g. auf Deutsch 'Contacts'=>'Contakten',
'moduleList' => Array('Home'=>'Inicio'
				, 'Dashboard'=>'Tablero'
				, 'Contacts'=>'Contactos'
				, 'Accounts'=>'Cuentas'
				, 'Opportunities'=>'Oportunidades'
				, 'Cases'=>'Casos'
				, 'Notes'=>'Notes & Attachments'
				, 'Calls'=>'Llamadas'
				, 'Emails'=>'Emails'
				, 'Meetings'=>'Reuniones'
				, 'Tasks'=>'Tareas'),

//e.g. en fran�ais 'Analyst'=>'Analyste',
'account_type_dom' => Array(''=>''
		, 'Analyst'=>'Analista'
		, 'Competitor'=>'Competidor'
		, 'Customer'=>'Cleinte'
		, 'Integrator'=>'Integrador'
		, 'Investor'=>'Inversionista'
		, 'Partner'=>'Asociado'
		, 'Press'=>'Prensa'
		, 'Prospect'=>'Prospecto'
		, 'Reseller'=>'Revendedor'
		, 'Other'=>'Otro'
		),

//e.g. en espa�ol 'Apparel'=>'Ropa',
'industry_dom' => Array(''=>''
		, 'Apparel'=>'Ropa'
		, 'Banking'=>'Banca'
		, 'Biotechnology'=>'Biotecnolog�a'
		, 'Chemicals'=>'Qu�micos'
		, 'Communications'=>'Comunicaciones'
		, 'Construction'=>'Construcci�n'
		, 'Consulting'=>'Consultor�a'
		, 'Education'=>'Educaci�n'
		, 'Electronics'=>'Electronica'
		, 'Energy'=>'Energ�a'
		, 'Engineering'=>'Ingenier�a'
		, 'Entertainment'=>'Entretenimiento'
		, 'Environmental'=>'Ambiente'
		, 'Finance'=>'Finanzas'
		, 'Food & Beverage'=>'Comida y Bebidas'
		, 'Government'=>'Gobierno'
		, 'Healthcare'=>'Salud'
		, 'Hospitality'=>'Hospital'
		, 'Insurance'=>'Seguro'
		, 'Machinery'=>'Maquinaria'
		, 'Manufacturing'=>'Fabricaci�n'
		, 'Media'=>'Media'
		, 'Not For Profit'=>'Sin Fines de Lucro'
		, 'Recreation'=>'Recreaci�n'
		, 'Retail'=>'Detallista'
		, 'Shipping'=>'Env�o'
		, 'Technology'=>'Tecnolog�a'
		, 'Telecommunications'=>'Telecomunicaciones'
		, 'Transportation'=>'Transporte'
		, 'Utilities'=>'Servicios'
		, 'Other'=>'Otro'
		),

'lead_source_dom' => Array(''=>''
		, 'Cold Call'=>'Llamada Fr�a'
		, 'Existing Customer'=>'Cliente Existente'
		, 'Self Generated'=>'Auto Generado'
		, 'Employee'=>'Empleado'
		, 'Partner'=>'Asociado'
		, 'Public Relations'=>'Relaciones P�blicas'
		, 'Direct Mail'=>'Correo Directo'
		, 'Conference'=>'Conferencia'
		, 'Trade Show'=>'Exposici�n'
		, 'Web Site'=>'Web Site'
		, 'Word of mouth'=>'Recomendaci�n'
		, 'Other'=>'Otro'
		),

'opportunity_type_dom' => Array(''=>''
		, 'Existing Business'=>'Negocios Existentes'
		, 'New Business'=>'Nuevos Negocios'
		),

//Note:  do not translate opportunity_relationship_type_default_key
//       it is the key for the default opportunity_relationship_type_dom value
'opportunity_relationship_type_default_key' => 'Primary Decision Maker',
'opportunity_relationship_type_dom' => Array(''=>''
		, 'Primary Decision Maker'=>'Tomador de Decisi�n Principal'
		, 'Business Decision Maker'=>'Tomador de Decisi�n de Negocio'
		, 'Business Evaluator'=>'Evaluador de Negocio'
		, 'Technical Decision Maker'=>'Tomador de Decisi�n T�cnica'
		, 'Technical Evaluator'=>'Evaluador T�cnico'
		, 'Executive Sponsor'=>'Patrocinador Ejecutivo'
		, 'Influencer'=>'Influenciador'
		, 'Other'=>'Otro'
		),

//Note:  do not translate case_relationship_type_default_key
//       it is the key for the default case_relationship_type_dom value
'case_relationship_type_default_key' => 'Contacto Principal',
'case_relationship_type_dom' => Array(''=>''
		, 'Primary Contact'=>'Contacto Principal'
		, 'Alternate Contact'=>'Contacto Alterno'
		),

'sales_stage_dom' => Array('Prospecting'=>'Prospecto'
		, 'Qualification'=>'Calificaci�n'
		, 'Needs Analysis'=>'Necesita An�lisis'
		, 'Value Proposition'=>'Propuesta de Valor'
		, 'Id. Decision Makers'=>'Id. Tomadores de Decisiones'
		, 'Perception Analysis'=>'An�lisis de Percepci�n'
		, 'Proposal/Price Quote'=>'Propuesta/Presupuesto'
		, 'Negotiation/Review'=>'Negociaci�n/Revisi�n'
		, 'Closed Won'=>'Cerrado Triunfo'
		, 'Closed Lost'=>'Cerrado Derrota'
		),

'salutation_dom' => Array(''=>''
		, 'Mr.'=>'Sr.'
		, 'Ms.'=>'Srta.'
		, 'Mrs.'=>'Sra.'
		, 'Dr.'=>'Dr.'
		, 'Prof.'=>'Prof.'
		),

'task_priority_dom' => Array('High'=>'Alto'
		, 'Medium'=>'Medio'
		, 'Low'=>'Bajo'
		),

'task_status_dom' => Array('Not Started'=>'No Iniciado'
		, 'In Progress'=>'En Progreso'
		, 'Completed'=>'Completado'
		, 'Pending Input'=>'Entrada Pendiente'
		, 'Deferred'=>'Diferido'
		),

'meeting_status_dom' => Array('Planned'=>'Planificada'
		, 'Held'=>'Mantenida'
		, 'Not Held'=>'No Mantenida'
		),

'call_status_dom' => Array('Planned'=>'Planificada'
		, 'Held'=>'Mantenida'
		, 'Not Held'=>'No Mantenida'
		),

//Note:  do not translate case_status_default_key
//       it is the key for the default case_status_dom value
'case_status_default_key' => 'New',
'case_status_dom' => Array('New'=>'Nueva'
		, 'Assigned'=>'Asignado'
		, 'Closed'=>'Cerrado'
		, 'Pending Input'=>'Entrada Pendiente'
		, 'Rejected'=>'Rechazada'
		),

'user_status_dom' => Array('Active'=>'Activo'
		, 'Inactive'=>'Inactivo'
		),

//Note:  do not translate record_type_default_key
//       it is the key for the default record_type_module value
'record_type_default_key' => 'Accounts',
'record_type_display' => array('Accounts' => '*Account',
		'Opportunities' => '*Opportunity',
		'Cases' => '*Case'),
);

?>