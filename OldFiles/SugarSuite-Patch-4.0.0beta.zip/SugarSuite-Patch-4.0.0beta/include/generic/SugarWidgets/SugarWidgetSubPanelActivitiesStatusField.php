<?php
/**
 * SugarWidgetSubPanelActivitiesStatusField
 *
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */

// $Id: SugarWidgetSubPanelActivitiesStatusField.php,v 1.4 2005/10/11 03:14:36 julian Exp $

require_once('include/generic/SugarWidgets/SugarWidgetField.php');
require_once('include/utils.php');

class SugarWidgetSubPanelActivitiesStatusField extends SugarWidgetField
{
	function displayList(&$layout_def)
	{
		global $current_language;
		$app_list_strings = return_app_list_strings_language($current_language);
		
		$module = empty($layout_def['module']) ? '' : $layout_def['module'];
		
		if(isset($layout_def['varname']))
		{
			$key = strtoupper($layout_def['varname']);
		}
		else
		{
			$key = $this->_get_column_alias($layout_def);
			$key = strtoupper($key);
		}

		$value = $layout_def['fields'][$key];
		
		switch($module)
		{
			case 'Meetings':
				$cell_html = $app_list_strings['meeting_status_dom'][$value];
				break;
			case 'Tasks':
				$cell_html = $app_list_strings['task_status_dom'][$value];
				break;
			case 'Calls':
				$cell_html = $app_list_strings['call_status_dom'][$value];
				break;
			case 'Emails':
        		$cell_html = $app_list_strings['dom_email_types'][$value];
        		break;
			default:
				$cell_html = $value;
				break;
		}
		
		return $cell_html;
	}
}

?>
