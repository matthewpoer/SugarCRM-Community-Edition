<?php

// $Id: Sugar_Smarty.php,v 1.3 2005/10/18 00:23:04 majed Exp $

require_once('include/Smarty/Smarty.class.php');
require_once('upgrade/dir_inc.php');
if(!defined('SUGAR_SMARTY_DIR'))
{
	define('SUGAR_SMARTY_DIR', 'cache/smarty/');
}

class Sugar_Smarty extends Smarty
{
	
	function Sugar_Smarty()
	{
		if(!file_exists(SUGAR_SMARTY_DIR)){
			mkdir_recursive(SUGAR_SMARTY_DIR, true);
		
			if(!file_exists(SUGAR_SMARTY_DIR . 'templates_c'))mkdir_recursive(SUGAR_SMARTY_DIR . 'templates_c', true);
			if(!file_exists(SUGAR_SMARTY_DIR . 'configs'))mkdir_recursive(SUGAR_SMARTY_DIR . 'configs', true);
			if(!file_exists(SUGAR_SMARTY_DIR . 'cache'))mkdir_recursive(SUGAR_SMARTY_DIR . 'cache', true);
		}
		
		$this->template_dir = '.';
		$this->compile_dir = SUGAR_SMARTY_DIR . 'templates_c';
		$this->config_dir = SUGAR_SMARTY_DIR . 'configs';
		$this->cache_dir = SUGAR_SMARTY_DIR . 'cache';
	}
	
}

?>
