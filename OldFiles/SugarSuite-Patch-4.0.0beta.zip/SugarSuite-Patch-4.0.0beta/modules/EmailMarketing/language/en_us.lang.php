<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.15 2005/11/29 20:09:46 ajay Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Email Marketing',
  'LBL_MODULE_TITLE' => 'Email Marketing: Home',
  'LBL_LIST_FORM_TITLE' => 'Email Marketing Campaigns',
  'LBL_PROSPECT_LIST_NAME' => 'Name:',
  'LBL_NAME' => 'Name: ',
  'LBL_LIST_NAME' => 'Name',
  'LBL_LIST_FROM_ADDR' => 'From Email',
  'LBL_LIST_DATE_START' => 'Start Date',
  'LBL_LIST_TEMPLATE_NAME' => 'Email Template',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_STATUS'	=>	'Status',
  'LBL_STATUS_TEXT'	=>	'Status:' ,
  
  'LBL_DATE_ENTERED' => 'Date Entered',
  'LBL_DATE_MODIFIED' => 'Date Modified',
  'LBL_MODIFIED' => 'Modified by: ',
  'LBL_CREATED' => 'Created by: ',
  'LBL_MESSAGE_FOR'	=> 'Send This Message To:',
  'LBL_MESSAGE_FOR_ID'	=> 'Message For',
  
  'LBL_FROM_NAME' => 'From Name: ',
  'LBL_FROM_ADDR' => 'From Email Address: ',
  'LBL_DATE_START' => 'Start Date',
  'LBL_TIME_START' => 'Start Time',
  'LBL_START_DATE_TIME' => 'Start Date & Time: ',
  'LBL_TEMPLATE' => 'Email Template: ',
  
  'LBL_MODIFIED_BY' => 'Modified by: ',
  'LBL_CREATED_BY' => 'Created by: ',
  'LBL_DATE_CREATED' => 'Created date: ',
  'LBL_DATE_LAST_MODIFIED' => 'Modified date: ',

  'LNK_NEW_CAMPAIGN' => 'Create Campaign',
  'LNK_CAMPAIGN_LIST' => 'Campaigns',
  'LNK_NEW_PROSPECT_LIST' => 'Create Prospect List',
  'LNK_PROSPECT_LIST_LIST' => 'Prospect Lists',
  'LNK_NEW_PROSPECT' => 'Create Prospect',
  'LNK_PROSPECT_LIST' => 'Prospects',
  'LBL_DEFAULT_SUBPANEL_TITLE'=>'Email Marketing',
  'LBL_CREATE_EMAIL_TEMPLATE'=>	'Create',
  'LBL_EDIT_EMAIL_TEMPLATE'=>	'Edit',
  'LBL_FROM_MAILBOX'=>'From Mailbox',
  'LBL_FROM_MAILBOX_NAME'=>'From Mailbox:',
  'LBL_PROSPECT_LIST_SUBPANEL_TITLE'=>'Prospect Lists',	
  'LBL_ALL_PROSPECT_LISTS'=>'All Prospect Lists in the Campaign.',
  'LBL_RELATED_PROSPECT_LISTS'=>'All Prospect Lists related to this message.',
  'LBL_PROSPECT_LIST_NAME'=>'Prospect List Name',
  'LBL_LIST_PROSPECT_LIST_NAME'=>'Targeted Prospect Lists',
  'LBL_MODULE_SCHEDULE_TITLE'=>'Campaign: Scheduling',
  'SCHEDULE_MESSAGE'=>'Please select the campaign messages that you would like to schedule:',
  'LBL_SCHEDULE_BUTTON_TITLE'=>'Schedule',
  'LBL_SCHEDULE_BUTTON_LABEL'=>'Schedule',
  'LBL_SCHEDULE_BUTTON_KEY'=>'T',
  
  
  
);
?>
