<?PHP
if(!is_admin($current_user)){
	sugar_die('No Access');
}
?>
<form action="index.php" method="post" name="DetailView" id="form">

			<input type="hidden" name="module" value="Users">
			<input type="hidden" name="user_id" value="">
			<input type="hidden" name="record" value="<?PHP echo $record; ?>">
			<input type="hidden" name="isDuplicate" value=''>
			
			
			<input type="hidden" name="action">
</form>

<?PHP
$record = '';
if(isset($_REQUEST['record'])) $record = $_REQUEST['record'];
$users = get_user_array(true, "Active", $record);
echo "<form name='Users'>
<input type='hidden' name='action' value='ListRoles'>
<input type='hidden' name='module' value='Users'>
<select name='record' onchange='document.Users.submit();'>";
echo get_select_options_with_id($users, $record);
echo "</select></form>";
if(!empty($record)){
	require_once('modules/ACLRoles/DetailUserRole.php');
	
}


?>
