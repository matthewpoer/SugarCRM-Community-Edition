<?PHP
require_once('modules/ACL/ACLController.php');
$role = new ACLRole();
if(isset($_REQUEST['record'])){
	$role->mark_deleted($_REQUEST['record']);
}
require_once('include/formbase.php');
handleRedirect();

?>
