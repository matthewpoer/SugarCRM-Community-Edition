<?PHP
global $mod_strings;
$module_menu = Array(
	Array("index.php?module=ACLRoles&action=index", $mod_strings['LIST_ROLES'],"Roles"),
	Array("index.php?module=ACLRoles&action=ListUsers", $mod_strings['LIST_ROLES_BY_USER'],"Roles"),
	Array("index.php?module=ACLRoles&action=EditView", $mod_strings['LBL_CREATE_ROLE'],"Roles"),
	
	);
?>
