<?PHP


require_once('modules/ACL/ACLController.php');
$role = new ACLRole();
$role->name = $_POST['name'];
if(isset($_REQUEST['record']))$role->id = $_POST['record'];
$role->description = $_POST['description'];
$role->save();
foreach($_POST as $name=>$value){
	if(substr_count($name, 'act_guid') > 0){
		$name = str_replace('act_guid', '', $name);

		$role->setAction($role->id,$name, $value);
	}
}
header("Location:index.php?module=ACLRoles&action=DetailView&record=". $role->id);
?>
