<?PHP
require_once('include/Sugar_Smarty.php');
require_once('modules/ACL/ACLController.php');
$sugar_smarty = new Sugar_Smarty();
$sugar_smarty->assign('MOD', $mod_strings);
$sugar_smarty->assign('APP', $app_strings);
$role = new ACLRole();
$role->retrieve($_REQUEST['record']);
$categories = ACLRole::getRoleActions($_REQUEST['record']);
$tdwidth = 10;
$names = ACLAction::setupCategoriesMatrix($categories);
	

$sugar_smarty->assign('ROLE', $role->toArray());
$sugar_smarty->assign('CATEGORIES', $categories);
$sugar_smarty->assign('TDWIDTH', $tdwidth);
$sugar_smarty->assign('ACTION_NAMES', $names);

$return= array('module'=>'ACLRoles', 'action'=>'index', 'record'=>'');
if(isset($_REQUEST['return_module'])){
	$return['module']=$_REQUEST['return_module'];
	if(isset($_REQUEST['return_action']))$return['action']=$_REQUEST['return_action'];
	if(isset($_REQUEST['return_record']))$return['record']=$_REQUEST['return_recrod'];
}
$sugar_smarty->assign('RETURN', $return);
$title = get_module_title( '',$mod_strings['LBL_ROLE'].':'. $role->name, '');
$sugar_smarty->assign('TITLE', $title);
$hide_hide_supanels = true;
echo $sugar_smarty->fetch('modules/ACLRoles/DetailView.tpl');
//for subpanels the variable must be named focus;
$focus =& $role;
$_REQUEST['module'] = 'ACLRoles';
require_once('include/SubPanel/SubPanelTiles.php');

$subpanel = new SubPanelTiles($role, 'ACLRoles');

echo $subpanel->display();
?>
