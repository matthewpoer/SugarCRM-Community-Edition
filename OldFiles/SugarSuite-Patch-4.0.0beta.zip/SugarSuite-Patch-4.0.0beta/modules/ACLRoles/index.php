<?PHP
if(!is_admin($current_user)){
	sugar_die('No Access');
}
require_once('modules/ACLRoles/ListView.php');
?>
