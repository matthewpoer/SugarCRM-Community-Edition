<?PHP
$mod_strings = array (

'LBL_ROLE'=>'Role',
'LBL_NAME'=>'Name',
'LBL_DESCRIPTION'=>'Description',
'LIST_ROLES'=>'List Roles',
'LBL_USERS_SUBPANEL_TITLE'=>'Users',
'LIST_ROLES_BY_USER'=>'List Roles By User',
'LBL_ROLES_SUBPANEL_TITLE'=>'User Roles',
'LBL_SEARCH_FORM_TITLE'=>'Search',
'LBL_CREATE_ROLE'=>'Create Role',
'LBL_EDIT_VIEW_DIRECTIONS'=>'Double click on a cell to change value.',
)
?>
