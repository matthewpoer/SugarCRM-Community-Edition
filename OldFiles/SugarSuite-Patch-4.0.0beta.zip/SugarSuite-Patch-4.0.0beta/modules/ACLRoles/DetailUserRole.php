<?PHP
require_once('include/Sugar_Smarty.php');
require_once('modules/ACL/ACLController.php');
$sugar_smarty = new Sugar_Smarty();
$sugar_smarty->assign('MOD', $mod_strings);
$sugar_smarty->assign('APP', $app_strings);


$categories = ACLAction::getUserActions($_REQUEST['record'],true);

$names = array();
$tdwidth = 10;
$names = ACLAction::setupCategoriesMatrix($categories);

$sugar_smarty->assign('CATEGORIES', $categories);
$sugar_smarty->assign('TDWIDTH', $tdwidth);
$sugar_smarty->assign('ACTION_NAMES', $names);

$title = get_module_title( '',$mod_strings['LBL_ROLES_SUBPANEL_TITLE'], '');
$focus = new User();
$focus->retrieve($_REQUEST['record']);
$sugar_smarty->assign('TITLE', $title);
$sugar_smarty->assign('USER_ID', $focus->id);
$sugar_smarty->assign('LAYOUT_DEF_KEY', 'UserRoles');
echo $sugar_smarty->fetch('modules/ACLRoles/DetailViewUser.tpl');


//this gets its layout_defs.php file from the user not from ACLRoles so look in modules/Users for the layout defs
require_once('include/SubPanel/SubPanelTiles.php');
$modules_exempt_from_availability_check=array('Users'=>'Users','ACLRoles'=>'ACLRoles',);
$subpanel = new SubPanelTiles($focus, 'UserRoles');

echo $subpanel->display();



?>
