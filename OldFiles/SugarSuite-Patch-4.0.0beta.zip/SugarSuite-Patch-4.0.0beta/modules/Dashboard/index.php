<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: index.php,v 1.61 2005/12/01 03:40:08 wayne Exp $
 * Description:  Main file for the Home module.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

global $app_strings;
global $app_list_strings;
global $mod_strings;
global $theme;
global $currentModule;

$theme_path="themes/".$theme."/";
$image_path=$theme_path."images/";
require_once($theme_path.'layout_utils.php');
require_once('log4php/LoggerManager.php');
require_once('modules/Charts/code/predefined_charts.php');
echo "<p>\n";
echo get_module_title($mod_strings['LBL_MODULE_NAME'], $mod_strings['LBL_MODULE_TITLE'], true); 
echo "\n</p>\n";


?>
<script type="text/javascript" language="JavaScript">
<!-- Begin
function toggleDisplay(id){

	if(this.document.getElementById( id).style.display=='none'){
		this.document.getElementById( id).style.display='inline'
		if(this.document.getElementById(id+"link") != undefined){
			this.document.getElementById(id+"link").style.display='none';
		}

	}else{
		this.document.getElementById(  id).style.display='none'
		if(this.document.getElementById(id+"link") != undefined){
			this.document.getElementById(id+"link").style.display='inline';
		}
	}
}
		//  End -->
// WARNING: this function is repeated in Reports/templates/templates_report_functions_js.php for charts within Reports.
// This "saved_chart_drilldown" is run when a graph is clicked from the dashboard. 
function saved_chart_drilldown(group_value,group_key,id)
{
       var report_url = 'index.php?module=Reports&page=report&action=index&id='+id+'#'+group_value;
       document.location = report_url;
}

	</script>

<?php
require_once('modules/Dashboard/Dashboard.php');
$dashboard = new Dashboard();
$users_dashboard = $dashboard->getUsersTopDashboard($current_user->id);
$dashboard_def = unserialize(from_html($users_dashboard->content));

print_add($users_dashboard->id,$dashboard_def);

$count = 0;
// if the user has changed the theme then refresh all charts
if($_SESSION['theme_changed'] || $theme != $current_user->getPreference('lastTheme')) { 
	$_REQUEST['pbss_refresh'] = 'true';
	$_REQUEST['lsbo_refresh'] = 'true';
	$_REQUEST['pbls_refresh'] = 'true';
	$_REQUEST['mypbss_refresh'] = 'true';
	$_REQUEST['obm_refresh'] = 'true';
}
foreach ($dashboard_def as $def)
{
  print_chart_header($users_dashboard->id, $count);
	if ( $def['type'] == 'code')
	{
		$func = $def['id'];
    global $currentModule; 
    $currentModule = 'Dashboard';
		require_once ("modules/Charts/code/".$func.".php");
		call_user_func($func);


































			
	}
  $count++;
}

function print_chart_header($dashboard_id, $chart_index)
{
 global $image_path,$mod_strings;
?>
<table width="100%" cellspacing="0" cellpadding="0" border="0">
<tr>
    <td align="right"><nobr>
<a href="index.php?return_action=<?php echo $_REQUEST['action'];?>&return_module=Dashboard&action=EditDashboard&dashboard_action=move_up&module=Dashboard&chart_index=<?Php echo $chart_index; ?>&record=<?php echo $dashboard_id; ?>"><?php echo get_image($image_path."uparrow",'border="0" align="absmiddle" alt="'.$mod_strings['LBL_MOVE_UP'].'"');?></a>
<a href="index.php?return_action=<?php echo $_REQUEST['action'];?>&return_module=Dashboard&action=EditDashboard&dashboard_action=move_down&module=Dashboard&chart_index=<?Php echo $chart_index; ?>&record=<?php echo $dashboard_id; ?>"><?php echo get_image($image_path."downarrow",'border="0" align="absmiddle" alt="'.$mod_strings['LBL_MOVE_DOWN'].'"');?></a>
<a href="index.php?return_action=<?php echo $_REQUEST['action'];?>&return_module=Dashboard&action=EditDashboard&dashboard_action=delete&module=Dashboard&chart_index=<?Php echo $chart_index; ?>&record=<?php echo $dashboard_id; ?>" class="listViewTdToolsS1"><?php echo get_image($image_path."close",'border="0" align="absmiddle" alt="'.$mod_strings['LBL_DELETE_FROM_DASHBOARD'].'"');?></a>
</nobr></td>
</tr>
</table>
<?php

}

function print_add($dashboard_id,&$dashboard_def)
{
  $chart_map = array();
  foreach($dashboard_def as $def)
  {
      $chart_map[$def['id']] = 1;
  }
 global $image_path,$mod_strings,$predefined_charts;
print $mod_strings['LBL_ADD_A_CHART'].":&nbsp;";
?>

<script language="javascript">
function add_chart(chart_index,chart_id,dashboard_id)
{
 var arr = chart_id.split('|');
 if (arr[0] == 'nothing')
 {
   return true;
 }
window.location="index.php?return_action=index&return_module=Dashboard&action=EditDashboard&module=Dashboard&dashboard_action=add&chart_index="+chart_index+"&chart_type="+arr[0]+"&chart_id="+arr[1]+"&record="+dashboard_id;
}
</script>
<style>
.do_nothing{font-weight: bold;}
</style>

<?php

print '<select name="add_chart" onchange="add_chart(0,this.options[this.selectedIndex].value,\''.$dashboard_id.'\')">';

print '<option value="nothing|" class="do_nothing" SELECTED>-- Basic Charts --</option>';

foreach ($predefined_charts as $chart)
{
  if ( ! empty($chart_map[$chart['id']]))
  {
    continue;
  }
  print '<option value="code|'.$chart['id'].'">'.$chart['label'].'</option>';
}
































print '</select>';



}

?>
