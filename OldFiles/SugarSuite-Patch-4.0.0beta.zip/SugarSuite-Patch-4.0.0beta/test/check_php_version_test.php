<?php
// $Id: check_php_version_test.php,v 1.2 2005/11/28 20:01:57 andrew Exp $

chdir('..');
require_once('include/utils.php');

class CheckPHPVersionTestCase extends UnitTestCase
{
	function CheckPHPVersionTestCase()
	{
		$this->UnitTestCase('CheckPHPVersion function tests');
	}

	function setUp()
	{
	}

	function tearDown()
	{
	}

	function test_min_ver()
	{
		$ver = '4.3.0';
		$retval = check_php_version($ver);
		$expected_retval = 1;

		$this->assertEqual($expected_retval, $retval,
			'Minimum version check failed.');
	}

	function test_max_ver()
	{
		$ver = '5.0.4';
		$retval = check_php_version($ver);
		$expected_retval = 1;

		$this->assertEqual($expected_retval, $retval,
			'Maximum version check failed.');
	}

	function test_invalid_ver_5_0_5()
	{
		$ver = '5.0.5';
		$retval = check_php_version($ver);
		$expected_retval = -1;

		$this->assertEqual($expected_retval, $retval,
			'Invalid version check failed.');
	}

	function test_unsupported_ver_4_4_0()
	{
		$ver = '4.4.0';
		$retval = check_php_version($ver);
		$expected_retval = 0;

		$this->assertEqual($expected_retval, $retval,
			'Unsupported version check failed.');
	}

	function test_unsupported_future_ver()
	{
		$ver = '7.9.5';
		$retval = check_php_version($ver);
		$expected_retval = 0;

		$this->assertEqual($expected_retval, $retval,
			'Unsupported version check failed.');
	}
}

chdir('test');

?>
