<?php
// $Id: all_unit_tests.php,v 1.2 2005/10/21 00:16:22 wayne Exp $

if (! defined('TEST'))
{
	define('TEST', __FILE__);
}

require_once('simpletest/unit_tester.php');
require_once('simpletest/web_tester.php');
require_once('simpletest/shell_tester.php');
require_once('simpletest/reporter.php');
require_once('simpletest/mock_objects.php');
require_once('SugarReporter.php');

class AllUnitTests extends GroupTest
{
	function _get_all_test_files()
	{
		$all_test_files = array();

		// matches files like 'timedate_test.php'
		$pattern = '/.*_test.php$/';

		$this_dir = dir('.');
		while ($file = $this_dir->read())
		{
			if (preg_match($pattern, $file))
			{
				$all_test_files[] = $file;
			}
		}

		return $all_test_files;
	}

	function AllUnitTests()
	{
		$this->GroupTest('All Sugar Unit Tests');

		$all_test_files = $this->_get_all_test_files();
		foreach($all_test_files as $test_file)
		{
			$this->addTestFile($test_file);
		}
	}
}

if (TEST == __FILE__)
{
	$test = new AllUnitTests();

	if (SimpleReporter::inCli())
	{
		exit ($test->run(new TextReporter()) ? 0 : 1);
	}

	$test->run(new SugarReporter());
}

?>
