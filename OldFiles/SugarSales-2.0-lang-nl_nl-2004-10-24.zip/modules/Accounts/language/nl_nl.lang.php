<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/include/language/en_us.lang.php,v 1.89 2004/10/25 02:32:20 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Bedrijven',
  'LBL_MODULE_TITLE' => 'Bedrijven: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Bedrijven Zoeken',
  'LBL_LIST_FORM_TITLE' => 'Lijst met Bedrijven',
  'LBL_NEW_FORM_TITLE' => 'Nieuw Bedrijf',
  'LBL_MEMBER_ORG_FORM_TITLE' => 'Lid van Organisatie',
  'LBL_LIST_ACCOUNT_NAME' => 'Bedrijf Naam',
  'LBL_LIST_CITY' => 'Plaats',
  'LBL_LIST_WEBSITE' => 'Website',
  'LBL_LIST_STATE' => 'Provincie',
  'LBL_LIST_PHONE' => 'Telefoon',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email Adres',
  'LBL_LIST_CONTACT_NAME' => 'Contact Naam',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_website' => 'LBL_LIST_WEBSITE',
  'db_billing_address_city' => 'LBL_LIST_CITY',
//END DON'T CONVERT
  'LBL_ACCOUNT_INFORMATION' => 'Account Information',
  'LBL_ACCOUNT' => 'Bedrijf:',
  'LBL_ACCOUNT_NAME' => 'Bedrijf Naam:',
  'LBL_PHONE' => 'Telefoon:',
  'LBL_WEBSITE' => 'Website:',
  'LBL_FAX' => 'Fax:',
  'LBL_TICKER_SYMBOL' => 'Beurs Symbool:',
  'LBL_OTHER_PHONE' => 'Alternatieve Telefoon:',
  'LBL_ANY_PHONE' => 'Andere Telefoon:',
  'LBL_MEMBER_OF' => 'Lid Van:',
  'LBL_EMAIL' => 'Email:',
  'LBL_EMPLOYEES' => 'Werknemers:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Alternatieve Email:',
  'LBL_ANY_EMAIL' => 'Andere Email:',
  'LBL_OWNERSHIP' => 'Eigenaar:',
  'LBL_RATING' => 'Beoordeling:',
  'LBL_INDUSTRY' => 'Industrie:',
  'LBL_SIC_CODE' => 'SIC Code:',
  'LBL_TYPE' => 'Type:',
  'LBL_ANNUAL_REVENUE' => 'Jaarlijks Inkomen:',
  'LBL_ADDRESS_INFORMATION' => 'Adres Informatie',
  'LBL_BILLING_ADDRESS' => 'Factuur Adres:',
  'LBL_SHIPPING_ADDRESS' => 'Aflever Adres:',
  'LBL_ANY_ADDRESS' => 'Ander Adres:',
  'LBL_CITY' => 'Plaats:',
  'LBL_STATE' => 'Provincie:',
  'LBL_POSTAL_CODE' => 'Postcode:',
  'LBL_COUNTRY' => 'Land:',
  'LBL_DESCRIPTION_INFORMATION' => 'Beschrijving Informatie',
  'LBL_DESCRIPTION' => 'Beschrijving:',
  'NTC_COPY_BILLING_ADDRESS' => 'Kopieer Faktuuradres naar Afleveradres',
  'NTC_COPY_SHIPPING_ADDRESS' => 'Kopieer Afleveradres naar Faktuur Adres',
  'NTC_REMOVE_MEMBER_ORG_CONFIRMATION' => 'Weet u zeker dat u dit record wilt verwijderen als lid van deze organisatie',
  'LBL_DUPLICATE' => 'Possible Duplicate Account',
  'MSG_DUPLICATE' => 'Creating this account may potentialy create a duplicate account. You may either select an account from the list below or you may click on Create New Account to continue creating a new account with the previously entered data.',
  'LNK_NEW_ACCOUNT' => 'Nieuw Bedrijf',
  'LNK_ACCOUNT_LIST' => 'Accounts',
  'LBL_INVITEE' => 'Contactpersonen',
  'ERR_DELETE_RECORD' => 'Er moet een record nummer zijn gespecificeerd om dit bedrijf te verwijderen.',
  'LNK_NEW_CONTACT' => 'Nieuw Contact',
  'LNK_NEW_OPPORTUNITY' => 'Nieuwe Kans',
  'LNK_NEW_CASE' => 'Nieuwe Zaak',
  'LNK_NEW_NOTE' => 'Nieuwe Notitie',
  'LNK_NEW_CALL' => 'Nieuw Telefoon Gesprek',
  'LNK_NEW_EMAIL' => 'Nieuwe Email',
  'LNK_NEW_MEETING' => 'Nieuwe Afspraak',
  'LNK_NEW_TASK' => 'Nieuwe Taak',
);


?>