<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/include/language/en_us.lang.php,v 1.89 2004/10/25 02:32:20 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Gebruikers',
  'LBL_MODULE_TITLE' => 'Gebruikers: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Gebruikers Zoeken',
  'LBL_LIST_FORM_TITLE' => 'Gebruikers Lijst',
  'LBL_NEW_FORM_TITLE' => 'Nieuwe Gebruiker',
  'LBL_USER' => 'Gebruikers:',
  'LBL_LOGIN' => 'Inloggen',
  'LBL_RESET_PREFERENCES' => 'Zet de standaard voorkeuren terug',
  'LBL_TIME_FORMAT' => 'Time Format:',
  'LBL_CURRENCY' => 'Currency:',
  'LBL_LIST_NAME' => 'Naam',
  'LBL_LIST_LAST_NAME' => 'Achter Naam',
  'LBL_LIST_USER_NAME' => 'Gebruikers Naam',
  'LBL_LIST_DEPARTMENT' => 'Afdeling',
  'LBL_LIST_EMAIL' => 'Email',
  'LBL_LIST_PRIMARY_PHONE' => 'Hoofd Telefoon',
  'LBL_LIST_ADMIN' => 'Beheerder',
  'LBL_NEW_USER_BUTTON_TITLE' => 'Nieuwe Gebruiker [Alt+N]',
  'LBL_NEW_USER_BUTTON_LABEL' => 'Nieuwe Gebruiker',
  'LBL_NEW_USER_BUTTON_KEY' => 'N',
  'LBL_ERROR' => 'Foutmelding:',
  'LBL_PASSWORD' => 'Paswoord:',
  'LBL_USER_NAME' => 'Gebruikers Naam:',
  'LBL_FIRST_NAME' => 'Voor Naam:',
  'LBL_LAST_NAME' => 'Achter Naam:',
  'LBL_USER_SETTINGS' => 'Gebruikers Instellingen',
  'LBL_THEME' => 'Thema:',
  'LBL_LANGUAGE' => 'Taal:',
  'LBL_ADMIN' => 'Beheerder:',
  'LBL_USER_INFORMATION' => 'Gebruiker Informatie',
  'LBL_OFFICE_PHONE' => 'Kantoor Telefoon:',
  'LBL_REPORTS_TO' => 'Rapporteert aan:',
  'LBL_OTHER_PHONE' => 'Anders:',
  'LBL_OTHER_EMAIL' => 'Alternatieve Email:',
  'LBL_NOTES' => 'Notities:',
  'LBL_DEPARTMENT' => 'Afdeling:',
  'LBL_STATUS' => 'Status:',
  'LBL_TITLE' => 'Titel:',
  'LBL_ANY_PHONE' => 'Andere Telefoon:',
  'LBL_ANY_EMAIL' => 'Andere Email:',
  'LBL_ADDRESS' => 'Adres:',
  'LBL_CITY' => 'Plaats:',
  'LBL_STATE' => 'Provincie:',
  'LBL_POSTAL_CODE' => 'Postcode:',
  'LBL_COUNTRY' => 'Land:',
  'LBL_NAME' => 'Naam:',
  'LBL_MOBILE_PHONE' => 'Mobiel:',
  'LBL_OTHER' => 'Anders:',
  'LBL_FAX' => 'Fax:',
  'LBL_EMAIL' => 'Email:',
  'LBL_HOME_PHONE' => 'Thuis Telefoon:',
  'LBL_ADDRESS_INFORMATION' => 'Adres Informatie',
  'LBL_PRIMARY_ADDRESS' => 'Hoofd Adres:',
  'LBL_CHANGE_PASSWORD_BUTTON_TITLE' => 'Change Password [Alt+P]',
  'LBL_CHANGE_PASSWORD_BUTTON_KEY' => 'P',
  'LBL_CHANGE_PASSWORD_BUTTON_LABEL' => 'Change Password',
  'LBL_LOGIN_BUTTON_TITLE' => 'Login [Alt+L]',
  'LBL_LOGIN_BUTTON_KEY' => 'L',
  'LBL_LOGIN_BUTTON_LABEL' => 'Login',
  'LBL_CHANGE_PASSWORD' => 'Wijzig Paswoord',
  'LBL_OLD_PASSWORD' => 'Oude Paswoord:',
  'LBL_NEW_PASSWORD' => 'Nieuwe Paswoord:',
  'LBL_CONFIRM_PASSWORD' => 'Bevestig Paswoord:',
  'ERR_ENTER_OLD_PASSWORD' => 'Voer uw oude paswoord nogmaals in a.u.b.',
  'ERR_ENTER_NEW_PASSWORD' => 'Voer uw nieuwe paswoord in a.u.b.',
  'ERR_ENTER_CONFIRMATION_PASSWORD' => 'Bevestig uw paswoord a.u.b.',
  'ERR_REENTER_PASSWORDS' => 'Voer uw paswoorden nogmaals in a.u.b.  De \\"Nieuwe Paswoord\\" en \\"Bevestig Paswoord\\" komen niet overeen.',
  'ERR_INVALID_PASSWORD' => 'U moet een geldige gebruikersnaam en paswoord invoeren.',
  'ERR_PASSWORD_CHANGE_FAILED_1' => 'Gebruikers paswoord wijziging is niet gelukt ',
  'ERR_PASSWORD_CHANGE_FAILED_2' => ' Niet Gelukt.  Het nieuwe paswoord moet worden ingevoerd.',
  'ERR_PASSWORD_INCORRECT_OLD' => 'Het oude paswoord is niet correct. Het oude paswoord voor de Gebruiker $this->user_name. Voer nogmaals de paswoord informatie in .',
  'ERR_USER_NAME_EXISTS_1' => 'De gebruikers Naam ',
  'ERR_USER_NAME_EXISTS_2' => ' Bestaat al. Het is niet toegestaan om gelijke gebruikersnamen te gebruiken.<br>Maak de nieuwe Gebruikers Naam uniek.',
  'ERR_LAST_ADMIN_1' => 'De Gebruikers Naam ',
  'ERR_LAST_ADMIN_2' => ' is de laatse Beheerder. Er moet op zijn minst 1 beheerder zijn.<br> Controleer de instellingen van de Gebruiker die tevens als beheerder fungeert.',
  'LNK_NEW_USER' => 'New User',
  'LNK_USER_LIST' => 'Users',
  'ERR_DELETE_RECORD' => 'Er moet een record nummer zijn gespecificeerd om deze gebruiker te verwijderen.',
  'LBL_RECEIVE_NOTIFICATIONS' => 'Assignment Notification:',
  'LBL_RECEIVE_NOTIFICATIONS_TEXT' => 'Receive an e-mail notification when a record is assigned to you.',
  'LBL_ADMIN_TEXT' => 'Grants administrator privileges to this user',
  'LBL_TIME_FORMAT_TEXT' => 'Set the display format for time stamps',
  'LBL_GRIDLINE' => 'Show Gridlines:',
  'LBL_GRIDLINE_TEXT' => 'Controls gridlines on detail views',
  'LBL_CURRENCY_TEXT' => 'Select the default currency',
  'LBL_YAHOO_ID' => 'Yahoo ID:',
  'LNK_NEW_CONTACT' => 'Nieuw Contact',
  'LNK_NEW_ACCOUNT' => 'Nieuw Bedrijf',
  'LNK_NEW_OPPORTUNITY' => 'Nieuwe Kans',
  'LNK_NEW_CASE' => 'Nieuwe Zaak',
  'LNK_NEW_NOTE' => 'Nieuwe Notitie',
  'LNK_NEW_CALL' => 'Nieuw Telefoon Gesprek',
  'LNK_NEW_EMAIL' => 'Nieuwe Email',
  'LNK_NEW_MEETING' => 'Nieuwe Afspraak',
  'LNK_NEW_TASK' => 'Nieuwe Taak',
);


?>