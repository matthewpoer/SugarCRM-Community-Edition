<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.2 2004/10/29 15:59:25 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_NEW_FORM_TITLE' => 'Nuovo Contatto',
  'LBL_FIRST_NAME' => 'Nome:',
  'LBL_LAST_NAME' => 'Cognome:',
  'LBL_LIST_LAST_NAME' => 'Cognome',
  'LBL_PHONE' => 'Telefono:',
  'LBL_EMAIL_ADDRESS' => 'Email:',
  'LBL_PIPELINE_FORM_TITLE' => 'Il mio portafoglio',
  'LNK_NEW_CONTACT' => 'Nuovo Contatto',
  'LNK_NEW_ACCOUNT' => 'Nuovo Cliente',
  'LNK_NEW_OPPORTUNITY' => 'Nuova Opportunità',
  'LNK_NEW_LEAD' => 'Create Lead',
  'LNK_NEW_CASE' => 'Nuovo Ticket Supporto',
  'LNK_NEW_NOTE' => 'Nuova Nota',
  'LNK_NEW_CALL' => 'Nuova Chiamata',
  'LNK_NEW_EMAIL' => 'Nuova Email',
  'LNK_NEW_MEETING' => 'Nuova Riunione',
  'LNK_NEW_TASK' => 'Nuovo Task',
  'ERR_ONE_CHAR' => 'Per favore inserisci almeno una lettera o un numero per la ricerca ...',
  'LBL_OPEN_TASKS' => 'I miei task aperti',
  'LBL_TOTAL_PIPELINE' => 'Il montante totale di portafoglio è ',
  'LBL_OPP_SIZE' => 'Volume in KEur.',
);


?>