<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.2 2004/10/29 15:59:25 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Cuentas',
  'LBL_MODULE_TITLE' => 'Cuentas: Inicio',
  'LBL_SEARCH_FORM_TITLE' => 'B�squeda Cuentas',
  'LBL_LIST_FORM_TITLE' => 'Lista Cuentas',
  'LBL_NEW_FORM_TITLE' => 'Nueva Cuenta',
  'LBL_MEMBER_ORG_FORM_TITLE' => 'Organizaciones Miembro',
  'LBL_LIST_ACCOUNT_NAME' => 'Nombre Cuenta',
  'LBL_LIST_CITY' => 'Ciudad',
  'LBL_LIST_WEBSITE' => 'Website',
  'LBL_LIST_STATE' => 'Estado',
  'LBL_LIST_PHONE' => 'Tel�fono',
  'LBL_LIST_EMAIL_ADDRESS' => '*Email Address',
  'LBL_LIST_CONTACT_NAME' => '*Contact Name',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_website' => 'LBL_LIST_WEBSITE',
  'db_billing_address_city' => 'LBL_LIST_CITY',
//END DON'T CONVERT
  'LBL_ACCOUNT_INFORMATION' => '*Account Information',
  'LBL_ACCOUNT' => 'Cuenta:',
  'LBL_ACCOUNT_NAME' => 'Nombre Cuenta:',
  'LBL_PHONE' => 'Tel�fono:',
  'LBL_WEBSITE' => 'Website:',
  'LBL_FAX' => 'Fax:',
  'LBL_TICKER_SYMBOL' => 'S�mbolo:',
  'LBL_OTHER_PHONE' => 'Otro Tel�fono:',
  'LBL_ANY_PHONE' => 'Cualquier Tel�fono:',
  'LBL_MEMBER_OF' => 'Miembro de:',
  'LBL_EMAIL' => 'Email:',
  'LBL_EMPLOYEES' => 'Empleados:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Otro Email:',
  'LBL_ANY_EMAIL' => 'Cualquier Email:',
  'LBL_OWNERSHIP' => 'Due�o:',
  'LBL_RATING' => 'Rating:',
  'LBL_INDUSTRY' => 'Industria:',
  'LBL_SIC_CODE' => 'C�digo SIC:',
  'LBL_TYPE' => 'Tipo:',
  'LBL_ANNUAL_REVENUE' => 'Ventas Anuales:',
  'LBL_ADDRESS_INFORMATION' => 'Direcci�n',
  'LBL_BILLING_ADDRESS' => 'Direcci�n Cobranza:',
  'LBL_SHIPPING_ADDRESS' => 'Direcci�n Env�o:',
  'LBL_ANY_ADDRESS' => 'Cualquier Direcci�n:',
  'LBL_CITY' => 'Ciudad:',
  'LBL_STATE' => 'Estado:',
  'LBL_POSTAL_CODE' => 'C�digo Postal:',
  'LBL_COUNTRY' => 'Pa�s:',
  'LBL_DESCRIPTION_INFORMATION' => 'Informaci�n Descriptiva',
  'LBL_DESCRIPTION' => 'Descripci�n:',
  'NTC_COPY_BILLING_ADDRESS' => 'Copiar direcci�n cobranza a direcci�n de env�o',
  'NTC_COPY_SHIPPING_ADDRESS' => 'Copiar direcci�n de env�o a direcci�n de cobranza',
  'NTC_REMOVE_MEMBER_ORG_CONFIRMATION' => '�Est� seguro que desea remover este registro como organizaci�n miembro?',
  'LBL_DUPLICATE' => 'Possible Duplicate Account',
  'MSG_DUPLICATE' => 'Creating this account may potentialy create a duplicate account. You may either select an account from the list below or you may click on Create New Account to continue creating a new account with the previously entered data.',
  'LNK_NEW_ACCOUNT' => 'Nueva Cuenta',
  'LNK_ACCOUNT_LIST' => 'Accounts',
  'LBL_INVITEE' => '*Contacts',
  'ERR_DELETE_RECORD' => 'Un n�mero de registro debe ser especificado para borrar la cuenta.',
  'LNK_NEW_CONTACT' => 'Nuevo Contacto',
  'LNK_NEW_OPPORTUNITY' => 'Nueva Oportunidad',
  'LNK_NEW_CASE' => 'Nuevo Caso',
  'LNK_NEW_NOTE' => 'Nueva Nota',
  'LNK_NEW_CALL' => 'Nueva Llamada',
  'LNK_NEW_EMAIL' => 'Nuevo Email',
  'LNK_NEW_MEETING' => 'Nueva Reuni�n',
  'LNK_NEW_TASK' => 'Nueva Tarea',
);


?>