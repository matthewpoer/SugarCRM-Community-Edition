<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Calendar',
  'LBL_MODULE_TITLE' => 'Calendar',
  'LNK_NEW_CALL' => 'Crear Llamada',
  'LNK_NEW_MEETING' => 'Crear Reunion',
  'LNK_NEW_APPOINTMENT' => 'Crear Recordatorio',
  'LNK_NEW_TASK' => 'Crear Tarea',
  'LNK_CALL_LIST' => 'Llamadas',
  'LNK_MEETING_LIST' => 'Reuniones',
  'LNK_TASK_LIST' => 'Tareas',
  'LNK_VIEW_CALENDAR' => 'Hoy',
  'LBL_MONTH' => 'Mes',
  'LBL_DAY' => 'Dia',
  'LBL_YEAR' => 'A�o',
  'LBL_WEEK' => 'Semana',
  'LBL_PREVIOUS_MONTH' => 'Mes Anterior',
  'LBL_PREVIOUS_DAY' => 'D�a Anterior',
  'LBL_PREVIOUS_YEAR' => 'A�o Anterior',
  'LBL_PREVIOUS_WEEK' => 'Semana Anterior',
  'LBL_NEXT_MONTH' => 'Siguiente Mes',
  'LBL_NEXT_DAY' => 'Siguiente D�a',
  'LBL_NEXT_YEAR' => 'Siguiente A�o',
  'LBL_NEXT_WEEK' => 'Siguiente Semana',
  'LBL_AM' => 'AM',
  'LBL_PM' => 'PM',
  'LBL_SCHEDULED' => 'Agendado',
  'LBL_BUSY' => 'Ocupado',
  'LBL_CONFLICT' => 'Conflicto',
  'LBL_USER_CALENDARS' => 'Calendarios de Usuario',
);

$mod_list_strings = array (
  'dom_cal_weekdays' => 
  array (
    0 => 'Dom',
    1 => 'Lun',
    2 => 'Mar',
    3 => 'Mie',
    4 => 'Jue',
    5 => 'Vie',
    6 => 'Sab',
  ),
  'dom_cal_weekdays_long' => 
  array (
    0 => 'Domingo',
    1 => 'Lunes',
    2 => 'Martes',
    3 => 'Mi�rcoles',
    4 => 'Jueves',
    5 => 'Viernes',
    6 => 'S�bado',
  ),
  'dom_cal_month' => 
  array (
    0 => '',
    1 => 'Ene',
    2 => 'Feb',
    3 => 'Mar',
    4 => 'Abr',
    5 => 'May',
    6 => 'Jun',
    7 => 'Jul',
    8 => 'Ago',
    9 => 'Sep',
    10 => 'Oct',
    11 => 'Nov',
    12 => 'Dic',
  ),
  'dom_cal_month_long' => 
  array (
    0 => '',
    1 => 'Enero',
    2 => 'Febrero',
    3 => 'Marzo',
    4 => 'Abril',
    5 => 'Mayo',
    6 => 'Junio',
    7 => 'Julio',
    8 => 'Agosto',
    9 => 'Septiembre',
    10 => 'Octubre',
    11 => 'Noviembre',
    12 => 'Diciembere',
  ),
);


?>