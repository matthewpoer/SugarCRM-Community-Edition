<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Emails',
  'LBL_MODULE_TITLE' => 'Emails: Inicio',
  'LBL_SEARCH_FORM_TITLE' => 'B�squeda Email',
  'LBL_LIST_FORM_TITLE' => 'Lista Email',
  'LBL_NEW_FORM_TITLE' => 'Rastrear Email',
  'LBL_LIST_SUBJECT' => 'Asunto',
  'LBL_LIST_CONTACT' => 'Contacto',
  'LBL_LIST_RELATED_TO' => 'Relacionado a',
  'LBL_LIST_DATE' => 'Fecha Env�o',
  'LBL_LIST_TIME' => 'Hora Env��io',
  'ERR_DELETE_RECORD' => 'Un n�mero de registro debe ser indicado para borrar la cuenta.',
  'LBL_DATE_SENT' => 'Fecha Env�o:',
  'LBL_SUBJECT' => 'Asunto:',
  'LBL_BODY' => 'Cuerpo:',
  'LBL_DATE_AND_TIME' => 'Fecha y Hora Env�o:',
  'LBL_DATE' => 'Fecha Env�o:',
  'LBL_TIME' => 'Hora Env�o:',
  'LBL_CONTACT_NAME' => ' Nombre Contacto: ',
  'LBL_EMAIL' => 'Email:',
  'LBL_COLON' => ':',
  'NTC_REMOVE_INVITEE' => '�Est� seguro que desea este destinatario del email?',
  'LBL_INVITEE' => 'Destinatarios',
  'LNK_NEW_CALL' => 'Nueva Llamada',
  'LNK_NEW_MEETING' => 'Nueva Reuni�n',
  'LNK_NEW_TASK' => 'Nueva Tarea',
  'LNK_NEW_NOTE' => 'Nueva Nota',
  'LNK_NEW_EMAIL' => 'Nuevo Email',
  'LNK_CALL_LIST' => 'Calls',
  'LNK_MEETING_LIST' => 'Meetings',
  'LNK_TASK_LIST' => 'Tasks',
  'LNK_NOTE_LIST' => 'Notes',
  'LNK_EMAIL_LIST' => 'Emails',
  'LNK_VIEW_CALENDAR' => 'Today',
  'LNK_NEW_CONTACT' => 'Nuevo Contacto',
  'LNK_NEW_ACCOUNT' => 'Nueva Cuenta',
  'LNK_NEW_OPPORTUNITY' => 'Nueva Oportunidad',
  'LNK_NEW_CASE' => 'Nuevo Caso',
);


?>