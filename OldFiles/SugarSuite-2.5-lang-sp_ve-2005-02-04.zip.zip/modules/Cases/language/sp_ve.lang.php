<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Casos',
  'LBL_MODULE_TITLE' => 'Casos: Inicio',
  'LBL_SEARCH_FORM_TITLE' => 'B�squeda Casos',
  'LBL_LIST_FORM_TITLE' => 'Lista Casos',
  'LBL_NEW_FORM_TITLE' => 'Nuevo Caso',
  'LBL_CONTACT_CASE_TITLE' => 'Contato-Caso:',
  'LBL_SUBJECT' => 'Asunto:',
  'LBL_CASE' => 'Caso:',
  'LBL_CASE_NUMBER' => 'N�mero Caso:',
  'LBL_NUMBER' => 'N�mero:',
  'LBL_STATUS' => 'Estado:',
  'LBL_PRIORITY' => 'Priority:',
  'LBL_ACCOUNT_NAME' => 'Nombre Cuenta:',
  'LBL_DESCRIPTION' => 'Descripci�n:',
  'LBL_RESOLUTION' => 'Resolution:',
  'LBL_CONTACT_NAME' => 'Nombre Contacto:',
  'LBL_CASE_SUBJECT' => 'Asunto Caso:',
  'LBL_CONTACT_ROLE' => 'Rol:',
  'LBL_LIST_NUMBER' => 'Num.',
  'LBL_LIST_SUBJECT' => 'Asunto',
  'LBL_LIST_ACCOUNT_NAME' => 'Nombre Cuenta',
  'LBL_LIST_STATUS' => 'Estado',
  'LBL_LIST_PRIORITY' => 'Priority',
  'LBL_LIST_LAST_MODIFIED' => '�ltima Modificaci�n',
  'LBL_INVITEE' => '*Contacts',
  'LNK_NEW_CASE' => 'Nuevo Caso',
  'LNK_CASE_LIST' => 'Cases',
  'NTC_REMOVE_INVITEE' => '*Are you sure you want to remove this contact from the case?',
  'ERR_DELETE_RECORD' => 'Un n�mero de registro debe ser especificaco para borrar la cuenta.',
  'NTC_REMOVE_FROM_BUG_CONFIRMATION' => 'Are you sure you want to remove this case from this bug?',
  'LBL_LIST_CLOSE' => 'Close',
  'LBL_LIST_MY_CASES' => 'My Open Cases',
  'LNK_NEW_CONTACT' => 'Nuevo Contacto',
  'LNK_NEW_ACCOUNT' => 'Nueva Cuenta',
  'LNK_NEW_OPPORTUNITY' => 'Nueva Oportunidad',
  'LNK_NEW_NOTE' => 'Nueva Nota',
  'LNK_NEW_CALL' => 'Nueva Llamada',
  'LNK_NEW_EMAIL' => 'Nuevo Email',
  'LNK_NEW_MEETING' => 'Nueva Reuni�n',
  'LNK_NEW_TASK' => 'Nueva Tarea',
);


?>