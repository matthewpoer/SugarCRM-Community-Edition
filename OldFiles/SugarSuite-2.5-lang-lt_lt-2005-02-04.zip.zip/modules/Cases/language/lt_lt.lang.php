<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.4 2005/02/04 23:56:38 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Paklausimai',
  'LBL_MODULE_TITLE' => 'Paklausimai: prad�ia',
  'LBL_SEARCH_FORM_TITLE' => 'Paklausim� paie�ka',
  'LBL_LIST_FORM_TITLE' => 'Paklausim� s�ra�as',
  'LBL_NEW_FORM_TITLE' => 'Naujas paklausimas',
  'LBL_CONTACT_CASE_TITLE' => 'Kontaktas-paklausimas:',
  'LBL_SUBJECT' => 'Tema:',
  'LBL_CASE' => 'Paklausimas:',
  'LBL_CASE_NUMBER' => 'Paklausimo numeris:',
  'LBL_NUMBER' => 'Numeris:',
  'LBL_STATUS' => 'B�sena:',
  'LBL_PRIORITY' => 'Prioritetas:',
  'LBL_ACCOUNT_NAME' => 'Kliento pavadinimas:',
  'LBL_DESCRIPTION' => 'Apra�ymas:',
  'LBL_RESOLUTION' => 'Sprendimas:',
  'LBL_CONTACT_NAME' => 'Kontaktas:',
  'LBL_CASE_SUBJECT' => 'Paklausimo tema:',
  'LBL_CONTACT_ROLE' => 'Vaidmuo:',
  'LBL_LIST_NUMBER' => 'Nr.',
  'LBL_LIST_SUBJECT' => 'Tema',
  'LBL_LIST_ACCOUNT_NAME' => 'Kliento pavadinimas',
  'LBL_LIST_STATUS' => 'B�sena',
  'LBL_LIST_PRIORITY' => 'Prioritetas',
  'LBL_LIST_LAST_MODIFIED' => 'Pakeistas',
  'LBL_INVITEE' => 'Kontaktas',
  'LNK_NEW_CASE' => 'Sukurti paklausim�',
  'LNK_CASE_LIST' => 'Paklausimai',
  'NTC_REMOVE_INVITEE' => 'Ar tikrai norite panaikinti �� kontakt� i� paklausimo?',
  'ERR_DELETE_RECORD' => 'Kliento naikinimui turi b�ti nurodytas �ra�o numeris.',
  'NTC_REMOVE_FROM_BUG_CONFIRMATION' => 'Are you sure you want to remove this case from this bug?',
  'LBL_LIST_CLOSE' => 'U�daryti',
  'LBL_LIST_MY_CASES' => 'Mano atviri paklausimai',
);


?>