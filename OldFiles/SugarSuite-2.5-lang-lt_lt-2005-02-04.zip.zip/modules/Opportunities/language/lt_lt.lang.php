<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.4 2005/02/04 23:56:38 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Galimyb�s',
  'LBL_MODULE_TITLE' => 'Galimyb�s: prad�ia',
  'LBL_SEARCH_FORM_TITLE' => 'Galimybi� paie�ka',
  'LBL_LIST_FORM_TITLE' => 'Galimybi� s�ra�as',
  'LBL_OPPORTUNITY_NAME' => 'Galimyb�s pavadinimas:',
  'LBL_OPPORTUNITY' => 'Galimyb�:',
  'LBL_NAME' => 'Galimyb�s pavadinimas',
  'LBL_INVITEE' => 'Kontaktai',
  'LBL_LIST_OPPORTUNITY_NAME' => 'Galimyb�',
  'LBL_LIST_ACCOUNT_NAME' => 'Klientas',
  'LBL_LIST_AMOUNT' => 'Suma',
  'LBL_LIST_DATE_CLOSED' => 'Pabaiga',
  'LBL_LIST_SALES_STAGE' => 'Pardavimo etapas',
  'db_sales_stage' => 'LBL_LIST_SALES_STAGE',
  'db_name' => 'LBL_NAME',
  'db_amount' => 'LBL_LIST_AMOUNT',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_date_closed' => 'LBL_LIST_DATE_CLOSED',
  'UPDATE' => 'Galimyb� - Valiutos atnaujinimas',
  'UPDATE_DOLLARAMOUNTS' => 'Atnaujinti JAV doleri� sumas',
  'UPDATE_VERIFY' => 'Patikrinti sumas',
//END DON'T CONVERT
  'UPDATE_VERIFY_TXT' => 'Patikrina, kad sum� reik�m�s galimyb�se b�t� teisingi de�imtainiai skai�iai tik i� skaitmen� ir de�imt�j� (.)',
  'UPDATE_FIX' => 'Pataisyti sumas',
  'UPDATE_FIX_TXT' => 'Bando pataisyti neteisingas sumas sukuriant teisingas de�imtaines dalis nurodytoje sumoje. Tai i�saugo taisomas sumas duomen� baz�s lauke "amount_backup". Jei tai �vykd�te ir aptikote netikslum�, nekartokite �io veiksmo, neatstat� i�saugot� reik�mi�, kadangi i�saugotos reik�m�s bus perra�ytos neteisingais duomenimis.',
  'UPDATE_DOLLARAMOUNTS_TXT' => 'Atnaujinkite sumas JAV doleriais galimyb�se pagal dabartin� nustatyt� kurs�. �i vert� bus naudojama skai�iuojant grafikus ir per�i�rint s�ra�us.',
  'UPDATE_CREATE_CURRENCY' => 'Naujos valiutos suk�rimas:',
  'UPDATE_VERIFY_FAIL' => '�ra�o patikrinimo klaida:',
  'UPDATE_VERIFY_CURAMOUNT' => 'Dabartin� suma:',
  'UPDATE_VERIFY_FIX' => 'Pataisymas duot�',
  'UPDATE_INCLUDE_CLOSE' => '�traukti u�darytus �ra�us',
  'UPDATE_VERIFY_NEWAMOUNT' => 'Nauja suma:',
  'UPDATE_VERIFY_NEWCURRENCY' => 'Nauja valiuta:',
  'UPDATE_DONE' => 'Baigta',
  'UPDATE_BUG_COUNT' => 'Bugs Found and Attempted to Resolve:',
  'UPDATE_BUGFOUND_COUNT' => 'Bugs Found:',
  'UPDATE_COUNT' => '�ra�ai atnaujinti:',
  'UPDATE_RESTORE_COUNT' => 'Atstatyt� sum� �ra�ai:',
  'UPDATE_RESTORE' => 'Atstatyti sumas',
  'UPDATE_RESTORE_TXT' => 'Atstato sum� reik�mes i� i�saugot�, atliekant pataisymus.',
  'UPDATE_FAIL' => 'Negalima atnaujinti - ',
  'UPDATE_NULL_VALUE' => 'Suma yra NULL, pakei�iama � 0 -',
  'UPDATE_MERGE' => 'Apjungti valiutas',
  'UPDATE_MERGE_TXT' => 'Apjungti kelet� valiut� � vien� valiut�. Jei pasteb�jote, kad yra keletas valiutos �ra�� tai pa�iai valiutai, galite jas apjungti. Tai apjungs valiutas ir visuose kituose moduliuose.',
  'LBL_ACCOUNT_NAME' => 'Klientas:',
  'LBL_AMOUNT' => 'Suma:',
  'LBL_CURRENCY' => 'Valiuta:',
  'LBL_DATE_CLOSED' => 'Laukiama u�baigimo data:',
  'LBL_TYPE' => 'Tipas:',
  'LBL_NEXT_STEP' => 'Kitas �ingsnis:',
  'LBL_LEAD_SOURCE' => 'Nuorodos �altinis:',
  'LBL_SALES_STAGE' => 'Pardavimo etapas:',
  'LBL_PROBABILITY' => 'Tikimyb� (%):',
  'LBL_DESCRIPTION' => 'Apra�ymas:',
  'LBL_DUPLICATE' => 'Galimai pasikartojanti galimyb�',
  'MSG_DUPLICATE' => '�ios galimyb�s suk�rimas gali sukurti pasikartojan�i� galimyb�. Pasirinkite galimyb� i� s�ra�o �emiau arba spauskite "Sukurti nauj� galimyb�" naujos galimyb�s suk�rimui su anks�iau �vestais duomenimis.',
  'LBL_NEW_FORM_TITLE' => 'Sukurti galimyb�',
  'LNK_NEW_OPPORTUNITY' => 'Sukurti galimyb�',
  'LNK_OPPORTUNITY_LIST' => 'Galimyb�s',
  'ERR_DELETE_RECORD' => 'Galimyb�s panaikinimui turi b�ti nurodytas �ra�o numeris.',
  'LBL_TOP_OPPORTUNITIES' => 'Mano atviros galimyb�s',
  'NTC_REMOVE_OPP_CONFIRMATION' => 'Ar tikrai norite pa�alinti �� kontakt� i� galimyb�s?',
  'UPDATE_ISSUE_COUNT' => 'Rasti netikslumai ir pabandyta i�spr�sti:',
  'UPDATE_ISSUEFOUND_COUNT' => 'Rasta netikslum�:',
);


?>