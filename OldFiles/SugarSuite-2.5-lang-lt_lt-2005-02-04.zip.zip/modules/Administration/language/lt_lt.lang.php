<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.4 2005/02/04 23:56:38 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Administravimas',
  'LBL_MODULE_TITLE' => 'Administravimas: prad�ia',
  'LBL_NEW_FORM_TITLE' => 'Sukurti klient�',
  'LNK_NEW_USER' => 'Sukurti vartotoj�',
  'ERR_DELETE_RECORD' => 'Kliento naikinimui turi b�ti nurodytas �ra�o numeris.',
  'LBL_CONFIGURE_SETTINGS_TITLE' => 'Keisti nustatymus',
  'LBL_CONFIGURE_SETTINGS' => 'Keisti sistemos nustatymus',
  'LBL_UPGRADE_TITLE' => 'Atnaujinti',
  'LBL_UPGRADE' => 'Atnaujinti Sugar Sales',
  'LBL_MANAGE_USERS_TITLE' => 'Vartotoj� tvarkymas',
  'LBL_MANAGE_USERS' => 'Tvarkyti vartotojus ir slapta�od�ius',
  'LBL_ADMINISTRATION_HOME_TITLE' => 'Sistemos administravimas',
  'LBL_NOTIFY_TITLE' => 'El.pa�to prane�im� nustatymai',
  'LBL_NOTIFY_FROMADDRESS' => '"From" adresas:',
  'LBL_MAIL_SMTPSERVER' => 'SMTP Server:',
  'LBL_MAIL_SMTPPORT' => 'SMTP Port:',
  'LBL_MAIL_SENDTYPE' => 'Mail Transfer Agent:',
  'LBL_MAIL_SMTPUSER' => 'SMTP vartotojas:',
  'LBL_MAIL_SMTPPASS' => 'SMTP slapta�odis:',
  'LBL_MAIL_SMTPAUTH_REQ' => 'Naudoti SMTP autentifikacij�?',
  'LBL_NOTIFY_SEND_BY_DEFAULT' => 'Si�sti prane�imus?',
  'LBL_NOTIFY_SUBJECT' => 'E.lai�ko tema:',
  'LBL_NOTIFY_ON' => 'Prane�imai �jungti?',
  'LBL_NOTIFY_FROMNAME' => '"From" vardas:',
  'LBL_CURRENCY' => 'Tvarkyti valiutas ir valiut� kursus',
  'LBL_RELEASE' => 'Tvarkyti versijas',
  'LBL_LAYOUT' => 'Prid�ti, naikinti, keisti laukus. Keisti lauk� i�d�stym�',
  'LBL_MANAGE_CURRENCIES' => 'Valiutos',
  'LBL_MANAGE_RELEASES' => 'Versijos',
  'LBL_MANAGE_LAYOUT' => 'Lauk� i�d�stymas',
  'LBL_MANAGE_OPPORTUNITIES' => 'Galimyb�s',
  'LBL_UPGRADE_CURRENCY' => 'Atnaujinti valiut� sumas -> ',
  'LBL_BACKUP' => 'Rezervin� kopija',
  'DESC_BACKUP' => 'Kopijuoti Sugar programas ir duomen� baz�',
  'LBL_CUSTOMIZE_FIELDS' => 'Tvarkyti laukus',
  'DESC_CUSTOMIZE_FIELDS' => 'Tvarkyti lauk� �ymes visomis kalbomis',
  'LBL_DROPDOWN_EDITOR' => 'Pasirinkim� redaktorius',
  'DESC_DROPDOWN_EDITOR' => 'Prid�ti, naikinti, keisti pasirinkim� s�ra�us',
  'LBL_IFRAME' => 'Svetain�',
  'DESC_IFRAME' => 'Prid�ti �ymes svetaini� rodymui',
  'LBL_BUG_TITLE' => 'Klaid� sekimas',
  'LBL_TIMEZONE' => 'Laiko juostos',
  'LBL_STUDIO_TITLE' => 'Studio',
  'LBL_CONFIGURE_TABS' => 'Tvarkyti �ymes',
  'LBL_CHOOSE_WHICH' => 'Pasirinkite, kurios �ym�s rodomos visoje sistemoje',
  'LBL_DISPLAY_TABS' => 'Rodyti �ymes',
  'LBL_HIDE_TABS' => 'Pasl�pti �ymes',
  'LBL_EDIT_TABS' => 'Redaguoti �ymes',
  'LBL_UPGRADE_DB_TITLE' => 'Upgrade database',
  'LBL_UPGRADE_DB' => 'Update the database from version 2.0.x to 2.5 ',
  'LBL_UPGRADE_DB_BEGIN' => 'Begining Upgrade',
  'LBL_UPGRADE_DB_COMPLETE' => 'Upgrade Complete',
  'LBL_UPGRADE_DB_FAIL' => 'Upgrade Failed',
);


?>