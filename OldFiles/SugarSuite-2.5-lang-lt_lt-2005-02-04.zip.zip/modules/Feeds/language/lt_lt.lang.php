<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.4 2005/02/04 23:56:38 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'RSS',
  'LBL_MODULE_TITLE' => 'RSS: prad�ia',
  'LBL_SEARCH_FORM_TITLE' => 'RSS prane�im� paie�ka',
  'LBL_LIST_FORM_TITLE' => 'RSS prane�im� s�ra�as',
  'LBL_MY_LIST_FORM_TITLE' => 'Mano RSS prane�imai',
  'LBL_NEW_FORM_TITLE' => 'Nauji RSS prane�imai',
  'NTC_DELETE_CONFIRMATION' => 'Ar tikrai norinte panaikinti �� �ra��?',
  'ERR_DELETE_RECORD' => 'Kontakto panaikinimui turi b�ti nurodytas �ra�o numeris.',
  'LNK_NEW_FEED' => 'Naujos RSS prane�imai',
//END DON'T CONVERT
  'LNK_FEED_LIST' => 'Visi RSS prane�imai',
  'LNK_MY_FEED_LIST' => 'Mano RSS prane�imai',
  'LBL_TITLE' => 'Pavadinimas',
  'LBL_RSS_URL' => 'RSS URL',
  'LBL_ONLY_MY' => 'Tik mano m�gstamiausi',
  'LBL_VISIT_WEBSITE' => 'aplankyti svetain�',
  'LBL_LAST_UPDATED' => 'Atnaujinta',
  'LBL_DELETE_FAVORITES' => 'Pa�alinti i� m�gstamiausi�',
  'LBL_DELETE_FAV_BUTTON_TITLE' => 'Pa�alinti i� m�gstamiausi� [Alt+D]',
  'LBL_DELETE_FAV_BUTTON_KEY' => '[Alt+D]',
  'LBL_DELETE_FAV_BUTTON_LABEL' => 'Pa�alinti i� m�gstamiausi�',
  'LBL_ADD_FAV_BUTTON_TITLE' => '�traukti � m�gstamiausius [Alt+A]',
  'LBL_ADD_FAV_BUTTON_KEY' => '[Alt+A]',
  'LBL_ADD_FAV_BUTTON_LABEL' => '�traukti � m�gstamiausius',
  'LBL_MOVE_UP' => 'Auk�tyn',
  'LBL_MOVE_DOWN' => '�emyn',
  'LBL_FEED_NOT_AVAILABLE' => 'Prane�im� n�ra',
);


?>