<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.4 2005/02/04 23:56:38 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Veiklos',
  'LBL_MODULE_TITLE' => 'Veiklos: prad�ia',
  'LBL_SEARCH_FORM_TITLE' => 'Veikl� paie�ka',
  'LBL_LIST_FORM_TITLE' => 'Veikl� s�ra�as',
  'LBL_LIST_SUBJECT' => 'Tema',
  'LBL_LIST_CONTACT' => 'Kontaktas',
  'LBL_LIST_RELATED_TO' => 'Susij�s su',
  'LBL_LIST_DATE' => 'Data',
  'LBL_LIST_TIME' => 'Prad�ios laikas',
  'LBL_LIST_CLOSE' => 'U�daryta',
  'LBL_SUBJECT' => 'Tema:',
  'LBL_STATUS' => 'B�sena:',
  'LBL_LOCATION' => 'Vieta:',
  'LBL_DATE_TIME' => 'Prad�ios data ir laikas:',
  'LBL_DATE' => 'Prad�ios data:',
  'LBL_TIME' => 'Prad�ios laikas:',
  'LBL_DURATION' => 'Trukm�:',
  'LBL_HOURS_MINS' => '(val/min)',
  'LBL_CONTACT_NAME' => 'Kontakto vardas: ',
  'LBL_MEETING' => 'Susitikimas:',
  'LBL_DESCRIPTION_INFORMATION' => 'Apra�ymas',
  'LBL_DESCRIPTION' => 'Apra�ymas:',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'Suplanuotas',
  'LNK_NEW_CALL' => 'Sukurti skambut�',
  'LNK_NEW_MEETING' => 'Sukurti susitikim�',
  'LNK_NEW_TASK' => 'Sukurti u�duot�',
  'LNK_NEW_NOTE' => 'Sukurti u�ra��',
  'LNK_NEW_EMAIL' => 'Sukurti el.lai�k�',
  'LNK_CALL_LIST' => 'Skambu�iai',
  'LNK_MEETING_LIST' => 'Susitikimai',
  'LNK_TASK_LIST' => 'U�duotys',
  'LNK_NOTE_LIST' => 'U�ra�ai',
  'LNK_EMAIL_LIST' => 'El.lai�kai',
  'ERR_DELETE_RECORD' => 'Kliento naikinimui turi b�ti nurodytas �ra�o numeris.',
  'NTC_REMOVE_INVITEE' => 'Ar tikrai norite panaikinti �� susitikimo dalyv�?',
  'LBL_INVITEE' => 'Dalyviai',
  'LBL_LIST_DIRECTION' => 'Direction',
  'LBL_DIRECTION' => 'Direction',
  'LNK_NEW_APPOINTMENT' => 'Naujas paskyrimas',
  'LNK_VIEW_CALENDAR' => '�iandien',
  'LBL_OPEN_ACTIVITIES' => 'Atviri veiksmai',
  'LBL_HISTORY' => 'Istorija',
  'LBL_UPCOMING' => 'Mano b�simi veiksmai',
  'LBL_TODAY' => 'iki ',
  'LBL_NEW_TASK_BUTTON_TITLE' => 'Sukurti u�duot� [Alt+N]',
  'LBL_NEW_TASK_BUTTON_KEY' => 'N',
  'LBL_NEW_TASK_BUTTON_LABEL' => 'Sukurti u�duot�',
  'LBL_SCHEDULE_MEETING_BUTTON_TITLE' => 'Suplanuoti susitikim� [Alt+M]',
  'LBL_SCHEDULE_MEETING_BUTTON_KEY' => 'M',
  'LBL_SCHEDULE_MEETING_BUTTON_LABEL' => 'Suplanuoti susitikim�',
  'LBL_SCHEDULE_CALL_BUTTON_TITLE' => 'Suplanuoti skambut� [Alt+C]',
  'LBL_SCHEDULE_CALL_BUTTON_KEY' => 'C',
  'LBL_SCHEDULE_CALL_BUTTON_LABEL' => 'Suplanuoti skambut�',
  'LBL_NEW_NOTE_BUTTON_TITLE' => 'Sukurti u�ra�� [Alt+T]',
  'LBL_NEW_NOTE_BUTTON_KEY' => 'T',
  'LBL_NEW_NOTE_BUTTON_LABEL' => 'Sukurti u�ra��',
  'LBL_TRACK_EMAIL_BUTTON_TITLE' => 'Archyvuoti el.pa�t� [Alt+K]',
  'LBL_TRACK_EMAIL_BUTTON_KEY' => 'K',
  'LBL_TRACK_EMAIL_BUTTON_LABEL' => 'Archyvuoti el.pa�t�',
  'LBL_LIST_STATUS' => 'B�sena',
  'LBL_LIST_DUE_DATE' => '�vykdymo data',
  'LBL_LIST_LAST_MODIFIED' => 'Taisytas',
  'NTC_NONE_SCHEDULED' => 'Nesuplanuota.',
  'appointment_filter_dom' => 
  array (
    'today' => '�iandien',
    'tomorrow' => 'rytoj',
    'this Saturday' => '�i� savait�',
    'next Saturday' => 'kit� savait�',
    'last this_month' => '�� m�nes�',
    'last next_month' => 'kit� m�nes�',
  ),
  'LNK_IMPORT_NOTES' => 'Import Notes',
);


?>