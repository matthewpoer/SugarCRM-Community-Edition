<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.4 2005/02/04 23:56:38 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Kalendorius',
  'LBL_MODULE_TITLE' => 'Kalendorius',
  'LNK_NEW_CALL' => 'Sukurti skambut�',
  'LNK_NEW_MEETING' => 'Sukurti susitikim�',
  'LNK_NEW_APPOINTMENT' => 'Sukurti paskyrim�',
  'LNK_NEW_TASK' => 'Sukurti u�duot�',
  'LNK_CALL_LIST' => 'Skambu�iai',
  'LNK_MEETING_LIST' => 'Susitikimai',
  'LNK_TASK_LIST' => 'U�duotys',
  'LNK_VIEW_CALENDAR' => '�iandien',
  'LBL_MONTH' => 'M�nuo',
  'LBL_DAY' => 'Diena',
  'LBL_YEAR' => 'Metai',
  'LBL_WEEK' => 'Savait�',
  'LBL_PREVIOUS_MONTH' => 'Ankstesnis m�nuo',
  'LBL_PREVIOUS_DAY' => 'Ankstesn� diena',
  'LBL_PREVIOUS_YEAR' => 'Ankstesni metai',
  'LBL_PREVIOUS_WEEK' => 'Ankstesn� savait�',
  'LBL_NEXT_MONTH' => 'Kitas m�nuo',
  'LBL_NEXT_DAY' => 'Kita diena',
  'LBL_NEXT_YEAR' => 'Kiti metai',
  'LBL_NEXT_WEEK' => 'Kita savait�',
  'LBL_AM' => 'AM',
  'LBL_PM' => 'PM',
  'LBL_SCHEDULED' => 'Suplanuotas',
  'LBL_BUSY' => 'U�imtas',
  'LBL_CONFLICT' => 'Persidengia',
  'LBL_USER_CALENDARS' => 'Vartotojo kalendoriai',
);

$mod_list_strings = array (
  'dom_cal_weekdays' => 
  array (
    0 => 'Sek',
    1 => 'Pir',
    2 => 'Ant',
    3 => 'Tre',
    4 => 'Ket',
    5 => 'Pen',
    6 => '�e�',
  ),
  'dom_cal_weekdays_long' => 
  array (
    0 => 'Sekmadienis',
    1 => 'Pirmadienis',
    2 => 'Antradienis',
    3 => 'Tre�iadienis',
    4 => 'Ketvirtadienis',
    5 => 'Penktadienis',
    6 => '�e�tadienis',
  ),
  'dom_cal_month' => 
  array (
    0 => '',
    1 => 'Sau',
    2 => 'Vas',
    3 => 'Kov',
    4 => 'Bal',
    5 => 'Geg',
    6 => 'Bir',
    7 => 'Lie',
    8 => 'Rgp',
    9 => 'Rgs',
    10 => 'Spa',
    11 => 'Lap',
    12 => 'Grd',
  ),
  'dom_cal_month_long' => 
  array (
    0 => '',
    1 => 'Sausis',
    2 => 'Vasaris',
    3 => 'Kovas',
    4 => 'Balandis',
    5 => 'Gegu��',
    6 => 'Bir�elis',
    7 => 'Liepa',
    8 => 'Rugpj�tis',
    9 => 'Rugs�jis',
    10 => 'Spalis',
    11 => 'Lapkritis',
    12 => 'Gruodis',
  ),
);


?>