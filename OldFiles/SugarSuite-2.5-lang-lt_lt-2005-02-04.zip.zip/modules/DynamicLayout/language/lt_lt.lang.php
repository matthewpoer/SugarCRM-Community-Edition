<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.4 2005/02/04 23:56:38 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_ADVANCED' => 'I�samesnis:',
  'DESC_USING_LAYOUT_TITLE' => 'I�d�stymo redaktoriaus naudojimas',
  'DESC_USING_LAYOUT_SHORTCUTS' => 'Trumpiniai:',
  'DESC_USING_LAYOUT_TOOLBAR' => '�rankiai:',
  'DESC_USING_LAYOUT_EDIT_ROWS' => 'Redaguoti eilutes:',
  'DESC_USING_LAYOUT_SELECT_FILE' => 'Pasirinkti byl�:',
  'DESC_USING_LAYOUT_EDIT_FIELDS' => 'Redaguoti laukus:',
  'DESC_USING_LAYOUT_ADD_FIELD' => 'Prid�ti lauk�:',
  'DESC_USING_LAYOUT_REMOVE_ITEM' => 'Panaikinti punkt�:',
  'DESC_USING_LAYOUT_DISPLAY_HTML' => 'Rodyti HTML kod�:',
  'DESC_USING_LAYOUT_BLK1' => 'I�d�stymo redaktorius leid�ia pakeisti lauk�, �ymi� ir objekt� i�d�stym� ekrane pagal j�s� poreikius. Pasirinkite norimo redaguoti puslapio byl� spausdami �Pasirinkti byl��.',
  'DESC_USING_LAYOUT_BLK2' => ' leid�ia pasirinkti kit� puslap� redagavimui; nei�saugoti redaguojamo puslapio pakeitimai bus prarasti. Jei ne�inote, kuri� byl� redaguoti, pa�ym�kite �Edit in Place�; tai prid�s redagavimo mygtuk� visose programos redaguojamose vietose. Nueikite � puslap�, kur� norite redaguoti, paspauskite redagavimo mygtuk�, ir b�site sugra�inti � redagavimo lang� su pasirinkta atitinkama byla.',
  'DESC_USING_LAYOUT_BLK3' => ' perkelkite atskirus laukus ar j� �ymes. Pasirinkite punkto �ymekl� ',
  'DESC_USING_LAYOUT_BLK4' => ' �alia norimo perkelti lauko ar �ym�s ir paspauskite �ymekl�, kur norite lauk� ar �ym� perkelti. Tai perkels objekt� i� pradin�s vietos � nurodyt� viet�. Jei ten jau yra laukas ar �ym�, tai objektai pasikeis vietomis. S�ra�� punktai redauojami taip pat: pasirinkite pradin� ir paskirties �ymeklius, ir punktai susikeis vietomis. Lauko ar formos panaikinimui i� ekrano nutemkite punkt� � �ranki� zon� kair�je.',
  'DESC_USING_LAYOUT_BLK5' => ' laid�ia prid�ti ar pa�alinti eilutes detalioje per�i�roje. Paspaudus "+" �terpiama eilut� po i�rinktosios, paspaudus "�" eilut� pa�alinama.',
  'DESC_USING_LAYOUT_BLK6' => '�rankiai suteikia galimyb� prid�ti � pasirinkt� form� naujus laukus ir �ymes, atgaminti jau pa�alintus punktus ir panaikinti punktus.',
  'DESC_USING_LAYOUT_BLK7' => ' leid�ia pasirinkti norimo prid�ti lauko tip� ir su juo susiet� �ym�. Mygtukas "Add" prideda nauj� lauk� ir jo �ym� � �ranki� zon�. I� �ia laukas gali b�ti perkeliamas pasirinkus jo �ymekl� ir paskirties �ymekl�.',
  'DESC_USING_LAYOUT_BLK8' => ' atliekamas pasirinkus jo �ymekl� ir paspaudus teksta �Drag unwanted items here�. Tai perkels pasirinkt� punkt� � �ranki� zon�.',
  'DESC_USING_LAYOUT_BLK9' => ' pasirinkus lauk� parodomas j� atitinkantis HTML kodas. Nors tai gali b�ti informatyvu, tai labai apkrauna kompiuterio procesori� ir tur�t� b�ti naudojama tik b�tinais atvejais.',
  'DESC_USING_LAYOUT_BLK10' => 'Pakeitim� i�saugojimui spauskite mygtuk� �Save Layout�. Pakeitim� panaikinimui eikite � kit� lang� ir redaguojamo lango pakeitimai dings.',
);


?>