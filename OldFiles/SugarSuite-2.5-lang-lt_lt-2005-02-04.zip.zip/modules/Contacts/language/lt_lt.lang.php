<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.4 2005/02/04 23:56:38 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Kontaktai',
  'LBL_INVITEE' => 'Tiesiogiai atskaitingas',
  'LBL_MODULE_TITLE' => 'Kontaktai: prad�ia',
  'LBL_SEARCH_FORM_TITLE' => 'Kontakt� paie�ka',
  'LBL_LIST_FORM_TITLE' => 'Kontakt� s�ra�as',
  'LBL_NEW_FORM_TITLE' => 'Naujas kontaktas',
  'LBL_CONTACT_OPP_FORM_TITLE' => 'Kontaktas-galimyb�:',
  'LBL_CONTACT' => 'Kontaktas:',
  'LBL_BUSINESSCARD' => 'Vizitin� kortel�',
  'LBL_LIST_NAME' => 'Vardas',
  'LBL_LIST_LAST_NAME' => 'Pavard�',
  'LBL_LIST_CONTACT_NAME' => 'Kontakto vardas',
  'LBL_LIST_TITLE' => 'Pareigos',
  'LBL_LIST_ACCOUNT_NAME' => 'Kliento pavadinimas',
  'LBL_LIST_EMAIL_ADDRESS' => 'El.pa�tas',
  'LBL_LIST_OTHER_EMAIL_ADDRESS' => 'Kitas el.pa�tas',
  'LBL_LIST_PHONE' => 'Telefonas',
  'LBL_LIST_CONTACT_ROLE' => 'Vaidmuo',
  'LBL_LIST_FIRST_NAME' => 'Vardas',
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_email2' => 'LBL_LIST_OTHER_EMAIL_ADDRESS',
  'LBL_EXISTING_CONTACT' => 'Paimtas jau esantis kontaktas',
  'LBL_CREATED_CONTACT' => 'Sukurtas naujas kontaktas',
  'LBL_EXISTING_ACCOUNT' => 'Paimtas jau esantis klientas',
//END DON'T CONVERT
  'LBL_CREATED_ACCOUNT' => 'Sukurtas naujas klientas',
  'LBL_CREATED_CALL' => 'Sukurtas naujas skambutis',
  'LBL_CREATED_MEETING' => 'Sukurtas naujas susitikimas',
  'LBL_ADDMORE_BUSINESSCARD' => 'Prid�ti kit� vizitin� kortel�',
  'LBL_ADD_BUSINESSCARD' => 'Sukurti i� vizitin�s kortel�s',
  'LBL_NAME' => 'Vardas:',
  'LBL_CONTACT_NAME' => 'Kontakto vardas:',
  'LBL_CONTACT_INFORMATION' => 'Kontakto informacija',
  'LBL_FIRST_NAME' => 'Vardas:',
  'LBL_OFFICE_PHONE' => 'Darbo telefonas:',
  'LBL_ACCOUNT_NAME' => 'Kliento pavadinimas:',
  'LBL_ANY_PHONE' => 'Telefonas:',
  'LBL_PHONE' => 'Telefonas:',
  'LBL_LAST_NAME' => 'Pavard�:',
  'LBL_MOBILE_PHONE' => 'Mob. telefonas:',
  'LBL_HOME_PHONE' => 'Prad�ia:',
  'LBL_LEAD_SOURCE' => 'Nuorodos �altinis:',
  'LBL_OTHER_PHONE' => 'Kitas telefonas:',
  'LBL_FAX_PHONE' => 'Faksas:',
  'LBL_PRIMARY_ADDRESS_STREET' => 'Gatv�:',
  'LBL_PRIMARY_ADDRESS_CITY' => 'Miestas:',
  'LBL_PRIMARY_ADDRESS_COUNTRY' => '�alis:',
  'LBL_PRIMARY_ADDRESS_STATE' => 'Rajonas:',
  'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'Pa�to kodas:',
  'LBL_ALT_ADDRESS_STREET' => 'Gatv�:',
  'LBL_ALT_ADDRESS_CITY' => 'Miestas:',
  'LBL_ALT_ADDRESS_COUNTRY' => '�alis:',
  'LBL_ALT_ADDRESS_STATE' => 'Rajonas:',
  'LBL_ALT_ADDRESS_POSTALCODE' => 'Pa�to kodas:',
  'LBL_TITLE' => 'Pareigos:',
  'LBL_DEPARTMENT' => 'Departamantas:',
  'LBL_BIRTHDATE' => 'Gimimo diena:',
  'LBL_EMAIL_ADDRESS' => 'El.pa�tas:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Kitas el.pa�tas:',
  'LBL_ANY_EMAIL' => 'El.pa�tas:',
  'LBL_REPORTS_TO' => 'Atskaitingas:',
  'LBL_ASSISTANT' => 'Asistentas:',
  'LBL_ASSISTANT_PHONE' => 'Asistento telefonas:',
  'LBL_DO_NOT_CALL' => 'Neskambinti:',
  'LBL_EMAIL_OPT_OUT' => 'Nesi�sti el.lai�k�:',
  'LBL_PRIMARY_ADDRESS' => 'Pagrindinis adresas:',
  'LBL_ALTERNATE_ADDRESS' => 'Kitas adresas:',
  'LBL_ANY_ADDRESS' => 'Adresas:',
  'LBL_CITY' => 'Miestas:',
  'LBL_STATE' => 'Rajonas:',
  'LBL_POSTAL_CODE' => 'Pa�to kodas:',
  'LBL_COUNTRY' => 'Valstyb�:',
  'LBL_DESCRIPTION_INFORMATION' => 'Apra�ymas',
  'LBL_ADDRESS_INFORMATION' => 'Adresas',
  'LBL_DESCRIPTION' => 'Apra�ymas:',
  'LBL_CONTACT_ROLE' => 'Vaidmuo:',
  'LBL_OPP_NAME' => 'Galimyb�s pavadinimas:',
  'LBL_IMPORT_VCARD' => 'Importuoti vCard',
  'LBL_IMPORT_VCARDTEXT' => 'Automati�kai sukurti nauj� kontakt� importuojant vCard.',
  'LBL_DUPLICATE' => 'Galimi pasikartojantys kontaktai',
  'MSG_SHOW_DUPLICATES' => '�io kontakto suk�rimas gali sukurti pasikartojant� kontakt�. Spauskite "Sukurti kontakt�" naujo kontakto suk�rimui su anks�iau �vestais duomenimis arba spauskite "Nutraukti".',
  'MSG_DUPLICATE' => '�io kontakto suk�rimas gali sukurti pasikartojant� kontakt�. Pasirinkite kontakt� i� s�ra�o �emiau arba spauskite "Sukurti nauj� kontakt�" naujo kontakto suk�rimui su anks�iau �vestais duomenimis.',
  'LNK_CONTACT_LIST' => 'Kontaktai',
  'LNK_IMPORT_VCARD' => 'Sukurti i� vCard',
  'LNK_NEW_CONTACT' => 'Sukurti kontakt�',
  'LNK_NEW_ACCOUNT' => 'Sukurti klient�',
  'LNK_NEW_OPPORTUNITY' => 'Sukurti galimyb�',
  'LNK_NEW_CASE' => 'Sukurti paklausim�',
  'LNK_NEW_NOTE' => 'Sukurti u�ra��',
  'LNK_NEW_CALL' => 'Sukurti skambut�',
  'LNK_NEW_EMAIL' => 'Sukurti el.lai�k�',
  'LNK_NEW_MEETING' => 'Sukurti susitikim�',
  'LNK_NEW_TASK' => 'Sukurti u�duot�',
  'LNK_NEW_APPOINTMENT' => 'Sukurti paskyrim�',
  'NTC_DELETE_CONFIRMATION' => 'Ar tikrai norite panaikinti �� �ra��?',
  'NTC_REMOVE_CONFIRMATION' => 'Ar tikrai norite pa�alinti �� kontakt� i� paklausimo?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Ar tikrai norite panaikinti �� tiesiogin�s atskaitomyb�s �ra��?',
  'ERR_DELETE_RECORD' => 'Kontakto naikinimui turi b�ti nurodytas �ra�o numeris.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Kopijuoti pagrindin� adres� � papildom� adres�',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Kopijuoti papildom� adres� � pagrindin� adres�',
  'LBL_SALUTATION' => 'Pasveikinimas',
  'LBL_SAVE_CONTACT' => 'I�saugoti kontakt�',
);


?>