<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.4 2005/02/04 23:56:38 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Vartotojai',
  'LBL_MODULE_TITLE' => 'Vartotojai: prad�ia',
  'LBL_SEARCH_FORM_TITLE' => 'Vartotoj� paie�ka',
  'LBL_LIST_FORM_TITLE' => 'Vartotojai',
  'LBL_NEW_FORM_TITLE' => 'Naujas vartotojas',
  'LBL_USER' => 'Vartotojai:',
  'LBL_LOGIN' => 'Prisijungti',
  'LBL_RESET_PREFERENCES' => 'Pakeisti nustatymus � pradinius',
  'LBL_TIME_FORMAT' => 'Laiko formatas:',
  'LBL_DATE_FORMAT' => 'Datos formatas:',
  'LBL_TIMEZONE' => 'Dabartinis laikas:',
  'LBL_CURRENCY' => 'Valiuta:',
  'LBL_LIST_NAME' => 'Vardas',
  'LBL_LIST_LAST_NAME' => 'Pavard�',
  'LBL_LIST_USER_NAME' => 'Vartotojas',
  'LBL_LIST_DEPARTMENT' => 'Skyrius',
  'LBL_LIST_EMAIL' => 'El.pa�tas',
  'LBL_LIST_PRIMARY_PHONE' => 'Pagrindinis telefonas',
  'LBL_LIST_ADMIN' => 'Administratorius',
  'LBL_NEW_USER_BUTTON_TITLE' => 'Naujas vartotojas [Alt+N]',
  'LBL_NEW_USER_BUTTON_LABEL' => 'Naujas vartotojas',
  'LBL_NEW_USER_BUTTON_KEY' => 'N',
  'LBL_ERROR' => 'Klaida:',
  'LBL_PASSWORD' => 'Slapta�odis:',
  'LBL_USER_NAME' => 'Vartotojas:',
  'LBL_FIRST_NAME' => 'Vardas:',
  'LBL_LAST_NAME' => 'Pavard�:',
  'LBL_USER_SETTINGS' => 'Vartotojo nustatymai',
  'LBL_THEME' => 'Vaizdas:',
  'LBL_LANGUAGE' => 'Kalba:',
  'LBL_ADMIN' => 'Administratorius:',
  'LBL_USER_INFORMATION' => 'Vartotojo informacija',
  'LBL_OFFICE_PHONE' => 'Darbo telefonas:',
  'LBL_REPORTS_TO' => 'Atskaitingas:',
  'LBL_OTHER_PHONE' => 'Kitas:',
  'LBL_OTHER_EMAIL' => 'Kitas el.pa�tas:',
  'LBL_NOTES' => 'Pastabos:',
  'LBL_DEPARTMENT' => 'Skyrius:',
  'LBL_STATUS' => 'B�sena:',
  'LBL_TITLE' => 'Pareigos',
  'LBL_ANY_PHONE' => 'Telefonas:',
  'LBL_ANY_EMAIL' => 'El.pa�tas:',
  'LBL_ADDRESS' => 'Adresas:',
  'LBL_CITY' => 'Miestas:',
  'LBL_STATE' => 'Rajonas:',
  'LBL_POSTAL_CODE' => 'Pa�to kodas:',
  'LBL_COUNTRY' => '�alis:',
  'LBL_NAME' => 'Vardas:',
  'LBL_MOBILE_PHONE' => 'Mob. telefonas:',
  'LBL_OTHER' => 'Kitas:',
  'LBL_FAX' => 'Faksas:',
  'LBL_EMAIL' => 'El.pa�tas:',
  'LBL_HOME_PHONE' => 'Nam� telefonas:',
  'LBL_ADDRESS_INFORMATION' => 'Adresas',
  'LBL_PRIMARY_ADDRESS' => 'Pagrindinis adresas:',
  'LBL_CHANGE_PASSWORD_BUTTON_TITLE' => 'Pakeisti slapta�od� [Alt+P]',
  'LBL_CHANGE_PASSWORD_BUTTON_KEY' => 'P',
  'LBL_CHANGE_PASSWORD_BUTTON_LABEL' => 'Pakeisti slapta�od�',
  'LBL_LOGIN_BUTTON_TITLE' => 'Prisijungti [Alt+L]',
  'LBL_LOGIN_BUTTON_KEY' => 'L',
  'LBL_LOGIN_BUTTON_LABEL' => 'Prisijungti',
  'LBL_CHANGE_PASSWORD' => 'Pakeisti slapta�od�',
  'LBL_OLD_PASSWORD' => 'Senasis slapta�odis:',
  'LBL_NEW_PASSWORD' => 'Naujasis slapta�odis:',
  'LBL_CONFIRM_PASSWORD' => 'Patvirtinti slapta�od�:',
  'ERR_ENTER_OLD_PASSWORD' => '�veskite savo sen�j� slapta�od�.',
  'ERR_ENTER_NEW_PASSWORD' => '�veskite savo naujaj� slapta�od�.',
  'ERR_ENTER_CONFIRMATION_PASSWORD' => '�veskite savo nauj�j� slapta�od� patvirtinimui.',
  'ERR_REENTER_PASSWORDS' => '�veskite slapta�od�ius dar kart�.  \\"new password\\" ir \\"confirm password\\" reik�m�s nesutampa.',
  'ERR_INVALID_PASSWORD' => 'Nurodykite galiojant� vartotojo vard� ir slapta�od�.',
  'ERR_PASSWORD_CHANGE_FAILED_1' => 'Vartotojo slapta�od�io pakeisti nepavyko d�l ',
  'ERR_PASSWORD_CHANGE_FAILED_2' => ' nepavyko. Turi b�ti sukurtas naujas slapta�odis.',
  'ERR_PASSWORD_INCORRECT_OLD' => 'Neteisingasvartotojo $this->user_name senasis slapta�odis. �veskite slapta�od� i� naujo.',
  'ERR_USER_NAME_EXISTS_1' => 'Vartotojo vardas ',
  'ERR_USER_NAME_EXISTS_2' => ' jau egzistuoja. Pasikartojantys vardai neleistini.<br>Pakaiskita vertotojo vard� unikaliu.',
  'ERR_LAST_ADMIN_1' => 'Vartotojas ',
  'ERR_LAST_ADMIN_2' => ' yra paskutinis Administratorius. Bent vienas vartotojas turi b�ti Administratoriumi.<br>Patikrinkite Administratoriaus nustatymus.',
  'LNK_NEW_USER' => 'Sukurti vartotoj�',
  'LNK_USER_LIST' => 'Vartotojai',
  'ERR_DELETE_RECORD' => 'Kliento panaikinimui turi b�ti nurodytas �ra�o numeris.',
  'LBL_RECEIVE_NOTIFICATIONS' => 'Priskyrimo prane�imas:',
  'LBL_RECEIVE_NOTIFICATIONS_TEXT' => 'Gauti prane�im� el.�inute apie vartotojui priskirt� �ra��',
  'LBL_ADMIN_TEXT' => 'Vartotojas turi Administratoriaus teises',
  'LBL_TIME_FORMAT_TEXT' => 'Nustatyti laiko rodymo format�',
  'LBL_DATE_FORMAT_TEXT' => 'Nustatyti datos rodymo format�',
  'LBL_TIMEZONE_TEXT' => 'Nustatyti dabartin� laik�',
  'LBL_GRIDLINE' => 'Rodyti tinklel�:',
  'LBL_GRIDLINE_TEXT' => 'Rodyti tinklel� detalioje per�i�roje',
  'LBL_CURRENCY_TEXT' => 'Pasirinkti einam�j� valiut�',
  'LBL_DISPLAY_TABS' => 'Rodyti �ymes',
  'LBL_HIDE_TABS' => 'Pasl�pti �ymes',
  'LBL_EDIT_TABS' => 'Redaguoti �ymes',
  'LBL_CHOOSE_WHICH' => 'Pasirinkite, kurios �ym�s matomos visoje sistemoje',
);


?>