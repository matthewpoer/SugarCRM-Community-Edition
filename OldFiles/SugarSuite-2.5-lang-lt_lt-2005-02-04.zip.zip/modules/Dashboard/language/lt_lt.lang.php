<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.4 2005/02/04 23:56:38 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Pasiekimai',
  'LBL_MODULE_TITLE' => 'Pasiekimai: prad�ia',
  'LBL_SALES_STAGE_FORM_TITLE' => 'Pardavimo etapai',
  'LBL_SALES_STAGE_FORM_DESC' => 'Sumin�s galimybi� vert�s pagal pasirinktus pardavim� etapus, pasirinktus vartotojus ir laukiam� pabaigos dat� nurodytame intervale.',
  'LBL_YEAR_BY_OUTCOME' => 'Pipeline By Month By Outcome',
  'LBL_MONTH_BY_OUTCOME_DESC' => 'Sumin�s galimybi� vert�s pagal m�nesius ir rezultatus, pagal pasirinktus vartotojus ir laukiam� pabaigos dat� nurodytame intervale. Rezultatai skirstomi � laim�tus, pralaim�tus ir kitas b�senas.',
  'LBL_LEAD_SOURCE_FORM_TITLE' => 'Galimyb�s pagal nuorodos �altin�',
  'LBL_LEAD_SOURCE_FORM_DESC' => 'Sumin�s galimybi� vert�s pagal pasirinktus nuorod� �altinius ir pasirinktus vartotojus',
  'LBL_LEAD_SOURCE_BY_OUTCOME' => 'Galimyb�s pagal nuorodos �altin� ir rezultat�',
  'LBL_LEAD_SOURCE_BY_OUTCOME_DESC' => 'Parodo sumines galimybi� vertes pagal pasirinktus nuorod� �altinius ir rezultatus, pagal pasirinktus vartotojus ir laukiam� pabaigos dat� nurodytame intervale. Rezultatai skirstomi � laim�tus, pralaim�tus ir kitas b�senas.',
  'LBL_PIPELINE_FORM_TITLE_DESC' => 'Sumin�s galimybi� vert�s pagal pasirinktus pardavimo etapus ir  ir laukiam� pabaigos dat� nurodytame intervale.',
  'LBL_DATE_RANGE' => 'Datos intervalas',
  'LBL_DATE_RANGE_TO' => 'iki',
  'ERR_NO_OPPS' => 'Sukurkite kelet� galimybi�, kad gal�tum�te pamatyti galimybi� grafikus.',
  'LBL_TOTAL_PIPELINE' => 'I� viso yra ',
  'LBL_ALL_OPPORTUNITIES' => 'Bendra vis� galimybi� vert� yra ',
  'LBL_OPP_SIZE' => 'Galimybi� dydis',
  'LBL_OPP_THOUSANDS' => ' t�kst.',
  'NTC_NO_LEGENDS' => 'Nieko',
  'LBL_LEAD_SOURCE_OTHER' => 'Kita',
  'LBL_EDIT' => 'Redaguoti',
  'LBL_REFRESH' => 'Atnaujinti',
  'LBL_CREATED_ON' => 'Grafikas sukurtas ',
  'LBL_OPPS_WORTH' => 'galimybi� vert�',
  'LBL_OPPS_IN_STAGE' => 'galimyb�s, kur pardavimo etapas yra',
  'LBL_OPPS_IN_LEAD_SOURCE' => 'galimyb�s, kur nuorodos �altinis yra',
  'LBL_OPPS_OUTCOME' => 'galimyb�s, kur rezultatai yra',
  'LBL_ROLLOVER_DETAILS' => 'Palieskite stulpel� detalesniam apra�ymui.',
  'LBL_ROLLOVER_WEDGE_DETAILS' => 'Palieskite punkt� detalesniam apra�ymui.',
  'LBL_USERS' => 'vartotojai:',
  'LBL_SALES_STAGES' => 'Pardavimo etapai:',
  'LBL_LEAD_SOURCES' => 'Nuorod� �altiniai:',
  'LBL_DATE_START' => 'Prad�ios data:',
  'LBL_DATE_END' => 'Pabaigos data:',
  'LBL_YEAR' => 'Metai:',
  'LNK_NEW_CONTACT' => 'Sukurti kontakt�',
  'LNK_NEW_ACCOUNT' => 'Sukurti klient�',
  'LNK_NEW_OPPORTUNITY' => 'Sukurti galimyb�',
  'LNK_NEW_QUOTE' => 'Sukurti pasi�lym�',
  'LNK_NEW_LEAD' => 'Sukurti nuorod�',
  'LNK_NEW_CASE' => 'Sukurti paklausim�',
  'LNK_NEW_NOTE' => 'Sukurti u�ra��',
  'LNK_NEW_CALL' => 'Sukurti skambut�',
  'LNK_NEW_MEETING' => 'Sukurti susitikim�',
  'LNK_NEW_TASK' => 'Sukurti u�duot�',
  'LNK_NEW_ISSUE' => 'Prane�ti klaid�',
  'LBL_MONTH_BY_OUTCOME' => 'M�nesio rezultatai',
);


?>