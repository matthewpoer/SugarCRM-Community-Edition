<?PHP
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
require_once('modules/Users/User.php');
require_once('modules/Leads/LeadFormBase.php');
require_once('include/logging.php');
 
$log =& LoggerManager::getLogger('index');

$users = array(
	'cheeto' => array('name'=>'admin', 'pass'=>'1b359d8753858b55befa0441067aaed3')
);

$current_user = new User();
$current_user->user_name = $users[$_POST['user']]['name'];
if($current_user->authenticate_user($users[$_POST['user']]['pass'])){
	$userid = $current_user->retrieve_user_id($users[$_REQUEST['user']]['name']);
	$current_user->retrieve($userid);
	$leadForm = new LeadFormBase();
	$prefix = '';
	if(isset($_POST['prefix']) && !empty($_POST['prefix'])){
		$prefix = 	$_POST['prefix'];
	}
	$_POST['assigned_user_id'] = $userid;
	$_POST['record'] ='';
	$leadForm->handleSave($prefix, false, true);
	if(isset($_POST['redirect']) && !empty($_POST['redirect'])){
		header("Location: ".$_POST['redirect']);	
	}else{
		echo "Thank You For Your Submission.";	
		
	}	
}
?>
