<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/modules/Import/ImportLead.php,v 1.7 2004/10/29 22:38:30 robert Exp $
 * Description:  Defines the Account SugarBean Account entity with the necessary
 * methods and variables.
 ********************************************************************************/

include_once('config.php');
require_once('include/logging.php');
require_once('database/DatabaseConnection.php');
require_once('data/SugarBean.php');
require_once('modules/Contacts/Contact.php');
require_once('modules/Opportunities/Opportunity.php');
require_once('modules/Cases/Case.php');
require_once('modules/Calls/Call.php');
require_once('modules/Notes/Note.php');
require_once('modules/Emails/Email.php');
require_once('modules/Leads/Lead.php');

global $app_list_strings;

class ImportLead extends Lead {
	 var $db;

	// these are fields that may be set on import
	// but are to be processed and incorporated
	// into fields of the parent class


	// This is the list of fields that are required.
	var $required_fields =  array("last_name"=>1);
	
	// This is the list of the functions to run when importing
	var $special_functions =  array(
		"get_names_from_full_name"
                ,"add_salutation"
                ,"add_lead_status"
                ,"add_lead_source"
                ,"add_do_not_call"
                ,"add_email_opt_out"
		,"add_primary_address_streets"
		,"add_alt_address_streets"

	 );


	// This is the list of fields that are importable.
	// some if these do not map directly to database columns
	var $importable_fields = Array(
                "refered_by"=>1
                ,"salutation"=>1
                ,"first_name"=>1
                ,"last_name"=>1
                ,"lead_source"=>1
                ,"lead_source_description"=>1
                ,"title"=>1
                ,"department"=>1
                ,"do_not_call"=>1
                ,"phone_home"=>1
                ,"phone_mobile"=>1
                ,"phone_work"=>1
                ,"phone_other"=>1
                ,"phone_fax"=>1
                ,"email1"=>1
                ,"email2"=>1
                ,"email_opt_out"=>1
                ,"primary_address_street"=>1
                ,"primary_address_city"=>1
                ,"primary_address_state"=>1
                ,"primary_address_postalcode"=>1
                ,"primary_address_country"=>1
                ,"alt_address_street"=>1
                ,"alt_address_city"=>1
                ,"alt_address_state"=>1
                ,"alt_address_postalcode"=>1
                ,"alt_address_country"=>1
		,"primary_address_street_2"=>1
                ,"primary_address_street_3"=>1
                ,"alt_address_street_2"=>1
                ,"alt_address_street_3"=>1
                ,"full_name"=>1
                ,"description"=>1
                ,"status"=>1
                ,"status_description"=>1
                ,"account_name"=>1
                ,"account_description"=>1
		);
        function add_salutation()
        {
                if ( isset($this->salutation) &&
                        ! isset( $app_list_strings['salutation_dom'][ $this->salutation ]) )
                {
                        $this->salutation = '';
                }
        }

        function add_lead_source()
        {
                if ( isset($this->lead_source) &&
                        ! isset( $app_list_strings['lead_source_dom'][ $this->lead_source ]) )
                {
                        $this->lead_source = '';
                }

        }

        function add_lead_status()
        {
                if ( isset($this->status) &&
                        ! isset( $app_list_strings['lead_status_dom'][ $this->status ]) )
                {
                        $this->status = '';
                }

        }

        function add_do_not_call()
        {
                if ( isset($this->do_not_call) && $this->do_not_call != 'on')
                {
                        $this->do_not_call = '';
                }

        }

        function add_email_opt_out()
        {
                if ( isset($this->email_opt_out) && $this->email_opt_out != 'on')
                {
                        $this->email_opt_out = '';
                }
        }

        function get_names_from_full_name()
        {
                if ( ! isset($this->full_name))
                {
                        return;
                }
                $arr = array();

                $name_arr = preg_split('/\s+/',$this->full_name);

                if ( count($name_arr) == 1)
                {
                        $this->last_name = $this->full_name;
                }
                else
                {
                        $this->first_name = array_shift($name_arr);

                        $this->last_name = join(' ',$name_arr);
                }

        }
        function add_primary_address_streets()
        {
                if ( isset($this->primary_address_street_2))
                {
                        $this->primary_address_street .= " ". $this->primary_address_street_2;
                }

                if ( isset($this->primary_address_street_3))
                {
                        $this->primary_address_street .= " ". $this->primary_address_street_3;
                }
        }

        function add_alt_address_streets()
        {
                if ( isset($this->alt_address_street_2))
                {
                        $this->alt_address_street .= " ". $this->alt_address_street_2;
                }

                if ( isset($this->alt_address_street_3))
                {
                        $this->alt_address_street .= " ". $this->alt_address_street_3;
                }

        }



	function ImportLead() {
		$this->log = LoggerManager::getLogger('import_lead');
		$this->db = new PearDatabase();
	}

}



?>
