<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/data/SugarBean.php,v 1.66 2004/11/10 21:21:16 julian Exp $
 * Description:  Defines the base class for all data entities used throughout the
 * application.  The base class including its methods and variables is designed to
 * be overloaded with module-specific methods and variables particular to the
 * module's base entity class.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

include_once('config.php');
require_once('include/logging.php');
require_once('data/Tracker.php');
require_once('include/utils.php');

class SugarBean
{
    /**
     * This method implements a generic insert and update logic for any SugarBean
     * This method only works for subclasses that implement the same variable names.
     * This method uses the presence of an id field that is not null to signify and update.
     * The id field should not be set otherwise.
     * todo - Add support for field type validation and encoding of parameters.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
     */

	var $new_schema = false;
	var $new_with_id = false;





	function save($check_notify = FALSE)
	{
		global $current_user;
		$isUpdate = true;

		if(!isset($this->id) || $this->id == "")
		{
			$isUpdate = false;
		}

		if ( $this->new_with_id == true )
		{
			$isUpdate = false;
		}

		$this->date_modified = date("Y-m-d H:i:s", time());
		if (isset($current_user)) $this->modified_user_id = $current_user->id;

		if($isUpdate)
		{
    			$query = "Update ";
		}
		else
		{
   			$this->date_entered = date('YmdHis');

			if($this->new_schema &&
				$this->new_with_id == false)
			{
				$this->id = create_guid();
			}

			$query = "INSERT into ";




		}

		if ($check_notify) {
			$this->send_assignment_notifications();
		}

		// write out the SQL statement.
		$query .= $this->table_name." set ";

		$firstPass = 0;
		foreach($this->column_fields as $field)
		{
			// Do not write out the id field on the update statement.
			// We are not allowed to change ids.
			if($isUpdate && ('id' == $field))
				continue;

			// Only assign variables that have been set.
			if(isset($this->$field))
			{
				// Try comparing this element with the head element.
				if(0 == $firstPass)
					$firstPass = 1;
				else
					$query = $query.", ";
				$query = $query.$field."='".PearDatabase::quote(from_html($this->$field))."'";
			}
		}

		if($isUpdate)
		{
			$query = $query." WHERE ID = '$this->id'";
			$this->log->info("Update $this->object_name: ".$query);
		}
		else
		{
        	$this->log->info("Insert: ".$query);
		}

		$this->db->query($query, true);

		// If this is not an update then store the id for later.
		if(!$isUpdate && !$this->new_schema && !$this->new_with_id)
		{
			//this is mysql specific
	        	$this->id = $this->db->getOne("SELECT LAST_INSERT_ID()" );
		}

		// let subclasses save related field changes
		$this->save_relationship_changes($isUpdate);
		return $this->id;
	}

    /**
     * This function handles sending out email notifications when items are first assigned to users.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
     */
function send_assignment_notifications()
{
	global $site_URL, $sugar_version, $app_list_strings, $current_user, $default_language;

	require_once("modules/Administration/Administration.php");
	$admin = new Administration();
	$admin->retrieveSettings();

	if ($admin->settings['notify_on']) {
		$this->log->info("Notifications: user assignment has changed, checking if user receives notifications");
		$notify_user = new User();
		$notify_user->retrieve($this->assigned_user_id);

		if ($notify_user->receive_notifications) {
			if (empty($notify_user->email1) && empty($notify_user->email2)) {
				$this->log->warn("Notifications: no e-mail address set for user {$notify_user->user_name}, cancelling send");
			}
			else {
				// send the e-mail!
				$notify_address = (empty($notify_user->email1)) ? $notify_user->email2 : $notify_user->email1;
				$notify_name = (empty($notify_user->first_name)) ? $notify_user->user_name : "{$notify_user->first_name} {$notify_user->last_name}";
				$this->log->debug("Notifications: user has e-mail defined");

				require_once("include/phpmailer/class.phpmailer.php");
				$notify_mail = new phpmailer;

				$notify_mail->AddAddress($notify_address, $notify_name);
				//$notify_mail->Subject = $admin->settings['notify_subject'];
				//$notify_mail->Body = "{$notify_name},\n\n{$current_user->user_name} has assigned a" . (in_array(substr($this->object_name, 0, 1), array("A", "E", "I", "O", "U")) ? "n" : "") . " {$this->object_name} to you.  Please click the link below to visit it:\n\n{$site_URL}/index.php?module={$app_list_strings['record_type_module'][$this->object_name]}&action=DetailView&record={$this->id}\n\n[Sugar Sales {$sugar_version}]";

				if (empty($_SESSION['authenticated_user_language'])) {
					$current_language = $default_language;
				}
				else {
					$current_language = $_SESSION['authenticated_user_language'];
				}

				require_once("XTemplate/xtpl.php");
				$xtpl = new XTemplate("include/language/{$current_language}.notify_template.html");

				$template_name = $this->object_name;
				switch ($this->object_name) {
					case "Quote":
						$xtpl->assign("QUOTE_SUBJECT", $this->name);
						$xtpl->assign("QUOTE_STATUS", $this->quote_stage);
						$xtpl->assign("QUOTE_CLOSEDATE", $this->date_quote_expected_closed);
						$xtpl->assign("QUOTE_DESCRIPTION", $this->description);
						break;
					case "Account":
						$xtpl->assign("ACCOUNT_NAME", $this->name);
						$xtpl->assign("ACCOUNT_TYPE", $this->account_type);
						$xtpl->assign("ACCOUNT_DESCRIPTION", $this->description);
						break;
					case "Case":
						$xtpl->assign("CASE_SUBJECT", $this->name);
						$xtpl->assign("CASE_PRIORITY", $this->priority);
						$xtpl->assign("CASE_STATUS", $this->status);
						$xtpl->assign("CASE_DESCRIPTION", $this->description);
						break;
					case "Task":
						$xtpl->assign("TASK_SUBJECT", $this->name);
						$xtpl->assign("TASK_PRIORITY", $this->priority);
						$xtpl->assign("TASK_DUEDATE", $this->date_due . " " . $this->time_due);
						$xtpl->assign("TASK_STATUS", $this->status);
						$xtpl->assign("TASK_DESCRIPTION", $this->description);
						break;
					case "Meeting":
						$xtpl->assign("MEETING_SUBJECT", $this->name);
						$xtpl->assign("MEETING_STATUS", $this->status);
						$xtpl->assign("MEETING_STARTDATE", $this->date_start . " " . $this->time_start);
						$xtpl->assign("MEETING_HOURS", $this->duration_hours);
						$xtpl->assign("MEETING_MINUTES", $this->duration_minutes);
						$xtpl->assign("MEETING_DESCRIPTION", $this->description);
						break;
					case "Email":
						$xtpl->assign("EMAIL_SUBJECT", $this->name);
						$xtpl->assign("EMAIL_DATESENT", $this->date_start . " " . $this->time_start);
						break;
					case "Call":
						$xtpl->assign("CALL_SUBJECT", $this->name);
						$xtpl->assign("CALL_STARTDATE", $this->date_start . " " . $this->time_start);
						$xtpl->assign("CALL_HOURS", $this->duration_hours);
						$xtpl->assign("CALL_MINUTES", $this->duration_minutes);
						$xtpl->assign("CALL_STATUS", $this->status);
						$xtpl->assign("CALL_DESCRIPTION", $this->description);
						break;
					case "Contact":
						$xtpl->assign("CONTACT_NAME", trim($this->first_name . " " . $this->last_name));
						$xtpl->assign("CONTACT_DESCRIPTION", $this->description);
						break;
					case "Lead":
						$xtpl->assign("LEAD_NAME", trim($this->first_name . " " . $this->last_name));
						$xtpl->assign("LEAD_SOURCE", $this->lead_source);
						$xtpl->assign("LEAD_STATUS", $this->status);
						$xtpl->assign("LEAD_DESCRIPTION", $this->description);
						break;
					case "Opportunity":
						$xtpl->assign("OPPORTUNITY_NAME", $this->name);
						$xtpl->assign("OPPORTUNITY_AMOUNT", $this->amount);
						$xtpl->assign("OPPORTUNITY_CLOSEDATE", $this->date_closed);
						$xtpl->assign("OPPORTUNITY_STAGE", $this->sales_stage);
						$xtpl->assign("OPPORTUNITY_DESCRIPTION", $this->description);
						break;
					default:
						$xtpl->assign("OBJECT", $this->object_name);
						$template_name = "Default";
				}

				$xtpl->assign("ASSIGNED_USER", $notify_name);
				$xtpl->assign("ASSIGNER", $current_user->user_name);
				$xtpl->assign("URL", "{$site_URL}/index.php?module={$app_list_strings['record_type_module'][$this->object_name]}&action=DetailView&record={$this->id}");
				$xtpl->assign("SUGAR", "Sugar Sales v{$sugar_version}");
				$xtpl->parse($template_name);
				$xtpl->parse($template_name . "_Subject");

				$notify_mail->Body = from_html(trim($xtpl->text($template_name)));
				$notify_mail->Subject = from_html($xtpl->text($template_name . "_Subject"));
				$notify_mail->From = $admin->settings['notify_fromaddress'];
				$notify_mail->FromName = (empty($admin->settings['notify_fromname'])) ? "" : $admin->settings['notify_fromname'];
				if ($admin->settings['mail_sendtype'] == "SMTP") {
					$notify_mail->Mailer = "smtp";
					$notify_mail->Host = $admin->settings['mail_smtpserver'];
					$notify_mail->Port = $admin->settings['mail_smtpport'];
					if ($admin->settings['mail_smtpauth_req']) {
						$notify_mail->SMTPAuth = TRUE;
						$notify_mail->Username = $admin->settings['mail_smtpuser'];
						$notify_mail->Password = $admin->settings['mail_smtppass'];
					}
				}

				if(!$notify_mail->Send()) {
					$this->log->warn("Notifications: error sending e-mail to {$notify_address} (method: {$notify_mail->Mailer}), (error: {$notify_mail->ErrorInfo})");
				}
				else {
					$this->log->info("Notifications: e-mail successfully sent to {$notify_address}");
				}
			}
		}
	}
	else {
		$this->log->info("Notifications: not sending e-mail, notify_on is set to OFF");
	}
}

    /**
     * This function is a good location to save changes that have been made to a relationship.
     * This should be overriden in subclasses that have something to save.
     * param $is_update true if this save is an update.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
     */
    function save_relationship_changes($is_update)
    {

    }

    /**
     * This function retrieves a record of the appropriate type from the DB.
     * It fills in all of the fields from the DB into the object it was called on.
     * param $id - If ID is specified, it overrides the current value of $this->id.  If not specified the current value of $this->id will be used.
     * returns this - The object that it was called apon or null if exactly 1 record was not found.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
     */
	function retrieve($id = -1, $encode=true) {
		if ($id == -1) {
			$id = $this->id;
		}

		$query = "SELECT $this->table_name.* FROM $this->table_name ";








		$query .= " WHERE $this->table_name.id = '$id' ";

		$this->log->debug("Retrieve $this->object_name: ".$query);

		$result =& $this->db->requireSingleResult($query, true, "Retrieving record by id $this->table_name:$id found ");

		if(empty($result))
		{
			return null;
		}

		$row = $this->db->fetchByAssoc($result, -1, $encode);

		foreach($this->column_fields as $field)
		{
			if(isset($row[$field]))
			{
				$this->$field = $row[$field];
			}else{
				$this->$field = '';
			}
		}

		$this->fill_in_additional_detail_fields();

		return $this;
	}

	/**
	 * This function returns a paged list of the current object type.  It is intended to allow for
	 * hopping back and forth through pages of data.  It only retrieves what is on the current page.
	 * This method must be called on a new instance.  It trashes the values of all the fields in the current one.
	 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc..
	 * All Rights Reserved..
	 * Contributor(s): ______________________________________..
	 */
	function get_list($order_by = "", $where = "", $row_offset = 0, $limit=-1, $max=-1) {
		$this->log->debug("get_list:  order_by = '$order_by' and where = '$where' and limit = '$limit'");

		$query = $this->create_list_query($order_by, $where);

		return $this->process_list_query($query, $row_offset, $limit, $max);
	}

	/**
	 * This function returns a full (ie non-paged) list of the current object type.
	 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc..
	 * All Rights Reserved..
	 * Contributor(s): ______________________________________..
	 */
	function get_full_list($order_by = "", $where = "") {
		$this->log->debug("get_full_list:  order_by = '$order_by' and where = '$where'");
		$query = $this->create_list_query($order_by, $where);
		return $this->process_full_list_query($query);
	}

	function create_list_query($order_by, $where)
	{
		$query = "SELECT $this->table_name.* FROM $this->table_name ";




		if($where != "")
			$query .= "where ($where) AND ".$this->table_name.".deleted=0 ";
		else
			$query .= "where ".$this->table_name.".deleted=0 ";

		if(!empty($order_by))
			$query .= " ORDER BY $order_by";



		return $query;
	}

	function process_list_query($query, $row_offset, $limit= -1, $max_per_page = -1)
	{
		global $list_max_entries_per_page;
		$this->log->debug("process_list_query: ".$query);
		if(!empty($limit) && $limit != -1){
			$result =& $this->db->limitQuery($query, $row_offset + 0, $limit,true,"Error retrieving $this->object_name list: ");
		}else{
			$result =& $this->db->query($query,true,"Error retrieving $this->object_name list: ");
		}

		$list = Array();
		if($max_per_page == -1){
			$max_per_page 	= $list_max_entries_per_page;
		}
		$rows_found =  $this->db->getRowCount($result);

		$this->log->debug("Found $rows_found ".$this->object_name."s");

		$previous_offset = $row_offset - $max_per_page;
		$next_offset = $row_offset + $max_per_page;

		if($rows_found != 0)
		{

			// We have some data.

			for($index = $row_offset , $row = $this->db->fetchByAssoc($result, $index); $row && ($index < $row_offset + $max_per_page || $max_per_page == -99) ;$index++, $row = $this->db->fetchByAssoc($result, $index)){
				foreach($this->list_fields as $field)
				{
					if (isset($row[$field])) {
						$this->$field = $row[$field];


						$this->log->debug("$this->object_name({$row['id']}): ".$field." = ".$this->$field);
					}else if (isset($row[$this->table_name .'.'.$field])) {
						$this->$field = $row[$this->table_name .'.'.$field];


						$this->log->debug("$this->object_name({$row[$this->table_name .'.'.'id']}): ".$field." = ".$this->$field);

					}
					else
					{
						$this->$field = "";
					}
				}

				$this->fill_in_additional_list_fields();

				$list[] = $this;
			}
		}

		$response = Array();
		$response['list'] = $list;
		$response['row_count'] = $rows_found;
		$response['next_offset'] = $next_offset;
		$response['previous_offset'] = $previous_offset;

		return $response;
	}

	function process_full_list_query($query)
	{
		$this->log->debug("process_full_list_query: query is ".$query);
		$result =& $this->db->query($query, false);
		$this->log->debug("process_full_list_query: result is ".$result);

		if($this->db->getRowCount($result) > 0){

			// We have some data.
			while ($row = $this->db->fetchByAssoc($result)) {
				foreach($this->list_fields as $field)
				{
					if (isset($row[$field])) {
						$this->$field = $row[$field];

						$this->log->debug("process_full_list: $this->object_name({$row['id']}): ".$field." = ".$this->$field);
					}else {
						$this->$field = '';
					}
				}

				$this->fill_in_additional_list_fields();

				$list[] = $this;
			}
		}

		if (isset($list)) return $list;
		else return null;
	}

	/**
	 * Track the viewing of a detail record.  This leverages get_summary_text() which is object specific
	 * params $user_id - The user that is viewing the record.
	 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc..
	 * All Rights Reserved..
	 * Contributor(s): ______________________________________..
	 */
	function track_view($user_id, $current_module)
	{
		$this->log->debug("About to call tracker (user_id, module_name, item_id)($user_id, $current_module, $this->id)");

		$tracker = new Tracker();
		$tracker->track_view($user_id, $current_module, $this->id, $this->get_summary_text());
	}

	/**
	 * return the summary text that should show up in the recent history list for this object.
	 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc..
	 * All Rights Reserved..
	 * Contributor(s): ______________________________________..
	 */
	function get_summary_text()
	{
		return "Base Implementation.  Should be overridden.";
	}

	/**
	 * This is designed to be overridden and add specific fields to each record.  This allows the generic query to fill in
	 * the major fields, and then targetted queries to get related fields and add them to the record.  The contact's account for instance.
	 * This method is only used for populating extra fields in lists
	 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc..
	 * All Rights Reserved..
	 * Contributor(s): ______________________________________..
	 */
	function fill_in_additional_list_fields()
	{
	}

	/**
	 * This is designed to be overridden and add specific fields to each record.  This allows the generic query to fill in
	 * the major fields, and then targetted queries to get related fields and add them to the record.  The contact's account for instance.
	 * This method is only used for populating extra fields in the detail form
	 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc..
	 * All Rights Reserved..
	 * Contributor(s): ______________________________________..
	 */
	function fill_in_additional_detail_fields()
	{
	}

	/**
	 * This is a helper class that is used to quickly created indexes when createing tables
	 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc..
	 * All Rights Reserved..
	 * Contributor(s): ______________________________________..
	 */
	function create_index($query)
	{
		$this->log->info($query);

		$result =& $this->db->query($query, true, "Error creating index:");
	}

	/** This function should be overridden in each module.  It marks an item as deleted.
	* If it is not overridden, then marking this type of item is not allowed
	 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc..
	 * All Rights Reserved..
	 * Contributor(s): ______________________________________..
	*/
	function mark_deleted($id)
	{
		$query = "UPDATE $this->table_name set deleted=1 where id='$id'";
		$this->db->query($query, true,"Error marking record deleted: ");

		$this->mark_relationships_deleted($id);

		// Take the item off of the recently viewed lists.
		$tracker = new Tracker();
		$tracker->delete_item_history($id);

	}

	/** This function deletes relationships to this object.  It should be overridden to handle the relationships of the specific object.
	* This function is called when the item itself is being deleted.  For instance, it is called on Contact when the contact is being deleted.
	 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc..
	 * All Rights Reserved..
	 * Contributor(s): ______________________________________..
	*/
	function mark_relationships_deleted($id)
	{

	}

	/**
	 * This function is used to execute the query and create an array template objects from the resulting ids from the query.
	 * It is currently used for building sub-panel arrays.
	 * param $query - the query that should be executed to build the list
	 * param $template - The object that should be used to copy the records.
	 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc..
	 * All Rights Reserved..
	 * Contributor(s): ______________________________________..
	 */
	function build_related_list($query, &$template)
	{

		$this->log->debug("Finding linked records $this->object_name: ".$query);

		$result =& $this->db->query($query, true);

		$list = Array();

		while($row = $this->db->fetchByAssoc($result))
		{
			$record = $template->retrieve($row['id']);

			if($record != null)
			{
				// this copies the object into the array
				$list[] = $template;
			}
		}

		return $list;
	}

	/**
	 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc..
	 * All Rights Reserved..
	 * Contributor(s): ______________________________________..
	 */
	function build_related_list2($query, &$template, &$field_list)
	{

		$this->log->debug("Finding linked values $this->object_name: ".$query);

		$result =& $this->db->query($query, true);

		$list = Array();

		while($row = $this->db->fetchByAssoc($result))
		{
			// Create a blank copy
			$copy = $template;

			foreach($field_list as $field)
			{
				// Copy the relevant fields
				$copy->$field = $row[$field];

			}


			// this copies the object into the array
			$list[] = $copy;
		}

		return $list;
	}

	/* This is to allow subclasses to fill in row specific columns of a list view form */
	function list_view_parse_additional_sections(&$list_form)
	{
	}

	/* This function assigns all of the values into the template for the list view */
	function get_list_view_array(){
		$return_array = Array();
		foreach($this->list_fields as $field)
		{
			$return_array[strtoupper($field)] = $this->$field;
		}

		return $return_array;
	}
	function get_list_view_data()
	{

		return $this->get_list_view_array();
	}

	function get_where(&$fields_array)
	{
		$where_clause = "WHERE ";
		$first = 1;
		foreach ($fields_array as $name=>$value)
		{
			if ($first)
			{
				$first = 0;
			}
			else
			{
				$where_clause .= " AND ";
			}

			$where_clause .= "$name = '".PearDatabase::quote($value)."'";
		}

		$where_clause .= " AND deleted=0";
		return $where_clause;
	}


	function retrieve_by_string_fields($fields_array, $encode=true)
	{
		$where_clause = $this->get_where($fields_array);

		$query = "SELECT * FROM $this->table_name $where_clause";
		$this->log->debug("Retrieve $this->object_name: ".$query);
		$result =& $this->db->requireSingleResult($query, true, "Retrieving record $where_clause:");
		if( empty($result))
		{
		 	return null;
		}

		$row = $this->db->fetchByAssoc($result, -1, $encode);

		foreach($this->column_fields as $field)
		{
			if(isset($row[$field]))
			{
				$this->$field = $row[$field];
			}
		}
		$this->fill_in_additional_detail_fields();
		return $this;
	}

	// this method is called during an import before inserting a bean
	// define an associative array called $special_fields
	// the keys are user defined, and don't directly map to the bean's fields
	// the value is the method name within that bean that will do extra
	// processing for that field. example: 'full_name'=>'get_names_from_full_name'

	function process_special_fields()
	{
		foreach ($this->special_functions as $func_name)
		{
			if ( method_exists($this,$func_name) )
			{
				$this->$func_name();
			}
		}
	}
	/**
		builds a generic search based on the query string using or
		do not include any $this-> because this is called on without having the class instantiated
	*/
	function build_generic_where_clause($value){
			$where_clause = "WHERE ";
		$first = 1;
		foreach ($fields_array as $name=>$value)
		{
			if ($first)
			{
				$first = 0;
			}
			else
			{
				$where_clause .= " or";
			}

			$where_clause .= "$name = '".PearDatabase::quote($value)."'";
		}

		$where_clause .= " AND deleted=0";
		return $where_clause;
	}




















	function parse_additional_headers(&$list_form, $xTemplateSection) {
			return $list_form;

	}
}

?>
