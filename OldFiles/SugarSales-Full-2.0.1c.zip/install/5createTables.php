<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/sugarcrm/install/5createTables.php,v 1.69 2004/11/04 02:25:46 lam Exp $
 * Description:  Executes a step in the installation process.
 ********************************************************************************/

if (isset($_REQUEST['db_name'])) $db_name  				= $_REQUEST['db_name'];
if (isset($_REQUEST['db_drop_tables'])) $db_drop_tables 	= $_REQUEST['db_drop_tables'];
if (isset($_REQUEST['db_create'])) $db_create 			= $_REQUEST['db_create'];
if (isset($_REQUEST['db_populate'])) $db_populate		= $_REQUEST['db_populate'];
if (isset($_REQUEST['admin_email'])) $admin_email		= $_REQUEST['admin_email'];
if (isset($_REQUEST['admin_password'])) $admin_password	= $_REQUEST['admin_password'];

$new_tables = 0;
$new_config = 0;

require_once('include/logging.php');
require_once('data/Tracker.php');
require_once('include/utils.php');
require_once('include/modules.php');

global $beanFiles;
foreach ($beanFiles as $bean=>$file) {
	require_once($file);
}

// load up the config_override.php file.  This is used to provide default user settings
if (is_file("config_override.php")) {
	require_once("config_override.php");
}
$db = new PearDatabase();
$log =& LoggerManager::getLogger('create_table');

function createSchemaTable () {
	global $log;
	// create the schema tables
	$query = "CREATE TABLE modules (id int(11) NOT NULL auto_increment,
				name text,
				PRIMARY KEY ( ID ))";

	$this->query($query);
}


function createObjectTable () {
	global $log;
	// create the object tables
	$query = "CREATE TABLE objects (
		module_id int(11),
		name text,
		PRIMARY KEY ( module_id, name ))";

	$this->query($query);
}

function createAttributesTable () {
	global $log;
	// create the attributes tables
	$query = "CREATE TABLE attributes (
		module_id int(11),
		object_name text,
		name text,

		PRIMARY KEY ( module_id, object_name ))";
	// fk module_id, object_name -> object table.

	$this->query($query);
}

function createLabelsTable () {
	global $log;
	// create the translation tables
	$query = "CREATE TABLE labels (
		module_id int(11),
		name text,
		value text,
		value_long text,
		value_popup text,
		PRIMARY KEY ( module_id, name ))";

	$this->query($query);
}

//Drop old tables if table exists and told to drop it
function drop_table_install(&$focus)
{

	global $log, $db;

	$result = $db->requireSingleResult("SHOW TABLES LIKE '".$focus->table_name."'");
	if (!empty($result)) {



		$focus->drop_tables();
		$log->info("<li>Dropped old ".$focus->table_name." table.");
		return 1;

	}
	else
	{
		$log->info("<li>Did not need to drop old ".$focus->table_name." table.  It doesn't exist.");
		return 0;
	}
}

// Creating new tables if they don't exist.
function create_table_install(&$focus)
{

	global $log, $db;
	$result = $db->query("SHOW TABLES LIKE '".$focus->table_name."'");
	if ($db->getRowCount($result) == 0)
	{
		$focus->create_tables();
		$log->info("<li>Created ".$focus->table_name." table.");
		return 1;
	}
	else
	{
		$log->info("<li>Table ".$focus->table_name." already exists.");
		return 0;
	}
}


function create_default_users()
{
	global $log, $db;
	global $admin_email;
	global $admin_password;
	global $create_default_user;
	global $default_user_name;
	global $default_password;
	global $default_user_is_admin;

	//Create default admin user
    $user = new User();
    $user->id = 1;
    $user->new_with_id = true;
    $user->last_name = 'Administrator';
	$user->user_name = 'admin';
	$user->title = "Administrator";
	$user->status = 'Active';
	$user->is_admin = 'on';
	$user->user_password = $user->encrypt_password($admin_password);
	$user->user_hash = strtolower(md5($admin_password));
	$user->email = $admin_email;
	$user->save();

	// We need to change the admin user to a fixed id of 1.
//	$query = "update users set id='1' where user_name='$user->user_name'";
//	$result = $db->query($query, true, "Error updating admin user ID: ");

	$log->info("Created ".$user->table_name." table. for user $user->id");

	if($create_default_user)
	{
		$default_user = new User();
		$default_user->last_name = $default_user_name;
	 	$default_user->user_name = $default_user_name;
		$default_user->status = 'Active';
			if (isset($default_user_is_admin) && $default_user_is_admin) $default_user->is_admin = 'on';
		$default_user->user_password = $default_user->encrypt_password($default_password);
		$default_user->save();
	}
}










































function insert_default_settings() {
	global $log, $db;

	$db->query("INSERT INTO config (category, name, value) VALUES ('notify', 'fromaddress', 'sugar@example.com')");
	$db->query("INSERT INTO config (category, name, value) VALUES ('notify', 'fromname', 'SugarCRM')");
	$db->query("INSERT INTO config (category, name, value) VALUES ('notify', 'send_by_default', '1')");
	$db->query("INSERT INTO config (category, name, value) VALUES ('notify', 'on', '0')");
	$db->query("INSERT INTO config (category, name, value) VALUES ('notify', 'subject', 'SugarCRM Notifications: New object assigned')");
	$db->query("INSERT INTO config (category, name, value) VALUES ('mail', 'smtpserver', 'localhost')");
	$db->query("INSERT INTO config (category, name, value) VALUES ('mail', 'smtpport', '25')");
	$db->query("INSERT INTO config (category, name, value) VALUES ('mail', 'sendtype', 'sendmail')");
	$db->query("INSERT INTO config (category, name, value) VALUES ('mail', 'smtpuser', '')");
	$db->query("INSERT INTO config (category, name, value) VALUES ('mail', 'smtppass', '')");
	$db->query("INSERT INTO config (category, name, value) VALUES ('mail', 'smtpauth_req', '0')");
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Sugar Sales Setup Wizard: Step 5</title>
<link rel="stylesheet" href="install/install.css" type="text/css" />
</head>
<body>
<table cellspacing="0" cellpadding="0" border="0" align="center" class="shell">
<tr>
    <th width="400">Step 5: Create Database Tables</th>
	<th width="200"><a href="http://www.sugarcrm.com" target="_blank"><img src="include/images/sugarcrm_logo.gif" alt="SugarCRM Logo" width="150" height="29" border="0" align="right"></a></th>
</tr>
<tr>
    <td colspan="2" width="600">

<?php

$startTime = microtime();

$focus = 0;

foreach ( $beanFiles as $bean=>$file)
{
	$focus = new $bean();

	if ($db_drop_tables == true )
	{
		$existed = drop_table_install($focus);

		if ($existed)
		{
			echo "<li><span class=stop>Dropped existing ".$focus->table_name." table</span><BR>\n";
		}
		else
		{
			echo "<li><span class=go>Table ".$focus->table_name." does not exist</span><BR>\n";
		}
	}
	$success = create_table_install($focus);

	if ( $success)
	{
		echo "<li><span class=go>Created new ".$focus->table_name." table</span><BR>\n";
		if ( $bean == "User")
		{
			$new_tables = 1;
		}
		if ( $bean == "Administration" ) {
			$new_config = 1;
		}
	}
	else
	{
		echo "<li>Table ".$focus->table_name." already exists<BR>\n";
	}

}

if ($new_config) {
	//die("inserting default settings");
	insert_default_settings();
}

if ($new_tables)
{
	create_default_users();




}

// populating the db with seed data
if ($db_populate)
{
	echo "<br><p>Populating seed data into $db_name";
	include("install/populateSeedData.php");
	echo "...<span class=go>done</span><BR></p>\n";
}

$endTime = microtime();

$deltaTime = microtime_diff($startTime, $endTime);




?>
<p>The database tables are now set up.</p>
<hr>
Total time: <?php echo "$deltaTime"; ?> seconds.<BR />
<hr>

<p>Your system is now installed and configured for use.  You will need to log in for the first time using the "admin"
userid and the password you entered in step 2.</p>
<?php
$fp = @fsockopen("www.sugarcrm.com", 80, $errno, $errstr, 3);
if (!$fp) {
 echo "<p><b>We could not detected an internet connection.</b> When you do have a connection, please visit <a href=\"http://www.sugarcrm.com/home/index.php?option=com_extended_registration&task=register\">http://www.sugarcrm.com/home/index.php?option=com_extended_registration&task=register</a> to register with SugarCRM. By letting us know a little bit about how your company plans to use Sugar Sales, we can ensure we are always delivering the right application for your business needs.</p>";
}
?>
	</td>
</tr>
<tr>
	<td align="right" colspan="2">
	<hr>
	<table cellspacing="0" cellpadding="0" border="0" class="stdTable">
		<tr>
		    <?php
		    if ($fp) {
				@fclose($fp);
			?><td><input class="button" type="button" name="cancel" value="Cancel" onclick="window.close();"/>&nbsp;&nbsp;&nbsp;&nbsp;<input class="button" type="button" name="back" value="Back" onclick="history.back()"/></td>
		    <form action="install.php" method="post" name="form" id="form" ><td>
			 <input type="hidden" name="file" value="6register.php">
	 <input class="button" type="submit" name="next" value="Next" />
				</form></td><?php
		    } else
		    {
		    	?>
				<td><input  name="cancel" value="Cancel" disabled/>&nbsp;&nbsp;&nbsp;&nbsp;<input   name="back" value="Back" disabled/></td>
		    <form action="index.php" method="post" name="form" id="form"><td>
			 <input type="hidden" name="default_user_name" value="admin">
	 <input class="button" type="submit" name="next" value="Finish" />
				</form></td>
				<?php
		    }?>
		</tr>
	</table>
	</td>
</tr>
</table>
<br>

</body>
</html>
