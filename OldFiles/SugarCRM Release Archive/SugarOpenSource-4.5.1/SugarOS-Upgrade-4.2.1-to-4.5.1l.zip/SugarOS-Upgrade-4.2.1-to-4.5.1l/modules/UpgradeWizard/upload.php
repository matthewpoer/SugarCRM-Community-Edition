<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************

 * Description:
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc. All Rights
 * Reserved. Contributor(s): ______________________________________..
 * *******************************************************************************/
logThis('At upload.php');
$stop = true; // flag to show "next"
$run = isset($_REQUEST['run']) ? $_REQUEST['run'] : '';
$out = '';

if(file_exists('ModuleInstall/PackageManager/PackageManagerDisplay.php')) {
	require_once('ModuleInstall/PackageManager/PackageManagerDisplay.php');
}

///////////////////////////////////////////////////////////////////////////////
////	UPLOAD FILE PROCESSING
switch($run) {
	case 'upload':
		logThis('running upload');
        $perform = false;
        $tempFile = '';

		if(isset($_REQUEST['release_id']) && $_REQUEST['release_id'] != ""){
            require_once('ModuleInstall/PackageManager/PackageManager.php');
            $pm = new PackageManager();
            $tempFile = '';
            $perform = false;
            if(!empty($_SESSION['ML_PATCHES'])){
            	$release_map = $_SESSION['ML_PATCHES'][$_REQUEST['release_id']];
            	if(!empty($release_map)){
            		$tempFile = $pm->download($release_map['category_id'], $release_map['package_id'], $_REQUEST['release_id'], getcwd().'/'.$sugar_config['upload_dir']);
            		$perform = true;
					if($release_map['type'] != 'patch'){
						$pm->performSetup($tempFile, $release_map['type'], false);
						header('Location: index.php?module=Administration&action=UpgradeWizard&view=module');
					}
            	}
            }

            $base_filename = urldecode($tempFile);
        }
        else if( empty( $_FILES['upgrade_zip']['tmp_name'] ) ) {
			logThis('ERROR: no file uploaded!');
			echo $mod_strings['ERR_UW_NO_FILE_UPLOADED'];

			// add PHP error if isset
			if(isset($_FILES['upgrade_zip']['error']) && !empty($_FILES['upgrade_zip']['error'])) {
				$out = "<b><span class='error'>{$mod_strings['ERR_UW_PHP_FILE_ERRORS'][$_FILES['upgrade_zip']['error']]}</span></b><br />";
			}
		} else {
			if(!move_uploaded_file($_FILES['upgrade_zip']['tmp_name'], getcwd().'/'.$sugar_config['upload_dir'].$_FILES['upgrade_zip']['name'])) {
				logThis('ERROR: could not move temporary file to final destination!');
				unlinkTempFiles();
				$out = "<b><span class='error'>{$mod_strings['ERR_UW_NOT_VALID_UPLOAD']}</span></b><br />";
			} else {
				$tempFile = getcwd().'/'.$sugar_config['upload_dir'].$_FILES['upgrade_zip']['name'];
				logThis('File uploaded to '.$tempFile);
                $base_filename = urldecode( $_REQUEST['upgrade_zip_escaped'] );
                $perform = true;
			}
        }
        if($perform){

		    $manifest_file = extractManifest($tempFile);

			if(is_file($manifest_file)) {
	    		require_once( $manifest_file );
				$error = validate_manifest( $manifest , $tempFile);
				if(!empty($error)) {
					$out = "<b><span class='error'>{$error}</span></b><br />";
					break;
				}
				$upgrade_zip_type = $manifest['type'];

				// exclude the bad permutations
				if($upgrade_zip_type != "patch") {
					logThis('ERROR: incorrect patch type found: '.$upgrade_zip_type);
					unlinkTempFiles();
					$out = "<b><span class='error'>{$mod_strings['ERR_UW_ONLY_PATCHES']}</span></b><br />";
					break;
				}


				$base_filename = preg_replace( "#\\\\#", "/", $base_filename );
				$base_filename = basename( $base_filename );

				mkdir_recursive( "$base_upgrade_dir/$upgrade_zip_type" );
				$target_path = "$base_upgrade_dir/$upgrade_zip_type/$base_filename";
				$target_manifest = remove_file_extension( $target_path ) . "-manifest.php";

				if(isset($manifest['icon']) && $manifest['icon'] != "" ) {
					logThis('extracting icons.');
					 $icon_location = extractFile( $tempFile ,$manifest['icon'] );
					 $path_parts = pathinfo( $icon_location );
					 copy( $icon_location, remove_file_extension( $target_path ) . "-icon." . $path_parts['extension'] );
				}

				if(copy($tempFile , $target_path)){
					logThis('copying manifest.php to final destination.');
					copy($manifest_file, $target_manifest);
					$out .= "{$base_filename} {$mod_strings['LBL_UW_FILE_UPLOADED']}.<br>\n";
				} else {
					logThis('ERROR: cannot copy manifest.php to final destination.');
					$out .= "<b><span class='error'>{$mod_strings['ERR_UW_UPLOAD_ERR']}</span></b><br />";
					break;
				}
			} else {
				logThis('ERROR: no manifest.php file found!');
				unlinkTempFiles();
				$out = "<b><span class='error'>{$mod_strings['ERR_UW_NO_MANIFEST']}</span></b><br />";
				break;
			}
			$_SESSION['install_file'] = clean_path($tempFile);
			logThis('zip file moved to ['.$_SESSION['install_file'].']');
			//rrs serialize manifest for saving in the db
			$serial_manifest = array();
			$serial_manifest['manifest'] = (isset($manifest) ? $manifest : '');
			$serial_manifest['installdefs'] = (isset($installdefs) ? $installdefs : '');
			$serial_manifest['upgrade_manifest'] = (isset($upgrade_manifest) ? $upgrade_manifest : '');
			$_SESSION['install_manifest'] = base64_encode(serialize($serial_manifest));
		}

		if(!empty($tempFile)) {
            $ifPatch = false;
    		if( isset( $manifest['copy_files']['from_dir'] ) && $manifest['copy_files']['from_dir'] != "" ){
		    	$from_dir = $manifest['copy_files']['from_dir'];
		    	$patch='patch';
		    	if(strpos(strtolower($from_dir),strtolower($patch)) >0){
		    		$ifPatch = true;
		    	}
			}
            if(!$ifPatch){
            	@dropIndexLeadsFor451iTo500Upgrade();
            }
			upgradeUWFiles($tempFile);
		}

	break; // end 'upload'

	case 'delete':
		logThis('running delete');

        if(!isset($_REQUEST['install_file']) || ($_REQUEST['install_file'] == "")) {
        	logThis('ERROR: trying to delete non-existent file: ['.$_REQUEST['install_file'].']');
            $error = $mod_strings['ERR_UW_NO_FILE_UPLOADED'];
        }

        // delete file in upgrades/patch
        $delete_me = urldecode( $_REQUEST['install_file'] );
        if(@unlink($delete_me)) {
        	logThis('unlinking: '.$delete_me);
            $out = basename($delete_me).$mod_strings['LBL_UW_FILE_DELETED'];
        } else {
        	logThis('ERROR: could not delete ['.$delete_me.']');
			$error = $mod_strings['ERR_UW_FILE_NOT_DELETED'].$delete_me;
        }

        // delete file in cache/upload
        $fileS = explode('/', $delete_me);
        $c = count($fileS);
        $fileName = (isset($fileS[$c-1]) && !empty($fileS[$c-1])) ? $fileS[$c-1] : $fileS[$c-2];
        $deleteUpload = getcwd().'/'.$sugar_config['upload_dir'].$fileName;
        logThis('Trying to delete '.$deleteUpload);
        if(!@unlink($deleteUpload)) {
        	logThis('ERROR: could not delete: ['.$deleteUpload.']');
        	$error = $mod_strings['ERR_UW_FILE_NOT_DELETED'].$sugar_config['upload_dir'].$fileName;
        }

        if(!empty($error)) {
			$out = "<b><span class='error'>{$error}</span></b><br />";
        }

        unlinkTempFiles();
        unlinkUploadFiles();
	break;
}
////	END UPLOAD FILE PROCESSING FORM
///////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////
////	READY TO INSTALL UPGRADES
$validReturn = getValidPatchName();
$ready = $validReturn['ready'];
$disabled = $validReturn['disabled'];
////	END READY TO INSTALL UPGRADES
///////////////////////////////////////////////////////////////////////////////

if(isset($_SESSION['install_file']) && !empty($_SESSION['install_file']) && is_file($_SESSION['install_file'])) {
	$stop = false;
} else {
	$stop = true;
}
$frozen = $out;

///////////////////////////////////////////////////////////////////////////////
////	UPLOAD FORM
$form =<<<eoq
<form name="the_form" id='the_form' enctype="multipart/form-data" action="index.php" method="post">
	<input type="hidden" name="module" value="UpgradeWizard">
	<input type="hidden" name="action" value="index">
	<input type="hidden" name="step" value="{$_REQUEST['step']}">
	<input type="hidden" name="run" value="upload">
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="tabForm">
<tr><td>
	<table width="450" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td>
				{$mod_strings['LBL_UPLOAD_UPGRADE']}
				<input type="file" onchange="uploadCheck();" name="upgrade_zip" size="40" />
			</td>
			<td valign="bottom">&nbsp;
				<input	id="upload_button" type=button
						{$disabled}
						value="{$mod_strings['LBL_UW_TITLE_UPLOAD']}"
						onClick="uploadCheck();document.the_form.upgrade_zip_escaped.value = escape( document.the_form.upgrade_zip.value );document.the_form.submit();" />
				<input type=hidden name="upgrade_zip_escaped" value="" />
			</td>
		</tr>
	</table>
</td></tr>
</table>
</form>
eoq;
$hidden_fields = "<input type=\"hidden\" name=\"module\" value=\"UpgradeWizard\">";
$hidden_fields .= "<input type=\"hidden\" name=\"action\" value=\"index\">";
$hidden_fields .= "<input type=\"hidden\" name=\"step\" value=\"{$_REQUEST['step']}\">";
$hidden_fields .= "<input type=\"hidden\" name=\"run\" value=\"upload\">";

$form2 = '';
if(class_exists("PackageManagerDisplay")) {
	$form2 = PackageManagerDisplay::buildPatchDisplay($form, $hidden_fields, 'index.php', array('patch', 'module'));
}
$form3 =<<<eoq2
<br>

<table width="100%" border="0" cellspacing="0" cellpadding="0" class="tabForm">
<tr><td>

	<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td>
				{$mod_strings['LBL_UW_FILES_QUEUED']}<br>
				{$ready}
			</td>
		</tr>
	</table>
</td></tr>
</table>
<script type="text/javascript" language="Javascript" src="include/JSON.js"></script>
<script>
 function uploadCheck(){
	//AJAX call for checking the file size and comparing with php.ini settings.
	var callback = {
		 success:function(r) {
		     var file_size = r.responseText;
		     //alert(file_size.length);
		     if(file_size.length >0){
		       var msg = SUGAR.language.get('UpgradeWizard','LBL_UW_FILE_SIZE');
		       msg = msg+file_size+SUGAR.language.get('UpgradeWizard','LBL_UW_FILE_BIGGER_MSG');
		       msg = msg+file_size+SUGAR.language.get('UpgradeWizard','LBL_BYTES_WEBSERVER_MSG');
		       alert(msg);
		       document.getElementById("upload_button").disabled='disabled';
		     }
		     else{
		       document.getElementById("upload_button").disabled='';
		     }
		 }
	}

    //var file_name = document.getElementById('upgrade_zip').value;
	var file_name = document.the_form.upgrade_zip.value;
	postData = 'file_name=' + JSON.stringify(file_name) + '&module=UpgradeWizard&action=UploadFileCheck&to_pdf=1';
	YAHOO.util.Connect.asyncRequest('POST', 'index.php', callback, postData);
}
</script>
eoq2;
$uwMain = $form.$form3;
////	END UPLOAD FORM
///////////////////////////////////////////////////////////////////////////////

$showBack		= true;
$showCancel		= true;
$showRecheck	= true;
$showNext		= ($stop) ? false : true;

$stepBack		= $_REQUEST['step'] - 1;
$stepNext		= $_REQUEST['step'] + 1;
$stepCancel		= -1;
$stepRecheck	= $_REQUEST['step'];


$_SESSION['step'][$steps['files'][$_REQUEST['step']]] = ($stop) ? 'failed' : 'success';

?>
