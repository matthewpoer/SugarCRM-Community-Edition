<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
require_once('include/pclzip/pclzip.lib.php');

function unzip( $zip_archive, $zip_dir ){
    if( !is_dir( $zip_dir ) ){
        die( "Specified directory '$zip_dir' for zip file '$zip_archive' extraction does not exist." );
    }

    $archive = new PclZip( $zip_archive );

    if( $archive->extract( PCLZIP_OPT_PATH, $zip_dir ) == 0 ){
        die( "Error: " . $archive->errorInfo(true) );
    }
}

function unzip_file( $zip_archive, $archive_file, $to_dir ){
    if( !is_dir( $to_dir ) ){
        die( "Specified directory '$to_dir' for zip file '$zip_archive' extraction does not exist." );
    }

    $archive = new PclZip( "$zip_archive" );
    if( $archive->extract(  PCLZIP_OPT_BY_NAME, $archive_file,
                            PCLZIP_OPT_PATH,    $to_dir         ) == 0 ){
        die( "Error: " . $archive->errorInfo(true) );
    }
}

function zip_dir( $zip_dir, $zip_archive ){
    $archive    = new PclZip( "$zip_archive" );
    $v_list     = $archive->create( "$zip_dir" );
    if( $v_list == 0 ){
        die( "Error: " . $archive->errorInfo(true) );
    }
}
?>
