<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');

class SugarHTMLArea {
	var $instanceName;
	var $BasePath	= 'include/htmlarea/' ;
	var $Height		= '400px' ;
	var $Value		= '';
	var $Width		= '100%';

	function SugarHTMLArea($instanceName) {
		$this->instanceName = $instanceName;
	}

	function display() {
		ob_start();
		?>
			<script type="text/javascript">
				_editor_url = "<?php echo $this->BasePath; ?>";
				_editor_lang = "en";
			</script>
			
			<!-- load the main HTMLArea file, this will take care of loading the CSS and other required core scripts. -->
			<script type="text/javascript" src="include/htmlarea/htmlarea.js"></script>
			</head>
			
			<!-- use <body onload="HTMLArea.replaceAll()" if you don't care about customizing the editor.  It's the easiest way! :) -->
			<textarea	id="<?php echo $this->instanceName; ?>" 
						name="<?php echo $this->instanceName; ?>" 
						style="width:100%" 
						rows="24" 
						cols="80"><?php echo $this->Value; ?>
			</textarea>
			<script>
				var html_editor = null;
				
				function initEditor() {
					// create an editor for the "ta" textbox
					html_editor = new HTMLArea("<?php echo $this->instanceName; ?>");
					
					setTimeout(function() {
							html_editor.generate();
						}, 1000);
					return false;
				}
				initEditor();
			</script>
		<?php

		$htmlarea_src =  ob_get_contents();
		ob_end_clean();
		return $htmlarea_src;
	} // end display();
}  // End class definition
?>
