<?php
    // $Id: sugar_version.php,v 1.34.2.7 2005/07/01 21:01:42 andrew Exp $
    $sugar_version      = '3.0.1b';
    $sugar_db_version   = '3.0.1';
?>
