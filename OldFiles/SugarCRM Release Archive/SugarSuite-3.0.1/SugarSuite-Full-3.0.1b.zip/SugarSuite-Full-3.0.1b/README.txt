Sugar Suite v3.0.1b
July 1, 2005

-=Overview=-
For a quick list of new features in Sugar Suite 3.0.1, check out 
the information below.

Our goal continues to be to build the customer relationship management 
system that you have always wanted, so your input is vital.

You can submit your feedback about the new release to our Sugar Forums
(http://www.sugarcrm.com/forums/).





Check out http://www.sugarcrm.com for more details on acquiring the Sugar 
Suite, the latest product roadmap, support forums, detailed product 
information and much more.  We hope you find this a useful tool for
building your business.

Enjoy! 
The Sugar Team  

-=IMPORTANT NOTES=-
Special Upgrade Install:
The 3.0.1 release provides an upgrade script and instructions that 
automates many, but not all, of the steps necessary to migrate 
a 3.0x version of Sugar Suite to the 3.0.1 release. The instructions
can be found with the 3.0.1 download, in the file 
"3_0 Upgrade Instructions.rtf". The upgrade script should be used for 
upgrading from 3.0x only, and not for applying patches. Please 
refer to PATCH.TXT for those steps.

--------------------------------------------------------------------------------
3.0.1b
--------------------------------------------------------------------------------





Fixed: Syncing a contact from Outlook with changes can cause the contact to be 
       unrelated from other components.
Fixed: Lead conversion doesn't associate notes to Contact, only Account
Fixed: Lead conversion doesn't create Account if Account has required custom 
       field

--------------------------------------------------------------------------------
3.0.1a
--------------------------------------------------------------------------------





Fixed: Saving a Call will not send an email to all call participants
Fixed: Error when deleting a Campaign


--------------------------------------------------------------------------------
3.0.1
--------------------------------------------------------------------------------






* New: Added HTTPS support to Outlook plug-in
* New: Added Contact and Calendar synchronization to the Outlook plug-in
* New: Added three new themes Sugar Lite, Rip Curl, Pipeline
* Fixed: Project ListView.html did not work properly with the Custom Layout Editor.
         This file must be overwritten in order for Project ListView data to be 
         visible.
* Fixed: Various Outlook plug-in fixes (searching, multiple record actions, 
         date time conversion and format)
* Fixed: Collection of SOAP API fixes added
* Fixed: Reports To button not visible to those with correct permissions
* Fixed: Error with attachments on email
* Fixed: Error with selecting user roles
* Fixed: Corrected problem where activity showed up multiple times in activities
         list on home screen
* Fixed: Dashboard Opportunities by Lead source can now include empty lead
* Fixed: Script error when viewing a note attachment
* Fixed: Duplicate call that did not retain Contact, or select user
* Fixed: Script error when printing from list view
* Fixed: Error when exporting Prospect list
* Fixed: Problem in Lead conversion resulting in php error
* Fixed: Error sorting Employee list view, by Reports To
