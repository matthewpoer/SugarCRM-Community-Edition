<?php
// $Id: sugar_version.php,v 1.44 2005/09/25 07:09:45 andrew Exp $
$sugar_version      = '3.5.1';
$sugar_db_version   = '3.5.1';
$sugar_flavor       = 'OS';
?>
