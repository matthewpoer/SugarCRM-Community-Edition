<?php
// array elements are regexp patterns, and must not contain '#' signs
$disc_client_ignore = array (
    // dirs
    "\\./cache/.*",
    "\\./examples/.*",
    // files
    "\\.*config\\.php\$",
    "\\.*sugarcrm\\.log\\.*",         "\\.*sync\\.log\\.*",
    "\\.htaccess\$",    
);

$disc_client_no_sync = array (
);
?>
