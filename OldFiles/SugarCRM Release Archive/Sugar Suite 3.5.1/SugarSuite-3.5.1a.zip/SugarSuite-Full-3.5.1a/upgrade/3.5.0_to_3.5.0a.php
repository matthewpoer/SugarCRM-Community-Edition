<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
   <meta http-equiv="Content-Script-Type" content="text/javascript">
   <meta http-equiv="Content-Style-Type" content="text/css">
   <title>SugarCRM Upgrade Wizard: 3.5 to 3.5a</title>
   <link rel="stylesheet" href="upgrade.css" type="text/css" />
</head>
<body>
<form action="index.php" method="post" id="form">
<table cellspacing="0" cellpadding="0" border="0" align="center" class="shell" style="height=15px;margin-bottom=0px">
<tr>
   <th width="400">Upgrade 3.5 to 3.5a</th>
   <th width="200" height="30" style="text-align: right;"><a href="http://www.sugarcrm.com" target=
      "_blank"><IMG src="../include/images/sugarcrm_login.png" width="120" height="19" alt="SugarCRM" border="0"></a></th>
</tr>
<tr>
   <td colspan="2" width="800">
<?PHP

chdir('..');
require_once('config.php');
require_once('include/database/PearDatabase.php');
$db = & PearDatabase::getInstance();

$sql_file = "3.5.0_to_3.5.0a_mysql.sql"; 
print( "<br>Running schema upgrade script $sql_file...<br><br>" );
run_sql_file( "upgrade/$sql_file" );

echo "<br>Fixing emails linked with opportunies....<br><br>";
require_once("upgrade/FixEmailOpportunities.php");
echo "Repairing Popups....<br><br>";
require_once("upgrade/upgradepopups.php");
echo '<br>';
echo "<br>Repairing Relationships....<br><br>";
require_once("modules/Administration/RebuildRelationship.php");
?>
        </td>
</tr>
<tr>
<td align="right" colspan="2">
<hr>
<table cellspacing="0" cellpadding="0" border="0" class="stdTable">
<tr>
<td> 
     <table cellspacing="0" cellpadding="0" border="0" class="stdTable">
       <tr>
       <?PHP




       		?>
    		<td><input class="button" type="button" name="goto" value="Finish" onclick="document.location.href='<?PHP echo $sugar_config['site_url']; ?>/index.php'" /></td>
       		 <?PHP



       ?>
       </tr>
     </table>
</td>
</tr>
</table>
</td>
</tr>
</table>
</form>
</body>
</html>
