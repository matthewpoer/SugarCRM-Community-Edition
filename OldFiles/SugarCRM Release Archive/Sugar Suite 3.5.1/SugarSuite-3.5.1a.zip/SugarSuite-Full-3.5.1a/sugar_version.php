<?php
// $Id: sugar_version.php,v 1.44.2.1 2005/10/04 23:44:37 andrew Exp $
$sugar_version      = '3.5.1a';
$sugar_db_version   = '3.5.1';
$sugar_flavor       = 'OS';
?>
