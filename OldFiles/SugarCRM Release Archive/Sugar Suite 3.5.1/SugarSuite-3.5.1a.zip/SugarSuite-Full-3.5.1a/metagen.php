<?php
die('No Access');
?>
