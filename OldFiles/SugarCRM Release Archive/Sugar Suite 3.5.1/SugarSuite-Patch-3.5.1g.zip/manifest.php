<?php
// created: 2006-03-13 12:00:00
$manifest = array (
  'acceptable_sugar_flavors' => 
  array (
    0 => 'OS',
  ),
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '3\\.5\\.1',
    ),
  ),
  'author' => 'SugarCRM, Inc.',
  'copy_files' => 
  array (
    'from_dir' => 'SugarSuite-Patch-3.5.1g',
    'to_dir' => '',
    'force_copy' => 
    array (
    ),
  ),
  'description' => '',
  'icon' => '',
  'is_uninstallable' => false,
  'name' => 'SugarSuite',
  'published_date' => '2006-03-13 12:00:00',
  'type' => 'patch',
  'version' => '3.5.1g',
);
?>
