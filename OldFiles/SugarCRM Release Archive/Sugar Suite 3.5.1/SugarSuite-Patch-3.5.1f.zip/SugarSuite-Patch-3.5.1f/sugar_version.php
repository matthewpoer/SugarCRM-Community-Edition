<?php
// $Id: sugar_version.php,v 1.44.2.4.2.1 2005/12/10 02:06:07 andrew Exp $
$sugar_version      = '3.5.1f';
$sugar_db_version   = '3.5.1';
$sugar_flavor       = 'OS';
?>
