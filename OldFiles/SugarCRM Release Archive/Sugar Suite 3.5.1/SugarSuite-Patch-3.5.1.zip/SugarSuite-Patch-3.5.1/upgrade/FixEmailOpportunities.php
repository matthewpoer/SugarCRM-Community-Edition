<?php
if( !is_file( "config.php" ) ){
    // running directly, not from index.php
    chdir( ".." );
}
require_once("config.php");
require_once("include/database/PearDatabase.php");

$db = & PearDatabase::getInstance();
$result = $db->query("UPDATE emails SET parent_type='Opportunities' WHERE parent_type ='Opportunitys'");

echo "<br>Emails linked with Opportunities corrected.<br><br>";
?>
