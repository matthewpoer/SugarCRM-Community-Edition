<?php
/**
 * This script executes before the files are copied during the install.
 *
 * LICENSE: The contents of this file are subject to the SugarCRM Professional
 * End User License Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/EULA.  By installing or using this file, You have
 * unconditionally agreed to the terms and conditions of the License, and You
 * may not use this file except in compliance with the License.  Under the
 * terms of the license, You shall not, among other things: 1) sublicense,
 * resell, rent, lease, redistribute, assign or otherwise transfer Your
 * rights to the Software, and 2) use the Software for timesharing or service
 * bureau purposes such as hosting the Software for commercial gain and/or for
 * the benefit of a third party.  Use of the Software may be subject to
 * applicable fees and any use of the Software without first paying applicable
 * fees is strictly prohibited.  You do not have the right to remove SugarCRM
 * copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2005 SugarCRM, Inc.; All Rights Reserved.
 */

// $Id: pre_install.php,v 1.3 2005/09/25 23:23:58 bob Exp $

require_once ('include/database/PearDatabase.php');
require_once ('include/utils.php');
require_once ('include/TimeDate.php');
require_once ('modules/Users/User.php');

/////////////////////////////////////////////////////////////////////
// HELPER FUNCTIONS
function _massEmailUpdateDone($db, $massName) {
	$query = "SELECT id FROM versions WHERE name = '".$massName."'";
	$result = $db->query($query);
	if($db->getRowCount($result) > 0) {
		$GLOBALS['log']->debug($massName."-Found ".$db->getRowCount($result)." rows.");
		return true;
	} else {
		$GLOBALS['log']->debug($massName."-Found ".$db->getRowCount($result)." rows.");
		return false;
	}	
}

function _setMassEmailUpdateDone($db, $massName) {
	$user = new User();
	// do something here to set the "done" condition
	// ID,deleted,date_entered,date_modified,modified_user_id,created_by,name,file_version,db_version
	$guid = create_guid();
	$dateEntered = gmdate("Y-m-d H:i:s");
	$dateModified = $dateEntered;
	$uid = '1';
	
	$query = "INSERT INTO versions VALUES('".$guid."',0,'".$dateEntered."', '".$dateModified."','".$uid."','".$uid."','".$massName."','3.5.1','3.5.1')";
	
	$GLOBALS['log']->debug($massName."-DB connection made.");
	
	if($db->tableExists('versions')) {
		$db->query($query);
		$GLOBALS['log']->debug($massName."-QUERY: ".$query);
	} else {
		$GLOBALS['log']->fatal($massName."-Could not update versions table!");
		die("Versions table does not exist.");
	}
}

function _do_mass_email_update()
{
    global $db;
	$massName = 'Mass Email Sent Date Update';

	if(!_massEmailUpdateDone($db, $massName)) {
		$db = & PearDatabase :: getInstance();
		$timedate = new TimeDate();
		//$conn = mysql_connect("localhost", "chris", "");
		//$db = mysql_select_db("sugarcrm");
		$offset = date('Z');
		$interval = '- INTERVAL '.$offset.' second';

		$q = "SELECT DISTINCT CONCAT(campaigns.name, CONCAT(': ',email_templates.subject)) AS email_campaign, from_addr, from_name "
			. 'FROM campaigns '
			. 'LEFT JOIN email_marketing ON (email_marketing.campaign_id = campaigns.id) '
			. 'LEFT JOIN email_templates ON (email_templates.id = email_marketing.template_id);';
		$GLOBALS['log']->debug($massName."-Initial query: ".$q);
		$result = $db->query($q);
		$rows = $db->getRowCount($result);
		$GLOBALS['log']->debug($massName."-Row count from Initial Query: ".$db->getRowCount($result));

		if($rows > 0) {
			for ($i = 0; $i < $rows; $i ++) {
			$a1 = mysql_fetch_array($result);
			$q3 = "UPDATE emails SET date_start=LEFT(CONCAT(date_start, CONCAT(' ', time_start)) $interval,10), ";
			$q3 .= "time_start=RIGHT(CONCAT(date_start, CONCAT(' ', time_start)) $interval,8) ";
			$q3 .= "WHERE date_start IS NOT NULL AND time_start IS NOT NULL ";
			$q3 .= "AND name = '".str_replace("'", "\'", $a1["email_campaign"])."'";
			$q3 .= "AND from_addr = '".$a1["from_addr"]."' ";

			$queries[$i] = $q3;
			}
			$GLOBALS['log']->debug($massName."-Queries built to update date_start and time_start values in the emails table");
			$GLOBALS['log']->debug($massName."-NUMBER OF QUERIES TO RUN: ".$i);

			if ($_REQUEST['execute']) {
				$GLOBALS['log']->fatal("Massaging Mass Email : Generating seed data using query: ".$q);
				foreach ($queries as $query) {
					$db->query($query);
					$query_time .= $db->query_time;
					$GLOBALS['log']->fatal("Massaging Mass Email : Sent Times & Dates. Executing query: ".$query);
				}
			$GLOBALS['log']->fatal("Massaging Mass Email : Total query time: ".$query_time);
			}	
		} else {
			$GLOBALS['log']->fatal("Massaging Mass Email : No rows modified.");
		}
		_setMassEmailUpdateDone($db, $massName);
		echo "<p><b>Mass email archive patch successfully applied</b></p>\n";
	} else {
		echo "<p><b>Mass email archive patch already applied</b></p>\n";
		$GLOBALS['log']->debug($massName."-Update already applied OR perform_update not passed");
	}
}

function pre_install()
{
	global $unzip_dir;
	$self_dir = "$unzip_dir/scripts";
	_do_mass_email_update();
}

?>
