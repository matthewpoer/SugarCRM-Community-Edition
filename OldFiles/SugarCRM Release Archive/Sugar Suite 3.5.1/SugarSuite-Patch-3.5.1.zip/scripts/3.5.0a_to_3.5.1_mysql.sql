-- Upgrades Sugar DB version 3.5.0a to 3.5.1
-- $Id: 3.5.0a_to_3.5.1_mysql.sql,v 1.1 2005/09/25 20:54:39 andrew Exp $

--
-- custom_fields
--

ALTER TABLE `custom_fields`
MODIFY COLUMN `bean_id` char(36) default '',
MODIFY COLUMN `set_num` int(11) default '0',
MODIFY COLUMN `field0` char(255) default '',
MODIFY COLUMN `field1` char(255) default '',
MODIFY COLUMN `field2` char(255) default '',
MODIFY COLUMN `field3` char(255) default '',
MODIFY COLUMN `field4` char(255) default '',
MODIFY COLUMN `field5` char(255) default '',
MODIFY COLUMN `field6` char(255) default '',
MODIFY COLUMN `field7` char(255) default '',
MODIFY COLUMN `field8` char(255) default '',
MODIFY COLUMN `field9` char(255) default '',
MODIFY COLUMN `deleted` tinyint(1) default '0';

--
-- emailman
--

ALTER TABLE `emailman`
ADD COLUMN `user_name` varchar(255) default NULL
AFTER `deleted`;

ALTER TABLE `emailman`
ADD COLUMN `campaign_name` varchar(50) default NULL
AFTER `user_name`;

ALTER TABLE `emailman`
ADD COLUMN `to_contact` varchar(255) default NULL
AFTER `campaign_name`;

ALTER TABLE `emailman`
ADD COLUMN `to_prospect` varchar(255) default NULL
AFTER `to_contact`;

ALTER TABLE `emailman`
ADD COLUMN `to_lead` varchar(255) default NULL
AFTER `to_prospect`;

ALTER TABLE `emailman`
ADD COLUMN `contact_email` varchar(100) default NULL
AFTER `to_lead`;

ALTER TABLE `emailman`
ADD COLUMN `prospect_email` varchar(100) default NULL
AFTER `contact_email`;

ALTER TABLE `emailman`
ADD COLUMN `lead_email` varchar(100) default NULL
AFTER `prospect_email`;

--
-- emailman_sent
--

ALTER TABLE `emailman_sent`
ADD COLUMN `user_name` varchar(255) default NULL
AFTER `deleted`;

ALTER TABLE `emailman_sent`
ADD COLUMN `campaign_name` varchar(50) default NULL
AFTER `user_name`;

ALTER TABLE `emailman_sent`
ADD COLUMN `to_contact` varchar(255) default NULL
AFTER `campaign_name`;

ALTER TABLE `emailman_sent`
ADD COLUMN `to_prospect` varchar(255) default NULL
AFTER `to_contact`;

ALTER TABLE `emailman_sent`
ADD COLUMN `to_lead` varchar(255) default NULL
AFTER `to_prospect`;

ALTER TABLE `emailman_sent`
ADD COLUMN `contact_email` varchar(100) default NULL
AFTER `to_lead`;

ALTER TABLE `emailman_sent`
ADD COLUMN `prospect_email` varchar(100) default NULL
AFTER `contact_email`;

ALTER TABLE `emailman_sent`
ADD COLUMN `lead_email` varchar(100) default NULL
AFTER `prospect_email`;

--
-- emails
--

ALTER TABLE `emails`
MODIFY COLUMN `name` varchar(255) NOT NULL default '';

--
-- opportunities
--

ALTER TABLE `opportunities`
MODIFY COLUMN `opportunity_type` varchar(255) default NULL,
MODIFY COLUMN `probability` double default NULL;













--
-- update the Sugar db version
--

DELETE FROM `config`
WHERE `category` = 'info' AND `name` = 'sugar_version';

INSERT INTO `config` (`category`, `name`, `value`)
VALUES ('info', 'sugar_version', '3.5.1');

