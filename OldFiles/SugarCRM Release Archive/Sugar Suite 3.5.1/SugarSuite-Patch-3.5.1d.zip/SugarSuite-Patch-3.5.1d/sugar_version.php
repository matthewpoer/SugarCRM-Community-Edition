<?php
// $Id: sugar_version.php,v 1.44.2.4 2005/11/15 18:44:36 andrew Exp $
$sugar_version      = '3.5.1d';
$sugar_db_version   = '3.5.1';
$sugar_flavor       = 'OS';
?>
