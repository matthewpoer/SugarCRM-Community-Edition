CREATE NONCLUSTERED INDEX idx_accounts_parent_id on accounts_audit (parent_id);

CREATE NONCLUSTERED INDEX idx_bugs_parent_id on bugs_audit (parent_id);


CREATE NONCLUSTERED INDEX idx_cases_parent_id on cases_audit (parent_id);

CREATE NONCLUSTERED INDEX idx_contacts_parent_id on contacts_audit (parent_id);


DROP TABLE dashboards;


CREATE NONCLUSTERED INDEX idx_leads_parent_id on leads_audit (parent_id);

CREATE NONCLUSTERED INDEX idx_opportunities_parent_id on opportunities_audit (parent_id);


ALTER TABLE [users] DROP COLUMN user_preferences;