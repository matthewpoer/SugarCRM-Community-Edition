create index idx_accounts_parent_id on accounts_audit (parent_id);

create index idx_bugs_parent_id on bugs_audit (parent_id);


create index idx_cases_parent_id on cases_audit (parent_id);

create index idx_contacts_parent_id on contacts_audit (parent_id);


DROP TABLE dashboards;

ALTER TABLE INBOUND_EMAIL ADD (mailbox2 CLOB NULL);

UPDATE INBOUND_EMAIL SET mailbox2 = mailbox;

ALTER TABLE INBOUND_EMAIL DROP COLUMN mailbox;

ALTER TABLE INBOUND_EMAIL RENAME COLUMN mailbox2 TO mailbox;


create index idx_leads_parent_id on leads_audit (parent_id);

create index dx_opportunities_parent_id on opportunities_audit (parent_id);


alter table users drop column user_preferences;