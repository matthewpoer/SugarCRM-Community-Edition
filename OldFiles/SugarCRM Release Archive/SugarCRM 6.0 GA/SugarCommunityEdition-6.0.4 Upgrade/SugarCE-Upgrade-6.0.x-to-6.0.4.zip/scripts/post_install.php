<?php
if(!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');

}
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2010 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

require_once(clean_path($unzip_dir.'/scripts/upgrade_utils.php'));




function add_EZ_PDF() {
	$cust_file =  "<?php\n";
	$cust_file .= '$sugarpdf_default["PDF_CLASS"] = "EZPDF";'."\n";
	$cust_file .= '$sugarpdf_default["PDF_ENABLE_EZPDF"] = "1";'."\n";
	$cust_file .= "?>\n";
	$file = 'custom/include/Sugarpdf/sugarpdf_default.php';
	if(!file_exists('custom/include/Sugarpdf')) {
		mkdir_recursive('custom/include/Sugarpdf'); // make sure the directory exists
	}
	
	file_put_contents($file,$cust_file);	
}


function rebuild_dashlets(){
    if(is_file('cache/dashlets/dashlets.php')) {
        unlink('cache/dashlets/dashlets.php');
    }
    
    global $sugar_version;
    if($sugar_version < '5.5.0') {
        require_once('include/SugarTheme/SugarTheme.php');
    }
    
    require_once('include/Dashlets/DashletCacheBuilder.php');

    $dc = new DashletCacheBuilder();
    $dc->buildCache();
}
function rebuild_roles(){
  $_REQUEST['upgradeWizard'] = true;
  require_once("data/SugarBean.php");
  global $ACLActions, $beanList, $beanFiles;
  include('modules/ACLActions/actiondefs.php');
  include('include/modules.php'); 
  global $sugar_version;
  if($sugar_version < '5.5.0') {
  	require_once('include/ListView/ListView.php');
  }
  include("modules/ACL/install_actions.php");
}

function upgrade_LDAP(){
	require_once('modules/Administration/Administration.php');
	$focus = new Administration();
	$focus->retrieveSettings('ldap', true);
	if(isset($focus->settings['ldap_admin_user']) && !empty($focus->settings['ldap_admin_user']))
	{
		$focus->saveSetting('ldap', 'authentication', '1');
	}else if(isset($focus->settings['ldap_admin_user'])) {
		$focus->saveSetting('ldap', 'authentication', '0');
	}
}
function runSqlFiles($origVersion,$destVersion,$queryType,$resumeFromQuery=''){
	global $sugar_config;
	global $unzip_dir;
	global $sugar_config;
	global $sugar_version;
	global $path;
	global $_SESSION;
	$self_dir = "$unzip_dir/scripts";

	// This flag is determined by the preflight check in the installer
	if(!isset($_SESSION['schema_change']) || /* pre-4.5.0 upgrade wizard */
		$_SESSION['schema_change'] == 'sugar') {
		_logThis("Upgrading the database from {$origVersion} to version {$destVersion}", $path);
		$origVersion = substr($origVersion, 0, 2) . 'x';
		$destVersion = substr($destVersion, 0, 2) . 'x';
		$schemaFileName = $origVersion."_to_".$destVersion;

		switch($sugar_config['dbconfig']['db_type']) {
			case 'mysql':
				$schemaFileName = $schemaFileName . '_mysql.sql';
				break;
			case 'mssql':
			    $schemaFileName = $schemaFileName . '_mssql.sql';
				break;
			case 'oci8':
				$schemaFileName = $schemaFileName . '_oracle.sql';
				break;
		}
		

		$schemaFile = $_SESSION['unzip_dir'].'/scripts/'.$schemaFileName;
		_logThis("Running SQL file $schemaFile", $path);
		if(is_file($schemaFile)) {
			//$sql_run_result = _run_sql_file($schemaFile);
			ob_start();
			@parseAndExecuteSqlFile($schemaFile,$queryType,$resumeFromQuery);
			ob_end_clean();
		} else {
			logThis("*** ERROR: Schema change script [{$schemaFile}] could not be found!", $path);
		}

	} else {
		_logThis('*** Skipping Schema Change Scripts - Admin opted to run queries manually and should have done so by now.', $path);
	}
}

function clearSugarImages(){
    $skipFiles = array('ACLRoles.gif','close.gif','delete.gif','delete_inline.gif','plus_inline.gif','sugar-yui-sprites-green.png',
             'sugar-yui-sprites-purple.png','sugar-yui-sprites-red.png','sugar-yui-sprites.png','themePreview.png');
    $themePath = clean_path(getcwd() . '/themes/Sugar/images');    
    $allFiles = array();    
    $allFiles = findSugarImages($themePath, $allFiles, $skipFiles);

    foreach( $allFiles as $the_file ){
        if( is_file( $the_file ) ){
            unlink( $the_file );
            _logThis("Deleted file: $the_file", $path);
        }
    }    
}

function findSugarImages($the_dir, $the_array, $skipFiles){
    if(!is_dir($the_dir)) {
        return $the_array;
    }
    $skipFiles = array_flip($skipFiles);
    $d = dir($the_dir);
    while (false !== ($f = $d->read())) {
        if($f == "." || $f == ".." ){
            continue;
        }
        if( is_file( "$the_dir/$f" ) && !isset($skipFiles[$f]) ){
            array_push( $the_array, "$the_dir/$f" );
        }
    }
    return( $the_array );
}

function findCompanyLogo($the_dir, $the_array){
    if(!is_dir($the_dir)) {
        return $the_array;
    }
    $d = dir($the_dir);
    while (false !== ($f = $d->read())) {
        if($f == "." || $f == ".." || $f == 'default'){
            continue;
        }
        if( is_file( "$the_dir/$f/images/company_logo.png" ) ){
            array_push( $the_array, "$the_dir/$f/images/company_logo.png" );
        }
    }
    return( $the_array );
}

function clearCompanyLogo(){
    $themePath = clean_path(getcwd() . '/themes');    
    $allFiles = array();    
    $allFiles = findCompanyLogo($themePath,$allFiles);

    foreach( $allFiles as $the_file ){
        if( is_file( $the_file ) ){
            unlink( $the_file );
            _logThis("Deleted file: $the_file", $path);
        }
    }    
}

function genericFunctions(){	
	$server_software = $_SERVER["SERVER_SOFTWARE"];
	if(strpos($server_software,'Microsoft-IIS') !== false)
	{
		if($sugar_version < '5.5.0'){
		    _logThis("Rebuild web.config.", $path);
		    include_once("modules/Administration/UpgradeIISAccess.php");
		}
	} else {
		///////////////////////////////////////////////////////////////////////////
        ////    FILESYSTEM SECURITY FIX (Bug 9365)
	    _logThis("Applying .htaccess update security fix.", $path);
        include_once("modules/Administration/UpgradeAccess.php");
	}

	///////////////////////////////////////////////////////////////////////////
	////	PRO/ENT ONLY FINAL TOUCHES


		///////////////////////////////////////////////////////////////////////////
	////	REBUILD JS LANG
	_logThis("Rebuilding JS Langauages", $path);
	rebuild_js_lang();

	///////////////////////////////////////////////////////////////////////////
	////	REBUILD DASHLETS
	_logThis("Rebuilding Dashlets", $path);
	rebuild_dashlets();


  	global $sugar_version;
    if($sugar_version < '5.5.0') {
        _logThis("Begin Upgrade LDAP authentication", $path);
        upgrade_LDAP();
        _logThis("End Upgrade LDAP authentication", $path);
        
        _logThis("BEGIN CLEAR COMPANY LOGO", $path);
        clearCompanyLogo();
        _logThis("END CLEAR COMPANY LOGO", $path);
        
        _logThis("BEGIN CLEAR IMAGES IN THEME SUGAR", $path);
        clearSugarImages();
        _logThis("END CLEAR IMAGES IN THEME SUGAR", $path);
    } 
    
	if($sugar_version < '5.5.1') {
    	_logThis("Begin Clear all English inline help files", $path);
    	clearHelpFiles();
    	_logThis("End all English inline help files", $path);
    }
    //Rebuild roles
     _logThis("Rebuilding Roles", $path);
	 if($sugar_version < '5.5.0') {
	     add_EZ_PDF();
     }
     ob_start();
     rebuild_roles();
     ob_end_clean();
}

function status_post_install_action($action){
	$currProg = post_install_progress();
	$currPostInstallStep = '';
	$postInstallQuery = '';
	if(is_array($currProg) && $currProg != null){
		foreach($currProg as $key=>$val){
			if($key==$action){
				return $val;
			}
		}
	}
	return '';
}

function post_install() {
	global $unzip_dir;
	global $sugar_config;
	global $sugar_version;
	global $path;
	global $_SESSION;
	if(!isset($_SESSION['sqlSkippedQueries'])){
	 	$_SESSION['sqlSkippedQueries'] = array();
	 }
	initialize_session_vars();
	if(!isset($unzip_dir) || $unzip_dir == null){
		$unzip_dir = $_SESSION['unzip_dir'];
	}
	_logThis('Entered post_install function.', $path);
	$self_dir = "$unzip_dir/scripts";

	///////////////////////////////////////////////////////////////////////////
	////	PUT DATABASE UPGRADE SCRIPT HANDLING HERE
	$new_sugar_version = getUpgradeVersion();
	$origVersion = substr(preg_replace("/[^0-9]/", "", $sugar_version),0,3);
	$destVersion = substr(preg_replace("/[^0-9]/", "", $new_sugar_version),0,3);

	if($origVersion < '550') {
        require('include/utils/autoloader.php');
        spl_autoload_register(array('SugarAutoLoader', 'autoload'));
        hide_subpanels_if_tabs_are_hidden();
	}    
	
	if($origVersion < '551') {
		_logThis('Upgrade outbound email setting', $path);
        upgradeOutboundSetting();
	}
	
	if($origVersion < '600' && !isset($_SERVER['HTTP_USER_AGENT'])) {
	   _logThis('Check to hide iFrames and Feeds modules', $path);
	   hide_iframes_and_feeds_modules();
	}	
				
	if($origVersion < '550' && ($sugar_config['dbconfig']['db_type'] == 'mssql')) {
		dropColumnConstraintForMSSQL("outbound_email", "mail_smtpssl");
		$GLOBALS['db']->query("ALTER TABLE outbound_email alter column mail_smtpssl int NULL");
		
		dropColumnConstraintForMSSQL("outbound_email", "mail_sendtype");
		$GLOBALS['db']->query("alter table outbound_email  add default 'smtp' for mail_sendtype;");
	} // if	
	
    //Upgrade multienum data if the version was less than 5.2.0k
    if ($sugar_version < '5.2.0k') {
        _logThis("Upgrading multienum data", $path);
        require_once("$unzip_dir/scripts/upgrade_multienum_data.php");
        upgrade_multienum_data();   
    }
    $post_action = status_post_install_action('sql_query');
	if($post_action != null){
	   if($post_action != 'done'){
			//continue from where left in previous run
			runSqlFiles($origVersion,$destVersion,'sql_query',$post_action);
		  	$currProg['sql_query'] = 'done';
		  	post_install_progress($currProg,'set');
		}
	 }
	 else{
		//never ran before
		runSqlFiles($origVersion,$destVersion,'sql_query');
	  	$currProg['sql_query'] = 'done';
	  	post_install_progress($currProg,'set');
	  }

	//if upgrading from 50GA we only need to do the version update.
	if ($origVersion>'500') {
		genericFunctions();		
	
		upgradeDbAndFileVersion($new_sugar_version);
	}
	
}

function upgradeOutboundSetting(){
	$query = "select count(*) as count from outbound_email where name='system' and mail_sendtype='sendmail' ";
	$result = $GLOBALS['db']->query($query);
	$row = $GLOBALS['db']->fetchByAssoc($result);
	
	if($row['count']>0) {
		require_once('modules/Configurator/Configurator.php');
		$configurator = new Configurator();
		$configurator->config['allow_sendmail_outbound'] = true;
		$configurator->handleOverride();
	}
}

function hide_subpanels_if_tabs_are_hidden(){
	global $path;	
	require_once('modules/MySettings/TabController.php');
    require_once ('include/SubPanel/SubPanelDefinitions.php') ;
        
	//grab the existing system tabs
	$newTB = new TabController();
	$tabs = $newTB->get_tabs_system();

	//set the hidden tabs key to lowercase
	$hidpanels_arr = array_change_key_case($tabs[1]);
	_logThis('panels to hide because tabs are hidden: '.var_export($hidpanels_arr,true), $path);
		
    //make subpanels hidden if tab is hidden
	SubPanelDefinitions::set_hidden_subpanels($hidpanels_arr);
	_logThis('panels were hidden ', $path);	
}

/**
 * hide_iframes_and_feeds_modules
 * This method determines whether or not to hide the iFrames and Feeds module
 * for an upgrade to 551
 */
function hide_iframes_and_feeds_modules() {
	global $path;
	
    _logThis('Beginning hide_iframes_and_feeds_modules', $path);
	$query = "SELECT id, contents, assigned_user_id FROM user_preferences WHERE deleted = 0 AND category = 'Home'";
	$result = $GLOBALS['db']->query($query, true, "Unable to update iFrames and Feeds dashlets!");
	while ($row = $GLOBALS['db']->fetchByAssoc($result)) {
		$content = unserialize(base64_decode($row['contents']));
		$assigned_user_id = $row['assigned_user_id'];
		$record_id = $row['id'];
		$current_user = new User();
        $current_user->retrieve($row['assigned_user_id']);
        
		if(!empty($content['dashlets']) && !empty($content['pages'])){
			$originalDashlets = $content['dashlets'];
			$originalPages = $content['pages'];
			
			//Determine if the original perference has already had the two dashlets or not
			foreach($originalDashlets as $key=>$ds){
				if(!empty($ds['options']['title']) && $ds['options']['title'] == 'LBL_DASHLET_DISCOVER_SUGAR_PRO'){
				   $originalDashlets[$key]['module'] = 'Home';
				}
				if(!empty($ds['options']['title']) && $ds['options']['title'] == 'LBL_DASHLET_SUGAR_NEWS'){
				   $originalDashlets[$key]['module'] = 'Home';
				}
			}
		}
		$current_user->setPreference('dashlets', $originalDashlets, 0, 'Home');
		$current_user->setPreference('pages', $originalPages, 0, 'Home');	
	} //while	
	
	$remove_iframes = false;
	$remove_feeds = false;
	
	//Check if we should remove iframes.  If the table does not exist or the directory
	//does not exist then we set remove_iframes to true
	if(!$GLOBALS['db']->tableExists('iframes') || !file_exists('modules/iFrames')) {
		$remove_iframes = true;
	} else {
		$result = $GLOBALS['db']->query('SELECT count(id) as total from iframes');
		if(!empty($result)) {
			$row = $GLOBALS['db']->fetchByAssoc($result);
			if($row['total'] == 0) {
			   $remove_iframes = true;
			}
		}
	}
	
	//Check if we should remove Feeds.  We check if the tab is hidden
	require_once("modules/MySettings/TabController.php");
	$controller = new TabController();
	$tabs = $controller->get_tabs_system();
	
	//If the feeds table does not exists or if the directory does not exist or if it is hidden in 
	//system tabs then set remove_feeds to true
	if(!$GLOBALS['db']->tableExists('feeds') || !file_exists('modules/Feeds') || (isset($tabs) && isset($tabs[1]) && isset($tabs[1]['Feeds']))) {
	   $remove_feeds = true;
	}
	
	if($remove_feeds) {
	   //Remove the modules/Feeds files
	   if(is_dir('modules/Feeds')) 
	   {
	      _logThis('Removing the Feeds files', $path);
	      rmdir_recursive('modules/Feeds');
	   }
		
	   if(file_exists('custom/Extension/application/Ext/Include/Feeds.php'))
	   {
	      _logThis('Removing custom/Extension/application/Ext/Include/Feeds.php ', $path);
	      unlink('custom/Extension/application/Ext/Include/Feeds.php');	   	
	   }
	   
	   //Drop the table
	   if($GLOBALS['db']->tableExists('feeds')) 
	   {
		   _logThis('Removing the Feeds table', $path);
		   $GLOBALS['db']->dropTableName('feeds');
	   }
	} else {
	   if(file_exists('modules/Feeds') && $GLOBALS['db']->tableExists('feeds')) {
		   _logThis('Writing Feed.php module to custom/Extension/application/Ext/Include', $path);
		   write_to_modules_ext_php('Feed', 'Feeds', 'modules/Feeds/Feed.php', true);
	   }
	}
	
	if($remove_iframes) {
		//Remove the module/iFrames files
		if(is_dir('modules/iFrames')) 
		{
		   _logThis('Removing the iFrames files', $path);
		   rmdir_recursive('modules/iFrames');
		}
		
		if(file_exists('custom/Extension/application/Ext/Include/iFrames.php'))
	    {
	       _logThis('Removing custom/Extension/application/Ext/Include/iFrames.php ', $path);
	       unlink('custom/Extension/application/Ext/Include/iFrames.php');	   	
	    }		
		
		//Drop the table
		if($GLOBALS['db']->tableExists('iframes')) 
		{
		   _logThis('Removing the iframes table', $path);
		   $GLOBALS['db']->dropTableName('iframes');
		}

	} else {
	   if(file_exists('modules/iFrames') && $GLOBALS['db']->tableExists('iframes')) {
		  _logThis('Writing iFrame.php module to custom/Extension/application/Ext/Include', $path);
		  write_to_modules_ext_php('iFrame', 'iFrames', 'modules/iFrames/iFrame.php', true);
	   }
	}	
	
	 _logThis('Finshed with hide_iframes_and_feeds_modules', $path);
}

/**
 * write_to_modules_ext_php
 * Writes the given module, class and path values to custom/Extensions/application/Include directory
 * for the module
 * @param $class String value of the class name of the module
 * @param $module String value of the name of the module entry
 * @param $path String value of the path of the module class file
 * @param $show Boolean value to determine whether or not entry should be added to moduleList or modInvisList Array
 */
function write_to_modules_ext_php($class, $module, $path, $show=false) {
	include('include/modules.php');
	global $beanList, $beanFiles;
	if(!isset($beanFiles[$class])) {
		$str = "<?php \n //WARNING: The contents of this file are auto-generated\n";

			if(!empty($module) && !empty($class) && !empty($path)){
				$str .= "\$beanList['$module'] = '$class';\n";
				$str .= "\$beanFiles['$class'] = '$path';\n";
				if($show){
					$str .= "\$moduleList[] = '$module';\n";
				}else{
					$str .= "\$modules_exempt_from_availability_check['$module'] = '$module';\n";
					$str .= "\$modInvisList[] = '$module';\n";
				}
			}

		$str.= "\n?>";
		if(!file_exists("custom/Extension/application/Ext/Include")){
			mkdir_recursive("custom/Extension/application/Ext/Include", true);
		}
		$out = sugar_fopen("custom/Extension/application/Ext/Include/{$module}.php", 'w');
		fwrite($out,$str);
		fclose($out);
		
		require_once('ModuleInstall/ModuleInstaller.php');
  		$moduleInstaller = new ModuleInstaller();
		$moduleInstaller->merge_files('Ext/Include', 'modules.ext.php', '', true);			
	}

}

?>