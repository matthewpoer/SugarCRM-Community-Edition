ALTER TABLE accounts_audit
    ADD INDEX idx_accounts_parent_id (parent_id);

ALTER TABLE bugs_audit
    ADD INDEX idx_bugs_parent_id (parent_id);


ALTER TABLE cases_audit
    ADD INDEX idx_cases_parent_id (parent_id);

ALTER TABLE contacts_audit
    ADD INDEX idx_contacts_parent_id (parent_id);


DROP TABLE dashboards;


ALTER TABLE leads_audit
    ADD INDEX idx_leads_parent_id (parent_id);

ALTER TABLE opportunities_audit
    ADD INDEX idx_opportunities_parent_id (parent_id);

ALTER TABLE outbound_email
    ALTER mail_smtpport SET DEFAULT 0;

    
ALTER TABLE users DROP user_preferences;    