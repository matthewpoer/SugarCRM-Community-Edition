<?php
if(!defined('sugarEntry'))define('sugarEntry', true);

/**
 * This script executes after the files are copied during the install.
 *
 * LICENSE: The contents of this file are subject to the SugarCRM Professional
 * End User License Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/EULA.  By installing or using this file, You have
 * unconditionally agreed to the terms and conditions of the License, and You
 * may not use this file except in compliance with the License.  Under the
 * terms of the license, You shall not, among other things: 1) sublicense,
 * resell, rent, lease, redistribute, assign or otherwise transfer Your
 * rights to the Software, and 2) use the Software for timesharing or service
 * bureau purposes such as hosting the Software for commercial gain and/or for
 * the benefit of a third party.  Use of the Software may be subject to
 * applicable fees and any use of the Software without first paying applicable
 * fees is strictly prohibited.  You do not have the right to remove SugarCRM
 * copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2005 SugarCRM, Inc.; All Rights Reserved.
 *
 * $Id$
 */

require_once('include/utils.php');
require_once('include/database/PearDatabase.php');
require_once('include/database/DBManager.php');
require_once('include/database/DBManagerFactory.php');
require_once("include/entryPoint.php");
require_once("modules/Emails/Email.php");



function get_email_addresses($addrs,$optout=0,$invalidEmail=0,$module=null) {
	$r2_arr=array(); //collection of matching email addresses.
	if (!empty($addrs)) {
		$addrs_arr = explode(';',$addrs);  //array of address in the row.
		if (count($addrs_arr)> 0) {
		    //if last element is empty unset it.
		    if (empty($addrs_arr[count($addrs_arr)-1])) {
		        unset($addrs_arr[count($addrs_arr)-1]);
		    }
			$addrs= "'".implode("','",$addrs_arr) . "'";  //comma delimited list of emailaddresses, used for query.
			$q2="select * from email_addresses where email_address in (". $addrs.  ") and deleted=0";
			$r2 = $GLOBALS['db']->query($q2, true);

			while($a2 = $GLOBALS['db']->fetchByAssoc($r2)) {
				$r2_arr[$a2['email_address']]= array(
					'id'=>$a2['id'],
					'email_address'=>$a2['email_address'],
					'opt_out'=>$a2['opt_out'],
					'invalid_email'=>$a2['invalid_email']
				);
			}
		}

		//create email_addres record if one does not exist.
		foreach ($addrs_arr as $addr) {
			if (!isset($r2_arr[$addr])) {
				$guid = create_guid();
				$caps1=strtoupper($addr);

				$qEmail1 = "INSERT INTO email_addresses (id, email_address, email_address_caps, opt_out,invalid_email)
						VALUES ('{$guid}', '{$addr}', '{$caps1}', $optout,$invalidEmail)";
				$GLOBALS['db']->query($qEmail1, true);

				$r2_arr[$addr]= array('id'=>$guid,'email_address'=>$addr,'opt_out'=>$optout,'invalid_email'=>$invalidEmail);
			}
			else{
				if((isset($r2_arr[$addr]['opt_out']) && $r2_arr[$addr]['opt_out'] != 1) && $optout==1){
					$updateOptOut = "UPDATE email_addresses set opt_out = $optout where id='{$r2_arr[$addr]['id']}'";
				    $GLOBALS['db']->query($updateOptOut, true);
				}
				if((isset($r2_arr[$addr]['invalid_email']) && $r2_arr[$addr]['invalid_email'] != 1) && $invalidEmail==1){
					$upInvalEmail = "UPDATE email_addresses set invalid_email = $invalidEmail where id='{$r2_arr[$addr]['id']}'";
				    $GLOBALS['db']->query($upInvalEmail, true);
				}
			}





		}
	}
	return $r2_arr;
}

function create_email_email_addr_rel($addrs,$rel_type,$email_id) {
    $db_addrs=get_email_addresses($addrs);
    if (!empty($db_addrs)) {
        foreach ($db_addrs as $address=>$addr_properties) {
            $relGuid = create_guid();
            $mod = 'Emails';
            $qRel= "INSERT INTO emails_email_addr_rel (id, email_id,email_address_id, address_type, deleted)
                     VALUES ('{$relGuid}', '{$email_id}', '{$addr_properties['id']}', '{$rel_type}', 0)";

            $GLOBALS['db']->query($qRel);
        }
    }
}

function update_optout_invalEmail_Beans($addr,$optout=0,$invalidEmail=0,$module=null) {
	if (!empty($addr) && !($module =='accounts' || $module == 'users')) {
		$updateOtherModules = '';
		if($module=='leads'){
			$updateOtherModules[0]='contacts';
            $updateOtherModules[1]='prospects';
		}
		if($module == 'contacts'){
			$updateOtherModules[0]='leads';
            $updateOtherModules[1]='prospects';
		}
		if($module == 'prospects'){
			$updateOtherModules[0]='leads';
            $updateOtherModules[1]='contacts';
		}
        foreach($updateOtherModules as $mod){
			$q2="update {$mod} set ";
			if($optout==1 && $invalidEmail==0){
				$q2 .="opt_out= $optout ";
			}
			if($invalidEmail==1 && $optout==0){
				$q2 .="invalid_email= $invalidEmail ";
			}
			if($invalidEmail==1 && $optout==1){
				$q2 .="opt_out= $optout,invalid_email= $invalidEmail ";
			}
			$q2 .="where (email1 =  '".$addr."' or email2= '".$addr."') and deleted=0";
			$r2 = $GLOBALS['db']->query($q2, true);
	  }
	}
}
function outbound_email_settings(){
$category = 'global';
		$query = "SELECT id,user_name FROM users WHERE deleted = 0";
	    $result1= $GLOBALS['db']->query($query, true);
		while($user = $GLOBALS['db']->fetchByAssoc($result1)) {
		        $user_pref = array();
				$result = $GLOBALS['db']->query("SELECT contents FROM user_preferences WHERE assigned_user_id='" . $user['id'] . "' AND category = '" . $category . "' AND deleted = 0", false, 'Failed to load user preferences');
				$row = $GLOBALS['db']->fetchByAssoc($result);
				if ($row) {
					//$_SESSION[$user->user_name . '_PREFERENCES'][$category] = unserialize(base64_decode($row['contents']));
					$user_pref[$category] = unserialize(base64_decode($row['contents']));
				}

		  if(isset($user_pref['global']) && $user_pref['global'] != null){
			if(isset($user_pref['global']['mail_smtpuser']) && $user_pref['global']['mail_smtpuser'] != null && isset($user_pref['global']['mail_smtppass']) && $user_pref['global']['mail_smtppass'] != null){
			   $guid = create_guid();
			   if(!isset($user_pref['global']['mail_smtpauth_req'])) $user_pref['global']['mail_smtpauth_req']=0;
			   if(!isset($user_pref['global']['mail_smtpssl'])) $user_pref['global']['mail_smtpssl'] = 0;
			   $qEmail1 = "INSERT INTO outbound_email (id,name,type,user_id,mail_sendtype,mail_smtpserver,mail_smtpport,mail_smtpuser,mail_smtppass,mail_smtpauth_req,mail_smtpssl)
			   		       VALUES('{$guid}','{$user['user_name']}','user','{$user['id']}','{$user_pref['global']['mail_sendtype']}','{$user_pref['global']['mail_smtpserver']}','{$user_pref['global']['mail_smtpport']}',
			   		       		'{$user_pref['global']['mail_smtpuser']}','{$user_pref['global']['mail_smtppass']}','{$user_pref['global']['mail_smtpauth_req']}','{$user_pref['global']['mail_smtpssl']}') ";

			   $GLOBALS['db']->query($qEmail1, true);
			}
		 }
	  }
}
function config_email_settings(){
    $category = 'mail';
	$query = "SELECT * FROM config WHERE category='" . $category . "'";
    $result= $GLOBALS['db']->query($query, true);
	$config_mail = array();
	while($row = $GLOBALS['db']->fetchByAssoc($result)){
	   $config_mail[$category][$row['name']]=$row['value'];
	}
	$category = 'notify';
	$query = "SELECT * FROM config WHERE category='" . $category . "'";
    $result1= $GLOBALS['db']->query($query, true);
	while($row = $GLOBALS['db']->fetchByAssoc($result1)){
	   $config_mail[$category][$row['name']]=$row['value'];
	}
		if(isset($config_mail['mail']['smtpuser']) && $config_mail['mail']['smtpuser'] != null && isset($config_mail['mail']['smtppass'] ) && $config_mail['mail']['smtppass'] != null){
		   $guid = create_guid();
		   if(!isset($config_mail['mail']['smtpauth_req'])) $config_mail['mail']['smtpauth_req']=0;
		   if(!isset($config_mail['mail']['smtpssl'])) $config_mail['mail']['smtpssl'] = 0;
		   if(!isset($config_mail['notify']['fromaddress'])) $config_mail['mail']['fromaddress']='do_not_reply@example.com';
		   if(!isset($config_mail['notify']['fromname'])) $config_mail['mail']['fromname'] = 'test_user';

		   $qEmail1 = "INSERT INTO outbound_email (id,name,type,user_id,mail_sendtype,mail_smtpserver,mail_smtpport,mail_smtpuser,mail_smtppass,mail_smtpauth_req,mail_smtpssl)
		   		       VALUES('{$guid}','system','system','1','{$config_mail['mail']['sendtype']}','{$config_mail['mail']['smtpserver']}','{$config_mail['mail']['smtpport']}',
		   		       		'{$config_mail['mail']['smtpuser']}','{$config_mail['mail']['smtppass']}','{$config_mail['mail']['smtpauth_req']}','{$config_mail['mail']['smtpssl']}') ";
		   $GLOBALS['db']->query($qEmail1, true);
          /*
		   $qConfig1 = "INSERT INTO config (value)
		   		       VALUES('{$config_mail['notify']['fromaddress']}') where config[category]='notify' and config[name]='fromaddress'";
		   $qConfig2 = "INSERT INTO config (value)
		   		       VALUES('{$config_mail['notify']['fromname']}') where config[category]='notify' and config[name]='fromname'";

		   $GLOBALS['db']->query($qConfig1, true);
		   $GLOBALS['db']->query($qConfig2, true);
		   */
		}
}

function inbound_email_settings(){
	$query1 = "SELECT id,is_group FROM users where id in(select group_id from inbound_email)";
    $query2= "Update inbound_email set is_personal = 1";
    $result1= $GLOBALS['db']->query($query1, true);
    $GLOBALS['db']->query($query2, true);
    while($row = $GLOBALS['db']->fetchByAssoc($result1)){
	   if($row['is_group']){
			$query3= "Update inbound_email set is_personal =0 where group_id='".$row['id']."'";
		    $GLOBALS['db']->query($query3, true);
	   }
	}
}

function upgrade_email5(){
	$email = new Email();
	$illegal_chars=array('"',"'","\\");
	$replace_with =array("","","");

	$qText = "
	INSERT INTO emails_text (email_id, from_addr, to_addrs, cc_addrs, bcc_addrs, description, description_html, raw_source, deleted)
	SELECT
		id,
		from_addr,
		to_addrs,
		cc_addrs,
		bcc_addrs,
		description,
		description_html,
		raw_source,
		deleted
	FROM emails";
	$email->db->query($qText, true);



	// email addresses
	$modules = array(
		'accounts',
		'contacts', // opt_out
		'leads', // opt_out
		'prospects', // opt_out
		'users',
	);

	foreach($modules as $module) {
		if($module == 'accounts' || $module == 'users') {
			$q = "SELECT id, email1, email2 FROM {$module}";
		} else {
			$q = "SELECT id, email1, email2, email_opt_out, invalid_email FROM {$module}";
		}
		$r = $email->db->query($q, true);

		while($a = $email->db->fetchByAssoc($r)) {
			$optOut=1;
			$invalidEmail=1;
			if(!isset($a['invalid_email']) or empty($a['invalid_email'])) {
				$invalidEmail = 0;
			} else {
				$invalid_Email=strtoupper($a['invalid_email']);
				if ($invalid_Email=='FALSE' or $invalid_Email=='NO' or $invalid_Email=='OFF' or $invalid_Email=='0') {
					$invalidEmail = 0;
				}
			}

			if(!isset($a['email_opt_out']) or empty($a['email_opt_out'])) {
				$optOut = 0;
			} else {
				$opt_out_value=strtoupper($a['email_opt_out']);
				if ($opt_out_value=='FALSE' or $opt_out_value=='NO' or $opt_out_value=='OFF' or $opt_out_value=='0') {
					$optOut = 0;
				}
			}
			$addrs=null;
			if (!empty($a['email1'])) {
				$addrs=str_replace(illegal_chars,$replace_with,$a['email1']);
			}
			if (!empty($a['email2'])) {
				if (empty($addrs)) {
					$addrs=str_replace($illegal_chars,$replace_with,$a['email2']);
				} else {
					$addrs.=';'.str_replace($illegal_chars,$replace_with,$a['email2']);
				}
			}

			if (!empty($addrs)) {
				$addrs_objs=get_email_addresses($addrs,$optOut,$invalidEmail,$module);
				foreach  ($addrs_objs as $email_address_key=>$email_address_object) {
					$primary=0;
					if ($email_address_key == $a['email1']) {
						$primary=1;
					}
					$relGuid = create_guid();
					$mod = ucfirst($module);
					$qRel = "INSERT INTO email_addr_bean_rel (id, email_address_id, bean_id, bean_module, primary_address)
								VALUES ('{$relGuid}', '{$email_address_object['id']}', '{$a['id']}', '{$mod}', $primary)";
					$email->db->query($qRel, true);
				}
			}
		}

	}


	//upgrade emails data
	$q = "SELECT id,from_addr, to_addrs,  cc_addrs, bcc_addrs FROM emails";
	$r = $email->db->query($q, true);
	while($a = $email->db->fetchByAssoc($r)) {
		$addrs=trim($a['from_addr']);
		if (!empty($addrs)) {
			$nm_addr=explode(" ",$addrs);
			if (count($nm_addr)==1) {
				$addrs=$nm_addr[0];
			}else {
			    $addrs=$nm_addr[1];
			}
			$addrs=str_replace("&lt;","",$addrs);
			$addrs=str_replace("&gt;","",$addrs);
		}
		create_email_email_addr_rel($addrs,'from',$a['id']);

		$addrs=trim($a['to_addrs']);
		create_email_email_addr_rel($addrs,'to',$a['id']);

		$addrs=trim($a['cc_addrs']);
		create_email_email_addr_rel($addrs,'cc',$a['id']);

		$addrs=trim($a['bcc_addrs']);
		create_email_email_addr_rel($addrs,'bcc',$a['id']);
	}

	// old rel tables to new rel tables
	$old_rels = array(
		'Accounts' => array(
			'fk' => 'account_id',
			'table' => 'emails_accounts'
		),
		'Bugs' => array(
			'fk' => 'bug_id',
			'table' => 'emails_bugs'
		),
		'Cases' => array(
			'fk' => 'case_id',
			'table' => 'emails_cases'
		),
		'Contacts' => array(
			'fk' => 'contact_id',
			'table' => 'emails_contacts'
		),
		'Leads' => array(
			'fk' => 'lead_id',
			'table' => 'emails_leads'
		),
		'Opportunities' => array(
			'fk' => 'opportunity_id',
			'table' => 'emails_opportunities'
		),
		'ProjectTask' => array(
			'fk' => 'project_task_id',
			'table' => 'emails_project_tasks'
		),
		'Project' => array(
			'fk' => 'project_id',
			'table' => 'emails_projects'
		),
		'Prospects' => array(
			'fk' => 'prospect_id',
			'table' => 'emails_prospects'
		),







		'Tasks' => array(
			'fk' => 'task_id',
			'table' => 'emails_tasks'
		),
		'Users' => array(
			'fk' => 'user_id',
			'table' => 'emails_users'
		),
	);
    $modulesHaveCampaignData = array('Contacts','Leads','Prospects','Users');
   	foreach($old_rels as $module => $stuff) {
   		if(in_array($module,$modulesHaveCampaignData)){
   			$q = "INSERT INTO emails_beans SELECT id, email_id, {$stuff['fk']}, '{$module}', campaign_data,date_modified, deleted FROM {$stuff['table']}";
   			$r = $email->db->query($q, true);
   		} else {
   			$q = "SELECT id, email_id, {$stuff['fk']}, '{$module}',date_modified, deleted FROM {$stuff['table']}";
   			$r = $email->db->query($q, true);
   			$campaign_data = null;
   			while($a = $email->db->fetchByAssoc($r)) {
   				$qM = "INSERT INTO emails_beans(id, email_id, bean_id, bean_module,campaign_data,date_modified,deleted)
   					  VALUES ('{$a['id']}', '{$a['email_id']}', '{$a[$stuff['fk']]}', '{$module}','{$campaign_data}','{$a['date_modified']}','{$a['deleted']}')";
   				$rM = $email->db->query($qM, true);
   			}
   		}
   	}


   /*
	$q="ALTER TABLE emails DROP COLUMN date_start,DROP COLUMN time_start,DROP COLUMN description,DROP COLUMN description_html,DROP COLUMN from_addr,DROP COLUMN from_name,DROP COLUMN to_addrs,DROP COLUMN to_addrs_ids,DROP COLUMN to_addrs_names,DROP COLUMN to_addrs_emails,DROP COLUMN cc_addrs,DROP COLUMN cc_addrs_ids,
	DROP COLUMN cc_addrs_names,DROP COLUMN cc_addrs_emails,DROP COLUMN bcc_addrs,DROP COLUMN bcc_addrs_ids,DROP COLUMN bcc_addrs_names,DROP COLUMN bcc_addrs_emails,DROP COLUMN raw_source";
	$email->db->query($q,true);
	*/
  //outbound email settings
  outbound_email_settings();
  config_email_settings();
  inbound_email_settings();
  encrypt_outbound_email_password();
}

function encrypt_outbound_email_password() {
	require_once('include/utils/encryption_utils.php');
	$fixPasswordQuery = "SELECT id, mail_smtppass FROM outbound_email";
	$result2= $GLOBALS['db']->query($fixPasswordQuery, true);
	while($a = $GLOBALS['db']->fetchByAssoc($result2)) {
		$outboundId = $a['id'];
		$outboundPassword = $a['mail_smtppass'];
		if (!empty($outboundPassword)) {
			$outboundPassword = blowfishEncode(blowfishGetKey('OutBoundEmail'), $outboundPassword);
			$GLOBALS['db']->query("update outbound_email set mail_smtppass = '{$outboundPassword}' where id = '$outboundId'", true);
		} // if
	} // while
} // fn

function upgrade_fields_meta(){
 $email = new Email();
 $query = "SELECT * FROM fields_meta_data";
 $result = $email->db->query($query);
 while ($row = $email->db->fetchByAssoc($result)) {
		$update_query = "UPDATE fields_meta_data SET ";
		$update_query .= "vname = '{$row['label']}' ";
		$update_query .= ", type = '{$row['data_type']}' ";
		$len = 50;
		if(!empty($row['max_size']))
			$len = $row['max_size'];
		$update_query .= ", len = {$len} ";
		$required = 0;
		if($row['required_option'] == 'required')
			$required = 1;
		$update_query .= ", required = {$required} ";
		if($row['default_value'] == '-none-')
            $update_query .= ", default_value = ''";
		$update_query .= ", massupdate = {$row['mass_update']}";
		$update_query .= " WHERE id = '{$row['id']}'";
		$email->db->query($update_query);
 }
 //Also update the reportable and set it to true.
 $update_reportable = "UPDATE fields_meta_data SET reportable=1";
 $email->db->query($update_reportable);

 /*drop some columns.
	 $que  = "ALTER TABLE fields_meta_data DROP COLUMN label,";
	 $que .= "DROP COLUMN help,";
	 $que .= "DROP COLUMN data_type,";
	 $que .= "DROP COLUMN required_option,";
	 $email->db->query($que);
 */
}
?>