<?php
if(!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');

}
/**
 * This script executes after the files are copied during the install.
 *
 * LICENSE: The contents of this file are subject to the SugarCRM Professional
 * End User License Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/EULA.  By installing or using this file, You have
 * unconditionally agreed to the terms and conditions of the License, and You
 * may not use this file except in compliance with the License.  Under the
 * terms of the license, You shall not, among other things: 1) sublicense,
 * resell, rent, lease, redistribute, assign or otherwise transfer Your
 * rights to the Software, and 2) use the Software for timesharing or service
 * bureau purposes such as hosting the Software for commercial gain and/or for
 * the benefit of a third party.  Use of the Software may be subject to
 * applicable fees and any use of the Software without first paying applicable
 * fees is strictly prohibited.  You do not have the right to remove SugarCRM
 * copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2005 SugarCRM, Inc.; All Rights Reserved.
 */


require_once(clean_path($unzip_dir.'/scripts/upgrade_utils.php'));






























function rebuild_dashlets(){
    if(is_file('cache/dashlets/dashlets.php')) {
        unlink('cache/dashlets/dashlets.php');
    }
    require_once('include/Dashlets/DashletCacheBuilder.php');

    $dc = new DashletCacheBuilder();
    $dc->buildCache();
}
function rebuild_teams(){

    require_once('modules/Administration/RepairTeams.php');

    process_team_access(false, false,true,'1');
}

function rebuild_roles(){
  $_REQUEST['upgradeWizard'] = true;
  include("modules/ACL/install_actions.php");
}

function runSqlFiles($origVersion,$destVersion,$queryType,$resumeFromQuery=''){
	global $sugar_config;
	global $unzip_dir;
	global $sugar_config;
	global $sugar_version;
	global $path;
	global $_SESSION;
	$self_dir = "$unzip_dir/scripts";

	// This flag is determined by the preflight check in the installer
	if(!isset($_SESSION['schema_change']) || /* pre-4.5.0 upgrade wizard */
		$_SESSION['schema_change'] == 'sugar') {
		_logThis("Upgrading the database from {$origVersion} to version {$destVersion}", $path);
		$schemaFileName = $origVersion."_to_".$destVersion;

		if($sugar_config['dbconfig']['db_type'] == 'oci8') {















		} elseif($sugar_config['dbconfig']['db_type'] == 'mssql') {
			//BEFORE RUNNING 451_to_500 sql script drop the constraints on the columns
			_logThis('Droping constraints on some columns ', $path);
				if($origVersion < '500'){
					require_once("$unzip_dir/scripts/upgrade_sqlsvr5.php");
					ob_start();
					@upgrade5_sqlsvr();
					ob_end_clean();
					}
			//$schemaFile = "$unzip_dir/scripts/$schemaFileName"."_mssql.sql";
			$schemaFile = $_SESSION['unzip_dir'].'/scripts/'.$origVersion.'_to_'.$destVersion.'_mssql.sql';
			_logThis("Running SQL file $schemaFile", $path);
			if(is_file($schemaFile)) {
				//$sql_run_result = _run_sql_file($schemaFile);
				ob_start();
				@parseAndExecuteSqlFile($schemaFile,$queryType,$resumeFromQuery);
				ob_end_clean();
			} else {
				logThis("*** ERROR: Schema change script [{$schemaFile}] could not be found!", $path);
			}
		}
		else {
			//$schemaFile = "$unzip_dir/scripts/$schemaFileName"."_mysql.sql";
			$schemaFile = $_SESSION['unzip_dir'].'/scripts/'.$origVersion.'_to_'.$destVersion.'_mysql.sql';
			_logThis("Running SQL file $schemaFile", $path);
			if(is_file($schemaFile)) {
				//$sql_run_result = _run_sql_file($schemaFile);
				ob_start();
				@parseAndExecuteSqlFile($schemaFile,$queryType,$resumeFromQuery);
				ob_end_clean();
			} else {
				logThis("*** ERROR: Schema change script [{$schemaFile}] could not be found!", $path);
			}
		}
	} else {
		_logThis('*** Skipping Schema Change Scripts - Admin opted to run queries manually and should have done so by now.', $path);
	}
}

function genericFunctions(){
	///////////////////////////////////////////////////////////////////////////
	////	FILESYSTEM SECURITY FIX (Bug 9365)
	_logThis("Applying .htaccess update security fix.", $path);
	include_once("modules/Administration/UpgradeAccess.php");

	///////////////////////////////////////////////////////////////////////////
	////	PRO/ENT ONLY FINAL TOUCHES








		///////////////////////////////////////////////////////////////////////////
	////	REBUILD JS LANG
	_logThis("Rebuilding JS Langauages", $path);
	rebuild_js_lang();

	///////////////////////////////////////////////////////////////////////////
	////	REBUILD DASHLETS
	_logThis("Rebuilding Dashlets", $path);
	rebuild_dashlets();








    //Rebuild roles
     _logThis("Rebuilding Roles", $path);
     ob_start();
     rebuild_roles();
     ob_end_clean();
}

function status_post_install_action($action){
	$currProg = post_install_progress();
	$currPostInstallStep = '';
	$postInstallQuery = '';
	if(is_array($currProg) && $currProg != null){
		foreach($currProg as $key=>$val){
			if($key==$action){
				return $val;
			}
		}
	}
	return '';
}

function post_install() {
	global $unzip_dir;
	global $sugar_config;
	global $sugar_version;
	global $path;
	global $_SESSION;
	initialize_session_vars();
	_logThis('Entered post_install function.', $path);
	$self_dir = "$unzip_dir/scripts";

	///////////////////////////////////////////////////////////////////////////
	////	PUT DATABASE UPGRADE SCRIPT HANDLING HERE
	$new_sugar_version = getUpgradeVersion();
	$origVersion = substr(preg_replace("/[^0-9]/", "", $sugar_version),0,3);
	$destVersion = substr(preg_replace("/[^0-9]/", "", $new_sugar_version),0,3);

	// The outbound_email password was was not encrypted so this code will encrpt the password
	if ($sugar_version >= '5.0.0' && $sugar_version < '5.0.0b') {
	  require_once('include/utils/encryption_utils.php');
	  $fixPasswordQuery = "SELECT id, mail_smtppass FROM outbound_email";
	  $result2= $GLOBALS['db']->query($fixPasswordQuery, true);
	  while($a = $GLOBALS['db']->fetchByAssoc($result2)) {
	  	$outboundId = $a['id'];
	  	$outboundPassword = $a['mail_smtppass'];
	  	if (!empty($outboundPassword)) {
	  		$outboundPassword = blowfishEncode(blowfishGetKey('OutBoundEmail'), $outboundPassword);
	  		$GLOBALS['db']->query("update outbound_email set mail_smtppass = '{$outboundPassword}' where id = '$outboundId'", true);
	  	} // if
	  } // while

	} // if
    $post_action = status_post_install_action('sql_query');
	if($post_action != null){
	   if($post_action != 'done'){
			//continue from where left in previous run
			runSqlFiles($origVersion,$destVersion,'sql_query',$post_action);
		  	$currProg['sql_query'] = 'done';
		  	post_install_progress($currProg,'set');
		}
	 }
	 else{
		//never ran before
		runSqlFiles($origVersion,$destVersion,'sql_query');
	  	$currProg['sql_query'] = 'done';
	  	post_install_progress($currProg,'set');
	  }


	//if upgrading from 50GA we only need to do the version update.
	if ($origVersion=='500' || $origVersion>'500') {
		genericFunctions();
		upgradeDbAndFileVersion($new_sugar_version);
		return;
	}
   //following is all pre 500 stuff will be used for upgrades from 451
   //Upgrade to 500 KB and Advanced Projects
     require_once("$unzip_dir/scripts/upgrade_kb_advanced_project5.php");
    _logThis('Start creating advanced projects', $path);
    $post_action = status_post_install_action('project_query');
    if($post_action != null){
	   if($post_action != 'done'){
			//continue from where left in previous run
			project_sqls($post_action);
		  	$currProg['project_query'] = 'done';
		  	post_install_progress($currProg,'set');
		}
	 }
	 else{
		//never ran before
		project_sqls();
	  	$currProg['project_query'] = 'done';
	  	post_install_progress($currProg,'set');
	  }
	_logThis('Done creating advanced projects', $path);

	_logThis('Start creating  Knowledge Base', $path);
	$post_action = status_post_install_action('kb_query');
     if($post_action != null){
	   if($post_action != 'done'){
			//continue from where left in previous run
			kb_sqls($post_action);
		  	$currProg['kb_query'] = 'done';
		  	post_install_progress($currProg,'set');
		}
	 }
	 else{
		//never ran before
		kb_sqls();
	  	$currProg['kb_query'] = 'done';
	  	post_install_progress($currProg,'set');
	  }
     _logThis('Done creating Knowledge Base ', $path);


    //Upgrade to 500 Email
    require_once("$unzip_dir/scripts/upgrade_email5.php");
	_logThis('Start Upgrading Email to 50', $path);
	$post_action = status_post_install_action('upgrade_email5');
   	if($post_action == null || $post_action != 'done'){
		//continue from where left in previous run
		upgrade_email5();
		$currProg['upgrade_email5'] = 'done';
	  	post_install_progress($currProg,'set');
	}
	_logThis('End Upgrading Email to 50', $path);

    //Upgrade to 500 Portal
    require_once("$unzip_dir/scripts/upgrade_portal5.php");
	_logThis('Start Upgrading Portal to 50', $path);
	$post_action = status_post_install_action('upgrade_portal5');
   	if($post_action == null || $post_action != 'done'){
		//continue from where left in previous run
		@upgrade_portal5();
		$currProg['upgrade_portal5'] = 'done';
	  	post_install_progress($currProg,'set');
	}
	_logThis('End Upgrading Portal to 50', $path);


	//Upgrade to 500 fields meta data
	_logThis('Start Upgrading Fields Meta Data to 50', $path);
	$post_action = status_post_install_action('upgrade_fields_meta');
   	if($post_action == null || $post_action != 'done'){
		//continue from where left in previous run
		upgrade_fields_meta();
		$currProg['upgrade_fields_meta'] = 'done';
	  	post_install_progress($currProg,'set');
	}
	_logThis('End Upgrading Fields Meta Data to 50', $path);

	////	END SCHEMA CHANGE UPGRADE SCRIPTS
	///////////////////////////////////////////////////////////////////////////
    /////START GENERIC FUNCTIONS IRRESPECTIVE OF VERSIONS
    	genericFunctions();
    ///COMPLETE GENERIC FUNCTIONS IRRESPECTIVE OF VERSIONS















	///////////////////////////////////////////////////////////////////////////
	////	FINALIZE VERSION UPDATES
	upgradeDbAndFileVersion($new_sugar_version);

}
?>