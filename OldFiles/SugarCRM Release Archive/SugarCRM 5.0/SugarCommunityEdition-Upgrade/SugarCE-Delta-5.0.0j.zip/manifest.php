<?php
// created: 2009-03-03 15:05:33
$manifest = array (
  'acceptable_sugar_flavors' => 
  array (
    0 => 'CE',
    1 => 'OS',
  ),
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '5\\.0\\.0[i|j]',
    ),
  ),
  'author' => 'SugarCRM, Inc.',
  'copy_files' => 
  array (
    'from_dir' => 'SugarCE-Delta-5.0.0j',
    'to_dir' => '',
    'force_copy' => 
    array (
    ),
  ),
  'description' => '',
  'icon' => '',
  'is_uninstallable' => false,
  'offline_client_applicable' => true,
  'name' => 'SugarCE',
  'published_date' => '2009-03-03 15:05:33',
  'type' => 'patch',
  'version' => '5.0.0j',
);
?>
