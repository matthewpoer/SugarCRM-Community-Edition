-- MSSQL upgrade script for Sugar 5.2.0 to 5.5.1

 ALTER TABLE leads ADD birthdate datetime  NULL;














 ALTER TABLE users ADD system_generated_password bit  DEFAULT '0' NOT NULL ,
                       pwd_last_changed datetime  NULL ,



                       external_auth_only bit  DEFAULT '0' NULL;

















































































DROP INDEX sgrfeed_date on sugarfeed;
create index sgrfeed_date on sugarfeed ( date_entered, deleted );














CREATE TABLE users_password_link (
                id varchar(36)  NOT NULL ,
                username varchar(36)  NULL ,
                date_generated datetime  NULL ,
                deleted bit  DEFAULT 0  NOT NULL  ) 
ALTER TABLE users_password_link ADD CONSTRAINT pk_users_password_link PRIMARY KEY (id) 
create index idx_username on users_password_link ( username );










































create index idx_calls_par_del  on calls (parent_id, parent_type, deleted );

create index idx_mail_to  on email_cache (toaddr );

alter table outbound_email alter column type varchar(15);

alter table inbound_email_autoreply add ie_id varchar(36);




