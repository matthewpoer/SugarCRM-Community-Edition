<?php
if(!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');

}
/**
 * This script executes after the files are copied during the install.
 *
 * LICENSE: The contents of this file are subject to the SugarCRM Professional
 * End User License Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/EULA.  By installing or using this file, You have
 * unconditionally agreed to the terms and conditions of the License, and You
 * may not use this file except in compliance with the License.  Under the
 * terms of the license, You shall not, among other things: 1) sublicense,
 * resell, rent, lease, redistribute, assign or otherwise transfer Your
 * rights to the Software, and 2) use the Software for timesharing or service
 * bureau purposes such as hosting the Software for commercial gain and/or for
 * the benefit of a third party.  Use of the Software may be subject to
 * applicable fees and any use of the Software without first paying applicable
 * fees is strictly prohibited.  You do not have the right to remove SugarCRM
 * copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2005 SugarCRM, Inc.; All Rights Reserved.
 */

require_once(clean_path($unzip_dir.'/scripts/upgrade_utils.php'));
































function add_EZ_PDF() {
	$cust_file =  "<?php\n";
	$cust_file .= '$sugarpdf_default["PDF_CLASS"] = "EZPDF";'."\n";
	$cust_file .= '$sugarpdf_default["PDF_ENABLE_EZPDF"] = "1";'."\n";
	$cust_file .= "?>\n";
	$file = 'custom/include/Sugarpdf/sugarpdf_default.php';
	if(!file_exists('custom/include/Sugarpdf')) {
		mkdir_recursive('custom/include/Sugarpdf'); // make sure the directory exists
	}
	
	file_put_contents($file,$cust_file);	
}


function rebuild_dashlets(){
    if(is_file('cache/dashlets/dashlets.php')) {
        unlink('cache/dashlets/dashlets.php');
    }
    
    global $sugar_version;
    if($sugar_version < '5.5.0') {
        require_once('include/SugarTheme/SugarTheme.php');
    }
    
    require_once('include/Dashlets/DashletCacheBuilder.php');

    $dc = new DashletCacheBuilder();
    $dc->buildCache();
}












function rebuild_roles(){
  $_REQUEST['upgradeWizard'] = true;
  require_once("data/SugarBean.php");
  global $ACLActions, $beanList, $beanFiles;
  include('modules/ACLActions/actiondefs.php');
  include('include/modules.php'); 
  global $sugar_version;
  if($sugar_version < '5.5.0') {
  	require_once('include/ListView/ListView.php');
  }
  include("modules/ACL/install_actions.php");
}

function upgrade_LDAP(){
	require_once('modules/Administration/Administration.php');
	$focus = new Administration();
	$focus->retrieveSettings('ldap', true);
	if(isset($focus->settings['ldap_admin_user']) && !empty($focus->settings['ldap_admin_user']))
	{
		$focus->saveSetting('ldap', 'authentication', '1');
	}else if(isset($focus->settings['ldap_admin_user'])) {
		$focus->saveSetting('ldap', 'authentication', '0');
	}
}










function runSqlFiles($origVersion,$destVersion,$queryType,$resumeFromQuery=''){
	global $sugar_config;
	global $unzip_dir;
	global $sugar_config;
	global $sugar_version;
	global $path;
	global $_SESSION;
	$self_dir = "$unzip_dir/scripts";

	// This flag is determined by the preflight check in the installer
	if(!isset($_SESSION['schema_change']) || /* pre-4.5.0 upgrade wizard */
		$_SESSION['schema_change'] == 'sugar') {
		_logThis("Upgrading the database from {$origVersion} to version {$destVersion}", $path);
		$schemaFileName = $origVersion."_to_".$destVersion;

		if($sugar_config['dbconfig']['db_type'] == 'oci8') {















		} elseif($sugar_config['dbconfig']['db_type'] == 'mssql') {
			//$schemaFile = "$unzip_dir/scripts/$schemaFileName"."_mssql.sql";
			$schemaFile = $_SESSION['unzip_dir'].'/scripts/'.$origVersion.'_to_'.$destVersion.'_mssql.sql';
			_logThis("Running SQL file $schemaFile", $path);
			if(is_file($schemaFile)) {
				//$sql_run_result = _run_sql_file($schemaFile);
				ob_start();
				@parseAndExecuteSqlFile($schemaFile,$queryType,$resumeFromQuery);
				ob_end_clean();
			} else {
				logThis("*** ERROR: Schema change script [{$schemaFile}] could not be found!", $path);
			}
		}
		else {
			//$schemaFile = "$unzip_dir/scripts/$schemaFileName"."_mysql.sql";
			$schemaFile = $_SESSION['unzip_dir'].'/scripts/'.$origVersion.'_to_'.$destVersion.'_mysql.sql';
			_logThis("Running SQL file $schemaFile", $path);
			if(is_file($schemaFile)) {
				//$sql_run_result = _run_sql_file($schemaFile);
				ob_start();
				@parseAndExecuteSqlFile($schemaFile,$queryType,$resumeFromQuery);
				ob_end_clean();
			} else {
				logThis("*** ERROR: Schema change script [{$schemaFile}] could not be found!", $path);
			}
		}
	} else {
		_logThis('*** Skipping Schema Change Scripts - Admin opted to run queries manually and should have done so by now.', $path);
	}
}

function clearSugarImages(){
    $skipFiles = array('ACLRoles.gif','close.gif','delete.gif','delete_inline.gif','plus_inline.gif','sugar-yui-sprites-green.png',
             'sugar-yui-sprites-purple.png','sugar-yui-sprites-red.png','sugar-yui-sprites.png','themePreview.png');
    $themePath = clean_path(getcwd() . '/themes/Sugar/images');    
    $allFiles = array();    
    $allFiles = findSugarImages($themePath, $allFiles, $skipFiles);

    foreach( $allFiles as $the_file ){
        if( is_file( $the_file ) ){
            unlink( $the_file );
            _logThis("Deleted file: $the_file", $path);
        }
    }    
}

function findSugarImages($the_dir, $the_array, $skipFiles){
    if(!is_dir($the_dir)) {
        return $the_array;
    }
    $skipFiles = array_flip($skipFiles);
    $d = dir($the_dir);
    while (false !== ($f = $d->read())) {
        if($f == "." || $f == ".." ){
            continue;
        }
        if( is_file( "$the_dir/$f" ) && !isset($skipFiles[$f]) ){
            array_push( $the_array, "$the_dir/$f" );
        }
    }
    return( $the_array );
}

function findCompanyLogo($the_dir, $the_array){
    if(!is_dir($the_dir)) {
        return $the_array;
    }
    $d = dir($the_dir);
    while (false !== ($f = $d->read())) {
        if($f == "." || $f == ".." || $f == 'default'){
            continue;
        }
        if( is_file( "$the_dir/$f/images/company_logo.png" ) ){
            array_push( $the_array, "$the_dir/$f/images/company_logo.png" );
        }
    }
    return( $the_array );
}

function clearCompanyLogo(){
    $themePath = clean_path(getcwd() . '/themes');    
    $allFiles = array();    
    $allFiles = findCompanyLogo($themePath,$allFiles);

    foreach( $allFiles as $the_file ){
        if( is_file( $the_file ) ){
            unlink( $the_file );
            _logThis("Deleted file: $the_file", $path);
        }
    }    
}

function genericFunctions(){	
	$server_software = $_SERVER["SERVER_SOFTWARE"];
	if(strpos($server_software,'Microsoft-IIS') !== false)
	{
		if($sugar_version < '5.5.0'){
		    _logThis("Rebuild web.config.", $path);
		    include_once("modules/Administration/UpgradeIISAccess.php");
		}
	} else {
		///////////////////////////////////////////////////////////////////////////
        ////    FILESYSTEM SECURITY FIX (Bug 9365)
	    _logThis("Applying .htaccess update security fix.", $path);
        include_once("modules/Administration/UpgradeAccess.php");
	}

	///////////////////////////////////////////////////////////////////////////
	////	PRO/ENT ONLY FINAL TOUCHES








		///////////////////////////////////////////////////////////////////////////
	////	REBUILD JS LANG
	_logThis("Rebuilding JS Langauages", $path);
	rebuild_js_lang();

	///////////////////////////////////////////////////////////////////////////
	////	REBUILD DASHLETS
	_logThis("Rebuilding Dashlets", $path);
	rebuild_dashlets();









  	global $sugar_version;
    if($sugar_version < '5.5.0') {
        _logThis("Begin Upgrade LDAP authentication", $path);
        upgrade_LDAP();
        _logThis("End Upgrade LDAP authentication", $path);
        
        _logThis("BEGIN CLEAR COMPANY LOGO", $path);
        clearCompanyLogo();
        _logThis("END CLEAR COMPANY LOGO", $path);
        
        _logThis("BEGIN CLEAR IMAGES IN THEME SUGAR", $path);
        clearSugarImages();
        _logThis("END CLEAR IMAGES IN THEME SUGAR", $path);
    } 
    
	if($sugar_version < '5.5.1') {
    	_logThis("Begin Clear all English inline help files", $path);
    	clearHelpFiles();
    	_logThis("End all English inline help files", $path);
    }
    //Rebuild roles
     _logThis("Rebuilding Roles", $path);
	 add_EZ_PDF();     

     ob_start();
     rebuild_roles();
     ob_end_clean();
}

function status_post_install_action($action){
	$currProg = post_install_progress();
	$currPostInstallStep = '';
	$postInstallQuery = '';
	if(is_array($currProg) && $currProg != null){
		foreach($currProg as $key=>$val){
			if($key==$action){
				return $val;
			}
		}
	}
	return '';
}

function post_install() {
	global $unzip_dir;
	global $sugar_config;
	global $sugar_version;
	global $path;
	global $_SESSION;
	if(!isset($_SESSION['sqlSkippedQueries'])){
	 	$_SESSION['sqlSkippedQueries'] = array();
	 }
	initialize_session_vars();
	if(!isset($unzip_dir) || $unzip_dir == null){
		$unzip_dir = $_SESSION['unzip_dir'];
	}
	_logThis('Entered post_install function.', $path);
	$self_dir = "$unzip_dir/scripts";

	///////////////////////////////////////////////////////////////////////////
	////	PUT DATABASE UPGRADE SCRIPT HANDLING HERE
	$new_sugar_version = getUpgradeVersion();
	$origVersion = substr(preg_replace("/[^0-9]/", "", $sugar_version),0,3);
	$destVersion = substr(preg_replace("/[^0-9]/", "", $new_sugar_version),0,3);

	if($origVersion < '550') {
        require('include/utils/autoloader.php');
        spl_autoload_register(array('SugarAutoLoader', 'autoload'));
        hide_subpanels_if_tabs_are_hidden();
	}    
	
	if($origVersion < '550' && ($sugar_config['dbconfig']['db_type'] == 'mssql')) {
		dropColumnConstraintForMSSQL("outbound_email", "mail_smtpssl");
		$GLOBALS['db']->query("ALTER TABLE outbound_email alter column mail_smtpssl int NULL");
	} // if	
	
	// The outbound_email password was was not encrypted so this code will encrpt the password
	if ($sugar_version >= '5.0.0' && $sugar_version < '5.0.0b') {
	  require_once('include/utils/encryption_utils.php');
	  $fixPasswordQuery = "SELECT id, mail_smtppass FROM outbound_email";
	  $result2= $GLOBALS['db']->query($fixPasswordQuery);
	  if($GLOBALS['db']->checkError()){
	  	//put in the array to use later on
	  	$_SESSION['sqlSkippedQueries'][] = $fixPasswordQuery;
      }
	  while($a = $GLOBALS['db']->fetchByAssoc($result2)) {
	  	$outboundId = $a['id'];
	  	$outboundPassword = $a['mail_smtppass'];
	  	if (!empty($outboundPassword)) {
	  		$outboundPassword = blowfishEncode(blowfishGetKey('OutBoundEmail'), $outboundPassword);
	  		$outboundPasswordQuery = "update outbound_email set mail_smtppass = '{$outboundPassword}' where id = '$outboundId'";
	  		$GLOBALS['db']->query();
	  		if($GLOBALS['db']->checkError()){
	  			//put in the array to use later on
	  			$_SESSION['sqlSkippedQueries'][] = $outboundPasswordQuery;
      		}
	  	} // if
	  } // while

	} // if
	
    //Upgrade multienum data if the version was less than 5.2.0k
    if ($sugar_version < '5.2.0k') {
        _logThis("Upgrading multienum data", $path);
        require_once("$unzip_dir/scripts/upgrade_multienum_data.php");
        upgrade_multienum_data();   
    }
    $post_action = status_post_install_action('sql_query');
	if($post_action != null){
	   if($post_action != 'done'){
			//continue from where left in previous run
			runSqlFiles($origVersion,$destVersion,'sql_query',$post_action);
		  	$currProg['sql_query'] = 'done';
		  	post_install_progress($currProg,'set');
		}
	 }
	 else{
		//never ran before
		runSqlFiles($origVersion,$destVersion,'sql_query');
	  	$currProg['sql_query'] = 'done';
	  	post_install_progress($currProg,'set');
	  }

	//if upgrading from 50GA we only need to do the version update.
	if ($origVersion=='500' || $origVersion>'500') {
		genericFunctions();
				
		_logThis("Add 'Go To Pro' and 'Sugar News' iframes into HOME page", $path);
	    require_once("$unzip_dir/scripts/addIFramesForHomePage.php");
	    $post_action = status_post_install_action('addIFramesForHomePage');
		if($post_action == null || $post_action != 'done'){
			//continue from where left in previous run
			add_new_iframe_dashlets();
			$currProg['addIFramesForHomePage'] = 'done';
			post_install_progress($currProg,'set');
		}
		





		upgradeDbAndFileVersion($new_sugar_version);
		return;
	}
}

function hide_subpanels_if_tabs_are_hidden(){
	global $path;	
	require_once('modules/MySettings/TabController.php');
    require_once ('include/SubPanel/SubPanelDefinitions.php') ;
        
	//grab the existing system tabs
	$newTB = new TabController();
	$tabs = $newTB->get_tabs_system();

	//set the hidden tabs key to lowercase
	$hidpanels_arr = array_change_key_case($tabs[1]);
	_logThis('panels to hide because tabs are hidden: '.var_export($hidpanels_arr,true), $path);
		
    //make subpanels hidden if tab is hidden
	SubPanelDefinitions::set_hidden_subpanels($hidpanels_arr);
	_logThis('panels were hidden ', $path);	
}
?>
