-- Oracle upgrade script for Sugar 5.1.0 to 5.5.0a















ALTER TABLE USERS ADD (
                    system_generated_password number(1)  DEFAULT 0 NOT NULL,
                    pwd_last_changed date  NULL,



                    external_auth_only number(1)  DEFAULT '0' NULL);
                    
ALTER TABLE outbound_email modify mail_smtpssl number;





































































































CREATE TABLE sugarfeed (
				id varchar2(36)  NOT NULL ,
				name varchar2(255)  NULL ,
				date_entered date  NULL ,
				date_modified date  NULL ,
				modified_user_id varchar2(36)  NULL ,
				created_by varchar2(36)  NULL ,
				description varchar2(255)  NULL ,
				deleted number(1)  DEFAULT '0' NULL ,




				assigned_user_id varchar2(36)  NULL ,
				related_module varchar2(100)  NULL ,
				related_id varchar2(36)  NULL ,
				link_url varchar2(255)  NULL ,
				link_type varchar2(30)  NULL ,
                constraint sugarfeedpk primary key(id) );
CREATE INDEX sgrfeed_date ON sugarfeed (date_entered,deleted);













CREATE TABLE users_password_link (
                id varchar2(36)  NOT NULL ,
                username varchar2(36)  NULL ,
                date_generated date  NULL ,
                deleted number(1)  DEFAULT 0  NOT NULL ,
                constraint users_password_link_pk primary key(id));
CREATE INDEX idx_username ON users_password_link (username);
ALTER TABLE EMAIL_CACHE MODIFY senddate date  NULL ;

ALTER TABLE IMPORT_MAPS ADD (
							CONTENT_TMP CLOB,
							DEFAULT_VALUES_TMP CLOB );

UPDATE IMPORT_MAPS SET 
		            CONTENT_TMP = blob_to_clob(CONTENT) ,
					DEFAULT_VALUES_TMP = blob_to_clob(DEFAULT_VALUES);

ALTER TABLE IMPORT_MAPS DROP COLUMN CONTENT;
ALTER TABLE IMPORT_MAPS DROP COLUMN DEFAULT_VALUES;

ALTER TABLE IMPORT_MAPS RENAME COLUMN CONTENT_TMP TO CONTENT;
ALTER TABLE IMPORT_MAPS RENAME COLUMN DEFAULT_VALUES_TMP TO DEFAULT_VALUES;
















