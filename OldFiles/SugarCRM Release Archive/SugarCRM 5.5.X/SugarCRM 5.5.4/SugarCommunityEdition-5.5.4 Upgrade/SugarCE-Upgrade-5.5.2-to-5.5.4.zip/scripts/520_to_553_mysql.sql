-- MySQL upgrade script for Sugar 5.2.0 to 5.5.1

ALTER TABLE upgrade_history modify column manifest longtext NULL;

ALTER TABLE leads add column birthdate date  NULL ;
ALTER TABLE calls add index idx_calls_par_del (parent_id, parent_type, deleted );







































ALTER TABLE users   add column system_generated_password bool  DEFAULT '0' NOT NULL ,  
		    add column pwd_last_changed datetime  NULL ,




                    add column external_auth_only bool  DEFAULT '0' NULL;                    

ALTER TABLE outbound_email modify mail_smtpssl int(1) DEFAULT 0 NULL, 
						   modify column `type` varchar(15) NOT NULL default 'user',
						   modify column `mail_sendtype` varchar(8) NOT NULL default 'smtp';













































































































ALTER TABLE sugarfeed   drop index sgrfeed_date ,  					    




						add index sgrfeed_date (date_entered, deleted)
						;















CREATE TABLE users_password_link (
                id char(36)  NOT NULL ,
                username varchar(36)  NULL ,
                date_generated datetime  NULL ,
                deleted bool  DEFAULT 0  NOT NULL  , 
                PRIMARY KEY (id),   
                KEY idx_username (username)) 
            CHARACTER SET utf8 COLLATE utf8_general_ci;

ALTER TABLE import_maps   modify column content text  NULL ,  modify column default_values text  NULL ;

create index `idx_mail_to`  on `email_cache` (`toaddr` );

ALTER TABLE inbound_email_autoreply   add column ie_id char(36);