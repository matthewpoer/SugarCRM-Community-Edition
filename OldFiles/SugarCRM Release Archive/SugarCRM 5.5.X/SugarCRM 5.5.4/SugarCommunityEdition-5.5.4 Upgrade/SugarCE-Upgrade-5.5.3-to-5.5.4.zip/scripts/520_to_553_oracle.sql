-- Oracle upgrade script for Sugar 5.2.0 to 5.5.1

ALTER TABLE LEADS ADD birthdate date  NULL ;














ALTER TABLE USERS ADD (
					system_generated_password number(1)  DEFAULT 0 NOT NULL,
					pwd_last_changed date  NULL ,



					external_auth_only number(1)  DEFAULT '0' NULL);

ALTER TABLE outbound_email modify(mail_smtpssl number,
								  TYPE VARCHAR2(15),
        						  MAIL_SENDTYPE  DEFAULT 'smtp');


































































































DROP INDEX sgrfeed_date ;
CREATE INDEX sgrfeed_date ON sugarfeed (date_entered,deleted);














CREATE TABLE users_password_link (
                id varchar2(36)  NOT NULL ,
                username varchar2(36)  NULL ,
                date_generated date  NULL ,
                deleted number(1)  DEFAULT 0  NOT NULL,
                constraint users_password_link_pk primary key(id));
CREATE INDEX idx_username ON users_password_link (username);

ALTER TABLE IMPORT_MAPS ADD (
                            CONTENT_TMP CLOB,
                            DEFAULT_VALUES_TMP CLOB );

UPDATE IMPORT_MAPS SET 
                    CONTENT_TMP = blob_to_clob(CONTENT) ,
                    DEFAULT_VALUES_TMP = blob_to_clob(DEFAULT_VALUES);

ALTER TABLE IMPORT_MAPS DROP COLUMN CONTENT;
ALTER TABLE IMPORT_MAPS DROP COLUMN DEFAULT_VALUES;

ALTER TABLE IMPORT_MAPS RENAME COLUMN CONTENT_TMP TO CONTENT;
ALTER TABLE IMPORT_MAPS RENAME COLUMN DEFAULT_VALUES_TMP TO DEFAULT_VALUES;

















create index idx_calls_par_del  on calls (parent_id, parent_type, deleted );

create index idx_mail_to  on email_cache (toaddr );

ALTER TABLE inbound_email_autoreply   add ie_id varchar2(36);