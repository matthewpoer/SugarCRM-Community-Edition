<?php
// created: 2012-04-04 19:58:49
$manifest = array (
  'acceptable_sugar_flavors' => 
  array (
    0 => 'CE',
  ),
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '6\\.4\\.[0-9]$',
    ),
  ),
  'author' => 'SugarCRM, Inc.',
  'copy_files' => 
  array (
    'from_dir' => 'SugarCE-Upgrade-6.4.x-to-6.4.3',
    'to_dir' => '',
    'force_copy' => 
    array (
    ),
  ),
  'description' => '',
  'icon' => '',
  'is_uninstallable' => false,
  'offline_client_applicable' => true,
  'name' => 'SugarCE',
  'published_date' => '2012-04-04 19:58:49',
  'type' => 'patch',
  'version' => '6.4.3',
);
?>
