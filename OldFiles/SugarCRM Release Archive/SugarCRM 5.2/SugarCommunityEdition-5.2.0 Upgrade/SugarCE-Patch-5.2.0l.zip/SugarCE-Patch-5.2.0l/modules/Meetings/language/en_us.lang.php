<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2010 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
	'ERR_DELETE_RECORD' => 'A record number must be specified to delete the meeting.',
	
	'LBL_ACCEPT_THIS'=>'Accept?',  
	'LBL_ADD_BUTTON'=> 'Add',
	'LBL_ADD_INVITEE' => 'Add Invitees',
	'LBL_COLON' => ':',
	'LBL_CONTACT_NAME' => 'Contact:',
	'LBL_CONTACTS_SUBPANEL_TITLE' => 'Contacts',
	'LBL_CREATED_BY'=>'Created by',
	'LBL_DATE_END'=>'Date End',
	'LBL_DATE_TIME' => 'Start Date & Time:',
	'LBL_DATE' => 'Start Date:',
	'LBL_DEFAULT_STATUS' => 'Planned',
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Meetings',
	'LBL_DEL'=> 'Del',
	'LBL_DESCRIPTION_INFORMATION' => 'Description Information',
	'LBL_DESCRIPTION' => 'Description:',
	'LBL_DURATION_HOURS' => 'Duration Hours:',
	'LBL_DURATION_MINUTES' => 'Duration Minutes:',
	'LBL_DURATION' => 'Duration:',
	'LBL_EMAIL' => 'Email',
	'LBL_FIRST_NAME' => 'First Name',
	'LBL_HISTORY_SUBPANEL_TITLE' => 'Notes',
	'LBL_HOURS_ABBREV' => 'h',
	'LBL_HOURS_MINS' => '(hours/minutes)',
	'LBL_INVITEE' => 'Invitees',
	'LBL_LAST_NAME' => 'Last Name',
	'LBL_ASSIGNED_TO_NAME'=>'Assigned to:',
	'LBL_LIST_ASSIGNED_TO_NAME' => 'Assigned User',
	'LBL_LIST_CLOSE' => 'Close',
	'LBL_LIST_CONTACT' => 'Contact',
	'LBL_LIST_DATE_MODIFIED'=>'Date Modified',
	'LBL_LIST_DATE' => 'Start Date',
	'LBL_LIST_DUE_DATE'=>'Due Date',
	'LBL_LIST_FORM_TITLE' => 'Meeting List',
	'LBL_LIST_MY_MEETINGS' => 'My Meetings',
	'LBL_LIST_RELATED_TO' => 'Related to',
	'LBL_LIST_STATUS'=>'Status',
	'LBL_LIST_SUBJECT' => 'Subject',
	'LBL_LIST_TIME' => 'Start Time',
	'LBL_LEADS_SUBPANEL_TITLE' => 'Leads',
	'LBL_LOCATION' => 'Location:',
	'LBL_MEETING' => 'Meeting:',
	'LBL_MINSS_ABBREV' => 'm',
	'LBL_MODIFIED_BY'=>'Modified by',
	'LBL_MODULE_NAME' => 'Meetings',
	'LBL_MODULE_TITLE' => 'Meetings: Home',
	'LBL_NAME' => 'Name',
	'LBL_NEW_FORM_TITLE' => 'Create Appointment',
	'LBL_OUTLOOK_ID' => 'Outlook ID',
	'LBL_PHONE' => 'Phone Office:',
	'LBL_REMINDER_TIME'=>'Reminder Time',
	'LBL_REMINDER' => 'Reminder:',
	'LBL_SCHEDULING_FORM_TITLE' => 'Scheduling',
	'LBL_SEARCH_BUTTON'=> 'Search',
	'LBL_SEARCH_FORM_TITLE' => 'Meeting Search',
	'LBL_SEND_BUTTON_KEY'=>'I',
	'LBL_SEND_BUTTON_LABEL'=>'Send Invites',
	'LBL_SEND_BUTTON_TITLE'=>'Send Invites [Alt+I]',
	'LBL_STATUS' => 'Status:',
	'LBL_SUBJECT' => 'Subject:',
	'LBL_TIME' => 'Start Time:',
	'LBL_USERS_SUBPANEL_TITLE' => 'Users',
	
	'LNK_CALL_LIST'=>'Calls',
	'LNK_EMAIL_LIST'=>'Emails',
	'LNK_MEETING_LIST'=>'Meetings',
	'LNK_NEW_APPOINTMENT' => 'Create Appointment',
	'LNK_NEW_CALL'=>'Schedule Call',
	'LNK_NEW_EMAIL'=>'Archive Email',
	'LNK_NEW_MEETING'=>'Schedule Meeting',
	'LNK_NEW_NOTE'=>'Create Note or Attachment',
	'LNK_NEW_TASK'=>'Create Task',
	'LNK_NOTE_LIST'=>'Notes',
	'LNK_TASK_LIST'=>'Tasks',
	'LNK_VIEW_CALENDAR' => 'Today',
	
	'NTC_REMOVE_INVITEE' => 'Are you sure you want to remove this invitee from the meeting?',
    'LBL_CREATED_USER' => 'Created User',
    'LBL_MODIFIED_USER' => 'Modified User',
    'NOTICE_DURATION_TIME' => 'Duration time must be greater than 0',
);
?>
