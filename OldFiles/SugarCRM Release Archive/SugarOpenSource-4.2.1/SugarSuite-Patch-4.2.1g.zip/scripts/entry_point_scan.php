<?php

if(!defined('sugarEntry'))define('sugarEntry', true);
function entryPointScan($path, $depth, $writableCheck = false){
	$dir = dir($path);
	while($entry = $dir->read()){
		if($entry != '.' && $entry != '..'){
			$fullpath = $path . '/'. $entry;
			
			if(is_file($fullpath) && strlen($entry) > 4 && strcmp(strtolower(substr($entry, -4, 4)), '.php' ) == 0){
			
				
					$GLOBALS['totalFileCount']++;
					if($writableCheck){
						entryPointWritable($fullpath);
					}else{
						updateEntryPoint($fullpath, $depth);
					}
				
			}
			if(is_dir($fullpath)){
				$ignore = false;
			
				foreach($GLOBALS['ignoreDirs'] as $ignorePath){
					
					
					if(substr_count(strtolower($fullpath), strtolower($ignorePath))> 0){
							$ignore = true;
					}
				}
				if(!$ignore){
					entryPointScan($fullpath, $depth + 1, $writableCheck);
					$GLOBALS['totalDirCount']++;
				}
			}
		}
	}
	$dir->close();


}


function entryPointWritable($path){
	if(!is_writable($path)){
		$GLOBALS['nonWritableFiles'][] = $path;
	}
}

function updateEntryPoint($path, $depth){
	$filedata = file_get_contents($path);
	$updated = false;
	//FIRST UPDATE ALL OLD WAYS FOR ENTRY POINTS
	//define(sugarEntry, true);
	$olddata = $filedata;
	$filedata =	preg_replace('/\$GLOBALS\[\'sugarEntry\'\][ ]*\=[ ]*true;/si',"if(!defined('sugarEntry'))define('sugarEntry', true);" , $filedata);
	if($olddata != $filedata){
		$updated = true;
	}
	//if(!defined('sugarEntry') || !sugarEntry)) die('Not A Valid Entry Point');

	$olddata = $filedata;
	$filedata =	preg_replace('/if[ ]*\([ ]*empty[ ]*\([ ]*\$GLOBALS\[\'sugarEntry\'\][ ]*\)[ ]*\)/si' ,"if(!defined('sugarEntry') || !sugarEntry)", $filedata);
	if($olddata != $filedata){
		$updated = true;
	}
	//clean up php tags to all be lower case
	//$filedata = str_replace('<?PHP', '<?php', $filedata);
	/*
	if(substr_count($filedata,'sugarEntry') == 0)	{
		$data = explode('<?php', $filedata, 2);
		//make sure we have <?php some where in there
		if(substr_count($filedata, '<?php') > 0 && count($data) == 1){
			$data[1] = $data[0];
			$data[0] = '';
			
		}
		if(count($data) == 2){
			//if the depth is 0 then it is an entry point
			if($depth == 0){
				$filedata = $data[0] . "<?php\nif(!defined('sugarEntry'))define('sugarEntry',true);\n". $data[1];

			}else{
				$filedata = $data[0] . "<?php\nif(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');\n". $data[1];

			}
		}
		$updated = true;
	}
*/
	if($updated){
		$fp = fopen($path, 'w');
		fwrite($fp, $filedata);
		fclose($fp);
		echo "<br>".'updated - ' . $path . "\n";
	}
}


?>
