

--
-- CHANGED TABLES
--

-- accounts
ALTER TABLE `accounts` CHANGE COLUMN `description` `description` longtext NULL;

-- accounts_audit
ALTER TABLE `accounts_audit` CHANGE COLUMN `before_value_text` `before_value_text` longtext NULL;
ALTER TABLE `accounts_audit` CHANGE COLUMN `after_value_text` `after_value_text` longtext NULL;

-- acl_roles
ALTER TABLE `acl_roles` CHANGE COLUMN `description` `description` longtext NULL;

-- acl_roles_actions
ALTER TABLE `acl_roles_actions` CHANGE COLUMN `access_override` `access_override` int(11) NULL;

-- bugs
ALTER TABLE `bugs` CHANGE COLUMN `description` `description` longtext NULL;
ALTER TABLE `bugs` CHANGE COLUMN `work_log` `work_log` longtext NULL;

-- bugs_audit
ALTER TABLE `bugs_audit` CHANGE COLUMN `before_value_text` `before_value_text` longtext NULL;
ALTER TABLE `bugs_audit` CHANGE COLUMN `after_value_text` `after_value_text` longtext NULL;

-- calls
ALTER TABLE `calls` CHANGE COLUMN `description` `description` longtext NULL;

-- campaigns
ALTER TABLE `campaigns` CHANGE COLUMN `objective` `objective` longtext NULL;
ALTER TABLE `campaigns` CHANGE COLUMN `content` `content` longtext NULL;

-- campaigns_audit
ALTER TABLE `campaigns_audit` CHANGE COLUMN `before_value_text` `before_value_text` longtext NULL;
ALTER TABLE `campaigns_audit` CHANGE COLUMN `after_value_text` `after_value_text` longtext NULL;

-- cases
ALTER TABLE `cases` CHANGE COLUMN `description` `description` longtext NULL;
ALTER TABLE `cases` CHANGE COLUMN `resolution` `resolution` longtext NULL;

-- cases_audit
ALTER TABLE `cases_audit` CHANGE COLUMN `before_value_text` `before_value_text` longtext NULL;
ALTER TABLE `cases_audit` CHANGE COLUMN `after_value_text` `after_value_text` longtext NULL;

-- config
ALTER TABLE `config` CHANGE COLUMN `value` `value` longtext NULL;

-- contacts
ALTER TABLE `contacts` CHANGE COLUMN `description` `description` longtext NULL;

-- contacts_audit
ALTER TABLE `contacts_audit` CHANGE COLUMN `before_value_text` `before_value_text` longtext NULL;
ALTER TABLE `contacts_audit` CHANGE COLUMN `after_value_text` `after_value_text` longtext NULL;
















-- dashboards
ALTER TABLE `dashboards` CHANGE COLUMN `description` `description` longtext NULL;
ALTER TABLE `dashboards` CHANGE COLUMN `content` `content` longtext NULL;










-- documents
ALTER TABLE `documents` CHANGE COLUMN `description` `description` longtext NULL;

-- email_marketing
ALTER TABLE `email_marketing` CHANGE COLUMN `campaign_id` `campaign_id` varchar(36) NULL;

-- email_templates
ALTER TABLE `email_templates` CHANGE COLUMN `description` `description` longtext NULL;
ALTER TABLE `email_templates` CHANGE COLUMN `body` `body` longtext NULL;
ALTER TABLE `email_templates` CHANGE COLUMN `body_html` `body_html` longtext NULL;

-- emails
ALTER TABLE `emails` CHANGE COLUMN `description` `description` longtext NULL;
ALTER TABLE `emails` CHANGE COLUMN `description_html` `description_html` longtext NULL;
ALTER TABLE `emails` CHANGE COLUMN `to_addrs` `to_addrs` longtext NULL;
ALTER TABLE `emails` CHANGE COLUMN `cc_addrs` `cc_addrs` longtext NULL;
ALTER TABLE `emails` CHANGE COLUMN `bcc_addrs` `bcc_addrs` longtext NULL;
ALTER TABLE `emails` CHANGE COLUMN `to_addrs_ids` `to_addrs_ids` longtext NULL;
ALTER TABLE `emails` CHANGE COLUMN `to_addrs_names` `to_addrs_names` longtext NULL;
ALTER TABLE `emails` CHANGE COLUMN `to_addrs_emails` `to_addrs_emails` longtext NULL;
ALTER TABLE `emails` CHANGE COLUMN `cc_addrs_ids` `cc_addrs_ids` longtext NULL;
ALTER TABLE `emails` CHANGE COLUMN `cc_addrs_names` `cc_addrs_names` longtext NULL;
ALTER TABLE `emails` CHANGE COLUMN `cc_addrs_emails` `cc_addrs_emails` longtext NULL;
ALTER TABLE `emails` CHANGE COLUMN `bcc_addrs_ids` `bcc_addrs_ids` longtext NULL;
ALTER TABLE `emails` CHANGE COLUMN `bcc_addrs_names` `bcc_addrs_names` longtext NULL;
ALTER TABLE `emails` CHANGE COLUMN `bcc_addrs_emails` `bcc_addrs_emails` longtext NULL;

-- feeds
ALTER TABLE `feeds` CHANGE COLUMN `description` `description` longtext NULL;

-- leads
ALTER TABLE `leads` CHANGE COLUMN `lead_source_description` `lead_source_description` longtext NULL;
ALTER TABLE `leads` CHANGE COLUMN `status_description` `status_description` longtext NULL;
ALTER TABLE `leads` CHANGE COLUMN `description` `description` longtext NULL;
ALTER TABLE `leads` CHANGE COLUMN `account_description` `account_description` longtext NULL;

-- leads_audit
ALTER TABLE `leads_audit` CHANGE COLUMN `before_value_text` `before_value_text` longtext NULL;
ALTER TABLE `leads_audit` CHANGE COLUMN `after_value_text` `after_value_text` longtext NULL;

-- meetings
ALTER TABLE `meetings` CHANGE COLUMN `description` `description` longtext NULL;

-- notes
ALTER TABLE `notes` CHANGE COLUMN `description` `description` longtext NULL;

-- opportunities
ALTER TABLE `opportunities` CHANGE COLUMN `description` `description` longtext NULL;

-- opportunities_audit
ALTER TABLE `opportunities_audit` CHANGE COLUMN `before_value_text` `before_value_text` longtext NULL;
ALTER TABLE `opportunities_audit` CHANGE COLUMN `after_value_text` `after_value_text` longtext NULL;

























-- project
ALTER TABLE `project` CHANGE COLUMN `description` `description` longtext NULL;

-- project_task
ALTER TABLE `project_task` CHANGE COLUMN `description` `description` longtext NULL;

-- project_task_audit
ALTER TABLE `project_task_audit` CHANGE COLUMN `before_value_text` `before_value_text` longtext NULL;
ALTER TABLE `project_task_audit` CHANGE COLUMN `after_value_text` `after_value_text` longtext NULL;

-- prospect_lists
ALTER TABLE `prospect_lists` CHANGE COLUMN `description` `description` longtext NULL;

-- prospects
ALTER TABLE `prospects` CHANGE COLUMN `description` `description` longtext NULL;















-- roles
ALTER TABLE `roles` CHANGE COLUMN `description` `description` longtext NULL;
ALTER TABLE `roles` CHANGE COLUMN `modules` `modules` longtext NULL;















-- tasks
ALTER TABLE `tasks` CHANGE COLUMN `description` `description` longtext NULL;
















-- users
ALTER TABLE `users` CHANGE COLUMN `description` `description` longtext NULL;
ALTER TABLE `users` CHANGE COLUMN `user_preferences` `user_preferences` longtext NULL;

-- users_signatures
ALTER TABLE `users_signatures` CHANGE COLUMN `signature` `signature` longtext NULL;
ALTER TABLE `users_signatures` CHANGE COLUMN `signature_html` `signature_html` longtext NULL;

-- vcals
ALTER TABLE `vcals` CHANGE COLUMN `content` `content` longtext NULL;











--
-- INDICES
--















DELETE FROM `config` WHERE `category` = 'info' AND `name` = 'sugar_version';
INSERT INTO `config` (`category`, `name`, `value`) VALUES ('info', 'sugar_version', '4.2.1');
