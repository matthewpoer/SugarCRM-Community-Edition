<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**
 * Layout definition for Contacts
 *
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */

// $Id: ForContacts.php,v 1.2.8.1 2006/06/02 01:12:27 majed Exp $

$subpanel_layout = array(
			'buttons' => array(
               array('widget_class'=>'SubPanelTopCreateButton'),
			array('widget_class'=>'SubPanelTopSelectButton', 'popup_module' => 'Cases'),
			),
			'list_fields' => array(
            array(
						'name' => 'first_name',
			 		 	'usage' => 'query_only',
					),
					array(
						'name' => 'last_name',
			 		 	'usage' => 'query_only',
					),
					array(
						'name' => 'name',
						'vname' => 'LBL_LIST_NAME',
						'widget_class' => 'SubPanelDetailViewLink',
			 		 	'module' => 'Contacts',
		 		 		'width' => '23%',
					),
					array(
			 		 	'name' => 'account_name',
			 		 	'module' => 'Accounts',
			 		 	'target_record_key' => 'account_id',
			 		 	'target_module' => 'Accounts',
						'widget_class' => 'SubPanelDetailViewLink',
			 		 	'vname' => 'LBL_LIST_ACCOUNT_NAME',
		 		 		'width' => '22%',
					),
					array(
						'name'=>'email1',
						'vname' => 'LBL_LIST_EMAIL',
						'widget_class' => 'SubPanelEmailLink',
		 		 		'width' => '30%',
					),
					array (
						'name' => 'phone_home',
						'vname' => 'LBL_LIST_PHONE',
		 		 		'width' => '15%',
					),
					array(
			 		 	'name' => 'nothing',
						'widget_class' => 'SubPanelEditButton',
			 		 	'module' => 'Contacts',
		 		 		'width' => '5%',
					),
					array(
			 		 	'name' => 'nothing',
						'widget_class' => 'SubPanelRemoveButton',
						'linked_field' => 'contacts',
			 		 	'module' => 'Contacts',
		 		 		'width' => '5%',
					),
			),
);
?>
