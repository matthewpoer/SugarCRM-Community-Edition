<?php
$GLOBALS['sugarEntry'] = true;
require_once('include/utils/file_utils.php');

// fix slot tags on all EditView.html
function fix_slot_tags() {
  $backup_dir = "420_post_install_fix_backups/pre_slot_tag_fix/";
  $cache_dir = create_cache_directory($backup_dir);
  
  $module_dirs = get_module_dir_list();
  foreach($module_dirs as $dir) {
    if(file_exists("modules/$dir/EditView.html")) {
      // read in the contents
      $file = fopen("modules/$dir/EditView.html", 'r');
      $contents = fread($file, filesize("modules/$dir/EditView.html")); 
      fclose($file);

      // search and replace to fix slot tags
      $user_input_pat = '/<slot>(<input.*sqsEnabled.*name\s*=.*assigned_user_name.*\/>)<\/slot>(.*<input.*open_popup\(.*Users.*\/>)/Uis';
      $team_input_pat = '/<slot>(<input.*sqsEnabled.*name\s*=.*team_name.*\/>)<\/slot>(.*<input.*open_popup\(.*Teams.*\/>)/Uis';
      
      if(preg_match($user_input_pat, $contents) || preg_match($team_input_pat, $contents)) {
      // backup the files here!
        create_cache_directory("{$backup_dir}modules/$dir/");
        copy("modules/$dir/EditView.html", "${cache_dir}modules/$dir/EditView.html");	
        $contents = preg_replace(array($user_input_pat, $team_input_pat), array('<slot>${1}${2}</slot>', '<slot>${1}${2}</slot>'), $contents);

        //write file back out
        $file = fopen("modules/$dir/EditView.html", 'w');
        fwrite($file, $contents);
        fclose($file);
      }
    }
  }
  return true; 
}

// apply javascript versioning files that weren't modified, only in folders modules and themes
function apply_js_versioning() {
  $backup_dir = "420_post_install_fix_backups/pre_js_versioning_fix/";
  $cache_dir = create_cache_directory($backup_dir);
  $css_regular_pat = '/(<link[^\/>]*\shref\s*=\s*[\'"].*\.css[^?\'"]*?)([\'"][^\>]*?\/?\>)/Ui'; // matches css links
  $javascript_src_pat = '/(<script[^\/>]*\ssrc\s*=\s*[\'"].*\.js[^?\'"]*?)([\'"][^\>]*?\/?\>)/Ui'; // matches javascript src

  $replacement_pat = '${1}?s={SUGAR_VERSION}&c={JS_CUSTOM_VERSION}${2}';
  $files = array();

  get_files($files, "./modules", '/\.(html|tmpl)$/');

  foreach($files as $the_file) {
    // read in the contents
    $file = fopen($the_file, 'r');
    $contents = fread($file, filesize($the_file)); 
    fclose($file);

    if(preg_match($css_regular_pat, $contents) || preg_match($javascript_src_pat, $contents)) {
      // backup the files here!
      $createDir = $backup_dir;
      $createDir .= substr($the_file, 2, strrpos($the_file, '/'));
      create_cache_directory($createDir);
      copy($the_file, $cache_dir . substr($the_file, 2, strlen($the_file)));
      
      $contents = preg_replace(array($css_regular_pat, $javascript_src_pat), array($replacement_pat, $replacement_pat), $contents);
      
      $file = fopen($the_file, 'w');
      fwrite($file, $contents);
      fclose($file);
    }
  }
  return true;
}

// recursively get all files in a dir with optional matching pattern
function get_files(&$arr, $dir, $pattern = null) { 
  $contents = glob("{$dir}/*"); 
  if(is_array($contents)) {
    foreach($contents as $file) { 
      if(is_dir($file)) {
        get_files($arr, $file, $pattern);
      }
      else {
        if(empty($pattern)) 
          $arr[] = $file;
        else if(preg_match($pattern, $file)) 
          $arr[] = $file;
      }
    }
  }
}

?>
