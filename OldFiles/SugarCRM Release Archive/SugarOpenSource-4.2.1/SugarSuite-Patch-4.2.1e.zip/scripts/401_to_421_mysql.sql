--
-- NEW TABLES
--

-- campaign_trkrs
CREATE TABLE `campaign_trkrs` (
  `id` varchar(36) NOT NULL default '',
  `tracker_name` varchar(30) default NULL,
  `tracker_url` varchar(255) default 'http://',
  `tracker_key` int(11) NOT NULL auto_increment,
  `campaign_id` varchar(36) default NULL,
  `date_entered` datetime NOT NULL default '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL default '0000-00-00 00:00:00',
  `modified_user_id` varchar(36) default NULL,
  `created_by` varchar(36) default NULL,
  `is_optout` tinyint(1) NOT NULL default '0',
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `campaign_tracker_key_idx` (`tracker_key`)
);





































































































-- emails_bugs
CREATE TABLE `emails_bugs` (
  `id` varchar(36) NOT NULL default '',
  `email_id` varchar(36) default NULL,
  `bug_id` varchar(36) default NULL,
  `date_modified` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `idx_bug_email_email` (`email_id`),
  KEY `idx_bug_email_bug` (`bug_id`)
);

-- emails_project_tasks
CREATE TABLE `emails_project_tasks` (
  `id` varchar(36) NOT NULL default '',
  `email_id` varchar(36) default NULL,
  `project_task_id` varchar(36) default NULL,
  `date_modified` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `idx_project_task_email_email` (`email_id`),
  KEY `idx_project_task_email_project_task` (`project_task_id`)
);

-- emails_projects
CREATE TABLE `emails_projects` (
  `id` varchar(36) NOT NULL default '',
  `email_id` varchar(36) default NULL,
  `project_id` varchar(36) default NULL,
  `date_modified` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `idx_project_email_email` (`email_id`),
  KEY `idx_project_email_project` (`project_id`)
);

-- emails_prospects
CREATE TABLE `emails_prospects` (
  `id` varchar(36) NOT NULL default '',
  `email_id` varchar(36) default NULL,
  `prospect_id` varchar(36) default NULL,
  `date_modified` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `idx_prospect_email_email` (`email_id`),
  KEY `idx_prospect_email_prospect` (`prospect_id`)
);















-- emails_tasks
CREATE TABLE `emails_tasks` (
  `id` varchar(36) NOT NULL default '',
  `email_id` varchar(36) default NULL,
  `task_id` varchar(36) default NULL,
  `date_modified` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `idx_task_email_email` (`email_id`),
  KEY `idx_task_email_task` (`task_id`)
);

-- linked_documents
CREATE TABLE `linked_documents` (
  `id` varchar(36) NOT NULL default '',
  `parent_id` varchar(36) default NULL,
  `parent_type` varchar(25) default NULL,
  `document_id` varchar(36) default NULL,
  `document_revision_id` varchar(36) default NULL,
  `date_modified` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
);

-- users_signatures
CREATE TABLE `users_signatures` (
  `id` varchar(36) NOT NULL default '',
  `date_entered` datetime NOT NULL default '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL default '0000-00-00 00:00:00',
  `deleted` tinyint(1) NOT NULL default '0',
  `user_id` varchar(36) default NULL,
  `name` varchar(255) default NULL,
  `signature` longtext,
  `signature_html` longtext,
  PRIMARY KEY  (`id`),
  KEY `idx_user_id` (`user_id`)
);



--
-- CHANGED TABLES
--

-- accounts
ALTER TABLE `accounts` CHANGE COLUMN `description` `description` longtext NULL;

-- accounts_audit
ALTER TABLE `accounts_audit` CHANGE COLUMN `before_value_text` `before_value_text` longtext NULL;
ALTER TABLE `accounts_audit` CHANGE COLUMN `after_value_text` `after_value_text` longtext NULL;

-- acl_roles
ALTER TABLE `acl_roles` CHANGE COLUMN `description` `description` longtext NULL;

-- acl_roles_actions
ALTER TABLE `acl_roles_actions` CHANGE COLUMN `access_override` `access_override` int(11) NULL;

-- bugs
ALTER TABLE `bugs` CHANGE COLUMN `description` `description` longtext NULL;
ALTER TABLE `bugs` CHANGE COLUMN `work_log` `work_log` longtext NULL;

-- bugs_audit
ALTER TABLE `bugs_audit` CHANGE COLUMN `before_value_text` `before_value_text` longtext NULL;
ALTER TABLE `bugs_audit` CHANGE COLUMN `after_value_text` `after_value_text` longtext NULL;

-- calls
ALTER TABLE `calls` CHANGE COLUMN `description` `description` longtext NULL;

-- campaign_log
ALTER TABLE `campaign_log` ADD COLUMN `more_information` varchar(100) NULL FIRST;

-- campaigns
ALTER TABLE `campaigns` ADD COLUMN `currency_id` varchar(36) NULL FIRST;
ALTER TABLE `campaigns` CHANGE COLUMN `objective` `objective` longtext NULL;
ALTER TABLE `campaigns` CHANGE COLUMN `content` `content` longtext NULL;

-- campaigns_audit
ALTER TABLE `campaigns_audit` CHANGE COLUMN `before_value_text` `before_value_text` longtext NULL;
ALTER TABLE `campaigns_audit` CHANGE COLUMN `after_value_text` `after_value_text` longtext NULL;

-- cases
ALTER TABLE `cases` CHANGE COLUMN `description` `description` longtext NULL;
ALTER TABLE `cases` CHANGE COLUMN `resolution` `resolution` longtext NULL;

-- cases_audit
ALTER TABLE `cases_audit` CHANGE COLUMN `before_value_text` `before_value_text` longtext NULL;
ALTER TABLE `cases_audit` CHANGE COLUMN `after_value_text` `after_value_text` longtext NULL;

-- config
ALTER TABLE `config` CHANGE COLUMN `value` `value` longtext NULL;

-- contacts
ALTER TABLE `contacts` CHANGE COLUMN `description` `description` longtext NULL;

-- contacts_audit
ALTER TABLE `contacts_audit` CHANGE COLUMN `before_value_text` `before_value_text` longtext NULL;
ALTER TABLE `contacts_audit` CHANGE COLUMN `after_value_text` `after_value_text` longtext NULL;







-- dashboards
ALTER TABLE `dashboards` CHANGE COLUMN `description` `description` longtext NULL;
ALTER TABLE `dashboards` CHANGE COLUMN `content` `content` longtext NULL;










-- documents
ALTER TABLE `documents` CHANGE COLUMN `description` `description` longtext NULL;
ALTER TABLE `documents` ADD COLUMN `related_doc_id` varchar(36) NULL FIRST;
ALTER TABLE `documents` ADD COLUMN `related_doc_rev_id` varchar(36) NULL FIRST;
ALTER TABLE `documents` ADD COLUMN `is_template` tinyint(1) NULL default '0' FIRST;
ALTER TABLE `documents` ADD COLUMN `template_type` varchar(25) NULL FIRST;

-- email_marketing
ALTER TABLE `email_marketing` CHANGE COLUMN `campaign_id` `campaign_id` varchar(36) NULL;

-- email_templates
ALTER TABLE `email_templates` CHANGE COLUMN `description` `description` longtext NULL;
ALTER TABLE `email_templates` CHANGE COLUMN `body` `body` longtext NULL;
ALTER TABLE `email_templates` CHANGE COLUMN `body_html` `body_html` longtext NULL;

-- emails
ALTER TABLE `emails` CHANGE COLUMN `description` `description` longtext NULL;
ALTER TABLE `emails` CHANGE COLUMN `description_html` `description_html` longtext NULL;
ALTER TABLE `emails` CHANGE COLUMN `to_addrs` `to_addrs` longtext NULL;
ALTER TABLE `emails` CHANGE COLUMN `cc_addrs` `cc_addrs` longtext NULL;
ALTER TABLE `emails` CHANGE COLUMN `bcc_addrs` `bcc_addrs` longtext NULL;
ALTER TABLE `emails` CHANGE COLUMN `to_addrs_ids` `to_addrs_ids` longtext NULL;
ALTER TABLE `emails` CHANGE COLUMN `to_addrs_names` `to_addrs_names` longtext NULL;
ALTER TABLE `emails` CHANGE COLUMN `to_addrs_emails` `to_addrs_emails` longtext NULL;
ALTER TABLE `emails` CHANGE COLUMN `cc_addrs_ids` `cc_addrs_ids` longtext NULL;
ALTER TABLE `emails` CHANGE COLUMN `cc_addrs_names` `cc_addrs_names` longtext NULL;
ALTER TABLE `emails` CHANGE COLUMN `cc_addrs_emails` `cc_addrs_emails` longtext NULL;
ALTER TABLE `emails` CHANGE COLUMN `bcc_addrs_ids` `bcc_addrs_ids` longtext NULL;
ALTER TABLE `emails` CHANGE COLUMN `bcc_addrs_names` `bcc_addrs_names` longtext NULL;
ALTER TABLE `emails` CHANGE COLUMN `bcc_addrs_emails` `bcc_addrs_emails` longtext NULL;

-- feeds
ALTER TABLE `feeds` CHANGE COLUMN `description` `description` longtext NULL;

-- leads
ALTER TABLE `leads` CHANGE COLUMN `lead_source_description` `lead_source_description` longtext NULL;
ALTER TABLE `leads` CHANGE COLUMN `status_description` `status_description` longtext NULL;
ALTER TABLE `leads` CHANGE COLUMN `description` `description` longtext NULL;
ALTER TABLE `leads` CHANGE COLUMN `account_description` `account_description` longtext NULL;

-- leads_audit
ALTER TABLE `leads_audit` CHANGE COLUMN `before_value_text` `before_value_text` longtext NULL;
ALTER TABLE `leads_audit` CHANGE COLUMN `after_value_text` `after_value_text` longtext NULL;

-- meetings
ALTER TABLE `meetings` CHANGE COLUMN `description` `description` longtext NULL;

-- notes
ALTER TABLE `notes` CHANGE COLUMN `description` `description` longtext NULL;

-- opportunities
ALTER TABLE `opportunities` CHANGE COLUMN `description` `description` longtext NULL;

-- opportunities_audit
ALTER TABLE `opportunities_audit` CHANGE COLUMN `before_value_text` `before_value_text` longtext NULL;
ALTER TABLE `opportunities_audit` CHANGE COLUMN `after_value_text` `after_value_text` longtext NULL;

































-- project
ALTER TABLE `project` CHANGE COLUMN `description` `description` longtext NULL;

-- project_task
ALTER TABLE `project_task` CHANGE COLUMN `description` `description` longtext NULL;

-- project_task_audit
ALTER TABLE `project_task_audit` CHANGE COLUMN `before_value_text` `before_value_text` longtext NULL;
ALTER TABLE `project_task_audit` CHANGE COLUMN `after_value_text` `after_value_text` longtext NULL;

-- prospect_lists
ALTER TABLE `prospect_lists` CHANGE COLUMN `description` `description` longtext NULL;

-- prospects
ALTER TABLE `prospects` CHANGE COLUMN `description` `description` longtext NULL;















-- roles
ALTER TABLE `roles` CHANGE COLUMN `description` `description` longtext NULL;
ALTER TABLE `roles` CHANGE COLUMN `modules` `modules` longtext NULL;















-- tasks
ALTER TABLE `tasks` CHANGE COLUMN `description` `description` longtext NULL;
















-- users
ALTER TABLE `users` CHANGE COLUMN `description` `description` longtext NULL;
ALTER TABLE `users` CHANGE COLUMN `user_preferences` `user_preferences` longtext NULL;

-- vcals
ALTER TABLE `vcals` CHANGE COLUMN `content` `content` longtext NULL;














--
-- INDICES
--

-- accounts
ALTER TABLE `accounts` DISABLE KEYS;
-- [added newly]
ALTER TABLE `accounts` ADD INDEX `idx_accnt_assigned_del` (`deleted`, `assigned_user_id`);
-- [added newly]
ALTER TABLE `accounts` ADD INDEX `idx_accnt_parent_id` (`parent_id`);
ALTER TABLE `accounts` ENABLE KEYS;

-- acl_roles_actions
ALTER TABLE `acl_roles_actions` DISABLE KEYS;
-- [added newly]
ALTER TABLE `acl_roles_actions` ADD INDEX `idx_aclrole_action` (`role_id`, `action_id`);
ALTER TABLE `acl_roles_actions` ENABLE KEYS;

-- acl_roles_users
ALTER TABLE `acl_roles_users` DISABLE KEYS;
-- [added newly]
ALTER TABLE `acl_roles_users` ADD INDEX `idx_aclrole_user` (`role_id`, `user_id`);
ALTER TABLE `acl_roles_users` ENABLE KEYS;

-- campaign_log
ALTER TABLE `campaign_log` DISABLE KEYS;
-- [added newly]
ALTER TABLE `campaign_log` ADD INDEX `idx_camp_tracker` (`target_tracker_key`);
-- [added newly]
ALTER TABLE `campaign_log` ADD INDEX `idx_camp_campaign_id` (`campaign_id`);
-- [added newly]
ALTER TABLE `campaign_log` ADD INDEX `idx_camp_more_info` (`more_information`);
ALTER TABLE `campaign_log` ENABLE KEYS;

-- config
ALTER TABLE `config` DISABLE KEYS;
-- [added newly]
ALTER TABLE `config` ADD INDEX `idx_config_cat` (`category`);
ALTER TABLE `config` ENABLE KEYS;

-- contacts
ALTER TABLE `contacts` DISABLE KEYS;
-- [added newly]
ALTER TABLE `contacts` ADD INDEX `idx_cont_assigned` (`assigned_user_id`);
-- [added newly]
ALTER TABLE `contacts` ADD INDEX `idx_cont_email1` (`email1`);
-- [added newly]
ALTER TABLE `contacts` ADD INDEX `idx_cont_email2` (`email2`);
ALTER TABLE `contacts` ENABLE KEYS;

-- emailman
ALTER TABLE `emailman` DISABLE KEYS;
-- [added newly]
ALTER TABLE `emailman` ADD INDEX `idx_eman_campaign_id` (`campaign_id`);
ALTER TABLE `emailman` ENABLE KEYS;

-- emails
ALTER TABLE `emails` DISABLE KEYS;
-- [added newly]
ALTER TABLE `emails` ADD INDEX `idx_email_parent_id` (`parent_id`);




-- [added newly]
ALTER TABLE `emails` ADD INDEX `idx_email_assigned` (`assigned_user_id`, `type`, `status`);
ALTER TABLE `emails` ENABLE KEYS;

-- leads
ALTER TABLE `leads` DISABLE KEYS;
-- [added newly]
ALTER TABLE `leads` ADD INDEX `idx_cont_email1` (`email1`, `deleted`);
-- [added newly]
ALTER TABLE `leads` ADD INDEX `idx_cont_email2` (`email2`, `deleted`);
-- [added newly]
ALTER TABLE `leads` ADD INDEX `idx_lead_assigned` (`assigned_user_id`);
-- [added newly]
ALTER TABLE `leads` ADD INDEX `idx_lead_contact` (`contact_id`);
ALTER TABLE `leads` ENABLE KEYS;

-- notes
ALTER TABLE `notes` DISABLE KEYS;
-- [added newly]
ALTER TABLE `notes` ADD INDEX `idx_notes_parent` (`parent_id`, `parent_type`);
-- [added newly]
ALTER TABLE `notes` ADD INDEX `idx_note_contact` (`contact_id`);
ALTER TABLE `notes` ENABLE KEYS;

-- opportunities
ALTER TABLE `opportunities` DISABLE KEYS;
-- [added newly]
ALTER TABLE `opportunities` ADD INDEX `idx_opp_assigned` (`assigned_user_id`);
ALTER TABLE `opportunities` ENABLE KEYS;















-- tasks
ALTER TABLE `tasks` DISABLE KEYS;
-- [added newly]
ALTER TABLE `tasks` ADD INDEX `idx_task_assigned` (`assigned_user_id`);
ALTER TABLE `tasks` ENABLE KEYS;









--
DELETE FROM `config` WHERE `category` = 'info' AND `name` = 'sugar_version';
INSERT INTO `config` (`category`, `name`, `value`) VALUES ('info', 'sugar_version', '4.2.1');
