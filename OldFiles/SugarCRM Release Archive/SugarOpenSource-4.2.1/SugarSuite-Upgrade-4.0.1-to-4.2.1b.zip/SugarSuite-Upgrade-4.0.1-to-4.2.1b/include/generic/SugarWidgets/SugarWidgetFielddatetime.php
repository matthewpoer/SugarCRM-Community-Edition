<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

require_once('include/JSON.php');
require_once('modules/Users/User.php');

class SugarWidgetFieldDateTime extends SugarWidgetReportField {
	var $reporter;
	var $assigned_user;
	
	// get the reporter attribute
	function getReporter() {
		$this->reporter = $this->layout_manager->getAttribute('reporter');	
	}
	
	// get the assigned user of the report
	function getAssignedUser() {  
		$json_obj = new JSON(JSON_LOOSE_TYPE);
		
		$this->getReporter();
		$report_def_str = $json_obj->decode($this->reporter->report_def_str);
		
		if(empty($report_def_str['assigned_user_id'])) return false;

		$this->assigned_user = new User();
		$this->assigned_user->retrieve($report_def_str['assigned_user_id']);
		return true;
	}
		
	function queryFilterOn(& $layout_def) {
		global $timedate;
		
		if($this->getAssignedUser()) {
			$begin = $timedate->handle_offset($layout_def['input_name0'] . ' 00:00:00', $timedate->get_db_date_time_format(), false, $this->assigned_user);
			$end = $timedate->handle_offset($layout_def['input_name0'] . ' 23:59:59', $timedate->get_db_date_time_format(), false, $this->assigned_user);
		}
		else {
			$begin = $layout_def['input_name0']." 00:00:00";
     		$end = $layout_def['input_name0']." 23:59:59";
		}






			return $this->_get_column_select($layout_def).">='".PearDatabase :: quote($begin)."' AND ".$this->_get_column_select($layout_def)."<='".PearDatabase :: quote($end)."'\n";



	}

	function queryFilterBefore(& $layout_def) {
		global $timedate;
		
		if($this->getAssignedUser()) {
			$begin = $timedate->handle_offset($layout_def['input_name0'] . ' 00:00:00', $timedate->get_db_date_time_format(), false, $this->assigned_user);
		}
		else {
			$begin = $layout_def['input_name0']." 00:00:00";
		}






			return $this->_get_column_select($layout_def)."<'".PearDatabase :: quote($begin)."'\n";




	}

	function queryFilterAfter(& $layout_def) {
		global $timedate;

		if($this->getAssignedUser()) {		
			$begin = $timedate->handle_offset($layout_def['input_name0'] . ' 23:59:59', $timedate->get_db_date_time_format(), false, $this->assigned_user);
		}
		else {
			$begin = $layout_def['input_name0']." 23:59:59";
		}






			return $this->_get_column_select($layout_def).">'".PearDatabase :: quote($begin)."'\n";



	}

	function queryFilterBetween_Dates(& $layout_def) {
		global $timedate;
		
		if($this->getAssignedUser()) {
			$begin = $timedate->handle_offset($layout_def['input_name0'] . ' 00:00:00', $timedate->get_db_date_time_format(), false, $this->assigned_user);
			$end = $timedate->handle_offset($layout_def['input_name1'] . ' 23:59:59', $timedate->get_db_date_time_format(), false, $this->assigned_user);
		}
		else {
			$begin = $layout_def['input_name0']." 00:00:00";
			$end = $layout_def['input_name1']." 23:59:59";
		}






			return "(".$this->_get_column_select($layout_def).">='".PearDatabase :: quote($begin)."' AND \n".$this->_get_column_select($layout_def)."<='".PearDatabase :: quote($end)."')\n";



	}

	function queryFilterNot_Equals_str(& $layout_def) {
		global $timedate;
		
		if($this->getAssignedUser()) {
			$begin = $timedate->handle_offset($layout_def['input_name0'] . ' 00:00:00', $timedate->get_db_date_time_format(), false, $this->assigned_user);
			$end = $timedate->handle_offset($layout_def['input_name0'] . ' 23:59:59', $timedate->get_db_date_time_format(), false, $this->assigned_user);
		}
		else {
			$begin = $layout_def['input_name0']." 00:00:00";
			$end = $layout_def['input_name0']." 23:59:59";
		}






			return "ISNULL(".$this->_get_column_select($layout_def).") OR \n(".$this->_get_column_select($layout_def)."<'".PearDatabase :: quote($begin)."' AND ".$this->_get_column_select($layout_def).">'".PearDatabase :: quote($end)."')\n";




	}

	function queryFilterTP_yesterday(& $layout_def) {
		global $timedate;

		$today = getdate();
		$be = mktime(0, 0, 0, $today['mon'], $today['mday'], $today['year']) - (24 * 60 * 60);
		$ed = mktime(23, 59, 59, $today['mon'], $today['mday'], $today['year']) - (24 * 60 * 60);

		$begin = gmdate('Y-m-d H:i:s', $be);
		$end = gmdate('Y-m-d H:i:s', $ed);

		if($this->getAssignedUser()) {
			$begin = $timedate->handle_offset($begin, $timedate->get_db_date_time_format(), false, $this->assigned_user);
			$end = $timedate->handle_offset($end, $timedate->get_db_date_time_format(), false, $this->assigned_user);
		}

		if ($this->reporter->db->dbType == 'oci8') {









		} else {
			if (isset ($layout_def['rel_field'])) {
				$field_name = "CONCAT(".$this->_get_column_select($layout_def).",' ',".$layout_def['rel_field'].")";
			} else {
				$field_name = $this->_get_column_select($layout_def);
			}
			return $field_name.">='".PearDatabase :: quote($begin)."' AND ".$field_name."<='".PearDatabase :: quote($end)."'\n";
		}
	}
	function queryFilterTP_today(& $layout_def) {
		global $timedate;
		
		$today = getdate();
		$be = mktime(0, 0, 0, $today['mon'], $today['mday'], $today['year']);
		$ed = mktime(23, 59, 59, $today['mon'], $today['mday'], $today['year']);

		$begin = gmdate('Y-m-d H:i:s', $be);
		$end = gmdate('Y-m-d H:i:s', $ed);
		
		if($this->getAssignedUser()) {
			$begin = $timedate->handle_offset($begin, $timedate->get_db_date_time_format(), false, $this->assigned_user);
			$end = $timedate->handle_offset($end, $timedate->get_db_date_time_format(), false, $this->assigned_user);
		}

		if ($this->reporter->db->dbType == 'oci8') {









		} else {
			if (isset ($layout_def['rel_field'])) {
				$field_name = "CONCAT(".$this->_get_column_select($layout_def).",' ',".$layout_def['rel_field'].")";
			} else {
				$field_name = $this->_get_column_select($layout_def);
			}
			return $field_name.">='".PearDatabase :: quote($begin)."' AND ".$field_name."<='".PearDatabase :: quote($end)."'\n";
		}
	}

	function queryFilterTP_tomorrow(& $layout_def) {
		global $timedate;

		$current_date = gmdate('Y-m-d H:i:s', time() + (24 * 60 * 60));
		$current_date = $timedate->to_display_date($current_date);
		$begin = $current_date." 00:00:00";
		$end = $current_date." 23:59:59";

		if($this->getAssignedUser()) {
			$begin = $timedate->handle_offset($begin, $timedate->get_db_date_time_format(), false, $this->assigned_user);
			$end = $timedate->handle_offset($end, $timedate->get_db_date_time_format(), false, $this->assigned_user);
		}

		if ($this->reporter->db->dbType == 'oci8') {



		} else {
			return $this->_get_column_select($layout_def).">='".PearDatabase :: quote($begin)."' AND ".$this->_get_column_select($layout_def)."<='".PearDatabase :: quote($end)."'\n";
		}
	}

	function queryFilterTP_last_7_days(& $layout_def) {
		$this->getReporter();
		
		if ($this->reporter->db->dbType == 'oci8') {



		} else {
			return "LEFT(".$this->_get_column_select($layout_def).",10) BETWEEN LEFT((current_date - interval '7' day),10) AND LEFT(current_date,10)";
		}
	}

	function queryFilterTP_next_7_days(& $layout_def) {
		$this->getReporter();
		





			return "LEFT(".$this->_get_column_select($layout_def).",10) BETWEEN LEFT(current_date,10) AND LEFT((current_date + interval '7' day),10)";



	}

	function queryFilterTP_last_month(& $layout_def) {
		$this->getReporter();
		





			return "LEFT(".$this->_get_column_select($layout_def).",7) = LEFT( (current_date  - interval '1' month),7)";



	}

	function queryFilterTP_this_month(& $layout_def) {
		$this->getReporter();
		





			return "LEFT(".$this->_get_column_select($layout_def).",7) = LEFT( current_date,7)";



	}

	function queryFilterTP_next_month(& $layout_def) {
		$this->getReporter();
		





			return "LEFT(".$this->_get_column_select($layout_def).",7) = LEFT( (current_date  + interval '1' month),7)";



	}

	function queryFilterTP_last_30_days(& $layout_def) {
		if ($this->reporter->db->dbType == 'oci8') {



		}else {
			return $this->_get_column_select($layout_def)." BETWEEN (current_date - interval '1' month) AND (current_date)";
		}
	}

	function queryFilterTP_next_30_days(& $layout_def) {
		if ($this->reporter->db->dbType == 'oci8') {



		}else {
			return $this->_get_column_select($layout_def)." BETWEEN (current_date) AND (current_date + interval '1' month)";
		}
	}

	function queryFilterTP_last_quarter(& $layout_def) {
		//return "LEFT(".$this->_get_column_select($layout_def).",10) BETWEEN (current_date + interval '1' month) AND current_date";
	}

	function queryFilterTP_this_quarter(& $layout_def) {
	}

	function queryFilterTP_last_year(& $layout_def) {
		$this->getReporter();
		





			return "LEFT(".$this->_get_column_select($layout_def).",4) = EXTRACT(YEAR FROM ( current_date  - interval '1' year))";



	}

	function queryFilterTP_this_year(& $layout_def) {
		$this->getReporter();
		





			return "LEFT(".$this->_get_column_select($layout_def).",4) = EXTRACT(YEAR FROM ( current_date ))";



	}

	function queryFilterTP_next_year(& $layout_def) {
		$this->getReporter();
		





			return "LEFT(".$this->_get_column_select($layout_def).",4) = EXTRACT(YEAR FROM ( current_date  + interval '1' year))";



	}

	function queryGroupBy($layout_def) {
		// i guess qualifier and column_function are the same..
		if (!empty ($layout_def['qualifier'])) {
			$func_name = 'queryGroupBy'.$layout_def['qualifier'];
			//print_r($layout_def);
			//print $func_name;
			if (method_exists($this, $func_name)) {
				return $this-> $func_name ($layout_def)." \n";
			}
		}
		return parent :: queryGroupBy($layout_def)." \n";
	}

	function queryOrderBy($layout_def) {
		// i guess qualifier and column_function are the same..
		if (!empty ($layout_def['qualifier'])) {
			$func_name = 'queryGroupBy'.$layout_def['qualifier'];
			if (method_exists($this, $func_name)) {
				return $this-> $func_name ($layout_def)." \n";
			}
		}
		$order_by = parent :: queryOrderBy($layout_def)." \n";
		return $order_by;
	}
    
    function displayListPlain($layout_def) {
        global $timedate;
        
        $content = parent:: displayListPlain($layout_def);
        if(count(explode(' ', $content)) == 2) 
            return $timedate->to_display_date_time($content);
        else 
            return $content;
    }
    
	function displayList($layout_def) {
		global $timedate;
		// i guess qualifier and column_function are the same..
		if (!empty ($layout_def['column_function'])) {
			$func_name = 'displayList'.$layout_def['column_function'];
			if (method_exists($this, $func_name)) {
				return $this-> $func_name ($layout_def)." \n";
			}
		}
		$content = parent :: displayListPlain($layout_def);

		return $timedate->to_display_date_time($content);
	}

	function querySelect(& $layout_def) {
		// i guess qualifier and column_function are the same..
		if (!empty ($layout_def['column_function'])) {
			$func_name = 'querySelect'.$layout_def['column_function'];
			if (method_exists($this, $func_name)) {
				return $this-> $func_name ($layout_def)." \n";
			}
		}
		return parent :: querySelect($layout_def)." \n";
	}
	function & displayListyear(& $layout_def) {
		global $app_list_strings;
		if (preg_match('/(\d{4})/', $this->displayListPlain($layout_def), $match)) {
			return $match[1];
		}
		return '';

	}

	function & displayListmonth(& $layout_def) {
		global $app_list_strings;
		$display = '';
		if (preg_match('/(\d{4})-(\d\d)/', $this->displayListPlain($layout_def), $match)) {
			$match[2] = preg_replace('/^0/', '', $match[2]);
			$display = $app_list_strings['dom_cal_month_long'][$match[2]]." {$match[1]}";
		}
		return $display;

	}
	function querySelectmonth(& $layout_def) {
		$this->getReporter();
		





			return "LEFT( ".$this->_get_column_select($layout_def).",7 ) ".$this->_get_column_alias($layout_def)." \n";



	}

	function queryGroupByMonth($layout_def) {
		$this->getReporter();
		





			return "LEFT(".$this->_get_column_select($layout_def).", 7) \n";



	}

	function querySelectyear(& $layout_def) {
		$this->getReporter();
		





			return "LEFT( ".$this->_get_column_select($layout_def).",4 ) ".$this->_get_column_alias($layout_def)." \n";



	}

	function queryGroupByYear($layout_def) {
		$this->getReporter();
		





			return "LEFT(".$this->_get_column_select($layout_def).", 4) \n";



	}

	function querySelectquarter(& $layout_def) {
		$this->getReporter();
		





			return "CONCAT(LEFT(".$this->_get_column_select($layout_def).", 4), '-', QUARTER(".$this->_get_column_select($layout_def).") )".$this->_get_column_alias($layout_def)."\n";



	}

	function displayListquarter(& $layout_def) {
		if (preg_match('/(\d{4})-(\d)/', $this->displayListPlain($layout_def), $match)) {
			return "Q".$match[2]." ".$match[1];
		}
		return '';

	}

	function queryGroupByQuarter($layout_def) {
		$this->getReporter();
		





			return "CONCAT(LEFT(".$this->_get_column_select($layout_def).", 4), '-', QUARTER(".$this->_get_column_select($layout_def).") )\n";



	}

}
?>

