<?php
global $sugar_version;
if(substr($sugar_version,0,5) == "4.0.1")
{
    if(empty($GLOBALS['sugarEntry']))
        $GLOBALS['sugarEntry'] = true;
}
else if(!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');

}
/**
 * This script executes after the files are copied during the install.
 *
 * LICENSE: The contents of this file are subject to the SugarCRM Professional
 * End User License Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/EULA.  By installing or using this file, You have
 * unconditionally agreed to the terms and conditions of the License, and You
 * may not use this file except in compliance with the License.  Under the
 * terms of the license, You shall not, among other things: 1) sublicense,
 * resell, rent, lease, redistribute, assign or otherwise transfer Your
 * rights to the Software, and 2) use the Software for timesharing or service
 * bureau purposes such as hosting the Software for commercial gain and/or for
 * the benefit of a third party.  Use of the Software may be subject to
 * applicable fees and any use of the Software without first paying applicable
 * fees is strictly prohibited.  You do not have the right to remove SugarCRM
 * copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2005 SugarCRM, Inc.; All Rights Reserved.
 * 

 */
 
require_once('include/utils/file_utils.php');

// fix slot tags on all EditView.html
function fix_slot_tags() {
  $backup_dir = "420_post_install_fix_backups/pre_slot_tag_fix/";
  $cache_dir = create_cache_directory($backup_dir);
  
  $module_dirs = get_module_dir_list();
  foreach($module_dirs as $dir) {
    if(file_exists("modules/$dir/EditView.html")) {
      // read in the contents
      $file = fopen("modules/$dir/EditView.html", 'r');
      $contents = fread($file, filesize("modules/$dir/EditView.html")); 
      fclose($file);

      // search and replace to fix slot tags
      $user_input_pat = '/<slot>(<input.*sqsEnabled.*name\s*=.*assigned_user_name.*\/>)<\/slot>(.*<input.*open_popup\(.*Users.*\/>)/Uis';
      $team_input_pat = '/<slot>(<input.*sqsEnabled.*name\s*=.*team_name.*\/>)<\/slot>(.*<input.*open_popup\(.*Teams.*\/>)/Uis';
      
      if(preg_match($user_input_pat, $contents) || preg_match($team_input_pat, $contents)) {
      // backup the files here!
        create_cache_directory("{$backup_dir}modules/$dir/");
        copy("modules/$dir/EditView.html", "${cache_dir}modules/$dir/EditView.html");	
        $contents = preg_replace(array($user_input_pat, $team_input_pat), array('<slot>${1}${2}</slot>', '<slot>${1}${2}</slot>'), $contents);

        //write file back out
        $file = fopen("modules/$dir/EditView.html", 'w');
        fwrite($file, $contents);
        fclose($file);
      }
    }
  }
  return true; 
}

/**
 * Allows UpgradeWizard to detect and stomp "stock" [Activity]/EditView.html templates that were incorrectly changed.
 * This addresses false positive auto-preserve flags on those template files. Because of the nature of the UW, this will
 * have to do some silly stuff to merge the fixed list with the built skippedFiles list, namely, use GLOBALS! :(
 */
function fixFubarActivitiesEditViewTemplates() {
	global $sugar_flavor;
	global $unzip_dir, $zip_from_dir; // need to find stomper files
	
	if(empty($sugar_flavor)) {
		include('sugar_version.php');
	}
	
	// these md5s are of the modified, but still "stock" EditView.html files
	$modifiedMd5 = array(
		'Calls' => array(
			'OS'	=> '3e75c29c0de2319a89187f09b30b1f52',
			'PRO'	=> 'b39fb4e3dbd48c7f1320f5215a69b297',
			'ENT'	=> 'b9d4e5352eef03ba934bfe6c5733fedd',
		),
		'Meetings' => array(
			'OS'	=> '92ffabadac1bcb9f710efcc99e782fa1',
			'PRO'	=> '0a9794a56a3f8c10a761a0260b14a111',
			'ENT'	=> '060dc0e3b8dc5dbe3bfcd0ec18f25688',
		),
		'Tasks' => array(
			'OS'	=> 'b44b4c2fcb802506831d3d78a19ce467',
			'PRO'	=> 'a151f2d8632fbf1670b87417139d5ae1',
			'ENT'	=> 'e64fe89cba19b1a4feb446ece65aea86',
		)
	);
	
	$modules = array('Calls', 'Meetings', 'Tasks');
	$badSkip = array();
	$skippedFilesFixed = array();
	$zipPath = clean_path($unzip_dir . '/' . $zip_from_dir);

	foreach($modules as $module) {
		$file = clean_path(getcwd()."/modules/{$module}/EditView.html");
		$fileMd5 = md5_file($file);

		if($fileMd5 == $modifiedMd5[$module][$sugar_flavor]) {
			if(in_array($file, $GLOBALS['skippedFiles'])) {
				$badSkip[] = $file;
				if(copy("{$zipPath}/modules/{$module}/EditView.html", $file)) {
					logThis("fixFubarActivitiesEditViewTemplates() replacing incorrectly skipped Activity EditView.html template [ {$file} ]");
				}
			}
		}
	}
	
	// fix the skippedFiles array
	foreach($GLOBALS['skippedFiles'] as $k => $v) {
		if(!in_array($v, $badSkip)) {
			$skippedFilesFixed[$k] = $v;
		}
	}
	
	// reset the skippedFiles array
	$GLOBALS['skippedFiles'] = $skippedFilesFixed;
}


function fix_close_and_create_tag() {
  $backup_dir = "420_post_install_fix_backups/pre_close_and_create_tag_fix/";
  $cache_dir = create_cache_directory($backup_dir);
  $module_dirs = array('Calls', 'Meetings', 'Tasks');
  
  foreach($module_dirs as $dir) {

    if(file_exists("modules/$dir/EditView.html")) {
      // read in the contents
      $file = fopen("modules/$dir/EditView.html", 'r');
      $contents = fread($file, filesize("modules/$dir/EditView.html")); 
      fclose($file);
      
      // This is the pattern for form element we are replacing
      $c_and_c_pat = '/<input title="{APP.LBL_CLOSE_AND_CREATE_BUTTON_TITLE}".*?onclick="(.*?)".*?>/s'; 
      preg_match_all($c_and_c_pat, $contents, $matches);
      
      if($matches[1]) {
         create_cache_directory("{$backup_dir}modules/$dir/");
         copy("modules/$dir/EditView.html", "${cache_dir}modules/$dir/EditView.html");
      
         foreach($matches[1] as $match) {
         	
                 $newString = '<input title="{APP.LBL_CLOSE_AND_CREATE_BUTTON_TITLE}" accessKey="{APP.LBL_CLOSE_AND_CREATE_BUTTON_KEY}" class="button" onclick="';
                 // Need to add method fill_invitees for Meetings and Calls
                 if($dir != 'Tasks') {
                    if(strpos($match, 'fill_invitees();') === false) {
                       $newString .= 'fill_invitees();';
                    } //if
                 }
                 
                 if(strpos($match, 'return check_form(') === false) {
                    $newString .= $match . 'return check_form(\'EditView\');';	
                 } else {
                    $newString .= $match;	
                 }
                   
                 $newString .= '" type="submit" name="button" value="{APP.LBL_CLOSE_AND_CREATE_BUTTON_LABEL}">';  
                   
                  
                 $contents = preg_replace($c_and_c_pat, $newString, $contents);    
                 $file = fopen("modules/$dir/EditView.html", 'w');
                 fwrite($file, $contents);
                 fclose($file);

         } //foreach 
      } //if
      
    }
  }
  return true; 	
} 
 

// apply javascript versioning files that weren't modified, only in folders modules and themes
function apply_js_versioning() {
  $backup_dir = "420_post_install_fix_backups/pre_js_versioning_fix/";
  $cache_dir = create_cache_directory($backup_dir);
  $css_regular_pat = '/(<link[^\/>]*\shref\s*=\s*[\'"].*\.css[^?\'"]*?)([\'"][^\>]*?\/?\>)/Ui'; // matches css links
  $javascript_src_pat = '/(<script[^\/>]*\ssrc\s*=\s*[\'"].*\.js[^?\'"]*?)([\'"][^\>]*?\/?\>)/Ui'; // matches javascript src

  $replacement_pat = '${1}?s={SUGAR_VERSION}&c={JS_CUSTOM_VERSION}${2}';
  $files = array();

  get_files($files, "./modules", '/\.(html|tmpl)$/');

  foreach($files as $the_file) {
    // read in the contents
    $file = fopen($the_file, 'r');
    $contents = fread($file, filesize($the_file)); 
    fclose($file);

    if(preg_match($css_regular_pat, $contents) || preg_match($javascript_src_pat, $contents)) {
      // backup the files here!
      $createDir = $backup_dir;
      $createDir .= substr($the_file, 2, strrpos($the_file, '/'));
      create_cache_directory($createDir);
      copy($the_file, $cache_dir . substr($the_file, 2, strlen($the_file)));
      
      $contents = preg_replace(array($css_regular_pat, $javascript_src_pat), array($replacement_pat, $replacement_pat), $contents);
      
      $file = fopen($the_file, 'w');
      fwrite($file, $contents);
      fclose($file);
    }
  }
  return true;
}

// recursively get all files in a dir with optional matching pattern
function get_files(&$arr, $dir, $pattern = null) { 
  $contents = glob("{$dir}/*"); 
  if(is_array($contents)) {
    foreach($contents as $file) { 
      if(is_dir($file)) {
        get_files($arr, $file, $pattern);
      }
      else {
        if(empty($pattern)) 
          $arr[] = $file;
        else if(preg_match($pattern, $file)) 
          $arr[] = $file;
      }
    }
  }
}


?>
