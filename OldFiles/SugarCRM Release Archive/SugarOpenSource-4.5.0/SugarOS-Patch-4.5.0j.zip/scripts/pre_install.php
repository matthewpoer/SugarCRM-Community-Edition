<?php
global $sugar_version;
if(substr($sugar_version,0,5) == "4.0.1")
{
    if(empty($GLOBALS['sugarEntry']))
    	$GLOBALS['sugarEntry'] = true;
}
else if(!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
    
}
/**
 * This script executes after the files are copied during the install.
 *
 * LICENSE: The contents of this file are subject to the SugarCRM Professional
 * End User License Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/EULA.  By installing or using this file, You have
 * unconditionally agreed to the terms and conditions of the License, and You
 * may not use this file except in compliance with the License.  Under the
 * terms of the license, You shall not, among other things: 1) sublicense,
 * resell, rent, lease, redistribute, assign or otherwise transfer Your
 * rights to the Software, and 2) use the Software for timesharing or service
 * bureau purposes such as hosting the Software for commercial gain and/or for
 * the benefit of a third party.  Use of the Software may be subject to
 * applicable fees and any use of the Software without first paying applicable
 * fees is strictly prohibited.  You do not have the right to remove SugarCRM
 * copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2005 SugarCRM, Inc.; All Rights Reserved.
 * 

 */
if(!defined('SUGARCRM_MIN_MEM')) {
	define('SUGARCRM_MIN_MEM', 32);
}

/**
 * Deprecated when SugarVersion is >=4.5.x
 * copies new UpgradeWizard code to modules dir
 */
function upgradeUw() {
	global $unzip_dir;

	// make sure we have the utils we need
	if(!function_exists('mkdir_recursive')) {
		require_once('include/dir_inc.php');
	}
	if(!function_exists('clean_path')) {
		require_once('include/utils/file_utils.php');
	}

	global $sugar_config;

	if ($sugar_config['dbconfig']['db_type'] == 'mysql')  {

		global $db;

		$q = "SELECT version();";
		$r = $db->query($q);
		$a = $db->fetchByAssoc($r);

		if(version_compare($a['version()'], '4.1.2') < 0){
			die("<br /><br /><b>UpgradeWizard cannot continue: MySQL version 4.1.2 or higher is required to upgrade SugarCRM.</b>");
		}
	}
	
	// mkdir
	mkdir_recursive(clean_path(getcwd().'/include/Pear/Crypt_Blowfish/Blowfish'));
	mkdir_recursive(clean_path(getcwd().'/modules/UpgradeWizard/language'));
	mkdir_recursive(clean_path(getcwd().'/include/Localization'));
	mkdir_recursive(clean_path(getcwd().'/install/language'));

	$zip_from_dir = $_REQUEST['zip_from_dir'];
	$errors = array();

	// force copy the uw_files.php file
	$src = clean_path($unzip_dir.'/'.$zip_from_dir.'/modules/UpgradeWizard/uw_files.php');
	$dest = clean_path(getcwd().'/modules/UpgradeWizard/uw_files.php');
	if(!copy($src, $dest)) {
		$errors[] = $file;
	}

	include('modules/UpgradeWizard/uw_files.php');

	foreach($uw_files as $file) {
		$src = clean_path($unzip_dir.'/'.$zip_from_dir.'/'.$file);
		$dest = clean_path(getcwd().'/'.$file);
		if(!copy($src, $dest)) {
			$errors[] = $file;
		}
	}
	// flag to tell new UpgradeWizard to skip upload step (using current patch zip)
	$_SESSION['UpgradedUpgradeWizard'] = true;
}

/**
 * function is called before installation fully begins during Upgrade process
 */
function pre_install() {
	global $unzip_dir;
	global $sugar_config;
	global $_SESSION;

	$log =& $GLOBALS['log'];
	$self_dir = "$unzip_dir/scripts";

	require_once($self_dir . '/entry_point_scan.php');

	/**
	 * THIS CODE SETS ENTRY POINT PROTECTION
	 */
	set_time_limit(3600);
	$GLOBALS['filesUpdatedCount'] = 0;
	$GLOBALS['totalFileCount'] = 0;
	$GLOBALS['totalDirCount'] = 0;
	$GLOBALS['nonWritableFiles'] = array();
	$GLOBALS['ignoreDirs'] = array('Cache', 'xTemplate', 'test', 'log4php',
		'include/Mail_IMAP', 'include/pclzip', 'include/pdf', 'include/phpmailer',
		'include/Smarty', 'include/TreeView', 'include/Net_URL',
		'include/HTTP_WebDAV_Server', 'include/domit' );

	//echo '<br>Scanning Files...';
	entryPointScan('.', 0, true);
	if(!empty($GLOBALS['nonWritableFiles'])){
		echo '<br><h2>UPDATE COULD NOT START:</h2>the following files need to be writable';
		echo '<pre>';
		print_r($GLOBALS['nonWritableFiles']);
		echo '</pre>';
		sugar_die('Files for modification need to be writable');
	}
	entryPointScan('.', 0, false);
	
	if(!isset($_SESSION['step'])) { // old UpgradeWizard
		if(isset($sugar_config['disc_client']) && $sugar_config['disc_client'] == true){
			$_REQUEST['zip_from_dir'] = 'SugarEnt-Upgrade-4.2.1-to-4.5.0';
		}
		upgradeUw();
		
		/* 
		 * cn: bug 8111 - make sure that redirect goes to same machine, even allowing for dumbass admins who clone their
		 * instances and do not edit config.php (site_url still points to live/active/production instance)
		 * 
		 * redirect to new code
		 */
		
		

		if(isset($sugar_config['disc_client']) && $sugar_config['disc_client'] == true){
			//rrs: hardcoded for now, will try to get from manifest file at a later date
			$_SESSION['sugar_version_file'] = $unzip_dir.'/SugarEnt-Upgrade-4.2.1-to-4.5.0/sugar_version.php';
			global $persistence;
			$persistence['sugar_version_file'] = $_SESSION['sugar_version_file'];
		}else{
			$httpHost		= $_SERVER['HTTP_HOST'];  // cn: 8472 - HTTP_HOST includes port in some cases
			if($colon = strpos($httpHost, ':')) {
				$httpHost	= substr($httpHost, 0, $colon);
			}
			$parsedSiteUrl	= parse_url($sugar_config['site_url']);
			$host			= ($parsedSiteUrl['host'] != $httpHost) ? $httpHost : $parsedSiteUrl['host'];

			// aw: 9721 - use SERVER_PORT for users who don't plug in the site_url at install correctly		
			if ($_SERVER['SERVER_PORT'] != 80){
				$port = ":".$_SERVER['SERVER_PORT'];
			}
			else if (isset($parsedSiteUrl['port']) && $parsedSiteUrl['port'] != 80){
				$port = ":".$parsedSiteUrl['port'];
			}
			else{
				$port = '';
			}			

			$path			= $parsedSiteUrl['path'];
			$cleanUrl		= "{$parsedSiteUrl['scheme']}://{$host}{$port}{$path}/index.php";
			header("Location: {$cleanUrl}?module=UpgradeWizard&action=index&showUpdateWizardMessage=true");
			die(); // end page execution
		}
	}
}
?>
