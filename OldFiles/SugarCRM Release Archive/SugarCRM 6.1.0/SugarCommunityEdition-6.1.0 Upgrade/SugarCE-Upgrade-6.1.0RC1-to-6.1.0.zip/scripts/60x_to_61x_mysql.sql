ALTER TABLE accounts_audit
    ADD INDEX idx_accounts_primary (id);
ALTER TABLE bugs_audit
    ADD INDEX idx_bugs_primary (id);
ALTER TABLE campaigns_audit
    ADD INDEX idx_campaigns_primary (id);
ALTER TABLE cases_audit
    ADD INDEX idx_cases_primary (id);
ALTER TABLE contacts_audit
    ADD INDEX idx_contacts_primary (id);
ALTER TABLE leads_audit
    ADD INDEX idx_leads_primary (id);
ALTER TABLE opportunities_audit
    ADD INDEX idx_opportunities_primary (id);
ALTER TABLE project_task_audit
    ADD INDEX idx_project_task_primary (id);
ALTER TABLE bugs_audit
    ADD INDEX idx_bugs_primary (id);

