<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */



class LabelEditor{
    
    /**
     * Takes in the request params from a save request and processes 
     * them for the save.
     *
     * @param REQUEST params  $params
     */
    function saveLabels($params, $module, $language){
       require_once('include/utils.php');
       $mod_strings = return_module_language($language, $module);
       $dirname = "custom/modules/$module/language";
       $filename = "$dirname/$language.lang.php";
     	$dir_exists = is_dir($dirname);
     	require_once('modules/Administration/Common.php');
    	if(!$dir_exists)$dir_exists = create_module_lang_dir($module);
 		if($dir_exists)
     	{
         	
         	if(is_file($filename)){
        		$contents = file_get_contents($filename);
        	 }else{
         		$contents = "<?PHP\n//Module: $module\n//Language:$language\n";	
        	 }
     	}else{
     		return false;
     	}
       $contents = str_replace("?>", '', $contents);
       $changed = false;
       foreach($params as $key=>$value){
       	 if(substr_count($key, 'label_') == 1 && strcmp($value, 'no_change') != 0){
           	 $key = substr($key, 6);
             if(!isset($mod_strings[$key]) || strcmp($value, $mod_strings[$key]) != 0){
                $pattern_match = '/\s*\$mod_strings\s*\[\s*\''.$key.'\'\s*\]\s*=\s*[\'\"]{1}.*?[\'\"]{1};\s*/ism';
                //out with the old
                $contents = preg_replace($pattern_match, "\n", $contents);
                //in with the new
                $contents .= "\n\$mod_strings['$key']=" . var_export_helper($value) . ";";
                $mod_strings[$key] = $value;
                $changed = true;
             }

        }
    }
 	if($changed){
    	$cache_key = "module_language.".$language.$module;
    	sugar_cache_clear($cache_key);
    	$fp = fopen($filename, 'w');
    	fwrite($fp, $contents);
    	fclose($fp);
    }
    return true;
      
    
    
    
    
    
       
    }
    
    
}


?>
