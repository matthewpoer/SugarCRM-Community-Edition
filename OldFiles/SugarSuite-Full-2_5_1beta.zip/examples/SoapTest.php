<?php
require_once('../include/nusoap/nusoap.php');  //must also have the nusoap code on the ClientSide.
$soapclient = new soapclient('http://localhost/sugarcrm/soap.php');  //define the SOAP Client an
$result = $soapclient->call('get_entry_list',array(array('user_name'=>'admin','password'=>'1b359d8753858b55befa0441067aaed3', 'version'=>'.01'),'module_name'=>'Contacts','query'=>'','order_by'=>'', 'field_value_list'=>array()));
echo '<b>HERE IS ERRORS:</b><BR>';
echo $soapclient->error_str;;

echo '<BR><BR><b>HERE IS RESPONSE:</b><BR>';
echo $soapclient->response;

echo '<BR><BR><b>HERE IS RESULT:</b><BR>';
echo print_r($result);

?>   
