<?PHP
	//returns a list of components that are not of expected version
	function get_invalid_versions(){
		$invalid = array();
		
		require_once('modules/Versions/ExpectedVersions.php');
		require_once('modules/Versions/Version.php');
		foreach($expect_versions as $expect){
			$version = new Version();
			$version->retrieve_by_string_fields(array('name'=>$expect['name']));
			if(!$version->is_expected_version($expect) && !empty($version->name) ){
				$invalid[$expect['name']] = $version->get_profile();
			}
		}
		return $invalid;
	}

?>
