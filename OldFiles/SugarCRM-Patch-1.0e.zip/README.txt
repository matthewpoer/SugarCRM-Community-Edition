******************************
*SugarCRM Summer 2004 Release* 
******************************



Recent Changes:

-------------------------------
1.0e
-------------------------------

Fix: Install process will not save a blank value for disable_persistent_connections.  
Fix: Removed the last occurance of the global variable authenticated_user_id.  
Fix: Case 26 - fixed the mysql_table_name issue by simply removing that code from step 5 of the installer
Fix: Case 25 - new issue.  fixed incorrect tab order in contact edit view.
Fix: Case 24 - new issue.  fixed incorrect tab order in note edit view.
Fix: Case 5 - Client Side Runtime Error in IE
Fix: Case 3 - Client Side Runtime Error in IE


-------------------------------
1.0d
-------------------------------

Fix: Removing some fatal error messages that should not be fatal.
Fix: Fixing printing to work without requiring register globals.
Fix: Fixed printing to work with sessions active
Fix: Removed printing from EditViews (it did not work correctly)
Fix: Fixing notice about authenticated user ID being an undefined variable.

-------------------------------
1.0c
-------------------------------

Fix: Searching for notes, emails, calls, meetings, and tasks (bug #12).  
Fix: The default user can no longer change passwords.  This prevents the demo user from changing their password.
Fix: Implemented code that will allow the administrator to disable MySQL persistent connections if necessary
    It automatically detects the problem and posts this information to all admin users on every page.  Only admin users get the post.  Attempting a persistent DB connection when it is not allowed on every page hit is slow.

-------------------------------
1.0b
-------------------------------

Fix: Account websites with 'http://' prefix that used to be required now breaks URLs
	Any website entered before we changed the format for the URLs now needs to have the 'http://' prefix removed.  This code patch automatically removes this prefix if present.

------------------------------------------------------------------------------------------
1.0a
------------------------------------------------------------------------------------------

Fix: List view entries with blank columns duplicate values
	If any of the columns from the list view are empty, that record's values get the values from the list above. All user's should download this patch to ensure correct list generation.


------------------------------------------------------------------------------------------
Sugar.Sales v1.0
July 4, 2004 

-=Introduction=-
The team at SugarCRM Inc. is pleased to bring you the first major release of SugarCRM Open Source, Sugar.Sales v1.0.  Many months ago,  it become clear to us that people like you want a fast, easy-to-use CRM application that is not only built on the open source technology stack, but is also delivered as open source itself.  The Sugar.Sales application is a result of listening to sales automation users and IT professionals over the past 10 years. We foresee Sugar.Sales, and the full suite of SugarCRM applications we are building over the next year, soon becoming the world's most popular CRM suite.  We hope you agree after using this release of Sugar.Sales.
This first release of Sugar.Sales is best suited for small sales forces.  If you're looking to manage the basics of sales deals where every user can see all of the data in the system, then Sugar.Sales v1.0 is right for you.  Over the next few months, we will be building out Sugar.Sales to meet the needs of larger, multi-national sales forces that need features like forecasting, data access permissions and internationalization.

Also, you can send us an email any time with your feedback at contact@sugarcrm.com.  Our goal is to build the sales automation system that you have always wanted, so your input is vital.

Check out our website at http://www.sugarcrm.com for our latest product roadmap, support forums, detailed product  information and much more.  

Enjoy! 
The Sugar.Team 


-=Included Features=-
An overview of the features in this release. 

Opportunities
Sugar.Sales provides a complete, yet easy-to-use Opportunities module.  From deal size to each contact�s role, from listing the competitors to tracking the lead source, sales reps can easily manage each sales opportunity to completion.  

Accounts & Contacts
With the Accounts & Contacts module, you can easily enter and update key account and contact information. Tracking and staying in touch with your customers is simply a click away. 

Activity & Task Management
Managing your customer interactions is at the heart of a sales automation application. Sugar.Sales provides a simple and clean set of tools for quickly tracking tasks, phone calls, emails and meetings. 

Notes & Attachments
Easily keep notes on every contact, opportunity or account. 

Home Screen 
Focus on the right activities with a quick view of your top opportunities, pipeline, today's appointments and task list.

Dashboard 
A picture is always worth a thousand words.  With the dashboard module, you can graphically view how your opportunities  breakdown by sales stage or industry.

Administration 
Easily manage all the users in the system, their passwords, user interface themes and more. 


-=Future Planned Features=-
What we're working on next. 

Internationalization 
Full support for multi-byte characters, user interface localization and translations, local date and time display. 

Leads
Put standardized processes into practice to make sure all sales reps use the same, consistent lead qualification  methodology. With the click of a button, quickly turn leads into opportunities. With the Sugar.Sales Leads module, you can also easily manage rented lists and prospect data separate from your customer data.

Forecasting
Accurately predict and forecast revenue by territory, product line or indirect channels. 

Sales Teams 
Assign your sales force to territories and sales teams and manage access permissions by teams or territories. 

Accounts & Contacts
Easily sync customer contact information between Sugar.Sales and MS Outlook and Palm devices. 

Activity & Task Management
Plug-ins for PDAs and email applications that deliver a best-in-class open source solution for tracking key customer  information in your PDA quickly and easily.

Notes & Attachments
Ability to enter HTML notes as well as upload file attachments. Also provide for searching across text or HTML notes as  wells a most file attachments.

Dashboard 
More dashboard charts including the ability to customize the charts by time ranges, deal size and more. 

Reports 
An easy-to-customize and easy-to-use reporting tool. 

Administration 
A simple set of tools that anybody can use for adding new fields to forms and changing columns displayed in lists. 

Ownership
Ability to assign an opportunity, account or lead to a user including record access permissions.
