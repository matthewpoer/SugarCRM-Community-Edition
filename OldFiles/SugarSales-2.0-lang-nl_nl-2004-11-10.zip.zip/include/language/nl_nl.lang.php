<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/modules/Accounts/Account.php,v 1.92 2004/11/10 22:27:36 clint Exp $
 * Description:
 ********************************************************************************/

$app_list_strings = array (
  'moduleList' => 
  array (
//to translate, only modify the right value in each key/value pair
    'Home' => 'Home',
//e.g. auf Deutsch 'Contacts'=>'Contakten',
    'Dashboard' => 'Dashboard',
    'Contacts' => 'Contacten',
    'Accounts' => 'Bedrijven',
    'Opportunities' => 'Kansen',
    'Cases' => 'zaken die spelen',
    'Notes' => 'Notities & Bijlagen',
    'Calls' => 'Telefoon Gesprekken',
    'Emails' => 'Emails',
    'Meetings' => 'Afspraken',
    'Tasks' => 'Taken',
    'Calendar' => 'Calendar',
    'Leads' => 'Leads',
    'Activities' => 'Activities',
  ),
  'account_type_dom' => 
  array (
    '' => '',
    'Analyst' => 'Analist',
    'Competitor' => 'Concurrent',
    'Customer' => 'Klant',
    'Integrator' => 'Integrator',
    'Investor' => 'Investeerder',
  //e.g. en fran�ais 'Analyst'=>'Analyste',
    'Partner' => 'Partner',
    'Press' => 'Pers',
    'Prospect' => 'Prospect',
    'Reseller' => 'Wederverkoper',
    'Other' => 'Anders',
  ),
  'industry_dom' => 
  array (
    '' => '',
    'Apparel' => 'Kleding',
    'Banking' => 'Banken',
    'Biotechnology' => 'Biotechnologie',
    'Chemicals' => 'Chemisch',
    'Communications' => 'Communicatie',
  //e.g. en espa�ol 'Apparel'=>'Ropa',
    'Construction' => 'Bouw',
    'Consulting' => 'Advies',
    'Education' => 'Opleiding',
    'Electronics' => 'Electronica',
    'Energy' => 'Energie',
    'Engineering' => 'Engineering',
    'Entertainment' => 'Ontspanning',
    'Environmental' => 'Milieu',
    'Finance' => 'Financieel',
    'Food & Beverage' => 'Levensmiddelen',
    'Government' => 'Overheid',
    'Healthcare' => 'Gezondheidszorg',
    'Hospitality' => 'Ziekenhuizen',
    'Insurance' => 'Verzekering',
    'Machinery' => 'Machines',
    'Manufacturing' => 'Fabricage',
    'Media' => 'Media',
    'Not For Profit' => 'Non Profit',
    'Recreation' => 'Recreatie',
    'Retail' => 'Detailhandel',
    'Shipping' => 'Vervoer',
    'Technology' => 'Technologie',
    'Telecommunications' => 'Telecommunicatie',
    'Transportation' => 'Transport',
    'Utilities' => 'Utiliteit',
    'Other' => 'Anders',
  ),
  'lead_source_dom' => 
  array (
    '' => '',
    'Cold Call' => 'Koude Aquisitie',
    'Existing Customer' => 'Bestaande Klant',
    'Self Generated' => 'Zelf Gegenereerd',
    'Employee' => 'Werknemer',
    'Partner' => 'Partner',
    'Public Relations' => 'Externe Relatie',
    'Direct Mail' => 'Direct Mail',
    'Conference' => 'Conferentie',
    'Trade Show' => 'Beurs',
    'Web Site' => 'Web Site',
    'Word of mouth' => 'Mond op Mond',
    'Other' => 'Anders',
  ),
  'opportunity_type_dom' => 
  array (
    '' => '',
    'Existing Business' => 'Bestaande Business',
    'New Business' => 'Nieuwe Business',
  ),
  'opportunity_relationship_type_default_key' => 'Primary Decision Maker',
  'opportunity_relationship_type_dom' => 
  array (
    '' => '',
    'Primary Decision Maker' => 'Primaire beslisser',
    'Business Decision Maker' => 'Beslisser voor deze kans',
    'Business Evaluator' => 'Evaluator',
    'Technical Decision Maker' => 'Technische beslisser',
//       it is the key for the default opportunity_relationship_type_dom value
    'Technical Evaluator' => 'Technische Evaluator',
    'Executive Sponsor' => 'Belangrijke Sponsor',
    'Influencer' => 'Beinvloeder',
    'Other' => 'Anders',
  ),
  'case_relationship_type_default_key' => 'Primary Contact',
  'case_relationship_type_dom' => 
  array (
    '' => '',
    'Primary Contact' => 'Primaire Contactpersoon',
    'Alternate Contact' => 'Alternatieve Contactpersoon',
  ),
  'sales_stage_dom' => 
//       it is the key for the default case_relationship_type_dom value
  array (
    'Prospecting' => 'Prospecting',
    'Qualification' => 'Kwalificatie',
    'Needs Analysis' => 'Behoefte analyse',
    'Value Proposition' => 'Maken van Propositie',
    'Id. Decision Makers' => 'Identificatie Beslissers',
    'Perception Analysis' => 'Perceptie Analyse',
    'Proposal/Price Quote' => 'Offerte/Prijsvoorstel',
    'Negotiation/Review' => 'Onderhandeling',
    'Closed Won' => 'Gewonnen',
    'Closed Lost' => 'Verloren',
  ),
  'activity_dom' => 
  array (
    'Call' => 'Call',
    'Meeting' => 'Meeting',
    'Task' => 'Task',
    'Email' => 'Email',
    'Note' => 'Note',
  ),
  'salutation_dom' => 
  array (
    '' => '',
    'Mr.' => 'Dhr.',
    'Ms.' => 'Mevr.',
    'Mrs.' => 'Mevr.',
    'Dr.' => 'Dr.',
    'Prof.' => 'Prof.',
  ),
  'task_priority_dom' => 
  array (
    'High' => 'Hoog',
    'Medium' => 'Nomaal',
    'Low' => 'Laag',
  ),
  'task_status_dom' => 
  array (
    'Not Started' => 'Niet Gestart',
    'In Progress' => 'In Behandeling',
    'Completed' => 'Afgerond',
    'Pending Input' => 'Wacht op Input',
    'Deferred' => 'Uitgesteld',
  ),
  'meeting_status_dom' => 
  array (
    'Planned' => 'Genoteerd',
    'Held' => 'Gehouden',
    'Not Held' => 'Niet Gehouden',
  ),
  'call_status_dom' => 
  array (
    'Planned' => 'Genoteerd',
    'Held' => 'Gehouden',
    'Not Held' => 'Niet Gehouden',
  ),
  'call_direction_dom' => 
  array (
    'Inbound' => 'Inbound',
    'Outbound' => 'Outbound',
  ),
  'lead_status_dom' => 
  array (
    '' => '',
    'New' => 'New',
    'Assigned' => 'Assigned',
    'In Process' => 'In Process',
    'Converted' => 'Converted',
    'Recycled' => 'Recycled',
    'Dead' => 'Dead',
  ),
  'lead_status_noblank_dom' => 
  array (
    'New' => 'New',
    'Assigned' => 'Assigned',
    'In Process' => 'In Process',
    'Converted' => 'Converted',
    'Recycled' => 'Recycled',
    'Dead' => 'Dead',
  ),
  'case_status_default_key' => 'New',
  'case_status_dom' => 
  array (
    'New' => 'Nieuw',
    'Assigned' => 'Toegewezen',
    'Closed' => 'Afgesloten',
    'Pending Input' => 'Wacht op Input',
    'Rejected' => 'Afgewezen',
//       it is the key for the default case_status_dom value
  ),
  'case_priority_default_key' => 'P2',
  'case_priority_dom' => 
  array (
    'P1' => 'High',
    'P2' => 'Medium',
    'P3' => 'Low',
  ),
  'user_status_dom' => 
  array (
    'Active' => 'Actief',
    'Inactive' => 'Niet Actief',
  ),
  'record_type_default_key' => 'Accounts',
  'record_type_display' => 
  array (
    'Accounts' => 'Bedrijf',
    'Opportunities' => 'Kansen',
    'Cases' => 'Zaken die spelen',
    'Leads' => 'Lead',
  ),
//       it is the key for the default record_type_module value
  'notifymail_sendtype' => 
  array (
    'sendmail' => 'sendmail',
    'SMTP' => 'SMTP',
  ),
);

$app_strings = array (
  'LBL_CHARSET' => 'ISO-8859-1',
  'LBL_BROWSER_TITLE' => 'SugarCRM - Commercial Open Source CRM',
  'LBL_MY_ACCOUNT' => 'Mijn Account',
  'LBL_ADMIN' => 'Beheer',
  'LBL_LOGOUT' => 'Uitloggen',
  'LBL_SEARCH' => 'Zoeken',
  'LBL_LAST_VIEWED' => 'Laatst bekeken',
  'NTC_WELCOME' => 'Welkom',
  'NTC_SUPPORT_SUGARCRM' => 'Steun het SugarCRM open source project met een donatie via Paypal - snel, gratis en veilig!',
  'NTC_NO_ITEMS_DISPLAY' => 'geen',
  'LBL_ALT_HOT_KEY' => 'Alt+',
  'LBL_SAVE_BUTTON_TITLE' => 'Opslaan [Alt+S]',
  'LBL_EDIT_BUTTON_TITLE' => 'Wijzig [Alt+E]',
  'LBL_EDIT_BUTTON' => 'Wijzig',
  'LBL_DUPLICATE_BUTTON_TITLE' => 'Kopieren [Alt+U]',
  'LBL_DUPLICATE_BUTTON' => 'kopieer',
  'LBL_DELETE_BUTTON_TITLE' => 'Verwijder [Alt+D]',
  'LBL_DELETE_BUTTON' => 'Verwijder',
  'LBL_NEW_BUTTON_TITLE' => 'Niew [Alt+N]',
  'LBL_CHANGE_BUTTON_TITLE' => 'Verander [Alt+G]',
  'LBL_CANCEL_BUTTON_TITLE' => 'Maak ongedaan [Alt+X]',
  'LBL_SEARCH_BUTTON_TITLE' => 'Zoeken [Alt+Q]',
  'LBL_CLEAR_BUTTON_TITLE' => 'Wissen [Alt+C]',
  'LBL_SELECT_BUTTON_TITLE' => 'Selecteer [Alt+T]',
  'LBL_SAVE_BUTTON_KEY' => 'S',
  'LBL_EDIT_BUTTON_KEY' => 'E',
  'LBL_DUPLICATE_BUTTON_KEY' => 'U',
  'LBL_DELETE_BUTTON_KEY' => 'D',
  'LBL_NEW_BUTTON_KEY' => 'N',
  'LBL_CHANGE_BUTTON_KEY' => 'G',
  'LBL_CANCEL_BUTTON_KEY' => 'X',
  'LBL_SEARCH_BUTTON_KEY' => 'Q',
  'LBL_CLEAR_BUTTON_KEY' => 'C',
  'LBL_SELECT_BUTTON_KEY' => 'T',
  'LBL_SAVE_BUTTON_LABEL' => 'Opslaan',
  'LBL_EDIT_BUTTON_LABEL' => 'Wijzig',
  'LBL_DUPLICATE_BUTTON_LABEL' => 'Kopieer',
  'LBL_DELETE_BUTTON_LABEL' => 'Verwijder',
  'LBL_NEW_BUTTON_LABEL' => 'Niew',
  'LBL_CHANGE_BUTTON_LABEL' => 'Verander',
  'LBL_CANCEL_BUTTON_LABEL' => 'Maak ongedaan',
  'LBL_SEARCH_BUTTON_LABEL' => 'Zoeken',
  'LBL_CLEAR_BUTTON_LABEL' => 'Wissen',
  'LBL_NEXT_BUTTON_LABEL' => 'Next',
  'LBL_SELECT_BUTTON_LABEL' => 'Selecteer',
  'LBL_SELECT_CONTACT_BUTTON_TITLE' => 'Selecteer Contact [Alt+T]',
  'LBL_SELECT_CONTACT_BUTTON_KEY' => 'T',
  'LBL_VIEW_PDF_BUTTON_LABEL' => 'View PDF',
  'LBL_VIEW_PDF_CONTACT_BUTTON_TITLE' => 'View PDF [Alt+P]',
  'LBL_VIEW_PDF_CONTACT_BUTTON_KEY' => 'P',
  'LBL_SELECT_CONTACT_BUTTON_LABEL' => 'Selecteer Contact',
  'LBL_SELECT_USER_BUTTON_TITLE' => 'Selecteer Gebruiker [Alt+U]',
  'LBL_SELECT_USER_BUTTON_KEY' => 'U',
  'LBL_SELECT_USER_BUTTON_LABEL' => 'Selecteer Gebruiker',
  'LBL_CREATE_BUTTON_LABEL' => 'Create',
  'LBL_SHORTCUTS' => 'Shortcuts',
  'LBL_LIST_NAME' => 'Naam',
  'LBL_LIST_USER_NAME' => 'Gebruikers Naam',
  'LBL_LIST_EMAIL' => 'Email',
  'LBL_LIST_PHONE' => 'Telefoon',
  'LBL_LIST_CONTACT_NAME' => 'Contact Naam',
  'LBL_LIST_CONTACT_ROLE' => 'Contact Role',
  'LBL_LIST_ACCOUNT_NAME' => 'Bedrijf Naam',
  'LBL_USER_LIST' => 'Gebruikers Lijst',
  'LBL_CONTACT_LIST' => 'Contacten Lijst',
  'LBL_RELATED_RECORDS' => 'Related Records',
  'LBL_MASS_UPDATE' => 'Mass Update',
  'LNK_ADVANCED_SEARCH' => 'Geavanceerd',
  'LNK_BASIC_SEARCH' => 'Normaal',
  'LNK_EDIT' => 'wijzig',
  'LNK_REMOVE' => 'weghalen',
  'LNK_DELETE' => 'verwijder',
  'LNK_LIST_START' => 'Start',
  'LNK_LIST_NEXT' => 'Volgende',
  'LNK_LIST_PREVIOUS' => 'Vorige',
  'LNK_LIST_END' => 'Einde',
  'LBL_LIST_OF' => 'van',
  'LBL_OR' => 'OR',
  'LNK_PRINT' => 'Print',
  'LNK_HELP' => 'Help',
  'LNK_ABOUT' => 'Over Ons',
  'NTC_REQUIRED' => 'Geeft een verplicht veld aan',
  'LBL_REQUIRED_SYMBOL' => '*',
  'LBL_CURRENCY_SYMBOL' => 'Eur',
  'LBL_PERCENTAGE_SYMBOL' => '%',
  'LBL_THOUSANDS_SYMBOL' => 'K',
  'NTC_DATE_FORMAT' => '(jjjj-mm-dd)',
  'NTC_TIME_FORMAT' => '(24:00)',
  'NTC_DATE_TIME_FORMAT' => '(jjjj-mm-dd 24:00)',
  'NTC_DELETE_CONFIRMATION' => 'Weet u zeker dat u dit record wilt verwijderen?',
  'ERR_DELETE_RECORD' => 'Er moet een record nummer zijn gespecificeerd om dit contact te verwijderen.',
  'ERR_CREATING_TABLE' => 'Foutmelding bij het creeeren van een tabel: ',
  'ERR_CREATING_FIELDS' => 'Foutmelding bij het invullen van aanvullende detail velden: ',
  'ERR_MISSING_REQUIRED_FIELDS' => 'Verplichte velden missen:',
  'ERR_INVALID_EMAIL_ADDRESS' => 'Dit is geen geldig email adres.',
  'ERR_INVALID_DATE_FORMAT' => 'Het datum formaat moet zijn: jjjj-mm-dd',
  'ERR_INVALID_MONTH' => 'Voer een geldige maand in a.u.b.',
  'ERR_INVALID_DAY' => 'Voer een geldige maand in a.u.b.Please enter a valid day.',
  'ERR_INVALID_YEAR' => 'Voer een geldig 4 cijferig jaartal in.',
  'ERR_INVALID_DATE' => 'Voer een geldige datum in a.u.b.',
  'ERR_INVALID_HOUR' => 'Voer een geldig uur in a.u.b.',
  'ERR_INVALID_TIME' => 'Voer een geldige tijd in a.u.b.',
  'ERR_INVALID_AMOUNT' => 'Please enter a valid amount.',
  'NTC_CLICK_BACK' => 'Klikt u a..u.b op de [terug] knop in uw browser en los het probleem op.',
  'LBL_LIST_ASSIGNED_USER' => 'Toegewezen aan',
  'LBL_ASSIGNED_TO' => 'Toegewezen aan:',
  'LBL_DATE_MODIFIED' => 'Laatst gewijzigd:',
  'LBL_DATE_ENTERED' => 'Aangemaakt:',
  'LBL_CURRENT_USER_FILTER' => 'Alleen mijn items:',
  'NTC_LOGIN_MESSAGE' => 'Eerst inloggen a.u.b.',
  'LBL_NONE' => '--Geen--',
  'LBL_BACK' => 'Terug',
  'LBL_IMPORT' => 'Importeren',
  'LBL_EXPORT' => 'Exporteren',
  'LBL_EXPORT_ALL' => 'Exporteer Alle',
  'LBL_SAVE_NEW_BUTTON_TITLE' => 'Save & Create New [Alt+V]',
  'LBL_SAVE_NEW_BUTTON_KEY' => 'V',
  'LBL_SAVE_NEW_BUTTON_LABEL' => 'Save & Create New',
  'LBL_NAME' => 'Name',
  'LBL_SUBJECT' => 'Subject',
);


?>