-- MySQL upgrade script for Sugar 4.2.1 to 4.5.1
-- $Id$

--
-- NEW TABLES
--





















-- saved_search
CREATE TABLE `saved_search` (
  `id` char(36) NOT NULL default '',
  `name` varchar(150) default NULL,
  `search_module` varchar(150) default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  `date_entered` datetime NOT NULL default '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL default '0000-00-00 00:00:00',
  `assigned_user_id` char(36) default NULL,



  `contents` text,
  `description` text,
  PRIMARY KEY  (`id`),
  KEY `idx_desc` (`name`,`deleted`)
) DEFAULT CHARSET=utf8;
































-- user_preferences
CREATE TABLE `user_preferences` (
  `id` char(36) NOT NULL default '',
  `category` varchar(50) default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  `date_entered` datetime NOT NULL default '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL default '0000-00-00 00:00:00',
  `assigned_user_id` char(36) NOT NULL default '',
  `contents` text,
  PRIMARY KEY  (`id`),
  KEY `idx_userprefnamecat` (`assigned_user_id`,`category`)
) DEFAULT CHARSET=utf8;




















--
-- CHANGED TABLES
--

-- accounts
ALTER TABLE `accounts` CHANGE COLUMN `description` `description` text NULL;
ALTER TABLE `accounts` ADD COLUMN `campaign_id` char(36) NULL AFTER `deleted`;

-- accounts_audit
ALTER TABLE `accounts_audit` CHANGE COLUMN `before_value_text` `before_value_text` text NULL;
ALTER TABLE `accounts_audit` CHANGE COLUMN `after_value_text` `after_value_text` text NULL;

-- acl_roles
ALTER TABLE `acl_roles` CHANGE COLUMN `description` `description` text NULL;

-- acl_roles_actions
ALTER TABLE `acl_roles_actions` CHANGE COLUMN `access_override` `access_override` int(3) NULL;

-- bugs
ALTER TABLE `bugs` CHANGE COLUMN `description` `description` text NULL;
ALTER TABLE `bugs` CHANGE COLUMN `work_log` `work_log` text NULL;

-- bugs_audit
ALTER TABLE `bugs_audit` CHANGE COLUMN `before_value_text` `before_value_text` text NULL;
ALTER TABLE `bugs_audit` CHANGE COLUMN `after_value_text` `after_value_text` text NULL;

-- calls
ALTER TABLE `calls` CHANGE COLUMN `description` `description` text NULL;

-- campaign_log
ALTER TABLE `campaign_log` ADD COLUMN `marketing_id` char(36) NULL AFTER `more_information`;
ALTER TABLE `campaign_log` CHANGE COLUMN `campaign_id` `campaign_id` char(36) NULL;

-- campaigns
ALTER TABLE `campaigns` ADD COLUMN `impressions` int(11) NULL default '0' AFTER `status`;
ALTER TABLE `campaigns` CHANGE COLUMN `objective` `objective` text NULL;
ALTER TABLE `campaigns` CHANGE COLUMN `content` `content` text NULL;
ALTER TABLE `campaigns` ADD COLUMN `frequency` varchar(25) NULL AFTER `content`;

-- campaigns_audit
ALTER TABLE `campaigns_audit` CHANGE COLUMN `before_value_text` `before_value_text` text NULL;
ALTER TABLE `campaigns_audit` CHANGE COLUMN `after_value_text` `after_value_text` text NULL;

-- cases
ALTER TABLE `cases` DROP COLUMN `account_name`;
ALTER TABLE `cases` CHANGE COLUMN `description` `description` text NULL;
ALTER TABLE `cases` CHANGE COLUMN `resolution` `resolution` text NULL;

-- cases_audit
ALTER TABLE `cases_audit` CHANGE COLUMN `before_value_text` `before_value_text` text NULL;
ALTER TABLE `cases_audit` CHANGE COLUMN `after_value_text` `after_value_text` text NULL;

-- config
ALTER TABLE `config` CHANGE COLUMN `value` `value` text NULL;

-- contacts
ALTER TABLE `contacts` CHANGE COLUMN `description` `description` text NULL;



ALTER TABLE `contacts` ADD COLUMN `campaign_id` char(36) NULL AFTER `invalid_email`;

-- contacts_audit
ALTER TABLE `contacts_audit` CHANGE COLUMN `before_value_text` `before_value_text` text NULL;
ALTER TABLE `contacts_audit` CHANGE COLUMN `after_value_text` `after_value_text` text NULL;
















-- dashboards
ALTER TABLE `dashboards` CHANGE COLUMN `description` `description` text NULL;
ALTER TABLE `dashboards` CHANGE COLUMN `content` `content` text NULL;










-- documents
ALTER TABLE `documents` CHANGE COLUMN `description` `description` text NULL;

-- email_templates
ALTER TABLE `email_templates` CHANGE COLUMN `description` `description` text NULL;
ALTER TABLE `email_templates` CHANGE COLUMN `body` `body` text NULL;
ALTER TABLE `email_templates` CHANGE COLUMN `body_html` `body_html` text NULL;




ALTER TABLE `email_templates` ADD COLUMN `text_only` tinyint(1) default '0' AFTER `deleted`;

-- emails
ALTER TABLE `emails` CHANGE COLUMN `to_addrs` `to_addrs` text NULL, CHANGE COLUMN `cc_addrs` `cc_addrs` text NULL, CHANGE COLUMN `bcc_addrs` `bcc_addrs` text NULL, CHANGE COLUMN `to_addrs_ids` `to_addrs_ids` text NULL, CHANGE COLUMN `to_addrs_names` `to_addrs_names` text NULL, CHANGE COLUMN `to_addrs_emails` `to_addrs_emails` text NULL, CHANGE COLUMN `cc_addrs_ids` `cc_addrs_ids` text NULL, CHANGE COLUMN `cc_addrs_names` `cc_addrs_names` text NULL, CHANGE COLUMN `cc_addrs_emails` `cc_addrs_emails` text NULL, CHANGE COLUMN `bcc_addrs_ids` `bcc_addrs_ids` text NULL, CHANGE COLUMN `bcc_addrs_names` `bcc_addrs_names` text NULL, CHANGE COLUMN `bcc_addrs_emails` `bcc_addrs_emails` text NULL, CHANGE `description` `description` longtext, CHANGE `description_html` `description_html` longtext;
ALTER TABLE `emails` ADD COLUMN `raw_source` longtext NULL AFTER `mailbox_id`;

-- emails_contacts
ALTER TABLE `emails_contacts` ADD COLUMN `campaign_data` text NULL AFTER `date_modified`;

-- emails_leads
ALTER TABLE `emails_leads` ADD COLUMN `campaign_data` text NULL AFTER `date_modified`;

-- emails_prospects
ALTER TABLE `emails_prospects` ADD COLUMN `campaign_data` text NULL AFTER `date_modified`;

-- emails_users
ALTER TABLE `emails_users` ADD COLUMN `campaign_data` text NULL AFTER `date_modified`;

-- feeds
ALTER TABLE `feeds` CHANGE COLUMN `description` `description` text NULL;

-- fields_meta_data
ALTER TABLE `fields_meta_data` ADD COLUMN `help` varchar(255) NULL AFTER `label`;
ALTER TABLE `fields_meta_data` ADD COLUMN `duplicate_merge` smallint(6) NULL default '0' AFTER `mass_update`;
ALTER TABLE `fields_meta_data` CHANGE COLUMN `ext1` `ext1` varchar(255) NULL;
ALTER TABLE `fields_meta_data` CHANGE COLUMN `ext2` `ext2` varchar(255) NULL;
ALTER TABLE `fields_meta_data` CHANGE COLUMN `ext3` `ext3` varchar(255) NULL;
ALTER TABLE `fields_meta_data` ADD COLUMN `ext4` text NULL AFTER `ext3`;









-- inbound_email
ALTER TABLE `inbound_email` CHANGE COLUMN `stored_options` `stored_options` text NULL;

-- leads
ALTER TABLE `leads` CHANGE COLUMN `lead_source_description` `lead_source_description` text NULL;
ALTER TABLE `leads` CHANGE COLUMN `status_description` `status_description` text NULL;
ALTER TABLE `leads` CHANGE COLUMN `description` `description` text NULL;
ALTER TABLE `leads` CHANGE COLUMN `account_description` `account_description` text NULL;

-- leads_audit
ALTER TABLE `leads_audit` CHANGE COLUMN `before_value_text` `before_value_text` text NULL;
ALTER TABLE `leads_audit` CHANGE COLUMN `after_value_text` `after_value_text` text NULL;

-- meetings
ALTER TABLE `meetings` CHANGE COLUMN `description` `description` text NULL;

-- notes
ALTER TABLE `notes` ADD COLUMN `embed_flag` tinyint(1) NOT NULL default '0' AFTER `portal_flag`;
ALTER TABLE `notes` CHANGE COLUMN `description` `description` text NULL;

-- opportunities
ALTER TABLE `opportunities` ADD COLUMN `campaign_id` char(36) NULL AFTER `opportunity_type`;
ALTER TABLE `opportunities` CHANGE COLUMN `description` `description` text NULL;

-- opportunities_audit
ALTER TABLE `opportunities_audit` CHANGE COLUMN `before_value_text` `before_value_text` text NULL;
ALTER TABLE `opportunities_audit` CHANGE COLUMN `after_value_text` `after_value_text` text NULL;





























-- project
ALTER TABLE `project` CHANGE COLUMN `description` `description` text NULL;

-- project_task
ALTER TABLE `project_task` CHANGE COLUMN `description` `description` text NULL;

-- project_task_audit
ALTER TABLE `project_task_audit` CHANGE COLUMN `before_value_text` `before_value_text` text NULL;
ALTER TABLE `project_task_audit` CHANGE COLUMN `after_value_text` `after_value_text` text NULL;

-- prospect_lists
ALTER TABLE `prospect_lists` CHANGE COLUMN `description` `description` text NULL;

-- prospects
ALTER TABLE `prospects` CHANGE COLUMN `description` `description` text NULL;
ALTER TABLE `prospects` ADD COLUMN `campaign_id` char(36) NULL AFTER `account_name`;















-- roles
ALTER TABLE `roles` CHANGE COLUMN `description` `description` text NULL;
ALTER TABLE `roles` CHANGE COLUMN `modules` `modules` text NULL;






-- tasks
ALTER TABLE `tasks` CHANGE COLUMN `description` `description` text NULL;









-- upgrade_history
ALTER TABLE `upgrade_history` ADD COLUMN `name` varchar(255) NULL AFTER `version`;
ALTER TABLE `upgrade_history` ADD COLUMN `description` text NULL AFTER `name`;
ALTER TABLE `upgrade_history` ADD COLUMN `id_name` varchar(255) NULL AFTER `description`;
ALTER TABLE `upgrade_history` ADD COLUMN `manifest` text NULL AFTER `id_name`;

-- users
ALTER TABLE `users` DROP COLUMN `user_password`;
ALTER TABLE `users` CHANGE COLUMN `user_name` `user_name` varchar(60) NULL;
ALTER TABLE `users` ADD COLUMN `authenticate_id` varchar(100) NULL AFTER `user_hash`;
ALTER TABLE `users` ADD COLUMN `sugar_login` tinyint(1) NULL default '1' AFTER `authenticate_id`;
UPDATE `users` SET is_admin = '1' WHERE is_admin = 'on';
UPDATE `users` SET is_admin = '0' WHERE is_admin != '1';
ALTER TABLE `users` CHANGE COLUMN `is_admin` `is_admin` tinyint(1) NULL default '0';
UPDATE `users` SET receive_notifications = '1' WHERE receive_notifications = 'on';
UPDATE `users` SET receive_notifications = '0' WHERE receive_notifications != '1';
ALTER TABLE `users` CHANGE COLUMN `receive_notifications` `receive_notifications` tinyint(1) NULL default '1';
ALTER TABLE `users` CHANGE COLUMN `description` `description` text NULL;
ALTER TABLE `users` CHANGE COLUMN `user_preferences` `user_preferences` text NULL;

-- users_signatures
ALTER TABLE `users_signatures` CHANGE COLUMN `signature` `signature` text NULL;
ALTER TABLE `users_signatures` CHANGE COLUMN `signature_html` `signature_html` text NULL;

-- vcals
ALTER TABLE `vcals` CHANGE COLUMN `content` `content` text NULL;













--
-- INDICES
--














-- documents
ALTER TABLE `documents` DISABLE KEYS;
ALTER TABLE `documents` ADD INDEX `idx_doc_cat` (`category_id`, `subcategory_id`);
ALTER TABLE `documents` ENABLE KEYS;

-- email_marketing_prospect_lists
ALTER TABLE `email_marketing_prospect_lists` DISABLE KEYS;
ALTER TABLE `email_marketing_prospect_lists` ADD INDEX `email_mp_prospects` (`email_marketing_id`, `prospect_list_id`);
ALTER TABLE `email_marketing_prospect_lists` DROP INDEX `idx_realted_id`;
ALTER TABLE `email_marketing_prospect_lists` ENABLE KEYS;

-- emails_project_tasks
ALTER TABLE `emails_project_tasks` DISABLE KEYS;
ALTER TABLE `emails_project_tasks` ADD INDEX `idx_ept_email` (`email_id`);
ALTER TABLE `emails_project_tasks` ADD INDEX `idx_ept_project_task` (`project_task_id`);
ALTER TABLE `emails_project_tasks` DROP INDEX `idx_project_task_email_email`;
ALTER TABLE `emails_project_tasks` DROP INDEX `idx_project_task_email_project_task`;
ALTER TABLE `emails_project_tasks` ENABLE KEYS;

































































-- prospect_lists_prospects
ALTER TABLE `prospect_lists_prospects` DISABLE KEYS;
ALTER TABLE `prospect_lists_prospects` ADD INDEX `idx_plp_pro_id` (`prospect_list_id`);
ALTER TABLE `prospect_lists_prospects` ADD INDEX `idx_plp_rel_id` (`related_id`, `related_type`, `prospect_list_id`);
ALTER TABLE `prospect_lists_prospects` DROP INDEX `idx_pro_id`;
ALTER TABLE `prospect_lists_prospects` DROP INDEX `idx_realted_id`;
ALTER TABLE `prospect_lists_prospects` ENABLE KEYS;

-- roles_users
ALTER TABLE `roles_users` DISABLE KEYS;
ALTER TABLE `roles_users` ADD INDEX `idx_ru_role_id` (`role_id`);
ALTER TABLE `roles_users` ADD INDEX `idx_ru_user_id` (`user_id`);
ALTER TABLE `roles_users` DROP INDEX `idx_role_id`;
ALTER TABLE `roles_users` DROP INDEX `idx_user_id`;
ALTER TABLE `roles_users` ENABLE KEYS;

-- users_feeds
ALTER TABLE `users_feeds` DISABLE KEYS;
ALTER TABLE `users_feeds` ADD INDEX `idx_ud_user_id` (`user_id`, `feed_id`);
ALTER TABLE `users_feeds` DROP INDEX `idx_user_id`;
ALTER TABLE `users_feeds` ENABLE KEYS;

-- users_signatures
ALTER TABLE `users_signatures` DISABLE KEYS;
ALTER TABLE `users_signatures` ADD INDEX `idx_usersig_uid` (`user_id`);
ALTER TABLE `users_signatures` DROP INDEX `idx_user_id`;
ALTER TABLE `users_signatures` ENABLE KEYS;








