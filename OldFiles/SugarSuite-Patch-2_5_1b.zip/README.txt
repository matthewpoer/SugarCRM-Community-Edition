Sugar v2.5.1b
March 14, 2005


-=Overview=-
The 2.5.1 maintenance release is primarily a bug fix release with some 
minor new features.  For a quick overview of the release, check out the
information below.  For more details on bugs fixs, check out the bug tracker
at http://sourceforge.net/tracker/?group_id=107819&atid=648812.

You can send us an email any time with your feedback at
support@sugarcrm.com.  Our goal continues to be to build the customer
relationship management system that you have always wanted, so your
input is vital.

Check out http://www.sugarcrm.com for more details on acquiring Sugar
Professional, the latest product roadmap, support forums, detailed
product information and much more.  We hope you find this a useful tool
for building your business.

Enjoy! 
The Sugar Team 


------------------------------------------------------------------------
2.5.1b
------------------------------------------------------------------------
Fixed: Date/time formatting issues
Fixed: Activities and Calendar issues with Report module
Fixed: Slow query logging variable creation in the config.php file on a clean
install




------------------------------------------------------------------------
2.5.1a
------------------------------------------------------------------------
Fixed: SOAP API issues
Fixed: User customized tabs
Fixed: Miscellaneous security issues
Fixed: E-mail address parsing




------------------------------------------------------------------------
2.5.1
------------------------------------------------------------------------
Fixed: some install checks
Fixed: config.php variables stored in an array
Added: support for email attachments
Added: support for email drafts
Added: admins can define per user what tabs a user can/cannot see

Added: create email template
Added: support for outbound email
Added: quote groups
Added: reorder line items in quotes


Fixed: Some default settings missing from config.php 
Fixed: Clear button in search tag does not work
Fixed: Caching of Query does not let you get out of advanced search

Fixed: not displaying only available tabs in user's Edit Tabs interface
Fixed: events do not show up in calendar if scheduled between 23:00 and 23:59
Fixed: events do not show up in calendar on second day of a 2 day long event
Fixed: custom fields do not work for Cases
Fixed: broken search when searching by assigned user
Fixed: date sorting is wrong for My Upcoming Activities when using different
date formating
Fixed: all dates show up as red for My Upcoming Activities when using
different data formating
Fixed: issues in installer
Fixed: removed beta code
Fixed: PNG images have been optimized
Fixed: "Other" query now works correctly for Opportunity list view
Fixed: Black bars showing up in Pipeline by Month by Outcome graph in
international languages
Added: ability to save search parameters between pages
Added: import capabilities to notes

Fixed: calendar errors in Reports
Fixed: deleting quotes fails
Fixed: graphs now respect team security
