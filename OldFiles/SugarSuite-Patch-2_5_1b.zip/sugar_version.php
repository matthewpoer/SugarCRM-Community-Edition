<?php
	// $Id: sugar_version.php,v 1.31.2.4 2005/03/15 02:18:40 andrew Exp $
	$sugar_version = '2.5.1b';
?>
