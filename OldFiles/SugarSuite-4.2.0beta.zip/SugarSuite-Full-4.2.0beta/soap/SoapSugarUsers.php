<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
require_once('soap/SoapHelperFunctions.php');
require_once('soap/SoapTypes.php');
require_once('modules/Accounts/Account.php');
/*************************************************************************************

THIS IS FOR SUGARCRM USERS


*************************************************************************************/
$disable_date_format = true;
$server->register(
        'login',
        array('user_auth'=>'tns:user_auth', 'application_name'=>'xsd:string'),
        array('return'=>'tns:set_entry_result'),
        $NAMESPACE); 
        
function login($user_auth, $application){
	$error = new SoapError();
	$user = new User();
	$user = $user->retrieve_by_string_fields(array('user_name'=>$user_auth['user_name'],'user_hash'=>$user_auth['password'], 'deleted'=>0, 'status'=>'Active', 'portal_only'=>0) );
	if(!empty($user) && !empty($user->id)){
		session_start();
		global $current_user;
		$current_user = $user;
		$user->loadPreferences();
		$_SESSION['is_valid_session']= true;
		$_SESSION['ip_address'] = $_SERVER['REMOTE_ADDR'];
		$_SESSION['user_id'] = $user->id;
		$_SESSION['type'] = 'user';
		$_SESSION['avail_modules']= get_user_module_list($user);
		login_success();
		return array('id'=>session_id(), 'error'=>$error);	
	}
	$error->set_error('invalid_login');
	return array('id'=>-1, 'error'=>$error);
	
}

//checks if the soap server and client are running on the same machine
$server->register(
        'is_loopback',
        array(),
        array('return'=>'xsd:int'),
        $NAMESPACE); 
        
function is_loopback(){
	if($_SERVER['REMOTE_ADDR'] == $_SERVER['SERVER_ADDR'])
		return 1;
	return 0;
}

/*
this validates the session and starts the session;
*/

function validate_authenticated($session_id){
	session_id($session_id);
	session_start();
	
	if(!empty($_SESSION['is_valid_session']) && $_SESSION['ip_address'] == $_SERVER['REMOTE_ADDR'] && $_SESSION['type'] == 'user'){
		
		global $current_user;
		require_once('modules/Users/User.php');
		$current_user = new User();
		$current_user->retrieve($_SESSION['user_id']);
		login_success();
		return true;	
	}
	
	session_destroy();
	return false;
}

$server->register(
    'seamless_login',
    array('session'=>'xsd:string'),
    array('return'=>'xsd:int'),
    $NAMESPACE);
    
    function seamless_login($session){
    		if(!validate_authenticated($session)){
    			return 0;
    		}
    		$_SESSION['seamless_login'] = true;
    		return 1;
    }

$server->register(
    'get_entry_list',
    array('session'=>'xsd:string', 'module_name'=>'xsd:string', 'query'=>'xsd:string', 'order_by'=>'xsd:string','offset'=>'xsd:int', 'select_fields'=>'tns:select_fields', 'max_results'=>'xsd:int', 'deleted'=>'xsd:int'),
    array('return'=>'tns:get_entry_list_result'),
    $NAMESPACE);

function get_entry_list($session, $module_name, $query, $order_by,$offset, $select_fields, $max_results, $deleted ){
	global  $beanList, $beanFiles; 
	$error = new SoapError();
	if(!validate_authenticated($session)){
		$error->set_error('invalid_login');	
		return array('result_count'=>-1, 'entry_list'=>array(), 'error'=>$error->get_soap_array());
	}
	if(empty($beanList[$module_name])){
		$error->set_error('no_module');	
		return array('result_count'=>-1, 'entry_list'=>array(), 'error'=>$error->get_soap_array());
	}
	global $current_user;
	if(!check_modules_access($current_user, $module_name, 'read')){
		$error->set_error('no_access');	
		return array('result_count'=>-1, 'entry_list'=>array(), 'error'=>$error->get_soap_array());
	}
	if($max_results > 0){
		global $sugar_config;
		$sugar_config['list_max_entries_per_page'] = $max_results;	
	}
	

	$class_name = $beanList[$module_name];
	require_once($beanFiles[$class_name]);
	$seed = new $class_name();
	if(! $seed->ACLAccess('ListView'))
	{
		$error->set_error('no_access');	
		return array('result_count'=>-1, 'entry_list'=>array(), 'error'=>$error->get_soap_array());
	}
	if($query == ''){
		$where = '';
	}
	if($offset == '' || $offset == -1){
		$offset = 0;
	}
	$response = $seed->get_list($order_by, $query, $offset,-1,-1,$deleted);
	
	$list = $response['list'];
	
	
	$output_list = array();

	
	$field_list = array();
	foreach($list as $value)
	{
		
		//$loga->fatal("Adding another account to the list");
		$output_list[] = get_return_value($value, $module_name);
		if(empty($field_list)){
			$field_list = get_field_list($value);	
		}
	}
	
	$output_list = filter_return_list($output_list, $select_fields, $module_name);
	$field_list = filter_field_list($field_list,$select_fields, $module_name);
	$next_offset = $offset + sizeof($output_list);

	return array('result_count'=>sizeof($output_list), 'next_offset'=>$next_offset,'field_list'=>$field_list, 'entry_list'=>$output_list, 'error'=>$error->get_soap_array());
}

$server->register(
    'get_entry',
    array('session'=>'xsd:string', 'module_name'=>'xsd:string', 'id'=>'xsd:string', 'select_fields'=>'tns:select_fields'),
    array('return'=>'tns:get_entry_result'),
    $NAMESPACE);

function get_entry($session, $module_name, $id,$select_fields ){
	return get_entries($session, $module_name, array($id), $select_fields);
}

$server->register(
    'get_entries',
    array('session'=>'xsd:string', 'module_name'=>'xsd:string', 'ids'=>'tns:select_fields', 'select_fields'=>'tns:select_fields'),
    array('return'=>'tns:get_entry_result'),
    $NAMESPACE);

function get_entries($session, $module_name, $ids,$select_fields ){
	global  $beanList, $beanFiles;
	$error = new SoapError();
	$field_list = array();
	$output_list = array();
	if(!validate_authenticated($session)){
		$error->set_error('invalid_login');	
		return array('field_list'=>$field_list, 'entry_list'=>array(), 'error'=>$error->get_soap_array());
	}
	if(empty($beanList[$module_name])){
		$error->set_error('no_module');	
		return array('field_list'=>$field_list, 'entry_list'=>array(), 'error'=>$error->get_soap_array());
	}
	global $current_user;
	if(!check_modules_access($current_user, $module_name, 'read')){
		$error->set_error('no_access');	
		return array('field_list'=>$field_list, 'entry_list'=>array(), 'error'=>$error->get_soap_array());
	}
	
	$class_name = $beanList[$module_name];
	require_once($beanFiles[$class_name]);
	
	//todo can modify in there to call bean->get_list($order_by, $where, 0, -1, -1, $deleted);
	//that way we do not have to call retrieve for each bean
	//perhaps also add a select_fields to this, so we only get the fields we need
	//and not do a select *
	foreach($ids as $id){
		$seed = new $class_name();
	if(! $seed->ACLAccess('DetailView'))
	{
		$error->set_error('no_access');	
		return array('field_list'=>$field_list, 'entry_list'=>array(), 'error'=>$error->get_soap_array());
	}
		$seed->retrieve($id);
		$output_list[] = get_return_value($seed, $module_name);
		
		if(empty($field_list)){
				$field_list = get_field_list($seed);	
				
		}
	}
		
		$output_list = filter_return_list($output_list, $select_fields, $module_name);
		$field_list = filter_field_list($field_list,$select_fields, $module_name);

	return array( 'field_list'=>$field_list, 'entry_list'=>$output_list, 'error'=>$error->get_soap_array());
}
  
$server->register(
    'set_entry',
    array('session'=>'xsd:string', 'module_name'=>'xsd:string',  'name_value_list'=>'tns:name_value_list'),
    array('return'=>'tns:set_entry_result'),
    $NAMESPACE);
    
function set_entry($session,$module_name, $name_value_list){
	global  $beanList, $beanFiles;
	
	$error = new SoapError();
	if(!validate_authenticated($session)){
		$error->set_error('invalid_login');	
		return array('id'=>-1, 'error'=>$error->get_soap_array());
	}
	if(empty($beanList[$module_name])){
		$error->set_error('no_module');	
		return array('id'=>-1, 'error'=>$error->get_soap_array());
	}
	global $current_user;
	if(!check_modules_access($current_user, $module_name, 'write')){
		$error->set_error('no_access');	
		return array('id'=>-1, 'error'=>$error->get_soap_array());
	}
	
	$class_name = $beanList[$module_name];
	require_once($beanFiles[$class_name]);
	$seed = new $class_name();
	
	foreach($name_value_list as $value){
		if($value['name'] == 'id'){
			$seed->retrieve($value['value']);
			break;	
		}
	}
	foreach($name_value_list as $value){
		$seed->$value['name'] = $value['value'];	
	}
	if(! $seed->ACLAccess('Save') || ($seed->deleted == 1  &&  !$seed->ACLAccess('Delete')))
	{
		$error->set_error('no_access');	
		return array('id'=>-1, 'error'=>$error->get_soap_array());
	}
	$seed->save();
	if($seed->deleted == 1){
			$seed->mark_deleted($seed->id);	
	}
	return array('id'=>$seed->id, 'error'=>$error->get_soap_array());
	
}

$server->register(
    'set_entries',
    array('session'=>'xsd:string', 'module_name'=>'xsd:string',  'name_value_lists'=>'tns:name_value_lists'),
    array('return'=>'tns:set_entries_result'),
    $NAMESPACE);
    
function set_entries($session,$module_name, $name_value_lists){
	global  $beanList, $beanFiles;
	
	$error = new SoapError();
	if(!validate_authenticated($session)){
		$error->set_error('invalid_login');	
		return array('ids'=>array(), 'error'=>$error->get_soap_array());
	}
	if(empty($beanList[$module_name])){
		$error->set_error('no_module');	
		return array('ids'=>array(), 'error'=>$error->get_soap_array());
	}
	global $current_user;
	if(!check_modules_access($current_user, $module_name, 'write')){
		$error->set_error('no_access');	
		return array('ids'=>-1, 'error'=>$error->get_soap_array());
	}
	
	$class_name = $beanList[$module_name];
	require_once($beanFiles[$class_name]);
	$ids = array();
	$count = 1;
	$total = sizeof($name_value_lists);
	foreach($name_value_lists as $name_value_list){
		$seed = new $class_name();
	
		$seed->update_vcal = false;
		foreach($name_value_list as $value){
			$seed->$value['name'] = $value['value'];
		}
		if($count == $total){
			$seed->update_vcal = false;	
		}
		$count++;
		
		//Add the account to a contact
		if($module_name == 'Contacts'){
			$GLOBALS['log']->debug('Creating Contact Account');
			add_create_account(&$seed);
			$duplicate_id = check_for_duplicate_contacts(&$seed);
			if($duplicate_id == null){
				if( $seed->ACLAccess('Save')){
					$seed->save();
					if($seed->deleted == 1){
						$seed->mark_deleted($seed->id);	
					}
					$ids[] = $seed->id;
				}
			}
			else{
				//since we found a duplicate we should set the sync flag
				if( $seed->ACLAccess('Save')){
					$seed->id = $duplicate_id;
					$seed->save();
					$ids[] = $duplicate_id;//we have a conflict	
				}
			}
		}
		else if($module_name == 'Meetings' || $module_name == 'Calls'){
			//we are going to check if we have a meeting in the system
			//with the same outlook_id. If we do find one then we will grab that 
			//id and save it
			if( $seed->ACLAccess('Save')){
				if(empty($seed->id) && !isset($seed->id)){
					if(!empty($seed->outlook_id) && isset($seed->outlook_id)){
						//at this point we have an object that does not have
						//the id set, but does have the outlook_id set
						//so we need to query the db to find if we already
						//have an object with this outlook_id, if we do
						//then we can set the id, otherwise this is a new object
						$order_by = "";
						$query = $seed->table_name.".outlook_id = '".$seed->outlook_id."'";
						$response = $seed->get_list($order_by, $query, 0,-1,-1,0);
						$list = $response['list'];
						if(count($list) > 0){
							foreach($list as $value)
							{
								$seed->id = $value['id'];
								break;
							}
						}//fi
					}//fi
				}//fi
				$seed->save();
				$ids[] = $seed->id;
			}//fi
		}
		else
		{
			if( $seed->ACLAccess('Save')){
				$seed->save();
				$ids[] = $seed->id;
			}
		}
	}
	return array('ids'=>$ids, 'error'=>$error->get_soap_array());
	
}
/*

NOTE SPECIFIC CODE
*/
$server->register(
        'set_note_attachment',
        array('session'=>'xsd:string','note'=>'tns:note_attachment'),
        array('return'=>'tns:set_entry_result'),
        $NAMESPACE);  

function set_note_attachment($session,$note)
{
	
	$error = new SoapError();
	if(!validate_authenticated($session)){
		$error->set_error('invalid_login');	
		return array('id'=>-1, 'error'=>$error->get_soap_array());
	}
	
	require_once('modules/Notes/NoteSoap.php');
	$ns = new NoteSoap();
	return array('id'=>$ns->saveFile($note), 'error'=>$error->get_soap_array());

}

$server->register(
    'get_note_attachment',
    array('session'=>'xsd:string', 'id'=>'xsd:string'),
    array('return'=>'tns:return_note_attachment'),
    $NAMESPACE);

function get_note_attachment($session,$id)
{
	$error = new SoapError();
	if(!validate_authenticated($session)){
		$error->set_error('invalid_login');	
		return array('result_count'=>-1, 'entry_list'=>array(), 'error'=>$error->get_soap_array());
	}
	require_once('modules/Notes/Note.php');
	$note = new Note();

	$note->retrieve($id);
	if(!$note->ACLAccess('DetailView')){
		$error->set_error('no_access');	
		return array('result_count'=>-1, 'entry_list'=>array(), 'error'=>$error->get_soap_array());
	}
	require_once('modules/Notes/NoteSoap.php');
	$ns = new NoteSoap();
	if(!isset($note->filename)){
		$note->filename = '';
	}
	$file= $ns->retrieveFile($id,$note->filename);
	if($file == -1){
		$error->set_error('no_file');
		$file = '';
	}

	return array('note_attachment'=>array('id'=>$id, 'filename'=>$note->filename, 'file'=>$file), 'error'=>$error->get_soap_array());

}
$server->register(
    'relate_note_to_module',
    array('session'=>'xsd:string', 'note_id'=>'xsd:string', 'module_name'=>'xsd:string', 'module_id'=>'xsd:string'),
    array('return'=>'tns:error_value'),
    $NAMESPACE);

function relate_note_to_module($session,$note_id, $module_name, $module_id){
	global  $beanList, $beanFiles;
	$error = new SoapError();
	if(!validate_authenticated($session)){
		$error->set_error('invalid_login');	
		return $error->get_soap_array();
	}
	if(empty($beanList[$module_name])){
		$error->set_error('no_module');	
		return $error->get_soap_array();
	}
	global $current_user;
	if(!check_modules_access($current_user, $module_name, 'read')){
		$error->set_error('no_access');	
		return $error->get_soap_array();
	}
	$class_name = $beanList['Notes'];
	require_once($beanFiles[$class_name]);
	$seed = new $class_name();
	$seed->retrieve($note_id);
	if(!$seed->ACLAccess('ListView')){
		$error->set_error('no_access');	
		return array('result_count'=>-1, 'entry_list'=>array(), 'error'=>$error->get_soap_array());
	}
	
	if($module_name != 'Contacts'){
		$seed->parent_type=$module_name;
		$seed->parent_id = $module_id;
		
	}else{
		
		$seed->contact_id=$module_id;

	}
	
	$seed->save();
	
	return $error->get_soap_array();
	
}
$server->register(
    'get_related_notes',
    array('session'=>'xsd:string', 'module_name'=>'xsd:string', 'module_id'=>'xsd:string', 'select_fields'=>'tns:select_fields'),
    array('return'=>'tns:get_entry_result'),
    $NAMESPACE);
    
function get_related_notes($session,$module_name, $module_id, $select_fields){
	global  $beanList, $beanFiles;
	$error = new SoapError();
	if(!validate_authenticated($session)){
		$error->set_error('invalid_login');	
		return array('result_count'=>-1, 'entry_list'=>array(), 'error'=>$error->get_soap_array());
	}
	if(empty($beanList[$module_name])){
		$error->set_error('no_module');	
		return array('result_count'=>-1, 'entry_list'=>array(), 'error'=>$error->get_soap_array());
	}
	global $current_user;
	if(!check_modules_access($current_user, $module_name, 'read')){
		$error->set_error('no_access');	
		return array('result_count'=>-1, 'entry_list'=>array(), 'error'=>$error->get_soap_array());
	}
	
	$class_name = $beanList[$module_name];
	require_once($beanFiles[$class_name]);
	$seed = new $class_name();
	$seed->retrieve($module_id);
	if(!$seed->ACLAccess('DetailView')){
		$error->set_error('no_access');	
		return array('result_count'=>-1, 'entry_list'=>array(), 'error'=>$error->get_soap_array());
	}
	$list = $seed->get_linked_beans('notes','Note', array(), 0, -1, 0);
	

	
	
	$output_list = Array();
	$field_list = Array();
	foreach($list as $value)
	{
		
		//$loga->fatal("Adding another account to the list");
		$output_list[] = get_return_value($value, 'Notes');
	if(empty($field_list)){
			$field_list = get_field_list($value);	
		}
	}
	$output_list = filter_return_list($output_list, $select_fields, $module_name);
	$field_list = filter_field_list($field_list,$select_fields, $module_name);
	

	return array('result_count'=>sizeof($output_list), 'next_offset'=>0,'field_list'=>$field_list, 'entry_list'=>$output_list, 'error'=>$error->get_soap_array());
}

$server->register(
        'logout',
        array('session'=>'xsd:string'),
        array('return'=>'tns:error_value'),
        $NAMESPACE); 
        
function logout($session){
	$error = new SoapError();
	if(validate_authenticated($session)){
		session_destroy();
		return $error->get_soap_array();
	}
	$error->set_error('no_session');
	return $error->get_soap_array();
}

$server->register(
    'get_module_fields',
    array('session'=>'xsd:string', 'module_name'=>'xsd:string'),
    array('return'=>'tns:module_fields'),
    $NAMESPACE);

function get_module_fields($session, $module_name){
	global  $beanList, $beanFiles;
	$error = new SoapError();
	$module_fields = array();
	if(! validate_authenticated($session)){
		$error->set_error('invalid_session');	
		return array('module_fields'=>$module_fields, 'error'=>$error->get_soap_array());
	}
	if(empty($beanList[$module_name])){
		$error->set_error('no_module');	
		return array('module_fields'=>$module_fields, 'error'=>$error->get_soap_array());
	}
	global $current_user;
	if(!check_modules_access($current_user, $module_name, 'read')){
		$error->set_error('no_access');	
		return array('module_fields'=>$module_fields, 'error'=>$error->get_soap_array());
	}
	$class_name = $beanList[$module_name];
	require_once($beanFiles[$class_name]);
	$seed = new $class_name();
	if($seed->ACLAccess('ListView', true) || $seed->ACLAccess('DetailView', true) || 	$seed->ACLAccess('EditView', true) )
{
	return get_return_module_fields($seed, $module_name, $error);
}else{
	$error->set_error('no_access');	
	return array('module_fields'=>$module_fields, 'error'=>$error->get_soap_array());
}
}

$server->register(
    'get_available_modules',
    array('session'=>'xsd:string'),
    array('return'=>'tns:module_list'),
    $NAMESPACE);
    
function get_available_modules($session){
	$error = new SoapError();
	$modules = array();
	if(! validate_authenticated($session)){
		$error->set_error('invalid_session');	
		return array('modules'=> $modules, 'error'=>$error->get_soap_array());
	}
	$modules = array_keys($_SESSION['avail_modules']);
	
	return array('modules'=> $modules, 'error'=>$error->get_soap_array());
		
}










$server->register(
    'update_portal_user',
    array('session'=>'xsd:string', 'portal_name'=>'xsd:string', 'name_value_list'=>'tns:name_value_list'),
    array('return'=>'tns:error_value'),
    $NAMESPACE);
function update_portal_user($session,$portal_name, $name_value_list){
	global  $beanList, $beanFiles;
	$error = new SoapError();
	if(! validate_authenticated($session)){
		$error->set_error('invalid_session');	
		return $error->get_soap_array();
	}
	$contact = new Contact();
	
	$searchBy = array('deleted'=>0);
	foreach($name_value_list as $name_value){
			$searchBy[$name_value['name']] = $name_value['value'];
	}
	if($contact->retrieve_by_string_fields($searchBy) != null){
		if(!$contact->duplicates_found){
			$contact->portal_name = $portal_name;
			$contact->portal_active = 1;
			if($contact->ACLAccess('Save')){
				$contact->save();
			}else{
				$error->set_error('no_access');
			}
			return $error->get_soap_array();
		}	
		$error->set_error('duplicates');
		return $error->get_soap_array();
	}
	$error->set_error('no_records');
	return $error->get_soap_array();
	
	
}

$server->register(
    'test',
    array('string'=>'xsd:string'),
    array('return'=>'xsd:string'),
    $NAMESPACE);
function test($string){
	return $string;	
}

$server->register(
    'get_user_id',
    array('session'=>'xsd:string'),
    array('return'=>'xsd:string'),
    $NAMESPACE);
function get_user_id($session){
	if(validate_authenticated($session)){
		global $current_user;
		return $current_user->id;
		
	}else{
		return '-1';	
	}
}

$server->register(
    'get_user_team_id',
    array('session'=>'xsd:string'),
    array('return'=>'xsd:string'),
    $NAMESPACE);
function get_user_team_id($session){
	if(validate_authenticated($session)){





		 return 1;



	}else{
		return '-1';	
	}
}

$server->register(
    'get_server_time',
    array(),
    array('return'=>'xsd:string'),
    $NAMESPACE);
    
function get_server_time(){
	return date('Y-m-d H:i:s');
}

$server->register(
    'get_gmt_time',
    array(),
    array('return'=>'xsd:string'),
    $NAMESPACE);
    
function get_gmt_time(){
	return gmdate('Y-m-d H:i:s');
}

$server->register(
    'get_server_version',
    array(),
    array('return'=>'xsd:string'),
    $NAMESPACE);
    
function get_server_version(){
	require_once('modules/Administration/Administration.php');
	$admin  = new Administration();
	$admin->retrieveSettings('info');
	if(isset($admin->settings['info_sugar_version'])){
		return $admin->settings['info_sugar_version'];
	}else{
		return '1.0';	
	} 
	
}

$server->register(
    'get_relationships',
    array('session'=>'xsd:string', 'module_name'=>'xsd:string', 'module_id'=>'xsd:string', 'related_module'=>'xsd:string', 'related_module_query'=>'xsd:string', 'deleted'=>'xsd:int'),
    array('return'=>'tns:get_relationships_result'),
    $NAMESPACE);

function get_relationships($session, $module_name, $module_id, $related_module, $related_module_query, $deleted){
		$error = new SoapError();
	$ids = array();	
	if(!validate_authenticated($session)){
		$error->set_error('invalid_login');	
		return array('ids'=>$ids,'error'=> $error->get_soap_array());
	}
	global  $beanList, $beanFiles;
	$error = new SoapError();
	
	if(empty($beanList[$module_name]) || empty($beanList[$related_module])){
		$error->set_error('no_module');	
		return array('ids'=>$ids, 'error'=>$error->get_soap_array());
	}
	$class_name = $beanList[$module_name];
	require_once($beanFiles[$class_name]);
	$mod = new $class_name();
	$mod->retrieve($module_id);
	if(!$mod->ACLAccess('DetailView')){
		$error->set_error('no_access');	
		return array('ids'=>$ids, 'error'=>$error->get_soap_array());
	}
	$list = array();
	switch($module_name){
		case 'Contacts':
			switch($related_module){
				case 'Calls':
					$list = $mod->get_linked_beans('calls','Call', array(),  0, -1, $deleted);
					break;
				case 'Meetings':
					$list = $mod->get_linked_beans('meetings','Meeting',  array(),  0, -1, $deleted);
					break;
				case 'Users':
					$list = $mod->get_linked_beans('user_sync','User',  array(),  0, -1, $deleted); 
			}
			break;
		case 'Users':
			switch($related_module){
				case 'Calls':
					$list = $mod->get_linked_beans('calls','Call',  array(),  0, -1, $deleted);
					break;
				case 'Meetings':
					$list = $mod->get_linked_beans('meetings','Meeting',  array(),  0, -1, $deleted);
					break;
				case 'Contacts':
					$list = $mod->get_linked_beans('contacts_sync','Contact',  array(),  0, -1, $deleted);
					
			}
			break;
		case 'Meetings':
			switch($related_module){
				case 'Contacts':
					$list = $mod->get_linked_beans('contacts','Contact',  array(),  0, -1, $deleted);
					break;
				case 'Users':
					$list = $mod->get_linked_beans('users','User',  array(),  0, -1, $deleted);				
					break;
			}
			break;
		case 'Calls':
			switch($related_module){
				case 'Contacts':
					$list = $mod->get_linked_beans('contacts','Contact',  array(),  0, -1, $deleted);
					break;
				case 'Users':
					$list = $mod->get_linked_beans('users','User',  array(),  0, -1, $deleted);				
					break;
			}
		case  'Accounts':
			switch($related_module){
				case 'Contacts':
					$list = $mod->get_linked_beans('contacts','Contact',  array(),  0, -1, $deleted);
					break;
				case 'Users':
					$list = $mod->get_linked_beans('users','User',  array(),  0, -1, $deleted);				
					break;
			}
			break;

		
		
	}
	$in = '';
	foreach($list as $item){
		if(empty($in)){
			$in .= "('" . $item->id ."'";	
		}else{
			$in .= ",'" . $item->id ."'";		
		}
		$ids[] = array('id'=>$item->id, 'date_modified'=>$item->date_modified, 'deleted'=>$item->deleted);
	}

	if(!empty($in) && !empty($related_module_query)){
		$in .=")";
		$ids = array();
		$class_name = $beanList[$related_module];
		require_once($beanFiles[$class_name]);
		$r_mod = new $class_name();
		$result = $r_mod->db->query("SELECT id, date_modified FROM " .$r_mod->table_name . " WHERE id IN $in AND ( $related_module_query )");
		while($row = $r_mod->db->fetchByAssoc($result)){
			$ids[] = array('id'=>$row['id'] , 'date_modified'=>$row['date_modified'], 'deleted'=>$row['deleted']);
		}
	}
	

	return array('ids'=>$ids, 'error'=> $error->get_soap_array());
}


$server->register(
    'set_relationship',
    array('session'=>'xsd:string','set_relationship_value'=>'tns:set_relationship_value'),
    array('return'=>'tns:error_value'),
    $NAMESPACE);
    
function set_relationship($session, $set_relationship_value){
	$error = new SoapError();
	if(!validate_authenticated($session)){
		$error->set_error('invalid_login');	
		return $error->get_soap_array();
	}
	return handle_set_relationship($set_relationship_value);
}

$server->register(
    'set_relationships',
    array('session'=>'xsd:string','set_relationship_list'=>'tns:set_relationship_list'),
    array('return'=>'tns:set_relationship_list_result'),
    $NAMESPACE);
    
function set_relationships($session, $set_relationship_list){
	$error = new SoapError();
	if(!validate_authenticated($session)){
		$error->set_error('invalid_login');	
		return -1;
	}
	$count = 0;
	$failed = 0;
	foreach($set_relationship_list as $set_relationship_value){
		$reter = handle_set_relationship($set_relationship_value);
		if($reter['number'] == 0){
			$count++;	
		}else{
			$failed++;
		}
	}
	return array('created'=>$count , 'failed'=>$failed, 'error'=>$error);
}



//INTERNAL FUNCTION NOT EXPOSED THROUGH SOAP
function handle_set_relationship($set_relationship_value)
{
    global  $beanList, $beanFiles;
    $error = new SoapError();
    
    $module1 = $set_relationship_value['module1'];
    $module1_id = $set_relationship_value['module1_id'];
    $module2 = $set_relationship_value['module2'];
    $module2_id = $set_relationship_value['module2_id'];    
    
    if(empty($beanList[$module1]) || empty($beanList[$module2]) )
    {
        $error->set_error('no_module');    
        return $error->get_soap_array();
    }
    $class_name = $beanList[$module1];
    require_once($beanFiles[$class_name]);
    $mod = new $class_name();
    $mod->retrieve($module1_id);
	if(!$mod->ACLAccess('DetailView')){
		$error->set_error('no_access');	
		return $error->get_soap_array();
	}
	if($module1 == "Contacts" && $module2 == "Users"){
		$key = 'contacts_users_id';
	}
	else{
    	$key = array_search(strtolower($module2),$mod->relationship_fields);
	}
	
    if(!$key)
    {
        $error->set_error('no_module');    
        return $error->get_soap_array();    
    }
    $mod->$key = $module2_id;    
    $mod->save_relationship_changes(false);
    return $error->get_soap_array();    
    
}


$server->register(
        'set_document_revision',
        array('session'=>'xsd:string','note'=>'tns:document_revision'),
        array('return'=>'tns:set_entry_result'),
        $NAMESPACE);  

function set_document_revision($session,$document_revision)
{
	
	$error = new SoapError();
	if(!validate_authenticated($session)){
		$error->set_error('invalid_login');	
		return array('id'=>-1, 'error'=>$error->get_soap_array());
	}
	
	require_once('modules/Documents/DocumentSoap.php');
	$dr = new DocumentSoap();
	return array('id'=>$dr->saveFile($document_revision), 'error'=>$error->get_soap_array());

}





?>
