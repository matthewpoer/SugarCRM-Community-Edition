<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Andre L L Dantas (alld@sourceforge) from Visuelles Informatica.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Import/language/en_us.lang.php,v 1.2 2004/09/08 17:41:40 sugarrob Exp $
 * Description:  Defines the English language pack for the Account module.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/
/* 
'LBL_GO_TO_BUTTON_TITLE'=>'V� ao Passo 2',
'LBL_IMPORT_MODULE_SELECT_DELIMITER'=>'Selecione Delimitador',
'LBL_IMPORT_MODULE_COMMA_CSV'=>'V�rgula (CSV)',
'LBL_IMPORT_MODULE_TAB'=>'Tab',
'LBL_IMPORT_MODULE_CUSTOM'=>'Customizado:',
'LBL_IMPORT_MODULE_ERROR_NO_UPLOAD'=>'Arquivo N�O foi carregado com sucesso, tente novamente',
'LBL_IMPORT_MODULE_ERROR_LARGE_FILE'=>'Arquivo � muito grande. M�ximo:',
'LBL_IMPORT_MODULE_ERROR_LARGE_FILE_END'=>'Bytes',
'LBL_IMPORT_MODULE_ERROR'=>'Erro:',
'LBL_IMPORT_MODULE_ERROR_MULTIPLE'=>'M�ltipas colunas foram definidas com o mesmo nome de campo.',
'LBL_IMPORT_MODULE_ERROR_DELIMITER_NOT'=>'Delimitador n�o foi definido.',
'LBL_IMPORT_MODULE_ERROR_CANT_OPEN'=>'Arquivo n�o pode ser aberto.',
'LBL_IMPORT_MODULE_STEP_1_TITLE'=>'Passo 1: Arquivo carregado',
'LBL_IMPORT_MODULE_STEP_2_TITLE'=>'Passo 2: Selecionar mapeamento de campos',
*/



$mod_strings = Array(
'LBL_MODULE_NAME'=>'Importar',
'LBL_TRY_AGAIN'=>'Tente novamente',
'LBL_ERROR'=>'Erro:',
'ERR_MULTIPLE'=>'M�ltiplas colunas foram definidas com o mesmo nome de campo.',
'ERR_MISSING_REQUIRED_FIELDS'=>'Faltam campos requeridos:',
'ERR_SELECT_FULL_NAME'=>'Voc� n�o pode selecionar Nome Completo quando Primeiro Nome e Sobrenome est�o selecionados.',
'ERR_SELECT_FILE'=>'Selecione um arquivo para carregar (subir).',
'LBL_SELECT_FILE'=>'Selecione arquivo:',
'LBL_CUSTOM'=>'Customizar',
'LBL_DONT_MAP'=>'-- N�o mapeie este campo --',
'LBL_STEP_1_TITLE'=>'Passo 1: Selecionar a Fonte',
'LBL_WHAT_IS'=>'Qual � a fonte de dados?',
'LBL_MICROSOFT_OUTLOOK'=>'Microsoft Outlook',
'LBL_ACT'=>'Act!',
'LBL_SALESFORCE'=>'Salesforce.com',
'LBL_MY_SAVED'=>'Minhas Fontes Salvos:',
'LBL_PUBLISH'=>'publicar',
'LBL_DELETE'=>'excluir',
'LBL_PUBLISHED_SOURCES'=>'Fontes Publicadas:',
'LBL_UNPUBLISH'=>'n�o publicadas',
'LBL_NEXT'=>'Pr�ximo >',
'LBL_BACK'=>'< Anterior',
'LBL_STEP_2_TITLE'=>'Passo 2: Carregar Arquivo Exportado',
'LBL_HAS_HEADER'=>'Tem cabe�alhos:',

'LBL_NUM_1'=>'1.',
'LBL_NUM_2'=>'2.',
'LBL_NUM_3'=>'3.',
'LBL_NUM_4'=>'4.',
'LBL_NUM_5'=>'5.',
'LBL_NUM_6'=>'6.',
'LBL_NUM_7'=>'7.',
'LBL_NUM_8'=>'8.',
'LBL_NUM_9'=>'9.',
'LBL_NUM_10'=>'10.',
'LBL_NUM_11'=>'11.',
'LBL_NUM_12'=>'12.',
'LBL_NOW_CHOOSE'=>'Agora escolha o arquivo a importar:',
'LBL_IMPORT_OUTLOOK_TITLE'=>'Microsoft Outlook 98 e 2000 podem exportar dados no formato de <b>Valores Separados por V�rgula</b> (CSV:Comma Separated Values) o qual pode ser usado para importar dados no sistema. Para exportar seus dados do Outlook, siga os seguintes passos:',
'LBL_OUTLOOK_NUM_1'=>'Inicie o <b>Outlook</b>',
'LBL_OUTLOOK_NUM_2'=>'Selecione o menu <b>Arquivo/File</b>, ent�o a op��o <b>Importar e Exportar / Import and Export ...</b>',
'LBL_OUTLOOK_NUM_3'=>'Escolha <b>Exportar para um arquivo / Export to a file</b> e clique <b>Pr�ximo / Next</b>',
'LBL_OUTLOOK_NUM_4'=>'Escolha <b>Comma Separated Values (Windows)</b> e clique <b>Pr�ximo / Next</b>.<br>  Nota: Voc� pode ser solicitado a instalar o componente de exporta��o',
'LBL_OUTLOOK_NUM_5'=>'Selecione a pasta <b>Contatos / Contacts</b> e clique <b>Pr�ximo / Next</b>. Voc� pode selecionar diferentes pastas de contatos se seus contatos estiverem armazenados em m�ltiplas pastas',
'LBL_OUTLOOK_NUM_6'=>'Escolha um nome de arquivo e clique <b>Pr�ximo / Next</b>',
'LBL_OUTLOOK_NUM_7'=>'Clique <b>Finalizar / Finish</b>',
'LBL_IMPORT_ACT_TITLE'=>'Act! can export data in the <b>Comma Separated Values</b> format which can be used to import data into the system. To export your data from Act!, follow the steps below:',
'LBL_ACT_NUM_1'=>'Launch <b>ACT!</b>',
'LBL_ACT_NUM_2'=>'Select the <b>File</b> menu, the <b>Data Exchange</b> menu option, then the <b>Export...</b> menu option',
'LBL_ACT_NUM_3'=>'Select the file type <b>Text-Delimited</b>',
'LBL_ACT_NUM_4'=>'Choose a filename and location for the exported data and click <b>Next</b>',
'LBL_ACT_NUM_5'=>'Select <b>Contacts records only</b>',
'LBL_ACT_NUM_6'=>'Click the <b>Options...</b> button',
'LBL_ACT_NUM_7'=>'Select <b>Comma</b> as the field separator character',
'LBL_ACT_NUM_8'=>'Check the <b>Yes, export field names</b> checkbox and click <b>OK</b>',
'LBL_ACT_NUM_9'=>'Click <b>Next</b>',
'LBL_ACT_NUM_10'=>'Select <b>All Records</b> and then Click <b>Finish</b>',

'LBL_IMPORT_SF_TITLE'=>'Salesforce.com can export data in the <b>Comma Separated Values</b> format which can be used to import data into the system. To export your data from Salesforce.com, follow the steps below:',
'LBL_SF_NUM_1'=>'Open your browser, go to http://www.salesforce.com, and login with your email address and password',
'LBL_SF_NUM_2'=>'Click on the <b>Reports</b> tab on the top menu',
'LBL_SF_NUM_3'=>'To export Accounts:</b> Click on the <b>Active Accounts</b> link<br><b>To export Contacts:</b> Click on the <b>Mailing List</b> link',
'LBL_SF_NUM_4'=>'On <b>Step 1: Select your report type</b>, select <b>Tabular Report</b>click <b>Next</b>',
'LBL_SF_NUM_5'=>'On <b>Step 2: Select the report columns</b>, choose the columns you want to export and click <b>Next</b>',
'LBL_SF_NUM_6'=>'On <b>Step 3: Select the information to summarize</b>, just click <b>Next</b>',
'LBL_SF_NUM_7'=>'On <b>Step 4: Order the report columns</b>, just click <b>Next</b>',
'LBL_SF_NUM_8'=>'On <b>Step 5: Select your report criteria</b>, under <b>Start Date</b>, choose a date far enough in the past to include all your Accounts. You can also export a subset of Accounts using more advanced criteria. When you are done, click <b>Run Report</b>',
'LBL_SF_NUM_9'=>'A report will be generated, and the page should display <b>Report Generation Status: Complete.</b> Now click <b>Export to Excel</b>',
'LBL_SF_NUM_10'=>'On <b>Export Report:</b>, for <b>Export File Format:</b>, choose <b>Comma Delimited .csv</b>. Click <b>Export</b>.',
'LBL_SF_NUM_11'=>'A dialog will pop up for you to save the export file to your computer.',
'LBL_IMPORT_CUSTOM_TITLE'=>'Many applications will allow you to export data into a <b>Comma Delimited text file (.csv)</b>. Generally most applications follow these general steps:',
'LBL_CUSTOM_NUM_1'=>'Launch the application and Open the data file',
'LBL_CUSTOM_NUM_2'=>'Select the <b>Save As...</b> or <b>Export...</b> menu option',
'LBL_CUSTOM_NUM_3'=>'Save the file in a <b>CSV</b> or <b>Comma Separated Values</b> format',

'LBL_STEP_3_TITLE'=>'Passo 3: Confirmar Campos e Importar',

'LBL_SELECT_FIELDS_TO_MAP'=>'Na lista abaixo, selecionar os campos do seu arquivo de importa��o que dever�o ser importados em cada campo do sistema. Quando terminar, clique <b>Importar Agora / Import Now</b>:',

'LBL_DATABASE_FIELD'=>'Campo do Banco de Dados',
'LBL_HEADER_ROW'=>'Linha Cabe�alho',
'LBL_ROW'=>'Linha',
'LBL_SAVE_AS_CUSTOM'=>'Salvar como Mapeamento Customizado:',
'LBL_CONTACTS_NOTE_1'=>'Sobrenome ou Primeiro Nome devem ser mapeados.',
'LBL_CONTACTS_NOTE_2'=>'Se Nome Completo est� mapeado, ent�o Primeiro Nome e Sobrenome s�o ignorados.',
'LBL_CONTACTS_NOTE_3'=>'Se Nome Completo est� mapeado, ent�o o dado deste campo ser� separado em Primeiro Nome e Sobrenome quando inserido na base de dados.',
'LBL_CONTACTS_NOTE_4'=>'Campos do Endere�o 2 e 3 ser�o concatenados com o campo Endere�o (principal) quando inserido na base de dados.',
'LBL_ACCOUNTS_NOTE_1'=>'Nome da Conta deve estar mapeado.',
'LBL_ACCOUNTS_NOTE_2'=>'Campos do Endere�o 2 e 3 ser�o concatenados com o campo Endere�o (principal) quando inserido na base de dados.',
'LBL_IMPORT_NOW'=>'Importar Agora',
'LBL_'=>'',
'LBL_'=>'',
'LBL_CANNOT_OPEN'=>'N�o � poss�vel abir o arquivo importado para leitura',
'LBL_NOT_SAME_NUMBER'=>'N�o h� o mesmo n�mero de campos por linha em seu arquivo',
'LBL_NO_LINES'=>'N�o h� linhas (registros) em seu arquivo de importa��o',
'LBL_FILE_ALREADY_BEEN_OR'=>'O arquivo de importa��o j� foi processado ou n�o existe',
'LBL_SUCCESS'=>'Sucesso:',
'LBL_SUCCESSFULLY'=>'Importados com Sucesso',
'LBL_LAST_IMPORT_UNDONE'=>'Sua �ltima importa��o foi desfeita',
'LBL_NO_IMPORT_TO_UNDO'=>'N�o h� importa��o para desfazer.',
'LBL_FAIL'=>'Falhou:',
'LBL_RECORDS_SKIPPED'=>'registros perdidos',
'LBL_IDS_EXISTED_OR_LONGER'=>'id\'s que ou existem ou s�o maiores que 36 caracteres',
'LBL_RESULTS'=>'Resultados',
'LBL_IMPORT_MORE'=>'Importar Mais',
'LBL_FINISHED'=>'Finalizar',
'LBL_UNDO_LAST_IMPORT'=>'Desfazer �ltima Importa��o',



);

$mod_list_strings = Array(
'contacts_import_fields' => Array(
	"id"=>"Contact ID"
	,"first_name"=>"Primeiro Nome"
	,"last_name"=>"Sobrenome"
	,"salutation"=>"Sauda��o"
	,"lead_source"=>"Fonte da Oportunidade"
	,"birthdate"=>"Data de Nascimento"
	,"do_not_call"=>"N�o Chamar"
	,"email_opt_out"=>"N�o Quer Email"
	,"primary_address_street_2"=>"Endere�o Principal linha 2"
	,"primary_address_street_3"=>"Endere�o Principal linha 3"
	,"alt_address_street_2"=>"Outro Endere�o linha 2"
	,"alt_address_street_3"=>"Outro Endere�o linha 3"
	,"full_name"=>"Nome Completo"
	,"account_name"=>"Nome da Conta"
	,"account_id"=>"ID da Conta"
	,"title"=>"T�tulo"
	,"department"=>"Departamento"
	,"birthdate"=>"Data de Nascimento"
	,"do_not_call"=>"N�o Chamar"
	,"phone_home"=>"Fone (Resid�ncia)"
	,"phone_mobile"=>"Fone (Celular)"
	,"phone_work"=>"Fone (Comercial)"
	,"phone_other"=>"Fone (Outro)"
	,"phone_fax"=>"Fax"
	,"email1"=>"Email"
	,"email2"=>"Email (Outro)"
	,"yahoo_id"=>"ID Yahoo!"
	,"assistant"=>"Assistente"
	,"assistant_phone"=>"Fone Assistente"
	,"primary_address_street"=>"Endere�o Principal"
	,"primary_address_city"=>"Cidade Endere�o Principal"
	,"primary_address_state"=>"Estado Endere�o Principal"
	,"primary_address_postalcode"=>"CEP Endere�o Principal"
	,"primary_address_country"=>"Pa�s Endere�o Principal"
	,"alt_address_street"=>"Outro Endere�o"
	,"alt_address_city"=>"Cidade Outro Endere�o"
	,"alt_address_state"=>"Estado Outro Endere�o"
	,"alt_address_postalcode"=>"CEP Outro Endere�o"
	,"alt_address_country"=>"Pa�s Outro Endere�o"
	,"description"=>"Descri��o"

	),

'accounts_import_fields' => Array(
	"id"=>"ID da Conta",
	"name"=>"Nome da Conta",
	"website"=>"Website",
	"industry"=>"Neg�cio",
	"type"=>"Tipo",
	"ticker_symbol"=>"C�digo Bolsa",
	"parent_name"=>"Membro de",
	"employees"=>"Funcion�rios",
	"ownership"=>"Propriedade",
	"phone_office"=>"Fone",
	"phone_fax"=>"Fax",
	"phone_alternate"=>"Outro Fone",
	"email1"=>"Email",
	"email2"=>"Outro Email",
	"rating"=>"Avalia��o",
	"sic_code"=>"C�digo SIC",
	"annual_revenue"=>"Receita Anual",
	"billing_address_street"=>"Endere�o Cobran�a",
	"billing_address_street_2"=>"Endere�o Cobran�a linha 2",
	"billing_address_street_3"=>"Endere�o Cobran�a linha 3",
	"billing_address_street_4"=>"Endere�o Cobran�a linha 4",
	"billing_address_city"=>"Cidade Endere�o Cobran�a",
	"billing_address_state"=>"Estado Endere�o Cobran�a",
	"billing_address_postalcode"=>"CEP Endere�o Cobran�a",
	"billing_address_country"=>"Pa�s Endere�o Cobran�a",
	"shipping_address_street"=>"Endere�o Entrega",
	"shipping_address_street_2"=>"Endere�o Entrega linha 2",
	"shipping_address_street_3"=>"Endere�o Entrega linha 3",
	"shipping_address_street_4"=>"Endere�o Entrega linha 4",
	"shipping_address_city"=>"Cidade Endere�o Entrega",
	"shipping_address_state"=>"Estado Endere�o Entrega",
	"shipping_address_postalcode"=>"CEP Endere�o Entrega",
	"shipping_address_country"=>"Pa�s Endere�o Entrega",
	"description"=>"Descri��o"
	)

);

?>