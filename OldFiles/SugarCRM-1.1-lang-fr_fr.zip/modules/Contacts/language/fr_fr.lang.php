<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Contacts/language/en_us.lang.php,v 1.10 2004/08/03 07:43:16 sugarclint Exp $
 * Description:  Defines the English language pack 
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_MODULE_NAME'=>'Contacts',
'LBL_DIRECT_REPORTS_FORM_NAME'=>'Rapports Directes',
'LBL_MODULE_TITLE'=>'Contacts: Accueil',
'LBL_SEARCH_FORM_TITLE'=>'Recherche de Contact',
'LBL_LIST_FORM_TITLE'=>'Liste des Contacts',
'LBL_NEW_FORM_TITLE'=>'Nouveau Contact',
'LBL_CONTACT_OPP_FORM_TITLE'=>'Contact-Affaire:',
'LBL_CONTACT'=>'Contact:',

'LBL_LIST_NAME'=>'Nom',
'LBL_LIST_LAST_NAME'=>'Nom de famille',
'LBL_LIST_CONTACT_NAME'=>'Nom du Contact',
'LBL_LIST_TITLE'=>'Fonction',
'LBL_LIST_ACCOUNT_NAME'=>'Nom du Compte',
'LBL_LIST_EMAIL_ADDRESS'=>'Email',
'LBL_LIST_PHONE'=>'T�l�phone',
'LBL_LIST_CONTACT_ROLE'=>'R�le',

'LBL_NAME'=>'Nom:',
'LBL_CONTACT_NAME'=>'Nom du Contact:',
'LBL_CONTACT_INFORMATION'=>'Informations sur le Contact ',
'LBL_FIRST_NAME'=>'Pr�nom:',
'LBL_OFFICE_PHONE'=>'T�l�phone Bureau:',
'LBL_ACCOUNT_NAME'=>'Nom du Compte:',
'LBL_ANY_PHONE'=>'Autre T�l�phone:',
'LBL_PHONE'=>'T�l�phone:',
'LBL_LAST_NAME'=>'Nom de famille:',
'LBL_MOBILE_PHONE'=>'T�l�phone portable:',
'LBL_HOME_PHONE'=>'T�l�phone personnel:',
'LBL_LEAD_SOURCE'=>'Source du Lead:',
'LBL_OTHER_PHONE'=>'Autre T�l�phone:',
'LBL_FAX_PHONE'=>'Fax:',
'LBL_TITLE'=>'Fonction:',
'LBL_DEPARTMENT'=>'Division:',
'LBL_BIRTHDATE'=>'Date de naissance:',
'LBL_EMAIL_ADDRESS'=>'Email:',
'LBL_OTHER_EMAIL_ADDRESS'=>'Autre Email:',
'LBL_ANY_EMAIL'=>'Email alternatif:',
'LBL_REPORTS_TO'=>'Rend compte � :',
'LBL_ASSISTANT'=>'Assistant:',
'LBL_YAHOO_ID'=>'Identifiant Yahoo! messenger:',
'LBL_ASSISTANT_PHONE'=>'T�l�phone Assistant:',
'LBL_DO_NOT_CALL'=>'Ne pas appeler:',
'LBL_EMAIL_OPT_OUT'=>'Ne pas prospecter par mail:',
'LBL_PRIMARY_ADDRESS'=>'Adresse principale:',
'LBL_ALTERNATE_ADDRESS'=>'Autre Adresse:',
'LBL_ANY_ADDRESS'=>'Adresse alternative:',
'LBL_CITY'=>'Ville:',
'LBL_STATE'=>'State:',
'LBL_POSTAL_CODE'=>'Code Postal:',
'LBL_COUNTRY'=>'Pays:',
'LBL_DESCRIPTION_INFORMATION'=>'Description',
'LBL_DESCRIPTION'=>'Description:',
'LBL_CONTACT_ROLE'=>'R�le:',
'LBL_OPP_NAME'=>"Nom de l'Affaire:",

'LNK_NEW_CONTACT'=>'Nouveau Contact',
'LNK_NEW_ACCOUNT'=>'Nouveau Compte',
'LNK_NEW_OPPORTUNITY'=>'Nouvelle Affaire',
'LNK_NEW_CASE'=>'Nouveau Ticket',
'LNK_NEW_NOTE'=>'Nouvelle Note',
'LNK_NEW_CALL'=>'Nouvel Appel',
'LNK_NEW_EMAIL'=>'New Email',
'LNK_NEW_MEETING'=>'Nouveau Rendez-vous',
'LNK_NEW_TASK'=>'Nouvelle T�che',
'NTC_DELETE_CONFIRMATION'=>'Etes vous s�r de vouloir supprimer cet enregistrement ?',
'NTC_REMOVE_CONFIRMATION'=>'Etes vous s�r de vouloir supprmier ce contact pour ce ticket?',
'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION'=>'Etes vous s�r de vouloir supprimer cet enregistrement en tant que rapport direct ?',
'NTC_REMOVE_OPP_CONFIRMATION'=>'Etes vous s�r de vouloir supprmier ce contact pour cette affaire ?',
'ERR_DELETE_RECORD'=>"Un num�ro d'enregistrement doit �tre sp�cifi� pour supprmier le contact.",
);

?>