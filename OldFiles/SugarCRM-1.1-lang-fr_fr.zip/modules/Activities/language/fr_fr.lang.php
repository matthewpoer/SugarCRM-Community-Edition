<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Activities/language/en_us.lang.php,v 1.7 2004/08/03 08:59:02 sugarclint Exp $
 * Description:  Defines the English language pack for the Account module.
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_OPEN_ACTIVITIES'=>'Activit�s ouvertes',
'LBL_HISTORY'=>'Historique',
'LBL_UPCOMING'=>"Prochaines Activit�s",
'LBL_TODAY'=>'pour ',

'LBL_NEW_TASK_BUTTON_TITLE'=>'Nouvelle T�che [Alt+N]',
'LBL_NEW_TASK_BUTTON_KEY'=>'N',
'LBL_NEW_TASK_BUTTON_LABEL'=>'Nouvelle T�che',
'LBL_SCHEDULE_MEETING_BUTTON_TITLE'=>'Rendez-vous plannifi� [Alt+M]',
'LBL_SCHEDULE_MEETING_BUTTON_KEY'=>'M',
'LBL_SCHEDULE_MEETING_BUTTON_LABEL'=>'Rendez-vous plannifi�',
'LBL_SCHEDULE_CALL_BUTTON_TITLE'=>'Appel plannifi� [Alt+C]',
'LBL_SCHEDULE_CALL_BUTTON_KEY'=>'C',
'LBL_SCHEDULE_CALL_BUTTON_LABEL'=>'Appel plannifi�',
'LBL_NEW_NOTE_BUTTON_TITLE'=>'Nouvelle Note [Alt+T]',
'LBL_NEW_NOTE_BUTTON_KEY'=>'T',
'LBL_NEW_NOTE_BUTTON_LABEL'=>'Nouvelle Note',
'LBL_TRACK_EMAIL_BUTTON_TITLE'=>'Track Email [Alt+K]',
'LBL_TRACK_EMAIL_BUTTON_KEY'=>'K',
'LBL_TRACK_EMAIL_BUTTON_LABEL'=>'Track Email',

'LBL_LIST_CLOSE'=>'Clos',
'LBL_LIST_STATUS'=>'Statuts',
'LBL_LIST_CONTACT'=>'Contact',
'LBL_LIST_RELATED_TO'=>'Relatif �',
'LBL_LIST_DUE_DATE'=>'Date pr�vue',
'LBL_LIST_DATE'=>'Date',
'LBL_LIST_SUBJECT'=>'Sujet',
'LBL_LIST_LAST_MODIFIED'=>'Derni�re modification',

'LNK_NEW_CONTACT'=>'Nouveau Contact',
'LNK_NEW_ACCOUNT'=>'Nouveau Compte',
'LNK_NEW_OPPORTUNITY'=>'Nouvelle Affaire',
'LNK_NEW_CASE'=>'Nouveau Ticket',
'LNK_NEW_NOTE'=>'Nouvelle Note',
'LNK_NEW_CALL'=>'Nouvel Appel',
'LNK_NEW_EMAIL'=>'Nouvel Email',
'LNK_NEW_MEETING'=>'Nouveau Rendez-vous',
'LNK_NEW_TASK'=>'Nouvelle T�che',
'ERR_DELETE_RECORD'=>"Un num�ro d'enregistrement doit �tre sp�cifi� pour supprimer ce compte.",
);

?>