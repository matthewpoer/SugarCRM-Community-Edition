<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/include/language/en_us.lang.php,v 1.22 2004/08/03 09:48:58 sugarclint Exp $
 * Description:  Defines the English language pack for the base application.
 ********************************************************************************/
 
$app_strings = Array(
'LBL_BROWSER_TITLE'=>'SugarCRM - Outil OPEN SOURCE de gestion de la relation client',
'LBL_MY_ACCOUNT'=>'Mon Compte',
'LBL_ADMIN'=>'Admin',
'LBL_LOGOUT'=>'D�connexion',
'LBL_SEARCH'=>'Recherche',
'LBL_LAST_VIEWED'=>'Derni�res consultations',
'NTC_WELCOME'=>'Bienvenue',
'NTC_SUPPORT_SUGARCRM'=>"Supportez le projet open source SugarCRM en faisant uu don par PayPal - C'est rapide, gratuit et s�curis� !",
'NTC_NO_ITEMS_DISPLAY'=>'Aucun',
'LBL_ALT_HOT_KEY'=>'Alt+',

'LBL_SAVE_BUTTON_TITLE'=>'Saauvegarder [Alt+S]',
'LBL_EDIT_BUTTON_TITLE'=>'Editer [Alt+E]',
'LBL_EDIT_BUTTON'=>'Editer',
'LBL_DUPLICATE_BUTTON_TITLE'=>'Dupliquer [Alt+U]',
'LBL_DUPLICATE_BUTTON'=>'Dupliquer',
'LBL_DELETE_BUTTON_TITLE'=>'Supprimer [Alt+D]',
'LBL_DELETE_BUTTON'=>'Supprimer',
'LBL_NEW_BUTTON_TITLE'=>'Nouveau [Alt+N]',
'LBL_CHANGE_BUTTON_TITLE'=>'Modifier [Alt+G]',
'LBL_CANCEL_BUTTON_TITLE'=>'Annuler [Alt+X]',
'LBL_SEARCH_BUTTON_TITLE'=>'Rechercher [Alt+Q]',
'LBL_CLEAR_BUTTON_TITLE'=>'Vider [Alt+C]',
'LBL_SELECT_BUTTON_TITLE'=>'Selectionner [Alt+T]',
'LBL_SAVE_BUTTON_KEY'=>'S',
'LBL_EDIT_BUTTON_KEY'=>'E',
'LBL_DUPLICATE_BUTTON_KEY'=>'U',
'LBL_DELETE_BUTTON_KEY'=>'D',
'LBL_NEW_BUTTON_KEY'=>'N',
'LBL_CHANGE_BUTTON_KEY'=>'G',
'LBL_CANCEL_BUTTON_KEY'=>'X',
'LBL_SEARCH_BUTTON_KEY'=>'Q',
'LBL_CLEAR_BUTTON_KEY'=>'C',
'LBL_SELECT_BUTTON_KEY'=>'T',
'LBL_SAVE_BUTTON_LABEL'=>'Sauvegarder',
'LBL_EDIT_BUTTON_LABEL'=>'Editer',
'LBL_DUPLICATE_BUTTON_LABEL'=>'Dupliquer',
'LBL_DELETE_BUTTON_LABEL'=>'Supprmier',
'LBL_NEW_BUTTON_LABEL'=>'Nouveau',
'LBL_CHANGE_BUTTON_LABEL'=>'Changer',
'LBL_CANCEL_BUTTON_LABEL'=>'Annuler',
'LBL_SEARCH_BUTTON_LABEL'=>'Rechercher',
'LBL_CLEAR_BUTTON_LABEL'=>'Vider',
'LBL_SELECT_BUTTON_LABEL'=>'Selectionner',

'LNK_ADVANCED_SEARCH'=>'Avanc�',
'LNK_BASIC_SEARCH'=>'rapide',
'LNK_EDIT'=>'editer',
'LNK_REMOVE'=>'supp',
'LNK_DELETE'=>'eff',
'LNK_LIST_START'=>'D�part',
'LNK_LIST_NEXT'=>'Suivant',
'LNK_LIST_PREVIOUS'=>'Pr�c�dent',
'LNK_LIST_END'=>'Fin',
'LBL_LIST_OF'=>'sur',
'LNK_PRINT'=>'Imprimer',
'LNK_HELP'=>'Aide',

'NTC_REQUIRED'=>'Indique les champs requis',
'LBL_REQUIRED_SYMBOL'=>'*',
'LBL_CURRENCY_SYMBOL'=>'�',
'LBL_THOUSANDS_SYMBOL'=>'K',
'NTC_DATE_FORMAT'=>'(aaaa-mm-jj)',
'NTC_TIME_FORMAT'=>'(24:00)',
'NTC_DATE_TIME_FORMAT'=>'(aaaa-mm-jj 24:00)',
'NTC_DELETE_CONFIRMATION'=>'Etes vous s�r de vouloir supprmier cet enregistrement ?',
'ERR_DELETE_RECORD'=>"Un num�ro d'enregistrement doit �tre sp�cifi� pour supprimer le contact.",
'ERR_CREATING_TABLE'=>'Erreur de cr�ation de la table: ',
'ERR_CREATING_FIELDS'=>'Erreur de saisie de champs: ',
'ERR_MISSING_REQUIRED_FIELDS'=>'Champs requis non renseign�s:',
'ERR_INVALID_EMAIL_ADDRESS'=>"n'est pas une adresse valide.",
'ERR_INVALID_DATE_FORMAT'=>'Le format de la date doit �tre: aaaa-mm-jj',
'ERR_INVALID_MONTH'=>'Merci de saisir un mois valide.',
'ERR_INVALID_DAY'=>'Merci de saisir un jour valide.',
'ERR_INVALID_YEAR'=>'Merci de saisir une ann�e � 4 chiffres valide.',
'ERR_INVALID_DATE'=>'Merci de saisir une date valide.',
'ERR_INVALID_HOUR'=>'Merci de saisir une heure valide.',
'ERR_INVALID_TIME'=>'Merci de saisir un horaire valide.',
'NTC_CLICK_BACK'=>'Merci de cliquer sur le bouton pr�c�dent du navigateur et de corriger le probl�me.',
'LBL_LIST_ASSIGNED_USER'=>'Assign� � ',
'LBL_ASSIGNED_TO'=>'Assign� �:',
'LBL_CURRENT_USER_FILTER'=>'Montrer uniquement les �l�ments qui me sont assign�s:',
);

//the left value is the key stored in the db and the right value is the display value
//to translate, only modify the right value in each key/value pair
$app_list_strings = Array(
//e.g. auf Deutsch 'Contacts'=>'Contakten', 
'moduleList' => Array('Home'=>'Accueil' 
				, 'Dashboard'=>'Tableau de bord' 
				, 'Contacts'=>'Contacts' 
				, 'Accounts'=>'Comptes'
				, 'Opportunities'=>'Affaires' 
				, 'Cases'=>'Tickets' 
				, 'Notes'=>'Notes' 
				, 'Calls'=>'Appels'
				, 'Emails'=>'Emails'
				, 'Meetings'=>'Rendez-vous' 
				, 'Tasks'=>'T�ches'),

//e.g. en fran�ais 'Analyst'=>'Analyste', 
'account_type_dom' => Array(''=>''
		, 'Analyst'=>'Analyste'
		, 'Competitor'=>'Concurrent'
		, 'Customer'=>'Client'
		, 'Integrator'=>'Integrateur'
		, 'Investor'=>'Investor'
		, 'Partner'=>'Partner'
		, 'Press'=>'Press'
		, 'Prospect'=>'Prospect'
		, 'Reseller'=>'Reseller'
		, 'Other'=>'Other'
		),
		
//e.g. en espa�ol 'Apparel'=>'Ropa', 
'industry_dom' => Array(''=>''
		, 'Apparel'=>'Textile'
		, 'Banking'=>'Banque'
		, 'Biotechnology'=>'Biotechnologie'
		, 'Chemicals'=>'Industrie Chimique'
		, 'Communications'=>'Communications'
		, 'Construction'=>'Construction - BTP'
		, 'Consulting'=>'Conseil'
		, 'Education'=>'Education'
		, 'Electronics'=>'Informatique - Electronique'
		, 'Energy'=>'Energie'
		, 'Engineering'=>'Ingenierie'
		, 'Entertainment'=>'Culture-Presse'
		, 'Environmental'=>'Environnement'
		, 'Finance'=>'Finance'
		, 'Food & Beverage'=>'Agro-alimentaire'
		, 'Government'=>'Administration'
		, 'Healthcare'=>'Sant�'
		, 'Hospitality'=>'Hopitaux'
		, 'Insurance'=>'Assurance'
		, 'Machinery'=>'Industrie lourde'
		, 'Manufacturing'=>'Industrie Manufact.'
		, 'Media'=>'Media'
		, 'Not For Profit'=>'Sans but lucratif'
		, 'Recreation'=>'Loisir'
		, 'Retail'=>'Commerce d�tail'
		, 'Shipping'=>'Transports'
		, 'Technology'=>'Technologie'
		, 'Telecommunications'=>'Telecommunications'
		, 'Transportation'=>'Voyage-hotellerie'
		, 'Utilities'=>'Services'
		, 'Other'=>'Autre'
		),

'lead_source_dom' => Array(''=>''
		, 'Cold Call'=>'Appel entrant'
		, 'Existing Customer'=>'Client existant'
		, 'Self Generated'=>'R�current'
		, 'Employee'=>'Employ�'
		, 'Partner'=>'Partenaire'
		, 'Public Relations'=>'Relation publique'
		, 'Direct Mail'=>'Mailing'
		, 'Conference'=>'Conference'
		, 'Trade Show'=>'Salon'
		, 'Web Site'=>'Site web'
		, 'Word of mouth'=>'Recommand�'
		, 'Other'=>'Autre'
		),

'opportunity_type_dom' => Array(''=>''
		, 'Existing Business'=>'Recurrent'
		, 'New Business'=>'Nouvelle affaire'
		),

//Note:  do not translate opportunity_relationship_type_default_key
//       it is the key for the default opportunity_relationship_type_dom value
'opportunity_relationship_type_default_key' => 'Primary Decision Maker',
'opportunity_relationship_type_dom' => Array(''=>''
		, 'Primary Decision Maker'=>'D�cideur principal'
		, 'Business Decision Maker'=>'Acheteur'
		, 'Business Evaluator'=>'Chef de projet'
		, 'Technical Decision Maker'=>'Responsable technique'
		, 'Technical Evaluator'=>'Utilisateur'
		, 'Executive Sponsor'=>'Sponsor'
		, 'Influencer'=>'Influenceur'
		, 'Other'=>'Autre'
		),
		
//Note:  do not translate case_relationship_type_default_key
//       it is the key for the default case_relationship_type_dom value
'case_relationship_type_default_key' => 'Contact Principal',
'case_relationship_type_dom' => Array(''=>''
		, 'Primary Contact'=>'Contact Principal'
		, 'Alternate Contact'=>'Contact Alternatif'
		),
		
'sales_stage_dom' => Array('Prospecting'=>'Prospection'
		, 'Qualification'=>'Qualification'
		, 'Needs Analysis'=>'Analyse des besoins'
		, 'Value Proposition'=>'Chiffrage'
		, 'Id. Decision Makers'=>'Id. D�cideurs'
		, 'Perception Analysis'=>'Evaluation'
		, 'Proposal/Price Quote'=>'Devis/Proposition'
		, 'Negotiation/Review'=>'Negociation'
		, 'Closed Won'=>'Gagn�'
		, 'Closed Lost'=>'Perdu'
		),

'salutation_dom' => Array(''=>''
		, 'Mr.'=>'Mr.'
		, 'Ms.'=>'Mlle.'
		, 'Mrs.'=>'Mme.'
		, 'Dr.'=>'Dr.'
		, 'Prof.'=>'Prof.'
		),

'task_priority_dom' => Array('High'=>'Haute'
		, 'Medium'=>'Moyenne'
		, 'Low'=>'Basse'
		),

'task_status_dom' => Array('Not Started'=>'Non d�marr�e'
		, 'In Progress'=>'En cours'
		, 'Completed'=>'R�alis�e'
		, 'Pending Input'=>'En attente'
		, 'Deferred'=>'Report�e'
		),

'meeting_status_dom' => Array('Planned'=>'Plannifi�'
		, 'Held'=>'Confirm�'
		, 'Not Held'=>'Non Confirm�'
		),

'call_status_dom' => Array('Planned'=>'Plannifi�'
		, 'Held'=>'Confirm�'
		, 'Not Held'=>'Non Confirm�'
		),

'case_status_dom' => Array('New'=>'Nouveau'
		, 'Assigned'=>'Assign�'
		, 'Closed'=>'Ferm�'
		, 'Pending Input'=>'En attente'
		, 'Rejected'=>'Rejet�'
		),

'user_status_dom' => Array('Active'=>'Actif'
		, 'Inactive'=>'Inactif'
		),

//Note:  do not translate record_type_default_key
//       it is the key for the default record_type_module value
'record_type_default_key' => 'Account',
'record_type_module' => array('Account' => 'Comptes', 
		'Opportunity' => 'Affaires', 
		'Case' => 'Tickets'),
'record_type_display' => array('Account' => 'Compte', 
		'Opportunity' => 'Affaire', 
		'Case' => 'Ticket'),

);

?>