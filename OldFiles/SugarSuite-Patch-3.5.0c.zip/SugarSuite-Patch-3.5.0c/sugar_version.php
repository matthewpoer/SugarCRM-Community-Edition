<?php

// $Id: sugar_version.php,v 1.41.2.1 2005/09/25 05:35:44 andrew Exp $

$sugar_version      = '3.5.0c';
$sugar_db_version   = '3.5.0';
$sugar_flavor       = 'OS';
?>
