<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: updater_utils.php,v 1.6.2.1 2005/09/26 22:56:25 joey Exp $
 ********************************************************************************/
 
function check_now($send_usage_info=true) {
 	
	global $sugar_config;
	global $db;
	$return_array=array();
	$info=array();
	
	include('sugar_version.php');
	$info['sugar_version']=$sugar_version;
	$info['sugar_db_version']=$sugar_db_version;
	$info['sugar_flavor']=$sugar_flavor;
	$info['ip_address'] = $_SERVER['SERVER_ADDR'];
	$info['application_key']=$sugar_config['unique_key'];
	$info['php_version']=phpversion();
	
		
		//get user count.
		$query="select count(*) count from users  where status='Active' and deleted=0";
		
		$result=$db->query($query,'fetching user count',false);
		$row=$db->fetchByAssoc($result);
		if (!empty($row)) { 
			$info['users']=$row['count'];
		}
		
		$query="select count(*) count from users where status='Active' and deleted=0 and is_admin='on'";
		$result=$db->query($query, 'fetching admin count', false);
		$row = $db->fetchByAssoc($result);
		if(!empty($row)) {
			$info['admin_users'] = $row['count'];
		}
		
		$query="select count(*) count from users";
		$result=$db->query($query, 'fetching all users count', false);
		$row = $db->fetchByAssoc($result);
		
		if(!empty($row)) {
			$info['registered_users'] = $row['count'];
		}
		
		if($sugar_config['dbconfig']['db_type'] == 'mysql')
		{
			$query = "SELECT count( DISTINCT users.id ) count FROM tracker, users WHERE users.id = tracker.user_id AND PERIOD_DIFF( NOW( ) , tracker.date_modified ) <=1";
			$result=$db->query($query, 'fetching last 30 users count', false);
			$row = $db->fetchByAssoc($result);
			$info['users_active_30_days'] = $row['count'];
		}
		elseif($sugar_config['dbconfig']['db_type'] == 'oci8')
		{
			$query = "SELECT count( DISTINCT users.id ) count FROM tracker, users WHERE users.id = tracker.user_id and MONTHS_BETWEEN( sysdate , tracker.date_modified ) <= 1";
			$result=$db->query($query, 'fetching last 30 users count', false);
			$row = $db->fetchByAssoc($result);
			$info['users_active_30_days'] = $row['count'];
		}
		else
		{
			$info['users_active_30_days'] = 0;
		}
			
		$query="select id from tracker order by date_modified desc";
		$result=$db->query($query,'fetching most recent tracker entry',false);
		$row=$db->fetchByAssoc($result);
		if (!empty($row)) { 
			$info['latest_tracker_id']=$row['id'];				
		}
		
		if ($sugar_flavor != 'OS') {
			include_once('modules/Administration/Administration.php');
			$admin=new Administration();
			$admin=&$admin->retrieveSettings('license');
			if (!empty($admin->settings))  {
				$info['license_users']=$admin->settings['license_users'];
				$info['license_expire_date']=$admin->settings['license_expire_date'];
				$info['license_key']=$admin->settings['license_key'];			
			}
		}
	
		$dbManager =& DBManagerFactory::getInstance();
		$info['db_type']=$sugar_config['dbconfig']['db_type'];
		$info['db_version']=$dbManager->version();


	require_once('include/nusoap/nusoap.php');
	$sclient = new nusoapclient('http://updates.sugarcrm.com/heartbeat/soap.php', false, false, false, false, false, 15, 15);
	
	$params = array();
	foreach($info as $key => $value)
		array_push($params, array('name' => $key, 'value' => $value ));

	$result = $sclient->call('check_new_version', $params);

	if(!$sclient->getError())
	{
		$return_array['version'] = $result["version"];
		$return_array['description'] = $result["description"];
	}
	else
	{
		$return_array = array();
	}
	

		
	return $return_array;
 }
function set_CheckUpdates_config_setting($value) {
	include_once('modules/Administration/Administration.php');
 	
	$admin=new Administration();
	$admin->saveSetting('Update','CheckUpdates',$value);
} 
 /* return's value for the 'CheckUpdates' config setting
  * if the setting does not exist one gets created with a default value of automatic.
  */
function get_CheckUpdates_config_setting() {
	
	$checkupdates='automatic';	
	include_once('modules/Administration/Administration.php');
 	
	$admin=new Administration();
	$admin=&$admin->retrieveSettings('Update');
	if (empty($admin->settings) or empty($admin->settings['Update_CheckUpdates'])) {
		$admin->saveSetting('Update','CheckUpdates','automatic');
	} else {
		$checkupdates=$admin->settings['Update_CheckUpdates'];
	}
	return $checkupdates;
}

function set_last_check_version_config_setting($value) {
	include_once('modules/Administration/Administration.php');
 	
	$admin=new Administration();
	$admin->saveSetting('Update','last_check_version',$value);
}
function get_last_check_version_config_setting() {
	
	include_once('modules/Administration/Administration.php');
 	
	$admin=new Administration();
	$admin=&$admin->retrieveSettings('Update');
	if (empty($admin->settings) or empty($admin->settings['Update_last_check_version'])) {
		return null;
	} else {
		return $admin->settings['Update_last_check_version'];
	}
}


function set_last_check_date_config_setting($value) {
	include_once('modules/Administration/Administration.php');
 	
	$admin=new Administration();
	$admin->saveSetting('Update','last_check_date',$value);
}
function get_last_check_date_config_setting() {
	
	include_once('modules/Administration/Administration.php');
 	
	$admin=new Administration();
	$admin=&$admin->retrieveSettings('Update');
	if (empty($admin->settings) or empty($admin->settings['Update_last_check_date'])) {
		return 0;
	} else {
		return $admin->settings['Update_last_check_date'];
	}
}

function set_sugarbeat($value) {
	global $sugar_config; 
	$_SUGARBEAT="sugarbeet";
	$sugar_config[$_SUGARBEAT] = $value;
	write_array_to_file( "sugar_config", $sugar_config, "config.php" );
}
function get_sugarbeat() {
 	global $sugar_config;
	$_SUGARBEAT="sugarbeet";
	
	if (isset($sugar_config[$_SUGARBEAT]) && $sugar_config[$_SUGARBEAT] == false) {
 		return false;	
	}
	return true;
}
 
 /* This function will check for availability of next version every week.
  * if automatic version check is not turned off.
  * 
  * If a new version is found, set the version number and desc in the session 
  * and update the last check date. 
  */
 function automatic_version_update_check() {
	global $sugar_config; 	
	global $_SESSION;
		 	
 	if (get_CheckUpdates_config_setting() == 'automatic') {
  		$last_check_date=get_last_check_date_config_setting();
  		$current_date_time=time();
  		$time_period=7*24*60*60;
  	
  		if (($current_date_time - $last_check_date) > $time_period) {
			$version=check_now(get_sugarbeat());		
			if ($version['version'] != get_last_check_version_config_setting()) {
				//set session variables.
				$_SESSION['available_version']=$version['version'];
				$_SESSION['available_version_description']=$version['description'];				
			}
			//update version and time stamp.
			set_last_check_date_config_setting("$current_date_time");
			set_last_check_version_config_setting($version['version']);				
  		}
 	}
 }
?>
