<?php
global $sugar_version;
if(substr($sugar_version,0,5) == "4.0.1")
{
    if(empty($GLOBALS['sugarEntry']))
        $GLOBALS['sugarEntry'] = true;
}
else if(!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');

}
/**
 * This script executes after the files are copied during the install.
 *
 * LICENSE: The contents of this file are subject to the SugarCRM Professional
 * End User License Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/EULA.  By installing or using this file, You have
 * unconditionally agreed to the terms and conditions of the License, and You
 * may not use this file except in compliance with the License.  Under the
 * terms of the license, You shall not, among other things: 1) sublicense,
 * resell, rent, lease, redistribute, assign or otherwise transfer Your
 * rights to the Software, and 2) use the Software for timesharing or service
 * bureau purposes such as hosting the Software for commercial gain and/or for
 * the benefit of a third party.  Use of the Software may be subject to
 * applicable fees and any use of the Software without first paying applicable
 * fees is strictly prohibited.  You do not have the right to remove SugarCRM
 * copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2005 SugarCRM, Inc.; All Rights Reserved.
 * 

 */
 
function entryPointScan($path, $depth, $writableCheck = false){
	$dir = dir($path);
	while($entry = $dir->read()){
		if($entry != '.' && $entry != '..'){
			$fullpath = $path . '/'. $entry;
			
			if(is_file($fullpath) && strlen($entry) > 4 && strcmp(strtolower(substr($entry, -4, 4)), '.php' ) == 0){
			
				
					$GLOBALS['totalFileCount']++;
					if($writableCheck){
						entryPointWritable($fullpath);
					}else{
						updateEntryPoint($fullpath, $depth);
					}
				
			}
			if(is_dir($fullpath)){
				$ignore = false;
			
				foreach($GLOBALS['ignoreDirs'] as $ignorePath){
					
					
					if(substr_count(strtolower($fullpath), strtolower($ignorePath))> 0){
							$ignore = true;
					}
				}
				if(!$ignore){
					entryPointScan($fullpath, $depth + 1, $writableCheck);
					$GLOBALS['totalDirCount']++;
				}
			}
		}
	}
	$dir->close();


}


function entryPointWritable($path){
	if(!is_writable($path)){
		$GLOBALS['nonWritableFiles'][] = $path;
	}
}

function updateEntryPoint($path, $depth){
	$filedata = file_get_contents($path);
	$updated = false;
	//FIRST UPDATE ALL OLD WAYS FOR ENTRY POINTS
	//define(sugarEntry, true);
	$olddata = $filedata;
	$filedata =	preg_replace('/\$GLOBALS\[\'sugarEntry\'\][ ]*\=[ ]*true;/si',"if(!defined('sugarEntry'))define('sugarEntry', true);" , $filedata);
	if($olddata != $filedata){
		$updated = true;
	}
	//if(!defined('sugarEntry') || !sugarEntry)) die('Not A Valid Entry Point');

	$olddata = $filedata;
	$filedata =	preg_replace('/if[ ]*\([ ]*empty[ ]*\([ ]*\$GLOBALS\[\'sugarEntry\'\][ ]*\)[ ]*\)/si' ,"if(!defined('sugarEntry') || !sugarEntry)", $filedata);
	if($olddata != $filedata){
		$updated = true;
	}
	//clean up php tags to all be lower case
	//$filedata = str_replace('<?PHP', '<?php', $filedata);
	/*
	if(substr_count($filedata,'sugarEntry') == 0)	{
		$data = explode('<?php', $filedata, 2);
		//make sure we have <?php some where in there
		if(substr_count($filedata, '<?php') > 0 && count($data) == 1){
			$data[1] = $data[0];
			$data[0] = '';
			
		}
		if(count($data) == 2){
			//if the depth is 0 then it is an entry point
			if($depth == 0){
				$filedata = $data[0] . "<?php\nif(!defined('sugarEntry'))define('sugarEntry',true);\n". $data[1];

			}else{
				$filedata = $data[0] . "<?php\nif(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');\n". $data[1];

			}
		}
		$updated = true;
	}
*/
	if($updated){
		$fp = fopen($path, 'w');
		fwrite($fp, $filedata);
		fclose($fp);
		//echo "<br>".'updated - ' . $path . "\n";
	}
}


?>
