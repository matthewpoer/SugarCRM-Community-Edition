<?php
if(!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');

}
/**
 * This script executes after the files are copied during the install.
 *
 * LICENSE: The contents of this file are subject to the SugarCRM Professional
 * End User License Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/EULA.  By installing or using this file, You have
 * unconditionally agreed to the terms and conditions of the License, and You
 * may not use this file except in compliance with the License.  Under the
 * terms of the license, You shall not, among other things: 1) sublicense,
 * resell, rent, lease, redistribute, assign or otherwise transfer Your
 * rights to the Software, and 2) use the Software for timesharing or service
 * bureau purposes such as hosting the Software for commercial gain and/or for
 * the benefit of a third party.  Use of the Software may be subject to
 * applicable fees and any use of the Software without first paying applicable
 * fees is strictly prohibited.  You do not have the right to remove SugarCRM
 * copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2005 SugarCRM, Inc.; All Rights Reserved.
 */


require_once(clean_path($unzip_dir.'/scripts/upgrade_utils.php'));






























function rebuild_dashlets(){
    if(is_file('cache/dashlets/dashlets.php')) {
        unlink('cache/dashlets/dashlets.php');
    }
    require_once('include/Dashlets/DashletCacheBuilder.php');

    $dc = new DashletCacheBuilder();
    $dc->buildCache();
}
function rebuild_teams(){

    require_once('modules/Administration/RepairTeams.php');

    process_team_access(false, false,true,'1');
}

function rebuild_roles(){
  include("modules/ACL/install_actions.php");
}

function post_install() {
	global $unzip_dir;
	global $sugar_config;
	global $sugar_version;
	global $path;
	global $_SESSION;

	_logThis('Entered post_install function.', $path);
	$self_dir = "$unzip_dir/scripts";

	///////////////////////////////////////////////////////////////////////////
	////	PUT DATABASE UPGRADE SCRIPT HANDLING HERE
	$new_sugar_version = getUpgradeVersion();
	$origVersion = substr(preg_replace("/[^0-9]/", "", $sugar_version),0,3);
	$destVersion = substr(preg_replace("/[^0-9]/", "", $new_sugar_version),0,3);
	// This flag is determined by the preflight check in the installer
	if(!isset($_SESSION['schema_change']) || /* pre-4.5.0 upgrade wizard */
		$_SESSION['schema_change'] == 'sugar') {
		_logThis("Upgrading the database from {$origVersion} to version {$destVersion}", $path);
		$schemaFileName = $origVersion."_to_".$destVersion;

		if($sugar_config['dbconfig']['db_type'] == 'oci8') {









		} elseif($sugar_config['dbconfig']['db_type'] == 'mssql') {
			//BEFORE RUNNING 451_to_500 sql script drop the constraints on the columns
			_logThis('Droping constraints on some columns ', $path);
				require_once("$unzip_dir/scripts/upgrade_sqlsvr5.php");
				upgrade5_sqlsvr();
			_logThis("Running SQL file 451_to_500_mssql.sql", $path);
			$schemaFile = "$self_dir/451_to_500_mssql.sql";
			if(is_file($schemaFile)) {
				$sql_run_result = _run_sql_file($schemaFile);
			} else {
				logThis("*** ERROR: Schema change script [{$schemaFile}] could not be found!", $path);
			}
		}
		else {
			_logThis("Running SQL file 451_to_500_mysql.sql", $path);
			$schemaFile = "$self_dir/451_to_500_mysql.sql";
			if(is_file($schemaFile)) {
				$sql_run_result = _run_sql_file($schemaFile);
			} else {
				logThis("*** ERROR: Schema change script [{$schemaFile}] could not be found!", $path);
			}
		}
	} else {
		_logThis('*** Skipping Schema Change Scripts - Admin opted to run queries manually and should have done so by now.', $path);
	}

   //Upgrade to 500 KB and Advanced Projects
    require_once("$unzip_dir/scripts/upgrade_kb_advanced_project5.php");
    _logThis('Start creating Kb and advanced projects', $path);
    	kb_and_project_sqls();
    _logThis('End creating Kb and advanced projects', $path);

    //Upgrade to 500 Email
    require_once("$unzip_dir/scripts/upgrade_email5.php");
	_logThis('Start Upgrading Email to 50', $path);
		upgrade_email5();
	_logThis('End Upgrading Email to 50', $path);

	//Upgrade to 500 fields meta data
	_logThis('Start Upgrading Fields Meta Data to 50', $path);
		upgrade_fields_meta();
	_logThis('End Upgrading Fields Meta Data to 50', $path);

	////	END SCHEMA CHANGE UPGRADE SCRIPTS
	///////////////////////////////////////////////////////////////////////////


	///////////////////////////////////////////////////////////////////////////
	////	FILESYSTEM SECURITY FIX (Bug 9365)
	_logThis("Applying .htaccess update security fix.", $path);
	include_once("modules/Administration/UpgradeAccess.php");

	///////////////////////////////////////////////////////////////////////////
	////	PRO/ENT ONLY FINAL TOUCHES
















	///////////////////////////////////////////////////////////////////////////
	////	REBUILD JS LANG
	_logThis("Rebuilding JS Langauages", $path);
	rebuild_js_lang();

	///////////////////////////////////////////////////////////////////////////
	////	REBUILD DASHLETS
	_logThis("Rebuilding Dashlets", $path);
	rebuild_dashlets();








    //Rebuild roles
     _logThis("Rebuilding Roles", $path);
     ob_start();
     rebuild_roles();
     ob_end_clean();

	///////////////////////////////////////////////////////////////////////////
	////	FINALIZE VERSION UPDATES
	upgradeDbAndFileVersion($new_sugar_version);
}
?>