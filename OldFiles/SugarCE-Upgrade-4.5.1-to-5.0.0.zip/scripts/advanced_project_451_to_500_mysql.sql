-- project
ALTER TABLE `project` ADD COLUMN `estimated_start_date` date NOT NULL AFTER `deleted`;
ALTER TABLE `project` ADD COLUMN `status` varchar(255) NULL AFTER `estimated_start_date`;
ALTER TABLE `project` ADD COLUMN `priority` varchar(255) NULL AFTER `status`;



ALTER TABLE `project` ADD COLUMN `estimated_end_date` date NOT NULL;
UPDATE `project` SET `status` = 'Draft';
UPDATE `project` SET `priority` = 'Medium';

-- project_task
ALTER TABLE `project_task` ADD COLUMN `time_start_backed` time NULL AFTER `deleted`;
UPDATE `project_task` SET `time_start_backed` = `time_start`;
ALTER TABLE `project_task` CHANGE COLUMN `time_start` `time_start` int(11) NULL;

ALTER TABLE `project_task` ADD COLUMN `time_finish` int(11) NULL AFTER `time_start`;
UPDATE `project_task` SET `time_finish` = `time_due`;

ALTER TABLE `project_task` ADD COLUMN `project_id` char(36) NULL AFTER `date_modified`;
UPDATE `project_task` SET `project_id` = `parent_id`;
ALTER TABLE `project_task` ADD COLUMN `project_task_id` int(11) NOT NULL AFTER `project_id`;
ALTER TABLE `project_task` ADD COLUMN `predecessors` text NULL AFTER `description`;




ALTER TABLE `project_task` MODIFY COLUMN `date_start` date NULL;
ALTER TABLE `project_task` ADD COLUMN `date_finish` date NULL AFTER `time_finish`;
UPDATE `project_task` SET `date_finish` = `date_due`;

ALTER TABLE `project_task` ADD COLUMN `duration` int(11) NOT NULL AFTER `date_finish`;
ALTER TABLE `project_task` ADD COLUMN `duration_unit` text NOT NULL AFTER `duration`;
UPDATE `project_task` SET `duration_unit` = 'Days';

ALTER TABLE `project_task` ADD COLUMN `actual_duration` int(11) NULL AFTER `duration_unit`;
UPDATE `project_task` SET `actual_duration` = CEILING(actual_effort / 8);
ALTER TABLE `project_task` CHANGE COLUMN `percent_complete` `percent_complete` int(11) NULL;
UPDATE `project_task` SET `percent_complete` = 0 WHERE `percent_complete` IS NULL;
ALTER TABLE `project_task` ADD COLUMN `parent_task_id` int(11) NULL AFTER `percent_complete`;






-- projects_accounts
CREATE TABLE `projects_accounts` (
  `id` varchar(36) NOT NULL,
  `account_id` varchar(36) default NULL,
  `project_id` varchar(36) default NULL,
  `date_modified` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `idx_proj_acct_proj` (`project_id`),
  KEY `idx_proj_acct_acct` (`account_id`),
  KEY `projects_accounts_alt` (`project_id`,`account_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- projects_bugs
CREATE TABLE `projects_bugs` (
  `id` varchar(36) NOT NULL,
  `bug_id` varchar(36) default NULL,
  `project_id` varchar(36) default NULL,
  `date_modified` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `idx_proj_bug_proj` (`project_id`),
  KEY `idx_proj_bug_bug` (`bug_id`),
  KEY `projects_bugs_alt` (`project_id`,`bug_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- projects_cases
CREATE TABLE `projects_cases` (
  `id` varchar(36) NOT NULL,
  `case_id` varchar(36) default NULL,
  `project_id` varchar(36) default NULL,
  `date_modified` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `idx_proj_case_proj` (`project_id`),
  KEY `idx_proj_case_case` (`case_id`),
  KEY `projects_cases_alt` (`project_id`,`case_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- projects_contacts
CREATE TABLE `projects_contacts` (
  `id` varchar(36) NOT NULL,
  `contact_id` varchar(36) default NULL,
  `project_id` varchar(36) default NULL,
  `date_modified` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `idx_proj_con_proj` (`project_id`),
  KEY `idx_proj_con_con` (`contact_id`),
  KEY `projects_contacts_alt` (`project_id`,`contact_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- projects_opportunities
CREATE TABLE `projects_opportunities` (
  `id` varchar(36) NOT NULL,
  `opportunity_id` varchar(36) default NULL,
  `project_id` varchar(36) default NULL,
  `date_modified` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `idx_proj_opp_proj` (`project_id`),
  KEY `idx_proj_opp_opp` (`opportunity_id`),
  KEY `projects_opportunities_alt` (`project_id`,`opportunity_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- projects_products
CREATE TABLE `projects_products` (
  `id` varchar(36) NOT NULL,
  `product_id` varchar(36) default NULL,
  `project_id` varchar(36) default NULL,
  `date_modified` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `idx_proj_prod_project` (`project_id`),
  KEY `idx_proj_prod_product` (`product_id`),
  KEY `projects_products_alt` (`project_id`,`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;































































