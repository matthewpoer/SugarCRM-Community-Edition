
<?php
/**
 * This script executes after the files are copied during the install.
 *
 * LICENSE: The contents of this file are subject to the SugarCRM Professional
 * End User License Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/EULA.  By installing or using this file, You have
 * unconditionally agreed to the terms and conditions of the License, and You
 * may not use this file except in compliance with the License.  Under the
 * terms of the license, You shall not, among other things: 1) sublicense,
 * resell, rent, lease, redistribute, assign or otherwise transfer Your
 * rights to the Software, and 2) use the Software for timesharing or service
 * bureau purposes such as hosting the Software for commercial gain and/or for
 * the benefit of a third party.  Use of the Software may be subject to
 * applicable fees and any use of the Software without first paying applicable
 * fees is strictly prohibited.  You do not have the right to remove SugarCRM
 * copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2005 SugarCRM, Inc.; All Rights Reserved.
 *
 * $Id$
 */

require_once('include/utils.php');
require_once('include/database/PearDatabase.php');
require_once('include/database/DBManager.php');
require_once('include/database/DBManagerFactory.php');
require_once("include/entryPoint.php");


function kb_and_project_sqls(){
	global $unzip_dir;
	global $sugar_config;
	global $sugar_version;
	global $path;
	global $_SESSION;

	$self_dir = "$unzip_dir/scripts";
	$kb_loaded = checkIfModuleLoaded('Knowledge Base');
	$advanced_project_loaded = (checkIfModuleLoaded('Advanced Project Management') || checkIfModuleLoaded('Project Management Module')) ? true : false;
	$dbType = $sugar_config['dbconfig']['db_type'];
	if($sugar_config['dbconfig']['db_type'] == 'oci8') {


































   }
    elseif($sugar_config['dbconfig']['db_type'] == 'mssql') {
		 //check if Advanced Project is loaded. If not then run the sqlscript to upgrade Advanced Project
        if($advanced_project_loaded == null){
            _logThis("Running SQL file advanced_project_451_to_500_mssql.sql", $path);
			$apSchemaFile = "$self_dir/advanced_project_451_to_500_mssql.sql";
			if(is_file($apSchemaFile)) {
				$sql_run_result = _run_sql_file($apSchemaFile);
			} else {
				logThis("*** ERROR: Schema change script [{$apSchemaFile}] could not be found!", $path);
			}
			require_once("$unzip_dir/scripts/upgrade_projects.php");
        }






























	}
	else {
         //check if Advanced Project is loaded. If not then run the sqlscript to upgrade Advanced Project
        if($advanced_project_loaded == null){
            _logThis("Running SQL file advanced_project_451_to_500_mysql.sql", $path);
			$apSchemaFile = "$self_dir/advanced_project_451_to_500_mysql.sql";
			if(is_file($apSchemaFile)) {
				$sql_run_result = _run_sql_file($apSchemaFile);
			} else {
				logThis("*** ERROR: Schema change script [{$apSchemaFile}] could not be found!", $path);
			}
			require_once("$unzip_dir/scripts/upgrade_projects.php");
        }





























	}
  }
function createKbIndex($dbType){
    $db =& PearDatabase::getInstance();
    $table = 'kbcontents';
	$column = 'kb_index';
	$index = "FTS_UNIQUE_IDX";
	$sequence = "KBCONTENTS_KB_INDEX_SEQ";
    if($dbType == 'oci8'){
		$columnType='number';
		$qC = "ALTER TABLE {$table} ADD ({$column} {$columnType})";
		$db->query($qC);
		$qI ="CREATE UNIQUE INDEX {$index} ON {$table}({$column})";
		$db->query($qI);
		$qS = "CREATE SEQUENCE {$sequence}";
		$db->query($qS);
		$qU = "UPDATE {$table} set {$column}=$sequence.nextval";
		$db->query($qU);
		$qN = "ALTER TABLE {$table} MODIFY ({$column} NOT NULL)";
		$db->query($qN);
    }
    if($dbType == 'mssql'){
    	$columnType='int';
    	$qC="ALTER TABLE {$table} add {$column} {$columnType} IDENTITY(1,1) NOT NULL;";
    	$db->query($qC);
    	$qI = "CREATE UNIQUE INDEX {$index} ON {$table}($column);";
    	$db->query($qI);
    }
    if($dbType == 'mysql'){
    	 $qCI="alter table kbcontents add kb_index int(11) unsigned auto_increment, add unique key fts_unique_idx(kb_index);";
    	 $db->query($qCI);
    }
}

function checkIfModuleLoaded($module_name){
	$db = &PearDatabase::getInstance();
	$query = "SELECT * FROM versions WHERE name='" . $module_name . "'";
	// check to see if row exists
	$result = $db->query($query, true, "Unable to retreive data from versions table");
	$row = $db->fetchByAssoc($result);
	return $row;
}

//check if kb_index is created
function checkIfKbIndexCreated($dbType){
	$db = &PearDatabase::getInstance();
	$query = "SELECT * FROM versions WHERE name='" . $module_name . "'";
	// check to see if row exists
	$result = $db->query($query, true, "Unable to retreive data from versions table");
	$row = $db->fetchByAssoc($result);
	return $row;
}

function checkUserPrivileges(){
global $sugar_config;
	$dbUser = $sugar_config['dbconfig']['db_user_name'];
	$db =& PearDatabase::getInstance();
	$query ="select sysadmin from sys.syslogins where (name='".$dbUser."' or loginname ='".$dbUser."')";
	$q = $db->query($query);
	$res =$db->fetchByAssoc($q);
	return $res['sysadmin'];
}
function create_fts_index($tableName,$fieldDefs,$indices,$dbType){
	 //if ( $indices[] = $indices;
        $db =& PearDatabase::getInstance();
        $columns = array();
        global $path;
		foreach ($indices as $index){
		  if(!empty($index['db']) && $index['db'] != $dbType)continue;
          $type = $index['type'];
          $name = $index['name'];
          if(is_array($index['fields'])) {
          	$fields = implode(", ", $index['fields']);
          }else{
          	$fields = $index['fields'];
          }
          switch ($type){
		    case 'fulltext':
				//echo $index['key_index'];;
				if ($dbType == 'mssql'){
                   _logThis("Checking for fts condition ", $path);
                   if(full_text_indexing_enabled_mssql() && checkUserPrivileges()){
						_logThis("Checking for fts condition Catalog begins", $path);
						create_default_full_text_catalog();
						_logThis("Checking for fts condition Catalog done", $path);
						$catalog_name="sugar_fts_catalog";
						if (isset ($index['catalog_name']) and $index['catalog_name'] != 'default') {
							$catalog_name=$index['catalog_name'];
						}
						$language="Language 1033";
						if (isset($index['language']) and !empty($index['language'])) {
							$language="Language " . $index['language'];
						}
						$key_index=$index['key_index'];
						$change_tracking="auto";
						if (isset($index['change_tracking']) and !empty($index['change_tracking'])) {
							$change_tracking=$index['change_tracking'];
						}
						$query = "CREATE FULLTEXT INDEX ON $tableName($fields $language) KEY INDEX $key_index ON $catalog_name WITH CHANGE_TRACKING $change_tracking" ;
						$db->query($query);
				   }
				  else{
     			 		echo 'SQL Server user has insufficient permissions to create a catalog and full text search';
    			  }
			   }
			   if ($dbType == 'mysql'){
      		     if(full_text_indexing_enabled_mysql()){
      		       $query = "ALTER TABLE $tableName ADD FULLTEXT ($fields)";
				   $db->query($query);
    			 } else {
    				$GLOBALS['log']->debug('MYISAM engine is not available/enabled, full-text indexes will be skipped. Skipping:',$name);
 	 			 }
	         }
	  }
	}  //end foreach
}

function create_default_full_text_catalog() {
		$db =& PearDatabase::getInstance();
		if (full_text_indexing_enabled_mssql()) {
			$GLOBALS['log']->debug('Creating the default catalog for full-text indexing, sugar_fts_catalog');
			//drop catalog if exists.
			$query="if not exists(select * from sys.fulltext_catalogs where name ='sugar_fts_catalog') CREATE FULLTEXT CATALOG sugar_fts_catalog ";
			$ret=$db->query($query);
			if (empty($ret)) {
				$GLOBALS['log']->error('Error creating default full-text catalog, sugar_fts_catalog');
			}
		}
	}
function create_fts_index_mysql($fields){
	if (full_text_indexing_enabled_mysql()) {
            $columns[] = " FULLTEXT ($fields)";
    	} else {
    		$GLOBALS['log']->debug('MYISAM engine is not available/enabled, full-text indexes will be skipped. Skipping:',$name);
 	 }
}

function create_fts_oracle(){
	$ver=$GLOBALS['db']->version();
	$tok = strtok($ver, '.');
	if ($tok !== false and $tok==9) {
		//$parameters="";
		$q="CREATE INDEX  KBCONTENTSFTK  ON  KBCONTENTS (KBDOCUMENT_BODY) INDEXTYPE IS CTXSYS.CONTEXT";
		$GLOBALS['db']->query($q);
	}
	else{
		$q="CREATE INDEX  KBCONTENTSFTK  ON  KBCONTENTS (KBDOCUMENT_BODY) INDEXTYPE IS CTXSYS.CONTEXT PARAMETERS ('sync (on commit)')";
		$GLOBALS['db']->query($q);
	}
}


function full_text_indexing_enabled_mssql($dbname=null) {
       $db =& PearDatabase::getInstance();
		if (empty($dbname)) {
			global $sugar_config;
			$dbname=$sugar_config['dbconfig']['db_name'];
		}
		$query="SELECT DATABASEPROPERTY('$dbname', 'IsFulltextEnabled') ftext";
		$status=$db->query($query);
		if (!empty($status)) {
			$row=$db->fetchByAssoc($status);
			if (isset($row['ftext']) and $row['ftext']==1) {

				//this property does return the true state of full-text index consistently.
				//need to perform a secondary test.
				$query2="EXEC sp_fulltext_service 'resource_usage'";
				$result=mssql_query($query2);
				$sqlmsg = mssql_get_last_message();
				if (!empty($sqlmsg)) {
					//igonoring context change error message.
					$ignore_message=(isset($app_strings['ERR_MSSQL_DB_CONTEXT'])) ? $app_strings['ERR_MSSQL_DB_CONTEXT'] : "Changed database context to";
					$sqlpos = strpos($sqlmsg, $ignore_message);
					if ( $sqlpos === false )  {
						$GLOBALS['log']->debug("Full text indexing is disabled because of following error " . $sqlmsg);
						return false;
					}
				}
				return true;
			}
		}
		return false;
	}
function full_text_indexing_enabled_mysql($dbname=null) {
        $db =& PearDatabase::getInstance();
		$query="SHOW storage ENGINES";
		$stat=$db->query($query);
		if (!empty($stat)) {
			while (($row=$db->fetchByAssoc($stat))!= null) {
				if ($row['Engine']=='MyISAM' and ($row['Support']=='YES' or $row['Support']=='DEFAULT')) {
					return true;
				}
			}
		}
		return false;
	}
?>