<?php
// created: 2009-03-10 12:22:31
$manifest = array (
  'acceptable_sugar_flavors' => 
  array (
    0 => 'CE',
    1 => 'OS',
  ),
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '5\\.2\\.0$',
      1 => '5\\.2\\.0[a-z]$',
      2 => '5\\.2\\.0beta',
    ),
  ),
  'author' => 'SugarCRM, Inc.',
  'copy_files' => 
  array (
    'from_dir' => 'SugarCE-Patch-5.2.0c',
    'to_dir' => '',
    'force_copy' => 
    array (
    ),
  ),
  'description' => '',
  'icon' => '',
  'is_uninstallable' => false,
  'offline_client_applicable' => true,
  'name' => 'SugarCE',
  'published_date' => '2009-03-10 12:22:31',
  'type' => 'patch',
  'version' => '5.2.0c',
);
?>
