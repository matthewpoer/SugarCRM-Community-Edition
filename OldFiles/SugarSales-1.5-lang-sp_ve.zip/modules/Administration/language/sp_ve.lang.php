<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Administration/language/sp_ve.lang.php,v 1.5 2004/08/20 13:08:20 sugarjacob Exp $
 * Description:  Defines the Spanish language pack for the Account module.
 ********************************************************************************/

$mod_strings = Array(
'LBL_MODULE_NAME'=>'Administraci�n',
'LBL_MODULE_TITLE'=>'Administraci�n: Home',

'LBL_NEW_FORM_TITLE'=>'Nueva Cuenta',
'LNK_NEW_CONTACT'=>'Nuevo Contacto',
'LNK_NEW_ACCOUNT'=>'Nueva Cuenta',
'LNK_NEW_OPPORTUNITY'=>'Nueva Oportunidad',
'LNK_NEW_CASE'=>'Nuevo Caso',
'LNK_NEW_NOTE'=>'Nueva Nota',
'LNK_NEW_CALL'=>'Nueva Llamada',
'LNK_NEW_EMAIL'=>'Nuevo Email',
'LNK_NEW_MEETING'=>'Nueva Reuni�n',
'LNK_NEW_TASK'=>'Nueva Tarea',
'ERR_DELETE_RECORD'=>"Un n�mero de registro debe ser indicado para borrar la cuenta.",
);

?>