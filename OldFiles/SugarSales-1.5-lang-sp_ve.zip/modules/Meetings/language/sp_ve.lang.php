<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Meetings/language/sp_ve.lang.php,v 1.12 2004/08/20 13:18:55 stratofun Exp $
 * Description:  Defines the Spanish language pack for the Account module.
 ********************************************************************************/

$mod_strings = Array(
'LBL_MODULE_NAME'=>'Reuniones',
'LBL_MODULE_TITLE'=>'Reuniones: Inicio',
'LBL_SEARCH_FORM_TITLE'=>'B�squeda Reuniones',
'LBL_LIST_FORM_TITLE'=>'Lista Reuniones',
'LBL_NEW_FORM_TITLE'=>'Programaci�n Reuniones',

'LBL_LIST_SUBJECT'=>'SAsunto',
'LBL_LIST_CONTACT'=>'Nombre Contacto',
'LBL_LIST_RELATED_TO'=>'Relacionado a',
'LBL_LIST_DATE'=>'Fecha Inicio',
'LBL_LIST_TIME'=>'Hora Inicio',
'LBL_LIST_CLOSE'=>'Cerrado',

'LBL_SUBJECT'=>'Asunto:',
'LBL_STATUS'=>'Estado:',
'LBL_LOCATION'=>'Localizaci�n:',
'LBL_DATE_TIME'=>'Fecha y Hora Inicio:',
'LBL_DATE'=>'Fecha Inicio:',
'LBL_TIME'=>'Hora Inicio:',
'LBL_DURATION'=>'Duraci�n:',
'LBL_HOURS_MINS'=>'(horas/minutos)',
'LBL_SUBJECT'=>'Asunto: ',
'LBL_CONTACT_NAME'=>'Nombre Contacto: ',
'LBL_MEETING'=>'Reuni�n:',
'LBL_DESCRIPTION_INFORMATION'=>'Informaci�n Descriptiva',
'LBL_DESCRIPTION'=>'Descripci�n:',
'LBL_COLON'=>':',
'LBL_DEFAULT_STATUS'=>'Planificado',

'LNK_NEW_CONTACT'=>'Nuevo Contacto',
'LNK_NEW_ACCOUNT'=>'Nueva Cuenta',
'LNK_NEW_OPPORTUNITY'=>'Nueva Oportunidad',
'LNK_NEW_CASE'=>'Nuevo Caso',
'LNK_NEW_NOTE'=>'Nueva Nota',
'LNK_NEW_CALL'=>'Nueva Llamada',
'LNK_NEW_EMAIL'=>'Nuevo Email',
'LNK_NEW_MEETING'=>'Nueva Reuni�n',
'LNK_NEW_TASK'=>'Nueva Tarea',
'ERR_DELETE_RECORD'=>"Un n�mero de registro debe ser indicado para borrar la reuni�n.",
'NTC_REMOVE_INVITEE'=>'�Est� seguro que desea borrar este invitado de la reuni�n?',
'LBL_INVITEE'=>'Invitados',
);

?>