<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Opportunities/language/sp_ve.lang.php,v 1.12 2004/08/20 13:17:25 stratofun Exp $
 * Description:  Defines the Spanish language pack for the Account module.
 ********************************************************************************/

$mod_strings = Array(
'LBL_MODULE_NAME'=>'Oportunidades',
'LBL_MODULE_TITLE'=>'Oportunidades: Inicio',
'LBL_SEARCH_FORM_TITLE'=>'B�squeda Oportunidades',
'LBL_LIST_FORM_TITLE'=>'Lista Oportunidades',
'LBL_OPPORTUNITY_NAME'=>'Nombre Oportunidad:',
'LBL_OPPORTUNITY'=>'Oportunidad:',
'LBL_NAME'=>'Nombre Oportunidad',

'LBL_LIST_OPPORTUNITY_NAME'=>'Oportunidad',
'LBL_LIST_ACCOUNT_NAME'=>'Nombre Cuenta',
'LBL_LIST_AMOUNT'=>'Monto',
'LBL_LIST_DATE_CLOSED'=>'Fecha Cierre',
'LBL_LIST_SALES_STAGE'=>'Etapa Ventas',

'LBL_OPPORTUNITY_NAME'=>'Nombre Oportunidad:',
'LBL_ACCOUNT_NAME'=>'Nombre Cuenta:',
'LBL_AMOUNT'=>'Monto:',
'LBL_DATE_CLOSED'=>'Fecha Cierre:',
'LBL_TYPE'=>'Tipo:',
'LBL_NEXT_STEP'=>'Pr�ximo Paso:',
'LBL_LEAD_SOURCE'=>'Fuente Lider:',
'LBL_SALES_STAGE'=>'SEtapa Ventas:',
'LBL_PROBABILITY'=>'Probabilidad (%):',
'LBL_DESCRIPTION'=>'Descripci�n:',

'LBL_NEW_FORM_TITLE'=>'Nueva Cuenta',
'LNK_NEW_CONTACT'=>'Nuevo Contacto',
'LNK_NEW_ACCOUNT'=>'Nueva Cuenta',
'LNK_NEW_OPPORTUNITY'=>'Nueva Oportunidad',
'LNK_NEW_CASE'=>'Nuevo Caso',
'LNK_NEW_NOTE'=>'Nueva Nota',
'LNK_NEW_CALL'=>'Nueva Llamada',
'LNK_NEW_EMAIL'=>'Nuevo Email',
'LNK_NEW_MEETING'=>'Nueva Reuni�n',
'LNK_NEW_TASK'=>'Nueva Tarea',

'ERR_DELETE_RECORD'=>"U n�mero de registro debe ser indicado para borrar la oportunidad.",
'LBL_TOP_OPPORTUNITIES'=>"Mis Principales Oportunidades",

'LBL_INVITEE'=>'*Contacts',
'NTC_REMOVE_OPP_CONFIRMATION'=>'*Are you sure you want to remove this contact from this opportunity?',
);

?>