<?php
	// $Id: sugar_version.php,v 1.31 2005/02/26 03:15:27 andrew Exp $
	$sugar_version = '2.5.1';
?>
