<?PHP

$portal_modules = array('Contacts', 'Accounts', 'Cases', 'Bugs', 'Notes');
/*
BUGS
*/
require_once('modules/Bugs/Bug.php');
function get_bugs_in_contacts($in, $orderBy = '')
	{
		// First, get the list of IDs.
		$query = "SELECT bug_id as id from contacts_bugs where contact_id IN $in AND deleted=0";
		if(!empty($orderBy)){
			$query .= ' ORDER BY ' . $orderBy;	
		}
		$contact = new Contact();



		$bug = new Bug();



		return $contact->build_related_list($query,$bug);
	}

function get_bugs_in_accounts($in, $orderBy = '')
	{
		// First, get the list of IDs.
		$query = "SELECT bug_id as id from accounts_bugs where account_id IN $in AND deleted=0";
		if(!empty($orderBy)){
			$query .= ' ORDER BY ' . $orderBy;	
		}
		$account = new Account();	



		$bug = new Bug();



		return $account->build_related_list($query, $bug);
	}

/*
Cases
*/
require_once('modules/Cases/Case.php');
function get_cases_in_contacts($in, $orderBy = '')
	{
		// First, get the list of IDs.
		$query = "SELECT case_id as id from contacts_cases where contact_id IN $in AND deleted=0";
		if(!empty($orderBy)){
			$query .= ' ORDER BY ' . $orderBy;	
		}
		$contact = new Contact();



		$case = new aCase();



		return $contact->build_related_list($query, $case);
	}
	
/*
NOTES
*/
require_once('modules/Notes/Note.php');
function get_notes_in_contacts($in, $orderBy = '')
	{
		// First, get the list of IDs.
		$query = "SELECT id from notes where contact_id IN $in AND deleted=0";
		if(!empty($orderBy)){
			$query .= ' ORDER BY ' . $orderBy;	
		}
		$contact = new Contact();	



		$note = new Note();



		return $contact->build_related_list($query, $note);
	}
	
function get_notes_in_module($in, $module, $orderBy = '')
	{
		// First, get the list of IDs.
		$query = "SELECT id from notes where parent_id IN $in AND parent_type='$module' AND deleted=0";
		if(!empty($orderBy)){
			$query .= ' ORDER BY ' . $orderBy;	
		}
		$sugar = new SugarBean();



		$note = new Note();



		return $sugar->build_related_list($query, $note);
	}

function get_accounts_from_contact($contact_id, $orderBy = '')
	{
		// First, get the list of IDs.
		$query = "SELECT account_id as id from accounts_contacts where contact_id='$contact_id' AND deleted=0";
		if(!empty($orderBy)){
			$query .= ' ORDER BY ' . $orderBy;	
		}
		$contact = new Contact();



		$account = new Account();



		return $contact->build_related_list($query,$account);
	}

function get_contacts_from_account($account_id, $orderBy = '')
	{
		// First, get the list of IDs.
		$query = "SELECT contact_id as id from accounts_contacts where account_id='$account_id' AND deleted=0";
		if(!empty($orderBy)){
			$query .= ' ORDER BY ' . $orderBy;	
		}
		$contact = new Contact();



		$account = new Account();



		return $account->build_related_list($query,$contact);
	}

function get_related_list($id_list, &$template){
		$list = array();



		foreach($id_list as $id){
		{
			$record = $template->retrieve($id);
			

			if($record != null)
			{
				// this copies the object into the array
				$list[] = $template;
			}
		}
		}
		
		return $list;
	
		
}

function build_relationship_tree(&$contact){
	global $sugar_config;
	$contact->retrieve();



	
	$accounts = get_accounts_from_contact($contact->id);
	$_SESSION['viewable'] = array();
	$_SESSION['viewable']['Accounts'] = array();
	$_SESSION['viewable']['Contacts'] = array();
	if(sizeof($accounts) > 0){
		$_SESSION['account_id'] = $accounts[0]->id;	
	}
	$contacts_in = '';
	$accounts_in = '';
	for($i = 0; $i < sizeof($accounts); $i++){
		$_SESSION['viewable']['Accounts'][$accounts[$i]->id] = $accounts[$i]->id;
		if(empty($accounts_in)){
			$accounts_in .= "('". $accounts[$i]->id. "'";
		}else{
			$accounts_in .= ",'". $accounts[$i]->id. "'";
		}
		if(!isset($sugar_config['portal_view']) || $sugar_config['portal_view'] != 'single_user'){
			$contacts = get_contacts_from_account($accounts[$i]->id);
			
			for($j = 0; $j < sizeof($contacts); $j++){
				$_SESSION['viewable']['Contacts'][$contacts[$j]->id] = $contacts[$j]->id;
				if(empty($contacts_in)){
					$contacts_in .= "('". $contacts[$j]->id. "'";
				}else{
					$contacts_in .= ",'". $contacts[$j]->id. "'";
				}
			}
	}
	}
	if(sizeof($accounts) == 0){
			$_SESSION['viewable']['Contacts'][$contact->id] = $contact->id;
			$contacts_in = "('". $contact->id;
	}
	$contacts_in .= ')';
	$accounts_in .= ')';
	$_SESSION['viewable']['accounts_in'] = $accounts_in;
	$_SESSION['viewable']['contacts_in'] = $contacts_in;
}

function get_contacts_in(){
	return $_SESSION['viewable']['contacts_in'];	
}

function get_accounts_in(){
	return $_SESSION['viewable']['accounts_in'];	
}

function get_module_in($module_name){
	$mod_in = '';
	if(!isset($_SESSION['viewable'][$module_name])){
		return '()';
	}
	if(isset($_SESSION['viewable'][strtolower($module_name).'_in'])){
		return $_SESSION['viewable'][strtolower($module_name).'_in'];	
	}
	foreach($_SESSION['viewable'][$module_name] as $id){
		if(empty($mod_in)){
			$mod_in = "('$id'";	
		}else{
			$mod_in = ",'$id'";	
		}	
	}
	$_SESSION['viewable'][strtolower($module_name).'_in'] = $mod_in;
}

$invalid_contact_fields = array('portal_name'=>1, 'portal_password'=>1, 'portal_active'=>1);
$valid_modules_for_contact = array('Contacts'=>1, 'Cases'=>1, 'Notes'=>1, 'Bugs'=>1, 'Accounts'=>1);




?>
