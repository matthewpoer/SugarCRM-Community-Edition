<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.override.php,v 1.2 2005/02/09 07:08:54 andrew Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_list_strings['contacts_import_fields']['nish_flag'] = 'NISH Rep';
$mod_list_strings['contacts_import_fields']["primary_address_type"] = '1st Address Type';
$mod_list_strings['contacts_import_fields']["alt_address_type"] = '2nd Address Type';

$mod_list_strings['contacts_import_fields']["primary_address_type"] = '1st Address Type';
$mod_list_strings['contacts_import_fields']["primary_address_street"] = "1st Address Street";
$mod_list_strings['contacts_import_fields']["primary_address_street_2"] = "1st Address Street 2";
$mod_list_strings['contacts_import_fields']["primary_address_street_3"] = "1st Address Street 3";
$mod_list_strings['contacts_import_fields']["primary_address_street_4"] = "1st Address Street 4";
$mod_list_strings['contacts_import_fields']["primary_address_city"] = "1st Address City";
$mod_list_strings['contacts_import_fields']["primary_address_state"] = "1st Address State";
$mod_list_strings['contacts_import_fields']["primary_address_postalcode"] = "1st Address Postalcode";
$mod_list_strings['contacts_import_fields']["primary_address_country"] = "1st Address Country";
$mod_list_strings['contacts_import_fields']["alt_address_type"] = '2nd Address Type';
$mod_list_strings['contacts_import_fields']["alt_address_street"] = "2nd Address Street";
$mod_list_strings['contacts_import_fields']["alt_address_street_2"] = "2nd Address Street 2";
$mod_list_strings['contacts_import_fields']["alt_address_street_3"] = "2nd Address Street 3";
$mod_list_strings['contacts_import_fields']["alt_address_street_4"] = "2nd Address Street 4";
$mod_list_strings['contacts_import_fields']["alt_address_city"] = "2nd Address City";
$mod_list_strings['contacts_import_fields']["alt_address_state"] = "2nd Address State";
$mod_list_strings['contacts_import_fields']["alt_address_postalcode"] = "2nd Address Postalcode";
$mod_list_strings['contacts_import_fields']["alt_address_country"] = "2nd Address Country";

$mod_list_strings['accounts_import_fields']["billing_address_type"] = '1st Address Type';
$mod_list_strings['accounts_import_fields']["billing_address_street"] = "1st Address Street";
$mod_list_strings['accounts_import_fields']["billing_address_street_2"] = "1st Address Street 2";
$mod_list_strings['accounts_import_fields']["billing_address_street_3"] = "1st Address Street 3";
$mod_list_strings['accounts_import_fields']["billing_address_street_4"] = "1st Address Street 4";
$mod_list_strings['accounts_import_fields']["billing_address_city"] = "1st Address City";
$mod_list_strings['accounts_import_fields']["billing_address_state"] = "1st Address State";
$mod_list_strings['accounts_import_fields']["billing_address_postalcode"] = "1st Address Postalcode";
$mod_list_strings['accounts_import_fields']["billing_address_country"] = "1st Address Country";
$mod_list_strings['accounts_import_fields']["shipping_address_type"] = '2nd Address Type';
$mod_list_strings['accounts_import_fields']["shipping_address_street"] = "2nd Address Street";
$mod_list_strings['accounts_import_fields']["shipping_address_street_2"] = "2nd Address Street 2";
$mod_list_strings['accounts_import_fields']["shipping_address_street_3"] = "2nd Address Street 3";
$mod_list_strings['accounts_import_fields']["shipping_address_street_4"] = "2nd Address Street 4";
$mod_list_strings['accounts_import_fields']["shipping_address_city"] = "2nd Address City";
$mod_list_strings['accounts_import_fields']["shipping_address_state"] = "2nd Address State";
$mod_list_strings['accounts_import_fields']["shipping_address_postalcode"] = "2nd Address Postalcode";
$mod_list_strings['accounts_import_fields']["shipping_address_country"] = "2nd Address Country";

$mod_list_strings['accounts_import_fields']["alt3_address_type"] = '3rd Address Type';
$mod_list_strings['accounts_import_fields']["alt3_address_street"] = '3rd Address Street';
$mod_list_strings['accounts_import_fields']["alt3_address_city"] = '3rd Address City';
$mod_list_strings['accounts_import_fields']["alt3_address_state"] = '3rd Address State';
$mod_list_strings['accounts_import_fields']["alt3_address_postalcode"] = '3rd Address Postalcode';
$mod_list_strings['accounts_import_fields']["alt3_address_country"] = '3rd Address Country';
$mod_list_strings['accounts_import_fields']["alt4_address_type"] = '4th Address Type';
$mod_list_strings['accounts_import_fields']["alt4_address_street"] = '4th Address Street';
$mod_list_strings['accounts_import_fields']["alt4_address_city"] = '4th Address City';
$mod_list_strings['accounts_import_fields']["alt4_address_state"] = '4th Address State';
$mod_list_strings['accounts_import_fields']["alt4_address_postalcode"] = '4th Address Postalcode';
$mod_list_strings['accounts_import_fields']["alt4_address_country"] = '4th Address Country';
$mod_list_strings['accounts_import_fields']["nish_rep_id"] = 'NISH Rep';
$mod_list_strings['accounts_import_fields']["operations_rep_id"] = 'Operations Rep ID';
$mod_list_strings['accounts_import_fields']["contract_rep_id"] = 'Contract Rep ID';
$mod_list_strings['accounts_import_fields']["account_rep_id"] = 'Account Rep ID';


$mod_list_strings['opportunities_import_fields']['procurement_agency_id'] = 'Procurement Agency';
$mod_list_strings['opportunities_import_fields']["assigned_from_id"] = 'Assigned From';
$mod_list_strings['opportunities_import_fields']['scope'] = 'Scope';
$mod_list_strings['opportunities_import_fields']['current_contractor_id'] = 'Current Contractor ID';
$mod_list_strings['opportunities_import_fields']['sol_URL_1'] = 'Sol URL 1';
$mod_list_strings['opportunities_import_fields']['comments'] = 'Comments';

?>
