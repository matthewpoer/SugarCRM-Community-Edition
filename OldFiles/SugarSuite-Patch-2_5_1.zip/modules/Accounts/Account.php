<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: Account.php,v 1.120 2005/02/23 21:08:41 robert Exp $
 * Description:  Defines the Account SugarBean Account entity with the necessary
 * methods and variables.
 ********************************************************************************/

include_once('config.php');
require_once('include/logging.php');
require_once('include/database/PearDatabase.php');
require_once('data/SugarBean.php');
require_once('modules/Contacts/Contact.php');
require_once('modules/Opportunities/Opportunity.php');
require_once('modules/Cases/Case.php');
require_once('modules/Calls/Call.php');
require_once('modules/Notes/Note.php');
require_once('modules/Emails/Email.php');
require_once('modules/Bugs/Bug.php');

// Account is used to store account information.
class Account extends SugarBean {
	var $field_name_map = array();
	// Stored fields
	var $date_entered;
	var $date_modified;
	var $modified_user_id;
	var $assigned_user_id;
	var $annual_revenue;
	var $billing_address_street;
	var $billing_address_city;
	var $billing_address_state;
	var $billing_address_country;
	var $billing_address_postalcode;
	var $description;
	var $email1;
	var $email2;
	var $employees;
	var $id;
	var $industry;
	var $name;
	var $ownership;
	var $parent_id;
	var $phone_alternate;
	var $phone_fax;
	var $phone_office;
	var $rating;
	var $shipping_address_street;
	var $shipping_address_city;
	var $shipping_address_state;
	var $shipping_address_country;
	var $shipping_address_postalcode;
	var $sic_code;
	var $ticker_symbol;
	var $account_type;
	var $website;

	var $created_by;
	var $created_by_name;
	var $modified_by_name;

	// These are for related fields
	var $bug_id;
	var $opportunity_id;
	var $case_id;
	var $contact_id;
	var $task_id;
	var $note_id;
	var $meeting_id;
	var $call_id;
	var $email_id;
	var $member_id;
	var $parent_name;
	var $assigned_user_name;
	var $account_id = '';
	var $account_name = '';







	var $table_name = "accounts";





	var $object_name = "Account";

	var $new_schema = true;

	var $column_fields = Array(
		"annual_revenue"
		,"billing_address_street"
		,"billing_address_city"
		,"billing_address_state"
		,"billing_address_postalcode"
		,"billing_address_country"
		,"date_entered"
		,"date_modified"
		,"modified_user_id"
		,"assigned_user_id"
		,"description"
		,"email1"
		,"email2"
		,"employees"
		,"id"
		,"industry"
		,"name"
		,"ownership"
		,"parent_id"
		,"phone_alternate"
		,"phone_fax"
		,"phone_office"
		,"rating"
		,"shipping_address_street"
		,"shipping_address_city"
		,"shipping_address_state"
		,"shipping_address_postalcode"
		,"shipping_address_country"
		,"sic_code"
		,"ticker_symbol"
		,"account_type"
		,"website"
		, "created_by"



		);

/*
	DO NOT DEPEND ON THIS THIS DATA STRUCTURE
	IT IS ONLY TEMPORARY AND MAY NOT BE SUmPPORTED IN FUTURE RELEASES
*/
		var $field_defs = array(
		array("name"=>"annual_revenue",
        		"vname"=>'LBL_ANNUAL_REVENUE',"type"=>"int","len"=>"255" ),



		array("name"=> "billing_address_street",
        		"vname"=>'LBL_BILLING_ADDRESS_STREET',"type"=>"varchar","len"=>"255"),
		array("name"=> "billing_address_city",
        		"vname"=>'LBL_BILLING_ADDRESS_CITY',"type"=>"varchar","len"=>"255"),
		array("name"=> "billing_address_state",
        		"vname"=>'LBL_BILLING_ADDRESS_STATE',"type"=>"varchar","len"=>"255"),
		array("name"=> "billing_address_postalcode",
        		"vname"=>'LBL_BILLING_ADDRESS_POSTALCODE',"type"=>"varchar","len"=>"255"),
		array("name"=> "billing_address_country",
        		"vname"=>'LBL_BILLING_ADDRESS_COUNTRY',"type"=>"varchar","len"=>"255"),
        	array('name'=>'date_entered','vname'=>'LBL_DATE_ENTERED','type'=>'date'),
        	array('name'=>'date_modified','vname'=>'LBL_DATE_MODIFIED','type'=>'date'),
        	array('name'=>'assigned_user_id','rname'=>'user_name','id_name'=>'assigned_user_id','vname'=>'LBL_ASSIGNED_TO','type'=>'assigned_user_name','table'=>'users','isnull'=>'false'),
		      array('name'=>'created_by','rname'=>'user_name',
							'id_name'=>'created_by','vname'=>'LBL_CREATED',
							'type'=>'assigned_user_name','table'=>'created_by_users',
							'isnull'=>'false'),
		     array('name'=>'modified_user_id','rname'=>'user_name',
							'id_name'=>'modified_user_id','vname'=>'LBL_MODIFIED',
							'type'=>'assigned_user_name','table'=>'modified_user_id_users',
							'isnull'=>'false'),
		array("name"=> "description",
        		"vname"=>'LBL_DESCRIPTION',"type"=>"varchar","len"=>"255"),
		array("name"=> "email1","vname"=>'LBL_EMAIL',"type"=>"email"),
		array("name"=>"email2","vname"=>'LBL_OTHER_EMAIL_ADDRESS',"type"=>"email"),
		array("name"=>"employees",
        		"vname"=>'LBL_EMPLOYEES',"type"=>"num","len"=>"255"),
		array("name"=>"industry", "vname"=>"LBL_INDUSTRY",'type'=>'enum',
				'options'=>'industry_dom'),
		array('name'=>'name', "type"=>"varchar", 'vname'=>'LBL_NAME'),
		array("name"=>"ownership",
        		"vname"=>'LBL_OWNERSHIP',"type"=>"varchar","len"=>"255"),
/*
		array('name'=>'parent_name','rname'=>'name','id_name'=>'parent_id','vname'=>'Member Of','type'=>'relate','table'=>'accounts','isnull'=>'true','module'=>'Accounts'),
*/
		array('name'=>'account_name','rname'=>'name','id_name'=>'account_id','vname'=>'LBL_MEMBER_OF','type'=>'relate','table'=>'parent_accounts','isnull'=>'true','module'=>'Accounts', 'massupdate'=>false),
		array("name"=>"phone_alternate",
			'vname'=>'LBL_PHONE_ALT','type'=>'phone'),
		array("name"=> "phone_fax",
			'vname'=>'LBL_PHONE_FAX','type'=>'phone'),
		array("name"=> "phone_office",
			'vname'=>'LBL_PHONE_OFFICE','type'=>'phone'),
		array("name"=>"rating",
        		"vname"=>"LBL_RATING","type"=>"varchar","len"=>"255"),
		array("name"=> "shipping_address_street",
        		"vname"=>'LBL_SHIPPING_ADDRESS_STREET',"type"=>"varchar","len"=>"255"),
		array("name"=> "shipping_address_city",
        		"vname"=>'LBL_SHIPPING_ADDRESS_CITY',"type"=>"varchar","len"=>"255"),
		array("name"=> "shipping_address_state",
        		"vname"=>'LBL_SHIPPING_ADDRESS_STATE',"type"=>"varchar","len"=>"255"),
		array("name"=> "shipping_address_postalcode",
        		"vname"=>'LBL_SHIPPING_ADDRESS_POSTALCODE',"type"=>"varchar","len"=>"255"),
		array("name"=> "shipping_address_country",
        		"vname"=>'LBL_SHIPPING_ADDRESS_COUNTRY',"type"=>"varchar","len"=>"255"),
		array("name"=> "sic_code",
        		"vname"=>'LBL_SIC_CODE',"type"=>"varchar","len"=>"255"),
		array("name"=> "ticker_symbol",
        		"vname"=>'LBL_TICKER_SYMBOL',"type"=>"varchar","len"=>"255"),
		array("name"=> "account_type",'vname'=>'LBL_TYPE','type'=>'enum',
				'options'=>'account_type_dom' ),
		array("name"=> "website",
        		"vname"=>'LBL_WEBSITE',"type"=>"varchar","len"=>"255"),
);

	// This is used to retrieve related fields from form posts.
	var $additional_column_fields = Array('assigned_user_name', 'assigned_user_id', 'opportunity_id', 'bug_id', 'case_id', 'contact_id', 'task_id', 'note_id', 'meeting_id', 'call_id', 'email_id', 'parent_name', 'member_id'



	);

	// This is the list of fields that are in the lists.
	var $list_fields = Array('id', 'name', 'website', 'phone_office', 'assigned_user_name', 'assigned_user_id'
	, 'billing_address_street'
	, 'billing_address_city'
	, 'billing_address_state'
	, 'billing_address_postalcode'
	, 'billing_address_country'
	, 'shipping_address_street'
	, 'shipping_address_city'
	, 'shipping_address_state'
	, 'shipping_address_postalcode'
	, 'shipping_address_country'




		);

	// This is the list of fields that are required.
	var $required_fields =  array("name"=>1);

	function Account() {
		$this->log =LoggerManager::getLogger('account');
		$this->db = new PearDatabase();
                $custom = new CustomFields();
                $custom->setFieldDefs($this); 
		foreach ($this->field_defs as $field)
		{
			$this->field_name_map[$field['name']] = $field;
		}




	}

	function create_tables () {
		$query = 'CREATE TABLE '.$this->table_name.' ( ';
		$query .='id char(36) NOT NULL';
		$query .=', date_entered datetime NOT NULL';
		$query .=', date_modified datetime NOT NULL';
		$query .=', modified_user_id char(36) NOT NULL';
		$query .=', assigned_user_id char(36)';
		$query .=', created_by char(36)';
		$query .=', name char(150)';
		$query .=', parent_id char(36)';
		$query .=', account_type char(25)';
		$query .=', industry char(25)';
		$query .=', annual_revenue char(25)';
		$query .=', phone_fax char(25)';
		$query .=', billing_address_street char(150)';
		$query .=', billing_address_city char(100)';
		$query .=', billing_address_state char(100)';
		$query .=', billing_address_postalcode char(20)';
		$query .=', billing_address_country char(100)';
		$query .=', description text';
		$query .=', rating char(25)';
		$query .=', phone_office char(25)';
		$query .=', phone_alternate char(25)';
		$query .=', email1 char(100)';
		$query .=', email2 char(100)';
		$query .=', website char(255)';
		$query .=', ownership char(100)';
		$query .=', employees char(10)';
		$query .=', sic_code char(10)';
		$query .=', ticker_symbol char(10)';
		$query .=', shipping_address_street char(150)';
		$query .=', shipping_address_city char(100)';
		$query .=', shipping_address_state char(100)';
		$query .=', shipping_address_postalcode char(20)';
		$query .=', shipping_address_country char(100)';
		$query .=', deleted bool NOT NULL default 0';



		$query .=', PRIMARY KEY ( id ) )';

		$this->db->query($query);

		$this->create_index("create index idx_accnt_id_del on accounts ( id , deleted )");



	}

	function drop_tables () {
		$query = 'DROP TABLE IF EXISTS '.$this->table_name;



		$this->db->query($query);

	//TODO Clint 4/27 - add exception handling logic here if the table can't be dropped.

	}

	function get_summary_text()
	{
		return $this->name;
	}

	/** Returns a list of the associated accounts who are member orgs
	 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc..
	 * All Rights Reserved..
	 * Contributor(s): ______________________________________..
	*/
	function get_member_accounts()
	{
		// First, get the list of IDs.
		$query = "SELECT a1.id from accounts as a1, accounts as a2 where a2.id=a1.parent_id AND a2.id='$this->id' AND a1.deleted=0";

		return $this->build_related_list($query, new Account());
	}

	function get_bugs()
	{
		// First, get the list of IDs.
		$query = "SELECT bug_id as id from accounts_bugs where account_id='$this->id' AND deleted=0";

		return $this->build_related_list($query, new Bug());
	}

	/** Returns a list of the associated contacts
	 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc..
	 * All Rights Reserved..
	 * Contributor(s): ______________________________________..
	*/
	function get_contacts()
	{
		// First, get the list of IDs.
		$query = "SELECT contact_id as id from accounts_contacts where account_id='$this->id' AND deleted=0";

		return $this->build_related_list($query, new Contact());
	}

	/** Returns a list of the associated opportunities
	 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc..
	 * All Rights Reserved..
	 * Contributor(s): ______________________________________..
	*/
	function get_opportunities()
	{
		// First, get the list of IDs.
		$query = "SELECT opportunity_id as id from accounts_opportunities where account_id='$this->id' AND deleted=0";

		return $this->build_related_list($query, new Opportunity());
	}

	function get_leads()
	{
		// First, get the list of IDs.
		$query = "SELECT id  from leads where account_id='$this->id' AND deleted=0";

		return $this->build_related_list($query, new Lead());
	}

	/** Returns a list of the associated cases
	 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc..
	 * All Rights Reserved..
	 * Contributor(s): ______________________________________..
	*/
	function get_cases()
	{
		// First, get the list of IDs.
		$query = "SELECT id from cases where account_id='$this->id' AND deleted=0";

		return $this->build_related_list($query, new aCase());
	}

	/** Returns a list of the associated tasks
	 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc..
	 * All Rights Reserved..
	 * Contributor(s): ______________________________________..
	*/
	function get_tasks()
	{
		// First, get the list of IDs.
		$query = "SELECT id from tasks where parent_id='$this->id' AND deleted=0";

		return $this->build_related_list($query, new Task());
	}

	/** Returns a list of the associated notes
	 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc..
	 * All Rights Reserved..
	 * Contributor(s): ______________________________________..
	*/
	function get_notes()
	{
		// First, get the list of IDs.
		$query = "SELECT id from notes where parent_id='$this->id' AND deleted=0";

		return $this->build_related_list($query, new note());
	}

	/** Returns a list of the associated meetings
	 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc..
	 * All Rights Reserved..
	 * Contributor(s): ______________________________________..
	*/
	function get_meetings()
	{
		// First, get the list of IDs.
		$query = "SELECT id from meetings where parent_id='$this->id' AND deleted=0";

		return $this->build_related_list($query, new Meeting());
	}

	/** Returns a list of the associated calls
	 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc..
	 * All Rights Reserved..
	 * Contributor(s): ______________________________________..
	*/
	function get_calls()
	{
		// First, get the list of IDs.
		$query = "SELECT id from calls where parent_id='$this->id' AND deleted=0";

		return $this->build_related_list($query, new Call());
	}

	/** Returns a list of the associated emails
	 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc..
	 * All Rights Reserved..
	 * Contributor(s): ______________________________________..
	*/
	function get_emails()
	{
		// First, get the list of IDs.
		$query = "SELECT id from emails where parent_id='$this->id' AND deleted=0";

		return $this->build_related_list($query, new Email());
	}





















































	function save_relationship_changes($is_update)
    {
    	if(!empty($this->member_id))
    	{
    		$this->set_account_member_account_relationship($this->id, $this->member_id);
    	}
    	if(!empty($this->opportunity_id))
    	{
    		$this->clear_account_opportunity_relationship('',$this->opportunity_id);
    		$this->set_account_opportunity_relationship($this->id, $this->opportunity_id);
    	}
    	if(!empty($this->case_id))
    	{
    		$this->set_account_case_relationship($this->id, $this->case_id);
    	}
		if(!empty($this->contact_id))
    	{
    		$this->set_account_contact_relationship($this->id, $this->contact_id);
    	}
    	if(!empty($this->task_id))
    	{
    		$this->set_account_task_relationship($this->id, $this->task_id);
    	}
    	if(!empty($this->bug_id))
    	{
    		$this->set_account_bug_relationship($this->id, $this->bug_id);
    	}
    	if(!empty($this->note_id))
    	{
    		$this->set_account_note_relationship($this->id, $this->note_id);
    	}
    	if(!empty($this->meeting_id))
    	{
    		$this->set_account_meeting_relationship($this->id, $this->meeting_id);
    	}
    	if(!empty($this->call_id))
    	{
    		$this->set_account_call_relationship($this->id, $this->call_id);
    	}
    	if(!empty($this->email_id))
    	{
    		$this->set_account_email_relationship($this->id, $this->email_id);
    	}







    }

	function set_account_opportunity_relationship($account_id, $opportunity_id)
	{
		$query = "insert into accounts_opportunities set id='".create_guid()."', opportunity_id='$opportunity_id', account_id='$account_id'";
		$this->db->query($query,true,"Error setting account to opportunity relationship: ");
	}

	function clear_account_opportunity_relationship($account_id='', $opportunity_id='')
	{
		if (empty($opportunity_id)) $opp_where = '';
		else $opp_where = " and opportunity_id = '$opportunity_id' ";
		if (empty($account_id)) $acc_where = '';
		else $acc_where = " and account_id = '$account_id' ";

		$query = "delete from accounts_opportunities where deleted=0 ".$opp_where.$acc_where;
		$this->db->query($query,true,"Error clearing account to opportunity relationship: ");
	}

	function set_account_bug_relationship($account_id, $bug_id)
	{
		$query = "insert into accounts_bugs set id='".create_guid()."', bug_id='$bug_id', account_id='$account_id'";
		$this->db->query($query,true,"Error setting account to bug relationship: ");
	}

	function clear_account_bug_relationship($account_id)
	{
		$query = "delete from accounts_bugs where account_id='$account_id' and deleted=0";
		$this->db->query($query,true,"Error clearing account to bug relationship: ");
	}

	function set_account_case_relationship($account_id, $case_id)
	{
		$query = "update cases set account_id='$account_id' where id='$case_id'";
		$this->db->query($query,true,"Error setting account to case relationship: ");
	}

	function clear_account_case_relationship($account_id='', $case_id='')
	{
		if (empty($case_id)) $where = '';
		else $where = " and id = '$case_id'";
		$query = "delete from cases where account_id='$account_id' and deleted=0 ".$where;
		$this->db->query($query,true,"Error clearing account to case relationship: ");
	}

	function set_account_contact_relationship($account_id, $contact_id)
	{
		$query = "select account_id from accounts_contacts where contact_id='$contact_id' and account_id='$account_id' and deleted=0" ;
		$result =& $this->db->query($query);
		if($this->db->getRowCount($result) > 0){
			$this->log->info('attempting to create an account contact relationship that already exists'	);
			return;
		}
		// clear any relationship for this contact_id
		$this->clear_contact_relationship($contact_id);

		$query = "insert into accounts_contacts set id='".create_guid()."', contact_id='$contact_id', account_id='$account_id'";
		$this->db->query($query,true,"Error setting account to contact relationship: "."<BR>$query");
	}
	function set_contact_relationship($self_id, $contact_id){
		$this->set_account_contact_relationship($self_id, $contact_id);	
	}

	function clear_account_contact_relationship($account_id)
	{
		$query = "delete from accounts_contacts where account_id='$account_id' and deleted=0";
		$this->db->query($query,true,"Error clearing account to contact relationship: ");
	}

	function clear_contact_relationship($contact_id)
	{
		$query = "delete from accounts_contacts where contact_id='$contact_id' and deleted=0";
		$this->db->query($query,true,"Error clearing a contact relationship: ");
	}

	function set_account_task_relationship($account_id, $task_id)
	{
		$query = "UPDATE tasks set parent_id='$account_id', parent_type='Accounts' where id='$task_id'";
		$this->db->query($query,true,"Error setting account to task relationship: ");
	}

	function clear_account_task_relationship($account_id)
	{
		$query = "UPDATE tasks set parent_id='', parent_type='' where parent_id='$account_id' and deleted=0";
		$this->db->query($query,true,"Error clearing account to task relationship: ");
	}

	function set_account_note_relationship($account_id, $note_id)
	{
		$query = "UPDATE notes set parent_id='$account_id', parent_type='Accounts' where id='$note_id'";
		$this->db->query($query,true,"Error setting account to note relationship: ");
	}

	function clear_account_note_relationship($account_id)
	{
		$query = "UPDATE notes set parent_id='', parent_type='' where parent_id='$account_id' and deleted=0";
		$this->db->query($query,true,"Error clearing account to note relationship: ");
	}

	function set_account_meeting_relationship($account_id, $meeting_id)
	{
		$query = "UPDATE meetings set parent_id='$account_id', parent_type='Accounts' where id='$meeting_id'";
		$this->db->query($query,true,"Error setting account to meeting relationship: ");
	}

	function clear_account_meeting_relationship($account_id)
	{
		$query = "UPDATE meetings set parent_id='', parent_type='' where parent_id='$account_id' and deleted=0";
		$this->db->query($query,true,"Error clearing account to meeting relationship: ");
	}

	function set_account_call_relationship($account_id, $call_id)
	{
		$query = "UPDATE calls set parent_id='$account_id', parent_type='Accounts' where id='$call_id'";
		$this->db->query($query,true,"Error setting account to call relationship: ");
	}

	function clear_account_call_relationship($account_id)
	{
		$query = "UPDATE calls set parent_id='', parent_type='' where parent_id='$account_id' and deleted=0";
		$this->db->query($query,true,"Error clearing account to call relationship: ");
	}

	function set_account_email_relationship($account_id, $email_id)
	{
		$query = "UPDATE emails set parent_id='$account_id', parent_type='Accounts' where id='$email_id'";
		$this->db->query($query,true,"Error setting account to email relationship: ");
	}

	function clear_account_email_relationship($account_id)
	{
		$query = "UPDATE emails set parent_id='', parent_type='' where parent_id='$account_id' and deleted=0";
		$this->db->query($query,true,"Error clearing account to email relationship: ");
	}

	function set_account_member_account_relationship($account_id, $member_id)
	{
		$query = "update accounts set parent_id='$account_id' where id='$member_id' and deleted=0";
		$this->db->query($query,true,"Error setting account to member account relationship: ");
	}

	function clear_account_account_relationship($account_id)
	{
		$query = "UPDATE accounts set parent_id='' where parent_id='$account_id' and deleted=0";
		$this->db->query($query,true,"Error clearing account to account relationship: ");
	}

	function clear_account_member_account_relationship($account_id)
	{
		$query = "UPDATE accounts set parent_id='' where id='$account_id' and deleted=0";
		$this->db->query($query,true,"Error clearing account to member account relationship: ");
	}

	function mark_relationships_deleted($id)
	{
		$this->clear_account_bug_relationship($id);
		$this->clear_account_account_relationship($id);
		$this->clear_account_contact_relationship($id);
		$this->clear_account_opportunity_relationship($id);
		$this->clear_account_case_relationship($id);
		$this->clear_account_task_relationship($id);
		$this->clear_account_note_relationship($id);
		$this->clear_account_meeting_relationship($id);
		$this->clear_account_call_relationship($id);
		$this->clear_account_email_relationship($id);



	}

	// This method is used to provide backward compatibility with old data that was prefixed with http://
	// We now automatically prefix http://
	function remove_redundant_http()
	{
		if(eregi("http://", $this->website))
		{
			$this->website = substr($this->website, 7);
		}
	}

	function fill_in_additional_list_fields()
	{
	// Fill in the assigned_user_name
	//	$this->assigned_user_name = get_assigned_user_name($this->assigned_user_id);




		$this->remove_redundant_http();
	}

	function fill_in_additional_detail_fields()
	{
		// Fill in the assigned_user_name
		$this->assigned_user_name = get_assigned_user_name($this->assigned_user_id);




		$query = "SELECT a1.name from accounts as a1, accounts as a2 where a1.id = a2.parent_id and a2.id = '$this->id' and a1.deleted=0";
		$result = $this->db->query($query,true," Error filling in additional detail fields: ");

		// Get the id and the name.
		$row = $this->db->fetchByAssoc($result);

		if($row != null)
		{
			$this->parent_name = $row['name'];
		}
		else
		{
			$this->parent_name = '';
		}

		$this->created_by_name = get_assigned_user_name($this->created_by);
		$this->modified_by_name = get_assigned_user_name($this->modified_user_id);

		$this->remove_redundant_http();
	}
	function get_list_view_data(){
		$temp_array = $this->get_list_view_array();
		$temp_array["ENCODED_NAME"]=$this->name;
//		$temp_array["ENCODED_NAME"]=htmlspecialchars($this->name, ENT_QUOTES);
		if(!empty($this->billing_address_state))
		{
			$temp_array["CITY"] = $this->billing_address_city . ', '. $this->billing_address_state;
		}
		else
		{
			$temp_array["CITY"] = $this->billing_address_city;
		}
		$temp_array["BILLING_ADDRESS_STREET"]  = preg_replace("/[\r]/",'',$this->billing_address_street);
		$temp_array["SHIPPING_ADDRESS_STREET"] = preg_replace("/[\r]/",'',$this->shipping_address_street);
		$temp_array["BILLING_ADDRESS_STREET"]  = preg_replace("/[\n]/",'\n',$temp_array["BILLING_ADDRESS_STREET"] );
		$temp_array["SHIPPING_ADDRESS_STREET"] = preg_replace("/[\n]/",'\n',$temp_array["SHIPPING_ADDRESS_STREET"] );
		return $temp_array;
	}
	/**
		builds a generic search based on the query string using or
		do not include any $this-> because this is called on without having the class instantiated
	*/
	function build_generic_where_clause ($the_query_string) {

	$where_clauses = Array();
	$the_query_string = addslashes($the_query_string);
	array_push($where_clauses, "accounts.name like '$the_query_string%'");
	if (is_numeric($the_query_string)) {
		array_push($where_clauses, "accounts.phone_alternate like '%$the_query_string%'");
		array_push($where_clauses, "accounts.phone_fax like '%$the_query_string%'");
		array_push($where_clauses, "accounts.phone_office like '%$the_query_string%'");
	}

	$the_where = "";
	foreach($where_clauses as $clause)
	{
		if(!empty($the_where)) $the_where .= " or ";
		$the_where .= $clause;
	}


	return $the_where;
}

	function create_export_query(&$order_by, &$where)
        {
			$query = "SELECT
					accounts.*,
                    users.user_name as assigned_user_name ";



                    $query .= "FROM accounts ";





            $query .= "LEFT JOIN users
                    	ON accounts.assigned_user_id=users.id ";




            $where_auto = " users.status='ACTIVE'
            AND accounts.deleted=0 ";

            if($where != "")
                    $query .= "where ($where) AND ".$where_auto;
            else
                    $query .= "where ".$where_auto;

            if(!empty($order_by))
                    $query .= " ORDER BY $order_by";

            return $query;
        }

        function create_list_query(&$order_by, &$where)
        {
		$custom_fields = new CustomFields();
                $query = "SELECT ";
		$query .= $custom_fields->get_list_query_custom_select($this);
                $query .= "
                    users.user_name as assigned_user_name,
                    accounts.*";



             $query .= " FROM  accounts ";





			 $query .= "LEFT JOIN users
                    	ON accounts.assigned_user_id=users.id ";



		$query .= $custom_fields->get_list_query_custom_from($this);

            $where_auto = " accounts.deleted=0 ";

            if($where != "")
                    $query .= "where ($where) AND ".$where_auto;
            else
                    $query .= "where ".$where_auto;

            if(!empty($order_by))
                    $query .= " ORDER BY $order_by";
            return $query;
        }

	function parse_additional_headers(&$list_form, $xTemplateSection) {

	}

	function list_view_parse_additional_sections(&$list_form, $xTemplateSection) {
		return $list_form;
	}


	function set_notification_body($xtpl, $account)
	{
		$xtpl->assign("ACCOUNT_NAME", $account->name);
		$xtpl->assign("ACCOUNT_TYPE", $account->account_type);
		$xtpl->assign("ACCOUNT_DESCRIPTION", $account->description);

		return $xtpl;
	}


}



?>
