Sugar Suite v4.0.1e
March 13, 2006

For a list of new features and other important information 
about Sugar Suite 4.0.1e, please see the ReleaseNotes.doc file.

Our goal continues to be to build the customer relationship management system 
that you have always wanted, so your input is vital.

To share ideas with the Sugar Community, ask questions, find answers and submit 
feedback, please visit our Sugar Forums at http://forums.sugarcrm.com.

Check out http://www.sugarcrm.com for more details on acquiring the Sugar Suite,
the latest product roadmap, support forums, detailed product information and 
much more.  We hope you find this a useful tool for building your business.

Enjoy! 
The Sugar Team  
