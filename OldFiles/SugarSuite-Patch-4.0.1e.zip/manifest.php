<?php
// created: 2006-03-13 19:20:13
$manifest = array (
  'acceptable_sugar_flavors' => 
  array (
    0 => 'OS',
  ),
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '^4\\.0\\.1[abcd]?$',
    ),
  ),
  'author' => 'SugarCRM, Inc.',
  'copy_files' => 
  array (
    'from_dir' => 'SugarSuite-Patch-4.0.1e',
    'to_dir' => '',
    'force_copy' => 
    array (
    ),
  ),
  'description' => 'Sugar 4.0.1e upgrade',
  'icon' => '',
  'is_uninstallable' => false,
  'name' => 'SugarSuite',
  'published_date' => '2006-03-13 19:20:13',
  'type' => 'patch',
  'version' => '4.0.1e',
);
?>
