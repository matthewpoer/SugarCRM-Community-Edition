<?php
if(substr($sugar_version,0,5) == "4.0.1")
{
    if(empty($GLOBALS['sugarEntry']))
        $GLOBALS['sugarEntry'] = true;
}
else if(!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');

}
/**
 * This script executes after the files are copied during the install.
 *
 * LICENSE: The contents of this file are subject to the SugarCRM Professional
 * End User License Agreement("License") which can be viewed at
 * http://www.sugarcrm.com/EULA.  By installing or using this file, You have
 * unconditionally agreed to the terms and conditions of the License, and You
 * may not use this file except in compliance with the License.  Under the
 * terms of the license, You shall not, among other things: 1) sublicense,
 * resell, rent, lease, redistribute, assign or otherwise transfer Your
 * rights to the Software, and 2) use the Software for timesharing or service
 * bureau purposes such as hosting the Software for commercial gain and/or for
 * the benefit of a third party.  Use of the Software may be subject to
 * applicable fees and any use of the Software without first paying applicable
 * fees is strictly prohibited.  You do not have the right to remove SugarCRM
 * copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright(C) 2005 SugarCRM, Inc.; All Rights Reserved.
 * 

 */


if(!defined('sugarEntry'))define('sugarEntry', true);

function upgradeSearchForms() {
  require_once('include/utils/file_utils.php');


  $backup_dir = "450_post_install_fix_backups/pre_search_form_fix/";
  $cache_dir = create_cache_directory($backup_dir);
  
  $module_dirs = get_module_dir_list();
  foreach($module_dirs as $dir) {
    if($dir == 'Notes' || $dir == 'Employees' || $dir == 'ProductTemplates' || $dir = 'Emails') continue;
    if(file_exists("modules/$dir/SearchForm.html")) {
      // read in the contents
      $file = fopen("modules/$dir/SearchForm.html", 'r');
      $contents = fread($file, filesize("modules/$dir/SearchForm.html")); 
      fclose($file);
      
      // being FIX
      // start removal
      $pattern = array('/<\s*form.*>/Uis', // remove all <form> and </form> tags
                 '/<\/\s*form\s*>/Uis', 
                 '/\{JAVASCRIPT\}/',  // remove {JAVASCRIPT} 
                 '/<\s*input\s*[;\(\)\._-\{\}\s\w=\'"]*?name\s*=\s*[\'"]{1}action[\'"]{1}[^>]*>/Uis', // remove <input action>
                 '/<\s*input\s*[;\(\)\._-\{\}\s\w=\'"]*?name\s*=\s*[\'"]{1}module[\'"]{1}[^>]*>/Uis', // remove <input module>
                 '/<\s*input\s*[;\(\)\._-\{\}\s\w=\'"]*?name\s*=\s*[\'"]{1}query[\'"]{1}[^>]*>/Uis', // remove <input query>
                 '/<\s*input\s*[;\(\)\._-\{\}\s\w=\'"]*?value\s*=\s*[\'"]{1}\s*\{APP\.LBL_SEARCH_BUTTON_LABEL\}\s*[\'"]{1}[^>]*>/Uis', // remove <input Search button>
                 '/<\s*input\s*[;\(\)\._-\{\}\s\w=\'"]*?value\s*=\s*[\'"]{1}\s*\{APP\.LBL_CLEAR_BUTTON_LABEL\}\s*[\'"]{1}[^>]*>/Uis', // remove <input clear button>
                 '/<\s*a\s+[^>]*>\s*\{ADVANCED_SEARCH_PNG\}\s*<\/a>/Uis', // remove basic / advanced search links
                 '/<\s*a\s+[^>]*>\s*\{APP\.LNK_ADVANCED_SEARCH\}\s*<\/a>/Uis', // remove basic / advanced search links
                 '/<\s*a\s+[^>]*>\s*\{BASIC_SEARCH_PNG\}\s*<\/a>/Uis', // remove basic / advanced search links
                 '/<\s*a\s+[^>]*>\s*\{APP\.LNK_BASIC_SEARCH\}\s*<\/a>/Uis', // remove basic / advanced search links
                );
      $contents = preg_replace($pattern, '', $contents);
      // end removal
      
      // place style attribute on table tags
      $pattern = '/(<\s*table\s*[%;\(\)\._-\{\}\s\w=\'"]*?)(class\s*=\s*[\'"]{1}tabForm[\'"]{1}[^>]*>)/Uis'; // remove <input action>
      $contents = preg_replace($pattern, '\1 style="border-top: 0px none; margin-bottom: 4px" \2', $contents);
      // end style
        
      // append _basic to all search inputs in the basic search form section
      $beginBasic = strpos($contents, '<!-- BEGIN: main -->');
      $endBasic = strpos($contents, '<!-- END: main -->');
      $basicContents = substr($contents, $beginBasic, $endBasic - $beginBasic);

      $pattern = '/(<\s*input\s*[;\(\)\._-\{\}\s\w=\'"]*?name\s*=\s*[\'"]{1})([\w_\s]*)(?<!_basic)([\'"]{1}[^>]*>)/Uis'; // match all inputs
      $basicContents = preg_replace($pattern, '\1\2_basic\3', $basicContents);

      $contents = substr_replace($contents, $basicContents, $beginBasic, $endBasic - $beginBasic);
      // END FIX

      create_cache_directory("{$backup_dir}modules/$dir/");
      copy("modules/$dir/SearchForm.html", "${cache_dir}modules/$dir/SearchForm.html");	

      //write file back out
      $file = fopen("modules/$dir/SearchForm.html", 'w');
      fwrite($file, $contents);
      fclose($file);
    }
  }
}


?>