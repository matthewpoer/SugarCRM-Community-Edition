<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * 
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and 
 * (ii) the SugarCRM copyright notice 
 * in the same form as they appear in the distribution.  See full license for requirements.
 * 
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: c:\\temp\\cvs_main/sugar_lang/modules/Opportunities/language/fi_fi.lang.php,v 1.1 2004/12/07 20:39:57 msuominen Exp $
 * Description:  Defines the Finnish language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Finnish language file for Sugar Sales 2.0.1a
 * by Markku Suominen (markku.suominen@antamis.com) 
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Myyntimahdollisuudet',
  'LBL_MODULE_TITLE' => 'Myyntimahdollisuudet',
  'LBL_SEARCH_FORM_TITLE' => 'Hae myyntimahdollisuus',
  'LBL_LIST_FORM_TITLE' => 'Lista myyntimahdollisuuksista',
  'LBL_OPPORTUNITY_NAME' => 'Mahdollisuuden nimi:',
  'LBL_OPPORTUNITY' => 'Myyntimahdollisuus:',
  'LBL_NAME' => 'Mahdollisuuden nimi',
  'LBL_INVITEE' => 'Kontaktit',
  'LBL_LIST_OPPORTUNITY_NAME' => 'Myyntimahdollisuus',
  'LBL_LIST_ACCOUNT_NAME' => 'Asiakkaan nimi',
  'LBL_LIST_AMOUNT' => 'Summa',
  'LBL_LIST_DATE_CLOSED' => 'Sulje',
  'LBL_LIST_SALES_STAGE' => 'Myynnin tila',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_sales_stage' => 'LBL_LIST_SALES_STAGE',
  'db_name' => 'LBL_NAME',
  'db_amount' => 'LBL_LIST_AMOUNT',
  'db_date_closed' => 'LBL_LIST_DATE_CLOSED',
//END DON'T CONVERT
  'UPDATE' => 'Myyntimahdollisuus - valuutan p�ivitys',
  'UPDATE_DOLLARAMOUNTS' => 'P�ivit� USD summat',
  'UPDATE_VERIFY' => 'Vahvista m��r�t',
  'UPDATE_VERIFY_TXT' => 'Varmistaa ett� myyntimahdollisuuksiin sy�tetyt luvut sis�lt�v�t vain numeroita (0-9) ja desimaalierottimen (.)',
  'UPDATE_FIX' => 'Korjaa summat',
  'UPDATE_FIX_TXT' => 'Toiminto yritt�� korjata virheelliset summat luomalla voimassaolevan desimaalin nykyisest� summasta. Toiminto tekee varmuuskopion muokatut summat tietokannan kentt��n amount_backup. Jos suoritat toiminnon ja havaitset virheit�, �l� suorita toimintoa uudelleen ennen kuin olet palauttanut alkuper�iset arvot. Muussa tapauksessa voit korvata varmuuskopion virheellisill� tiedoilla.',
  'UPDATE_DOLLARAMOUNTS_TXT' => 'P�ivit� myyntimahdollisuuksien USD summat valitun valuutan muuntokurssin mukaan. Arvoa k�ytet��n graafien ja listojen laskennassa',
  'UPDATE_CREATE_CURRENCY' => 'Uuden valuutan luonti:',
  'UPDATE_VERIFY_FAIL' => 'Tietueen vahvistaminen ei onnistunut:',
  'UPDATE_VERIFY_CURAMOUNT' => 'Nykyinen m��r�:',
  'UPDATE_VERIFY_FIX' => 'Suorittamalla korjaustoiminnon tulos on',
  'UPDATE_INCLUDE_CLOSE' => 'Ota mukaan suljetut tietueet',
  'UPDATE_VERIFY_NEWAMOUNT' => 'Uusi summa:',
  'UPDATE_VERIFY_NEWCURRENCY' => 'Uusi valuutta:',
  'UPDATE_DONE' => 'Valmis',
  'UPDATE_ISSUE_COUNT' => 'Ongelmia havaittu, yritet��n korjata tilannetta:',
  'UPDATE_ISSUEFOUND_COUNT' => 'Ongelmia havaittu:',
  'UPDATE_COUNT' => 'Tietueet p�ivitetty:',
  'UPDATE_RESTORE_COUNT' => 'Tietueen summat palautettu:',
  'UPDATE_RESTORE' => 'Palauta m��r�t',
  'UPDATE_RESTORE_TXT' => '',
  'UPDATE_FAIL' => 'P�ivitys ei onnistunut -',
  'UPDATE_NULL_VALUE' => 'Summa on NULL, arvoksi asetetaan 0 -',
  'UPDATE_MERGE' => 'Yhdist� valuutat',
  'UPDATE_MERGE_TXT' => 'Yhdist�� useamman valuutan yhdeksi valuutaksi. Jos huomaat ett� samaan valuuttaa liittyy useita valuuttatietueita, voit yhdist�� ne. Muutos koskee my�s muissa moduuleissa esiintyvi� valuuttoja.',
  'LBL_ACCOUNT_NAME' => 'Asiakkaan nimi:',
  'LBL_AMOUNT' => 'Summa:',
  'LBL_CURRENCY' => 'Valuutta:',
  'LBL_DATE_CLOSED' => 'Oletettu p��t�sp�iv�:',
  'LBL_TYPE' => 'Tyyppi:',
  'LBL_NEXT_STEP' => 'Seuraava askel:',
  'LBL_LEAD_SOURCE' => 'Liidin l�hde:',
  'LBL_SALES_STAGE' => 'Myynnin tila:',
  'LBL_PROBABILITY' => 'Todenn�k�isyys (%):',
  'LBL_DESCRIPTION' => 'Kuvaus:',
  'LBL_DUPLICATE' => 'Mahdollinen kaksoiskappale',
  'MSG_DUPLICATE' => 'T�m�n myyntimahdollisuuden luonti voi tuottaa kaksoiskappaleen. Voit joko valita myyntimahdollisuuden alla olevasta listasta tai voit napsauttaa "Luo uusi myyntimahdollisuus" jatkaaksesi myyntimahdollisuuden luontia aikaisemmin sy�tetyn tiedon pohjalta.',
  'LBL_NEW_FORM_TITLE' => 'Luo myyntimahdollisuus',
  'LNK_NEW_OPPORTUNITY' => 'Luo myyntimahdollisuus',
  'LNK_OPPORTUNITY_LIST' => 'Myyntimahdollisuudet',
  'ERR_DELETE_RECORD' => 'Poista myyntimahdollisuus antamalla tietueen numero.',
  'LBL_TOP_OPPORTUNITIES' => 'T�rkeimm�t avoimet myyntimahdollisuudet',
  'NTC_REMOVE_OPP_CONFIRMATION' => 'Haluatko poistaa myyntimahdollisuuteen liittyv�n kontaktin?',
);


?>
