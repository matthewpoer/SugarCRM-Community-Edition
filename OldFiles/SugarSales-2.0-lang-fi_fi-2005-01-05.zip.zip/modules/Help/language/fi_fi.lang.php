<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * 
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and 
 * (ii) the SugarCRM copyright notice 
 * in the same form as they appear in the distribution.  See full license for requirements.
 * 
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Finnish language file for Sugar Sales 2.0.1a
 * by Markku Suominen (markku.suominen@antamis.com) 
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: c:\\temp\\cvs_main/sugar_lang/modules/Help/language/fi_fi.lang.php,v 1.1 2004/12/07 20:39:47 msuominen Exp $
 * Description:  Defines the Finnish language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Asiakkaat',
  'LBL_MODULE_TITLE' => 'Asiakkaat',
  'LBL_SEARCH_FORM_TITLE' => 'Hae asiakas',
  'LBL_LIST_FORM_TITLE' => 'Asiakaslista',
  'LBL_NEW_FORM_TITLE' => 'Luo asiakas',
  'LNK_NEW_CONTACT' => 'Luo kontakti',
  'LNK_NEW_ACCOUNT' => 'Luo asiakas',
  'LNK_NEW_OPPORTUNITY' => 'Luo myyntimahdollisuus',
  'LNK_NEW_CASE' => 'Luo palvelupyynt�',
  'LNK_NEW_NOTE' => 'Luo muistio',
  'LNK_NEW_CALL' => 'Luo puhelinsoitto',
  'LNK_NEW_EMAIL' => 'Luo s�hk�posti',
  'LNK_NEW_MEETING' => 'Luo tapaaminen',
  'LNK_NEW_TASK' => 'Luo teht�v�',
  'ERR_DELETE_RECORD' => 'Poista asiakas antamalla tietueen numero.',
);


?>
