<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * 
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and 
 * (ii) the SugarCRM copyright notice 
 * in the same form as they appear in the distribution.  See full license for requirements.
 * 
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Finnish language file for Sugar Sales 2.0.1a
 * by Markku Suominen (markku.suominen@antamis.com) 
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: c:\\temp\\cvs_main/sugar_lang/modules/Import/language/fi_fi.lang.php,v 1.1 2004/12/07 20:39:49 msuominen Exp $
 * Description:  Defines the Finnish language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_IMPORT_MODULE_NO_DIRECTORY' => 'Hakemisto ',
  'LBL_IMPORT_MODULE_NO_DIRECTORY_END' => ' ei ole tai on kirjoitussuojattu',
  'LBL_IMPORT_MODULE_ERROR_NO_UPLOAD' => 'Tiedoston vienti palvelimelle ei onnistunut, yrit� uudelleen',
  'LBL_IMPORT_MODULE_ERROR_LARGE_FILE' => 'Tiedosto on liian suuri, suurin koko:',
  'LBL_IMPORT_MODULE_ERROR_LARGE_FILE_END' => 'tavua. Muuta $upload_maxsize arvoa config.php-tiedostossa',
  'LBL_MODULE_NAME' => 'Tuo',
  'LBL_TRY_AGAIN' => 'Yrit� uudelleen',
  'LBL_ERROR' => 'Virhe:',
  'ERR_MULTIPLE' => 'Useita samannimisi� sarakkeita.',
  'ERR_MISSING_REQUIRED_FIELDS' => 'Vaadittuja kentti� puuttuu:',
  'ERR_SELECT_FULL_NAME' => 'Et voi valita koko nime� kun Etunimi ja Sukunimi on valittu.',
  'ERR_SELECT_FILE' => 'Palvelimelle viet�v� tiedosto.',
  'LBL_SELECT_FILE' => 'Valitse tiedosto:',
  'LBL_CUSTOM' => 'Muokattu',
  'LBL_DONT_MAP' => '-- �l� ota huomioon t�t� kentt�� --',
  'LBL_STEP_1_TITLE' => 'Kohta 1: Valitse l�hde',
  'LBL_WHAT_IS' => 'Mik� on tietol�hde?',
  'LBL_MICROSOFT_OUTLOOK' => 'Microsoft Outlook',
  'LBL_ACT' => 'Act!',
  'LBL_SALESFORCE' => 'Salesforce.com',
  'LBL_MY_SAVED' => 'Tallennetut l�hteet:',
  'LBL_PUBLISH' => 'julkaise',
  'LBL_DELETE' => 'poista',
  'LBL_PUBLISHED_SOURCES' => 'Published Sources:',
  'LBL_UNPUBLISH' => 'lopeta julkaisu',
  'LBL_NEXT' => 'Seuraava >',
  'LBL_BACK' => '< Takaisin',
  'LBL_STEP_2_TITLE' => 'Kohta 2: Vie tiedosto palvelimelle',
  'LBL_HAS_HEADER' => 'Otsikko on:',
  'LBL_NUM_1' => '1.',
  'LBL_NUM_2' => '2.',
  'LBL_NUM_3' => '3.',
  'LBL_NUM_4' => '4.',
  'LBL_NUM_5' => '5.',
  'LBL_NUM_6' => '6.',
  'LBL_NUM_7' => '7.',
  'LBL_NUM_8' => '8.',
  'LBL_NUM_9' => '9.',
  'LBL_NUM_10' => '10.',
  'LBL_NUM_11' => '11.',
  'LBL_NUM_12' => '12.',
  'LBL_NOW_CHOOSE' => 'Valitse tuotava tiedosto:',
  'LBL_IMPORT_OUTLOOK_TITLE' => 'Microsoft Outlook 98 ja 2000 vied� tiedot <b>Comma Separated Values</b> muodossa jota voidaan k�ytt�� data tuontiin j�rjestelm��n. Vie tieto Outlookista seuraavien ohjeiden avulla:',
  'LBL_OUTLOOK_NUM_1' => 'K�ynnist� <b>Outlook</b>',
  'LBL_OUTLOOK_NUM_2' => 'Valitse <b>File</b> valikko, sen j�lkeen <b>Import and Export ...</b> valikko',
  'LBL_OUTLOOK_NUM_3' => 'Valitse <b>Export to a file</b> ja valitse Next',
  'LBL_OUTLOOK_NUM_4' => 'Valitse <b>Comma Separated Values (Windows)</b> ja napsauta <b>Next</b>.<br>  Huomaa: voit ehk� joutua asentamaan tiedon vienti (export) komponentin',
  'LBL_OUTLOOK_NUM_5' => 'Valitse <b>Contacts</b> kansio ja napsauta <b>Next</b>. Voit valita toisen kontakteja sis�lt�v�n kansion jos kontakteja on tallennettu eri kansioihin',
  'LBL_OUTLOOK_NUM_6' => 'Valitse tiedosto ja napsauta <b>Next</b>',
  'LBL_OUTLOOK_NUM_7' => 'Napsauta <b>Finish</b>',
  'LBL_IMPORT_ACT_TITLE' => 'Act! voi vied� tietoa <b>Comma Separated Values</b> muodossa. T�t� muotoa voidaan k�ytt�� tiedon tuontiin. Vie tieto Act!-ohjelmasta seuraavien ohjeiden avulla:',
  'LBL_ACT_NUM_1' => 'K�ynnist� <b>ACT!</b>',
  'LBL_ACT_NUM_2' => 'Valitse <b>File</b> valikko, <b>Data Exchange</b> valikko ja sen j�lkeen <b>Export...</b> valikko',
  'LBL_ACT_NUM_3' => 'Valitse tiedostotyypiksi <b>Text-Delimited</b>',
  'LBL_ACT_NUM_4' => 'Valitse tiedostonimi ja sijainti viet�v�lle tiedolle ja napsauta <b>Next</b>',
  'LBL_ACT_NUM_5' => 'Valitse <b>Contacts records only</b>',
  'LBL_ACT_NUM_6' => 'Napsauta <b>Options...</b> painiketta',
  'LBL_ACT_NUM_7' => 'Valitse <b>Comma</b> kenttien erotinmerkiksi',
  'LBL_ACT_NUM_8' => 'Valitse <b>Yes, export field names</b> valinta ja napsauta <b>OK</b>',
  'LBL_ACT_NUM_9' => 'Napsauta <b>Next</b>',
  'LBL_ACT_NUM_10' => 'Valitse <b>All Records</b> napsauta sen j�lkeen <b>Finish</b>',
  'LBL_IMPORT_SF_TITLE' => 'Salesforce.com voi vied� tietoa <b>Comma Separated Values</b> muodossa. T�t� muotoa voidaan k�ytt�� tiedon tuontiin. Vie tieto Salesforce.com-sivustolta seuraavien ohjeiden avulla:',
  'LBL_SF_NUM_1' => 'Avaa selain ja siirry sivustolle http://www.salesforce.com. Kirjaudu s�hk�postiosoitteesi ja salanasi avulla',
  'LBL_SF_NUM_2' => 'Napsauta <b>Reports</b> kielekett� yl�valikossa',
  'LBL_SF_NUM_3' => '<b>Asiakastietojen vienti:</b> Napsauta <b>Active Accounts</b> linkki�<br><b>Kontaktien vienti:</b> Napsauta <b>Mailing List</b> linkki�',
  'LBL_SF_NUM_4' => '<b>kohta 1: Valitse raportin tyyppi</b>, valitse <b>Tabular Report</b>napsauta <b>Next</b>',
  'LBL_SF_NUM_5' => '<b>kohta 2: Valitse raportin sarakkeet</b>, valitse halutut sarakkeet ja napsauta <b>Next</b>',
  'LBL_SF_NUM_6' => '<b>kohta 3: Valitse kokoomatieto</b>, napsauta<b>Next</b>',
  'LBL_SF_NUM_7' => '<b>kohta 4: J�rjest� raportin sarakkeet</b>, napsauta <b>Next</b>',
  'LBL_SF_NUM_8' => '<b>kohta 5: Valitse raportin kriteerit</b>, kohdassa <b>Start Date</b>, valitse riitt�v�n pitk�ll� menneisyydess� oleva p�iv�m��r� jotta kaikki asiakastiedot tulisivat mukaan. Voit my�s vied� osan asiakastiedoista tarkempia kriteerej� k�ytt�m�ll�. Kun olet valmis, napsauta <b>Run Report</b>',
  'LBL_SF_NUM_9' => 'Raportti luodaan ja sivulla tulisi n�ky� <b>Report Generation Status: Complete.</b> Napsauta t�m�n j�lkeen <b>Export to Excel</b>',
  'LBL_SF_NUM_10' => 'Kohdassa <b>Export Report:</b>, ja <b>Export File Format:</b>, valitse <b>Comma Delimited .csv</b>. Napsauta <b>Export</b>.',
  'LBL_SF_NUM_11' => 'Esiin tulevan valintaikkunan avulla tallennat tiedoston omalle koneellesi.',
  'LBL_IMPORT_CUSTOM_TITLE' => 'Monet sovellukset sallivat tiedon viennin <b>Comma Delimited text file (.csv)</b> -muodossa. Useimmat ohjelmat seuraavat n�it� ohjeita:',
  'LBL_CUSTOM_NUM_1' => 'K�ynnist� sovellus ja avaa tiedosto',
  'LBL_CUSTOM_NUM_2' => 'Valitse <b>Save As...</b> tai <b>Export...</b> valikko',
  'LBL_CUSTOM_NUM_3' => 'Tallenna tiedosto <b>CSV</b> tai <b>Comma Separated Values</b> muodossa',
  'LBL_STEP_3_TITLE' => 'Kohta 3: Vahvista kent�t ja tuo',
  'LBL_SELECT_FIELDS_TO_MAP' => 'Valitse alla olevasta listasta tuotavat kent�t ja mihin ne tietokannassa kohdistetaan. Kun olet valmis, napsauta <b>Import Now</b>:',
  'LBL_DATABASE_FIELD' => 'Tietokannan kentt�',
  'LBL_HEADER_ROW' => 'Otsikkorivi',
  'LBL_ROW' => 'Row',
  'LBL_SAVE_AS_CUSTOM' => 'Tallenna muokattuna karttana:',
  'LBL_CONTACTS_NOTE_1' => 'Joko suku- tai etunimi tulee kohdistaa.',
  'LBL_CONTACTS_NOTE_2' => 'Jos koko nimi -kentt� on kohdistettu, etunimi ja sukunimi sivuutetaan.',
  'LBL_CONTACTS_NOTE_3' => 'Jos koko nimi - kentt� on kohdistettu, koko nimi -kent�ss� oleva tieto jaetaan etunimi ja sukunimi -kenttiin tietokantaan siirrett�ess�.',
  'LBL_CONTACTS_NOTE_4' => 'Kent�t Katuosoite 2 ja Katuosoite 3 yhdistet��n Katuosoite-kentt��n tietokantaan siirrett�ess�.',
  'LBL_ACCOUNTS_NOTE_1' => 'Asiakas tulee kohdistaa.',
  'LBL_ACCOUNTS_NOTE_2' => 'Kent�t Katuosoite 2 ja Katuosoite 3 yhdistet��n Katuosoite-kentt��n tietokantaan siirrett�ess�.',
  'LBL_OPPORTUNITIES_NOTE_1' => 'Myyntimahdollisuuden nimi, Asiakas, Sulkemisp�iv�m��r� ja Myynnin tila ovat vaadittuja kentti�.',
  'LBL_IMPORT_NOW' => 'Tuo nyt',
  'LBL_' => '',
  'LBL_CANNOT_OPEN' => 'Tiedoston avaaminen ei onnistunut',
  'LBL_NOT_SAME_NUMBER' => 'Tiedostossa ei ollut samaa m��r�� kentti� eri riveill�',
  'LBL_NO_LINES' => 'Tiedostossa ei ollut rivej�',
  'LBL_FILE_ALREADY_BEEN_OR' => 'Tiedosto on jo k�sitelty tai sit� ei ole',
  'LBL_SUCCESS' => 'Onnistui:',
  'LBL_SUCCESSFULLY' => 'Tiedot tuotu onnistuneesti',
  'LBL_LAST_IMPORT_UNDONE' => 'Viimeisin tiedon tuonti on peruttu',
  'LBL_NO_IMPORT_TO_UNDO' => 'Peruttavaa tiedon tuontia ei ollut.',
  'LBL_FAIL' => 'Virhe:',
  'LBL_RECORDS_SKIPPED' => 'tietuetta sivuutettiin koska niist� puuttui yksi tai useampi vaadittu kentt�',
  'LBL_IDS_EXISTED_OR_LONGER' => 'tietuetta sivuutettiin koska avainkent�t olivat jo olemassa tai ne olivat yli 36 merkki� pitki�',
  'LBL_RESULTS' => 'Tulokset',
  'LBL_IMPORT_MORE' => 'Tuo lis��',
  'LBL_FINISHED' => 'Valmis',
  'LBL_UNDO_LAST_IMPORT' => 'Peru viimeisin tiedon tuonti',
);

$mod_list_strings = Array(
'contacts_import_fields' => Array(
	"id"=>"Contact ID"
	,"first_name"=>"First Name"
	,"last_name"=>"Last Name"
	,"salutation"=>"Salutation"
	,"lead_source"=>"Liidin l�hde"
	,"birthdate"=>"Liidin l�hde"
	,"do_not_call"=>"�l� soita"
	,"email_opt_out"=>"Ei s�hk�postia"
	,"primary_address_street_2"=>"Ensisijainen katuosoite 2"
	,"primary_address_street_3"=>"Ensisijainen katuosoite 3"
	,"alt_address_street_2"=>"Muu katuosoite 2"
	,"alt_address_street_3"=>"Muu katuosoite 3"
	,"full_name"=>"Full Name"
	,"account_name"=>"Asiakas"
	,"account_id"=>"Asiakkaan ID"
	,"title"=>"Title"
	,"department"=>"Osasto"
	,"birthdate"=>"Syntym�p��iv�"
	,"do_not_call"=>"�l� soita"
	,"phone_home"=>"Puhelin (koti)"
	,"phone_mobile"=>"Puhelin (k�sipuhelin)"
	,"phone_work"=>"Puhelin (ty�)"
	,"phone_other"=>"Puhelin (muu)"
	,"phone_fax"=>"Faksi"
	,"email1"=>"S�hk�posti"
	,"email2"=>"S�hk�posti (muu)"
	,"assistant"=>"Assistentti"
	,"assistant_phone"=>"Assistentin puhelin"
	,"primary_address_street"=>"Ensisijainen osoite"
	,"primary_address_city"=>"Ensisijainen osoite kaupunki"
	,"primary_address_state"=>"Ensisijainen osoite osavaltio"
	,"primary_address_postalcode"=>"Ensisijainen osoite postinumero"
	,"primary_address_country"=>"Ensisijainen osoite maa"
	,"alt_address_street"=>"Muu katuosoite"
	,"alt_address_city"=>"Muu osoite kaupunki"
	,"alt_address_state"=>"Muu osoite osavaltio"
	,"alt_address_postalcode"=>"Muu osoite postinumero"
	,"alt_address_country"=>"Muu osoite maa"
	,"description"=>"Description"

	),

'accounts_import_fields' => Array(
	"id"=>"Asiakkaan ID",
	"name"=>"Asiakas",
	"website"=>"WWW-sivusto",
	"industry"=>"Teollisuus",
	"account_type"=>"Type",
	"ticker_symbol"=>"Tikkerisymboli",
	"parent_name"=>"J�sen",
	"employees"=>"Ty�ntekij�it�",
	"ownership"=>"Omistuspohja",
	"phone_office"=>"Puhelin",
	"phone_fax"=>"Faksi",
	"phone_alternate"=>"Muu puhelin",
	"email1"=>"S�hk�posti",
	"email2"=>"Muu s�hk�posti",
	"rating"=>"Arvio",
	"sic_code"=>"SIC koodi",
	"annual_revenue"=>"Liikevaihto",
	"billing_address_street"=>"Laskutusosoite",
	"billing_address_street_2"=>"Laskutusosoite 2",
	"billing_address_street_3"=>"Laskutusosoite 3",
	"billing_address_street_4"=>"Laskutusosoite 4",
	"billing_address_city"=>"Laskutusosoite kaupunki",
	"billing_address_state"=>"Laskutusosoite osavaltio",
	"billing_address_postalcode"=>"Laskutusosoite postinumero",
	"billing_address_country"=>"Laskutusosoite maa",
	"shipping_address_street"=>"Toimitusosoite",
	"shipping_address_street_2"=>"Toimitusosoite 2",
	"shipping_address_street_3"=>"Toimitusosoite 3",
	"shipping_address_street_4"=>"Toimitusosoite 4",
	"shipping_address_city"=>"Toimitusosoite kaupunki",
	"shipping_address_state"=>"Toimitusosoite osavaltio",
	"shipping_address_postalcode"=>"Toimitusosoite postinumero",
	"shipping_address_country"=>"Toimitusosoite maa",
	"description"=>"Kuvaus"
	),

'opportunities_import_fields' => Array(
		"id"=>"Asiakkaan ID"
                , "name"=>"Myyntimahdollisuuden nimi"
                , "account_name"=>"Asiakas"
                , "opportunity_type"=>"Myyntimahdollisuuden tyyppi"
                , "lead_source"=>"Liidin l�hde"
                , "amount"=>"Summa"
                , "date_closed"=>"Sulkemisp�iv�m��r�"
                , "next_step"=>"Seuraava kohta"
                , "sales_stage"=>"Myynnin tila"
                , "probability"=>"Todenn�k�isyys"
                , "description"=>"Kuvaus"
                ),

'leads_import_fields' => Array(
                "refered_by"=>"Viitattu kohteesta"
                ,"salutation"=>"Tervehdys"
                ,"first_name"=>"Etunimi"
                ,"last_name"=>"Sukunimi"
                ,"lead_source"=>"Liidin l�hde"
                ,"lead_source_description"=>"Liidin l�hteen kuvaus"
                ,"title"=>"Asema"
                ,"department"=>"Osasto"
                ,"do_not_call"=>"�l� soita"
	,"phone_home"=>"Puhelin (koti)"
	,"phone_mobile"=>"Puhelin (k�sipuhelin)"
	,"phone_work"=>"Puhelin (ty�)"
	,"phone_other"=>"Puhelin (muu)"
	,"phone_fax"=>"Faksi"
	,"email1"=>"S�hk�posti"
	,"email2"=>"S�hk�posti (muu)"
        ,"email_opt_out"=>"Ei s�hk�postia"
	,"primary_address_street_2"=>"Ensisijainen katuosoite 2"
	,"primary_address_street_3"=>"Ensisijainen katuosoite 3"
	,"alt_address_street_2"=>"Muu katuosoite 2"
	,"alt_address_street_3"=>"Muu katuosoite 3"
	,"primary_address_street"=>"Ensisijainen katuosoite"
	,"primary_address_city"=>"Ensisijainen osoite kaupunki"
	,"primary_address_state"=>"Ensisijainen osoite osavaltio"
	,"primary_address_postalcode"=>"Ensisijainen osoite postinumero"
	,"primary_address_country"=>"Ensisijainen osoite maa"
	,"alt_address_street"=>"Muu katuosoite"
	,"alt_address_city"=>"Muu osoite kaupunki"
	,"alt_address_state"=>"Muu osoite osavaltio"
	,"alt_address_postalcode"=>"Muu osoite postinumero"
	,"alt_address_country"=>"Muu osoite maa"
	,"full_name"=>"Koko nimi"
	,"description"=>"Kuvaus"
        ,"status"=>"Tila"
        ,"status_description"=>"Tilan kuvaus"
        ,"account_name"=>"Asiakas"
        ,"account_description"=>"Kuvaus"
        ),


















































);

?>
