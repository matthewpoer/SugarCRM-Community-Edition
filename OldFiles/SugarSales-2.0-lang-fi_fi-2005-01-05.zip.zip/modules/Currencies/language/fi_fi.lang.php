<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * 
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and 
 * (ii) the SugarCRM copyright notice 
 * in the same form as they appear in the distribution.  See full license for requirements.
 * 
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: c:\\temp\\cvs_main/sugar_lang/modules/Currencies/language/fi_fi.lang.php,v 1.1 2004/12/07 20:39:43 msuominen Exp $
 * Description:  Defines the Finnish language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Finnish language file for Sugar Sales 2.0.1a
 * by Markku Suominen (markku.suominen@antamis.com) 
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_LIST_FORM_TITLE' => 'Valuutat',
  'LBL_CURRENCY' => 'Valuutta',
  'LBL_ADD' => 'Lis��',
  'LBL_MERGE' => 'Yhdist�',
  'LBL_MERGE_TXT' => 'Tarkista yhdistett�v�t valuutat. Toiminto poistaa valitut valuutat ja ottaa k�ytt��n valitun valuutan.',
  'LBL_US_DOLLAR' => 'U.S. dollari',
  'LBL_DELETE' => 'Poista',
  'LBL_LIST_SYMBOL' => 'Valuutan symboli',
  'LBL_LIST_NAME' => 'Valuutan nimi',
  'LBL_LIST_ISO4217' => 'ISO 4217 koodi',
  'LBL_UPDATE' => 'P�ivit�',
  'LBL_LIST_RATE' => 'Muuntokurssi',
  'LBL_LIST_STATUS' => 'Tila',
  'LNK_NEW_CONTACT' => 'Uusi kontakti',
  'LNK_NEW_ACCOUNT' => 'Uusi asiakas',
  'LNK_NEW_OPPORTUNITY' => 'Uusi myyntimahdollisuus',
  'LNK_NEW_CASE' => 'Uusi palvelupyynt�',
  'LNK_NEW_NOTE' => 'Luo muistio',
  'LNK_NEW_CALL' => 'Uusi puhelinsoitto',
  'LNK_NEW_EMAIL' => 'Uusi s�hk�posti',
  'LNK_NEW_MEETING' => 'Uusi tapaaminen',
  'LNK_NEW_TASK' => 'Luo teht�v�',
  'NTC_DELETE_CONFIRMATION' => 'Haluatko poistaa tietueen? On ehk� parempi valita tilaksi ei aktiivinen, muutoin kaikki t�t� valuuttaa k�ytt�v�t tietueet muunnetaan dollareiksi.',
  'currency_status_dom' => 
  array (
    'Active' => 'Aktiivinen',
    'Inactive' => 'Ei aktiivinen',
  ),
);


?>
