<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * 
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and 
 * (ii) the SugarCRM copyright notice 
 * in the same form as they appear in the distribution.  See full license for requirements.
 * 
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Finnish language file for Sugar Sales 2.0.1a
 * by Markku Suominen (markku.suominen@antamis.com) 
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: c:\\temp\\cvs_main/sugar_lang/modules/Accounts/language/fi_fi.lang.php,v 1.4 2004/12/07 20:39:31 msuominen Exp $
 * Description:  Defines the Finnish language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Asiakkaat',
  'LBL_MODULE_TITLE' => 'Asiakkaat:',
  'LBL_SEARCH_FORM_TITLE' => 'Hae asiakas',
  'LBL_LIST_FORM_TITLE' => 'Asiakaslista',
  'LBL_NEW_FORM_TITLE' => 'Uusi asiakas',
  'LBL_MEMBER_ORG_FORM_TITLE' => 'J�senorganisaatiot',
  'LBL_LIST_ACCOUNT_NAME' => 'Asiakas',
  'LBL_LIST_CITY' => 'Kaupunki',
  'LBL_LIST_WEBSITE' => 'WWW-sivusto',
  'LBL_LIST_STATE' => 'Osavaltio',
  'LBL_LIST_PHONE' => 'Puhelin',
  'LBL_LIST_EMAIL_ADDRESS' => 'S�hk�postiosoite',
  'LBL_LIST_CONTACT_NAME' => 'Kontaktin nimi',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_website' => 'LBL_LIST_WEBSITE',
  'db_billing_address_city' => 'LBL_LIST_CITY',
//END DON'T CONVERT
  'LBL_ACCOUNT_INFORMATION' => 'Tietoja asiakkaasta',
  'LBL_ACCOUNT' => 'Asiakas:',
  'LBL_ACCOUNT_NAME' => 'Asiakas:',
  'LBL_PHONE' => 'Puhelin:',
  'LBL_WEBSITE' => 'WWW-sivusto:',
  'LBL_FAX' => 'Faksi:',
  'LBL_TICKER_SYMBOL' => 'Tikkerisymboli:',
  'LBL_OTHER_PHONE' => 'Muu puhelin:',
  'LBL_ANY_PHONE' => 'Muu puhelin:',
  'LBL_MEMBER_OF' => 'J�sen:',
  'LBL_EMAIL' => 'S�hk�posti:',
  'LBL_EMPLOYEES' => 'Ty�ntekij�t:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Muu s�hk�posti:',
  'LBL_ANY_EMAIL' => 'Muu s�hk�posti:',
  'LBL_OWNERSHIP' => 'Omistaja:',
  'LBL_RATING' => 'Arvio:',
  'LBL_INDUSTRY' => 'Teollisuusala:',
  'LBL_SIC_CODE' => 'SIC koodi:',
  'LBL_TYPE' => 'Tyyppi:',
  'LBL_ANNUAL_REVENUE' => 'Liikevaihto:',
  'LBL_ADDRESS_INFORMATION' => 'Osoitetiedot',
  'LBL_BILLING_ADDRESS' => 'Laskutusosoite:',
  'LBL_SHIPPING_ADDRESS' => 'Postitusosoite:',
  'LBL_ANY_ADDRESS' => 'Muu osoite:',
  'LBL_CITY' => 'Kaupunki:',
  'LBL_STATE' => 'Osavaltio:',
  'LBL_POSTAL_CODE' => 'Postinumero:',
  'LBL_COUNTRY' => 'Maa:',
  'LBL_DESCRIPTION_INFORMATION' => 'Kuvaus',
  'LBL_DESCRIPTION' => 'Kuvaus:',
  'NTC_COPY_BILLING_ADDRESS' => 'Kopioi laskutusosoite postitusosoitteeksi',
  'NTC_COPY_SHIPPING_ADDRESS' => 'Kopioi postitusosoite laskutusosoitteeksi',
  'NTC_REMOVE_MEMBER_ORG_CONFIRMATION' => 'Haluatko varmasti poistaa t�m�n j�senorganisaation',
  'LBL_DUPLICATE' => 'Mahdollinen kaksoiskappale',
  'MSG_DUPLICATE' => 'Asiakkaan luonti voi tuottaa kaksoiskappaleen. Voit joko valita asiakkaan alla olevasta listasta tai  napsauttaa "Luo uusi asiakas jatkaaksesi asiakkaan luontia aikaisemmin sy�tetyn tiedon pohjalta.',
  'LNK_NEW_ACCOUNT' => 'Luo asiakas',
  'LNK_ACCOUNT_LIST' => 'Asiakkaat',
  'LBL_INVITEE' => 'Kontaktit',
  'ERR_DELETE_RECORD' => 'Poista asiakas antamalla tietueen numero.',
  'NTC_DELETE_CONFIRMATION' => 'Haluatko poistaa t�m�n tietueen?',

);


?>
