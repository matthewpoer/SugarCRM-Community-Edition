<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * 
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and 
 * (ii) the SugarCRM copyright notice 
 * in the same form as they appear in the distribution.  See full license for requirements.
 * 
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: c:\\temp\\cvs_main/sugar_lang/modules/Activities/language/fi_fi.lang.php,v 1.2 2004/12/07 20:39:31 msuominen Exp $
 * Description:  Defines the Finnish language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Finnish language file for Sugar Sales 2.0.1a
 * by Markku Suominen (markku.suominen@antamis.com) 
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Aktiviteetit',
  'LBL_MODULE_TITLE' => 'Aktiviteetit:',
  'LBL_SEARCH_FORM_TITLE' => 'Hae aktiviteetti',
  'LBL_LIST_FORM_TITLE' => 'Aktiviteettilista',
  'LBL_LIST_SUBJECT' => 'Aihe',
  'LBL_LIST_CONTACT' => 'Kontakti',
  'LBL_LIST_RELATED_TO' => 'Liittyy aiheeseen',
  'LBL_LIST_DATE' => 'P�iv�m��r�',
  'LBL_LIST_TIME' => 'Aloitusaika',
  'LBL_LIST_CLOSE' => 'Sulje',
  'LBL_SUBJECT' => 'Aihe:',
  'LBL_STATUS' => 'Tila:',
  'LBL_LOCATION' => 'Sijainti:',
  'LBL_DATE_TIME' => 'Aloitusp�iv� ja aika:',
  'LBL_DATE' => 'Aloitusp�iv�:',
  'LBL_TIME' => 'Aloitusaika:',
  'LBL_DURATION' => 'Kesto:',
  'LBL_HOURS_MINS' => '(tuntia/minuuttia)',
  'LBL_CONTACT_NAME' => 'Kontaktin nimi: ',
  'LBL_MEETING' => 'Tapaaminen:',
  'LBL_DESCRIPTION_INFORMATION' => 'Kuvaus',
  'LBL_DESCRIPTION' => 'Kuvaus:',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'Suunniteltu',
  'LNK_NEW_CALL' => 'Luo puhelinsoitto',
  'LNK_NEW_MEETING' => 'Luo tapaaminen',
  'LNK_NEW_TASK' => 'Luo teht�v�',
  'LNK_NEW_NOTE' => 'Luo muistio',
  'LNK_NEW_EMAIL' => 'Luo s�hk�posti',
  'LNK_CALL_LIST' => 'Puhelinsoitot',
  'LNK_MEETING_LIST' => 'Tapaamiset',
  'LNK_TASK_LIST' => 'Teht�v�t',
  'LNK_NOTE_LIST' => 'Muistiot',
  'LNK_EMAIL_LIST' => 'S�hk�postit',
  'ERR_DELETE_RECORD' => 'Poista asiakas antamalla tietueen numero.',
  'NTC_REMOVE_INVITEE' => 'Haluatko poistaa henkil�n tapaamisesta?',
  'LBL_INVITEE' => 'Kutsutut',
  'LBL_LIST_DIRECTION' => 'Suunta',
  'LBL_DIRECTION' => 'Suunta',
  'LNK_NEW_APPOINTMENT' => 'Uusi tapaaminen',
  'LNK_VIEW_CALENDAR' => 'T�n��n',
  'LBL_OPEN_ACTIVITIES' => 'Avoimet aktiviteetit',
  'LBL_HISTORY' => 'Historia',
  'LBL_UPCOMING' => 'Omat tulevat aktiviteetit',
  'LBL_TODAY' => 'saakka ',
  'LBL_NEW_TASK_BUTTON_TITLE' => 'Luo teht�v� [Alt+N]',
  'LBL_NEW_TASK_BUTTON_KEY' => 'N',
  'LBL_NEW_TASK_BUTTON_LABEL' => 'Luo teht�v�',
  'LBL_SCHEDULE_MEETING_BUTTON_TITLE' => 'Etsi',
  'LBL_SCHEDULE_MEETING_BUTTON_KEY' => 'M',
  'LBL_SCHEDULE_MEETING_BUTTON_LABEL' => 'Valitse tapaamisaika',
  'LBL_SCHEDULE_CALL_BUTTON_TITLE' => 'Valitse tapaamisaika',
  'LBL_SCHEDULE_CALL_BUTTON_KEY' => 'C',
  'LBL_SCHEDULE_CALL_BUTTON_LABEL' => 'Valitse soittoaika',
  'LBL_NEW_NOTE_BUTTON_TITLE' => 'Luo muistio [Alt+T]',
  'LBL_NEW_NOTE_BUTTON_KEY' => 'T',
  'LBL_NEW_NOTE_BUTTON_LABEL' => 'Luo muistio',
  'LBL_TRACK_EMAIL_BUTTON_TITLE' => 'Arkistoi s�hk�posti [Alt+K]',
  'LBL_TRACK_EMAIL_BUTTON_KEY' => 'K',
  'LBL_TRACK_EMAIL_BUTTON_LABEL' => 'Arkistoi s�hk�posti',
  'LBL_LIST_STATUS' => 'Tila',
  'LBL_LIST_DUE_DATE' => 'Valmistumisp�iv�',
  'LBL_LIST_LAST_MODIFIED' => 'Viimeksi muutettu',
  'NTC_NONE_SCHEDULED' => 'Ei l�ydetty',
);


?>
