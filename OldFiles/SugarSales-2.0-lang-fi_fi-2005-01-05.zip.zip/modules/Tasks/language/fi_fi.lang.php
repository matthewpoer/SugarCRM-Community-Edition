<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * 
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and 
 * (ii) the SugarCRM copyright notice 
 * in the same form as they appear in the distribution.  See full license for requirements.
 * 
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: c:\\temp\\cvs_main/sugar_lang/modules/Tasks/language/fi_fi.lang.php,v 1.1 2004/12/07 20:39:59 msuominen Exp $
 * Description:  Defines the Finnish language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Finnish language file for Sugar Sales 2.0.1a
 * by Markku Suominen (markku.suominen@antamis.com) 
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Teht�v�t',
  'LBL_TASK' => 'Teht�v�t: ',
  'LBL_MODULE_TITLE' => ' Teht�v�t:',
  'LBL_SEARCH_FORM_TITLE' => ' Hae teht�v�',
  'LBL_LIST_FORM_TITLE' => ' Teht�v�lista',
  'LBL_NEW_FORM_TITLE' => ' Luo teht�v�',
  'LBL_NEW_FORM_SUBJECT' => 'Aihe:',
  'LBL_NEW_FORM_DUE_DATE' => 'Valmistumisp�iv�:',
  'LBL_NEW_FORM_DUE_TIME' => 'Valmistumisaika:',
  'LBL_NEW_TIME_FORMAT' => '(24:00)',
  'LBL_LIST_CLOSE' => 'Sulje',
  'LBL_LIST_SUBJECT' => 'Aihe',
  'LBL_LIST_CONTACT' => 'Kontakti',
  'LBL_LIST_RELATED_TO' => 'Liittyy aiheeseen',
  'LBL_LIST_DUE_DATE' => 'Valmistumisp�iv�',
  'LBL_LIST_DUE_TIME' => 'Valmistumisaika',
  'LBL_SUBJECT' => 'Aihe:',
  'LBL_STATUS' => 'Tila:',
  'LBL_DUE_DATE' => 'Valmistumisp�iv�:',
  'LBL_PRIORITY' => 'Prioriteetti:',
  'LBL_COLON' => ':',
  'LBL_DUE_DATE_AND_TIME' => 'Teht�v� valmis:',
  'DATE_FORMAT' => '(yyyy-mm-dd)',
  'LBL_NONE' => 'ei mit��n',
  'LBL_CONTACT' => 'Kontakti:',
  'LBL_PHONE' => 'Puhelin:',
  'LBL_EMAIL' => 'S�hk�posti:',
  'LBL_DESCRIPTION_INFORMATION' => 'Kuvaus',
  'LBL_DESCRIPTION' => 'Kuvaus:',
  'LBL_NAME' => 'Name:',
  'LBL_CONTACT_NAME' => 'Kontaktin nimi: ',
  'LBL_LIST_COMPLETE' => 'Valmis:',
  'LBL_LIST_STATUS' => 'Tila:',
  'ERR_DELETE_RECORD' => 'Poista kontakti antamalla tietueen numero.',
  'ERR_INVALID_HOUR' => 'Kirjoita tunti v�lilt� 0 ja 24',
  'LBL_DEFAULT_STATUS' => 'Ei aloitettu',
  'LBL_DEFAULT_PRIORITY' => 'Normaali',
  'LNK_NEW_CALL' => 'Luo puhelinsoitto',
  'LNK_NEW_MEETING' => 'Luo tapaaminen',
  'LNK_NEW_TASK' => 'Luo teht�v�',
  'LNK_NEW_NOTE' => 'Luo muistio',
  'LNK_NEW_EMAIL' => 'Luo s�hk�posti',
  'LNK_CALL_LIST' => 'Puhelinsoitot',
  'LNK_MEETING_LIST' => 'Tapaamiset',
  'LNK_TASK_LIST' => 'Teht�v�t',
  'LNK_NOTE_LIST' => 'Muistiot',
  'LNK_EMAIL_LIST' => 'S�hk�postit',
  'LNK_VIEW_CALENDAR' => 'T�n��n',
);


?>
