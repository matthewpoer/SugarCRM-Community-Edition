<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * 
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and 
 * (ii) the SugarCRM copyright notice 
 * in the same form as they appear in the distribution.  See full license for requirements.
 * 
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Finnish language file for Sugar Sales 2.0.1a
 * by Markku Suominen (markku.suominen@antamis.com) 
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: c:\\temp\\cvs_main/sugar_lang/modules/Cases/language/fi_fi.lang.php,v 1.1 2004/12/07 20:39:36 msuominen Exp $
 * Description:  Defines the Finnish language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Palvelupyynn�t',
  'LBL_MODULE_TITLE' => 'Palvelupyynn�t:',
  'LBL_SEARCH_FORM_TITLE' => 'Hae palvelupyynt�',
  'LBL_LIST_FORM_TITLE' => 'Palvelupyynt�lista',
  'LBL_NEW_FORM_TITLE' => 'Uusi palvelupyynt�',
  'LBL_CONTACT_CASE_TITLE' => 'Kontakti-palvelupyynt�:',
  'LBL_SUBJECT' => 'Aihe:',
  'LBL_CASE' => 'Palvelupyynt�:',
  'LBL_CASE_NUMBER' => 'Palvelupyynn�n numero:',
  'LBL_NUMBER' => 'Numero:',
  'LBL_STATUS' => 'Tila:',
  'LBL_PRIORITY' => 'Prioriteetti:',
  'LBL_ACCOUNT_NAME' => 'Asiakas:',
  'LBL_DESCRIPTION' => 'Kuvaus:',
  'LBL_CONTACT_NAME' => 'Kontaktin nimi:',
  'LBL_CASE_SUBJECT' => 'Palvelupyynn�n aihe:',
  'LBL_CONTACT_ROLE' => 'Rooli:',
  'LBL_LIST_NUMBER' => 'Num.',
  'LBL_LIST_SUBJECT' => 'Aihe',
  'LBL_LIST_ACCOUNT_NAME' => 'Asiakas',
  'LBL_LIST_STATUS' => 'Tila',
  'LBL_LIST_PRIORITY' => 'Prioriteetti',
  'LBL_LIST_LAST_MODIFIED' => 'Viimeksi muutettu',
  'LBL_INVITEE' => 'Kontaktit',
  'LNK_NEW_CASE' => 'Luo palvelupyynt�',
  'LNK_CASE_LIST' => 'Palvelupyynn�t',
  'NTC_REMOVE_INVITEE' => 'Haluatko poistaa kontaktin palvelupyynn�st�?',
  'ERR_DELETE_RECORD' => 'Poista asiakas antamalla tietueen numero.',
);


?>
