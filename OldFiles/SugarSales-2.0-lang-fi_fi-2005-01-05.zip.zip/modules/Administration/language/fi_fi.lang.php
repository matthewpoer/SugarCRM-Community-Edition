<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * 
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and 
 * (ii) the SugarCRM copyright notice 
 * in the same form as they appear in the distribution.  See full license for requirements.
 * 
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Finnish language file for Sugar Sales 2.0.1a
 * by Markku Suominen (markku.suominen@antamis.com) 
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: c:\\temp\\cvs_main/sugar_lang/modules/Administration/language/fi_fi.lang.php,v 1.1 2004/12/07 20:39:33 msuominen Exp $
 * Description:  Defines the Finnish language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Yll�pito',
  'LBL_MODULE_TITLE' => 'Yll�pito:',
  'LBL_NEW_FORM_TITLE' => 'Luo asiakas',
  'LNK_NEW_USER' => 'Luo k�ytt�j�',
  'ERR_DELETE_RECORD' => 'Poista asiakas antamalla tietueen numero.',
  'LBL_CONFIGURE_SETTINGS_TITLE' => 'Muuta asetuksia',
  'LBL_CONFIGURE_SETTINGS' => 'Muuta j�rjestelm�n asetukset',
  'LBL_UPGRADE_TITLE' => 'P�ivit�',
  'LBL_UPGRADE' => 'P�ivit� Sugar Sales',
  'LBL_MANAGE_USERS_TITLE' => 'K�ytt�j�hallinta',
  'LBL_MANAGE_USERS' => 'K�ytt�tietojen hallinta',
  'LBL_ADMINISTRATION_HOME_TITLE' => 'J�rjestelm�nhallinta',
  'LBL_NOTIFY_TITLE' => 'S�hk�postin l�hetysvalinnat',
  'LBL_NOTIFY_FROMADDRESS' => '"From" Osoite:',
  'LBL_MAIL_SMTPSERVER' => 'SMTP palvelin:',
  'LBL_MAIL_SMTPPORT' => 'SMTP portti:',
  'LBL_MAIL_SENDTYPE' => 'Mail Transfer Agent:',
  'LBL_MAIL_SMTPUSER' => 'SMTP k�ytt�j�tunnus:',
  'LBL_MAIL_SMTPPASS' => 'SMTP salasana:',
  'LBL_MAIL_SMTPAUTH_REQ' => 'K�yt� SMTP autentikointia?',
  'LBL_NOTIFY_SEND_BY_DEFAULT' => 'L�het� muistutukset oletusarvoisesti?',
  'LBL_NOTIFY_SUBJECT' => 'S�hk�postin aihe:',
  'LBL_NOTIFY_ON' => 'Muistutuksen p��ll�?',
  'LBL_NOTIFY_FROMNAME' => '"L�hett�j�" nimi:',
  'LBL_CURRENCY' => 'Valuutat ja valuuttakurssit',
  'LBL_MANAGE_CURRENCIES' => 'Valuutat',
  'LBL_MANAGE_OPPORTUNITIES' => 'Mahdollisuudet',
  'LBL_UPGRADE_CURRENCY' => 'P�ivit� valuuttasummat in',






























);


?>
