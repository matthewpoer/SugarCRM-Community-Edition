<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * 
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and 
 * (ii) the SugarCRM copyright notice 
 * in the same form as they appear in the distribution.  See full license for requirements.
 * 
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Finnish language file for Sugar Sales 2.0.1a
 * by Markku Suominen (markku.suominen@antamis.com)
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: c:\\temp\\cvs_main/sugar_lang/include/language/fi_fi.lang.php,v 1.1 2004/12/07 22:41:58 msuominen Exp $
 * Description:  Defines the Finnish language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

//the left value is the key stored in the db and the right value is the display value
//to translate, only modify the right value in each key/value pair
$app_list_strings = array (
//e.g. auf Deutsch 'Contacts'=>'Contakten',
  'moduleList' => 
  array (
    'Home' => 'Etusivu',
    'Dashboard' => 'Johdon n�kym�',
    'Contacts' => 'Kontaktit',
    'Accounts' => 'Asiakkaat',
    'Opportunities' => 'Myyntimahdollisuudet',
    'Cases' => 'Palvelupyynn�t',
    'Notes' => 'Muistio',
    'Calls' => 'Soitot',
    'Emails' => 'S�hk�postit',
    'Meetings' => 'Tapaamiset',
    'Tasks' => 'Teht�v�t',
    'Calendar' => 'Kalenteri',
    'Leads' => 'Liidit',





    'Activities' => 'Aktiviteetit',
  ),
  //e.g. en fran�ais 'Analyst'=>'Analyste',
  'account_type_dom' => 
  array (
    '' => '',
    'Analyst' => 'Analyytikko',
    'Competitor' => 'Kilpailija',
    'Customer' => 'Asiakas',
    'Integrator' => 'Integraattori',
    'Investor' => 'Sijoittaja',
    'Partner' => 'Partneri',
    'Press' => 'Lehdist�',
    'Prospect' => 'Prospekti',
    'Reseller' => 'J�lleenmyyj�',
    'Other' => 'Muuta',
  ),
  //e.g. en espa�ol 'Apparel'=>'Ropa',
  'industry_dom' => 
  array (
    '' => '',
    'Apparel' => 'Vaatetus',
    'Banking' => 'Pankki',
    'Biotechnology' => 'Bioteknologia',
    'Chemicals' => 'Kemikaalit',
    'Communications' => 'Kommunikaatio',
    'Construction' => 'Rakennus',
    'Consulting' => 'Konsultointi',
    'Education' => 'Opetus',
    'Electronics' => 'Elektroniikka',
    'Energy' => 'Energia',
    'Engineering' => 'Insin��ri',
    'Entertainment' => 'Viihde',
    'Environmental' => 'Ymp�rist�',
    'Finance' => 'Rahoitus',
    'Food & Beverage' => 'Ruoka & juoma',
    'Government' => 'Hallinto',
    'Healthcare' => 'Terveydenhoito',
    'Hospitality' => 'Majoitus',
    'Insurance' => 'Vakuutus',
    'Machinery' => 'Koneteollisuus',
    'Manufacturing' => 'Valmistus',
    'Media' => 'Media',
    'Not For Profit' => 'Voittoa tuottamaton',
    'Recreation' => 'Vapaa-aika',
    'Retail' => 'J�lleenmyynti',
    'Shipping' => 'Laiva',
    'Technology' => 'Teknologia',
    'Telecommunications' => 'Telekommunikaatio',
    'Transportation' => 'Kuljetus',
    'Utilities' => 'Utilities',
    'Other' => 'Muu',
  ),
  'lead_source_dom' => 
  array (
    '' => '',
    'Cold Call' => 'Puhelinsoitto',
    'Existing Customer' => 'Vanha asiakas',
    'Self Generated' => 'Itse l�hestynyt',
    'Employee' => 'Ty�ntekij�',
    'Partner' => 'Partneri',
    'Public Relations' => 'PR',
    'Direct Mail' => 'Suorapostitus',
    'Conference' => 'Konferenssi',
    'Trade Show' => 'Messut',
    'Web Site' => 'Web-sivusto',
    'Word of mouth' => 'Kuullut muualta',
    'Other' => 'Muuta',
  ),
  'opportunity_type_dom' => 
  array (
    '' => '',
    'Existing Business' => 'Olemassaoleva liiketoiminta',
    'New Business' => 'Uusi liiketoiminta',
  ),
  //Note:  do not translate opportunity_relationship_type_default_key
//       it is the key for the default opportunity_relationship_type_dom value
  'opportunity_relationship_type_default_key' => 'Primary Decision Maker',
  'opportunity_relationship_type_dom' => 
  array (
    '' => '',
    'Primary Decision Maker' => 'Ensisijainen p��tt�j�',
    'Business Decision Maker' => 'Liiketoiminnasta p��tt�v�',
    'Business Evaluator' => 'Liiketoimintaa arvioiva',
    'Technical Decision Maker' => 'Tekninen p��tt�j�',
    'Technical Evaluator' => 'Tekninen arvioija',
    'Executive Sponsor' => 'Yritysjohtoa tukeva',
    'Influencer' => 'Vaikuttaja',
    'Other' => 'Muuta',
  ),
  //Note:  do not translate case_relationship_type_default_key
//       it is the key for the default case_relationship_type_dom value
  'case_relationship_type_default_key' => 'Primary Contact',
  'case_relationship_type_dom' => 
  array (
    '' => '',
    'Primary Contact' => 'Ensisijainen kontakti',
    'Alternate Contact' => 'Toissijainen kontakti',
  ),
  'sales_stage_dom' => 
  array (
    'Prospecting' => 'Prospektointi',
    'Qualification' => 'Valinta',
    'Needs Analysis' => 'Tarveanalyysi',
    'Value Proposition' => 'Ehdotus',
    'Id. Decision Makers' => 'Tunnista p��tt�j�t',
    'Perception Analysis' => 'Mielikuvaanalyysi',
    'Proposal/Price Quote' => 'Tarjous',
    'Negotiation/Review' => 'Neuvottelu/arviointi',
    'Closed Won' => 'Voitettu',
    'Closed Lost' => 'H�vitty',
  ),
  'activity_dom' => 
  array (
    'Call' => 'Soitto',
    'Meeting' => 'Tapaaminen',
    'Task' => 'Teht�v�',
    'Email' => 'S�hk�posti',
    'Note' => 'Muistio',
  ),
  'salutation_dom' => 
  array (
    '' => '',
    'Mr.' => 'Herra',
    'Ms.' => 'Neiti',
    'Mrs.' => 'Rouva',
    'Dr.' => 'Tohtori',
    'Prof.' => 'Professori',
  ),
  'task_priority_dom' => 
  array (
    'High' => 'Korkea',
    'Medium' => 'Normaali',
    'Low' => 'Matala',
  ),
  'task_status_dom' => 
  array (
    'Not Started' => 'Ei aloitettu',
    'In Progress' => 'K�ynniss�',
    'Completed' => 'Valmis',
    'Pending Input' => 'Odottaa vastausta',
    'Deferred' => 'Siirretty',
  ),
  'meeting_status_dom' => 
  array (
    'Suunniteltu' => 'Suunniteltu',
    'Held' => 'Pidetty',
    'Not Held' => 'Ei pidetty',
  ),
  'call_status_dom' => 
  array (
    'Suunniteltu' => 'Suunniteltu',
    'Held' => 'Pidetty',
    'Not Held' => 'Ei pidetty',
  ),
  'call_direction_dom' => 
  array (
    'Inbound' => 'Vastattu',
    'Outbound' => 'Soitettu',
  ),
  'lead_status_dom' => 
  array (
    '' => '',
    'New' => 'Uusi',
    'Assigned' => 'Vastuuhenkil� nimetty',
    'In Process' => 'K�ynniss�',
    'Converted' => 'Muunnettu',
    'Recycled' => 'Takaisin k�sitelt�v�ksi',
    'Dead' => 'Lopetettu',
  ),
  'lead_status_noblank_dom' => 
  array (
    'New' => 'Uusi',
    'Assigned' => 'Vastuuhenkil� nimetty',
    'In Process' => 'K�ynniss�',
    'Converted' => 'Muunnettu',
    'Recycled' => 'Kierr�tetty',
    'Dead' => 'Lopetettu',
  ),
  //Note:  do not translate case_status_default_key
//       it is the key for the default case_status_dom value
  'case_status_default_key' => 'New',
  'case_status_dom' => 
  array (
    'New' => 'Uusi',
    'Assigned' => 'Vastuuhenkil� nimetty',
    'Closed' => 'Suljettu',
    'Pending Input' => 'Odottaa vastausta',
    'Rejected' => 'Torjuttu',
  ),
  'case_priority_default_key' => 'P2',
  'case_priority_dom' => 
  array (
    'P1' => 'Korkea',
    'P2' => 'Normaali',
    'P3' => 'Alhainen',
  ),
  'user_status_dom' => 
  array (
    'Active' => 'Aktiivinen',
    'Inactive' => 'Ei aktiivinen',
  ),
  //Note:  do not translate record_type_default_key
//       it is the key for the default record_type_module value
  'record_type_default_key' => 'Accounts',
  'record_type_display' => 
  array (
    'Accounts' => 'Asiakas',
    'Opportunities' => 'Myyntimahdollisuus',
    'Cases' => 'Palvelupyynt�',
    'Liidit' => 'Liidi',




  ),
  'notifymail_sendtype' => 
  array (
    'sendmail' => 'sendmail',
    'SMTP' => 'SMTP',
  ),
);

$app_strings = array (
  'LBL_CHARSET' => 'ISO-8859-1',
  'LBL_BROWSER_TITLE' => 'SugarCRM - Commercial Open Source CRM',
  'LBL_MY_ACCOUNT' => 'Omat tiedot',
  'LBL_ADMIN' => 'Admin',
  'LBL_LOGOUT' => 'Kirjaudu ulos',
  'LBL_SEARCH' => 'Etsi',
  'LBL_LAST_VIEWED' => 'Viimeksi katsottu',
  'NTC_WELCOME' => 'Tervetuloa',
  'NTC_SUPPORT_SUGARCRM' => 'Tue SugarCRM open source projektia PayPal-lahjoituksen avulla - se on nopeaa, ilmaista ja turvallista.',
  'NTC_NO_ITEMS_DISPLAY' => 'ei mit��n',
  'LBL_ALT_HOT_KEY' => 'Alt+',
  'LBL_SAVE_BUTTON_TITLE' => 'Tallenna [Alt+S]',
  'LBL_EDIT_BUTTON_TITLE' => 'Muokkaa [Alt+E]',
  'LBL_EDIT_BUTTON' => 'Muokkaa',
  'LBL_DUPLICATE_BUTTON_TITLE' => 'Kopioi [Alt+U]',
  'LBL_DUPLICATE_BUTTON' => 'Kopioi',
  'LBL_DELETE_BUTTON_TITLE' => 'Poista [Alt+D]',
  'LBL_DELETE_BUTTON' => 'Poista',
  'LBL_NEW_BUTTON_TITLE' => 'Luo [Alt+N]',
  'LBL_CHANGE_BUTTON_TITLE' => 'Muuta [Alt+G]',
  'LBL_CANCEL_BUTTON_TITLE' => 'Peru [Alt+X]',
  'LBL_SEARCH_BUTTON_TITLE' => 'Etsi [Alt+Q]',
  'LBL_CLEAR_BUTTON_TITLE' => 'Tyhjenn� [Alt+C]',
  'LBL_SELECT_BUTTON_TITLE' => 'Valitse [Alt+T]',
  'LBL_SAVE_BUTTON_KEY' => 'S',
  'LBL_EDIT_BUTTON_KEY' => 'E',
  'LBL_DUPLICATE_BUTTON_KEY' => 'U',
  'LBL_DELETE_BUTTON_KEY' => 'D',
  'LBL_NEW_BUTTON_KEY' => 'N',
  'LBL_CHANGE_BUTTON_KEY' => 'G',
  'LBL_CANCEL_BUTTON_KEY' => 'X',
  'LBL_SEARCH_BUTTON_KEY' => 'Q',
  'LBL_CLEAR_BUTTON_KEY' => 'C',
  'LBL_SELECT_BUTTON_KEY' => 'T',
  'LBL_SAVE_BUTTON_LABEL' => 'Tallenna',
  'LBL_EDIT_BUTTON_LABEL' => 'Muokkaa',
  'LBL_DUPLICATE_BUTTON_LABEL' => 'Kopioi',
  'LBL_DELETE_BUTTON_LABEL' => 'Poista',
  'LBL_NEW_BUTTON_LABEL' => 'Luo',
  'LBL_CHANGE_BUTTON_LABEL' => 'Muuta',
  'LBL_CANCEL_BUTTON_LABEL' => 'Peru',
  'LBL_SEARCH_BUTTON_LABEL' => 'Etsi',
  'LBL_CLEAR_BUTTON_LABEL' => 'Tyhjenn�',
  'LBL_NEXT_BUTTON_LABEL' => 'Seuraava',
  'LBL_SELECT_BUTTON_LABEL' => 'Valitse',
  'LBL_SELECT_CONTACT_BUTTON_TITLE' => 'Valitse kontakti [Alt+T]',
  'LBL_SELECT_CONTACT_BUTTON_KEY' => 'T',
  'LBL_VIEW_PDF_BUTTON_LABEL' => 'Tulosta',
  'LBL_VIEW_PDF_CONTACT_BUTTON_TITLE' => 'Tulosta [Alt+P]',
  'LBL_VIEW_PDF_CONTACT_BUTTON_KEY' => 'P',
  'LBL_SELECT_CONTACT_BUTTON_LABEL' => 'Valitse kontakti',
  'LBL_SELECT_USER_BUTTON_TITLE' => 'Valitse k�ytt�j� [Alt+U]',
  'LBL_SELECT_USER_BUTTON_KEY' => 'U',
  'LBL_SELECT_USER_BUTTON_LABEL' => 'Valitse k�ytt�j�',
  'LBL_CREATE_BUTTON_LABEL' => 'Luo',
  'LBL_SHORTCUTS' => 'Pikavalinnat',
  'LBL_LIST_NAME' => 'Nimi',



  'LBL_LIST_USER_NAME' => 'K�ytt�j�nimi',
  'LBL_LIST_EMAIL' => 'S�hk�posti',
  'LBL_LIST_PHONE' => 'Puhelin',
  'LBL_LIST_CONTACT_NAME' => 'Nimi',
  'LBL_LIST_CONTACT_ROLE' => 'Kontaktin rooli',
  'LBL_LIST_ACCOUNT_NAME' => 'Asiakas',
  'LBL_USER_LIST' => 'K�ytt�j�lista',
  'LBL_CONTACT_LIST' => 'Kontaktilista',
  'LBL_RELATED_RECORDS' => 'Liittyv�t tietueet',
  'LBL_MASS_UPDATE' => 'Massap�ivitys',
  'LNK_ADVANCED_SEARCH' => 'Laajennettu',
  'LNK_BASIC_SEARCH' => 'Perus',
  'LNK_EDIT' => 'muokkaa',
  'LNK_REMOVE' => 'poista',
  'LNK_DELETE' => 'poista',
  'LNK_LIST_START' => 'Alku',
  'LNK_LIST_NEXT' => 'Seuraava',
  'LNK_LIST_PREVIOUS' => 'Edellinen',
  'LNK_LIST_END' => 'Loppu',
  'LBL_LIST_OF' => ' / ',
  'LBL_OR' => 'TAI',
  'LNK_PRINT' => 'Tulosta',
  'LNK_HELP' => 'Ohje',
  'LNK_ABOUT' => 'Tietoja',
  'NTC_REQUIRED' => 'Tarkoittaa vaadittua kentt��',
  'LBL_REQUIRED_SYMBOL' => '*',
  'LBL_CURRENCY_SYMBOL' => '$',
  'LBL_PERCENTAGE_SYMBOL' => '%',
  'LBL_THOUSANDS_SYMBOL' => 'K',
  'NTC_DATE_FORMAT' => '(yyyy-mm-dd)',
  'NTC_TIME_FORMAT' => '(24:00)',
  'NTC_DATE_TIME_FORMAT' => '(yyyy-mm-dd 24:00)',
  'NTC_DELETE_CONFIRMATION' => 'Haluatko poistaa tietueen?',
  'ERR_DELETE_RECORD' => 'Poista kontakti antamalla tietueen numero.',
  'ERR_CREATING_TABLE' => 'Virhe taulun luonnissa: ',
  'ERR_CREATING_FIELDS' => 'Virhe lis�tietokentiss�: ',
  'ERR_MISSING_REQUIRED_FIELDS' => 'Sy�t� tieto vaadittuihin kenttiin:',
  'ERR_INVALID_EMAIL_ADDRESS' => 'ei voimassaoleva s�hk�postiosoite.',
  'ERR_INVALID_DATE_FORMAT' => 'P�iv�m��r�n tulee olla muotoa: yyyy-mm-dd',
  'ERR_INVALID_MONTH' => 'Anna kuukausi.',
  'ERR_INVALID_DAY' => 'Anna p�iv�.',
  'ERR_INVALID_YEAR' => 'Anna nelinumeroinen vuosiluku.',
  'ERR_INVALID_DATE' => 'Anna p�iv�m��r�.',
  'ERR_INVALID_HOUR' => 'Anna tunti.',
  'ERR_INVALID_TIME' => 'Anna kellonaika.',
  'ERR_INVALID_AMOUNT' => 'Anna summa.',
  'NTC_CLICK_BACK' => 'Napsauta selaimen Takaisin-painiketta ja korjaa ongelma.',
  'LBL_LIST_ASSIGNED_USER' => 'K�ytt�j�',
  'LBL_ASSIGNED_TO' => 'Vastuuhenkil�:',
  'LBL_DATE_MODIFIED' => 'Muokattu:',
  'LBL_DATE_ENTERED' => 'Luotu:',
  'LBL_CURRENT_USER_FILTER' => 'Vain omat tiedot:',
  'NTC_LOGIN_MESSAGE' => 'Anna k�ytt�j�nimi ja salasana.',
  'LBL_NONE' => '--Ei valittu--',
  'LBL_BACK' => 'Takaisin',
  'LBL_IMPORT' => 'Tuo',
  'LBL_EXPORT' => 'Vie',
  'LBL_EXPORT_ALL' => 'Vie kaikki',
  'LBL_SAVE_NEW_BUTTON_TITLE' => 'Tallenna ja luo uusi [Alt+V]',
  'LBL_SAVE_NEW_BUTTON_KEY' => 'V',
  'LBL_SAVE_NEW_BUTTON_LABEL' => 'Tallenna ja luo uusi',
  'LBL_NAME' => 'Nimi',





  'LBL_SUBJECT' => 'Aihe',
);


?>
