<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Home/language/ge_ch.lang.php, v 1.01 2004/08/09 09:48:58 erich.althaus@creative-solutions.ch $
 * Description:  Defines the German language pack
 ********************************************************************************/

$mod_strings = Array(
'LBL_NEW_FORM_TITLE'=>'Neuer Kontakt',
'LBL_FIRST_NAME'=>'Vornamen:',
'LBL_LAST_NAME'=>'Nachnamen:',
'LBL_PHONE'=>'Telefon:',
'LBL_EMAIL_ADDRESS'=>'Email:',

'LBL_PIPELINE_FORM_TITLE'=>'Pipeline',

'LNK_NEW_CONTACT'=>'Neuer Kontakt',
'LNK_NEW_ACCOUNT'=>'Neuer Account',
'LNK_NEW_OPPORTUNITY'=>'Neue Opportunity',
'LNK_NEW_CASE'=>'Neuer Case',
'LNK_NEW_NOTE'=>'Neue Notiz',
'LNK_NEW_CALL'=>'Neues Telefonat',
'LNK_NEW_EMAIL'=>'Neue Email',
'LNK_NEW_MEETING'=>'Neues Meeting',
'LNK_NEW_TASK'=>'Neue Pendenz',

'ERR_ONE_CHAR'=>'Bitte mindestens ein Zeichen oder eine Ziffer f�r die Suche eingeben',

//New to SugarCRM 1.1c.
'LBL_LIST_LAST_NAME'=>'Nachnamen',
'LBL_PIPELINE_FORM_TITLE'=>'Meine Pipeline',
'LBL_OPEN_TASKS'=>'Meine offenen Pendenzen',
);
?>