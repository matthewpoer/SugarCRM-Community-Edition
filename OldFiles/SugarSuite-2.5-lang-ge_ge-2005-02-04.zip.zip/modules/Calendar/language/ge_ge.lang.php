<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Calendar',
  'LBL_MODULE_TITLE' => 'Calendar',
  'LNK_NEW_CALL' => 'Neuer Anruf',
  'LNK_NEW_MEETING' => 'Neues Meeting',
  'LNK_NEW_APPOINTMENT' => 'Neues Treffen',
  'LNK_NEW_TASK' => 'Neue Aufgabe',
  'LNK_CALL_LIST' => 'Anruf',
  'LNK_MEETING_LIST' => 'Meeting',
  'LNK_TASK_LIST' => 'Aufgaben',
  'LNK_VIEW_CALENDAR' => 'Heute',
  'LBL_MONTH' => 'Monat',
  'LBL_DAY' => 'Tag',
  'LBL_YEAR' => 'Jahr',
  'LBL_WEEK' => 'Woche',
  'LBL_PREVIOUS_MONTH' => 'Voriger Monat',
  'LBL_PREVIOUS_DAY' => 'Voriger Tag',
  'LBL_PREVIOUS_YEAR' => 'Voriges Jahr',
  'LBL_PREVIOUS_WEEK' => 'Vorige Woche',
  'LBL_NEXT_MONTH' => 'N�chster Monat',
  'LBL_NEXT_DAY' => 'N�chster Tag',
  'LBL_NEXT_YEAR' => 'N�chstes Jahr',
  'LBL_NEXT_WEEK' => 'N�chste Woche',
  'LBL_AM' => '',
  'LBL_PM' => '',
  'LBL_SCHEDULED' => 'Gebucht',
  'LBL_BUSY' => 'Belegt',
  'LBL_CONFLICT' => 'Konflikt',
  'LBL_USER_CALENDARS' => 'User Kalender',
);

$mod_list_strings = array (
  'dom_cal_weekdays' => 
  array (
    0 => 'So.',
    1 => 'Mo.',
    2 => 'Di.',
    3 => 'Mi.',
    4 => 'Do.',
    5 => 'Fr.',
    6 => 'Sa.',
  ),
  'dom_cal_weekdays_long' => 
  array (
    0 => 'Sonntag',
    1 => 'Montag',
    2 => 'Dienstag',
    3 => 'Mittwoch',
    4 => 'Donnerstag',
    5 => 'Freitag',
    6 => 'Samstag',
  ),
  'dom_cal_month' => 
  array (
    0 => '',
    1 => 'Jan',
    2 => 'Feb',
    3 => 'Mar',
    4 => 'Apr',
    5 => 'Mai',
    6 => 'Jun',
    7 => 'Jul',
    8 => 'Aug',
    9 => 'Sep',
    10 => 'Okt',
    11 => 'Nov',
    12 => 'Dez',
  ),
  'dom_cal_month_long' => 
  array (
    0 => '',
    1 => 'Januar',
    2 => 'Februar',
    3 => 'M�rz',
    4 => 'April',
    5 => 'Mai',
    6 => 'Juni',
    7 => 'Juli',
    8 => 'August',
    9 => 'September',
    10 => 'Oktober',
    11 => 'November',
    12 => 'Dezember',
  ),
);


?>