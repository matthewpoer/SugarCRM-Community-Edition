<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_LIST_FORM_TITLE' => 'W�hrungen',
  'LBL_CURRENCY' => 'W�hrung',
  'LBL_ADD' => 'Hinzuf�gen',
  'LBL_MERGE' => 'Zusammenf�hren',
  'LBL_MERGE_TXT' => '�berpr�fen Sie die W�hrungen welche Sie mit der gew�hlten W�hrung zusammenf�hren wollen. Dies l�scht alle markierten W�hrungen, die damit verbundenen Betr�ge werden der gew�hlten W�hrung zugewiesen.',
  'LBL_US_DOLLAR' => 'U.S. Dollar',
  'LBL_DELETE' => 'L�schen',
  'LBL_LIST_SYMBOL' => 'W�hrung Symbol',
  'LBL_LIST_NAME' => 'Bezeichnung der W�hrung',
  'LBL_LIST_ISO4217' => 'ISO 4217 Code',
  'LBL_UPDATE' => 'Aktualisieren',
  'LBL_LIST_RATE' => 'Umrechnungsfaktor',
  'LBL_LIST_STATUS' => 'Status',
  'LNK_NEW_CONTACT' => 'Neuer Kontakt',
  'LNK_NEW_ACCOUNT' => 'Neuer Kunde',
  'LNK_NEW_OPPORTUNITY' => 'Neuer Auftrag',
  'LNK_NEW_CASE' => 'Neue Anfrage',
  'LNK_NEW_NOTE' => 'Neue Notiz',
  'LNK_NEW_CALL' => 'Neuer Anruf',
  'LNK_NEW_EMAIL' => 'Neue Email',
  'LNK_NEW_MEETING' => 'Neuer Termin',
  'LNK_NEW_TASK' => 'Neue Aufgabe',
  'NTC_DELETE_CONFIRMATION' => 'Wollen Sie diesen Eintrag wirklich l�schen? M�glicherweise ist es besser den Status auf Inaktiv zu setzen, da ansonsten alle W�hrungen auf US Dollar umgestellt werden.',
  'currency_status_dom' => 
  array (
    'Active' => 'Aktiv',
    'Inactive' => 'Inaktiv',
  ),
);


?>