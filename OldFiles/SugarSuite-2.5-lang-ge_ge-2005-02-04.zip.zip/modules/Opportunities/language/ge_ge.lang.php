<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Auftr�ge',
  'LBL_MODULE_TITLE' => 'Auftr�ge: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Auftr�ge suchen',
  'LBL_LIST_FORM_TITLE' => 'Auftr�ge Liste',
  'LBL_OPPORTUNITY_NAME' => 'Auftrag:',
  'LBL_OPPORTUNITY' => 'Auftrag:',
  'LBL_NAME' => 'Auftrag Namen',
  'LBL_INVITEE' => 'Kontakte',
  'LBL_LIST_OPPORTUNITY_NAME' => 'Auftrag',
  'LBL_LIST_ACCOUNT_NAME' => 'Kunde',
  'LBL_LIST_AMOUNT' => 'Betrag',
  'LBL_LIST_DATE_CLOSED' => 'Geschlossen am',
  'LBL_LIST_SALES_STAGE' => 'Verkaufs Phase',
  'db_sales_stage' => 'LBL_LIST_SALES_STAGE',
  'db_name' => 'LBL_NAME',
  'db_amount' => 'LBL_LIST_AMOUNT',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_date_closed' => 'LBL_LIST_DATE_CLOSED',
  'UPDATE' => 'Auftrag - W�hrung aktualisieren',
  'UPDATE_DOLLARAMOUNTS' => 'Aktualisiere U.S. Dollar Betr�ge',
  'UPDATE_VERIFY' => '�berpr�fe Betr�ge',
//END DON'T CONVERT
  'UPDATE_VERIFY_TXT' => '�berpr�ft ob die Betr�ge in den Auftr�gen g�ltige Deimal Ziffern sind welche nur aus numerischen Charakteren (0-9) und dezimaltrennzeichen (.) bestehen.',
  'UPDATE_FIX' => 'Fixe Betr�ge',
  'UPDATE_FIX_TXT' => 'Versucht jegliche ung�ltigen Betr�ge zu korrigieren indem eine g�ltige Dezimale aus dem jetzigen Betrag erzeugt wird. Dies sichert alle Betr�ge in das Datenbank Feld amount_backup. Falls Sie dies ausf�hren und Problem feststellen, lassen Sie diese Funktion nicht erneut laufen ohne das Sie die gesicherten Werte nicht zur�ckgespielt haben. Ansonsten werden die gesicherten Daten mit ung�ltigen Informatieonen �berschrieben.',
  'UPDATE_DOLLARAMOUNTS_TXT' => 'Aktualisiere die U.S. Dollar Betr�ge f�r die Auftr�ge welche auf den aktuellen Umrechnungsfaktoren basieren. Dieser Eintrag wird benutzt um Diagramme und die Betr�ge in den Listenansichten zu berechnen!',
  'UPDATE_CREATE_CURRENCY' => 'Neue W�hrung:',
  'UPDATE_VERIFY_FAIL' => 'Eintrag konnte nicht �berpr�ft werden:',
  'UPDATE_VERIFY_CURAMOUNT' => 'Jetziger Betrag:',
  'UPDATE_VERIFY_FIX' => 'Die Korrektur ergibt',
  'UPDATE_INCLUDE_CLOSE' => 'Ziehe geschlossene Eintr�ge mit ein',
  'UPDATE_VERIFY_NEWAMOUNT' => 'Neuer Betrag:',
  'UPDATE_VERIFY_NEWCURRENCY' => 'Neue W�hrung:',
  'UPDATE_DONE' => 'Fertig',
  'UPDATE_BUG_COUNT' => 'Bugs Found and Attempted to Resolve:',
  'UPDATE_BUGFOUND_COUNT' => 'Bugs Found:',
  'UPDATE_COUNT' => 'Eintr�ge aktualisiert:',
  'UPDATE_RESTORE_COUNT' => 'Betr�ge wiederhergestellt:',
  'UPDATE_RESTORE' => 'Betr�ge wiederherstellen',
  'UPDATE_RESTORE_TXT' => 'Stellt die Betr�ge aus der Sicherung wieder her.',
  'UPDATE_FAIL' => 'Aktualisierung nicht m�glich - ',
  'UPDATE_NULL_VALUE' => 'Betrag ist leer und wird auf 0 gestellt -',
  'UPDATE_MERGE' => 'W�hrungen zusammenf�hren',
  'UPDATE_MERGE_TXT' => 'Verschiedene W�hrungen in eine einzige W�hrung zusammenf�hren. Falls Sie feststellen das verschiedene W�hrungseintr�ge f�r die selbe W�hrung vorhanden sind so k�nnen Sie diese zusammen f�hren. Dies wird jedoch die W�hrungen in allen anderen Modulen ebenfalls zusammenf�hren.',
  'LBL_ACCOUNT_NAME' => 'Kunde:',
  'LBL_AMOUNT' => 'Betrag:',
  'LBL_CURRENCY' => 'W�hrungen:',
  'LBL_DATE_CLOSED' => 'Voraussichtliches Auftragsdatum:',
  'LBL_TYPE' => 'Typ:',
  'LBL_NEXT_STEP' => 'N�chster Schritt:',
  'LBL_LEAD_SOURCE' => 'Herkunft:',
  'LBL_SALES_STAGE' => 'Verkaufs Phase:',
  'LBL_PROBABILITY' => 'Wahrscheinlichkeit (%):',
  'LBL_DESCRIPTION' => 'Beschreibung:',
  'LBL_DUPLICATE' => 'M�glicherweise Doppelter Auftrag',
  'MSG_DUPLICATE' => 'Dieser Auftrag ist eventuell schon vorhanden. W�hlen Sie deshalb entweder einen Auftrag aus der untenstehenden Liste oder klicken Sie auf Neuen Auftrag um diesen mit den bereits eingegebenen Daten anzulegen.',
  'LBL_NEW_FORM_TITLE' => 'Neuer Kunde',
  'LNK_NEW_OPPORTUNITY' => 'Neuer Auftrag',
  'LNK_OPPORTUNITY_LIST' => 'Auftr�ge',
  'ERR_DELETE_RECORD' => 'Ein Eintrag muss ausgew�hlt sein um ein Auftrag zu l�schen.',
  'LBL_TOP_OPPORTUNITIES' => 'Top Auftr�ge',
  'NTC_REMOVE_OPP_CONFIRMATION' => 'Sind Sie sicher das Sie diesen Kontakt von diesem Auftrag entfernen wollen?',
  'UPDATE_ISSUE_COUNT' => 'Probleme gefunden und versucht zu beheben:',
  'UPDATE_ISSUEFOUND_COUNT' => 'Probleme gefunden:',
  'LNK_NEW_CONTACT' => 'Neuer Kontakt',
  'LNK_NEW_ACCOUNT' => 'Neuer Kunde',
  'LNK_NEW_CASE' => 'Neue Anfrage',
  'LNK_NEW_NOTE' => 'Neue Notiz',
  'LNK_NEW_CALL' => 'Neuer Anruf',
  'LNK_NEW_EMAIL' => 'Neue Email',
  'LNK_NEW_MEETING' => 'Neuer Termin',
  'LNK_NEW_TASK' => 'Neue Aufgabe',
);


?>