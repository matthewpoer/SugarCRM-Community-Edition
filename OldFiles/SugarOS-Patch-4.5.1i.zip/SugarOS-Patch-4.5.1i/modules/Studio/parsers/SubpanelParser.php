<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */





/**
 * interface for studio parsers
 */
 require_once('modules/Studio/parsers/ListViewParser.php');
class SubpanelParser extends ListViewParser {
    var $listViewDefs = false;
	var $defaults = array();
	var $additional = array();
	var $available = array();
  	var $columns = array('LBL_DEFAULT'=>'getDefaultFields', 'LBL_AVAILABLE'=>'getAvailableFields');

    function loadModule($module_name,$child_module){
		$this->parent_module = $module_name;
		$this->child_module = $child_module;
		global $beanList, $beanFiles;
		$class = $beanList[$module_name];
		require_once($beanFiles[$class]);
		require_once('include/SubPanel/SubPanelDefinitions.php');
		$mod = new $class();
		$spd = new SubPanelDefinitions($mod);
		$spd->open_layout_defs(true, '', true);
		$original_panel  = $spd->load_subpanel($child_module, true, true);
		$this->original_list_fields = $original_panel->get_list_fields();
		$spd->open_layout_defs(true, '', false);
		$this->panel  = $spd->load_subpanel($child_module, true);
		$this->list_fields = $this->panel->get_list_fields();
		$this->language_module = $this->panel->template_instance->module_dir;

	}

	/**
	 * returns the default fields for a listview
	 */
	function getDefaultFields(){
		$this->defaults = array();
		foreach($this->list_fields  as $key=>$def){
				if(!empty($def['usage']) && strcmp($def['usage'], 'query_only') == 0)continue;
				if(!empty($def['vname']))$def['label'] = $def['vname'];
				$this->defaults[$key]= $def;
		}
		return $this->defaults;
	}

	function getAvailableFields(){
		$this->availableFields = array();
		foreach($this->original_list_fields as $key=>$def){
			if(!isset($this->list_fields[$key])){
				if(!empty($def['vname']))$def['label'] = $def['vname'];
				$this->availableFields[$key] = $def;
			}
		}
		foreach($this->panel->template_instance->field_defs as $key=>$def){
			//MFH BUG #13890
			if(((empty($def['source']) || $def['source'] == 'db') && $def['type'] !='id' && $def['dbtype'] !='id' && $def['dbType'] !='id' && $def['name'] != 'deleted' || strpos($def['name'],"_name") != false || !empty($def['custom_type'])) && empty($this->list_fields[$key])){
				$this->availableFields[$key] = array('width' => '25', 'label'=> $def['vname'] );
			}
		}
		return $this->availableFields;
	}




    function handleSave(){
    	require_once('include/SubPanel/SubPanel.php');
    	$this->subpanel = new SubPanel($this->parent_module, 'fab4', $this->child_module, $this->panel);
		$newFields = array();

        foreach($this->list_fields as $name => $field){
			if(!isset($field['usage'])|| $field['usage'] != 'query_only'){
				$existingFields[$name] = $field;

			}else{
				$newFields[$name] = $field;
			}
		}

	   global $beanList, $beanFiles;
	   $cMod = !preg_match("/^[a-z]/", $this->child_module) ? $this->child_module : strtoupper($this->child_module[0]) . substr($this->child_module, 1);
	   $class = $beanList[$cMod];
	   if ($class == null ) $class= $this->child_module;
	   $mod = new $class();

	   foreach($_REQUEST['group_0'] as $field){
	   		if(!empty($this->original_list_fields[$field])){
	   		   $newFields[$field] = $this->original_list_fields[$field];
	   		}else{

	   		   $vname = '';
               if(isset($this->panel->template_instance->field_defs[$field])){
					$vname = $this->panel->template_instance->field_defs[$field]['vname'];
			   }

			   if(isset($mod->field_name_map[$field]) &&
			     ($mod->field_name_map[$field]['type'] == 'bool' || (isset($mod->field_name_map[$field]['custom_type']) && $mod->field_name_map[$field]['custom_type'] == 'bool'))) {
			   	 $newFields[$field] = array('name'=>$field, 'vname'=>$vname, 'widget_type'=>'checkbox');
			   } else {
	             $newFields[$field] = array('name'=>$field, 'vname'=>$vname);
			   }
	   		}
	   }

	 $this->subpanel->saveSubPanelDefOverride( $this->panel,'list_fields', $newFields);


    }








}
?>
