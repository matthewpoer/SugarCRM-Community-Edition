--
-- NEW TABLES 
--

-- campaign_trkrs

CREATE TABLE `campaign_trkrs` (
  `id` varchar(36) NOT NULL default '',
  `tracker_name` varchar(30) default NULL,
  `tracker_url` varchar(255) default 'http://',
  `tracker_key` int(11) NOT NULL auto_increment,
  `campaign_id` varchar(36) default NULL,
  `date_entered` datetime NOT NULL default '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL default '0000-00-00 00:00:00',
  `modified_user_id` varchar(36) default NULL,
  `created_by` varchar(36) default NULL,
  `is_optout` tinyint(1) NOT NULL default '0',
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `campaign_tracker_key_idx` (`tracker_key`)) DEFAULT CHARSET=utf8;





























































































-- emails_bugs
CREATE TABLE `emails_bugs` (
  `id` varchar(36) NOT NULL default '',
  `email_id` varchar(36) default NULL,
  `bug_id` varchar(36) default NULL,
  `date_modified` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `idx_bug_email_email` (`email_id`),
  KEY `idx_bug_email_bug` (`bug_id`)) DEFAULT CHARSET=utf8;

-- emails_project_tasks
CREATE TABLE `emails_project_tasks` (
  `id` varchar(36) NOT NULL default '',
  `email_id` varchar(36) default NULL,
  `project_task_id` varchar(36) default NULL,
  `date_modified` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `idx_project_task_email_email` (`email_id`),
  KEY `idx_project_task_email_project_task` (`project_task_id`)) DEFAULT CHARSET=utf8;

-- emails_projects
CREATE TABLE `emails_projects` (
  `id` varchar(36) NOT NULL default '',
  `email_id` varchar(36) default NULL,
  `project_id` varchar(36) default NULL,
  `date_modified` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `idx_project_email_email` (`email_id`),
  KEY `idx_project_email_project` (`project_id`)) DEFAULT CHARSET=utf8;

-- emails_prospects
CREATE TABLE `emails_prospects` (
  `id` varchar(36) NOT NULL default '',
  `email_id` varchar(36) default NULL,
  `prospect_id` varchar(36) default NULL,
  `date_modified` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `idx_prospect_email_email` (`email_id`),
  KEY `idx_prospect_email_prospect` (`prospect_id`)) DEFAULT CHARSET=utf8;















-- emails_tasks
CREATE TABLE `emails_tasks` (
  `id` varchar(36) NOT NULL default '',
  `email_id` varchar(36) default NULL,
  `task_id` varchar(36) default NULL,
  `date_modified` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `idx_task_email_email` (`email_id`),
  KEY `idx_task_email_task` (`task_id`)) DEFAULT CHARSET=utf8;

-- linked_documents
CREATE TABLE `linked_documents` (
  `id` varchar(36) NOT NULL default '',
  `parent_id` varchar(36) default NULL,
  `parent_type` varchar(25) default NULL,
  `document_id` varchar(36) default NULL,
  `document_revision_id` varchar(36) default NULL,
  `date_modified` datetime default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)) DEFAULT CHARSET=utf8;




















-- saved_search
CREATE TABLE `saved_search` (
  `id` varchar(36) NOT NULL default '',
  `name` varchar(150) default NULL,
  `search_module` varchar(150) default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  `date_entered` datetime NOT NULL default '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL default '0000-00-00 00:00:00',
  `assigned_user_id` varchar(36) default NULL,



  `contents` text,
  `description` text,
  PRIMARY KEY  (`id`),
  KEY `idx_desc` (`name`,`deleted`)) DEFAULT CHARSET=utf8;

-- session
CREATE TABLE `session_active` (
   `id` varchar(36) NOT NULL default '',
   `session_id` varchar(100) default NULL,
   `last_request_time` datetime default NULL,
   `session_type` varchar(100) default NULL,
   `is_violation` tinyint(1) default '0',
   `num_active_sessions` int(11) default '0',
   `date_entered` datetime default NULL,
   `date_modified` datetime default NULL,
   `deleted` tinyint(1) NOT NULL default '0',
   PRIMARY KEY  (`id`),
   UNIQUE KEY `idx_session_id` (`session_id`)) DEFAULT CHARSET=utf8;

-- Table structure for table `session_history`
CREATE TABLE `session_history` (
   `id` varchar(36) NOT NULL default '',
   `session_id` varchar(100) default NULL,
   `date_entered` datetime default NULL,
   `date_modified` datetime default NULL,
   `last_request_time` datetime default NULL,
   `session_type` varchar(100) default NULL,
   `is_violation` tinyint(1) default '0',
   `num_active_sessions` int(11) default '0',
   `deleted` tinyint(1) NOT NULL default '0',
   PRIMARY KEY  (`id`)) DEFAULT CHARSET=utf8;

-- user_preferences
CREATE TABLE `user_preferences` (
  `id` varchar(36) NOT NULL default '',
  `category` varchar(50) default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  `date_entered` datetime NOT NULL default '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL default '0000-00-00 00:00:00',
  `assigned_user_id` varchar(36) default NULL,
  `contents` text,
  PRIMARY KEY  (`id`),
  KEY `idx_userprefnamecat` (`assigned_user_id`,`category`)) DEFAULT CHARSET=utf8;

-- users_signatures
CREATE TABLE `users_signatures` (
  `id` varchar(36) NOT NULL default '',
  `date_entered` datetime NOT NULL default '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL default '0000-00-00 00:00:00',
  `deleted` tinyint(1) NOT NULL default '0',
  `user_id` varchar(36) default NULL,
  `name` varchar(255) default NULL,
  `signature` text,
  `signature_html` text,
  PRIMARY KEY  (`id`),
  KEY `idx_user_id` (`user_id`)) DEFAULT CHARSET=utf8;


















--
-- CHANGED TABLES
--

-- campaign_log
ALTER TABLE `campaign_log` ADD COLUMN `more_information` varchar(100) NULL AFTER `date_modified`;

-- campaigns
ALTER TABLE `campaigns` ADD COLUMN `currency_id` varchar(36) NULL AFTER `status`;

-- contacts
ALTER TABLE `contacts` ADD COLUMN `portal_password` varchar(32) NULL AFTER `portal_active`;

-- document_revisions
ALTER TABLE `document_revisions` CHANGE COLUMN `document_id` `document_id` varchar(36) NULL;

-- documents
ALTER TABLE `documents` ADD COLUMN `related_doc_id` varchar(36) NULL AFTER `mail_merge_document`;
ALTER TABLE `documents` ADD COLUMN `related_doc_rev_id` varchar(36) NULL AFTER `related_doc_id`;
ALTER TABLE `documents` ADD COLUMN `is_template` tinyint(1) NULL default '0' AFTER `related_doc_rev_id`;
ALTER TABLE `documents` ADD COLUMN `template_type` varchar(25) NULL AFTER `is_template`;

-- email_marketing
ALTER TABLE `email_marketing` CHANGE COLUMN `campaign_id` `campaign_id` varchar(36) NULL;

-- emails
ALTER TABLE `emails` ADD COLUMN `raw_source` text NULL AFTER `mailbox_id`;

-- fields_meta_data
ALTER TABLE `fields_meta_data` ADD COLUMN `help` varchar(255) NULL AFTER `label`;
ALTER TABLE `fields_meta_data` CHANGE COLUMN `ext1` `ext1` varchar(255) DEFAULT '';
ALTER TABLE `fields_meta_data` CHANGE COLUMN `ext2` `ext2` varchar(255) DEFAULT '';
ALTER TABLE `fields_meta_data` CHANGE COLUMN `ext3` `ext3` varchar(255) DEFAULT '';
ALTER TABLE `fields_meta_data` ADD COLUMN `ext4` text NULL AFTER `ext3`;
ALTER TABLE `fields_meta_data` ADD COLUMN `duplicate_merge` smallint(6) default 0 AFTER `ext4`;









-- inbound_email
ALTER TABLE `inbound_email` CHANGE COLUMN `stored_options` `stored_options` text NULL;

























-- users
ALTER TABLE `users` CHANGE COLUMN `user_name` `user_name` varchar(60) NULL;
ALTER TABLE `users` ADD COLUMN `authenticate_id` varchar(100) NULL AFTER `user_hash`;
ALTER TABLE `users` ADD COLUMN `sugar_login` tinyint(1) NULL default '1' AFTER `authenticate_id`;
UPDATE `users` SET is_admin = '1' WHERE is_admin = 'on';
UPDATE `users` SET is_admin = '0' WHERE is_admin != '1';
ALTER TABLE `users` CHANGE COLUMN `is_admin` `is_admin` tinyint(1) NULL default '0';
ALTER TABLE `users` CHANGE COLUMN `receive_notifications` `receive_notifications` tinyint(1) NULL default '1';


--
-- LONGTEXT CONVERSION
--
-- accounts
ALTER TABLE `accounts` CHANGE COLUMN `description` `description` longtext NULL;
-- accounts_audit
ALTER TABLE `accounts_audit` CHANGE COLUMN `before_value_text` `before_value_text` longtext NULL, CHANGE COLUMN `after_value_text` `after_value_text` longtext NULL;
-- acl_roles
ALTER TABLE `acl_roles` CHANGE COLUMN `description` `description` longtext NULL;
-- bugs
ALTER TABLE `bugs` CHANGE COLUMN `description` `description` longtext NULL, CHANGE COLUMN `work_log` `work_log` longtext NULL;
-- bugs_audit
ALTER TABLE `bugs_audit` CHANGE COLUMN `before_value_text` `before_value_text` longtext NULL, CHANGE COLUMN `after_value_text` `after_value_text` longtext NULL;
-- calls
ALTER TABLE `calls` CHANGE COLUMN `description` `description` longtext NULL;
-- campaigns
ALTER TABLE `campaigns` CHANGE COLUMN `objective` `objective` longtext NULL, CHANGE COLUMN `content` `content` longtext NULL;
-- campaigns_audit
ALTER TABLE `campaigns_audit` CHANGE COLUMN `before_value_text` `before_value_text` longtext NULL, CHANGE COLUMN `after_value_text` `after_value_text` longtext NULL;
-- cases
ALTER TABLE `cases` CHANGE COLUMN `description` `description` longtext NULL, CHANGE COLUMN `resolution` `resolution` longtext NULL;
-- cases_audit
ALTER TABLE `cases_audit` CHANGE COLUMN `before_value_text` `before_value_text` longtext NULL, CHANGE COLUMN `after_value_text` `after_value_text` longtext NULL;
-- config
ALTER TABLE `config` CHANGE COLUMN `value` `value` longtext NULL;

-- contacts
ALTER TABLE `contacts` CHANGE COLUMN `description` `description` longtext NULL;
-- contacts_audit
ALTER TABLE `contacts_audit` CHANGE COLUMN `before_value_text` `before_value_text` longtext NULL, CHANGE COLUMN `after_value_text` `after_value_text` longtext NULL;




-- dashboards
ALTER TABLE `dashboards` CHANGE COLUMN `description` `description` longtext NULL, CHANGE COLUMN `content` `content` longtext NULL;




-- documents
ALTER TABLE `documents` CHANGE COLUMN `description` `description` longtext NULL;
-- email_templates
ALTER TABLE `email_templates` CHANGE COLUMN `description` `description` longtext NULL, CHANGE COLUMN `body` `body` longtext NULL, CHANGE COLUMN `body_html` `body_html` longtext NULL;

-- emails
ALTER TABLE `emails` CHANGE COLUMN `description` `description` longtext NULL,
CHANGE COLUMN `description_html` `description_html` longtext NULL,
CHANGE COLUMN `to_addrs` `to_addrs` longtext NULL,
CHANGE COLUMN `cc_addrs` `cc_addrs` longtext NULL,
CHANGE COLUMN `bcc_addrs` `bcc_addrs` longtext NULL,
CHANGE COLUMN `to_addrs_ids` `to_addrs_ids` longtext NULL,
CHANGE COLUMN `to_addrs_names` `to_addrs_names` longtext NULL,
CHANGE COLUMN `to_addrs_emails` `to_addrs_emails` longtext NULL,
CHANGE COLUMN `cc_addrs_ids` `cc_addrs_ids` longtext NULL,
CHANGE COLUMN `cc_addrs_names` `cc_addrs_names` longtext NULL,
CHANGE COLUMN `cc_addrs_emails` `cc_addrs_emails` longtext NULL,
CHANGE COLUMN `bcc_addrs_ids` `bcc_addrs_ids` longtext NULL,
CHANGE COLUMN `bcc_addrs_names` `bcc_addrs_names` longtext NULL,
CHANGE COLUMN `bcc_addrs_emails` `bcc_addrs_emails` longtext NULL;
-- feeds
ALTER TABLE `feeds` CHANGE COLUMN `description` `description` longtext NULL;
-- leads
ALTER TABLE `leads` CHANGE COLUMN `lead_source_description` `lead_source_description` longtext NULL,
CHANGE COLUMN `status_description` `status_description` longtext NULL,
CHANGE COLUMN `description` `description` longtext NULL,
CHANGE COLUMN `account_description` `account_description` longtext NULL;

-- leads_audit
ALTER TABLE `leads_audit` CHANGE COLUMN `before_value_text` `before_value_text` longtext NULL, CHANGE COLUMN `after_value_text` `after_value_text` longtext NULL;
-- meetings
ALTER TABLE `meetings` CHANGE COLUMN `description` `description` longtext NULL;
-- notes
ALTER TABLE `notes` CHANGE COLUMN `description` `description` longtext NULL;
-- opportunities
ALTER TABLE `opportunities` CHANGE COLUMN `description` `description` longtext NULL;
-- opportunities_audit
ALTER TABLE `opportunities_audit` CHANGE COLUMN `before_value_text` `before_value_text` longtext NULL, CHANGE COLUMN `after_value_text` `after_value_text` longtext NULL;

















-- project
ALTER TABLE `project` CHANGE COLUMN `description` `description` longtext NULL;
-- project_task
ALTER TABLE `project_task` CHANGE COLUMN `description` `description` longtext NULL;
-- project_task_audit
ALTER TABLE `project_task_audit` CHANGE COLUMN `before_value_text` `before_value_text` longtext NULL, CHANGE COLUMN `after_value_text` `after_value_text` longtext NULL;
-- prospect_lists
ALTER TABLE `prospect_lists` CHANGE COLUMN `description` `description` longtext NULL;
-- prospects
ALTER TABLE `prospects` CHANGE COLUMN `description` `description` longtext NULL;












-- roles
ALTER TABLE `roles` CHANGE COLUMN `description` `description` longtext NULL, CHANGE COLUMN `modules` `modules` longtext NULL;
-- tasks
ALTER TABLE `tasks` CHANGE COLUMN `description` `description` longtext NULL;








-- users
ALTER TABLE `users` CHANGE COLUMN `description` `description` longtext NULL, CHANGE COLUMN `user_preferences` `user_preferences` longtext NULL;
-- vcals
ALTER TABLE `vcals` CHANGE COLUMN `content` `content` longtext NULL;










--
-- INDICES
--

-- accounts
ALTER TABLE `accounts` DISABLE KEYS;
-- [added newly]
ALTER TABLE `accounts` ADD INDEX `idx_accnt_assigned_del` (`deleted`, `assigned_user_id`);
-- [added newly]
ALTER TABLE `accounts` ADD INDEX `idx_accnt_parent_id` (`parent_id`);
ALTER TABLE `accounts` ENABLE KEYS;

-- acl_roles_actions
ALTER TABLE `acl_roles_actions` DISABLE KEYS;
-- [added newly]
ALTER TABLE `acl_roles_actions` ADD INDEX `idx_aclrole_action` (`role_id`, `action_id`);
ALTER TABLE `acl_roles_actions` ENABLE KEYS;

-- acl_roles_users
ALTER TABLE `acl_roles_users` DISABLE KEYS;
-- [added newly]
ALTER TABLE `acl_roles_users` ADD INDEX `idx_aclrole_user` (`role_id`, `user_id`);
ALTER TABLE `acl_roles_users` ENABLE KEYS;

-- campaign_log
ALTER TABLE `campaign_log` DISABLE KEYS;
-- [added newly]
ALTER TABLE `campaign_log` ADD INDEX `idx_camp_tracker` (`target_tracker_key`);
-- [added newly]
ALTER TABLE `campaign_log` ADD INDEX `idx_camp_campaign_id` (`campaign_id`);
-- [added newly]
ALTER TABLE `campaign_log` ADD INDEX `idx_camp_more_info` (`more_information`);
ALTER TABLE `campaign_log` ENABLE KEYS;

-- campaigns
ALTER TABLE `campaigns` DISABLE KEYS;
-- [added newly]
ALTER TABLE `campaigns` ADD INDEX `camp_auto_tracker_key` (`tracker_key`);
-- [dropping index]
ALTER TABLE `campaigns` DROP INDEX `auto_tracker_key`;
ALTER TABLE `campaigns` ENABLE KEYS;

-- config
ALTER TABLE `config` DISABLE KEYS;
-- [added newly]
ALTER TABLE `config` ADD INDEX `idx_config_cat` (`category`);
ALTER TABLE `config` ENABLE KEYS;

-- contacts
ALTER TABLE `contacts` DISABLE KEYS;
-- [added newly]
ALTER TABLE `contacts` ADD INDEX `idx_cont_assigned` (`assigned_user_id`);
-- [added newly]
ALTER TABLE `contacts` ADD INDEX `idx_cont_email1` (`email1`);
-- [added newly]
ALTER TABLE `contacts` ADD INDEX `idx_cont_email2` (`email2`);
ALTER TABLE `contacts` ENABLE KEYS;

-- currencies
ALTER TABLE `currencies` DISABLE KEYS;
-- [added newly]
ALTER TABLE `currencies` ADD INDEX `idx_currency_name` (`name`, `deleted`);
-- [dropping index]
ALTER TABLE `currencies` DROP INDEX `idx_cont_name`;
ALTER TABLE `currencies` ENABLE KEYS;

-- dashboards
ALTER TABLE `dashboards` DISABLE KEYS;
-- [added newly]
ALTER TABLE `dashboards` ADD INDEX `idx_dashboard_name` (`name`, `deleted`);
-- [dropping index]
ALTER TABLE `dashboards` DROP INDEX `idx_desc`;
ALTER TABLE `dashboards` ENABLE KEYS;

-- emailman
ALTER TABLE `emailman` DISABLE KEYS;
-- [added newly]
ALTER TABLE `emailman` ADD INDEX `idx_eman_campaign_id` (`campaign_id`);
ALTER TABLE `emailman` ENABLE KEYS;

-- emails
ALTER TABLE `emails` DISABLE KEYS;
-- [added newly]
ALTER TABLE `emails` ADD INDEX `idx_email_parent_id` (`parent_id`);




-- [added newly]
ALTER TABLE `emails` ADD INDEX `idx_email_assigned` (`assigned_user_id`, `type`, `status`);
ALTER TABLE `emails` ENABLE KEYS;

-- feeds
ALTER TABLE `feeds` DISABLE KEYS;
-- [added newly]
ALTER TABLE `feeds` ADD INDEX `idx_feed_name` (`title`, `deleted`);
-- [dropping index]
ALTER TABLE `feeds` DROP INDEX `idx_desc`;
ALTER TABLE `feeds` ENABLE KEYS;

-- import_maps
ALTER TABLE `import_maps` DISABLE KEYS;
-- [added newly]
ALTER TABLE `import_maps` ADD INDEX `idx_owner_module_name` (`assigned_user_id`, `module`, `name`, `deleted`);
-- [dropping index]
ALTER TABLE `import_maps` DROP INDEX `idx_cont_owner_id_module_and_name`;
ALTER TABLE `import_maps` ENABLE KEYS;

-- leads
ALTER TABLE `leads` DISABLE KEYS;
-- [added newly]
ALTER TABLE `leads` ADD INDEX `idx_lead_email1` (`email1`, `deleted`);
-- [added newly]
ALTER TABLE `leads` ADD INDEX `idx_lead_email2` (`email2`, `deleted`);
-- [added newly]
ALTER TABLE `leads` ADD INDEX `idx_lead_assigned` (`assigned_user_id`);
-- [added newly]
ALTER TABLE `leads` ADD INDEX `idx_lead_contact` (`contact_id`);
ALTER TABLE `leads` ENABLE KEYS;

-- notes
ALTER TABLE `notes` DISABLE KEYS;
-- [added newly]
ALTER TABLE `notes` ADD INDEX `idx_notes_parent` (`parent_id`, `parent_type`);
-- [added newly]
ALTER TABLE `notes` ADD INDEX `idx_note_contact` (`contact_id`);
ALTER TABLE `notes` ENABLE KEYS;

-- opportunities
ALTER TABLE `opportunities` DISABLE KEYS;
-- [added newly]
ALTER TABLE `opportunities` ADD INDEX `idx_opp_assigned` (`assigned_user_id`);
ALTER TABLE `opportunities` ENABLE KEYS;

-- prospects
ALTER TABLE `prospects` DISABLE KEYS;
-- [added newly]
ALTER TABLE `prospects` ADD INDEX `prospect_auto_tracker_key` (`tracker_key`);
-- [dropping index]
ALTER TABLE `prospects` DROP INDEX `auto_tracker_key`;
ALTER TABLE `prospects` ENABLE KEYS;



























-- tasks
ALTER TABLE `tasks` DISABLE KEYS;
-- [added newly]
ALTER TABLE `tasks` ADD INDEX `idx_task_assigned` (`assigned_user_id`);
ALTER TABLE `tasks` ENABLE KEYS;



















-- users
ALTER TABLE `users` DISABLE KEYS;
-- [added newly]
ALTER TABLE `users` ADD INDEX `user_name_idx` (`user_name`);
-- [added newly]
ALTER TABLE `users` ADD INDEX `user_password_idx` (`user_password`);
-- [dropping index]
ALTER TABLE `users` DROP INDEX `user_name`;
-- [dropping index]
ALTER TABLE `users` DROP INDEX `user_password`;
ALTER TABLE `users` ENABLE KEYS;


