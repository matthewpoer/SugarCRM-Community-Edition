<?php
	// $Id: sugar_version.php,v 1.3 2005/02/12 03:13:49 andrew Exp $
	$sugar_version = '2.5.1beta';
?>
