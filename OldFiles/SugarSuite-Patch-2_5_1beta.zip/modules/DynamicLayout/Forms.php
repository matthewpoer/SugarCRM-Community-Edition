<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

function get_chooser_js() {
	// added here for compatibility
}

function get_validate_record_js() {

}
function get_new_record_form () {
require_once('modules/DynamicLayout/AddField.php');
global $image_path;
if(empty($_REQUEST['edit_row_MSI']) && $_REQUEST['action'] != 'SelectFile' && !empty($_SESSION['dyn_layout_file'])){
$addfield = new AddField();

$font_slot = '<IMG src="'.$image_path.'slot.gif" alt="Slot" border="0" >';
$slot_path =$image_path ."slot.gif";
$html =  get_left_form_header("Toolbox");
$plus = get_image($image_path."plus_inline.png",'style="margin-left:4px;margin-right:4px;" alt="Add Field" border="0" align="absmiddle"');
$delete = get_image($image_path."delete_inline.png","border='0' alt='Delete' style='margin-left:4px;margin-right:4px;'");
$delete_items = $addfield->get_html();
$html .=<<<EOQ
<script>
var slot_path = '{$slot_path}';
var font_slot = '{$font_slot}';
</script>
<script  src="modules/DynamicLayout/DynamicLayout.js"></script>
<p>
<input type='checkbox' class="checkbox" style='vertical-align: middle;' id='display_html_MSI' name='display_html_MSI' > Display HTML Code <br>
<a href='#' onclick='addFieldPOPUP()' class='leftColumnModuleS3Link'>$plus</a> <a href='#' onclick='addFieldPOPUP()' class='leftColumnModuleS3Link'>Add Field</a>

<p>$delete_items</p>

EOQ;

$html .= get_left_form_footer();
return $html;
}


}

?>
