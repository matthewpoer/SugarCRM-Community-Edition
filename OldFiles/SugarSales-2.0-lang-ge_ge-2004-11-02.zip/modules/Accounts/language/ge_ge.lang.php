<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.2 2004/10/29 15:59:25 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Kunden',
  'LBL_MODULE_TITLE' => 'Kunden: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Kunden suchen',
  'LBL_LIST_FORM_TITLE' => 'Kundenliste',
  'LBL_NEW_FORM_TITLE' => 'Neuer Kunde',
  'LBL_MEMBER_ORG_FORM_TITLE' => 'Organisation',
  'LBL_LIST_ACCOUNT_NAME' => 'Namen',
  'LBL_LIST_CITY' => 'Ort',
  'LBL_LIST_WEBSITE' => 'Web',
  'LBL_LIST_STATE' => 'Bundesland',
  'LBL_LIST_PHONE' => 'Telefon',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email Adresse',
  'LBL_LIST_CONTACT_NAME' => 'Kontakt Name',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_website' => 'LBL_LIST_WEBSITE',
  'db_billing_address_city' => 'LBL_LIST_CITY',
//END DON'T CONVERT
  'LBL_ACCOUNT_INFORMATION' => 'Kunde',
  'LBL_ACCOUNT' => 'Kunde:',
  'LBL_ACCOUNT_NAME' => 'Namen:',
  'LBL_PHONE' => 'Telefon:',
  'LBL_WEBSITE' => 'Web:',
  'LBL_FAX' => 'Fax:',
  'LBL_TICKER_SYMBOL' => 'Ticker Symbol:',
  'LBL_OTHER_PHONE' => 'Weitere Telefonnummer:',
  'LBL_ANY_PHONE' => 'Andere Telefonnummer:',
  'LBL_MEMBER_OF' => 'Mitglied von:',
  'LBL_EMAIL' => 'Email:',
  'LBL_EMPLOYEES' => 'Mitarbeiter:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Andere Email:',
  'LBL_ANY_EMAIL' => 'Weitere Email:',
  'LBL_OWNERSHIP' => 'Eigent�mer:',
  'LBL_RATING' => 'Bewertung:',
  'LBL_INDUSTRY' => 'Branche:',
  'LBL_SIC_CODE' => 'SIC Code:',
  'LBL_TYPE' => 'Typ:',
  'LBL_ANNUAL_REVENUE' => 'Erl�s pro Jahr:',
  'LBL_ADDRESS_INFORMATION' => 'Addressinformationen',
  'LBL_BILLING_ADDRESS' => 'Rechnungs Adresse:',
  'LBL_SHIPPING_ADDRESS' => 'Liefer Adresse:',
  'LBL_ANY_ADDRESS' => 'weitere Adresse:',
  'LBL_CITY' => 'Ort:',
  'LBL_STATE' => 'Bundesland:',
  'LBL_POSTAL_CODE' => 'PLZ:',
  'LBL_COUNTRY' => 'Land:',
  'LBL_DESCRIPTION_INFORMATION' => 'Zus�tzliche Informationen',
  'LBL_DESCRIPTION' => 'Beschreibung:',
  'NTC_COPY_BILLING_ADDRESS' => 'Rechnungs Adresse in Liefer Adresse kopieren',
  'NTC_COPY_SHIPPING_ADDRESS' => 'Liefer Adresse in Rechnungs Adresse kopieren',
  'NTC_REMOVE_MEMBER_ORG_CONFIRMATION' => 'Sind Sie sicher das Sie diesen Eintrag als Mitglieder Organisation entfernen wollen?',
  'LBL_DUPLICATE' => 'Possible Duplicate Account',
  'MSG_DUPLICATE' => 'Creating this account may potentialy create a duplicate account. You may either select an account from the list below or you may click on Create New Account to continue creating a new account with the previously entered data.',
  'LNK_NEW_ACCOUNT' => 'Neuer Kunde',
  'LNK_ACCOUNT_LIST' => 'Accounts',
  'LBL_INVITEE' => 'Kontakte',
  'ERR_DELETE_RECORD' => 'Ein Eintrag muss ausgew�hlt sein um ein Kunde zu l�schen.',
  'LNK_NEW_CONTACT' => 'Neuer Kontakt',
  'LNK_NEW_OPPORTUNITY' => 'Neuer Auftrag',
  'LNK_NEW_CASE' => 'Neue Anfrage',
  'LNK_NEW_NOTE' => 'Neue Notiz',
  'LNK_NEW_CALL' => 'Neues Telefonat',
  'LNK_NEW_EMAIL' => 'Neue Email',
  'LNK_NEW_MEETING' => 'Neuer Termin',
  'LNK_NEW_TASK' => 'Neue Aufgabe',
);


?>