Sugar Suite v3.0a
May 2, 2005

-=Overview=-
For a quick list of new features in Sugar Suite 3.0, check out 
the information below.

Our goal continues to be to build the customer relationship management 
system that you have always wanted, so your input is vital.

You can submit your feedback about the new release to our Sugar Forums
(http://www.sugarcrm.com/forums/).





Check out http://www.sugarcrm.com for more details on acquiring the Sugar 
Suite, the latest product roadmap, support forums, detailed 
product information and much more.  We hope you find this a useful tool
for building your business.

Enjoy! 
The Sugar Team  

-=IMPORTANT NOTES=-
Special Upgrade Install:
The 3.0 release provides an upgrade script and instructions that 
automates many, but not all, of the steps necessary to migrate 
a 2.5.1x version of Sugar Suite to the 3.0 release. The instructions
can be found with the 3.0 download, in the file 
"3_0 Upgrade Instructions.rtf".


--------------------------------------------------------------------------------
3.0a
--------------------------------------------------------------------------------
 * Made email template functionality visible to create, view and include a
   template when composing an email.

--------------------------------------------------------------------------------
3.0
--------------------------------------------------------------------------------
-=New Features=-
New features in Sugar Suite 3.0 include:

 * Role support has been added to the 3.0 release allowing administrators
   to define a role, the tabs that a role are allowed to access, and 
   then add users to the role. Users can belong to multiple roles giving
   them access to the union of all roles.
 * Campaign management, allowing users to organize marketing activities
   and measure their effectiveness and influence on the sales pipeline.
   Users can manage and track marketing efforts associated to leads, 
   contacts and opportunities for closed-loop marketing analysis.
 * List designer, providing query, list management and list filtering 
   tools that allow personnel to segment contact databases for target
   marketing purposes.  Users can query the system to generate lists 
   targeting specific audiences, and then save the queries for re-use 
   for similar future campaigns. Users can also import temporary lists
   such as those rented from brokers or data service providers.
 * Email marketing, enabling marketing teams to create email templates
   that can be personalized for recipients and sent as email blasts on
   any desired schedule.  The email is then recorded as sent within the
   lead or contact history, enabling a 360-degree view of the customer.
 * Document management, providing a central repository for product
   briefs, data sheets, collateral materials and other documents
   required by sales, marketing, and support teams.
 * Project management, a group collaboration tool that allows
   organizations to define steps, establish timelines, and assign work
   to members on any project relevant to end users.
 * Employee directory, including search functions by first or last
   names, roles, departments and basic contact information.  This 
   permits quick employee lookups without leaving the Sugar Suite
   application.
 * Calendaring synchronization, enabling users to use Sugar Suite for
   full group calendaring utilizing scheduling information managed both
   inside and outside of the Sugar Suite application. The new Sugar
   free/busy server can communicate  with any client calendaring system
   that can reference a free/busy published service such as Microsoft
   Outlook(R) or Mac iCal(R).
 * Administration enhancements that allow Sugar Suite to be customized
   easier, scale better, and offer more advanced security.













