<?php
	// $Id: sugar_version.php,v 1.34.2.2 2005/05/02 22:14:58 bob Exp $
	$sugar_version = '3.0a';
?>
