<?php
/**
 * Subpanel definition classes to ease the use of layout_defs.php
 *
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */

// $Id: SubPanelDefinitions.php,v 1.14 2005/08/17 20:30:26 ajay Exp $

//input
//	module directory
//constructor
//	open the layout_definitions file.
//
class aSubPanel {
	
	var $name;
	var $_instance_properties;
	
	var $mod_strings;
	var $panel_definition;
	var $sub_subpanels;
	var $parent_bean;
	
	//module's table name and column fields.
	var $table_name;
	var $db_fields;
	var $bean_name;
	var $template_instance; 

	function aSubPanel($name,$instance_properties, $parent_bean, $reload = false) {

		global $current_language;
		$this->_instance_properties=&$instance_properties;
		$this->name=&$name;
		$this->parent_bean=&$parent_bean;
			
		if ($this->isCollection()) { 
			//this will be true sub-panels like activities. in these cases default to the parent module.
			require('modules/'.$parent_bean->module_dir.'/language/'.$current_language.'.lang.php');
			$this->mod_strings=&$mod_strings;

			$this->load_sub_subpanels(); //load sub-panel definition.
		} else {
			require('modules/'.$instance_properties['module'].'/language/'.$current_language.'.lang.php');
			$this->mod_strings=&$mod_strings;
			//load definition of the named subpanel style.
			$def_path = 'modules/'.$this->_instance_properties['module'].'/subpanels/'.$this->_instance_properties['subpanel_name'].'.php';
			if(!$reload){
				include_once($def_path);
			}else{
				include($def_path);	
			}
			
			if(isset($this->_instance_properties['override_subpanel_name']) && file_exists('custom/modules/'.$this->_instance_properties['module'].'/subpanels/'.$this->_instance_properties['override_subpanel_name'].'.php')){
			$cust_def_path = 'custom/modules/'.$this->_instance_properties['module'].'/subpanels/'.$this->_instance_properties['override_subpanel_name'].'.php';
			if(!$reload){
				include_once($cust_def_path);
			}else{
				include($cust_def_path);	
			}
			}
			$this->panel_definition=&$subpanel_layout;
			$this->load_module_info();   //load module info from the module's bean file.
		}


	}
	
	function distinct_query() {
		if (isset($this->_instance_properties['get_distinct_data'])) {
			
			if (!empty($this->_instance_properties['get_distinct_data']))
				return true;
			else 
				return false;
		}
		return false;
	}
	
	//return the translated header value.
	function get_title() {
		return $this->mod_strings[$this->_instance_properties['title_key']];		
	}
	
	//return the definition of buttons. looks for buttons in 2 locations.
	function get_buttons() {
		$buttons=array();
		if (isset($this->_instance_properties['top_buttons'])) {
			//this will happen only in the case of sub-panels with multiple sources(activities).
			$buttons=$this->_instance_properties['top_buttons'];
		}
		else {
			$buttons=$this->panel_definition['top_buttons'];
		}

		// permissions. hide SubPanelTopComposeEmailButton from activities if email module is disabled.
		//only email is  being tested becuase other submodules in activites/history such as notes, tasks, meetings and calls cannot be disabled.
		//as of today these are the only 2 sub-panels that use the union clause. 
		$mod_name=$this->get_module_name();
		if ($mod_name=='Activities' or $mod_name='History') {
			global $modListHeader;
			global $modules_exempt_from_availability_check;
			if (!(array_key_exists('Emails',$modListHeader) or  array_key_exists('Emails',$modules_exempt_from_availability_check))) {
				foreach($buttons as $key=>$button) {
					foreach ($button as $property=>$value) { 
						if ($value == 'SubPanelTopComposeEmailButton' or $value=='SubPanelTopArchiveEmailButton') {
							//remove this button from the array.
							unset($buttons[$key]);
						}
					}	
				}				
			}
		}

		return $buttons;
	}

	//call this function for sub-panels that have unions.
	function load_sub_subpanels() {
		global $modListHeader;
		global $modules_exempt_from_availability_check;
		
		if (empty($this->sub_subpanels)) {
			$panels=$this->get_inst_prop_value('collection_list');
			foreach ($panels as $panel=>$properties) {								
				if (array_key_exists($properties['module'],$modListHeader) or  array_key_exists($properties['module'],$modules_exempt_from_availability_check)) {
					$this->sub_subpanels[$panel]=&new aSubPanel($panel,$properties,$this->parent_bean);
				}
			}
		}
	}
	
	function isDatasourceFunction() {
		if (strpos($this->get_inst_prop_value('get_subpanel_data'), 'function') === false) {
			return false;
		}	
		return true;
	}	
	function isCollection() {
		if ($this->get_inst_prop_value('type')== 'collection') return true;
		else return false;	
	}
	
	//get value of a property defined at the panel instance level.
	function get_inst_prop_value($name) {
		if (isset($this->_instance_properties[$name]))
			return $this->_instance_properties[$name];
		else
			return null;	
	}
	//get value of a property defined at the panel definition level.
	function get_def_prop_value($name) {
		
		if (isset($this->panel_definition[$name])) { 
			return $this->panel_definition[$name];
		} else {
			return null;
		}	
	}
	
	//if datasource is of the type function then return the function name
	//else return the value as is.
	function get_data_source_name() {
		if ($this->isDatasourceFunction()) {
			return (substr_replace($this->get_inst_prop_value('get_subpanel_data'),'',0,9));
		} else {
			return $this->get_inst_prop_value('get_subpanel_data');
		}
	} 
	//returns the where clause for the query.
	function get_where() {
		return $this->get_def_prop_value('where');
	}
	
	function is_fill_in_additional_fields(){
		
		return 	$this->get_def_prop_value('fill_in_additional_fields');
	}
	
	//returns the default order by clause.
	function get_default_order_by() {
		return $this->get_def_prop_value('default_order_by');
	}
	function get_list_fields() {
		if (isset($this->panel_definition['list_fields'])) {
			return $this->panel_definition['list_fields'];
		} else {
			return array();
		}
	}
	
	function get_module_name() {
		return $this->get_inst_prop_value('module');			
	}
	
	//load subpanel mdoule's table name and column fields.
	function load_module_info() {
		global $beanList;
		global $beanFiles;
		
		$module_name=$this->get_module_name();
		if (!empty($module_name)) {
			
			$bean_name=$beanList[$this->get_module_name()];
			$this->bean_name=$bean_name;
		
			include_once ($beanFiles[$bean_name]);
			$this->template_instance=new $bean_name;
			$this->template_instance->force_load_details = true;
			$this->table_name=&$this->template_instance->table_name;
			$this->db_fields=&$this->template_instance->column_fields;
		}
	}
	//this function is to be used only with sub-panels that are based 
	//on collections.
	function get_header_panel_def() {
		if (!empty($this->sub_subpanels)) {
			if (!empty($this->_instance_properties['header_definition_from_subpanel']) && !empty($this->sub_subpanels[$this->_instance_properties['header_definition_from_subpanel']])) {
				return $this->sub_subpanels[$this->_instance_properties['header_definition_from_subpanel']];
			}
			reset($this->sub_subpanels);
			return current($this->sub_subpanels);
		}
		return this;		
	}

	/**
	 * Returns an array of current properties of the class.
	 * It will simply give the class name for instances of classes.
	 */
	function _to_array()
	{
		return array(
			'_instance_properties' => $this->_instance_properties,
			'db_fields' => $this->db_fields,
			'mod_strings' => $this->mod_strings,
			'name' => $this->name,
			'panel_definition' => $this->panel_definition,
			'parent_bean' => get_class($this->parent_bean),
			'sub_subpanels' => $this->sub_subpanels,
			'table_name' => $this->table_name,
			'template_instance' => get_class($this->template_instance),
		);
	}
};


class SubPanelDefinitions {

	var $_focus;
	var $_visible_tabs_array;
	var $panels;
	var $layout_defs;
		
	function SubPanelDefinitions($focus) {
		$this->_focus=&$focus;
		$this->open_layout_defs();
	}	

	/**
	 * This function returns an ordered list of the tabs.
	 */
	function get_available_tabs() {
		global $modListHeader;
		global $modules_exempt_from_availability_check;
		
		if (isset($this->_visible_tabs_array)) return $this->_visible_tabs_array;
		
		foreach ($this->layout_defs['subpanel_setup'] as $key=>$values_array) {
			//check permissions.
			if(array_key_exists($values_array['module'], $modules_exempt_from_availability_check) or array_key_exists($values_array['module'], $modListHeader)) {
				$this->visible_tabs_array[$values_array['order']]=$key;
			}	
		}
		ksort($this->visible_tabs_array);
		return $this->visible_tabs_array;
	}
	
	/**
	 * Load the definition of the a sub-panel.
	 * Also the sub-panel is added to an array of sub-panels.
	 * use of reload has been deprecated, since the subpanel is initialized every time.
	 */
	function load_subpanel($name, $reload=false) {
		$panel=new aSubPanel($name,$this->layout_defs['subpanel_setup'][strtolower($name)],$this->_focus, $reload);
		return $panel;
	}
	
	/**
	 * Load the layout def file and associate the definition with a variable in the file.
	 */
	function open_layout_defs($reload=false) {
		
		if (empty($this->layout_defs) || $reload) {
			require('modules/'.$this->_focus->module_dir.'/layout_defs.php');
			if(file_exists('custom/modules/'.$this->_focus->module_dir . '/Ext/Layoutdefs/layoutdefs.ext.php')){
  				
  				require('custom/modules/'.$this->_focus->module_dir . '/Ext/Layoutdefs/layoutdefs.ext.php');
  				
  			}
  			
			$this->layout_defs=$layout_defs[$this->_focus->module_dir];
		
		} 
	}
	
	/**
	 * Removes a tab from the list of loaded tabs.
	 * Returns true if successful, false otherwise.
	 * Hint: Used by Campaign's DetailView.
	 */
	function exclude_tab($tab_name)
	{
		$result = false;
		if(!empty($this->layout_defs['subpanel_setup'][$tab_name]))
		{
			unset($this->layout_defs['subpanel_setup'][$tab_name]);
		}
		
		return $result;
	}
}
?>
