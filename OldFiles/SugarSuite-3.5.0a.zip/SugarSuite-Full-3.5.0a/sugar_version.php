<?php
    // $Id: sugar_version.php,v 1.40 2005/08/17 23:35:58 bob Exp $
    $sugar_version      = '3.5.0a';
    $sugar_db_version   = '3.5.0';
    $sugar_flavor       = 'OS';
?>
