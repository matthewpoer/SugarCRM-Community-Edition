<?PHP
if( !isset($upgrade_script) || ($upgrade_script == false) ){
	die('Unable to process script directly.');
}


$sugar_config['default_currency_name'] = 'U.S. Dollar';
$sugar_config['default_currency_symbol'] = '$';
$sugar_config['default_currency_iso4217'] = 'USD';

$query_count = 0;
$execute = true;
$export = false;

$log =& LoggerManager::getLogger('index');


set_time_limit(600);
	if(!$export){
    // flush after each output so the user can see the progress in real-time
    ob_implicit_flush();
?>
<html>
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
   <meta http-equiv="Content-Script-Type" content="text/javascript">
   <meta http-equiv="Content-Style-Type" content="text/css">
   <title>SugarCRM Upgrade Wizard: Step <?php echo $next_step ?></title>
   <link rel="stylesheet" href="upgrade.css" type="text/css" />
</head>
<body>
<form action="index.php" method="post" id="form">
<table cellspacing="0" cellpadding="0" border="0" align="center" class="shell" style="height=15px;margin-bottom=0px">
<tr>
   <th width="400">Step <?php echo $next_step ?>: GMT Date Upgrade</th>
   <th width="200" height="30" style="text-align: right;"><a href="http://www.sugarcrm.com" target=
      "_blank"><IMG src="../include/images/sugarcrm_login.png" width="120" height="19" alt="SugarCRM" border="0"></a></th>
</tr>
<tr>
   <td colspan="2" width="800">
<?PHP
}
require_once('include/database/PearDatabase.php');
require_once('include/modules.php');
require_once('include/utils.php');
require_once('include/TimeDate.php');
$timedate =  new TimeDate();



$db =& PearDatabase::getInstance();


$sql= "/* MAIN TABLES */\n";

foreach($beanList as $module=>$class_name){
	
	if(!isset($beanFiles[$class_name])){
		continue;
	}

	require_once($beanFiles[$class_name]);
	$mod =& new $class_name();
	$fields = array();

	//handle all normal fields;
	if(!isset($mod->field_defs)){
		continue;
	}
	
	$offset=date('Z');
	$interval='- INTERVAL '.$offset.' second';

		
	//prepare one update statement per date or datetime field.
	foreach($mod->field_defs as $field)
	{

			if(!isset($field['type'])){
				continue;	
			}
			if( $field['type'] == 'datetime'){

				$update = "UPDATE $mod->table_name SET ".$field['name'] .'='.$field['name'] .' '. $interval;
				$update.=' WHERE '.$field['name'] .' is not null';
				$sql.= $update . "\n";
				$queries[]=$update;

				if($field['name'] == 'date_modified'){
					$update= "UPDATE $mod->table_name SET date_modified = '1999-12-31 23:59:59' WHERE date_modified is NULL ";
					$sql.= $update . "\n";
					$queries[]=$update;
				}
			
			}
			if($field['type'] == 'date'){
				if(isset($field['rel_field'])){

					$update= "UPDATE $mod->table_name SET {$field['name']}=LEFT(CONCAT({$field['name']},' ', {$field['rel_field']}) $interval,10),";
					$update.= "{$field['rel_field']}=RIGHT(CONCAT({$field['name']},' ', {$field['rel_field']}) $interval,8)";					
					$update.=' WHERE '.$field['name'] .' is not null and '.$field['rel_field'].' is not null';
					$sql.= $update . "\n";
					$queries[]=$update;
				}
			}
			
		}
}		


$sql.= "/* RELATIONSHIP TABLES */\n";
$olddictionary = $dictionary;
unset($dictionary);
include('modules/TableDictionary.php');
foreach($dictionary as $meta){
   		$tablename = $meta['table'];
   		$fielddefs = $meta['fields'];
   		foreach($fielddefs as $fielddef){

   			if($fielddef['name'] == 'date_modified'){
   				$sql.= "/* RELATIONSHIP - $tablename */\n";
   				$sql.= "/* replace any NULL date_modified with 1999-12-31 23:59:59 */\n";
				$update = "UPDATE $tablename SET date_modified = '1999-12-31 23:59:59' WHERE date_modified is NULL ";
				$sql.= $update . "\n";
				$queries[]=$update;

   			}

   		}

  }
$dictionary = $olddictionary;

if($export){
   		header("Content-Disposition: attachment; filename=SugarDBGMTDATETIMEUPGRADE.sql");
		header("Content-Type: text/sql; charset={$app_strings['LBL_CHARSET']}");
		header( "Expires: Mon, 26 Jul 1997 05:00:00 GMT" );
		header( "Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT" );
		header( "Cache-Control: post-check=0, pre-check=0", false );
		header("Content-Length: ".strlen($sql));
   		echo $sql;
   		die();
   }else{
   	
   	foreach ($queries as $query) {
		echo "Executing query ".$query;
   		$db->query($query);
   		echo '<br>';
   	}
   }


    print( "<br><br>Click 'Next' to continue...<br>" );
?>
	</td>
</tr>
<tr>
<td align="right" colspan="2">
<hr>
<table cellspacing="0" cellpadding="0" border="0" class="stdTable">
<tr>
<td>
     <input type="hidden" name="current_step" value="<?php echo $next_step ?>">
     <table cellspacing="0" cellpadding="0" border="0" class="stdTable">
       <tr>
         <td><input class="button" type="submit" name="goto" value="Next" /></td>
       </tr>
     </table>
</td>
</tr>
</table>
</td>
</tr>
</table>
</form>
</body>
</html>


