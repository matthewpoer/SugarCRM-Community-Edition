<?php
if( !is_file( "config.php" ) ){
    // running directly, not from index.php
    chdir( ".." );
}
require_once("config.php");
require_once("include/database/PearDatabase.php");

$db = PearDatabase::getInstance();
$result = $db->query("SELECT id, user_preferences, user_name FROM users");

// loop through user preferences and check for "bad" elements; rebuild preferences array and update database
while ($row = $db->fetchByAssoc($result)) {
        echo "&nbsp; &nbsp; &nbsp; Clearing sort preferences for user <b>{$row['user_name']}</b>... ";

        $prefs = array();
        $newprefs = array();

        $prefs = unserialize(base64_decode($row['user_preferences']));
		if(!empty($prefs)){
	        foreach ($prefs as $key => $val) {
	                if (!preg_match("/[A-Za-z_]*?_ORDER_BY/", $key)) {
	                        $newprefs[$key] = $val;
	                }
	        }
	        
        	$newstr = mysql_escape_string(base64_encode(serialize($newprefs)));
       		mysql_query("UPDATE users SET user_preferences = '{$newstr}' WHERE id = '{$row['id']}'");;
		}
        echo "done.<br>";

		$the_old_prefs[] = $prefs;
		$the_new_prefs[] = $newprefs;

        unset($prefs);
        unset($newprefs);
        unset($newstr);
}

echo "<br>All sort preferences cleared!<br><br>";
?>
