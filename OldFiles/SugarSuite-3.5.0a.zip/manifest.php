<?php
// created: 2005-08-19 15:59:51
$manifest = array (
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '3\\.0\\.1.*',
    ),
  ),
  'acceptable_sugar_flavors' => 
  array (
    0 => 'OS',
  ),
  'name' => 'SugarSuite',
  'description' => '',
  'author' => 'SugarCRM, Inc.',
  'published_date' => '2005-08-19 15:59:51',
  'version' => '3.5.0a',
  'type' => 'full',
  'icon' => '',
  'copy_files' => 
  array (
    'from_dir' => 'SugarSuite-Full-3.5.0a',
    'to_dir' => '',
    'force_copy' => 
    array (
    ),
  ),
);
?>
