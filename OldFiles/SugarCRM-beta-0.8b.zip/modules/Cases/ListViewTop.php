<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1
 * ("License"); You may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Cases/ListViewTop.php,v 1.1 2004/06/15 04:52:53 sugarclint Exp $
 * Description:  TODO: To be written.
 ********************************************************************************/

require_once('XTemplate/xtpl.php');
require_once("data/Tracker.php");
require_once('modules/Cases/Case.php');
require_once('themes/'.$theme.'/layout_utils.php');
require_once('logging.php');

$list_form=new XTemplate ('modules/Cases/ListViewTop.html');
$list_form->assign("THEME", $theme);
$list_form->assign("IMAGE_PATH", $image_path);
$list_form->assign("MODULE_NAME", $current_module);

global $opp_list;

//build top 5 case list
$oddRow = true;
$count = 1;
for($row = 0; $count <= 5; $row++)
{
	if ($opp_list[$row]->sales_stage != 'Closed Won' && $opp_list[$row]->sales_stage != 'Closed Lost') {
		$count++;
		$case_fields = array(
			'ID' => $opp_list[$row]->id,
			'NAME' => $opp_list[$row]->name,
			'ACCOUNT_NAME' => $opp_list[$row]->account_name,
			'DATE_CLOSED' => $opp_list[$row]->date_closed,
			'AMOUNT' => $opp_list[$row]->amount,
		);
		
		$list_form->assign("CASE", $case_fields);
	
		
		if($oddRow)
		{
			//todo move to themes
			$list_form->assign("ROW_COLOR", 'oddListRow');
		}
		else
		{
			//todo move to themes
			$list_form->assign("ROW_COLOR", 'evenListRow');
		}
		$oddRow = !$oddRow;
		
		// Put the rows in.
		$list_form->parse("main.row");
	}
}
$list_form->parse("main");

echo get_form_header("My Top Cases", "", false);
$list_form->out("main");
echo get_form_footer();

echo "</td></tr>\n</table>\n";

?>
