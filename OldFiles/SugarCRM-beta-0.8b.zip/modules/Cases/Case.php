<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1
 * ("License"); You may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Cases/Case.php,v 1.2 2004/06/15 05:40:25 sugarclint Exp $
 * Description:  TODO: To be written.
 ********************************************************************************/

include_once('config.php');
require_once('logging.php');
require_once('database/DatabaseConnection.php');
require_once('data/SugarBean.php');
require_once('modules/Contacts/Contact.php');
require_once('modules/Tasks/Task.php');
require_once('modules/Calls/Call.php');
require_once('include/utils.php');

// Case is used to store customer information.
class aCase extends SugarBean {
	var $log;

	// Stored fields
	var $id;
	var $date_entered;
	var $date_modified;
	var $modified_user_id;
	var $number;
	var $description;
	var $name;
	var $status;

	// These are related
	var $account_name;	
	var $account_id;
	var $contact_id;
	var $task_id;
	var $meeting_id;
	var $call_id;
	
	var $table_name = "cases";
	var $rel_account_table = "accounts_cases";
	var $rel_contact_table = "contacts_cases";

	var $object_name = "Case";

	var $column_fields = Array("id"
		, "name"
		, "number"
		, "date_entered"
		, "date_modified"
		, "modified_user_id"
		, "status"
		, "description"
		);

	// This is used to retrieve related fields from form posts.
	var $additional_column_fields = Array('account_name', 'account_id', 'contact_id', 'task_id', 'meeting_id', 'call_id');		

	// This is the list of fields that are in the lists.
	var $list_fields = Array('id', 'status', 'name', 'account_name', 'number', 'account_id');
		
	function aCase() {
		$this->log = LoggerManager::getLogger('case');
	}

	var $new_schema = true;

	function create_tables () {
		$query = 'CREATE TABLE '.$this->table_name.' ( ';
		$query .='id char(50) NOT NULL';
		$query .=', number int( 11 ) NOT NULL auto_increment';
		$query .=', date_entered timestamp( 14 ) NOT NULL';
		$query .=', date_modified timestamp( 14 ) NOT NULL';
		$query .=', modified_user_id char(50) NOT NULL';
		$query .=', deleted bool NOT NULL default 0';
		$query .=', name char(100)';
		$query .=', status char(25)';
		$query .=', description char(255)';
		$query .=', KEY ( NUMBER )';
		$query .=', PRIMARY KEY ( ID ) )';

		$this->log->info($query);
		
		mysql_query($query) or die("Error creating table: ".mysql_error());

		//TODO Clint 4/27 - add exception handling logic here if the table can't be created.
		
		$query = "CREATE TABLE $this->rel_account_table (";
		$query .='id char(50) NOT NULL';
		$query .=', case_id char(50)';
		$query .=', account_id char(50)';
		$query .=', deleted bool NOT NULL default 0';
		$query .=', PRIMARY KEY ( ID ) )';
	
		$this->log->info($query);
		mysql_query($query) or die("Error creating account/case relationship table: ".mysql_error());
		
		$query = "CREATE TABLE $this->rel_contact_table (";
		$query .='id char(50) NOT NULL';
		$query .=', contact_id char(50)';
		$query .=', case_id char(50)';
		$query .=', contact_role char(50)';
		$query .=', deleted bool NOT NULL default 0';
		$query .=', PRIMARY KEY ( ID ) )';
	
		$this->log->info($query);
		mysql_query($query) or die("Error creating case/contact relationship table: ".mysql_error());

		// Create the indexes
		$this->create_index("create index idx_case_name on cases (name)");
		$this->create_index("create index idx_acc_case_acc on accounts_cases (account_id)");
		$this->create_index("create index idx_acc_case_opp on accounts_cases (case_id)");
		$this->create_index("create index idx_con_case_con on contacts_cases (contact_id)");
		$this->create_index("create index idx_con_case_case on contacts_cases (case_id)");
	}

	function drop_tables () {
		$query = 'DROP TABLE IF EXISTS '.$this->table_name;

		$this->log->info($query);
			
		mysql_query($query);

		$query = 'DROP TABLE IF EXISTS '.$this->rel_account_table;

		$this->log->info($query);
			
		mysql_query($query);

		$query = 'DROP TABLE IF EXISTS '.$this->rel_contact_table;

		$this->log->info($query);
			
		mysql_query($query);

		//TODO Clint 4/27 - add exception handling logic here if the table can't be dropped.

	}
	
	function get_summary_text()
	{
		return "$this->name";
	}

	function create_list_query($order_by, $where)
	{
		$query = "SELECT cases.id, cases.status, cases.name, cases.number, accounts.name as account_name, accounts.id as account_id FROM cases, accounts_cases a_c, accounts ";
		$where_auto = "a_c.case_id = cases.id AND a_c.account_id = accounts.id AND a_c.deleted=0 AND accounts.deleted=0 AND cases.deleted=0";
		
		if($where != "")
			$query .= "where $where AND ".$where_auto;
		else 
			$query .= "where ".$where_auto;		

		if($order_by != "")
			$query .= " ORDER BY cases.$order_by";
		else 
			$query .= " ORDER BY cases.name";			

		return $query;
	}


	function save_relationship_changes($is_update)
    {
    	$this->clear_account_case_relationship($this->id);
    	
		if($this->account_id != "")
    	{
    		$this->set_account_case_relationship($this->id, $this->account_id);    	
    	}
    	if($this->contact_id != "")
    	{
    		$this->set_linked_contact_case_relationship($this->id, $this->contact_id);    	
    	}
    	if($this->task_id != "")
    	{
    		$this->set_task_case_relationship($this->id, $this->task_id);    	
    	}
    	if($this->meeting_id != "")
    	{
    		$this->set_meeting_case_relationship($this->id, $this->meeting_id);    	
    	}
    	if($this->call_id != "")
    	{
    		$this->set_call_case_relationship($this->id, $this->call_id);    	
    	}
    }

	function clear_account_case_relationship($case_id)
	{
		$query = "UPDATE accounts_cases set deleted=1 where case_id='$case_id' and deleted=0";
		mysql_query($query) or die("Error clearing account to contact relationship: ".mysql_error());
	}
    
	function set_account_case_relationship($case_id, $account_id)
	{
		$query = "insert into accounts_cases set id='".create_guid()."', case_id='$case_id', account_id='$account_id'";
		mysql_query($query) or die("Error setting account to contact relationship: ".mysql_error());
	}

	function set_linked_contact_case_relationship($case_id, $contact_id)
	{
		$query = "insert into contacts_cases set id='".create_guid()."', case_id='$case_id', contact_id='$contact_id', contact_role='$this->case_relationship_type_default'";
		mysql_query($query) or die("Error setting case to contact relationship: ".mysql_error());
	}

	function set_task_case_relationship($case_id, $task_id)
	{
		$query = "UPDATE tasks set parent_id='$case_id', parent_type='Case' where id='$task_id'";
		mysql_query($query) or die("Error setting case to task relationship: ".mysql_error());
	}

	function set_meeting_case_relationship($case_id, $meeting_id)
	{
		$query = "UPDATE meetings set parent_id='$case_id', parent_type='Case' where id='$meeting_id'";
		mysql_query($query) or die("Error setting case to meeting relationship: ".mysql_error());
	}

	function set_call_case_relationship($case_id, $call_id)
	{
		$query = "UPDATE calls set parent_id='$case_id', parent_type='Case' where id='$call_id'";
		mysql_query($query) or die("Error setting case to call relationship: ".mysql_error());
	}

	function mark_relationships_deleted($id)
	{
		$query = "UPDATE accounts_cases set deleted=1 where case_id='$id' and deleted=0";
		mysql_query($query) or die("Error marking record deleted: ".mysql_error());
		$query = "UPDATE contacts_cases set deleted=1 where case_id='$id' and deleted=0";
		mysql_query($query) or die("Error marking record deleted: ".mysql_error());
	}
	
	function fill_in_additional_detail_fields()
	{
		$query = "SELECT acc.id, acc.name from accounts as acc, accounts_cases as a_c where acc.id = a_c.account_id and a_c.case_id = '$this->id' and a_c.deleted=0 and acc.deleted=0";
		$result = mysql_query($query) or die("Error filling in additional detail fields: ".mysql_error());

		// Get the id and the name.
		$row = mysql_fetch_assoc($result);

		if($row != null)
		{
			$this->account_name = $row['name'];
			$this->account_id 	= $row['id'];
		}
	}
	
	
	/** Returns a list of the associated contacts
	*/
	function get_contacts()
	{
		// First, get the list of IDs.
		$query = "SELECT c.id, c.first_name, c.last_name, c.title, c.yahoo_id, c.email1, c.phone_work, o_c.contact_role as case_role, o_c.id as case_rel_id ".
				 "from contacts_cases o_c, contacts c ".
				 "where o_c.case_id = '$this->id' and o_c.deleted=0 and c.id = o_c.contact_id AND c.deleted=0";
		
	    $temp = Array('id', 'first_name', 'last_name', 'title', 'yahoo_id', 'email1', 'phone_work', 'case_role', 'case_rel_id');
		return $this->build_related_list2($query, new Contact(), $temp);
	}
	
	/** Returns a list of the associated tasks
	*/
	function get_tasks()
	{
		// First, get the list of IDs.
		$query = "SELECT id from tasks where parent_id='$this->id' AND deleted=0";
		
		return $this->build_related_list($query, new Task());
	}
	
	/** Returns a list of the associated meetings
	*/
	function get_meetings()
	{
		// First, get the list of IDs.
		$query = "SELECT id from meetings where parent_id='$this->id' AND deleted=0";
		
		return $this->build_related_list($query, new Meeting());
	}
	
	/** Returns a list of the associated calls
	*/
	function get_calls()
	{
		// First, get the list of IDs.
		$query = "SELECT id from calls where parent_id='$this->id' AND deleted=0";
		
		return $this->build_related_list($query, new Call());
	}
}



?>
