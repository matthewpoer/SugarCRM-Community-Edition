<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1
 * ("License"); You may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/install/1checkSystem.php,v 1.2 2004/06/06 02:23:26 sugarjacob Exp $
 * Description:  Executes a step in the installation process.
 ********************************************************************************/
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>SugarCRM Open Source Installer: Step 1</title>
<link rel="stylesheet" href="install/install.css" type="text/css" />
</head>
<body leftMargin="0" topMargin="0" marginheight="0" marginwidth="0">
<table width="100%" border="0" cellpadding="5" cellspacing="0" class="formHeader"><tbody>
  <tr><td align="center"><IMG alt="SugarCRM" src="include/images/SUGAR.jpg"/></td></tr>
</tbody></table>
<table align="center" border="0" cellpadding="2" cellspacing="2" border="1" width="60%"><tbody>
    <tr> 
      <td width="100%" colspan="3">
		<table width=100% cellpadding="0" cellspacing="0" border="0"><tbody><tr>
			  <td>
			   <table cellpadding="0" cellspacing="0" border="0"><tbody><tr>
				<td class="formHeader" vAlign="top" align="left" height="20"> 
				 <IMG height="5" src="include/images/left_arc.gif" width="5" border="0"></td>
				<td class="formHeader" vAlign="middle" align="left" noWrap width="100%" height="20">Step 1: System Check</td>
				<td  class="formHeader" vAlign="top" align="right" height="20">
				  <IMG height="5" src="include/images/right_arc.gif" width="5" border="0"></td>
				</tr></tbody></table>
			  </td>
			  <td width="100%" align="right">&nbsp;</td>
			  </tr><tr>
			  <td colspan="2" width="100%" class="formHeader"><IMG width="100%" height="2" src="include/images/blank.gif"></td>
			  </tr>
		</tbody></table>
	  </td>
    </tr>
	<tr><td align="center" colspan="3"><span class="moduleTitle">Welcome to the SugarCRM Open Source installation</span><P>
  			This installer creates the SugarCRM database tables and sets the configuration variables that you need to start.   
			The entire process should take about ten minutes. 
			For installation help, please visit the SugarCRM <A href="http://www.sugarcrm.com/support">support forums</A>.</td>
	</tr>

	<tr><td>&nbsp;</td></tr>

	<tr>
		<td width="100">&nbsp;</td>
		<td w><IMG class="formHeader" width="100%" height="1" src="include/images/blank.gif"></td>
		<td width="100">&nbsp;</td>
	</tr>
	<tr align="center">
		<td width="100">&nbsp;</td>
		<td><strong>NOTE:</strong> Official SugarCRM Open Source distributions are ONLY available from the <A href="http://sourceforge.net/projects/sugarcrm/">SugarCRM Open Source 
	project</A> located on SourceForge.net.  Please ensure you are installing an official distribution.</td>
		<td width="100">&nbsp;</td>
	</tr>
	<tr>
		<td width="100">&nbsp;</td>
		<td ><IMG class="formHeader" width="100%" height="1" src="include/images/blank.gif"></td>
		<td width="100">&nbsp;</td>
	</tr>

	<tr><td>&nbsp;</td></tr>

    <tr><td colspan="3">In order for your SugarCRM installation to function properly, please ensure all of the 
	system check items listed below are green.  If any are red, please take the necessary steps
	to fix them.</td></tr>
    <tr><td colspan="3" align="center">
	    <table cellpadding="1" cellspacing="1" border="0"><tbody><tr>
			<td><strong>PHP version 4.1 or later</strong></td>
			<td width="100">&nbsp;</td>
			<td align="right"><?php $php_version = phpversion(); echo $php_version < "4.1"?"<strong><font color=\"#FF0000\">Version $php_version Installed</font></strong>":"<strong><font color=\"#00CC00\">Version $php_version Installed</font></strong>"; ?></td>
			<td>&nbsp;</td>
    	</tr>
		<tr>
			<td><strong>MySQL database</strong></td>
			<td width="100">&nbsp;</td>
        	<td align="right"><?php echo function_exists('mysql_connect')?"<strong><font color=\"#00CC00\">Available</font></strong>":"<strong><font color=\"#FF0000\">Not Available</font></strong>";?></td>
			<td>&nbsp;</td>
	    </tr>
		<tr> 
			<td><strong>config.php</strong></td>
			<td width="100">&nbsp;</td>
			<td align="right"><?php echo (is_writable('./config.php') || is_writable('.'))?"<strong><font color=\"#00CC00\">Writeable</font></strong>":"<strong><font color=\"#FF0000\">Not Writeable</font></strong>"; ?></td>
		</tr>
		<tr> 
			<td><strong>GD graphics library version 2.0 or later</strong></td>
			<td width="100">&nbsp;</td>
			<td align="right"><?php 
								if (!extension_loaded('gd')) {
									echo "<strong><font color=\"#FF0000\">GD Library not configured in your PHP installation.<br>Uncomment the php_gd2.dll extension definition in your php.ini file to enable this necessary graphics library.</font></strong>";
								}
								else {
									$gd_info=gd_info();							 
									$gd_version=$gd_info['GD Version']; 
									$gd_version=preg_replace('%[^0-9.]%', '', $gd_version); 
									if ($gd_version > "2.0") { 
										echo "<strong><font color=\"#00CC00\">Version $gd_version Installed</font></strong>";
									}
									else { 
										echo "<strong><font color=\"#FF0000\">Version $gd_version Installed.<br>Go to <a href='http://www.boutell.com/gd/'>http://www.boutell.com/gd/</a>, download the latest version, and configure php.ini to reference it.</font></strong>";
									}
								}
								?>
			</td>
		</tr>
       </tbody></table>
	</td></tr>
	<tr> 
       <td colspan="3" align="right">
	    <form action="install.php" method="post" name="form" id="form">
		<input type="hidden" name="file" value="2setConfig.php" />
		<input class="button" type="submit" name="next" value="Continue" /></td>
    </tr>
	</tbody> 	
		
</form>
</body>
</html>