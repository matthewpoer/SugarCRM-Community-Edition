<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/include/language/en_us.lang.php,v 1.89 2004/10/25 02:32:20 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

//to translate, only modify the right value in each key/value pair
$app_list_strings = array (
//e.g. auf Deutsch 'Contacts'=>'Contakten',
  'moduleList' => 
  array (
    'Home' => 'Hem',
    'Dashboard' => 'Dashboard',
    'Contacts' => 'Kontakter',
    'Accounts' => 'F�retag',
    'Opportunities' => 'Aff�rer',
    'Cases' => '�renden',
    'Notes' => 'Notes & Attachments',
    'Calls' => 'Samtal',
    'Emails' => 'Epost',
    'Meetings' => 'M�ten',
    'Tasks' => 'Uppgifter',
    'Calendar' => 'Calendar',
    'Leads' => 'Leads',
    'Activities' => 'Activities',
  ),
  'account_type_dom' => 
  array (
    '' => '',
    'Analyst' => 'Analytiker',
    'Competitor' => 'Konkurrent',
  //e.g. en fran�ais 'Analyst'=>'Analyste',
    'Customer' => 'Kund',
    'Integrator' => 'Integrat�r',
    'Investor' => 'Investerare',
    'Partner' => 'Partner',
    'Press' => 'Press',
    'Prospect' => 'Kund�mne',
    'Reseller' => '�terf�rs�ljare',
    'Other' => '�vrigt',
  ),
  'industry_dom' => 
  array (
    '' => '',
    'Apparel' => 'Bekl�dnadsindustri',
    'Banking' => 'Bank',
  //e.g. en espa�ol 'Apparel'=>'Ropa',
    'Biotechnology' => 'Bioteknologi',
    'Chemicals' => 'Kemikalie',
    'Communications' => 'Kommunikation',
    'Construction' => 'Konstruktion',
    'Consulting' => 'Konsulting',
    'Education' => 'Utbildning',
    'Electronics' => 'Elektronik',
    'Energy' => 'Energi',
    'Engineering' => 'Ingenj�rskonst',
    'Entertainment' => 'Underh�llning',
    'Environmental' => 'Milj�',
    'Finance' => 'Finans',
    'Food & Beverage' => 'Livsmedel',
    'Government' => 'Offentlig f�rvaltning',
    'Healthcare' => 'H�lsov�rd',
    'Hospitality' => 'Hotell/Restaurang',
    'Insurance' => 'F�rs�kring',
    'Machinery' => 'Maskinteknik',
    'Manufacturing' => 'Tillverkande',
    'Media' => 'Media',
    'Not For Profit' => 'Ideell verksamhet',
    'Recreation' => 'Turism/resor',
    'Retail' => 'Handel',
    'Shipping' => 'Frakt',
    'Technology' => 'Teknologi',
    'Telecommunications' => 'Telekommunikationer',
    'Transportation' => 'Transport',
    'Utilities' => 'Utilities',
    'Other' => '�vrigt',
  ),
  'lead_source_dom' => 
  array (
    '' => '',
    'Cold Call' => 'Ointresserad',
    'Existing Customer' => 'Befintlig kund',
    'Self Generated' => 'Personlig',
    'Employee' => 'Anst�lld',
    'Partner' => 'Partner',
    'Public Relations' => 'Public Relations',
    'Direct Mail' => 'Direct Mail',
    'Conference' => 'Konferens',
    'Trade Show' => 'M�ssa',
    'Web Site' => 'Web Site',
    'Word of mouth' => 'Muntligen',
    'Other' => '�vrigt',
  ),
  'opportunity_type_dom' => 
  array (
    '' => '',
    'Existing Business' => 'Befintlig aff�r',
    'New Business' => 'Ny aff�r',
  ),
  'opportunity_relationship_type_default_key' => 'Primary Decision Maker',
  'opportunity_relationship_type_dom' => 
  array (
    '' => '',
    'Primary Decision Maker' => 'Huvudsaklig beslutsfattare',
//       it is the key for the default opportunity_relationship_type_dom value
    'Business Decision Maker' => 'Aff�rsm�ssig beslutsfattare',
    'Business Evaluator' => 'Aff�rsm�ssig utv�rderare',
    'Technical Decision Maker' => 'Teknisk beslutsfattare',
    'Technical Evaluator' => 'Teknisk utv�rderare',
    'Executive Sponsor' => 'Ledningsfinansi�r',
    'Influencer' => 'Person med inflytande',
    'Other' => '�vrigt',
  ),
  'case_relationship_type_default_key' => 'Primary Contact',
  'case_relationship_type_dom' => 
  array (
    '' => '',
    'Primary Contact' => 'Huvusaklig kontakt',
//       it is the key for the default case_relationship_type_dom value
    'Alternate Contact' => 'Alternativ kontakt',
  ),
  'sales_stage_dom' => 
  array (
    'Prospecting' => 'Prospektering',
    'Qualification' => 'Kvalifikation',
    'Needs Analysis' => 'Analys beh�vs',
    'Value Proposition' => 'F�rsl� v�rde',
    'Id. Decision Makers' => 'Identifiera beslutsfattare',
    'Perception Analysis' => 'Analysera genomslag',
    'Proposal/Price Quote' => 'Offert',
    'Negotiation/Review' => 'F�rhandling/uppdatering',
    'Closed Won' => 'Avslutad vunnen',
    'Closed Lost' => 'Avslutad f�rlorad',
  ),
  'activity_dom' => 
  array (
    'Call' => 'Call',
    'Meeting' => 'Meeting',
    'Task' => 'Task',
    'Email' => 'Email',
    'Note' => 'Note',
  ),
  'salutation_dom' => 
  array (
    '' => '',
    'Mr.' => 'Herr',
    'Ms.' => 'Fr�ken',
    'Mrs.' => 'Fru',
    'Dr.' => 'Dr.',
    'Prof.' => 'Prof.',
  ),
  'task_priority_dom' => 
  array (
    'High' => 'H�g',
    'Medium' => 'Medium',
    'Low' => 'L�g',
  ),
  'task_status_dom' => 
  array (
    'Not Started' => 'Ej p�b�rjad',
    'In Progress' => 'Aktiv',
    'Completed' => 'Avslutad',
    'Pending Input' => 'V�ntar p� uppgifter',
    'Deferred' => 'Uppskjuten',
  ),
  'meeting_status_dom' => 
  array (
    'Planned' => 'Planerad',
    'Held' => 'Genomf�rd',
    'Not Held' => 'Ej genomf�rd',
  ),
  'call_status_dom' => 
  array (
    'Planned' => 'Planerad',
    'Held' => 'Genomf�rd',
    'Not Held' => 'Ej genomf�rd',
  ),
  'call_direction_dom' => 
  array (
    'Inbound' => 'Inbound',
    'Outbound' => 'Outbound',
  ),
  'lead_status_dom' => 
  array (
    '' => '',
    'New' => 'New',
    'Assigned' => 'Assigned',
    'In Process' => 'In Process',
    'Converted' => 'Converted',
    'Recycled' => 'Recycled',
    'Dead' => 'Dead',
  ),
  'lead_status_noblank_dom' => 
  array (
    'New' => 'New',
    'Assigned' => 'Assigned',
    'In Process' => 'In Process',
    'Converted' => 'Converted',
    'Recycled' => 'Recycled',
    'Dead' => 'Dead',
  ),
  'case_status_default_key' => 'New',
  'case_status_dom' => 
  array (
    'New' => 'Nytt',
    'Assigned' => 'Tilldelat',
//       it is the key for the default case_status_dom value
    'Closed' => 'Avslutat',
    'Pending Input' => 'V�ntar p� uppgifter',
    'Rejected' => 'Avslag',
  ),
  'case_priority_default_key' => 'P2',
  'case_priority_dom' => 
  array (
    'P1' => 'High',
    'P2' => 'Medium',
    'P3' => 'Low',
  ),
  'user_status_dom' => 
  array (
    'Active' => 'Aktiv',
    'Inactive' => 'Inaktiv',
  ),
  'record_type_default_key' => 'Accounts',
  'record_type_display' => 
  array (
    'Accounts' => '*Account',
    'Opportunities' => '*Opportunity',
//       it is the key for the default record_type_module value
    'Cases' => '*Case',
    'Leads' => 'Lead',
  ),
  'notifymail_sendtype' => 
  array (
    'sendmail' => 'sendmail',
    'SMTP' => 'SMTP',
  ),
);

$app_strings = array (
  'LBL_CHARSET' => 'ISO-8859-1',
  'LBL_BROWSER_TITLE' => 'SugarCRM - Commercial Open Source CRM',
  'LBL_MY_ACCOUNT' => 'Mitt Konto',
  'LBL_ADMIN' => 'Admin',
  'LBL_LOGOUT' => 'Logga ut',
  'LBL_SEARCH' => 'S�k',
  'LBL_LAST_VIEWED' => 'Senaste info',
  'NTC_WELCOME' => 'V�lkommen',
  'NTC_SUPPORT_SUGARCRM' => 'Support the SugarCRM open source project with a donation through PayPal - it\'s fast, free and secure!',
  'NTC_NO_ITEMS_DISPLAY' => 'ingenting',
  'LBL_ALT_HOT_KEY' => 'Alt+',
  'LBL_SAVE_BUTTON_TITLE' => 'Spara [Alt+S]',
  'LBL_EDIT_BUTTON_TITLE' => 'Redigera [Alt+E]',
  'LBL_EDIT_BUTTON' => 'Redigera',
  'LBL_DUPLICATE_BUTTON_TITLE' => 'Duplicera [Alt+U]',
  'LBL_DUPLICATE_BUTTON' => 'Duplicera',
  'LBL_DELETE_BUTTON_TITLE' => 'Radera [Alt+D]',
  'LBL_DELETE_BUTTON' => 'Radera',
  'LBL_NEW_BUTTON_TITLE' => 'Nytt [Alt+N]',
  'LBL_CHANGE_BUTTON_TITLE' => '�ndra [Alt+G]',
  'LBL_CANCEL_BUTTON_TITLE' => 'Avbryt [Alt+X]',
  'LBL_SEARCH_BUTTON_TITLE' => 'S�k [Alt+Q]',
  'LBL_CLEAR_BUTTON_TITLE' => 'Radera [Alt+C]',
  'LBL_SELECT_BUTTON_TITLE' => 'V�lj [Alt+T]',
  'LBL_SAVE_BUTTON_KEY' => 'S',
  'LBL_EDIT_BUTTON_KEY' => 'E',
  'LBL_DUPLICATE_BUTTON_KEY' => 'U',
  'LBL_DELETE_BUTTON_KEY' => 'D',
  'LBL_NEW_BUTTON_KEY' => 'N',
  'LBL_CHANGE_BUTTON_KEY' => 'G',
  'LBL_CANCEL_BUTTON_KEY' => 'X',
  'LBL_SEARCH_BUTTON_KEY' => 'Q',
  'LBL_CLEAR_BUTTON_KEY' => 'C',
  'LBL_SELECT_BUTTON_KEY' => 'T',
  'LBL_SAVE_BUTTON_LABEL' => 'Spara',
  'LBL_EDIT_BUTTON_LABEL' => 'Redigera',
  'LBL_DUPLICATE_BUTTON_LABEL' => 'Duplicera',
  'LBL_DELETE_BUTTON_LABEL' => 'Radera',
  'LBL_NEW_BUTTON_LABEL' => 'Nytt',
  'LBL_CHANGE_BUTTON_LABEL' => '�ndra',
  'LBL_CANCEL_BUTTON_LABEL' => 'Avbryt',
  'LBL_SEARCH_BUTTON_LABEL' => 'S�k',
  'LBL_CLEAR_BUTTON_LABEL' => 'Radera',
  'LBL_NEXT_BUTTON_LABEL' => 'Next',
  'LBL_SELECT_BUTTON_LABEL' => 'V�lj',
  'LBL_SELECT_CONTACT_BUTTON_TITLE' => 'Select Contact [Alt+T]',
  'LBL_SELECT_CONTACT_BUTTON_KEY' => 'T',
  'LBL_VIEW_PDF_BUTTON_LABEL' => 'View PDF',
  'LBL_VIEW_PDF_CONTACT_BUTTON_TITLE' => 'View PDF [Alt+P]',
  'LBL_VIEW_PDF_CONTACT_BUTTON_KEY' => 'P',
  'LBL_SELECT_CONTACT_BUTTON_LABEL' => 'Select Contact',
  'LBL_SELECT_USER_BUTTON_TITLE' => 'Select User [Alt+U]',
  'LBL_SELECT_USER_BUTTON_KEY' => 'U',
  'LBL_SELECT_USER_BUTTON_LABEL' => 'Select User',
  'LBL_CREATE_BUTTON_LABEL' => 'Create',
  'LBL_SHORTCUTS' => 'Shortcuts',
  'LBL_LIST_NAME' => 'Name',
  'LBL_LIST_USER_NAME' => 'User Name',
  'LBL_LIST_EMAIL' => 'Email',
  'LBL_LIST_PHONE' => 'Phone',
  'LBL_LIST_CONTACT_NAME' => 'Contact Name',
  'LBL_LIST_CONTACT_ROLE' => 'Contact Role',
  'LBL_LIST_ACCOUNT_NAME' => 'Account Name',
  'LBL_USER_LIST' => 'User List',
  'LBL_CONTACT_LIST' => 'Contact List',
  'LBL_RELATED_RECORDS' => 'Related Records',
  'LBL_MASS_UPDATE' => 'Mass Update',
  'LNK_ADVANCED_SEARCH' => 'Avancerad',
  'LNK_BASIC_SEARCH' => 'Enkel',
  'LNK_EDIT' => 'redigera',
  'LNK_REMOVE' => 'ta bort',
  'LNK_DELETE' => 'radera',
  'LNK_LIST_START' => 'Start',
  'LNK_LIST_NEXT' => 'N�sta',
  'LNK_LIST_PREVIOUS' => 'F�reg�ende',
  'LNK_LIST_END' => 'Slut',
  'LBL_LIST_OF' => 'av',
  'LBL_OR' => 'OR',
  'LNK_PRINT' => 'Skriv ut',
  'LNK_HELP' => 'Hj�lp',
  'LNK_ABOUT' => '*About',
  'NTC_REQUIRED' => 'Markerar obligatoriska f�lt',
  'LBL_REQUIRED_SYMBOL' => '*',
  'LBL_CURRENCY_SYMBOL' => '$',
  'LBL_PERCENTAGE_SYMBOL' => '%',
  'LBL_THOUSANDS_SYMBOL' => 'K',
  'NTC_DATE_FORMAT' => '(����-mm-dd)',
  'NTC_TIME_FORMAT' => '(24:00)',
  'NTC_DATE_TIME_FORMAT' => '(����-mm-dd 24:00)',
  'NTC_DELETE_CONFIRMATION' => '�r du s�ker p� att du vill radera denna post?',
  'ERR_DELETE_RECORD' => 'Ett post nr kr�vs f�r att radera det aktuella kontakten.',
  'ERR_CREATING_TABLE' => 'Fel vid skapande av tabellen: ',
  'ERR_CREATING_FIELDS' => 'Fel vid ifyllnad av extra detaljerad information: ',
  'ERR_MISSING_REQUIRED_FIELDS' => 'Obligatoriska f�lt saknas:',
  'ERR_INVALID_EMAIL_ADDRESS' => '�r inte en giltig epostadress.',
  'ERR_INVALID_DATE_FORMAT' => 'Datumformatet m�ste vara : ����-mm-dd',
  'ERR_INVALID_MONTH' => 'Ange en giltig m�nad.',
  'ERR_INVALID_DAY' => 'Ange ett giltigt datum.',
  'ERR_INVALID_YEAR' => 'Ange ett giltigt �rtal med 4 siffror.',
  'ERR_INVALID_DATE' => 'Ange ett giltigt datum.',
  'ERR_INVALID_HOUR' => 'Ange en giltig timme.',
  'ERR_INVALID_TIME' => 'Ange ett giltigt klockslag.',
  'ERR_INVALID_AMOUNT' => 'Please enter a valid amount.',
  'NTC_CLICK_BACK' => 'Klicka p� bak�tknappen och korrigera uppgifterna.',
  'LBL_LIST_ASSIGNED_USER' => 'Tilldelad till',
  'LBL_ASSIGNED_TO' => 'Tilldelat till:',
  'LBL_DATE_MODIFIED' => '*Last Modified:',
  'LBL_DATE_ENTERED' => '*Created:',
  'LBL_CURRENT_USER_FILTER' => 'Visa endast de uppgifter som �r tilldelade till mig:',
  'NTC_LOGIN_MESSAGE' => 'Please login to the application.',
  'LBL_NONE' => '--None--',
  'LBL_BACK' => '*Back',
  'LBL_IMPORT' => '*Import',
  'LBL_EXPORT' => '*Export',
  'LBL_EXPORT_ALL' => 'Export All',
  'LBL_SAVE_NEW_BUTTON_TITLE' => 'Save & Create New [Alt+V]',
  'LBL_SAVE_NEW_BUTTON_KEY' => 'V',
  'LBL_SAVE_NEW_BUTTON_LABEL' => 'Save & Create New',
  'LBL_NAME' => 'Name',
  'LBL_SUBJECT' => 'Subject',
);


?>