<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/include/language/en_us.lang.php,v 1.89 2004/10/25 02:32:20 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Administration',
  'LBL_MODULE_TITLE' => 'Administration: Hem',
  'LBL_NEW_FORM_TITLE' => 'Nytt F�retag',
  'LNK_NEW_USER' => 'Create User',
  'ERR_DELETE_RECORD' => 'Ett Post nummer m�ste anges f�r att radera F�retaget.',
  'LBL_CONFIGURE_SETTINGS_TITLE' => 'Configure Settings',
  'LBL_CONFIGURE_SETTINGS' => 'Configure system-wide settings',
  'LBL_UPGRADE_TITLE' => 'Upgrade',
  'LBL_UPGRADE' => 'Upgrade Sugar Sales',
  'LBL_MANAGE_USERS_TITLE' => 'User Management',
  'LBL_MANAGE_USERS' => 'Manage user accounts and passwords',
  'LBL_ADMINISTRATION_HOME_TITLE' => 'System Administration',
  'LBL_NOTIFY_TITLE' => 'E-mail Notification Options',
  'LBL_NOTIFY_FROMADDRESS' => '"From" Address:',
  'LBL_MAIL_SMTPSERVER' => 'SMTP Server:',
  'LBL_MAIL_SMTPPORT' => 'SMTP Port:',
  'LBL_MAIL_SENDTYPE' => 'Mail Transfer Agent:',
  'LBL_MAIL_SMTPUSER' => 'SMTP Username:',
  'LBL_MAIL_SMTPPASS' => 'SMTP Password:',
  'LBL_MAIL_SMTPAUTH_REQ' => 'Use SMTP Authentication?',
  'LBL_NOTIFY_SEND_BY_DEFAULT' => 'Send notifications by default?',
  'LBL_NOTIFY_SUBJECT' => 'E-mail subject:',
  'LBL_NOTIFY_ON' => 'Notifications on?',
  'LBL_NOTIFY_FROMNAME' => '"From" Name:',
  'LBL_CURRENCY' => 'Setup Currencies and Currency Rates',
  'LBL_MANAGE_CURRENCIES' => 'Currencies',
  'LBL_MANAGE_OPPORTUNITIES' => 'Opportunities',
  'LBL_UPGRADE_CURRENCY' => 'Upgrade currency amounts in ',
  'LNK_NEW_CONTACT' => 'Ny Kontakt',
  'LNK_NEW_ACCOUNT' => 'Nytt F�retag',
  'LNK_NEW_OPPORTUNITY' => 'Ny Aff�r',
  'LNK_NEW_CASE' => 'Nytt �rende',
  'LNK_NEW_NOTE' => 'Ny Anteckning',
  'LNK_NEW_CALL' => 'Nytt Samtal',
  'LNK_NEW_EMAIL' => 'Nytt Epost',
  'LNK_NEW_MEETING' => 'Nytt M�te',
  'LNK_NEW_TASK' => 'Ny Uppgift',
);


?>