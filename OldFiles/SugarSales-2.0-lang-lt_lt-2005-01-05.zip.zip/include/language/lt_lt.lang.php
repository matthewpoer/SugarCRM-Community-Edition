<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/sugarcrm/include/language/lt_lt.lang.php, v1.01 2005/01/05 eugen Exp $
 * Description:  Defines the Lithuanian language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

//the left value is the key stored in the db and the right value is the display value
//to translate, only modify the right value in each key/value pair
$app_list_strings = array (
//e.g. auf Deutsch 'Contacts'=>'Contakten',
  'moduleList' => 
  array (
    'Home' => 'Prad�ia',
    'Dashboard' => 'Pasiekimai',
    'Contacts' => 'Kontaktai',
    'Accounts' => 'Klientai',
    'Opportunities' => 'Galimyb�s',
    'Cases' => 'Paklausimai',
    'Notes' => 'U�ra�ai',
    'Calls' => 'Skambu�iai',
    'Emails' => 'El.lai�kai',
    'Meetings' => 'Susitikimai',
    'Tasks' => 'U�duotys',
    'Calendar' => 'Kalendorius',
    'Leads' => 'Nuorodos',
    'Activities' => 'Veiksmai',
  ),
  //e.g. en fran�ais 'Analyst'=>'Analyste',
  'account_type_dom' => 
  array (
    '' => '',
    'Analyst' => 'Analitikas',
    'Competitor' => 'Konkurentas',
    'Customer' => 'Klientas',
    'Integrator' => 'Integratorius',
    'Investor' => 'Investuotojas',
    'Partner' => 'Partneris',
    'Press' => 'Spauda',
    'Prospect' => 'Perspektyvus',
    'Reseller' => 'Tarpininkas',
    'Other' => 'Kitas',
  ),
  //e.g. en espa�ol 'Apparel'=>'Ropa',
  'industry_dom' => 
  array (
    '' => '',
    'Apparel' => 'Apranga',
    'Banking' => 'Bankininkyst�',
    'Biotechnology' => 'Biotechnologijos',
    'Chemicals' => 'Chemija',
    'Communications' => 'Ry�iai',
    'Construction' => 'Statyba',
    'Consulting' => 'Konsultavimas',
    'Education' => '�vietimas',
    'Electronics' => 'Elektronika',
    'Energy' => 'Energetika',
    'Engineering' => 'Mechanika',
    'Entertainment' => 'Pramogos',
    'Environmental' => 'Aplinka',
    'Finance' => 'Finansai',
    'Food & Beverage' => 'Maistas ir g�rimai',
    'Government' => 'Valdymas',
    'Healthcare' => 'Sveikatos apsauga',
    'Hospitality' => 'Apgyvendinimas',
    'Insurance' => 'Draudimas',
    'Machinery' => 'Ma�inos',
    'Manufacturing' => 'Gamyba',
    'Media' => '�iniasklaida',
    'Not For Profit' => 'Ne pelno',
    'Recreation' => 'Poilsis',
    'Retail' => 'Ma�menin� prekyba',
    'Shipping' => 'Laivyba',
    'Technology' => 'Technologijos',
    'Telecommunications' => 'Telekomunikacijos',
    'Transportation' => 'Transportas',
    'Utilities' => 'Komunalin�s paslaugos',
    'Other' => 'Kita',
  ),
  'lead_source_dom' => 
  array (
    '' => '',
    'Cold Call' => 'Skambutis',
    'Existing Customer' => 'Egzistuojantis klientas',
    'Self Generated' => 'Savaiminis',
    'Employee' => 'Darbuotojas',
    'Partner' => 'Partneris',
    'Public Relations' => 'Vie�ieji ry�iai',
    'Direct Mail' => 'Tiesioginis lai�kas',
    'Conference' => 'Konferencija',
    'Trade Show' => 'Paroda',
    'Web Site' => 'Interneto svetain�',
    'Word of mouth' => '�odin� rekomendacija',
    'Other' => 'Kitas',
  ),
  'opportunity_type_dom' => 
  array (
    '' => '',
    'Existing Business' => 'Egzistuojantis',
    'New Business' => 'Naujas',
  ),
  //Note:  do not translate opportunity_relationship_type_default_key
//       it is the key for the default opportunity_relationship_type_dom value
  'opportunity_relationship_type_default_key' => 'Primary Decision Maker',
  'opportunity_relationship_type_dom' => 
  array (
    '' => '',
    'Primary Decision Maker' => 'Svarbiausias sprendim� pri�m�jas',
    'Business Decision Maker' => 'Verslo sprendim� pri�m�jas',
    'Business Evaluator' => 'Verslo vystytojas',
    'Technical Decision Maker' => 'Techninis sprendim� pri�m�jas',
    'Technical Evaluator' => 'Techninis vystytojas',
    'Executive Sponsor' => 'Vykdantysis finansuotojas',
    'Influencer' => '�takotojas',
    'Other' => 'Kitas',
  ),
  //Note:  do not translate case_relationship_type_default_key
//       it is the key for the default case_relationship_type_dom value
  'case_relationship_type_default_key' => 'Primary Contact',
  'case_relationship_type_dom' => 
  array (
    '' => '',
    'Primary Contact' => 'Svarbiausias kontaktas',
    'Alternate Contact' => 'Papildomas kontaktas',
  ),
  'sales_stage_dom' => 
  array (
    'Prospecting' => 'Perspektyva',
    'Qualification' => '�vertinimas',
    'Needs Analysis' => 'Reikalinga analiz�',
    'Value Proposition' => 'Poreikio nustatymas',
    'Id. Decision Makers' => 'Nustatomi sprendim� pri�m�jai',
    'Perception Analysis' => 'U�duoties nagrin�jimas',
    'Proposal/Price Quote' => 'Pasi�lymas/s�mata',
    'Negotiation/Review' => 'Derybos/per�i�ra',
    'Closed Won' => 'Laim�tas',
    'Closed Lost' => 'Pralaim�tas',
  ),
  'activity_dom' => 
  array (
    'Call' => 'Skambutis',
    'Meeting' => 'Susitikimas',
    'Task' => 'U�duotis',
    'Email' => 'El.lai�kas',
    'Note' => 'Prane�imas',
  ),
  'salutation_dom' => 
  array (
    '' => '',
    'Mr.' => 'Mr.',
    'Ms.' => 'Ms.',
    'Mrs.' => 'Mrs.',
    'Dr.' => 'Dr.',
    'Prof.' => 'Prof.',
  ),
  'task_priority_dom' => 
  array (
    'High' => 'Auk�tas',
    'Medium' => 'Vidutinis',
    'Low' => '�emas',
  ),
  'task_status_dom' => 
  array (
    'Not Started' => 'Neprad�ta',
    'In Progress' => 'Vykdoma',
    'Completed' => 'U�baigta',
    'Pending Input' => 'Laukia duomen�',
    'Deferred' => 'Atid�ta',
  ),
  'meeting_status_dom' => 
  array (
    'Planned' => 'Suplanuotas',
    'Held' => '�vyk�s',
    'Not Held' => 'Ne�vyk�s',
  ),
  'call_status_dom' => 
  array (
    'Planned' => 'Suplanuotas',
    'Held' => '�vyk�s',
    'Not Held' => 'Ne�vyk�s',
  ),
  'call_direction_dom' => 
  array (
    'Inbound' => '�einantis',
    'Outbound' => 'I�einantis',
  ),
  'lead_status_dom' => 
  array (
    '' => '',
    'New' => 'Nauja',
    'Assigned' => 'Priskirta',
    'In Process' => 'Vykdoma',
    'Converted' => 'Pakeista',
    'Recycled' => 'I�mesta',
    'Dead' => 'Dingusi',
  ),
  'lead_status_noblank_dom' => 
  array (
    'New' => 'Nauja',
    'Assigned' => 'Priskirta',
    'In Process' => 'Vykdoma',
    'Converted' => 'Pakeista',
    'Recycled' => 'I�mesta',
    'Dead' => 'Dingusi',
  ),
  //Note:  do not translate case_status_default_key
//       it is the key for the default case_status_dom value
  'case_status_default_key' => 'New',
  'case_status_dom' => 
  array (
    'New' => 'Naujas',
    'Assigned' => 'Priskirtas',
    'Closed' => 'U�baigtas',
    'Pending Input' => 'Laukia duomen�',
    'Rejected' => 'Atmestas',
  ),
  'case_priority_default_key' => 'P2',
  'case_priority_dom' => 
  array (
    'P1' => 'Auk�tas',
    'P2' => 'Vidutinis',
    'P3' => '�emas',
  ),
  'user_status_dom' => 
  array (
    'Active' => 'Aktyvus',
    'Inactive' => 'Neaktyvus',
  ),
  //Note:  do not translate record_type_default_key
//       it is the key for the default record_type_module value
  'record_type_default_key' => 'Accounts',
  'record_type_display' => 
  array (
    'Accounts' => 'Klientai',
    'Opportunities' => 'Galimyb�s',
    'Cases' => 'Paklausimai',
    'Leads' => 'Nuorodos',
  ),

  'notifymail_sendtype' => 
  array (
    'sendmail' => 'sendmail',
    'SMTP' => 'SMTP',
  ),
);

$app_strings = array (
  'LBL_CHARSET' => 'windows-1257',
  'LBL_BROWSER_TITLE' => 'SugarCRM - Commercial Open Source CRM',
  'LBL_MY_ACCOUNT' => 'Mano duomenys',
  'LBL_ADMIN' => 'Administravimas',
  'LBL_LOGOUT' => 'I�eiti',
  'LBL_SEARCH' => 'Ie�koti',
  'LBL_LAST_VIEWED' => 'Paskutiniai �ra�ai',
  'NTC_WELCOME' => 'Sveiki',
  'NTC_SUPPORT_SUGARCRM' => 'Support the SugarCRM open source project with a donation through PayPal - it\'s fast, free and secure!',
  'NTC_NO_ITEMS_DISPLAY' => 'nieko',
  'LBL_ALT_HOT_KEY' => 'Alt+',
  'LBL_SAVE_BUTTON_TITLE' => 'I�saugoti [Alt+S]',
  'LBL_EDIT_BUTTON_TITLE' => 'Redaguoti [Alt+E]',
  'LBL_EDIT_BUTTON' => 'Redaguoti',
  'LBL_DUPLICATE_BUTTON_TITLE' => 'Dubliuoti [Alt+U]',
  'LBL_DUPLICATE_BUTTON' => 'Dubliuoti',
  'LBL_DELETE_BUTTON_TITLE' => 'Naikinti [Alt+D]',
  'LBL_DELETE_BUTTON' => 'Naikinti',
  'LBL_NEW_BUTTON_TITLE' => 'Sukurti [Alt+N]',
  'LBL_CHANGE_BUTTON_TITLE' => 'Keisti [Alt+G]',
  'LBL_CANCEL_BUTTON_TITLE' => 'Atmesti [Alt+X]',
  'LBL_SEARCH_BUTTON_TITLE' => 'Ie�koti [Alt+Q]',
  'LBL_CLEAR_BUTTON_TITLE' => 'I�valyti [Alt+C]',
  'LBL_SELECT_BUTTON_TITLE' => 'I�rinkti [Alt+T]',
  'LBL_SAVE_BUTTON_KEY' => 'S',
  'LBL_EDIT_BUTTON_KEY' => 'E',
  'LBL_DUPLICATE_BUTTON_KEY' => 'U',
  'LBL_DELETE_BUTTON_KEY' => 'D',
  'LBL_NEW_BUTTON_KEY' => 'N',
  'LBL_CHANGE_BUTTON_KEY' => 'G',
  'LBL_CANCEL_BUTTON_KEY' => 'X',
  'LBL_SEARCH_BUTTON_KEY' => 'Q',
  'LBL_CLEAR_BUTTON_KEY' => 'C',
  'LBL_SELECT_BUTTON_KEY' => 'T',
  'LBL_SAVE_BUTTON_LABEL' => 'I�saugoti',
  'LBL_EDIT_BUTTON_LABEL' => 'Redaguoti',
  'LBL_DUPLICATE_BUTTON_LABEL' => 'Dubliuoti',
  'LBL_DELETE_BUTTON_LABEL' => 'Naikinti',
  'LBL_NEW_BUTTON_LABEL' => 'Sukurti',
  'LBL_CHANGE_BUTTON_LABEL' => 'Pakeisti',
  'LBL_CANCEL_BUTTON_LABEL' => 'Atmesti',
  'LBL_SEARCH_BUTTON_LABEL' => 'Ie�koti',
  'LBL_CLEAR_BUTTON_LABEL' => 'I�valyti',
  'LBL_NEXT_BUTTON_LABEL' => 'Toliau',
  'LBL_SELECT_BUTTON_LABEL' => 'I�rinkti',
  'LBL_SELECT_CONTACT_BUTTON_TITLE' => 'I�rinkti kontakt� [Alt+T]',
  'LBL_SELECT_CONTACT_BUTTON_KEY' => 'T',
  'LBL_VIEW_PDF_BUTTON_LABEL' => 'Spausdinti',
  'LBL_VIEW_PDF_CONTACT_BUTTON_TITLE' => 'Spausdinti [Alt+P]',
  'LBL_VIEW_PDF_CONTACT_BUTTON_KEY' => 'P',
  'LBL_SELECT_CONTACT_BUTTON_LABEL' => 'I�rinkti kontakt�',
  'LBL_SELECT_USER_BUTTON_TITLE' => 'I�rinkti vartotoj� [Alt+U]',
  'LBL_SELECT_USER_BUTTON_KEY' => 'U',
  'LBL_SELECT_USER_BUTTON_LABEL' => 'I�rinkti vartotoj�',
  'LBL_CREATE_BUTTON_LABEL' => 'Sukurti',
  'LBL_SHORTCUTS' => 'Trumpiniai',
  'LBL_LIST_NAME' => 'Vardas',



  'LBL_LIST_USER_NAME' => 'Vartotojo vardas',
  'LBL_LIST_EMAIL' => 'El.pa�tas',
  'LBL_LIST_PHONE' => 'Telefonas',
  'LBL_LIST_CONTACT_NAME' => 'Kontakto vardas',
  'LBL_LIST_CONTACT_ROLE' => 'Kontakto vaidmuo',
  'LBL_LIST_ACCOUNT_NAME' => 'Kliento pavadinimas',
  'LBL_USER_LIST' => 'Vartotoj� s�ra�as',
  'LBL_CONTACT_LIST' => 'Kontakt� s�ra�as',
  'LBL_RELATED_RECORDS' => 'Susij� �ra�ai',
  'LBL_MASS_UPDATE' => 'Atnaujinti visk�',
  'LNK_ADVANCED_SEARCH' => 'I�samiai',
  'LNK_BASIC_SEARCH' => 'Paprastai',
  'LNK_EDIT' => 'redaguoti',
  'LNK_REMOVE' => '�alinti',
  'LNK_DELETE' => 'naikinti',
  'LNK_LIST_START' => 'Prad�ia',
  'LNK_LIST_NEXT' => 'Kitas',
  'LNK_LIST_PREVIOUS' => 'Ankstesnis',
  'LNK_LIST_END' => 'Pabaiga',
  'LBL_LIST_OF' => 'i�',
  'LBL_OR' => 'ARBA',
  'LNK_PRINT' => 'Spausdinti',
  'LNK_HELP' => 'Pagalba',
  'LNK_ABOUT' => 'Apie',
  'NTC_REQUIRED' => 'Pa�ymi b�tin� lauk�',
  'LBL_REQUIRED_SYMBOL' => '*',
  'LBL_CURRENCY_SYMBOL' => '$',
  'LBL_PERCENTAGE_SYMBOL' => '%',
  'LBL_THOUSANDS_SYMBOL' => 'K',
  'NTC_DATE_FORMAT' => '(yyyy-mm-dd)',
  'NTC_TIME_FORMAT' => '(24:00)',
  'NTC_DATE_TIME_FORMAT' => '(yyyy-mm-dd 24:00)',
  'NTC_DELETE_CONFIRMATION' => 'Ar tikrai norite naikinti �� �ra��?',
  'ERR_DELETE_RECORD' => 'Kontakto naikinimui turi b�ti nurodyta �ra�o numeris.',
  'ERR_CREATING_TABLE' => 'Klaida kuriant lentel�: ',
  'ERR_CREATING_FIELDS' => 'Klaida pildant papildomus laukus: ',
  'ERR_MISSING_REQUIRED_FIELDS' => 'Tr�ksta reikaling� lauk�:',
  'ERR_INVALID_EMAIL_ADDRESS' => 'negalima el.pa�to adresas.',
  'ERR_INVALID_DATE_FORMAT' => 'Datos formatas turi b�ti: yyyy-mm-dd',
  'ERR_INVALID_MONTH' => '�veskite reising� m�nes�.',
  'ERR_INVALID_DAY' => '�veskite teising� dien�.',
  'ERR_INVALID_YEAR' => '�veskite teisingus 4-i� skaitmen� metus.',
  'ERR_INVALID_DATE' => '�veskite teising� dat�.',
  'ERR_INVALID_HOUR' => '�veskite teising� valand�.',
  'ERR_INVALID_TIME' => '�veskite teising� laik�.',
  'ERR_INVALID_AMOUNT' => '�veskite teising� sum�.',
  'NTC_CLICK_BACK' => 'Paspauskite nar�ykl�s mygtuk� "Back" ir i�taisykite klaid�.',
  'LBL_LIST_ASSIGNED_USER' => 'Vartotojas',
  'LBL_ASSIGNED_TO' => 'Priskirta:',
  'LBL_DATE_MODIFIED' => 'Pakeista:',
  'LBL_DATE_ENTERED' => 'Sukurta:',
  'LBL_CURRENT_USER_FILTER' => 'Tik mano �ra�us:',
  'NTC_LOGIN_MESSAGE' => '�veskite savo vartotojo vard� ir slapta�od�.',
  'LBL_NONE' => '--nenurodyta--',
  'LBL_BACK' => 'Atgal',
  'LBL_IMPORT' => 'Importuoti',
  'LBL_EXPORT' => 'Eksportuoti',
  'LBL_EXPORT_ALL' => 'Eksportuoti visk�',
  'LBL_SAVE_NEW_BUTTON_TITLE' => 'I�saugoti ir sukurti nauj� [Alt+V]',
  'LBL_SAVE_NEW_BUTTON_KEY' => 'V',
  'LBL_SAVE_NEW_BUTTON_LABEL' => 'I�saugoti ir sukurti nauj�',
  'LBL_NAME' => 'Vardas',





  'LBL_SUBJECT' => 'Tema',
);


?>
