<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/sugarcrm/modules/Tasks/language/lt_lt.lang.php, v1.00 2004/12/30 eugen Exp $
 * Description:  Defines the Lithuanian language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'U�duotys',
  'LBL_TASK' => 'U�duotys: ',
  'LBL_MODULE_TITLE' => ' U�duotys: prad�ia',
  'LBL_SEARCH_FORM_TITLE' => ' U�duo�i� paie�ka',
  'LBL_LIST_FORM_TITLE' => ' U�duo�i� s�ra�as',
  'LBL_NEW_FORM_TITLE' => ' Sukurti u�duot�',
  'LBL_NEW_FORM_SUBJECT' => 'Tema:',
  'LBL_NEW_FORM_DUE_DATE' => '�vykdymo data:',
  'LBL_NEW_FORM_DUE_TIME' => '�vykdymo laikas:',
  'LBL_NEW_TIME_FORMAT' => '(24:00)',
  'LBL_LIST_CLOSE' => 'U�daryti',
  'LBL_LIST_SUBJECT' => 'Tema',
  'LBL_LIST_CONTACT' => 'Kontaktas',
  'LBL_LIST_RELATED_TO' => 'Susij� su',
  'LBL_LIST_DUE_DATE' => '�vykdymo data',
  'LBL_LIST_DUE_TIME' => '�vykdymo laikas',
  'LBL_SUBJECT' => 'Tema:',
  'LBL_STATUS' => 'B�sena:',
  'LBL_DUE_DATE' => '�vykdymo data:',
  'LBL_PRIORITY' => 'Prioritetas:',
  'LBL_COLON' => ':',
  'LBL_DUE_DATE_AND_TIME' => 'Pabaigos data ir laikas:',
  'DATE_FORMAT' => '(yyyy-mm-dd)',
  'LBL_NONE' => 'nieko',
  'LBL_CONTACT' => 'Kontaktas:',
  'LBL_PHONE' => 'Telefonas:',
  'LBL_EMAIL' => 'El.pa�tas:',
  'LBL_DESCRIPTION_INFORMATION' => 'Apra�ymas',
  'LBL_DESCRIPTION' => 'Apra�ymas:',
  'LBL_NAME' => 'Vardas:',
  'LBL_CONTACT_NAME' => 'Kontakto vardas: ',
  'LBL_LIST_COMPLETE' => '�vykdyta:',
  'LBL_LIST_STATUS' => 'B�sena:',
  'ERR_DELETE_RECORD' => 'Kontakto panaikinimui turi b�ti nurodytas �ra�o numeris.',
  'ERR_INVALID_HOUR' => '�veskite valand� nuo 0 iki 24',
  'LBL_DEFAULT_STATUS' => 'Neprad�ta',
  'LBL_DEFAULT_PRIORITY' => 'Vidutinis',
  'LNK_NEW_CALL' => 'Sukurti skambut�',
  'LNK_NEW_MEETING' => 'Sukurti susitikim�',
  'LNK_NEW_TASK' => 'Sukurti u�duot�',
  'LNK_NEW_NOTE' => 'Sukurti u�ra��',
  'LNK_NEW_EMAIL' => 'Sukurti el.lai�k�',
  'LNK_CALL_LIST' => 'Skambu�iai',
  'LNK_MEETING_LIST' => 'Susitikimai',
  'LNK_TASK_LIST' => 'U�duotys',
  'LNK_NOTE_LIST' => 'U�ra�ai',
  'LNK_EMAIL_LIST' => 'El.lai�kai',
  'LNK_VIEW_CALENDAR' => '�iandien',
);


?>
