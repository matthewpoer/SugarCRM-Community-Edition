<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/sugarcrm/modules/Calendar/language/lt_lt.lang.php,v 1.00 2005/01/05 eugen Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LNK_NEW_CALL' => 'Sukurti skambut�',
  'LNK_NEW_MEETING' => 'Sukurti susitikim�',
  'LNK_NEW_APPOINTMENT' => 'Sukurti paskyrim�',
  'LNK_NEW_TASK' => 'Sukurti u�duot�',
  'LNK_CALL_LIST' => 'Skambu�iai',
  'LNK_MEETING_LIST' => 'Susitikimai',
  'LNK_TASK_LIST' => 'U�duotys',
  'LNK_VIEW_CALENDAR' => '�iandien',
  'LBL_MONTH' => 'M�nuo',
  'LBL_DAY' => 'Diena',
  'LBL_YEAR' => 'Metai',
  'LBL_WEEK' => 'Savait�',
  'LBL_PREVIOUS_MONTH' => 'Ankstesnis m�nuo',
  'LBL_PREVIOUS_DAY' => 'Ankstesn� diena',
  'LBL_PREVIOUS_YEAR' => 'Ankstesni metai',
  'LBL_PREVIOUS_WEEK' => 'Ankstesn� savait�',
  'LBL_NEXT_MONTH' => 'Kitas m�nuo',
  'LBL_NEXT_DAY' => 'Kita diena',
  'LBL_NEXT_YEAR' => 'Kiti metai',
  'LBL_NEXT_WEEK' => 'Kita savait�',
  'LBL_AM' => 'AM',
  'LBL_PM' => 'PM',
  'LBL_SCHEDULED' => 'Suplanuotas',
  'LBL_BUSY' => 'U�imtas',
  'LBL_CONFLICT' => 'Persidengia',
  'LBL_USER_CALENDARS' => 'Vartotojo kalendoriai',
);

$mod_list_strings = array(
'dom_cal_weekdays'=>array(
"Sek",
"Pir",
"Ant",
"Tre",
"Ket",
"Pen",
"�e�",
),
'dom_cal_weekdays_long'=>array(
"Sekmadienis",
"Pirmadienis",
"Antradienis",
"Tre�iadienis",
"Ketvirtadienis",
"Penktadienis",
"�e�tadienis",
),
'dom_cal_month'=>array(
"",
"Sau",
"Vas",
"Kov",
"Bal",
"Geg",
"Bir",
"Lie",
"Rgp",
"Rgs",
"Spa",
"Lap",
"Grd",
),
'dom_cal_month_long'=>array(
"",
"Sausis",
"Vasaris",
"Kovas",
"Balandis",
"Gegu��",
"Bir�elis",
"Liepa",
"Rugpj�tis",
"Rugs�jis",
"Spalis",
"Lapkritis",
"Gruodis",
)
);
?>
