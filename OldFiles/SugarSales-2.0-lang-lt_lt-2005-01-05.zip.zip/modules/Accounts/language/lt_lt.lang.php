<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/sugarcrm/modules/Accounts/language/lt_lt.lang.php, v1.00 2004/12/30 eugen Exp $
 * Description:  Defines the Lithuanian language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Klientai',
  'LBL_MODULE_TITLE' => 'Klientai: prad�ia',
  'LBL_SEARCH_FORM_TITLE' => 'Kliento paie�ka',
  'LBL_LIST_FORM_TITLE' => 'Klient� s�ra�as',
  'LBL_NEW_FORM_TITLE' => 'Naujas klientas',
  'LBL_MEMBER_ORG_FORM_TITLE' => 'Priklauso organizacijai',
  'LBL_LIST_ACCOUNT_NAME' => 'Kliento pavadinimas',
  'LBL_LIST_CITY' => 'Miestas',
  'LBL_LIST_WEBSITE' => 'Svetain�',
  'LBL_LIST_STATE' => 'Rajonas',
  'LBL_LIST_PHONE' => 'Telefonas',
  'LBL_LIST_EMAIL_ADDRESS' => 'El. pa�tas',
  'LBL_LIST_CONTACT_NAME' => 'Kontaktas',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_website' => 'LBL_LIST_WEBSITE',
  'db_billing_address_city' => 'LBL_LIST_CITY',
//END DON'T CONVERT
  'LBL_ACCOUNT_INFORMATION' => 'Kliento informacija',
  'LBL_ACCOUNT' => 'Klientas:',
  'LBL_ACCOUNT_NAME' => 'Kliento pavadinimas:',
  'LBL_PHONE' => 'Telefonas:',
  'LBL_WEBSITE' => 'Svetain�:',
  'LBL_FAX' => 'Faksas:',
  'LBL_TICKER_SYMBOL' => 'Ticker Symbol:',
  'LBL_OTHER_PHONE' => 'Kitas telefonas:',
  'LBL_ANY_PHONE' => 'Any Phone:',
  'LBL_MEMBER_OF' => 'Priklauso organizacijai:',
  'LBL_EMAIL' => 'El.pa�tas:',
  'LBL_EMPLOYEES' => 'Darbuotojai:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Kitas e.pa�tas:',
  'LBL_ANY_EMAIL' => 'Any Email:',
  'LBL_OWNERSHIP' => 'Nuosavyb�:',
  'LBL_RATING' => 'Reitingas:',
  'LBL_INDUSTRY' => 'Veiklos sritis:',
  'LBL_SIC_CODE' => 'SIC Code:',
  'LBL_TYPE' => 'Tipas:',
  'LBL_ANNUAL_REVENUE' => 'Metin�s pajamos:',
  'LBL_ADDRESS_INFORMATION' => 'Adresas',
  'LBL_BILLING_ADDRESS' => 'Adresas s�skaitoms:',
  'LBL_SHIPPING_ADDRESS' => 'Siuntimo adresas:',
  'LBL_ANY_ADDRESS' => 'Any Address:',
  'LBL_CITY' => 'Miestas:',
  'LBL_STATE' => 'Rajonas:',
  'LBL_POSTAL_CODE' => 'Pa�to kodas:',
  'LBL_COUNTRY' => 'Valstyb�:',
  'LBL_DESCRIPTION_INFORMATION' => 'Apra�ymas',
  'LBL_DESCRIPTION' => 'Apra�ymas:',
  'NTC_COPY_BILLING_ADDRESS' => 'Kopijuoti adres� s�skaitoms � siuntimo adres�',
  'NTC_COPY_SHIPPING_ADDRESS' => 'Kopijuoti siuntimo adres� � adres� s�skaitoms',
  'NTC_REMOVE_MEMBER_ORG_CONFIRMATION' => 'Ar tikrai norite panaikinti �� priklausymo organizacijai �ra��?',
  'LBL_DUPLICATE' => 'Galimai pasikartojamas klientas',
  'MSG_DUPLICATE' => '�io kliento suk�rimas gali sukurti pasikartojant� klient�. Pasirinkite klient� i� s�ra�o apa�ioje arba paspauskite "Sukurti nauj� klient�" naujo kliento suk�rimui su anks�iau �vestais duomenimis.',
  'LNK_NEW_ACCOUNT' => 'Sukurti klient�',
  'LNK_ACCOUNT_LIST' => 'Klientai',
  'LBL_INVITEE' => 'Kontaktai',
  'ERR_DELETE_RECORD' => 'Kliento naikinimui turi b�ti nurodytas �ra�o numeris.',
  'NTC_DELETE_CONFIRMATION' => 'Ar tikrai norite panaikinti �� �ra��?',

);


?>
