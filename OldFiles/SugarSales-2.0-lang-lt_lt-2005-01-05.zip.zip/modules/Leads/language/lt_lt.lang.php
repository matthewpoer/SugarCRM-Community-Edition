<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/sugarcrm/modules/Leads/language/lt_lt.lang.php, v1.01 2005/01/05 eugen Exp $
 * Description:  Defines the Lithuanian language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Nuorodos',
  'LBL_INVITEE' => 'Tiesiogiai atskaitingas',
  'LBL_MODULE_TITLE' => 'Nuorodos: prad�ia',
  'LBL_SEARCH_FORM_TITLE' => 'Nuorod� paie�ka',
  'LBL_LIST_FORM_TITLE' => 'Nuorod� s�ra�as',
  'LBL_NEW_FORM_TITLE' => 'Nauja nuoroda',
  'LBL_CONTACT_OPP_FORM_TITLE' => 'Nuoroda-galimyb�:',
  'LBL_CONTACT' => 'Noroda:',
  'LBL_BUSINESSCARD' => 'Pakeisti nuorod�',
  'LBL_LIST_NAME' => 'vardas',
  'LBL_LIST_LAST_NAME' => 'Pavard�',
  'LBL_LIST_CONTACT_NAME' => 'Nuorodos pavadinimas',
  'LBL_LIST_TITLE' => 'Pareigos',
  'LBL_LIST_ACCOUNT_NAME' => 'Kliento pavadinimas',
  'LBL_LIST_EMAIL_ADDRESS' => 'El.pa�tas',
  
  'LBL_LIST_PHONE' => 'Telefonas',
  'LBL_LIST_CONTACT_ROLE' => 'Vaidmuo',
  'LBL_LIST_FIRST_NAME' => 'Vardas',
  'LBL_LIST_REFERED_BY' => 'Rekomendavo',
  'LBL_LIST_LEAD_SOURCE' => 'Nuorodos �altinis',
  'LBL_LIST_STATUS' => 'B�sena',
  'LBL_LIST_DATE_ENTERED' => 'Suk�rimo data',
  'LBL_LIST_LEAD_SOURCE_DESCRIPTION' => 'Nuorodos �altinio apra�ymas',
  'LBL_LIST_MY_LEADS' => 'Mano nuorodos',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_account_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_email2' => 'LBL_LIST_EMAIL_ADDRESS',
//END DON'T CONVERT
  'LBL_EXISTING_CONTACT' => 'Paimtas jau esantis kontaktas',
  'LBL_CREATED_CONTACT' => 'Sukurtas naujas kontaktas',
  'LBL_EXISTING_OPPORTUNITY' => 'Paimta jau esanti galimyb�',
  'LBL_CREATED_OPPORTUNITY' => 'Sukurta nauja galimyb�',
  'LBL_EXISTING_ACCOUNT' => 'Paimtas jau esantis klientas',
  'LBL_CREATED_ACCOUNT' => 'Sukurtas naujas klientas',
  'LBL_CREATED_CALL' => 'Sukurtas naujas skambutis',
  'LBL_CREATED_MEETING' => 'Sukurtas naujas susitikimas',
  'LBL_BACKTOLEADS' => 'Atgal � nuorodas',
  'LBL_CONVERTLEAD' => 'Pakeisti nuorod�',
  'LBL_NAME' => 'Vardas:',
  'LBL_CONTACT_NAME' => 'Nuorodos pavadinimas:',
  'LBL_CONTACT_INFORMATION' => 'Nuorodos informacija',
  'LBL_FIRST_NAME' => 'Vardas:',
  'LBL_OFFICE_PHONE' => 'Darbo telefonas:',
  'LBL_ACCOUNT_NAME' => 'Kliento pavadinimas:',
  'LBL_OPPORTUNITY_NAME' => 'Galimyb�s pavadinimas:',
  'LBL_OPPORTUNITY_AMOUNT' => 'Galimyb�s suma:',
  'LBL_ANY_PHONE' => 'Any Phone:',
  'LBL_PHONE' => 'Telefonas:',
  'LBL_LAST_NAME' => 'Pavard�:',
  'LBL_MOBILE_PHONE' => 'Mob. telefonas:',
  'LBL_HOME_PHONE' => 'Prad�ia:',
  'LBL_LEAD_SOURCE' => 'Nuorodos �altinis:',
  'LBL_STATUS' => 'B�sena:',
  'LBL_LEAD_SOURCE_DESCRIPTION' => 'Nuorodos �altinio apra�ymas:',
  'LBL_STATUS_DESCRIPTION' => 'B�senos apra�ymas:',
  'LBL_OTHER_PHONE' => 'Kitas telefonas:',
  'LBL_FAX_PHONE' => 'Faksas:',
  'LBL_TITLE' => 'Titulas:',
  'LBL_DEPARTMENT' => 'Departamentas:',
  'LBL_EMAIL_ADDRESS' => 'El.pa�tas:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Kitas el.pa�tas:',
  'LBL_ANY_EMAIL' => 'Any Email:',
  'LBL_REPORTS_TO' => 'Atskaitingas:',
  'LBL_DO_NOT_CALL' => 'Neskambinti:',
  'LBL_EMAIL_OPT_OUT' => 'Nesi�sti el.lai�k�:',
  'LBL_PRIMARY_ADDRESS' => 'Pagrindinis adresas:',
  'LBL_ALTERNATE_ADDRESS' => 'Kitas adresas:',
  'LBL_ANY_ADDRESS' => 'Any Address:',
  'LBL_REFERED_BY' => 'Rekomendavo:',
  'LBL_CITY' => 'Miestas:',
  'LBL_STATE' => 'Rajonas:',
  'LBL_POSTAL_CODE' => 'Pa�to kodas:',
  'LBL_COUNTRY' => '�alis:',
  'LBL_DESCRIPTION_INFORMATION' => 'Apra�ymas',
  'LBL_ADDRESS_INFORMATION' => 'Adresas',
  'LBL_DESCRIPTION' => 'Apra�ymas:',
  'LBL_CONTACT_ROLE' => 'Vaidmuo:',
  'LBL_OPP_NAME' => 'Galimyb�s pavadinimas:',
  'LBL_IMPORT_VCARD' => 'Importuoti vCard',
  'LNK_IMPORT_VCARD' => 'Sukurti i� vCard',
  'LBL_IMPORT_VCARDTEXT' => 'Automati�kai sukurti nauj� nuorod� importuojant vCard.',
  'LBL_DUPLICATE' => 'Pana�ios nuorodos',
  'MSG_DUPLICATE' => 'Rastos pana�ios nuorodos. Pa�ym�kite nuorodas susiejimui su �ra�ais, kurie bus sukurti po �io pakeitimo. Pa�ym�j�, spauskite "toliau".',
  'LBL_ADD_BUSINESSCARD' => 'Prid�ti vizitin� kortel�',
  'LNK_NEW_APPOINTMENT' => 'Sukurti paskyrim�',
  'LNK_NEW_LEAD' => 'Sukurti nuorod�',
  'LNK_LEAD_LIST' => 'Nuorodos',
  'NTC_DELETE_CONFIRMATION' => 'Ar tikrai norite panaikinti �� �ra��?',
  'NTC_REMOVE_CONFIRMATION' => 'Ar tikrai norite pa�alinti �i� nuorod� i� paklausimo?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Ar tikrai norite panaikinti �� tiesiogin�s atskaitomyb�s �ra��?',
  'ERR_DELETE_RECORD' => 'Nuorodos naikinimui turi b�ti nurodytas �ra�o numeris.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Kopijuoti pagrindin� adres� � papildom� adres�',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Kopijuoti papildom� adres� � pagrindin� adres�',
  'LNK_NEW_CONTACT' => 'Sukurti kontakt�',
  'LNK_NEW_NOTE' => 'Sukurti u�ra��',
  'LNK_NEW_ACCOUNT' => 'Sukurti klient�',
  'LNK_NEW_OPPORTUNITY' => 'Sukurti galimyb�',
  'LNK_SELECT_ACCOUNT' => 'I�rinkti klient�',
  'LBL_SALUTATION' => 'Pasveikinimas',
   'NTC_OPPORTUNITY_REQUIRES_ACCOUNT' => 'Galimybei sukurti reikalingas klientas.\n Sukurkite nauj� klient� arba pasirinkite jau esant�.',
);


?>
