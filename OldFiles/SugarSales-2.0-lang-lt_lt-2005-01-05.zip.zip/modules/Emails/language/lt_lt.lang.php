<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/sugarcrm/modules/Emails/language/lt_lt.lang.php, v1.00 2004/12/30 eugen Exp $
 * Description:  Defines the Lithuanian language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'El.lai�kai',
  'LBL_MODULE_TITLE' => 'El.lai�kai: prad�ia',
  'LBL_SEARCH_FORM_TITLE' => 'El.lai�k� paie�ka',
  'LBL_LIST_FORM_TITLE' => 'El.lai�k� s�ra�as',
  'LBL_NEW_FORM_TITLE' => 'Archyvuoti el.lai�kus',
  'LBL_LIST_SUBJECT' => 'Tema',
  'LBL_LIST_CONTACT' => 'Kontaktas',
  'LBL_LIST_RELATED_TO' => 'Susij�s su',
  'LBL_LIST_DATE' => 'I�siuntimo data',
  'LBL_LIST_TIME' => 'I�siuntimo laikas',
  'ERR_DELETE_RECORD' => 'Kliento naikinimui turi b�ti nurodytas �ra�o numeris.',
  'LBL_DATE_SENT' => 'I�siuntimo data:',
  'LBL_SUBJECT' => 'Tema:',
  'LBL_BODY' => 'Prane�imas:',
  'LBL_DATE_AND_TIME' => 'I�siuntimo data ir laikas:',
  'LBL_DATE' => 'I�siuntimo data:',
  'LBL_TIME' => 'I�siuntimo laikas:',
  'LBL_CONTACT_NAME' => ' Kontakto vardas: ',
  'LBL_EMAIL' => 'El.lai�kas:',
  'LBL_COLON' => ':',
  'LNK_NEW_EMAIL' => 'Sukurti el.lai�k�',
  'LNK_EMAIL_LIST' => 'El.lai�kai',
  'NTC_REMOVE_INVITEE' => 'Ar tikrai norite panaikinti �� el.lai�ko gav�j�?',
  'LBL_INVITEE' => 'Gav�jai',
'LNK_NEW_CALL'=>'Sukurti skambut�',
'LNK_NEW_MEETING'=>'Sukurti susitikim�',
'LNK_NEW_TASK'=>'Sukurti u�duot�',
'LNK_NEW_NOTE'=>'Sukurti u�ra��',
'LNK_NEW_EMAIL'=>'Sukurti el.lai�k�',
'LNK_CALL_LIST'=>'Skambu�iai',
'LNK_MEETING_LIST'=>'Susitikimai',
'LNK_TASK_LIST'=>'U�duotys',
'LNK_NOTE_LIST'=>'U�ra�ai',
'LNK_EMAIL_LIST'=>'El.lai�kai',

);


?>
