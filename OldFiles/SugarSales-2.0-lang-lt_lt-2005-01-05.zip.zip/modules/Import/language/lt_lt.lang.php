<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/sugarcrm/modules/Import/language/lt_lt.lang.php,v 1.00 2005/01/05 eugen Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_IMPORT_MODULE_NO_DIRECTORY' => 'Katalogas ',
  'LBL_IMPORT_MODULE_NO_DIRECTORY_END' => ' neegzistuoja arba draud�iamas ra�ymui',
  'LBL_IMPORT_MODULE_ERROR_NO_UPLOAD' => 'Bylos pakrauti nepavyko, pabandykite dar kart�',
  'LBL_IMPORT_MODULE_ERROR_LARGE_FILE' => 'Byla per didel�. Maks:',
  'LBL_IMPORT_MODULE_ERROR_LARGE_FILE_END' => 'bait�. Pakeiskite $upload_maxsize byloje config.php',
  'LBL_MODULE_NAME' => 'Importuoti',
  'LBL_TRY_AGAIN' => 'Bandyti dar kart�',
  'LBL_ERROR' => 'Klaida:',
  'ERR_MULTIPLE' => 'Keletas stulpeli� priskirti tam pa�iam laukui.',
  'ERR_MISSING_REQUIRED_FIELDS' => 'Tr�ksta reikaling� laik�:',
  'ERR_SELECT_FULL_NAME' => 'Nagalima pasirinkti "Vardas, Pavard�" jei pasirinkote "Vardas" ir "Pavard�".',
  'ERR_SELECT_FILE' => 'Pasirinkte byl� pakrovimui.',
  'LBL_SELECT_FILE' => 'Pasirinkite byl�:',
  'LBL_CUSTOM' => 'Kitas',
  'LBL_DONT_MAP' => '-- nenaudoti �io lauko --',
  'LBL_STEP_1_TITLE' => '�ingsnis 1: duomen� �altinio pasirinkimas',
  'LBL_WHAT_IS' => 'Kas yra duomen� �altinis?',
  'LBL_MICROSOFT_OUTLOOK' => 'Microsoft Outlook',
  'LBL_ACT' => 'Act!',
  'LBL_SALESFORCE' => 'Salesforce.com',
  'LBL_MY_SAVED' => 'My Saved Sources:',
  'LBL_PUBLISH' => 'skelbti',
  'LBL_DELETE' => 'naikinti',
  'LBL_PUBLISHED_SOURCES' => 'Paskelbti �altiniai:',
  'LBL_UNPUBLISH' => 'neskelbti',
  'LBL_NEXT' => 'Toliau >',
  'LBL_BACK' => '< Atgal',
  'LBL_STEP_2_TITLE' => '�ingsnis 2: eksporto bylos pakrovimas',
  'LBL_HAS_HEADER' => 'Turi antra�t�:',
  'LBL_NUM_1' => '1.',
  'LBL_NUM_2' => '2.',
  'LBL_NUM_3' => '3.',
  'LBL_NUM_4' => '4.',
  'LBL_NUM_5' => '5.',
  'LBL_NUM_6' => '6.',
  'LBL_NUM_7' => '7.',
  'LBL_NUM_8' => '8.',
  'LBL_NUM_9' => '9.',
  'LBL_NUM_10' => '10.',
  'LBL_NUM_11' => '11.',
  'LBL_NUM_12' => '12.',
  'LBL_NOW_CHOOSE' => 'Pasirinkite byl� importui:',
  'LBL_IMPORT_OUTLOOK_TITLE' => 'Microsoft Outlook 98 ir 2000 gali eksportuoti duomenis <b>Comma Separated Values</b> formatu, kuris tinkamas duomen� importui � sistem�. Duomen� eksportui i� Outlook �vykdykite �iuos �ingsnius:',
  'LBL_OUTLOOK_NUM_1' => 'I�kvieskite <b>Outlook</b>',
  'LBL_OUTLOOK_NUM_2' => 'Punkte <b>File</b> pasirinkite <b>Import and Export ...</b>',
  'LBL_OUTLOOK_NUM_3' => 'Pasirinkite <b>Export to a file</b> ir spauskite <b>Next</b>',
  'LBL_OUTLOOK_NUM_4' => 'Pasirinkite <b>Comma Separated Values (Windows)</b> ir spauskite <b>Next</b>.<br>  Pastaba: J�s� gali papra�yti �diegti eksporto komponent�',
  'LBL_OUTLOOK_NUM_5' => 'Pasirinkite <b>Contacts</b> subkatalog� ir spauskite <b>Next</b>. Galite pasirinkti kit� kontakt� katalog�, jei jie saugomi keliuose kataloguose',
  'LBL_OUTLOOK_NUM_6' => 'Nurodykite bylos pavadinim� ir spauskite <b>Next</b>',
  'LBL_OUTLOOK_NUM_7' => 'Spauskite <b>Finish</b>',
  'LBL_IMPORT_ACT_TITLE' => 'Act! gali eksportuoti duomenis <b>Comma Separated Values</b> formatu, kuris tinkamas duomen� importui � sistem�. Duomen� eksportui i� Act! �vykdykite �iuos �ingsnius:',
  'LBL_ACT_NUM_1' => 'I�kvieskite <b>ACT!</b>',
  'LBL_ACT_NUM_2' => 'Punkte <b>File</b> pasirinkte <b>Data Exchange</b>, po to pasirinkite <b>Export...</b>',
  'LBL_ACT_NUM_3' => 'Pasirinkite bylos tip� <b>Text-Delimited</b>',
  'LBL_ACT_NUM_4' => 'Nurodykite eksportuojam� duomen� bylos pavadinim� bei viet� ir spauskite <b>Next</b>',
  'LBL_ACT_NUM_5' => 'Pasirinkite <b>Contacts records only</b>',
  'LBL_ACT_NUM_6' => 'Paspauskite mygtuk� <b>Options...</b>',
  'LBL_ACT_NUM_7' => 'Pasirinkite lauk� atskyrimo simbol� <b>Comma</b>',
  'LBL_ACT_NUM_8' => 'Pa�ym�kite langel� <b>Yes, export field names</b> ir spauskite <b>OK</b>',
  'LBL_ACT_NUM_9' => 'Spauskite <b>Next</b>',
  'LBL_ACT_NUM_10' => 'Pasirinkite <b>All Records</b> ir spauskite <b>Finish</b>',
  'LBL_IMPORT_SF_TITLE' => 'Salesforce.com gali eksportuoti duomenis <b>Comma Separated Values</b> formatu, kuris tinkamas duomen� importui � sistem�. Duomen� eksportui i� Salesforce.com �vykdykite �iuos �ingsnius:',
  'LBL_SF_NUM_1' => 'Nar�ykl�je pasirinkite http://www.salesforce.com ir prisijunkite su savo el.pa�to adresu ir slapta�od�iu',
  'LBL_SF_NUM_2' => 'Vir�utiniame meniu paspauskite <b>Reports</b>',
  'LBL_SF_NUM_3' => '<b>Klient� eksportui:</b> paspauskite nuorod� <b>Active Accounts</b><br><b>Kontakt� eksportui:</b> paspauskite nuorod� <b>Mailing List</b>',
  'LBL_SF_NUM_4' => '<b>Step 1: Select your report type</b> pasirinkite <b>Tabular Report</b> ir paspauskite <b>Next</b>',
  'LBL_SF_NUM_5' => '<b>Step 2: Select the report columns</b> pasirinkite stulpelius, kuriuos norite eksportuoti, ir paspauskite <b>Next</b>',
  'LBL_SF_NUM_6' => '<b>Step 3: Select the information to summarize</b> spauskite <b>Next</b>',
  'LBL_SF_NUM_7' => '<b>Step 4: Order the report columns</b> spauskite <b>Next</b>',
  'LBL_SF_NUM_8' => '<b>Step 5: Select your report criteria</b> prie <b>Start Date</b> pasirinkite pakankamai sen� dat�, kuri apimt� visus klientus. Taipogi galite eksportuoti klient� poaib� naudodami kitus kriterijus. Pabaig� spauskite <b>Run Report</b>',
  'LBL_SF_NUM_9' => 'Bus sugeneruota ataskaita ir matysite <b>Report Generation Status: Complete.</b> Dabar paspauskite <b>Export to Excel</b>',
  'LBL_SF_NUM_10' => '<b>Export Report:</b> prie <b>Export File Format:</b> pasirinkite <b>Comma Delimited .csv</b>. Paspauskite <b>Export</b>.',
  'LBL_SF_NUM_11' => 'Pamatysite dialogo lang� eksporto pylos i�saugojimui.',
  'LBL_IMPORT_CUSTOM_TITLE' => 'Daugelis taikom�j� program� leid�ia eksportuoti duomenis <b>Comma Delimited text file (.csv)</b> formatu. Daugumi program� reikalingi �ie �ingsniai:',
  'LBL_CUSTOM_NUM_1' => 'I�kvieskite program� ir atidarykite duomen� byl�',
  'LBL_CUSTOM_NUM_2' => 'Pasirinkte punkt� <b>Save As...</b> arba <b>Export...</b>',
  'LBL_CUSTOM_NUM_3' => 'I�saugokite byl� <b>CSV</b> arba <b>Comma Separated Values</b> formatu',
  'LBL_STEP_3_TITLE' => 'Step 3: lauk� pasirinkimas ir importas',
  'LBL_SELECT_FIELDS_TO_MAP' => 'Pasirinkite importo bylos laukus, kurie bus importuojami � kiekvien� sistemos lauk�. Baig� paspauskite <b>Importuoti</b>:',
  'LBL_DATABASE_FIELD' => 'Duomen� baz�s laukas',
  'LBL_HEADER_ROW' => 'Antra�r�s eilut�',
  'LBL_ROW' => 'Eilut�',
  'LBL_SAVE_AS_CUSTOM' => 'I�saugoti lauk� pasirinkim�:',
  'LBL_CONTACTS_NOTE_1' => 'Pasirinkite tik "Pavard�" arba "Vardas, pavard�".',
  'LBL_CONTACTS_NOTE_2' => 'Jei pasirenkamas "Vardas, pavard�", tai "Vardas" ir "Pavard�" yra ignoruojami.',
  'LBL_CONTACTS_NOTE_3' => 'Jei pasirenkamas "Vardas, pavard�", tai duomenys "Vardas, pavard�" �traukiant � duomen� baz� padalinami � laukus "Vardas" ir "Pavard�".',
  'LBL_CONTACTS_NOTE_4' => 'Laukai "Adresas/gatv� 2" ir "Adresas/gatv� 3" �traukiant � duomen� baz� yra sujungiami su pagrindiniu "Adresas/gatv�" lauku.',
  'LBL_ACCOUNTS_NOTE_1' => 'Turi b�ti pasirinktas laukas "Kliento pavadinimas".',
  'LBL_ACCOUNTS_NOTE_2' => 'Laukai "Adresas/gatv� 2" ir "Adresas/gatv� 3" �traukiant � duomen� baz� yra sujungiami su pagrindiniu "Adresas/gatv�" lauku.',
  'LBL_OPPORTUNITIES_NOTE_1' => '"Galimyb�s pavadinimas", "Kliento pavadinimas", "Pabaigos data" ir "Pardavimo etapas" yra b�tini laukai.',
  'LBL_IMPORT_NOW' => 'Importuoti',
  'LBL_' => '',
  'LBL_CANNOT_OPEN' => 'Nepavyko nuskaityti importo bylos',
  'LBL_NOT_SAME_NUMBER' => 'Nevienodas lauk� skai�ius bylos eilut�se',
  'LBL_NO_LINES' => 'Importo byloje n�ta nei vienos eilut�s',
  'LBL_FILE_ALREADY_BEEN_OR' => 'Importo byla jau buvo apdorota arba ji neegzistuoja',
  'LBL_SUCCESS' => 'S�kmingai:',
  'LBL_SUCCESSFULLY' => 'S�kmingai importuota',
  'LBL_LAST_IMPORT_UNDONE' => 'Paskutinis importas at�auktas',
  'LBL_NO_IMPORT_TO_UNDO' => 'N�ra importo, kur� galima at�aukti.',
  'LBL_FAIL' => 'Klaida:',
  'LBL_RECORDS_SKIPPED' => '�ra�ai praleisti, kadangi juose tr�ksta vieno ar daugiau b�tin� lauk�',
  'LBL_IDS_EXISTED_OR_LONGER' => '�ra�ai praleisti, kadangi ID jau egzistuoja arba yra ilgesnis nei 36 simboliai',
  'LBL_RESULTS' => 'Rezultatai',
  'LBL_IMPORT_MORE' => 'Importuoti daugiau',
  'LBL_FINISHED' => 'Baigta',
  'LBL_UNDO_LAST_IMPORT' => 'At�aukti paskutin� import�',
);

$mod_list_strings = Array(
'contacts_import_fields' => Array(
	"id"=>"Kontakto ID"
	,"first_name"=>"Vardas"
	,"last_name"=>"Pavard�"
	,"salutation"=>"Kreipinys"
	,"lead_source"=>"Nuorodos �altinis"
	,"birthdate"=>"Gimimo data"
	,"do_not_call"=>"Neskambinti"
	,"email_opt_out"=>"Nesi�sti el.lai�k�t"
	,"primary_address_street_2"=>"Pagrindinis adresas/gatv� 2"
	,"primary_address_street_3"=>"Pagrindinis adresas/gatv� 3"
	,"alt_address_street_2"=>"Kitas adresas/gatv� 2"
	,"alt_address_street_3"=>"Kitas adresas/gatv� 3"
	,"full_name"=>"Vardas, pavard�"
	,"account_name"=>"Kliento pavadinimas"
	,"account_id"=>"Kliento ID"
	,"title"=>"Pareigos"
	,"department"=>"Departamentas"
	,"birthdate"=>"Gimimo data"
	,"do_not_call"=>"Neskambinti"
	,"phone_home"=>"Nam� telefonas"
	,"phone_mobile"=>"Mob. telefonas"
	,"phone_work"=>"Darbo telefonas"
	,"phone_other"=>"Kitas telefonas"
	,"phone_fax"=>"Faksas"
	,"email1"=>"El.pa�tas"
	,"email2"=>"Kitas el.pa�tas"
	,"assistant"=>"Asistentas"
	,"assistant_phone"=>"Asistento telefonas"
	,"primary_address_street"=>"Pagrindinis adresas/gatv�"
	,"primary_address_city"=>"Pagrindinis adresas/miestas"
	,"primary_address_state"=>"Pagrindinis adresas/rajonas"
	,"primary_address_postalcode"=>"Pagrindinis adresas/pa�to kodas"
	,"primary_address_country"=>"Pagrindinis adresas/�alis"
	,"alt_address_street"=>"Kitas adresas/gatv�"
	,"alt_address_city"=>"Kitas adresas/miestas"
	,"alt_address_state"=>"Kitas adresas/rajonas"
	,"alt_address_postalcode"=>"Kitas adresas/pa�to kodas"
	,"alt_address_country"=>"Kitas adresas/�alis"
	,"description"=>"Apra�ymas"

	),

'accounts_import_fields' => Array(
	"id"=>"Kliento ID",
	"name"=>"Kliento pavadinimas",
	"website"=>"Svetain�",
	"industry"=>"Veiklos sritis",
	"account_type"=>"Tipas",
	"ticker_symbol"=>"Ticker Symbol",
	"parent_name"=>"Priklauso organizacijai",
	"employees"=>"Darbuotojai",
	"ownership"=>"Nuosavyb�",
	"phone_office"=>"Telefonas",
	"phone_fax"=>"Faksas",
	"phone_alternate"=>"Kitas telefonas",
	"email1"=>"El.pa�tas",
	"email2"=>"Kitas el.pa�tas",
	"rating"=>"Reitingas",
	"sic_code"=>"SIC Code",
	"annual_revenue"=>"Metin�s pajamos",
	"billing_address_street"=>"S�skaitoms adresas/gatv�",
	"billing_address_street_2"=>"S�skaitoms adresas/gatv� 2",
	"billing_address_street_3"=>"S�skaitoms adresas/gatv� 3",
	"billing_address_street_4"=>"S�skaitoms adresas/gatv� 4",
	"billing_address_city"=>"S�skaitoms adresas/miestas",
	"billing_address_state"=>"S�skaitoms adresas/rajonas",
	"billing_address_postalcode"=>"S�skaitoms adresas/pa�to kodas",
	"billing_address_country"=>"S�skaitoms adresas/�alis",
	"shipping_address_street"=>"Siuntimo adresas/gatv�",
	"shipping_address_street_2"=>"Siuntimo adresas/gatv� 2",
	"shipping_address_street_3"=>"Siuntimo adresas/gatv� 3",
	"shipping_address_street_4"=>"Siuntimo adresas/gatv� 4",
	"shipping_address_city"=>"Siuntimo adresas/miestas",
	"shipping_address_state"=>"Siuntimo adresas/rajonas",
	"shipping_address_postalcode"=>"Siuntimo adresas/pa�to kodas",
	"shipping_address_country"=>"Siuntimo adresas/�alis",
	"description"=>"Apra�ymas"
	),

'opportunities_import_fields' => Array(
		"id"=>"Kliento ID"
                , "name"=>"Galimyb�s pavadinimas"
                , "account_name"=>"Kliento pavadinimas"
                , "opportunity_type"=>"Galimyb�s tipas"
                , "lead_source"=>"Nuorodos �altinis"
                , "amount"=>"Suma"
                , "date_closed"=>"Pabaigos data"
                , "next_step"=>"Kitas �ingsnis"
                , "sales_stage"=>"Pardavimo etapas"
                , "probability"=>"Tikimyb�"
                , "description"=>"Apra�ymas"
                ),

'leads_import_fields' => Array(
                "refered_by"=>"Rekomendavo"
                ,"salutation"=>"Kreipinys"
                ,"first_name"=>"Vardas"
                ,"last_name"=>"Pavard�"
                ,"lead_source"=>"Nuorodos �altinis"
                ,"lead_source_description"=>"Nuorodos �altinio apra�ymas"
                ,"title"=>"Pareigos"
                ,"department"=>"Departamentas"
                ,"do_not_call"=>"Neskambinti"
	,"phone_home"=>"Nam� telefonas"
	,"phone_mobile"=>"Mob. telefonas"
	,"phone_work"=>"Darbo telefonas"
	,"phone_other"=>"Kitas telefonas"
	,"phone_fax"=>"Faksas"
	,"email1"=>"El.pa�tas"
	,"email2"=>"Kitas el.pa�tas"
        ,"email_opt_out"=>"Nesi�sti el.lai�k�"
	,"primary_address_street_2"=>"Pagrindinis adresas/gatv� 2"
	,"primary_address_street_3"=>"Pagrindinis adresas/gatv� 3"
	,"alt_address_street_2"=>"Kitas adresas/gatv� 2"
	,"alt_address_street_3"=>"Kitas adresas/gatv� 3"
	,"primary_address_street"=>"Pagrindinis adresas/gatv�"
	,"primary_address_city"=>"Pagrindinis adresas/miestas"
	,"primary_address_state"=>"Pagrindinis adresas/rajonas"
	,"primary_address_postalcode"=>"Pagrindinis adresas/pa�to kodas"
	,"primary_address_country"=>"Pagrindinis adresas/�alis"
	,"alt_address_street"=>"Kitas adresas/gatv�"
	,"alt_address_city"=>"Kitas adresas/miestas"
	,"alt_address_state"=>"Kitas adresas/rajonas"
	,"alt_address_postalcode"=>"Kitas adresas/pa�to kodas"
	,"alt_address_country"=>"Kitas adresas/�alis"
	,"full_name"=>"Vardas, pavard�"
	,"description"=>"Apra�ymas"
        ,"status"=>"B�sena"
        ,"status_description"=>"B�senos apra�ymas"
        ,"account_name"=>"Kliento pavadinimas"
        ,"account_description"=>"Kliento apra�ymas"
        ),



);

?>
