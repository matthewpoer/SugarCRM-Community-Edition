<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/include/language/en_us.lang.php,v 1.89 2004/10/25 02:32:20 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Appels',
  'LBL_MODULE_TITLE' => 'Appels: Accueil',
  'LBL_SEARCH_FORM_TITLE' => 'Recherche d\'Appels',
  'LBL_LIST_FORM_TITLE' => 'Liste des Appels',
  'LBL_NEW_FORM_TITLE' => 'Appel plannifi�',
  'LBL_LIST_CLOSE' => 'Clos',
  'LBL_LIST_SUBJECT' => 'Sujet',
  'LBL_LIST_CONTACT' => 'Contact',
  'LBL_LIST_RELATED_TO' => 'Relatif �',
  'LBL_LIST_DATE' => 'Date de d�marrage',
  'LBL_LIST_TIME' => 'Heure de d�marrage',
  'LBL_LIST_DURATION' => 'Dur�e',
  'LBL_LIST_DIRECTION' => 'Direction',
  'LBL_SUBJECT' => 'Sujet:',
  'LBL_CONTACT_NAME' => 'Contact:',
  'LBL_DESCRIPTION_INFORMATION' => 'Description ',
  'LBL_DESCRIPTION' => 'Description:',
  'LBL_STATUS' => 'Statut:',
  'LBL_DATE' => 'Date de d�marrage:',
  'LBL_DURATION' => 'Dur�e:',
  'LBL_HOURS_MINUTES' => '(heures/minutes)',
  'LBL_CALL' => 'Appel:',
  'LBL_DATE_TIME' => 'Date & heure de d�marrage:',
  'LBL_TIME' => 'Heure de d�marrage:',
  'LBL_HOURS_ABBREV' => 'h',
  'LBL_MINSS_ABBREV' => 'm',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'Plannifi�',
  'LNK_NEW_CALL' => 'Nouvel Appel',
  'LNK_NEW_MEETING' => 'Nouveau Rendez-vous',
  'LNK_NEW_TASK' => 'Nouvelle T�che',
  'LNK_NEW_NOTE' => 'Nouvelle Note',
  'LNK_NEW_EMAIL' => 'Nouvel Email',
  'LNK_CALL_LIST' => 'Calls',
  'LNK_MEETING_LIST' => 'Meetings',
  'LNK_TASK_LIST' => 'Tasks',
  'LNK_NOTE_LIST' => 'Notes',
  'LNK_EMAIL_LIST' => 'Emails',
  'LNK_VIEW_CALENDAR' => 'Today',
  'ERR_DELETE_RECORD' => 'Un num�ro d\'enregistrement doit �tre sp�cifi� pour supprimer ce compte.',
  'NTC_REMOVE_INVITEE' => 'Etes vous s�r de vouloir supprimer ce contact de l\'appel ?',
  'LBL_INVITEE' => 'Contacts',
  'LNK_NEW_CONTACT' => 'Nouveau Contact',
  'LNK_NEW_ACCOUNT' => 'Nouveau Compte',
  'LNK_NEW_OPPORTUNITY' => 'Nouvelle Affaire',
  'LNK_NEW_CASE' => 'Nouveau Ticket',
  'LBL_INVITEES' => 'Contacts',
);


?>