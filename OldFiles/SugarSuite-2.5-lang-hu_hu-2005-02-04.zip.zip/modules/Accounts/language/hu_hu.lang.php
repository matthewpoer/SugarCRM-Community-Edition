<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => '�gyf�l',
  'LBL_MODULE_TITLE' => '�gyf�l: Nyilv�ntart�s',
  'LBL_SEARCH_FORM_TITLE' => '�gyf�l keres�s',
  'LBL_LIST_FORM_TITLE' => '�gyf�l lista',
  'LBL_NEW_FORM_TITLE' => '�j �gyf�l',
  'LBL_MEMBER_ORG_FORM_TITLE' => 'T�rsszervezet',
  'LBL_BUG_FORM_TITLE' => 'Accounts',
  'LBL_LIST_ACCOUNT_NAME' => '�gyf�l neve',
  'LBL_LIST_CITY' => 'V�ros',
  'LBL_LIST_WEBSITE' => 'Honlap',
  'LBL_LIST_STATE' => 'Orsz�g',
  'LBL_LIST_PHONE' => 'Telefon',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email',
  'LBL_LIST_CONTACT_NAME' => 'Kapcsolat neve',
  'db_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_website' => 'LBL_LIST_WEBSITE',
  'db_billing_address_city' => 'LBL_LIST_CITY',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'LBL_ACCOUNT_INFORMATION' => '�gyf�l inform�ci�',
  'LBL_ACCOUNT' => '�gyf�l:',
  'LBL_ACCOUNT_NAME' => '�gyf�ln�v:',
//END DON'T CONVERT
  'LBL_PHONE' => 'Telefon:',
  'LBL_PHONE_ALT' => 'Alternate Phone:',
  'LBL_WEBSITE' => 'Honlap:',
  'LBL_FAX' => 'Fax:',
  'LBL_TICKER_SYMBOL' => 'Ticker szimb�lum:',
  'LBL_OTHER_PHONE' => 'Egy�b telefon:',
  'LBL_ANY_PHONE' => 'B�rmely telefon:',
  'LBL_MEMBER_OF' => 'Tags�g:',
  'LBL_PHONE_OFFICE' => 'Phone Office:',
  'LBL_PHONE_FAX' => 'Phone Fax:',
  'LBL_EMAIL' => 'Email:',
  'LBL_EMPLOYEES' => 'Alkalmazottak:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Egy�b Email:',
  'LBL_ANY_EMAIL' => 'B�rmely Email:',
  'LBL_OWNERSHIP' => 'Tulajdoni viszony:',
  'LBL_RATING' => 'Besorol�s:',
  'LBL_INDUSTRY' => 'Ipar�g:',
  'LBL_SIC_CODE' => 'SIC k�d:',
  'LBL_TYPE' => 'T�pus:',
  'LBL_ANNUAL_REVENUE' => '�ves forgalom:',
  'LBL_ADDRESS_INFORMATION' => 'C�m inform�ci�',
  'LBL_BILLING_ADDRESS' => 'Sz�ml�z�si c�m:',
  'LBL_BILLING_ADDRESS_STREET' => 'Billing Address Street:',
  'LBL_BILLING_ADDRESS_CITY' => 'Billing Address City:',
  'LBL_BILLING_ADDRESS_STATE' => 'Billing Address State:',
  'LBL_BILLING_ADDRESS_POSTALCODE' => 'Billing Address Postal Code:',
  'LBL_BILLING_ADDRESS_COUNTRY' => 'Billing Address Country:',
  'LBL_SHIPPING_ADDRESS_STREET' => 'Shipping Address Street:',
  'LBL_SHIPPING_ADDRESS_CITY' => 'Shipping Address City:',
  'LBL_SHIPPING_ADDRESS_STATE' => 'Shipping Address State:',
  'LBL_SHIPPING_ADDRESS_POSTALCODE' => 'Shipping Address Postal Code:',
  'LBL_SHIPPING_ADDRESS_COUNTRY' => 'Shipping Address Country:',
  'LBL_SHIPPING_ADDRESS' => 'Post�z�si c�m:',
  'LBL_DATE_MODIFIED' => 'Date Modified:',
  'LBL_DATE_ENTERED' => 'Date Entered:',
  'LBL_ANY_ADDRESS' => 'B�rmely c�m:',
  'LBL_CITY' => 'V�ros:',
  'LBL_STATE' => '�llam:',
  'LBL_POSTAL_CODE' => 'Ir�ny�t�sz�m:',
  'LBL_COUNTRY' => 'Orsz�g:',
  'LBL_DESCRIPTION_INFORMATION' => 'Ismertet� inform�ci�',
  'LBL_DESCRIPTION' => 'Ismertet�:',
  'NTC_COPY_BILLING_ADDRESS' => 'M�sold a sz�ml�z�si c�met a post�z�si c�mhez',
  'NTC_COPY_SHIPPING_ADDRESS' => 'M�sold a post�z�si c�met a sz�ml�z�si c�mhez',
  'NTC_REMOVE_MEMBER_ORG_CONFIRMATION' => 'Biztosan t�r�lni akarja ezeket az adatokat a t�rsszervezetek k�z�l?',
  'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Are you sure you want to remove this record?',
  'LBL_DUPLICATE' => 'Lehets�ges, hogy m�r l�tezik ilyen adategys�g',
  'MSG_SHOW_DUPLICATES' => 'Creating this contact may potentialy create a duplicate contact. You may either click on Create Account to continue creating this new account with the previously entered data or you may click Cancel.',
  'MSG_DUPLICATE' => 'A l�trehozni tervezett adategys�g val�sz�n�leg m�r l�tezik. V�laszthat az al�bbi �gyf�llist�b�l egy bejegyz�st, vagy az �j �gyf�l nyom�gombbal l�trehozhatja az im�nt be�rt adategys�get.',
  'LNK_NEW_ACCOUNT' => '�j �gyf�l',
  'LNK_ACCOUNT_LIST' => '�gyfelek',
  'LBL_INVITEE' => 'Kapcsolatok',
  'ERR_DELETE_RECORD' => 'Az azonos�t�sz�m meghat�roz�sa sz�ks�ges az adategys�g elt�vol�t�s�hoz.',
  'NTC_DELETE_CONFIRMATION' => 'Are you sure you want to delete this record?',
  'LBL_SAVE_ACCOUNT' => 'Save Account',
);


?>