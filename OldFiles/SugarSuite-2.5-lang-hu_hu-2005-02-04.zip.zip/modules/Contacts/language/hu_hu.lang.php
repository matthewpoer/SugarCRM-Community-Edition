<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Kapcsolatok',
  'LBL_INVITEE' => 'K�zvetlen jelent�st�tel',
  'LBL_MODULE_TITLE' => 'Kapcsolatok: Nyilv�ntart�s',
  'LBL_SEARCH_FORM_TITLE' => 'Kapcsolat keres�s',
  'LBL_LIST_FORM_TITLE' => 'Kapcsolatok lista',
  'LBL_NEW_FORM_TITLE' => '�j kapcsolat',
  'LBL_CONTACT_OPP_FORM_TITLE' => 'Kapcsolat-lehet�s�g:',
  'LBL_CONTACT' => 'Kapcsolat:',
  'LBL_BUSINESSCARD' => 'C�gk�rtya',
  'LBL_LIST_NAME' => 'N�v',
  'LBL_LIST_LAST_NAME' => 'Vezet�kn�v',
  'LBL_LIST_CONTACT_NAME' => 'Kapcsolat n�v',
  'LBL_LIST_TITLE' => 'Munkak�r',
  'LBL_LIST_ACCOUNT_NAME' => '�gyf�l n�v',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email',
  'LBL_LIST_OTHER_EMAIL_ADDRESS' => 'M�s Email',
  'LBL_LIST_PHONE' => 'Telefon',
  'LBL_LIST_CONTACT_ROLE' => 'Szerep',
  'LBL_LIST_FIRST_NAME' => 'Keresztn�v',
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_email2' => 'LBL_LIST_OTHER_EMAIL_ADDRESS',
  'LBL_EXISTING_CONTACT' => 'Megl�v� kapcsolat alkalmaz�sa',
  'LBL_CREATED_CONTACT' => '�j kapcsolat l�trehozva',
  'LBL_EXISTING_ACCOUNT' => 'Megl�v� �gyf�l alkalmaz�sa',
//END DON'T CONVERT
  'LBL_CREATED_ACCOUNT' => '�j �gyf�l l�trehozva',
  'LBL_CREATED_CALL' => '�j h�v�s l�trehozva',
  'LBL_CREATED_MEETING' => '�j t�rgyal�s l�trehozva',
  'LBL_ADDMORE_BUSINESSCARD' => 'M�s c�gk�rtya hozz�ad�sa',
  'LBL_ADD_BUSINESSCARD' => '�j kapcsolat c�gk�rty�b�l',
  'LBL_NAME' => 'N�v:',
  'LBL_CONTACT_NAME' => 'Kapcsolat neve:',
  'LBL_CONTACT_INFORMATION' => 'Kapcsolat inform�ci�',
  'LBL_FIRST_NAME' => 'Keresztn�v:',
  'LBL_OFFICE_PHONE' => 'Munkahelyi telefon:',
  'LBL_ACCOUNT_NAME' => '�gyf�l n�v:',
  'LBL_ANY_PHONE' => 'B�rmely telefon:',
  'LBL_PHONE' => 'Telefon:',
  'LBL_LAST_NAME' => 'Vezet�kn�v:',
  'LBL_MOBILE_PHONE' => 'Mobil:',
  'LBL_HOME_PHONE' => 'Otthon:',
  'LBL_LEAD_SOURCE' => '�rdekl�d�s forr�sa:',
  'LBL_OTHER_PHONE' => 'M�s telefon:',
  'LBL_FAX_PHONE' => 'Fax:',
  'LBL_PRIMARY_ADDRESS_STREET' => 'Primary Address Street:',
  'LBL_PRIMARY_ADDRESS_CITY' => 'Primary Address City:',
  'LBL_PRIMARY_ADDRESS_COUNTRY' => 'Primary Address Country:',
  'LBL_PRIMARY_ADDRESS_STATE' => 'Primary Address State:',
  'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'Primary Address Postal Code:',
  'LBL_ALT_ADDRESS_STREET' => 'Alternate Address Street:',
  'LBL_ALT_ADDRESS_CITY' => 'Alternate Address City:',
  'LBL_ALT_ADDRESS_COUNTRY' => 'Alternate Address Country:',
  'LBL_ALT_ADDRESS_STATE' => 'Alternate Address State:',
  'LBL_ALT_ADDRESS_POSTALCODE' => 'Alternate Address Postal Code:',
  'LBL_TITLE' => 'Munkak�r:',
  'LBL_DEPARTMENT' => 'Oszt�ly:',
  'LBL_BIRTHDATE' => 'Sz�let�s id�pontja:',
  'LBL_EMAIL_ADDRESS' => 'Email:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'M�s Email:',
  'LBL_ANY_EMAIL' => 'B�rmely Email:',
  'LBL_REPORTS_TO' => 'Felettes:',
  'LBL_ASSISTANT' => 'Asszisztens:',
  'LBL_ASSISTANT_PHONE' => 'Asszisztens telefon:',
  'LBL_DO_NOT_CALL' => 'Ne h�vja:',
  'LBL_EMAIL_OPT_OUT' => 'Opc. kimen� Email:',
  'LBL_PRIMARY_ADDRESS' => 'Els�dleges c�m:',
  'LBL_ALTERNATE_ADDRESS' => 'Alternat�v c�m:',
  'LBL_ANY_ADDRESS' => 'B�rmely c�m:',
  'LBL_CITY' => 'V�ros:',
  'LBL_STATE' => '�llam:',
  'LBL_POSTAL_CODE' => 'Ir�ny�t�sz�m:',
  'LBL_COUNTRY' => 'Orsz�g:',
  'LBL_DESCRIPTION_INFORMATION' => 'Ismertet� inform�ci�',
  'LBL_ADDRESS_INFORMATION' => 'C�m inform�ci�',
  'LBL_DESCRIPTION' => 'Ismertet�:',
  'LBL_CONTACT_ROLE' => 'Szerep:',
  'LBL_OPP_NAME' => 'Lehet�s�g n�v:',
  'LBL_IMPORT_VCARD' => 'Import vCard',
  'LBL_IMPORT_VCARDTEXT' => '�j kapcsolat automatikusan l�trehozva a vCard import�l�s�val.',
  'LBL_DUPLICATE' => 'A kapcsolat esetleg m�r l�tezik a nyilv�ntart�sban',
  'MSG_SHOW_DUPLICATES' => 'Creating this contact may potentialy create a duplicate contact. You may either click on Create Contact to continue creating this new contact with the previously entered data or you may click Cancel.',
  'MSG_DUPLICATE' => 'Az �j kapcsolat felv�tele esetleg azonos egy m�r megl�v� kapcsolattal. V�lassza ki a kapcsolatot az al�bbi list�b�l, vagy v�lassza az �j Kapcsolat nyom�gombot az im�nt felvezetett adategys�g felv�tel�re.',
  'LNK_CONTACT_LIST' => 'Kapcsolatok',
  'LNK_IMPORT_VCARD' => '�j kapcsolat vCard-b�l',
  'LNK_NEW_CONTACT' => '�j kapcsolat',
  'LNK_NEW_ACCOUNT' => '�j �gyf�l',
  'LNK_NEW_OPPORTUNITY' => '�j lehet�s�g',
  'LNK_NEW_CASE' => '�j �gy',
  'LNK_NEW_NOTE' => '�j jegyzet',
  'LNK_NEW_CALL' => '�j h�v�s',
  'LNK_NEW_EMAIL' => '�j Email',
  'LNK_NEW_MEETING' => '�j t�rgyal�s',
  'LNK_NEW_TASK' => '�j feladat',
  'LNK_NEW_APPOINTMENT' => '�j egyeztet�s',
  'NTC_DELETE_CONFIRMATION' => 'Biztosan t�r�lni akarja ezt az adategys�get?',
  'NTC_REMOVE_CONFIRMATION' => 'Biztosan t�r�lni akarja ezt a kapcsolatot ebb�l az �gyb�l?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Biztosan t�r�lni akarja ezt az adategys�get a k�zvetlen jelent�sek k�z�l?',
  'ERR_DELETE_RECORD' => 'Az azonos�t�sz�m meghat�roz�sa sz�ks�ges az adategys�g t�rl�s�hez.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Az els�dleges c�m m�sol�sa az alternat�v c�mhez',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Az alternat�v c�m m�sol�sa az els�dleges c�mhez',
  'LBL_SALUTATION' => 'Megsz�l�t�s',
  'LBL_SAVE_CONTACT' => 'Save Contact',
);


?>