<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'T�rgyal�sok',
  'LBL_MODULE_TITLE' => 'T�rgyal�sok: Nyilv�ntart�s',
  'LBL_SEARCH_FORM_TITLE' => 'T�rgyal�s keres�s',
  'LBL_LIST_FORM_TITLE' => 'T�rgyal�s lista',
  'LBL_NEW_FORM_TITLE' => 'T�rgyal�s id�z�t�se',
  'LBL_LIST_SUBJECT' => 'T�rgy',
  'LBL_LIST_CONTACT' => 'Kapcsolat neve',
  'LBL_LIST_RELATED_TO' => 'Kapcsol�dik ehhez ',
  'LBL_LIST_DATE' => 'Kezd�si d�tum',
  'LBL_LIST_TIME' => 'Kezd�si id�pont',
  'LBL_LIST_CLOSE' => 'Z�r�s',
  'LBL_SUBJECT' => 'T�rgy: ',
  'LBL_STATUS' => 'St�tusz:',
  'LBL_LOCATION' => 'Helysz�n:',
  'LBL_DATE_TIME' => 'Kezd�si d�tum & id�pont:',
  'LBL_DATE' => 'Kezd�si d�tum:',
  'LBL_TIME' => 'Kezd�si id�pont:',
  'LBL_DURATION' => 'Id�tartam:',
  'LBL_DURATION_HOURS' => 'Duration Hours:',
  'LBL_DURATION_MINUTES' => 'Duration Minutes:',
  'LBL_HOURS_MINS' => '(�r�k/percek)',
  'LBL_CONTACT_NAME' => 'Kapcsolat neve: ',
  'LBL_MEETING' => 'T�rgyal�s:',
  'LBL_DESCRIPTION_INFORMATION' => 'Le�r�si inform�ci�',
  'LBL_DESCRIPTION' => 'Le�r�s:',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'Tervezve',
  'LNK_NEW_CALL' => '�j h�v�s',
  'LNK_NEW_MEETING' => '�j t�rgyal�s',
  'LNK_NEW_TASK' => '�j feladat',
  'LNK_NEW_NOTE' => '�j jegyzet',
  'LNK_NEW_EMAIL' => '�j Email',
  'LNK_CALL_LIST' => 'H�v�sok',
  'LNK_MEETING_LIST' => 'T�rgyal�sok',
  'LNK_TASK_LIST' => 'Feladatok',
  'LNK_NOTE_LIST' => 'Jegyzetek',
  'LNK_EMAIL_LIST' => 'Emailek',
  'LNK_VIEW_CALENDAR' => 'Ma',
  'ERR_DELETE_RECORD' => 'Az azonos�t�sz�m meghat�roz�sa sz�ks�ges a t�rgyal�s t�rl�s�hez.',
  'NTC_REMOVE_INVITEE' => 'Biztosan t�r�lni k�v�nja a megh�vottat a t�rgyal�sr�l?',
  'LBL_INVITEE' => 'Megh�vottak',
  'LNK_NEW_APPOINTMENT' => '�j egyeztet�s',
);


?>