<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Calendar',
  'LBL_MODULE_TITLE' => 'Calendar',
  'LNK_NEW_CALL' => '�j h�v�s',
  'LNK_NEW_MEETING' => '�j t�rgyal�s',
  'LNK_NEW_APPOINTMENT' => '�j egyeztet�s',
  'LNK_NEW_TASK' => '�j feladat',
  'LNK_CALL_LIST' => 'H�v�sok',
  'LNK_MEETING_LIST' => 'T�rgyal�sok',
  'LNK_TASK_LIST' => 'Feladatok',
  'LNK_VIEW_CALENDAR' => 'Ma',
  'LBL_MONTH' => 'H�nap',
  'LBL_DAY' => 'Nap',
  'LBL_YEAR' => '�v',
  'LBL_WEEK' => 'H�t',
  'LBL_PREVIOUS_MONTH' => 'El�z� h�nap',
  'LBL_PREVIOUS_DAY' => 'El�z� nap',
  'LBL_PREVIOUS_YEAR' => 'El�z� �v',
  'LBL_PREVIOUS_WEEK' => 'El�z� h�t',
  'LBL_NEXT_MONTH' => 'K�vetkez� h�nap',
  'LBL_NEXT_DAY' => 'K�vetkez� nap',
  'LBL_NEXT_YEAR' => 'K�vetkez� �v',
  'LBL_NEXT_WEEK' => 'K�vetkez� h�t',
  'LBL_AM' => 'AM',
  'LBL_PM' => 'PM',
  'LBL_SCHEDULED' => 'Betervezve',
  'LBL_BUSY' => 'Folyamatban',
  'LBL_CONFLICT' => '�tk�z�s',
  'LBL_USER_CALENDARS' => 'Felhaszn�l�i napt�r',
);

$mod_list_strings = array (
  'dom_cal_weekdays' => 
  array (
    0 => 'V',
    1 => 'H',
    2 => 'K',
    3 => 'Sze',
    4 => 'Cs',
    5 => 'P',
    6 => 'Szo',
  ),
  'dom_cal_weekdays_long' => 
  array (
    0 => 'Vas�rnap',
    1 => 'H�tf�',
    2 => 'Kedd',
    3 => 'Szerda',
    4 => 'Cs�t�rt�k',
    5 => 'P�ntek',
    6 => 'Szombat',
  ),
  'dom_cal_month' => 
  array (
    0 => '',
    1 => 'Jan',
    2 => 'Feb',
    3 => 'M�r',
    4 => 'Apr',
    5 => 'M�j',
    6 => 'J�n',
    7 => 'J�l',
    8 => 'Aug',
    9 => 'Szep',
    10 => 'Okt',
    11 => 'Nov',
    12 => 'Dec',
  ),
  'dom_cal_month_long' => 
  array (
    0 => '',
    1 => 'Janu�r',
    2 => 'Febru�r',
    3 => 'M�rcius',
    4 => '�prilis',
    5 => 'M�jus',
    6 => 'J�nius',
    7 => 'J�lius',
    8 => 'Augusztus',
    9 => 'Szeptember',
    10 => 'Okt�ber',
    11 => 'November',
    12 => 'December',
  ),
);


?>