<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Kimutat�sok',
  'LBL_MODULE_TITLE' => 'Kimutat�sok: Nyilv�ntart�s',
  'LBL_SALES_STAGE_FORM_TITLE' => 'Folyamat az �rt�kes�t�s alapj�n',
  'LBL_SALES_STAGE_FORM_DESC' => 'Kumulat�v lehet�s�gek �sszess�ge az �rt�kes�t�s meghat�rozott szakaszaira kijel�lt felhaszn�l�k eset�ben, akiknek a v�rhat� z�r�si id�pontja a megadott id�tartamra esik.',
  'LBL_YEAR_BY_OUTCOME' => 'Pipeline By Month By Outcome',
  'LBL_MONTH_BY_OUTCOME_DESC' => 'Kumulat�v lehet�s�gek �sszess�ge a hozam meghat�rozott szakaszaira kijel�lt felhaszn�l�k eset�ben, akiknek a v�rhat� z�r�si id�pontja a megadott id�tartamra esik. A hozam meg�t�l�se a sikeresen z�rt, sikertelen�l z�rt vagy m�s �rt�k alapj�n t�rt�nik.',
  'LBL_LEAD_SOURCE_FORM_TITLE' => '�rdekl�d�k a m�dszerek szerint',
  'LBL_LEAD_SOURCE_FORM_DESC' => 'Kumulat�v �rdekl�d�k �sszess�ge az �zleti folyamat meghat�rozott szakaszaira a kijel�lt felhaszn�l�k eset�ben.',
  'LBL_LEAD_SOURCE_BY_OUTCOME' => '�rdekl�d�k a m�dszerek szerint',
  'LBL_LEAD_SOURCE_BY_OUTCOME_DESC' => 'Kumulat�v �rdekl�d�k �sszess�ge az �zleti folyamat �s a hozam meghat�rozott szakaszaira kijel�lt felhaszn�l�k eset�ben, akiknek a v�rhat� z�r�si id�pontja a megadott id�tartamra esik. A hozam meg�t�l�se a sikeresen z�rt, sikertelen�l z�rt vagy m�s �rt�k alapj�n t�rt�nik.',
  'LBL_PIPELINE_FORM_TITLE_DESC' => 'Kumulat�v �rdekl�d�k �sszess�ge az �rt�kes�t�s meghat�rozott szakaszaira, ahol a v�rhat� z�r�si id�pontja a megadott id�tartamra esik.',
  'LBL_DATE_RANGE' => 'Az id�pont k�v�l esik a lehets�ges �rt�keken',
  'LBL_DATE_RANGE_TO' => '-',
  'ERR_NO_OPPS' => 'K�rem �ll�tson �ssze �zlet-adategys�geket a grafikon �br�zol�s�hoz.',
  'LBL_TOTAL_PIPELINE' => 'A folyamat �sszess�ge ',
  'LBL_ALL_OPPORTUNITIES' => '�zletek �sszessen ',
  'LBL_OPP_SIZE' => '�rdekl�d�s m�rt�ke: ',
  'LBL_OPP_THOUSANDS' => 'K',
  'NTC_NO_LEGENDS' => 'Nincs',
  'LBL_LEAD_SOURCE_OTHER' => 'M�s',
  'LBL_EDIT' => 'Szerkeszt�s',
  'LBL_REFRESH' => 'Friss�t�s',
  'LBL_CREATED_ON' => 'Legut�bb lefuttatva ',
  'LBL_OPPS_WORTH' => 'opportunities worth',
  'LBL_OPPS_IN_STAGE' => '�rdekl�d�k, ahol az �rt�kes�t�si szakasz',
  'LBL_OPPS_IN_LEAD_SOURCE' => '�rdekl�d�k, ahol az �zleti folyamat',
  'LBL_OPPS_OUTCOME' => '�zletek, ahol a hozam',
  'LBL_ROLLOVER_DETAILS' => 'Rollover a bar for details.',
  'LBL_ROLLOVER_WEDGE_DETAILS' => 'Rollover a wedge for details.',
  'LBL_USERS' => 'Felhaszn�l�k:',
  'LBL_SALES_STAGES' => '�rt�kes�t�si szakasz:',
  'LBL_LEAD_SOURCES' => 'Szakasz:',
  'LBL_DATE_START' => 'Kezd�s d�tum:',
  'LBL_DATE_END' => 'Z�r�s d�tum:',
  'LBL_YEAR' => 'Year:',
  'LNK_NEW_CONTACT' => '�j kapcsolat',
  'LNK_NEW_ACCOUNT' => '�j �gyf�l',
  'LNK_NEW_OPPORTUNITY' => '�j �zlet',
  'LNK_NEW_QUOTE' => '�j aj�nlat',
  'LNK_NEW_LEAD' => '�j �rdekl�d�',
  'LNK_NEW_CASE' => '�j �gy',
  'LNK_NEW_NOTE' => '�j jegyzet',
  'LNK_NEW_CALL' => '�j h�v�s',
  'LNK_NEW_MEETING' => '�j t�rgyal�s',
  'LNK_NEW_TASK' => '�j feladat',
  'LNK_NEW_ISSUE' => 'Report Bug',
  'LBL_MONTH_BY_OUTCOME' => 'Folyamat a havi hozam tekintet�ben',
);


?>