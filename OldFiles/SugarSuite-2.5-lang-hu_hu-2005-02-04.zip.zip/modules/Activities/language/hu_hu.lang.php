<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Aktivit�sok',
  'LBL_MODULE_TITLE' => 'Aktivit�sok: Nyilv�ntart�s',
  'LBL_SEARCH_FORM_TITLE' => 'Aktivit�sok keres�s',
  'LBL_LIST_FORM_TITLE' => 'Aktivit�sok lista',
  'LBL_LIST_SUBJECT' => 'T�rgy',
  'LBL_LIST_CONTACT' => 'Kapcsolat',
  'LBL_LIST_RELATED_TO' => 'Kapcsol�dik ehhez: ',
  'LBL_LIST_DATE' => 'D�tum',
  'LBL_LIST_TIME' => 'Kezd�si id�pont',
  'LBL_LIST_CLOSE' => 'Z�r�s',
  'LBL_SUBJECT' => 'T�rgy:',
  'LBL_STATUS' => 'St�tusz:',
  'LBL_LOCATION' => 'Helysz�n:',
  'LBL_DATE_TIME' => 'Kezd�si d�tum �s id�pont:',
  'LBL_DATE' => 'Kezd�si d�tum:',
  'LBL_TIME' => 'Kezd�si id�pont:',
  'LBL_DURATION' => 'Id�tartam:',
  'LBL_HOURS_MINS' => '(�r�k/percek)',
  'LBL_CONTACT_NAME' => 'Kapcsolat neve: ',
  'LBL_MEETING' => 'T�rgyal�s:',
  'LBL_DESCRIPTION_INFORMATION' => 'Ismertet� inform�ci�',
  'LBL_DESCRIPTION' => 'Ismertet�:',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'Tervezett',
  'LNK_NEW_CALL' => '�j h�v�s',
  'LNK_NEW_MEETING' => '�j t�rgyal�s',
  'LNK_NEW_TASK' => '�j feladat',
  'LNK_NEW_NOTE' => '�j jegyzet',
  'LNK_NEW_EMAIL' => '�j Email',
  'LNK_CALL_LIST' => 'H�v�sok',
  'LNK_MEETING_LIST' => 'T�rgyal�sok',
  'LNK_TASK_LIST' => 'Feladatok',
  'LNK_NOTE_LIST' => 'Jegyzetek',
  'LNK_EMAIL_LIST' => 'Emailek',
  'ERR_DELETE_RECORD' => 'Az azonos�t�sz�m meghat�roz�sa sz�ks�ge az adategys�g t�rl�s�hez.',
  'NTC_REMOVE_INVITEE' => 'Biztosan t�r�lni k�v�nja a megh�vottat a t�rgyal�sra megh�vottak list�j�r�l?',
  'LBL_INVITEE' => 'Megh�vottak',
  'LBL_LIST_DIRECTION' => 'T�rgyal�s c�lja',
  'LBL_DIRECTION' => 'T�rgyal�s c�lja',
  'LNK_NEW_APPOINTMENT' => '�j egyeztet�s',
  'LNK_VIEW_CALENDAR' => 'Ma',
  'LBL_OPEN_ACTIVITIES' => 'Nyitott aktivit�sok',
  'LBL_HISTORY' => 'El�zm�nyek',
  'LBL_UPCOMING' => 'Szem�lyes soronk�vetkez� aktivit�sok',
  'LBL_TODAY' => '- ',
  'LBL_NEW_TASK_BUTTON_TITLE' => '�j feladat [Alt+N]',
  'LBL_NEW_TASK_BUTTON_KEY' => 'N',
  'LBL_NEW_TASK_BUTTON_LABEL' => '�j feladat',
  'LBL_SCHEDULE_MEETING_BUTTON_TITLE' => 'T�rgyal�s tervez�se [Alt+M]',
  'LBL_SCHEDULE_MEETING_BUTTON_KEY' => 'M',
  'LBL_SCHEDULE_MEETING_BUTTON_LABEL' => 'T�rgyal�s tervez�se',
  'LBL_SCHEDULE_CALL_BUTTON_TITLE' => 'H�v�s tervez�se [Alt+C]',
  'LBL_SCHEDULE_CALL_BUTTON_KEY' => 'C',
  'LBL_SCHEDULE_CALL_BUTTON_LABEL' => 'H�v�s tervez�se',
  'LBL_NEW_NOTE_BUTTON_TITLE' => '�j jegyzet [Alt+T]',
  'LBL_NEW_NOTE_BUTTON_KEY' => 'T',
  'LBL_NEW_NOTE_BUTTON_LABEL' => '�j jegyzet',
  'LBL_TRACK_EMAIL_BUTTON_TITLE' => 'Email t�rol�sa [Alt+K]',
  'LBL_TRACK_EMAIL_BUTTON_KEY' => 'K',
  'LBL_TRACK_EMAIL_BUTTON_LABEL' => 'Email t�rol�sa',
  'LBL_LIST_STATUS' => 'St�tusz',
  'LBL_LIST_DUE_DATE' => 'Lej�rati id�pont',
  'LBL_LIST_LAST_MODIFIED' => 'Utols� m�dos�t�s',
  'NTC_NONE_SCHEDULED' => 'Nincsen tervezve.',
  'appointment_filter_dom' => 
  array (
    'today' => 'today',
    'tomorrow' => 'tomorrow',
    'this Saturday' => 'this week',
    'next Saturday' => 'next week',
    'last this_month' => 'this month',
    'last next_month' => 'next month',
  ),
  'LNK_IMPORT_NOTES' => 'Import Notes',
);


?>