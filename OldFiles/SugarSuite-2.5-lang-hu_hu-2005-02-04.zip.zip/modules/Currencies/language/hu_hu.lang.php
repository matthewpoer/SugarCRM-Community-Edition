<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_LIST_FORM_TITLE' => 'P�nznemek',
  'LBL_CURRENCY' => 'P�nznem',
  'LBL_ADD' => 'Hozz�ad�s',
  'LBL_MERGE' => '�sszevon�s',
  'LBL_MERGE_TXT' => 'K�rem ellen�rizze a p�nznemeket, melyeket a kiv�lasztott p�nznemhez k�v�n t�rs�tani. Ez a funkci� t�r�lni fogja a kipip�zott p�nznemeket �s �tv�lt minden sz�m�rt�ket a viszony�t�si p�nznemnek megfelel�en.',
  'LBL_US_DOLLAR' => 'U.S. Doll�r',
  'LBL_DELETE' => 'T�rl�s',
  'LBL_LIST_SYMBOL' => 'P�nznem szimb�lum',
  'LBL_LIST_NAME' => 'P�nznem n�v',
  'LBL_LIST_ISO4217' => 'ISO 4217 k�d',
  'LBL_UPDATE' => 'Friss�t�s',
  'LBL_LIST_RATE' => 'V�lt� �rfolyam',
  'LBL_LIST_STATUS' => 'St�tusz',
  'LNK_NEW_CONTACT' => '�j kapcsolat',
  'LNK_NEW_ACCOUNT' => '�j �gyf�l',
  'LNK_NEW_OPPORTUNITY' => '�j �zlet',
  'LNK_NEW_CASE' => '�j �gy',
  'LNK_NEW_NOTE' => '�j jegyzet',
  'LNK_NEW_CALL' => '�j h�v�s',
  'LNK_NEW_EMAIL' => '�j Email',
  'LNK_NEW_MEETING' => '�j t�rgyal�s',
  'LNK_NEW_TASK' => '�j feladat',
  'NTC_DELETE_CONFIRMATION' => 'Biztosan t�r�lni k�v�nja ezt az adategys�get? Tal�n szerencs�sebb passz�v �zemm�dra jel�lni, m�sk�l�nben minden adategys�g, amely ezt a p�nznemet haszn�lja, U.S Doll�rban fogja kifejezni az �rt�k�t.',
  'currency_status_dom' => 
  array (
    'Active' => 'Akt�v',
    'Inactive' => 'Passz�v',
  ),
);


?>