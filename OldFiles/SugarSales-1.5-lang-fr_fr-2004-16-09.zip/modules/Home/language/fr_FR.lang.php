<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): SYNOLIA TEAM - contactsugar@synolia.com / http://www.synolia.fr
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Home/language/en_us.lang.php,v 1.5 2004/08/03 07:43:17 sugarclint Exp $
 * Description:  Defines the English language pack 
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_NEW_FORM_TITLE'=>'Nouveau Contact',
'LBL_FIRST_NAME'=>'Pr�nom:',
'LBL_LAST_NAME'=>'Nom:',
'LBL_LIST_LAST_NAME'=>'Nom',
'LBL_PHONE'=>'T�l�phone:',
'LBL_EMAIL_ADDRESS'=>'Email:',

'LBL_PIPELINE_FORM_TITLE'=>'Portefeuille',
'LBL_TOTAL_PIPELINE'=>'Le montant total du portefeuille est ',
'LBL_OPP_SIZE'=>'Taille des Affaires en K�',

'LNK_NEW_CONTACT'=>'Nouveau Contact',
'LNK_NEW_ACCOUNT'=>'Nouveau Compte',
'LNK_NEW_OPPORTUNITY'=>'Nouvelle Affaire',
'LNK_NEW_CASE'=>'Nouveau Ticket',
'LNK_NEW_NOTE'=>'Nouvelle Note',
'LNK_NEW_CALL'=>'Nouvel Appel',
'LNK_NEW_EMAIL'=>'Nouvel Email',
'LNK_NEW_MEETING'=>'Nouveau Rendez-vous',
'LNK_NEW_TASK'=>'Nouvelle T�che',

'ERR_ONE_CHAR'=>"Merci de saisir au moins une lettre ou un chiffre pour votre recherche ...",
'LBL_OPEN_TASKS'=>'Mes t�ches ouvertes',
);

?>