<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Import/language/en_us.lang.php,v 1.2 2004/09/08 17:41:40 sugarrob Exp $
 * Description:  Defines the English language pack for the Account module.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/
/* 
'LBL_GO_TO_BUTTON_TITLE'=>'Aller � l'�tape 2',
'LBL_IMPORT_MODULE_SELECT_DELIMITER'=>'Select d�limiteur',
'LBL_IMPORT_MODULE_COMMA_CSV'=>'Virgule (CSV)',
'LBL_IMPORT_MODULE_TAB'=>'Tab',
'LBL_IMPORT_MODULE_CUSTOM'=>'Personnalis�:',
'LBL_IMPORT_MODULE_ERROR_NO_UPLOAD'=>'Le fichier n'a pas �t� upload� correctement, merci d'essayer � nouveau',
'LBL_IMPORT_MODULE_ERROR_LARGE_FILE'=>'La taille du fichier est trop importante. Max:',
'LBL_IMPORT_MODULE_ERROR_LARGE_FILE_END'=>'Octets',
'LBL_IMPORT_MODULE_ERROR'=>'Erreur:',
'LBL_IMPORT_MODULE_ERROR_MULTIPLE'=>'Plusieurs colonnes ont �t� d�finies avec le m�me nom de champ.',
'LBL_IMPORT_MODULE_ERROR_DELIMITER_NOT'=>'Le d�limiteur n'est pas d�fini.',
'LBL_IMPORT_MODULE_ERROR_CANT_OPEN'=>'File could not be opened.',
'LBL_IMPORT_MODULE_STEP_1_TITLE'=>'Step 1: File Upload',
'LBL_IMPORT_MODULE_STEP_2_TITLE'=>'Step 2: Choose Field Mappings',
*/



$mod_strings = Array(
'LBL_MODULE_NAME'=>'Import',
'LBL_TRY_AGAIN'=>'Essayez � nouveau',
'LBL_ERROR'=>'Erreur:',
'ERR_MULTIPLE'=>'Plusieurs colonnes ont �t� d�finies avec le m�me nom de champ.',
'ERR_MISSING_REQUIRED_FIELDS'=>'Champs requis manquants:',
'ERR_SELECT_FULL_NAME'=>'Vouu ne pouvez pas s�lectionner le nom complet lorsque le nom et le pr�nom sont s�lectionn�s.',
'ERR_SELECT_FILE'=>'Selectionnez un fichier � uploader.',
'LBL_SELECT_FILE'=>'Selectionner un fichier:',
'LBL_CUSTOM'=>'Custom',
'LBL_DONT_MAP'=>'-- Ne pas mapper ce champ --',
'LBL_STEP_1_TITLE'=>'Etape 1: Selectionner la source',
'LBL_WHAT_IS'=>'Quelle est la source de donn�es?',
'LBL_MICROSOFT_OUTLOOK'=>'Microsoft Outlook',
'LBL_ACT'=>'Act!',
'LBL_SALESFORCE'=>'Salesforce.com',
'LBL_MY_SAVED'=>'Mes sources sauvegard�es:',
'LBL_PUBLISH'=>'publi�',
'LBL_DELETE'=>'supprim�',
'LBL_PUBLISHED_SOURCES'=>'Sources publi�es:',
'LBL_UNPUBLISH'=>'non-publi�',
'LBL_NEXT'=>'Suivant >',
'LBL_BACK'=>'< Retour',
'LBL_STEP_2_TITLE'=>"Etape 2: Uploader le fichier d'export",
'LBL_HAS_HEADER'=>'A comme en-t�te:',

'LBL_NUM_1'=>'1.',
'LBL_NUM_2'=>'2.',
'LBL_NUM_3'=>'3.',
'LBL_NUM_4'=>'4.',
'LBL_NUM_5'=>'5.',
'LBL_NUM_6'=>'6.',
'LBL_NUM_7'=>'7.',
'LBL_NUM_8'=>'8.',
'LBL_NUM_9'=>'9.',
'LBL_NUM_10'=>'10.',
'LBL_NUM_11'=>'11.',
'LBL_NUM_12'=>'12.',
'LBL_NOW_CHOOSE'=>'Maintenant, choisir le fichier � importer:',
'LBL_IMPORT_OUTLOOK_TITLE'=>'Microsoft Outlook 98 et 2000 peuvent exporter des donn�es au format <b>s�parateur : Virgule </b> qui peut �tre utilis� pour importer les donn�es dans le syst�me. Pour exporter vos donn�es depuis Outlook, suivre les �tapes suivantes :',
'LBL_OUTLOOK_NUM_1'=>'D�marrer <b>Outlook</b>',
'LBL_OUTLOOK_NUM_2'=>'Selectionner le menu <b>Fichier</b> , et le sous-menu <b>Import et Export ...</b> ',
'LBL_OUTLOOK_NUM_3'=>'Choisir <b>Exporter vers un fichier</b> et cliquer sur suivant',
'LBL_OUTLOOK_NUM_4'=>"Choisir <b>S�parateur Virgule (Windows)</b> et cliquer sur <b>Suivant</b>.<br>  Remarque: Il peut vous etre demand� d'installer le composant d'export",
'LBL_OUTLOOK_NUM_5'=>'Selectionner le r�pertoire <b>Contacts</b> et cliquer sur <b>Suivant</b>. Vous pouvez s�lectionner diff�rents r�pertoires contacts si vos contacts sont stock�s dans de multiples r�pertoires.',
'LBL_OUTLOOK_NUM_6'=>'Choisir uu nom de fichier et cliquer sur <b>Suivant</b>',
'LBL_OUTLOOK_NUM_7'=>'Cliquer sur <b>Terminer</b>',
'LBL_IMPORT_ACT_TITLE'=>'Act! peut exporter des donn�es au format <b>s�parateur : Virgule</b> qui peut �tre utilis� pour importer les donn�es dans le syst�me. Pour exporter vos donn�es depuis Act!, suivre les �tapes suivantes :',
'LBL_ACT_NUM_1'=>'Lancer <b>ACT!</b>',
'LBL_ACT_NUM_2'=>"Selectionner le menu <b>Fichier</b> , le sous-menu <b>Data Exchange</b> , puis l'option <b>Exporter...</b>",
'LBL_ACT_NUM_3'=>'Selectionner le fichier de type <b>Delimiteur-Texte</b>',
'LBL_ACT_NUM_4'=>'Choisir un nom de fichier et le r�pertoire ou stocker les donn�es export�es et cliquer sur <b>Suivant</b>',
'LBL_ACT_NUM_5'=>'Selectionner <b>Enregistrements des contacts seulement</b>',
'LBL_ACT_NUM_6'=>'Cliquer sur le bouton <b>Options...</b> ',
'LBL_ACT_NUM_7'=>'Selectionner la <b>Virgule</b> en tant que caract�re de s�paration de champs',
'LBL_ACT_NUM_8'=>'Cocher la case <b>Oui, exporter les noms des champs</b> et cliquer sur <b>OK</b>',
'LBL_ACT_NUM_9'=>'Cliquer sur <b>Suivant</b>',
'LBL_ACT_NUM_10'=>'Selectionner <b>Touts les enregistrements</b> et cliquer sur  <b>Terminer</b>',

'LBL_IMPORT_SF_TITLE'=>'Salesforce.com peut exporter des donn�es au format <b>s�parateur : Virgule</b> qui peut �tre utilis� pour importer les donn�es dans le syst�me. Pour exporter vos donn�es depuis Salesforce.com, suivre les �tapes suivantes :',
'LBL_SF_NUM_1'=>"Ouvrir votre navigateur, saisir l'url http://www.salesforce.com, et s'identifier",
'LBL_SF_NUM_2'=>"Cliquer sur l'onglet <b>Rapports</b> dans le menu sup�rieur",
'LBL_SF_NUM_3'=>'Pour exporter les comptes:</b> Cliquer sur le lien <b>Comptes actifs</b> <br><b>Pour exporter les Contacts:</b> Cliquer sur le lien <b>Mailing List</b>',
'LBL_SF_NUM_4'=>'<b>Etape 1: Selectionner votre type de rapport</b>, selectionner <b>Tabular Report</b>cliquer sur <b>Suivant</b>',
'LBL_SF_NUM_5'=>'<b>Etape 2: Selectionner les colonnes du rapport </b>, choisir les colonnes que vous souhaitez exporter et cliquer sur <b>Suivant</b>',
'LBL_SF_NUM_6'=>'<b>Etape 3: Selectionner les informations � r�sumer</b>, cliquer sur <b>Suivant</b>',
'LBL_SF_NUM_7'=>'<b>Etape 4: Ordonner les colonnes du rapports</b>, puis cliquer sur <b>Suivant</b>',
'LBL_SF_NUM_8'=>'<b>Etape 5: Selectionner les crit�res de votre rapport</b>, pour le champ <b>Date de d�marrage</b>, choisir une date suffisamment �loign�e pour inclure tous vos comptes. Vous pouvez aussi exporter une sous selection de ce rapport en utilisant de multiples crit�res. Une fois termin�, cliquer sur <b>Lancer le rapport</b>',
'LBL_SF_NUM_9'=>"Un rapport sera g�n�r�, et l'�cran doit pr�senter <b>Etat de la g�n�ration du rapport: Termin�.</b> Maintenant cliquer sur <b>Exporter vers Excel</b>",
'LBL_SF_NUM_10'=>"Dans <b>Export du rapport:</b>, pour <b>Format de fichier d'export:</b>, choisir <b>D�limiteur Virgule .csv</b>. Cliquer sur <b>Exporter</b>.",
'LBL_SF_NUM_11'=>"Une boite de dialogue va apparaitre vous demandant de sauvegarder le fichier d'export sur votre machine.",
'LBL_IMPORT_CUSTOM_TITLE'=>"De nombreuses applications vous permettrons d'exporter des donn�es au format <b>Fichier texte, d�limiteur : Virgule (.csv)</b>. G�n�ralement, beaucoup d'applications suivent ces diff�rentes �tapes:",
'LBL_CUSTOM_NUM_1'=>"Lancer l'application et ouvrir le fichier de donn�es",
'LBL_CUSTOM_NUM_2'=>'Selectionner le menu <b>Enregistrer sous...</b> ou <b>Exporter...</b> ',
'LBL_CUSTOM_NUM_3'=>'Sauvegarder le fichier dans un format <b>CSV</b> ou <b>S�parateur Virgule</b> ',

'LBL_STEP_3_TITLE'=>'Etape 3: Confirmer les champs et importer',

'LBL_SELECT_FIELDS_TO_MAP'=>"Dans la liste ci-dessous, selectionner les champs dans votre fichier d'import que vouu souhaitez importer dans chaque champs du syst�me. Lorsque c'est termin�, cliquer sur <b>Importer Maintenant</b>:",

'LBL_DATABASE_FIELD'=>'Champ de la base',
'LBL_HEADER_ROW'=>"Ligne d'en-t�te",
'LBL_ROW'=>'Ligne',
'LBL_SAVE_AS_CUSTOM'=>'Sauvegarder un mapping personnalis�:',
'LBL_CONTACTS_NOTE_1'=>'Soit le nom ou le pr�nom doivent �tre mapp�s.',
'LBL_CONTACTS_NOTE_2'=>'Si le Nom complet est mapp�, Nom et pr�nom seront ignor�s.',
'LBL_CONTACTS_NOTE_3'=>"Si le Nom complet est mapp�, les informations du champ Nom Complet seront r�parties dans les champs Nom et Pr�nom lors de l'insertion dans la base.",
'LBL_CONTACTS_NOTE_4'=>"Les champs Adresse 2 et Adresse 3 sont concat�n�s ensemble avec le champ adresse principale lors de l'insertion dans la base de donn�es.",
'LBL_ACCOUNTS_NOTE_1'=>'Le nom du compte doit �tre mapp�.',
'LBL_ACCOUNTS_NOTE_2'=>"Les champs Adresse 2 et Adresse 3 sont concat�n�s ensemble avec le champ adresse principale lors de l'insertion dans la base de donn�es.",
'LBL_IMPORT_NOW'=>'Importer Maintenant',
'LBL_'=>'',
'LBL_'=>'',
'LBL_CANNOT_OPEN'=>"Impossible d'ouvrir le fichier import� en lecture.",
'LBL_NOT_SAME_NUMBER'=>"Il n'y a pas le m�me nombre de champs par ligne dans votre fichier",
'LBL_NO_LINES'=>"Aucune ligne dans votre fichier d'import",
'LBL_FILE_ALREADY_BEEN_OR'=>"Le fichier d'import � d�j� � �t� utilis� ou n'existe pas",
'LBL_SUCCESS'=>'Termin� avec succ�s:',
'LBL_SUCCESSFULLY'=>'Import r�ussi',
'LBL_LAST_IMPORT_UNDONE'=>"Votre dernier import n'a pas �t� valid�",
'LBL_NO_IMPORT_TO_UNDO'=>"Il n'y a pas d'import � annuler.",
'LBL_FAIL'=>'Echec:',
'LBL_RECORDS_SKIPPED'=>'Enregistrement ignor�',
'LBL_IDS_EXISTED_OR_LONGER'=>"identifiants qui n'existent pas ou sont plus long que les 36 caract�res utilis�s",
'LBL_RESULTS'=>'R�sultats',
'LBL_IMPORT_MORE'=>'Importer encore',
'LBL_FINISHED'=>'Termin�',
'LBL_UNDO_LAST_IMPORT'=>'Annuler le dernier import',



);

$mod_list_strings = Array(
'contacts_import_fields' => Array(
	"id"=>"Contact ID"
	,"first_name"=>"Pr�nom"
	,"last_name"=>"Nom"
	,"salutation"=>"Salutation"
	,"lead_source"=>"Source du Lead"
	,"birthdate"=>"date de naissance"
	,"do_not_call"=>"Ne pas appeler"
	,"email_opt_out"=>"Email Opt Out"
	,"primary_address_street_2"=>"Adresse principale 2"
	,"primary_address_street_3"=>"Adresse principale 3"
	,"alt_address_street_2"=>"Autre Adresse 2"
	,"alt_address_street_3"=>"Autre Adresse 3"
	,"full_name"=>"Nom cmplet"
	,"account_name"=>"Nom du compte"
	,"account_id"=>"ID du compte"
	,"title"=>"Titre"
	,"department"=>"D�partement"
	,"birthdate"=>"Date anniverssaire"
	,"do_not_call"=>"Ne pas appeler"
	,"phone_home"=>"T�l�phone (Maison)"
	,"phone_mobile"=>"T�l�phone (Mobile)"
	,"phone_work"=>"T�l�phone (Bureau)"
	,"phone_other"=>"T�l�phone (Autre)"
	,"phone_fax"=>"Fax"
	,"email1"=>"Email"
	,"email2"=>"Email (Autre)"
	,"yahoo_id"=>"Yahoo! ID"
	,"assistant"=>"Assistant(e)"
	,"assistant_phone"=>"T�l�phone Assistant(e) "
	,"primary_address_street"=>"Adresse principale"
	,"primary_address_city"=>"Adresse principale de la ville "
	,"primary_address_state"=>"Etat"
	,"primary_address_postalcode"=>"Code postal"
	,"primary_address_country"=>"Pays"
	,"alt_address_street"=>"Autre adresse"
	,"alt_address_city"=>"Autre Ville"
	,"alt_address_state"=>"Autre �tat"
	,"alt_address_postalcode"=>"Autre code postal"
	,"alt_address_country"=>"Autre Pays"
	,"description"=>"D�scription"

	),

'accounts_import_fields' => Array(
	"id"=>"ID du compte",
	"name"=>"Nom du compte",
	"website"=>"Site web",
	"industry"=>"Secteur",
	"type"=>"Type",
	"ticker_symbol"=>"Symbol du Ticker",
	"parent_name"=>"Membre de",
	"employees"=>"Employ�s",
	"ownership"=>"Propri�taire",
	"phone_office"=>"T�l�phone",
	"phone_fax"=>"Fax",
	"phone_alternate"=>"Autre T�l�phone",
	"email1"=>"Email",
	"email2"=>"Autre Email",
	"rating"=>"Note",
	"sic_code"=>"Code APE",
	"annual_revenue"=>"Revenu annuel",
	"billing_address_street"=>"Adresse de facturation",
	"billing_address_street_2"=>"Adresse de facturation 2",
	"billing_address_street_3"=>"Adresse de facturation 3",
	"billing_address_street_4"=>"Adresse de facturation 4",
	"billing_address_city"=>"Ville (facturation)",
	"billing_address_state"=>"Etat (facturation)",
	"billing_address_postalcode"=>"Code postal (facturation)",
	"billing_address_country"=>"pays (facturation)",
	"shipping_address_street"=>"Adresse de livraison",
	"shipping_address_street_2"=>"Adresse de livraison 2",
	"shipping_address_street_3"=>"Adresse de livraison 3",
	"shipping_address_street_4"=>"Adresse de livraison 4",
	"shipping_address_city"=>"Ville (livraison)",
	"shipping_address_state"=>"Etat (Livraison)",
	"shipping_address_postalcode"=>"Code Postal (Livraison)",
	"shipping_address_country"=>"Pays (Livraison)",
	"description"=>"Description"
	)

);

?>
