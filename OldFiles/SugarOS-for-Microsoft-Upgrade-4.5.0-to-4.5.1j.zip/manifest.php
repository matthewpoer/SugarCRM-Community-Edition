<?php
// created: 2008-03-24 11:45:58
$manifest = array (
  'acceptable_sugar_flavors' => 
  array (
    0 => 'OS',
  ),
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '4\\.5\\.0',
    ),
  ),
  'author' => 'SugarCRM, Inc.',
  'copy_files' => 
  array (
    'from_dir' => 'SugarOS-for-Microsoft-Upgrade-4.5.0-to-4.5.1j',
    'to_dir' => '',
    'force_copy' => 
    array (
    ),
  ),
  'description' => '',
  'icon' => '',
  'is_uninstallable' => false,
  'offline_client_applicable' => true,
  'name' => 'SugarOS',
  'published_date' => '2008-03-24 11:45:58',
  'type' => 'patch',
  'version' => '4.5.1j',
);
?>
