<?php
 if(!defined('sugarEntry'))define('sugarEntry', true);
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Community License Version
 * 1.0 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/S-CL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

require_once('include/JSON.php');
require_once('include/entryPoint.php');
require_once('include/utils.php');

$json = getJSONobj();
$file_name = $json->decode(html_entity_decode($_REQUEST['file_name']));
if(isset($file_name['jsonObject']) && $file_name['jsonObject'] != null){
    $file_name = $file_name['jsonObject'];
}else{
    echo 'empty';
    exit();
}
$forQuotes = $json->decode(html_entity_decode($_REQUEST['forQuotes']));
if($forQuotes){
	$add="_quotes";
}else{
	$add="";
}
$img_size = getimagesize($file_name);
$filetype = $img_size['mime'];
if(($filetype != 'image/jpeg' && $filetype != 'image/png') ||  ($filetype != 'image/jpeg' && $forQuotes)){
	$filetype='other';
}
else{
	$test=$img_size[0]/$img_size[1];

	if (($test>10 || $test<1) && !$forQuotes){
		$filetype='size';
	}
	if (($test>20 || $test<3)&& $forQuotes){
		$filetype='size';
	}
		
}
if (!empty($filetype)) {
    echo $filetype.$add;
}
sugar_cleanup();
exit();
?>
