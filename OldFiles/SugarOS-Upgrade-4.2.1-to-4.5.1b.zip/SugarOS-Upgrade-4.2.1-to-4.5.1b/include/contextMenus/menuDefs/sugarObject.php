<?php

global $app_strings;

$menuDef['sugarObject'] = array(
    array('text' => 'LBL_ADD_TO_FAVORITES', 
          'action' => 'SUGAR.contextMenu.addToFavorites'),
    );

?>
