<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Users/language/en_us.lang.php,v 1.5 2004/08/03 08:58:01 sugarclint Exp $
 * Description:  Defines the English language pack for the Account module.
 ********************************************************************************/

$mod_strings = Array(
'LBL_MODULE_NAME'=>'Utenti',
'LBL_MODULE_TITLE'=>'Utenti: Home',
'LBL_SEARCH_FORM_TITLE'=>"Cerca Utenti",
'LBL_LIST_FORM_TITLE'=>'Elenco Utenti',
'LBL_NEW_FORM_TITLE'=>'Nuovo Utente',
'LBL_USER'=>'Utenti:',
'LBL_LOGIN'=>'Login',

'LBL_LIST_NAME'=>'Nome',
'LBL_LIST_LAST_NAME'=>'Nome',
'LBL_LIST_USER_NAME'=>"Nome utente",
'LBL_LIST_DEPARTMENT'=>'Dipartimento',
'LBL_LIST_EMAIL'=>'Email',
'LBL_LIST_PRIMARY_PHONE'=>'Telefono Principale',
'LBL_LIST_ADMIN'=>'Admin',

'LBL_NEW_USER_BUTTON_TITLE'=>'Nuovo Utente [Alt+N]',
'LBL_NEW_USER_BUTTON_LABEL'=>'Nuovo Utente',
'LBL_NEW_USER_BUTTON_KEY'=>'N',

'LBL_ERROR'=>'Errore:',
'LBL_PASSWORD'=>'Password:',
'LBL_USER_NAME'=>"Nome utente:",
'LBL_FIRST_NAME'=>'Nome:',
'LBL_LAST_NAME'=>'Cognome:',
'LBL_YAHOO_ID'=>'Identificativo Yahoo messenger:',
'LBL_USER_SETTINGS'=>'Parametri Utente',
'LBL_THEME'=>'Tema:',
'LBL_LANGUAGE'=>'Linguaggio:',
'LBL_ADMIN'=>'Admin:',
'LBL_USER_INFORMATION'=>'Informazioni Utente',
'LBL_OFFICE_PHONE'=>'Telefono ufficio:',
'LBL_REPORTS_TO'=>'Riporta a',
'LBL_OTHER_PHONE'=>'Altro Telefono:',
'LBL_OTHER_EMAIL'=>'Altra Email:',
'LBL_NOTES'=>'Note:',
'LBL_DEPARTMENT'=>'Dipartimento:',
'LBL_STATUS'=>'Stato:',
'LBL_TITLE'=>'Titolo',
'LBL_ANY_PHONE'=>'Telefono alternativo:',
'LBL_ANY_EMAIL'=>'Email alternativo:',
'LBL_ADDRESS'=>'Indirizzo:',
'LBL_CITY'=>'Città:',
'LBL_STATE'=>'Stato/Provincia:',
'LBL_POSTAL_CODE'=>'C.A.P.:',
'LBL_COUNTRY'=>'Nazione:',
'LBL_NAME'=>'Nome:',
'LBL_USER_SETTINGS'=>'Parametri Utente',
'LBL_USER_INFORMATION'=>'Informazioni Utente',
'LBL_MOBILE_PHONE'=>'Telefono Cellulare:',
'LBL_OTHER'=>'Altro:',
'LBL_FAX'=>'Fax:',
'LBL_EMAIL'=>'Email:',
'LBL_HOME_PHONE'=>'Telefono Personale:',
'LBL_ADDRESS_INFORMATION'=>"Informazioni sull'indirizzo",
'LBL_PRIMARY_ADDRESS'=>'Indirizzo principale:',

'LBL_CHANGE_PASSWORD_BUTTON_TITLE'=>'Cambia Password [Alt+P]',
'LBL_CHANGE_PASSWORD_BUTTON_KEY'=>'P',
'LBL_CHANGE_PASSWORD_BUTTON_LABEL'=>'Cambia Password',
'LBL_LOGIN_BUTTON_TITLE'=>'Login [Alt+L]',
'LBL_LOGIN_BUTTON_KEY'=>'L',
'LBL_LOGIN_BUTTON_LABEL'=>'Login',

'LBL_CHANGE_PASSWORD'=>'Cambia Password',
'LBL_OLD_PASSWORD'=>'Password Attuale:',
'LBL_NEW_PASSWORD'=>'Password Nuova:',
'LBL_CONFIRM_PASSWORD'=>'Conferma Nuova Password:',
'ERR_ENTER_OLD_PASSWORD'=>'Per favore inserisci la password attuale.',
'ERR_ENTER_NEW_PASSWORD'=>'Per favore inserisci la password nuova.',
'ERR_ENTER_CONFIRMATION_PASSWORD'=>'Per favore conferma la password nuova.',
'ERR_REENTER_PASSWORDS'=>'Per favore reinserisci la password.  La \"nuova password\" e la \"vecchia password\" non corrispondono.',
'ERR_INVALID_PASSWORD'=>"Devi specificare un nome utente e una password valide.",
'ERR_PASSWORD_CHANGE_FAILED_1'=>'Cambio passwoer utente non riuscito per ',
'ERR_PASSWORD_CHANGE_FAILED_2'=>' fallito. Deve essere inserita la nuova password',
'ERR_PASSWORD_INCORRECT_OLD'=>'Password vecchia non esatta per l\'utente $this->user_name. Reinserire.',
'ERR_USER_NAME_EXISTS_1'=>'Nome Utente ',
'ERR_USER_NAME_EXISTS_2'=>' gia presente. Nomi Utente duplicati non sono ammessi.<br>Modificare il Nome Utente.',
'ERR_LAST_ADMIN_1'=>'Il nome utente ',
'ERR_LAST_ADMIN_2'=>' è l\'ultimo utente amministratore.  Ci deve essere almeno un utente amministrativo.<br>Verifica le impostazioni di Amministrazione.',

'LNK_NEW_CONTACT'=>'Nuovo Contatto',
'LNK_NEW_ACCOUNT'=>'Nuovo Cliente',
'LNK_NEW_OPPORTUNITY'=>'Nuova Opportunità',
'LNK_NEW_CASE'=>'Nuovo Ticket Supporto',
'LNK_NEW_NOTE'=>'Nuova Nota',
'LNK_NEW_CALL'=>'Nuova Chiamata',
'LNK_NEW_EMAIL'=>'Nuova Email',
'LNK_NEW_MEETING'=>'Nuova Riunione',
'LNK_NEW_TASK'=>'Nuovo Task',
'ERR_DELETE_RECORD'=>"Devi specificare un numero record per eliminare l'utenza.",

'LBL_RESET_PREFERENCES'=>'*Reset To Default Preferences',
);

?>