<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Meetings/language/en_us.lang.php,v 1.10 2004/08/03 09:48:28 sugarclint Exp $
 * Description:  Defines the English language pack for the Account module.
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_MODULE_NAME'=>'Riunioni',
'LBL_MODULE_TITLE'=>'Riunioni: Home',
'LBL_SEARCH_FORM_TITLE'=>'Cerca Riunione',
'LBL_LIST_FORM_TITLE'=>'Elenco Riunioni',
'LBL_NEW_FORM_TITLE'=>'Pianifica una riunione',

'LBL_LIST_SUBJECT'=>'soggetto',
'LBL_LIST_CONTACT'=>'Nome Contatto',
'LBL_LIST_RELATED_TO'=>'Relativo a ',
'LBL_LIST_DATE'=>'Data d\'inizio',
'LBL_LIST_TIME'=>'Ora d\'inizio',

'LBL_SUBJECT'=>'soggetto:',
'LBL_STATUS'=>'Stao:',
'LBL_LOCATION'=>'Località:',
'LBL_DATE_TIME'=>'Data & Ora di inizio:',
'LBL_DATE'=>'Data d\'inizio:',
'LBL_TIME'=>'Ora d\'inizio:',
'LBL_DURATION'=>'Durata:',
'LBL_HOURS_MINS'=>'(ore/minuti)',
'LBL_SUBJECT'=>'soggetto: ',
'LBL_CONTACT_NAME'=>'Nome Contatto: ',
'LBL_MEETING'=>'Riunione:',
'LBL_DESCRIPTION_INFORMATION'=>'Descrizione ',
'LBL_DESCRIPTION'=>'Descrizione:',
'LBL_COLON'=>':',
'LBL_DEFAULT_STATUS'=>'Pianificata',

'LNK_NEW_CONTACT'=>'Nuovo Contatto',
'LNK_NEW_ACCOUNT'=>'Nuovo Cliente',
'LNK_NEW_OPPORTUNITY'=>'Nuova Opportunità',
'LNK_NEW_CASE'=>'Nuovo Ticket Supporto',
'LNK_NEW_NOTE'=>'Nuova Nota',
'LNK_NEW_CALL'=>'Nuova Chiamata',
'LNK_NEW_EMAIL'=>'Nuova Email',
'LNK_NEW_MEETING'=>'Nuova Riunione',
'LNK_NEW_TASK'=>'Nuovo Task',
'ERR_DELETE_RECORD'=>"Devi specificare un numero record per eliminare il cliente.",

//New to SugarCRM 1.1c.  Still need to be translated.
'LBL_LIST_CLOSE'=>'Chiudi',
'NTC_REMOVE_INVITEE'=>'Sei sicuro di voler rimuovere questo invitato dalla riunione?',
'LBL_INVITEE'=>'Invitati',
);

?>