<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Opportunities/language/en_us.lang.php,v 1.10 2004/08/03 07:43:19 sugarclint Exp $
 * Description:  Defines the English language pack for the Account module.
 ********************************************************************************/

$mod_strings = Array(
'LBL_MODULE_NAME'=>'Opportunità',
'LBL_MODULE_TITLE'=>'Opportunità: Accueil',
'LBL_SEARCH_FORM_TITLE'=>'Cerca Opportunità',
'LBL_LIST_FORM_TITLE'=>'Elenco Opportunità',
'LBL_OPPORTUNITY_NAME'=>"Nome Opportunità:",
'LBL_OPPORTUNITY'=>'Opportunità:',
'LBL_NAME'=>"Nome Opportunità",

'LBL_LIST_OPPORTUNITY_NAME'=>'Opportunità',
'LBL_LIST_ACCOUNT_NAME'=>'Nome Cliente',
'LBL_LIST_AMOUNT'=>'Valore',
'LBL_LIST_DATE_CLOSED'=>'Data di Chiusura',
'LBL_LIST_SALES_STAGE'=>'Fase di Vendita',

'LBL_OPPORTUNITY_NAME'=>"Nome Opportunità:",
'LBL_ACCOUNT_NAME'=>'Nome Cliente:',
'LBL_AMOUNT'=>'Valore:',
'LBL_DATE_CLOSED'=>'data chiusura:',
'LBL_TYPE'=>'Tipo:',
'LBL_NEXT_STEP'=>'prossimo passo:',
'LBL_LEAD_SOURCE'=>'Fonte del Lead:',
'LBL_SALES_STAGE'=>'Fase di Vendita:',
'LBL_PROBABILITY'=>'Probabilità(%):',
'LBL_DESCRIPTION'=>'Descrizione:',

'LNK_NEW_CONTACT'=>'Nuovo Contatto',
'LNK_NEW_ACCOUNT'=>'Nuovo Cliente',
'LNK_NEW_OPPORTUNITY'=>'Nuova Opportunità',
'LNK_NEW_CASE'=>'Nuovo Ticket Supporto',
'LNK_NEW_NOTE'=>'Nuova Nota',
'LNK_NEW_CALL'=>'Nuova Chiamata',
'LNK_NEW_EMAIL'=>'Nuova Email',
'LNK_NEW_MEETING'=>'Nuova Riunione',
'LNK_NEW_TASK'=>'Nuovo Task',
'ERR_DELETE_RECORD'=>"Devi specificare un numero record per eliminare l'opportunità.",

'LBL_TOP_OPPORTUNITIES'=>"Migliori Opportunità",

'LBL_INVITEE'=>'*Contacts',
'NTC_REMOVE_OPP_CONFIRMATION'=>'*Are you sure you want to remove this contact from this opportunity?',
);

?>