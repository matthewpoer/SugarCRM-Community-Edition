-- ORACLE upgrade script for Sugar 5.0.0 to 5.1.0RC

--
-- TABLES modified from 500 to 510RC
--
-- import maps
ALTER TABLE IMPORT_MAPS MODIFY(name VARCHAR2(254));
ALTER TABLE IMPORT_MAPS ADD(enclosure VARCHAR2(1) DEFAULT '' NOT NULL);
ALTER TABLE IMPORT_MAPS ADD(delimiter VARCHAR2(1)  DEFAULT ',' NOT NULL);
ALTER TABLE IMPORT_MAPS ADD(default_values BLOB);
ALTER TABLE users_last_import add (import_module VARCHAR2(36)  NULL);

ALTER TABLE accounts modify account_type VARCHAR2(50) NULL;
ALTER TABLE accounts modify industry VARCHAR2(50) NULL ;

-- emails changes
ALTER TABLE EMAILS ADD flagged NUMBER(1,0) NULL;
ALTER TABLE EMAILS ADD reply_to_status NUMBER(1,0) NULL;
ALTER TABLE EMAILS_TEXT ADD reply_to_addr VARCHAR2(255)  NULL;

-- ALTER TABLE fields_meta_data  modify default_value VARCHAR2(255) NULL ;
ALTER TABLE fields_meta_data add (importable VARCHAR2(255)  NULL) ;

-- inbound email  to do
ALTER TABLE INBOUND_EMAIL ADD(mailbox_temp CLOB);
UPDATE INBOUND_EMAIL SET mailbox_temp = mailbox;
ALTER TABLE INBOUND_EMAIL DROP COLUMN mailbox;
ALTER TABLE INBOUND_EMAIL RENAME COLUMN mailbox_temp TO mailbox;

-- project task
ALTER TABLE project_task add status varchar(255)  NULL;
ALTER TABLE project_task add order_number NUMBER  default '1';
ALTER TABLE project_task add task_number NUMBER  default NULL;
ALTER TABLE project_task add estimated_effort NUMBER default NULL;
ALTER TABLE project_task add utilization NUMBER default '100';

-- tracker table changes
ALTER TABLE tracker add monitor_id VARCHAR2(36) NULL;
ALTER TABLE tracker add team_id VARCHAR2(36) NULL;
ALTER TABLE tracker add deleted NUMBER(1,0) DEFAULT '0' NULL;
ALTER TABLE tracker modify (session_id VARCHAR2(36));
CREATE INDEX "idx_tracker_monitor_id" ON tracker (monitor_id);

ALTER TABLE saved_reports modify(name varchar2(255));


CREATE TABLE REPORT_CACHE (
  ID varchar2(36) NOT NULL,
  assigned_user_id varchar2(36) NOT NULL,
  contents clob,
  deleted varchar2(1) default '' NOT NULL ,
  date_entered date NOT NULL,
  date_modified date NOT NULL,
  report_options clob default NULL,
  PRIMARY KEY  (ID,assigned_user_id,deleted)
);

CREATE TABLE calls_leads (
    id varchar2(36)  NOT NULL ,
    call_id varchar2(36)  NULL ,
    lead_id varchar2(36)  NULL ,
    required varchar2(1)  DEFAULT '1' NULL ,
    accept_status varchar2(25)  DEFAULT 'none' NULL ,
    date_modified date  NULL ,
    deleted NUMBER(1,0) DEFAULT '0' NOT NULL  ,
    PRIMARY KEY (id)
);
CREATE INDEX idx_lead_call_call ON calls_leads(call_id);
CREATE INDEX idx_lead_call_lead ON calls_leads(lead_id);
CREATE INDEX idx_call_lead ON calls_leads(call_id, lead_id);


CREATE TABLE meetings_leads (
    id varchar2(36)  NOT NULL ,
    meeting_id varchar2(36)  NULL ,
    lead_id varchar2(36)  NULL ,
    required varchar2(1)  DEFAULT '1' NULL ,
    accept_status varchar2(25)  DEFAULT 'none' NULL ,
    date_modified date NULL ,
    deleted NUMBER(1,0) DEFAULT '0' NOT NULL  ,
    PRIMARY KEY (id)
);
CREATE INDEX idx_lead_meeting_meeting ON meetings_leads(meeting_id);
CREATE INDEX idx_lead_meeting_lead ON meetings_leads(lead_id);
CREATE INDEX idx_meeting_lead ON meetings_leads(meeting_id, lead_id);


CREATE TABLE TRACKER_PERF (
  ID NUMBER NOT NULL ENABLE,
  monitor_id varchar2(36) NOT NULL,
  server_response_time NUMBER(30,10) default NULL,
  db_round_trips NUMBER default NULL,
  files_opened NUMBER default NULL,
  memory_usage number default NULL,
  DELETED NUMBER(1,0) DEFAULT '0',
  date_modified date,
  CONSTRAINT "trackerperfPK" PRIMARY KEY ("ID") ENABLE
);
CREATE INDEX  "idx_tracker_perf_mon_id" ON  tracker_perf (monitor_id);
CREATE SEQUENCE "TRACKER_PERF_ID_SEQ";
--
-- Table structure for table tracker_queries
--

CREATE TABLE TRACKER_QUERIES (
  ID NUMBER NOT NULL enable,
  query_id VARCHAR2(36) NOT NULL,
  text CLOB,
  query_hash varchar2(36) default NULL,
  sec_total number(30,10) default NULL,
  sec_avg number(30,10) default NULL,
  run_count number(30,10) default NULL,
  deleted number(1,0) default '0',
  date_modified date default NULL,
  PRIMARY KEY  (ID)
);
CREATE INDEX  "idx_tracker_queries_query_hash" ON  tracker_queries (query_hash);
CREATE SEQUENCE "TRACKER_QUERIES_ID_SEQ";
CREATE INDEX "idx_tracker_queries_query_id" ON tracker_queries (query_id);
--
-- Table structure for table tracker_sessions
--

CREATE TABLE TRACKER_SESSIONS (
  ID NUMBER NOT NULL enable,
  session_id varchar2(36) default NULL,
  date_start date default NULL,
  date_end date default NULL,
  seconds NUMBER default '0',
  client_ip varchar2(20) default NULL,
  user_id varchar2(36) default NULL,
  active NUMBER(1,0) default '1',
  round_trips NUMBER default NULL,
  deleted NUMBER(1,0) default '0',
  PRIMARY KEY  (ID)
);
CREATE INDEX  "idx_tracker_sessions_s_id" ON  tracker_sessions (session_id);
CREATE SEQUENCE "TRACKER_SESSIONS_ID_SEQ";
--
-- Table structure for table tracker_tracker_queries
--
CREATE TABLE TRACKER_TRACKER_QUERIES (
  ID NUMBER NOT NULL ENABLE,
  monitor_id varchar2(36) default NULL,
  query_id varchar2(36) default NULL,
  date_modified date default NULL,
  PRIMARY KEY  (ID)
);

CREATE INDEX  "idx_tracker_tq_monitor" ON  tracker_tracker_queries (monitor_id);
CREATE INDEX  "idx_tracker_tq_query" ON  tracker_tracker_queries (query_id);
CREATE SEQUENCE "TRACKER_TRACKER_QUERIES_ID_SEQ";
