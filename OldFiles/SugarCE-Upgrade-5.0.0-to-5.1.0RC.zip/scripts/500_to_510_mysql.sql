-- MySQL upgrade script for Sugar 5.0.0 to 5.1.0RC

--
-- TABLES modified from 500 to 510RC
--
-- import maps
ALTER TABLE `import_maps` modify column `name` varchar(254) NOT NULL,
                          add column `enclosure` varchar(1) NOT NULL default ' ',
                          add column `delimiter` varchar(1) NOT NULL default ',',
                          add column `default_values` blob;

-- emails changes
ALTER TABLE `emails` add column `flagged` bool NULL;
ALTER TABLE `emails` add column `reply_to_status` bool NULL;

ALTER TABLE `emails_text` add column `reply_to_addr` varchar(255) NULL;

-- inbound email
ALTER TABLE `inbound_email` modify column `mailbox` text NOT NULL;

-- project task
ALTER TABLE `project_task` add column `status` varchar(255)  NULL,
                           add column `order_number` int(11)  default '1',
                           add column `task_number` int(11)  default NULL,
                           add column `estimated_effort` int(11)  default NULL,
                           add column `utilization` int(11)  default '100';

-- tracker table changes
ALTER TABLE `tracker` add column `monitor_id` char(36)  NULL,



                      add column deleted tinyint(1)default '0',
                      modify column session_id varchar(36) NULL,
                      ADD  INDEX idx_tracker_monitor_id (monitor_id);


ALTER TABLE accounts   modify column account_type varchar(50)  NULL ,
                       modify column industry varchar(50)  NULL ;

ALTER TABLE users_last_import   add column import_module varchar(36)  NULL ;

-- ALTER TABLE fields_meta_data   modify column default_value varchar(255)  NULL;
ALTER TABLE fields_meta_data add column importable varchar(255)  NULL;

CREATE TABLE calls_leads (id varchar(36)  NOT NULL ,call_id varchar(36)  NULL ,lead_id varchar(36)  NULL ,required varchar(1)  DEFAULT '1' NULL ,accept_status varchar(25)  DEFAULT 'none' NULL ,date_modified datetime  NULL ,deleted bool  DEFAULT '0' NOT NULL  , PRIMARY KEY (id),   KEY idx_lead_call_call (call_id),   KEY idx_lead_call_lead (lead_id),   KEY idx_call_lead (call_id, lead_id)) CHARACTER SET utf8 COLLATE utf8_general_ci;
CREATE TABLE meetings_leads (id varchar(36)  NOT NULL ,meeting_id varchar(36)  NULL ,lead_id varchar(36)  NULL ,required varchar(1)  DEFAULT '1' NULL ,accept_status varchar(25)  DEFAULT 'none' NULL ,date_modified datetime  NULL ,deleted bool  DEFAULT '0' NOT NULL  , PRIMARY KEY (id),   KEY idx_lead_meeting_meeting (meeting_id),   KEY idx_lead_meeting_lead (lead_id),   KEY idx_meeting_lead (meeting_id, lead_id)) CHARACTER SET utf8 COLLATE utf8_general_ci;
























































































