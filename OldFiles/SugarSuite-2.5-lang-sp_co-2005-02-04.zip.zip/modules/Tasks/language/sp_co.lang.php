<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Tareas',
  'LBL_TASK' => 'Tareas: ',
  'LBL_MODULE_TITLE' => ' Tareas: Inicio',
  'LBL_SEARCH_FORM_TITLE' => ' Buscar Tareas',
  'LBL_LIST_FORM_TITLE' => ' Liusta Tareas',
  'LBL_NEW_FORM_TITLE' => ' Crear Tareas',
  'LBL_NEW_FORM_SUBJECT' => 'Asunto:',
  'LBL_NEW_FORM_DUE_DATE' => 'Fecha L�mite:',
  'LBL_NEW_FORM_DUE_TIME' => 'Hora L�mite:',
  'LBL_NEW_TIME_FORMAT' => '(24:00)',
  'LBL_LIST_CLOSE' => 'Cerrar',
  'LBL_LIST_SUBJECT' => 'Asunto',
  'LBL_LIST_CONTACT' => 'Contacto',
  'LBL_LIST_PRIORITY' => 'Priority',
  'LBL_LIST_RELATED_TO' => 'Relacionado a',
  'LBL_LIST_DUE_DATE' => 'Fecha L�mite',
  'LBL_LIST_DUE_TIME' => 'Hora L�mite',
  'LBL_SUBJECT' => 'Asunto:',
  'LBL_STATUS' => 'Estatus:',
  'LBL_DUE_DATE' => 'Fecha L�mite:',
  'LBL_DUE_TIME' => 'Due Time:',
  'LBL_PRIORITY' => 'Prioridad:',
  'LBL_COLON' => ':',
  'LBL_DUE_DATE_AND_TIME' => 'Fecha y Hora L�mite:',
  'LBL_START_DATE_AND_TIME' => 'Start Date & Time:',
  'LBL_START_DATE' => 'Start Date:',
  'LBL_START_TIME' => 'Start Time:',
  'DATE_FORMAT' => '(yyyy-mm-dd)',
  'LBL_NONE' => 'ningun',
  'LBL_CONTACT' => 'Contacto:',
  'LBL_PHONE' => 'Tel�fono:',
  'LBL_EMAIL' => 'Email:',
  'LBL_DESCRIPTION_INFORMATION' => 'Informaci�n Descriptiva',
  'LBL_DESCRIPTION' => 'Descripci�n:',
  'LBL_NAME' => 'Nombre:',
  'LBL_CONTACT_NAME' => 'Contacto: ',
  'LBL_LIST_COMPLETE' => 'Completo:',
  'LBL_LIST_STATUS' => 'Estatus:',
  'LBL_DATE_DUE_FLAG' => 'No Due Date',
  'LBL_DATE_START_FLAG' => 'No Start Date',
  'ERR_DELETE_RECORD' => 'Un numero de registro debe ser especificado para borrar el contacto.',
  'ERR_INVALID_HOUR' => 'Porfavor ingrese una hora entre 0 y 24',
  'LBL_DEFAULT_STATUS' => 'No iniciado',
  'LBL_DEFAULT_PRIORITY' => 'Medio',
  'LBL_LIST_MY_TASKS' => 'My Open Tasks',
  'LNK_NEW_CALL' => 'Crear Llamada',
  'LNK_NEW_MEETING' => 'Crear Reuni�n',
  'LNK_NEW_TASK' => 'Crear Tarea',
  'LNK_NEW_NOTE' => 'Crear Nota',
  'LNK_NEW_EMAIL' => 'Crear Email',
  'LNK_CALL_LIST' => 'Llamadas',
  'LNK_MEETING_LIST' => 'Reuni�n',
  'LNK_TASK_LIST' => 'Tareas',
  'LNK_NOTE_LIST' => 'Notas',
  'LNK_EMAIL_LIST' => 'Emails',
  'LNK_VIEW_CALENDAR' => 'Hoy',
  'LBL_CONTACT_FIRST_NAME' => 'Contact First Name',
  'LBL_CONTACT_LAST_NAME' => 'Contact Last Name',
);


?>