<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Administraci�n',
  'LBL_MODULE_TITLE' => 'Administraci�n: Inicio',
  'LBL_NEW_FORM_TITLE' => 'Crear Cuenta',
  'LNK_NEW_USER' => 'Crear Usuario',
  'ERR_DELETE_RECORD' => 'Un numero de registro debe ser seleccionado para borrar la cuenta.',
  'LBL_CONFIGURE_SETTINGS_TITLE' => 'Configurar Par�metros',
  'LBL_CONFIGURE_SETTINGS' => 'Configurar par�metros de todo el sistema',
  'LBL_UPGRADE_TITLE' => 'Actualizar',
  'LBL_UPGRADE' => 'Actualizar CRM',
  'LBL_MANAGE_USERS_TITLE' => 'Administraci�n de cuentas',
  'LBL_MANAGE_USERS' => 'Administrar cuentas y passwords',
  'LBL_ADMINISTRATION_HOME_TITLE' => 'Administrar Sistema',
  'LBL_NOTIFY_TITLE' => 'Opciones de Notificaci�n por E-mail',
  'LBL_NOTIFY_FROMADDRESS' => 'Direccion "From":',
  'LBL_MAIL_SMTPSERVER' => 'Servidor SMTP:',
  'LBL_MAIL_SMTPPORT' => 'Puerto SMTP:',
  'LBL_MAIL_SENDTYPE' => 'Agente Transferencia Correo:',
  'LBL_MAIL_SMTPUSER' => 'Usuario SMTP:',
  'LBL_MAIL_SMTPPASS' => 'Password SMTP:',
  'LBL_MAIL_SMTPAUTH_REQ' => 'Usar Autenticaci�n SMTP?',
  'LBL_NOTIFY_SEND_BY_DEFAULT' => 'Enviar notificaciones por defecto?',
  'LBL_NOTIFY_SUBJECT' => 'Asunto del E-mail:',
  'LBL_NOTIFY_ON' => 'Notificaciones activas?',
  'LBL_NOTIFY_FROMNAME' => 'Nombre "From":',
  'LBL_CURRENCY' => 'Configurar Monedas y Tasas de Cambio',
  'LBL_RELEASE' => 'Manage releases and versions',
  'LBL_LAYOUT' => 'Add, remove, change fields, and layout fields and panels across the application',
  'LBL_MANAGE_CURRENCIES' => 'Monedas',
  'LBL_MANAGE_RELEASES' => 'Releases',
  'LBL_MANAGE_LAYOUT' => 'Field Layout',
  'LBL_MANAGE_OPPORTUNITIES' => 'Oportunidades',
  'LBL_UPGRADE_CURRENCY' => 'Actualizar montos de moneda en ',
  'LBL_BACKUP' => 'Backup',
  'DESC_BACKUP' => 'Backup your Sugar application and database',
  'LBL_CUSTOMIZE_FIELDS' => 'Customize Fields',
  'DESC_CUSTOMIZE_FIELDS' => 'Customize the field labels in all the available languages',
  'LBL_DROPDOWN_EDITOR' => 'Dropdown Editor',
  'DESC_DROPDOWN_EDITOR' => 'Add, delete, or change the dropdown lists in the application',
  'LBL_IFRAME' => 'Portal',
  'DESC_IFRAME' => 'Add tabs which can display any web site',
  'LBL_BUG_TITLE' => 'Bug Tracker',
  'LBL_TIMEZONE' => 'Time Zone',
  'LBL_STUDIO_TITLE' => 'Studio',
  'LBL_CONFIGURE_TABS' => 'Configure Tabs',
  'LBL_CHOOSE_WHICH' => 'Choose which tabs are displayed system-wide',
  'LBL_DISPLAY_TABS' => 'Display Tabs',
  'LBL_HIDE_TABS' => 'Hide Tabs',
  'LBL_EDIT_TABS' => 'Edit Tabs',
  'LBL_UPGRADE_DB_TITLE' => 'Upgrade database',
  'LBL_UPGRADE_DB' => 'Update the database from version 2.0.x to 2.5 ',
  'LBL_UPGRADE_DB_BEGIN' => 'Begining Upgrade',
  'LBL_UPGRADE_DB_COMPLETE' => 'Upgrade Complete',
  'LBL_UPGRADE_DB_FAIL' => 'Upgrade Failed',
);


?>