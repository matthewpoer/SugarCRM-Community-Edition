<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Oportunidades',
  'LBL_MODULE_TITLE' => 'Oportunidades: Inicio',
  'LBL_SEARCH_FORM_TITLE' => 'Buscar Oportunidad',
  'LBL_LIST_FORM_TITLE' => 'Lista Oportunidades',
  'LBL_OPPORTUNITY_NAME' => 'Oportunidad:',
  'LBL_OPPORTUNITY' => 'Oportunidad:',
  'LBL_NAME' => 'Oportunidad',
  'LBL_INVITEE' => 'Contactos',
  'LBL_LIST_OPPORTUNITY_NAME' => 'Oportunidad',
  'LBL_LIST_ACCOUNT_NAME' => 'Cuenta',
  'LBL_LIST_AMOUNT' => 'Monto',
  'LBL_LIST_DATE_CLOSED' => 'Cerrar',
  'LBL_LIST_SALES_STAGE' => 'Estado Ventas',
  'db_sales_stage' => 'LBL_LIST_SALES_STAGE',
  'db_name' => 'LBL_NAME',
  'db_amount' => 'LBL_LIST_AMOUNT',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_date_closed' => 'LBL_LIST_DATE_CLOSED',
  'UPDATE' => 'Oportunidad - Actualziar Moneda',
  'UPDATE_DOLLARAMOUNTS' => 'Actualizar montos U.S. Dolar',
  'UPDATE_VERIFY' => 'Verificar Montos',
//END DON'T CONVERT
  'UPDATE_VERIFY_TXT' => 'Verifca que el monto en las oportunidades sea un numero decimal valido con solo caracteres numericos(0-9) y decimales(.)',
  'UPDATE_FIX' => 'Arreglar Montos',
  'UPDATE_FIX_TXT' => 'Intento arreglar cualquier monto invalido creando un decimal valido desde el monto actual. Esto copiara cualqueir monto que modifique en la base de datos, en el campo amount_backup. Si usted corre esto y nota errores, no corra de nuevo sin recuperar los datos del backup ya que podria sobreescribir el backup con datos invalidos.',
  'UPDATE_DOLLARAMOUNTS_TXT' => 'Actualziar los montos de U.S. Dollar para las oportunidades basado en las tasas de cambio actuales. Este valor es usado para calcular graficas y listar valores.',
  'UPDATE_CREATE_CURRENCY' => 'Crear Nueva Moneda:',
  'UPDATE_VERIFY_FAIL' => 'Fallo de verificaci�n de registro:',
  'UPDATE_VERIFY_CURAMOUNT' => 'Monto actual:',
  'UPDATE_VERIFY_FIX' => 'Corriendo reparaci�n',
  'UPDATE_INCLUDE_CLOSE' => 'Incluir Registros Cerrados',
  'UPDATE_VERIFY_NEWAMOUNT' => 'Nuevo Monto:',
  'UPDATE_VERIFY_NEWCURRENCY' => 'Nueva Moneda:',
  'UPDATE_DONE' => 'Hecho',
  'UPDATE_BUG_COUNT' => 'Bugs Found and Attempted to Resolve:',
  'UPDATE_BUGFOUND_COUNT' => 'Bugs Found:',
  'UPDATE_COUNT' => 'Registros Actualizados:',
  'UPDATE_RESTORE_COUNT' => 'Montos Recuperados:',
  'UPDATE_RESTORE' => 'Recuperar Montos',
  'UPDATE_RESTORE_TXT' => 'Recuperar montos del backup creado durante la reparaci�n.',
  'UPDATE_FAIL' => 'No puede actualziar - ',
  'UPDATE_NULL_VALUE' => 'Monto es NULO cambiarlo a 0 -',
  'UPDATE_MERGE' => 'Combianr Monedas',
  'UPDATE_MERGE_TXT' => 'Combinar multiples monedas en una sola moneda. Si usted nota que hay multiples registros de moneda para la misma moneda, usted puede seleccionar combinarlas. Tambien puede combinar las monedas para todos los otros modulos.',
  'LBL_ACCOUNT_NAME' => 'Cuentas:',
  'LBL_AMOUNT' => 'Monto:',
  'LBL_CURRENCY' => 'Moneda:',
  'LBL_DATE_CLOSED' => 'Fecha esperada de cierre:',
  'LBL_TYPE' => 'Tipo:',
  'LBL_NEXT_STEP' => 'Siguiente paso:',
  'LBL_LEAD_SOURCE' => 'Origen:',
  'LBL_SALES_STAGE' => 'Estado de Ventas:',
  'LBL_PROBABILITY' => 'Probabilidad (%):',
  'LBL_DESCRIPTION' => 'Descripci�n:',
  'LBL_DUPLICATE' => 'Posible Oportunidad Duplicada',
  'MSG_DUPLICATE' => 'Creando esta oportunidad puede potencialmente crear una oportunidad duplicada. Usted puede seleccionar una oportunidad de la lista o crear una nueva para continuar creandola con los datos ingresados previamente.',
  'LBL_NEW_FORM_TITLE' => 'Crear Oportunidad',
  'LNK_NEW_OPPORTUNITY' => 'Crer Oportunidad',
  'LNK_OPPORTUNITY_LIST' => 'Oportunidades',
  'ERR_DELETE_RECORD' => 'Un numero de registro debe ser especificado para borrar la oportunidad.',
  'LBL_TOP_OPPORTUNITIES' => 'Mis Principales Oportundiades Abiertas',
  'NTC_REMOVE_OPP_CONFIRMATION' => 'Esta seguro de querer remover este contacto de esta Oportunidad?',
  'UPDATE_ISSUE_COUNT' => 'Error encontrado e intento por resolverlo:',
  'UPDATE_ISSUEFOUND_COUNT' => 'Errores encontrados:',
);


?>