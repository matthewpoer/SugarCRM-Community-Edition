<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Cuentas',
  'LBL_MODULE_TITLE' => 'Cuentas: Inicio',
  'LBL_SEARCH_FORM_TITLE' => 'Buscar Cuenta',
  'LBL_LIST_FORM_TITLE' => 'Listado de Cuentas',
  'LBL_NEW_FORM_TITLE' => 'Nueva Cuenta',
  'LBL_MEMBER_ORG_FORM_TITLE' => 'Organizaciones Miembro',
  'LBL_BUG_FORM_TITLE' => 'Accounts',
  'LBL_LIST_ACCOUNT_NAME' => 'Nombre Cuenta',
  'LBL_LIST_CITY' => 'Ciudad',
  'LBL_LIST_WEBSITE' => 'Website',
  'LBL_LIST_STATE' => 'Estado',
  'LBL_LIST_PHONE' => 'Tel�fono',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email',
  'LBL_LIST_CONTACT_NAME' => 'Contacto',
  'db_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_website' => 'LBL_LIST_WEBSITE',
  'db_billing_address_city' => 'LBL_LIST_CITY',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'LBL_ACCOUNT_INFORMATION' => 'Informaci�n de la Cuenta',
  'LBL_ACCOUNT' => 'Cuenta:',
  'LBL_ACCOUNT_NAME' => 'Nombre Cuenta:',
//END DON'T CONVERT
  'LBL_PHONE' => 'Tel�fono:',
  'LBL_PHONE_ALT' => 'Alternate Phone:',
  'LBL_WEBSITE' => 'Website:',
  'LBL_FAX' => 'Fax:',
  'LBL_TICKER_SYMBOL' => 'Sigla:',
  'LBL_OTHER_PHONE' => 'Otro Tel�fono:',
  'LBL_ANY_PHONE' => 'Cualquier Tel�fono:',
  'LBL_MEMBER_OF' => 'Miembro de:',
  'LBL_PHONE_OFFICE' => 'Phone Office:',
  'LBL_PHONE_FAX' => 'Phone Fax:',
  'LBL_EMAIL' => 'Email:',
  'LBL_EMPLOYEES' => 'Empelados:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Otro Email:',
  'LBL_ANY_EMAIL' => 'Email:',
  'LBL_OWNERSHIP' => 'Due�o:',
  'LBL_RATING' => 'Puntaje:',
  'LBL_INDUSTRY' => 'Industria:',
  'LBL_SIC_CODE' => 'NIT:',
  'LBL_TYPE' => 'Tipo:',
  'LBL_ANNUAL_REVENUE' => 'Ingresos Anuales:',
  'LBL_ADDRESS_INFORMATION' => 'Direcci�n de Informaci�n',
  'LBL_BILLING_ADDRESS' => 'Direcci�n de Facturaci�n:',
  'LBL_BILLING_ADDRESS_STREET' => 'Billing Address Street:',
  'LBL_BILLING_ADDRESS_CITY' => 'Billing Address City:',
  'LBL_BILLING_ADDRESS_STATE' => 'Billing Address State:',
  'LBL_BILLING_ADDRESS_POSTALCODE' => 'Billing Address Postal Code:',
  'LBL_BILLING_ADDRESS_COUNTRY' => 'Billing Address Country:',
  'LBL_SHIPPING_ADDRESS_STREET' => 'Shipping Address Street:',
  'LBL_SHIPPING_ADDRESS_CITY' => 'Shipping Address City:',
  'LBL_SHIPPING_ADDRESS_STATE' => 'Shipping Address State:',
  'LBL_SHIPPING_ADDRESS_POSTALCODE' => 'Shipping Address Postal Code:',
  'LBL_SHIPPING_ADDRESS_COUNTRY' => 'Shipping Address Country:',
  'LBL_SHIPPING_ADDRESS' => 'Direcci�n de Env�o:',
  'LBL_DATE_MODIFIED' => 'Date Modified:',
  'LBL_DATE_ENTERED' => 'Date Entered:',
  'LBL_ANY_ADDRESS' => 'Direcci�n:',
  'LBL_CITY' => 'Ciudad:',
  'LBL_STATE' => 'Estado:',
  'LBL_POSTAL_CODE' => 'Codigo Postal:',
  'LBL_COUNTRY' => 'Pa�s:',
  'LBL_DESCRIPTION_INFORMATION' => 'Informaci�n adicional',
  'LBL_DESCRIPTION' => 'Descripci�n:',
  'NTC_COPY_BILLING_ADDRESS' => 'Copiar direcci�n de facturaci�n a direcci�n de envio',
  'NTC_COPY_SHIPPING_ADDRESS' => 'Copiar Direcci�n de envio a direcci�n de facturaci�n',
  'NTC_REMOVE_MEMBER_ORG_CONFIRMATION' => 'Esta seguro de remover este registro de las organizaciones miembro?',
  'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Are you sure you want to remove this record?',
  'LBL_DUPLICATE' => 'Posible Cuenta Duplicada',
  'MSG_SHOW_DUPLICATES' => 'Creating this contact may potentialy create a duplicate contact. You may either click on Create Account to continue creating this new account with the previously entered data or you may click Cancel.',
  'MSG_DUPLICATE' => 'Crear esta cuenta puede potencialemnte crear una cuenta duplicada. Usted puede seleccionar una cuenta de la lista sigueinte o seleccionar Crear Nueva Cuenta para continuar creando una nueva cuenta.',
  'LNK_NEW_ACCOUNT' => 'Crear Cuenta',
  'LNK_ACCOUNT_LIST' => 'Cuentas',
  'LBL_INVITEE' => 'Contactos',
  'ERR_DELETE_RECORD' => 'Un numero de registro debe ser seleccionado para borrar la cuenta.',
  'NTC_DELETE_CONFIRMATION' => 'Are you sure you want to delete this record?',
  'LBL_SAVE_ACCOUNT' => 'Save Account',
);


?>