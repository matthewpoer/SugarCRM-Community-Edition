<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Llamadas',
  'LBL_MODULE_TITLE' => 'Llamadas: Inicio',
  'LBL_SEARCH_FORM_TITLE' => 'Buscar Llamadas',
  'LBL_LIST_FORM_TITLE' => 'Lista de Llamadas',
  'LBL_NEW_FORM_TITLE' => 'Programar Llamda',
  'LBL_LIST_CLOSE' => 'Cerrar',
  'LBL_LIST_SUBJECT' => 'Asunto',
  'LBL_LIST_CONTACT' => 'Contacto',
  'LBL_LIST_RELATED_TO' => 'Relacionado a',
  'LBL_LIST_DATE' => 'Fecha Inicio',
  'LBL_LIST_TIME' => 'Hora Inicio',
  'LBL_LIST_DURATION' => 'Duraci�n',
  'LBL_LIST_DIRECTION' => 'Direcci�n',
  'LBL_SUBJECT' => 'Asunto:',
  'LBL_CONTACT_NAME' => 'Contacto:',
  'LBL_DESCRIPTION_INFORMATION' => 'Informaci�n Descriptiva',
  'LBL_DESCRIPTION' => 'Descripci�n:',
  'LBL_STATUS' => 'Estado:',
  'LBL_DIRECTION' => 'Direction:',
  'LBL_DATE' => 'Fecha Inicio:',
  'LBL_DURATION' => 'Duraci�n:',
  'LBL_DURATION_HOURS' => 'Duration Hours:',
  'LBL_DURATION_MINUTES' => 'Duration Minutes:',
  'LBL_HOURS_MINUTES' => '(houras/minutos)',
  'LBL_CALL' => 'Llamada:',
  'LBL_DATE_TIME' => 'Fecha y Hora de Inicio:',
  'LBL_TIME' => 'Hora Inicio:',
  'LBL_HOURS_ABBREV' => 'h',
  'LBL_MINSS_ABBREV' => 'm',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'Planeada',
  'LNK_NEW_CALL' => 'Crear Llamada',
  'LNK_NEW_MEETING' => 'Crear Reuni�n',
  'LNK_NEW_TASK' => 'Crear Tarea',
  'LNK_NEW_NOTE' => 'Crear Nota',
  'LNK_NEW_EMAIL' => 'Crear Email',
  'LNK_CALL_LIST' => 'Llamadas',
  'LNK_MEETING_LIST' => 'Reuniones',
  'LNK_TASK_LIST' => 'Tareas',
  'LNK_NOTE_LIST' => 'Notas',
  'LNK_EMAIL_LIST' => 'Emails',
  'LNK_VIEW_CALENDAR' => 'Hoy',
  'ERR_DELETE_RECORD' => 'Un numero de registro debe ser seleccionado para borrar la cuenta.',
  'NTC_REMOVE_INVITEE' => 'Esta usted seguro de querer remover este invitado de la llamada?',
  'LBL_INVITEE' => 'Invitados',
  'LBL_RELATED_TO' => 'Related To:',
  'LNK_NEW_APPOINTMENT' => 'Create Appointment',
);


?>