<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/cvsroot/sugarcrm/modules/iFrames/iFrame.php,v 1.6 2005/01/19 20:00:14 majed Exp $
 ********************************************************************************/
include_once('config.php');
require_once('include/logging.php');
require_once('include/database/PearDatabase.php');
require_once('data/SugarBean.php');

// Contact is used to store customer information.
class iFrame extends SugarBean 
{
	// Stored fields
	var $id;
	var $url;
	var $name;
	var $deleted;
	var $status = 1;
	var $placement='' ;
	var $date_entered;
	var $created_by;
	var $type;
	var $date_modified;
	var $table_name = "iframes";
	var $object_name = "iFrame";
	
	var $new_schema = true;

	var $column_fields = Array("id"
		,"url"
		,"name"
		,"placement"
		,'type'
		,"deleted"
		,"status"
        ,"date_entered"
        ,"date_modified"
        ,"created_by"
		);
	var $list_fields= array() ;
	
	var $field_defs = array(
		array("name"=>"name", "vname"=>"LBL_LIST_NAME","type"=>"varchar","len"=>"255"),
		array("name"=>"url", "vname"=>"LBL_LIST_URL","type"=>"varchar","len"=>"255"),
		array("name"=>"type", "vname"=>"LBL_LIST_TYPE","type"=>"varchar","len"=>"255"),
		array("name"=>"placement", "vname"=>"LBL_LIST_PLACEMENT","type"=>"varchar","len"=>"255"),
		array("name"=>"status", "vname"=>"LBL_LIST_STATUS","type"=>"bool"),
       	array('name'=>'date_entered','vname'=>'LBL_DATE_ENTERED','type'=>'date'),
       	array('name'=>'date_modified','vname'=>'LBL_DATE_MODIFIED','type'=>'date'),

	);
	var $required_fields = array('name'=>1, 'visible'=>2, 'url'=>3 , 'placement'=>4);
	

	function iFrame() 
	{
		$this->log = LoggerManager::getLogger('iFrame');
		$this->db = new PearDatabase();
		$this->list_fields = $this->column_fields;
		foreach ($this->field_defs as $field)
		{
			$this->field_name_map[$field['name']] = $field;
		}



	}
	
	function get_xtemplate_data(){
		$return_array = array();
		global $current_user;
		foreach($this->column_fields as $field)
		{
			$return_array[strtoupper($field)] = $this->$field;
		}
				if(is_admin($current_user)){
					$select = translate('DROPDOWN_PLACEMENT', 'iFrames');
					$return_array['PLACEMENT_SELECT'] = get_select_options_with_id($select, $return_array['PLACEMENT'] );
				}else{
					$select = translate('DROPDOWN_PLACEMENT', 'iFrames');
					$shortcut = array('shortcut'=> $select['shortcut']);
					$return_array['PLACEMENT_SELECT'] = get_select_options_with_id($shortcut, '');
				}
					
				if(is_admin($current_user)){
					$select = translate('DROPDOWN_TYPE', 'iFrames');
					$return_array['TYPE_SELECT'] = get_select_options_with_id($select, $return_array['TYPE'] );
				}else{
					$select = translate('DROPDOWN_TYPE', 'iFrames');
					$personal = array('personal'=> $select['personal']);
					$return_array['TYPE_SELECT'] = get_select_options_with_id($personal, '');
				}	
				if(!empty($select[$return_array['PLACEMENT']])){
					$return_array['PLACEMENT'] = $select[$return_array['PLACEMENT']];
				}
				
		return $return_array;	
	}
	
		function get_list_view_data()
	{
		$ret_array = parent::get_list_view_array();
		if(!empty($ret_array['STATUS']) && $ret_array['STATUS'] > 0){
			 $ret_array['STATUS'] = '<input type="checkbox" class="checkbox" style="checkbox" checked disabled>';
		}else{
			$ret_array['STATUS'] = '<input type="checkbox" class="checkbox" style="checkbox" disabled>'	;
		}
		$ret_array['CREATED_BY'] = get_assigned_user_name($this->created_by);
		$ret_array['PLACEMENT'] = translate('DROPDOWN_PLACEMENT', 'iFrames', $ret_array['PLACEMENT']);
				$ret_array['TYPE'] = translate('DROPDOWN_TYPE', 'iFrames', $ret_array['TYPE']);
		return $ret_array;
		
	}

	function create_tables () 
	{
		$query = 'CREATE TABLE '.$this->table_name.' ( ';
		$query .='id char(36) NOT NULL';
		$query .=', name char(255) NOT NULL';
		$query .=', url char(255) NOT NULL';
		$query .=', type char(255) NOT NULL';
		$query .=', placement char(255) NOT NULL';
		$query .= ',status bool NOT NULL default 0';
		$query .=', deleted bool NOT NULL default 0';
        $query .=', date_entered datetime NOT NULL';
        $query .=', date_modified datetime NOT NULL';
        $query .=', created_by char(36) NOT NULL';
        $query .=', PRIMARY KEY ( ID ) )';

		
		
		
		$this->db->query($query,true,"Error creating table: ".$this->table_name. ":" );


		//TODO Clint 4/27 - add exception handling logic here if the table can't be created.
	
		// Create the indexes
                $this->create_index("create index idx_cont_name on ".$this->table_name." ( name, deleted)");
	}

	function drop_tables () 
	{
		$query = 'DROP TABLE IF EXISTS '.$this->table_name;

		
			
		$this->db->query($query);

		//TODO Clint 4/27 - add exception handling logic here if the table can't be dropped.

	}
	
	function lookup_frames($placement){
			global $current_user;
			if(isset($current_user)){
				$id = $current_user->id;
			}else{
				$id = -1;	
			}
			$query = 'SELECT placement,name,id,url from '  .$this->table_name . " WHERE deleted=0 AND status=1 AND (placement='$placement' OR placement='all') AND (type='global' OR (type='personal' AND created_by='$id'));";
			$res = $this->db->query($query);
			$frames = array();
			while($row = $this->db->fetchByAssoc($res)){
				$frames[$row['name']] = array($row['id'], $row['url'], $row['placement']);
			}
			return $frames;
		
	}
        

}


?>
