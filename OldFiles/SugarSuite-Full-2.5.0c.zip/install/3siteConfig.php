<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

// $Id: 3siteConfig.php,v 1.34 2005/01/20 22:46:44 andrew Exp $

$suicide = true;
if(isset($install_script))
{
   if($install_script)
   {
      $suicide = false;
   }
}

if($suicide)
{
   // mysterious suicide note
   die('Unable to process script directly.');
}

if(isset($_SESSION['step_3_submitted']) && $_SESSION['step_3_submitted'])
{
   // restore the values submitted by the user from the session
   $setup_site_url = $_SESSION['setup_site_url'];
   $setup_site_cache_path =$_SESSION['setup_site_cache_path'];
   $setup_site_custom_session_path =$_SESSION['setup_site_custom_session_path'];
   $setup_site_session_path =$_SESSION['setup_site_session_path'];
   $setup_site_specify_guid =$_SESSION['setup_site_specify_guid'];
   $setup_site_guid =$_SESSION['setup_site_guid'];
   $setup_site_admin_password =$_SESSION['setup_site_admin_password'];
   $setup_site_admin_password_retype =$_SESSION['setup_site_admin_password_retype'];
}
else
{
   $web_root = $_SERVER['SERVER_NAME'].$_SERVER['PHP_SELF'];
   $web_root = str_replace("/install.php", "", $web_root);
   $web_root = "http://$web_root";
   $current_dir = str_replace('\install',"", dirname(__FILE__));
   $current_dir = str_replace('/install',"", $current_dir);
   $current_dir = trim($current_dir);

   require_once('config.php');

   // set the form's php var to the loaded config's var else default to sane settings

   if(isset($site_URL))
   {
      if($site_URL == '')
      {
         $setup_site_url = $web_root;
      }
      else
      {
         $setup_site_url = $site_URL;
      }
   }
   else
   {
      $setup_site_url = $web_root;
   }
   $_SESSION['$setup_site_url'] = $setup_site_url;

   if(isset($cache_dir))
   {
      $setup_site_cache_path = $cache_dir;
   }
   else
   {
      $setup_site_cache_path = $current_dir . '/cache';
   }
   $_SESSION['setup_site_cache_path'] = $setup_site_cache_path;

   $setup_site_custom_session_path = false;
   $_SESSION['setup_site_custom_session_path'] = $setup_site_custom_session_path;

   if(isset($session_dir))
   {
      $setup_site_session_path = $session_dir;
   }
   else
   {
      $setup_site_session_path = '';
   }
   $_SESSION['setup_site_session_path'] = $setup_site_session_path;

   $setup_site_specify_guid = false;
   $_SESSION['setup_site_specify_guid'] = $setup_site_specify_guid;

   if(isset($unique_key))
   {
      $setup_site_guid = $unique_key;
   }
   else
   {
      $setup_site_guid = '';
   }
   $_SESSION['setup_site_guid'] = $setup_site_guid;

   $setup_site_admin_password = '';
   $setup_site_admin_password_retype = '';
}

// should this be moved to install.php?
if (is_file("config.php"))
{
   require_once("config.php");

	if(isset($disable_persistent_connections))
		$_SESSION['disable_persistent_connections'] = $disable_persistent_connections;
	if(isset($default_language))
		$_SESSION['default_language'] = $default_language;
	if(isset($translation_string_prefix))
		$_SESSION['translation_string_prefix'] = $translation_string_prefix;
	if(isset($default_charset))
		$_SESSION['default_charset'] = $default_charset;

	if(isset($RSS_CACHE_TIME))
		$_SESSION['rss_cache_time'] = $RSS_CACHE_TIME;
	if(isset($languages))
	{
		// We need to encode the languages in a way that can be retrieved later.
		$language_keys = Array();
		$language_values = Array();

		foreach($languages as $key=>$value)
		{
			$language_keys[] = $key;
			$language_values[] = $value;
		}

		$_SESSION['language_keys'] = urlencode(implode(",",$language_keys));
		$_SESSION['language_values'] = urlencode(implode(",",$language_values));
	}
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
   <meta http-equiv="Content-Script-Type" content="text/javascript">
   <meta http-equiv="Content-Style-Type" content="text/css">
   <title>SugarCRM Setup Wizard: Step 3</title>
   <link rel="stylesheet" href="install/install.css" type="text/css" />
   <script type="text/javascript" src="install/installCommon.js"></script>
   <script type="text/javascript" src="install/3siteConfig.js"></script>
</head>
<body onload="javascript:toggleGUID();toggleSession();">
<form action="install.php" method="post" name="setConfig" id="form">
<input type="hidden" name="current_step" value="3">
<table cellspacing="0" cellpadding="0" border="0" align="center" class="shell">
<tr>
   <th width="400">Step 3: Site Configuration</th>
   <th width="200" height="30" style="text-align: right;"><a href="http://www.sugarcrm.com" target=
      "_blank"><IMG src="include/images/sugarcrm_login.png" width="120" height="19" alt="SugarCRM" border="0"></a></th>
   </tr>
<tr>
   <td colspan="2" width="600">
   <p>Please enter your site configuration information below.
      If you are unsure of the fields, we suggest that you use the default
      values.</p>
   <?php
      if(isset($validation_errors))
      {
         if(count($validation_errors) > 0)
         {
            echo '<div id="errorMsgs">';
            echo '<p>Please fix the following errors before proceeding:</p>';
            echo '<ul>';

            foreach($validation_errors as $error)
            {
               echo '<li>' . $error . '</li>';
            }

            echo '</ul>';
            echo '</div>';
         }
      }
   ?>
   <div class="required">* Required field</div>
   <table width="100%" cellpadding="0" cellpadding="0" border="0" class="StyleDottedHr">
   <tr><th colspan="3" align="left">Site Configuration</td></tr>
   <tr><td><span class="required">*</span></td>
       <td><b>URL</td>
       <td align="left"><input type="text" name="setup_site_url"
			value="<?php echo $setup_site_url; ?>" size="40" /></td></tr>
   <tr><td><span class="required">*</span></td>
       <td><b>SugarCRM <em>admin</em> password</b><br><i>Caution: This will override the admin password
				of any previous installation.</i></td>
       <td align="left"><input type="password" name="setup_site_admin_password"
                         value="<?php echo $setup_site_admin_password; ?>" size="20" /></td></tr>
   <tr><td><span class="required">*</span></td>
       <td><b>Re-type SugarCRM <em>admin</em> password</td>
       <td align="left"><input type="password" name="setup_site_admin_password_retype"
                        value="<?php echo $setup_site_admin_password_retype; ?>" size="20" /></td></tr>
   <tr><th colspan="3" align="left">Advanced Site Security</td></tr>
   <tr><td></td>
       <td><b>Use a Custom Session Directory for SugarCRM</b><br>
				<em>Provide a secure folder for storing SugarCRM session information
					to prevent session data from being vulnerable on shared servers.</em></td>
       <td><input type="checkbox" class="checkbox" name="setup_site_custom_session_path" value="yes"
                  onclick="javascript:toggleSession();"
                  <?php if($setup_site_custom_session_path) echo 'checked="checked"'; ?> /></td></tr>
   <tbody id="setup_site_session_section">
   <tr><td><span class="required">*</span></td>
       <td><b>Path to Session Directory<br>(must be writable)</td>
       <td align="left"><input type="text" name="setup_site_session_path" size='40'
                        value="<?php echo $setup_site_session_path; ?>" /></td></tr>
   </tbody>
   <tr><td></td>
       <td><b>Provide Your Own Application ID</b><br>
				<em>Override the auto-generated
				application ID that prevents sessions
				from one instance of SugarCRM from being
				used on another instance.  If you have
				a cluster of SugarCRM installations,
				they all must share the same application
				ID.</em></td>

       <td><input type="checkbox" class="checkbox" name="setup_site_specify_guid" value="yes"
                  onclick="javascript:toggleGUID();"
                  <?php if($setup_site_specify_guid) echo 'checked="checked"'; ?> /></td></tr>
   <tbody id="setup_site_guid_section">
   <tr><td><span class="required">*</span></td>
       <td><b>Application ID</td>
       <td align="left"><input type="text" name="setup_site_guid" size='30'
                        value="<?php echo $setup_site_guid; ?>" /></td></tr>
   </tbody>
</table>
</td>
</tr>
<tr>
   <td align="right" colspan="2">
   <hr>
   <table cellspacing="0" cellpadding="0" border="0" class="stdTable">
   <tr>
   <td><input class="button" type="button" onclick="window.open('http://www.sugarcrm.com/forums/');" value="Help" /></td>
   <td><input class="button" type="submit" name="goto" value="Back" /></td>
   <td><input class="button" type="submit" name="goto" value="Next" /></td>
   </tr>
   </table>
</td>
</tr>
</table>
</form>
<br>
</body>
</html>
