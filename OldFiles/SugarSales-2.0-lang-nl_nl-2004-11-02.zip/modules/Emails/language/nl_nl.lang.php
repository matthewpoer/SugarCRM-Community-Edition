<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.2 2004/10/29 15:59:25 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Emails',
  'LBL_MODULE_TITLE' => 'Emails: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Email Zoeken',
  'LBL_LIST_FORM_TITLE' => 'Email Lijst',
  'LBL_NEW_FORM_TITLE' => 'Volgen Email',
  'LBL_LIST_SUBJECT' => 'Onderwerp',
  'LBL_LIST_CONTACT' => 'Contactpersoon',
  'LBL_LIST_RELATED_TO' => 'Gerelateerd aan',
  'LBL_LIST_DATE' => 'Verzonden Datum ',
  'LBL_LIST_TIME' => 'Verzonden Tijdstip',
  'ERR_DELETE_RECORD' => 'Er moet een rcord nummerzijn gespecificeerd om dit bedrijf te verwijderen.',
  'LBL_DATE_SENT' => 'Verzonden Datum:',
  'LBL_SUBJECT' => 'Onderwerp:',
  'LBL_BODY' => 'Tekst Inhoud:',
  'LBL_DATE_AND_TIME' => 'Verzonden Datum en Tijd:',
  'LBL_DATE' => 'Verzonden Datum:',
  'LBL_TIME' => 'Verzonden Tijdstip:',
  'LBL_CONTACT_NAME' => ' Contactpersoon Naam: ',
  'LBL_EMAIL' => 'Email:',
  'LBL_COLON' => ':',
  'LNK_NEW_EMAIL' => 'Nieuwe Email',
  'LNK_EMAIL_LIST' => 'Emails',
  'NTC_REMOVE_INVITEE' => 'Weet u zeker dat u deze ontvanger wilt verwijderen van deze email?',
  'LBL_INVITEE' => 'Ontvanger(s)',
  'LNK_NEW_CALL' => 'Nieuw Telefoon Gesprek',
  'LNK_NEW_MEETING' => 'Nieuwe Afspraak',
  'LNK_NEW_TASK' => 'Nieuwe Taak',
  'LNK_NEW_NOTE' => 'Nieuwe Notitie',
  'LNK_CALL_LIST' => 'Calls',
  'LNK_MEETING_LIST' => 'Meetings',
  'LNK_TASK_LIST' => 'Tasks',
  'LNK_NOTE_LIST' => 'Notes',
  'LNK_NEW_CONTACT' => 'Nieuw Contact',
  'LNK_NEW_ACCOUNT' => 'Nieuw Bedrijf',
  'LNK_NEW_OPPORTUNITY' => 'Nieuwe Kans',
  'LNK_NEW_CASE' => 'Nieuwe Zaak',
);


?>