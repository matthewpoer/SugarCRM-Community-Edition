<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => '�renden',
  'LBL_MODULE_TITLE' => '�renden : Hem',
  'LBL_SEARCH_FORM_TITLE' => 'S�k �rende',
  'LBL_LIST_FORM_TITLE' => '�rendelista',
  'LBL_NEW_FORM_TITLE' => 'Nytt �rende',
  'LBL_CONTACT_CASE_TITLE' => 'Kontakt-�rende:',
  'LBL_SUBJECT' => '�rende:',
  'LBL_CASE' => '�rende:',
  'LBL_CASE_NUMBER' => '�rendenummer:',
  'LBL_NUMBER' => 'Nummer:',
  'LBL_STATUS' => 'Status:',
  'LBL_PRIORITY' => 'Priority:',
  'LBL_ACCOUNT_NAME' => 'F�retagsnamn:',
  'LBL_DESCRIPTION' => 'Beskrivning:',
  'LBL_RESOLUTION' => 'Resolution:',
  'LBL_CONTACT_NAME' => 'Kontakt Namn:',
  'LBL_CASE_SUBJECT' => '�renderubrik:',
  'LBL_CONTACT_ROLE' => 'Roll:',
  'LBL_LIST_NUMBER' => 'Num.',
  'LBL_LIST_SUBJECT' => 'Rubrik',
  'LBL_LIST_ACCOUNT_NAME' => 'F�retagsnamn',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_LIST_PRIORITY' => 'Priority',
  'LBL_LIST_LAST_MODIFIED' => 'Senast Uppdaterad',
  'LBL_INVITEE' => '*Contacts',
  'LNK_NEW_CASE' => 'Nytt �rende',
  'LNK_CASE_LIST' => 'Cases',
  'NTC_REMOVE_INVITEE' => '*Are you sure you want to remove this contact from the case?',
  'ERR_DELETE_RECORD' => 'Ett Post nummer m�ste anges f�r att radera F�retaget.',
  'NTC_REMOVE_FROM_BUG_CONFIRMATION' => 'Are you sure you want to remove this case from this bug?',
  'LBL_LIST_CLOSE' => 'Close',
  'LBL_LIST_MY_CASES' => 'My Open Cases',
  'LNK_NEW_CONTACT' => 'Ny Kontakt',
  'LNK_NEW_ACCOUNT' => 'Nytt F�retag',
  'LNK_NEW_OPPORTUNITY' => 'Ny Aff�r',
  'LNK_NEW_NOTE' => 'Ny Anteckning',
  'LNK_NEW_CALL' => 'Nytt Samtal',
  'LNK_NEW_EMAIL' => 'Ny Epost',
  'LNK_NEW_MEETING' => 'Nytt M�te',
  'LNK_NEW_TASK' => 'Ny Uppgift',
);


?>