<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Clienti',
  'LBL_MODULE_TITLE' => 'Client: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Cerca Cliente',
  'LBL_LIST_FORM_TITLE' => 'Elenco Clienti',
  'LBL_NEW_FORM_TITLE' => 'Nuovo Cliente',
  'LBL_MEMBER_ORG_FORM_TITLE' => 'Membri delle organizzazioni',
  'LBL_BUG_FORM_TITLE' => 'Accounts',
  'LBL_LIST_ACCOUNT_NAME' => 'Nome del Cliente',
  'LBL_LIST_CITY' => 'Città',
  'LBL_LIST_WEBSITE' => 'Sito web',
  'LBL_LIST_STATE' => 'Età',
  'LBL_LIST_PHONE' => 'Telefono',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email Address',
  'LBL_LIST_CONTACT_NAME' => 'Contact Name',
  'db_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_website' => 'LBL_LIST_WEBSITE',
  'db_billing_address_city' => 'LBL_LIST_CITY',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'LBL_ACCOUNT_INFORMATION' => 'Account Information',
  'LBL_ACCOUNT' => 'Cliente:',
  'LBL_ACCOUNT_NAME' => 'Nome del Cliente:',
//END DON'T CONVERT
  'LBL_PHONE' => 'Telefono:',
  'LBL_PHONE_ALT' => 'Alternate Phone:',
  'LBL_WEBSITE' => 'Sito web:',
  'LBL_FAX' => 'Fax:',
  'LBL_TICKER_SYMBOL' => 'Ticker:',
  'LBL_OTHER_PHONE' => 'Altro Telefono:',
  'LBL_ANY_PHONE' => 'Telefono alternativo:',
  'LBL_MEMBER_OF' => 'Membro di:',
  'LBL_PHONE_OFFICE' => 'Phone Office:',
  'LBL_PHONE_FAX' => 'Phone Fax:',
  'LBL_EMAIL' => 'Email:',
  'LBL_EMPLOYEES' => 'Dipendenti:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Altra Email:',
  'LBL_ANY_EMAIL' => 'Email alternativa:',
  'LBL_OWNERSHIP' => 'Proprietario:',
  'LBL_RATING' => 'Note:',
  'LBL_INDUSTRY' => 'Attività',
  'LBL_SIC_CODE' => 'Partita IVA:',
  'LBL_TYPE' => 'Tipo:',
  'LBL_ANNUAL_REVENUE' => 'Fatturato Annuo:',
  'LBL_ADDRESS_INFORMATION' => 'Indirizzo',
  'LBL_BILLING_ADDRESS' => 'Indirizzo di Fatturazione:',
  'LBL_BILLING_ADDRESS_STREET' => 'Billing Address Street:',
  'LBL_BILLING_ADDRESS_CITY' => 'Billing Address City:',
  'LBL_BILLING_ADDRESS_STATE' => 'Billing Address State:',
  'LBL_BILLING_ADDRESS_POSTALCODE' => 'Billing Address Postal Code:',
  'LBL_BILLING_ADDRESS_COUNTRY' => 'Billing Address Country:',
  'LBL_SHIPPING_ADDRESS_STREET' => 'Shipping Address Street:',
  'LBL_SHIPPING_ADDRESS_CITY' => 'Shipping Address City:',
  'LBL_SHIPPING_ADDRESS_STATE' => 'Shipping Address State:',
  'LBL_SHIPPING_ADDRESS_POSTALCODE' => 'Shipping Address Postal Code:',
  'LBL_SHIPPING_ADDRESS_COUNTRY' => 'Shipping Address Country:',
  'LBL_SHIPPING_ADDRESS' => 'Indirizzo di Spedizione:',
  'LBL_DATE_MODIFIED' => 'Date Modified:',
  'LBL_DATE_ENTERED' => 'Date Entered:',
  'LBL_ANY_ADDRESS' => 'Altro Indirizzo:',
  'LBL_CITY' => 'Città:',
  'LBL_STATE' => 'Provincia:',
  'LBL_POSTAL_CODE' => 'C.A.P.:',
  'LBL_COUNTRY' => 'Nazione:',
  'LBL_DESCRIPTION_INFORMATION' => 'Descrizione',
  'LBL_DESCRIPTION' => 'Descrizione:',
  'NTC_COPY_BILLING_ADDRESS' => 'Copia indirizzo di fatturazione come indirizzo di spedizione',
  'NTC_COPY_SHIPPING_ADDRESS' => 'Copia indirizzo di spedizione come indirizzo di fatturazione',
  'NTC_REMOVE_MEMBER_ORG_CONFIRMATION' => 'Sei sicuro di voler eliminare questa informazione?',
  'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Are you sure you want to remove this record?',
  'LBL_DUPLICATE' => 'Possible Duplicate Account',
  'MSG_SHOW_DUPLICATES' => 'Creating this contact may potentialy create a duplicate contact. You may either click on Create Account to continue creating this new account with the previously entered data or you may click Cancel.',
  'MSG_DUPLICATE' => 'Creating this account may potentialy create a duplicate account. You may either select an account from the list below or you may click on Create New Account to continue creating a new account with the previously entered data.',
  'LNK_NEW_ACCOUNT' => 'Nuovo Cliente',
  'LNK_ACCOUNT_LIST' => 'Accounts',
  'LBL_INVITEE' => 'Contacts',
  'ERR_DELETE_RECORD' => 'Devi specificare un numero record per eliminare il cliente.',
  'NTC_DELETE_CONFIRMATION' => 'Are you sure you want to delete this record?',
  'LBL_SAVE_ACCOUNT' => 'Save Account',
  'LNK_NEW_CONTACT' => 'Nuovo Contatto',
  'LNK_NEW_OPPORTUNITY' => 'Nuova Opportunità',
  'LNK_NEW_CASE' => 'Nuovo Ticket Supporto',
  'LNK_NEW_NOTE' => 'Nuova Nota',
  'LNK_NEW_CALL' => 'Nuova Chiamata',
  'LNK_NEW_EMAIL' => 'Nuova Email',
  'LNK_NEW_MEETING' => 'Nuova Riunione',
  'LNK_NEW_TASK' => 'Nuovo Task',
);


?>