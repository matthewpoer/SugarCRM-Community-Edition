<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Activities',
  'LBL_MODULE_TITLE' => 'Activities: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Activities Search',
  'LBL_LIST_FORM_TITLE' => 'Activities List',
  'LBL_LIST_SUBJECT' => 'Soggetto',
  'LBL_LIST_CONTACT' => 'Contatto',
  'LBL_LIST_RELATED_TO' => 'Relativo a',
  'LBL_LIST_DATE' => 'Data',
  'LBL_LIST_TIME' => 'Start Time',
  'LBL_LIST_CLOSE' => 'Chiuso',
  'LBL_SUBJECT' => 'Subject:',
  'LBL_STATUS' => 'Status:',
  'LBL_LOCATION' => 'Location:',
  'LBL_DATE_TIME' => 'Start Date & Time:',
  'LBL_DATE' => 'Start Date:',
  'LBL_TIME' => 'Start Time:',
  'LBL_DURATION' => 'Duration:',
  'LBL_HOURS_MINS' => '(hours/minutes)',
  'LBL_CONTACT_NAME' => 'Contact Name: ',
  'LBL_MEETING' => 'Meeting:',
  'LBL_DESCRIPTION_INFORMATION' => 'Description Information',
  'LBL_DESCRIPTION' => 'Description:',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'Planned',
  'LNK_NEW_CALL' => 'Nuova Chiamata',
  'LNK_NEW_MEETING' => 'Nuovo Meeting',
  'LNK_NEW_TASK' => 'Nuovo Task',
  'LNK_NEW_NOTE' => 'Nuova Nota',
  'LNK_NEW_EMAIL' => 'Nuova Email',
  'LNK_CALL_LIST' => 'Calls',
  'LNK_MEETING_LIST' => 'Meetings',
  'LNK_TASK_LIST' => 'Tasks',
  'LNK_NOTE_LIST' => 'Notes',
  'LNK_EMAIL_LIST' => 'Emails',
  'ERR_DELETE_RECORD' => 'Devi specificare un numero record per eliminare il cliente.',
  'NTC_REMOVE_INVITEE' => 'Are you sure you want to remove this invitee from the meeting?',
  'LBL_INVITEE' => 'Invitees',
  'LBL_LIST_DIRECTION' => 'Direction',
  'LBL_DIRECTION' => 'Direction',
  'LNK_NEW_APPOINTMENT' => 'New Appointment',
  'LNK_VIEW_CALENDAR' => 'Today',
  'LBL_OPEN_ACTIVITIES' => 'Attività Aperte',
  'LBL_HISTORY' => 'Storico',
  'LBL_UPCOMING' => 'Le mie prossime attività',
  'LBL_TODAY' => 'per ',
  'LBL_NEW_TASK_BUTTON_TITLE' => 'Nuovo Task [Alt+N]',
  'LBL_NEW_TASK_BUTTON_KEY' => 'N',
  'LBL_NEW_TASK_BUTTON_LABEL' => 'Nuovo Task',
  'LBL_SCHEDULE_MEETING_BUTTON_TITLE' => 'Pianifica Meeting[Alt+M]',
  'LBL_SCHEDULE_MEETING_BUTTON_KEY' => 'M',
  'LBL_SCHEDULE_MEETING_BUTTON_LABEL' => 'Pianifica Meeting',
  'LBL_SCHEDULE_CALL_BUTTON_TITLE' => 'Pianifica Chiamata[Alt+C]',
  'LBL_SCHEDULE_CALL_BUTTON_KEY' => 'C',
  'LBL_SCHEDULE_CALL_BUTTON_LABEL' => 'Pianifica Chiamata',
  'LBL_NEW_NOTE_BUTTON_TITLE' => 'Nuova [Alt+T]',
  'LBL_NEW_NOTE_BUTTON_KEY' => 'T',
  'LBL_NEW_NOTE_BUTTON_LABEL' => 'Nuova Nota',
  'LBL_TRACK_EMAIL_BUTTON_TITLE' => 'Traccia Email [Alt+K]',
  'LBL_TRACK_EMAIL_BUTTON_KEY' => 'K',
  'LBL_TRACK_EMAIL_BUTTON_LABEL' => 'Traccia Email',
  'LBL_LIST_STATUS' => 'Stato',
  'LBL_LIST_DUE_DATE' => 'Data prevista',
  'LBL_LIST_LAST_MODIFIED' => 'Ultima modifica',
  'NTC_NONE_SCHEDULED' => 'Niente di pianificato.',
  'appointment_filter_dom' => 
  array (
    'today' => 'today',
    'tomorrow' => 'tomorrow',
    'this Saturday' => 'this week',
    'next Saturday' => 'next week',
    'last this_month' => 'this month',
    'last next_month' => 'next month',
  ),
  'LNK_IMPORT_NOTES' => 'Import Notes',
  'LNK_NEW_CONTACT' => 'Nuovo Contatto',
  'LNK_NEW_ACCOUNT' => 'Nuovo Cliente',
  'LNK_NEW_OPPORTUNITY' => 'Nuova Opportunità',
  'LNK_NEW_CASE' => 'Nuovo Ticket Supporto',
);


?>