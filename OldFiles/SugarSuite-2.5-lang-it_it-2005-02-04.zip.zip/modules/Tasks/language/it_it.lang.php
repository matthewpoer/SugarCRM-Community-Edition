<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Task',
  'LBL_TASK' => 'Task: ',
  'LBL_MODULE_TITLE' => ' Task: Home',
  'LBL_SEARCH_FORM_TITLE' => ' Cerca Task',
  'LBL_LIST_FORM_TITLE' => ' Elenco Task',
  'LBL_NEW_FORM_TITLE' => ' Nuovo Task',
  'LBL_NEW_FORM_SUBJECT' => 'soggetto:',
  'LBL_NEW_FORM_DUE_DATE' => 'data di completamento:',
  'LBL_NEW_FORM_DUE_TIME' => 'ora di completamento:',
  'LBL_NEW_TIME_FORMAT' => '(24:00)',
  'LBL_LIST_CLOSE' => 'Chiuso',
  'LBL_LIST_SUBJECT' => 'soggetto',
  'LBL_LIST_CONTACT' => 'Contatto',
  'LBL_LIST_PRIORITY' => 'Priority',
  'LBL_LIST_RELATED_TO' => 'Relativo a',
  'LBL_LIST_DUE_DATE' => 'Data di completamento',
  'LBL_LIST_DUE_TIME' => 'Ora di completamento',
  'LBL_SUBJECT' => 'soggetto:',
  'LBL_STATUS' => 'Stato:',
  'LBL_DUE_DATE' => 'Data di completamento',
  'LBL_DUE_TIME' => 'Due Time:',
  'LBL_PRIORITY' => 'Priorità',
  'LBL_COLON' => ':',
  'LBL_DUE_DATE_AND_TIME' => 'Data & Ora di completamento',
  'LBL_START_DATE_AND_TIME' => 'Start Date & Time:',
  'LBL_START_DATE' => 'Start Date:',
  'LBL_START_TIME' => 'Start Time:',
  'DATE_FORMAT' => '(yyyy-mm-dd 24:00)',
  'LBL_NONE' => 'nessuno',
  'LBL_CONTACT' => 'Contatto:',
  'LBL_PHONE' => 'Telefono:',
  'LBL_EMAIL' => 'Email:',
  'LBL_DESCRIPTION_INFORMATION' => 'Descrizione ',
  'LBL_DESCRIPTION' => 'Descrizione:',
  'LBL_NAME' => 'Nome:',
  'LBL_CONTACT_NAME' => 'Nome Contatto: ',
  'LBL_LIST_COMPLETE' => 'Termina',
  'LBL_LIST_STATUS' => 'Stato:',
  'LBL_DATE_DUE_FLAG' => 'No Due Date',
  'LBL_DATE_START_FLAG' => 'No Start Date',
  'ERR_DELETE_RECORD' => 'Devi specificare un numero record per eliminare il cliente.',
  'ERR_INVALID_HOUR' => 'Per favore inserisci un\'ora compresa tra 0 et 24',
  'LBL_DEFAULT_STATUS' => 'Non Iniziata',
  'LBL_DEFAULT_PRIORITY' => 'Media',
  'LBL_LIST_MY_TASKS' => 'My Open Tasks',
  'LNK_NEW_CALL' => 'Nuova Chiamata',
  'LNK_NEW_MEETING' => 'Nuova Riunione',
  'LNK_NEW_TASK' => 'Nuovo Task',
  'LNK_NEW_NOTE' => 'Nuova Nota',
  'LNK_NEW_EMAIL' => 'Nuova Email',
  'LNK_CALL_LIST' => 'Calls',
  'LNK_MEETING_LIST' => 'Meetings',
  'LNK_TASK_LIST' => 'Tasks',
  'LNK_NOTE_LIST' => 'Notes',
  'LNK_EMAIL_LIST' => 'Emails',
  'LNK_VIEW_CALENDAR' => 'Today',
  'LBL_CONTACT_FIRST_NAME' => 'Contact First Name',
  'LBL_CONTACT_LAST_NAME' => 'Contact Last Name',
  'LNK_NEW_CONTACT' => 'Nuovo Contatto',
  'LNK_NEW_ACCOUNT' => 'Nuovo Cliente',
  'LNK_NEW_OPPORTUNITY' => 'Nuova Opportunità',
  'LNK_NEW_CASE' => 'Nuovo Ticket Supporto',
);


?>