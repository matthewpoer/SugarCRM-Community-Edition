<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Calendar',
  'LBL_MODULE_TITLE' => 'Calendar',
  'LNK_NEW_CALL' => 'Crea Chiamata',
  'LNK_NEW_MEETING' => 'Crea Riunione',
  'LNK_NEW_APPOINTMENT' => 'Crea Appuntamento',
  'LNK_NEW_TASK' => 'Crea Attivit�',
  'LNK_CALL_LIST' => 'Chiamate',
  'LNK_MEETING_LIST' => 'Riunioni',
  'LNK_TASK_LIST' => 'Attivit�',
  'LNK_VIEW_CALENDAR' => 'Oggi',
  'LBL_MONTH' => 'Mese',
  'LBL_DAY' => 'Giorno',
  'LBL_YEAR' => 'Anno',
  'LBL_WEEK' => 'Settimana',
  'LBL_PREVIOUS_MONTH' => 'Mese Precedente',
  'LBL_PREVIOUS_DAY' => 'Giorno Precedente',
  'LBL_PREVIOUS_YEAR' => 'Anno Precedente',
  'LBL_PREVIOUS_WEEK' => 'Settimana Precedente',
  'LBL_NEXT_MONTH' => 'Mese Successivo',
  'LBL_NEXT_DAY' => 'Giorno Successivo',
  'LBL_NEXT_YEAR' => 'Anno Successivo',
  'LBL_NEXT_WEEK' => 'Settimana Successiva',
  'LBL_AM' => 'AM',
  'LBL_PM' => 'PM',
  'LBL_SCHEDULED' => 'Pianificato',
  'LBL_BUSY' => 'Occupato',
  'LBL_CONFLICT' => 'Conflitto',
  'LBL_USER_CALENDARS' => 'Calendari Utente',
);

$mod_list_strings = array (
  'dom_cal_weekdays' => 
  array (
    0 => 'Dom',
    1 => 'Lun',
    2 => 'Mar',
    3 => 'Mer',
    4 => 'Gio',
    5 => 'Ven',
    6 => 'Sab',
  ),
  'dom_cal_weekdays_long' => 
  array (
    0 => 'Domenica',
    1 => 'Lunedi',
    2 => 'Martedi',
    3 => 'Mercoledi',
    4 => 'Giovedi',
    5 => 'Venerdi',
    6 => 'Sabato',
  ),
  'dom_cal_month' => 
  array (
    0 => '',
    1 => 'Gen',
    2 => 'Feb',
    3 => 'Mar',
    4 => 'Apr',
    5 => 'Mag',
    6 => 'Giu',
    7 => 'Lug',
    8 => 'Ago',
    9 => 'Set',
    10 => 'Ott',
    11 => 'Nov',
    12 => 'Dic',
  ),
  'dom_cal_month_long' => 
  array (
    0 => '',
    1 => 'Gennaio',
    2 => 'Febbraio',
    3 => 'Marzo',
    4 => 'Aprile',
    5 => 'Maggio',
    6 => 'Giugno',
    7 => 'Luglio',
    8 => 'Agosto',
    9 => 'Settembre',
    10 => 'Ottobre',
    11 => 'Novembre',
    12 => 'Dicembre',
  ),
);


?>