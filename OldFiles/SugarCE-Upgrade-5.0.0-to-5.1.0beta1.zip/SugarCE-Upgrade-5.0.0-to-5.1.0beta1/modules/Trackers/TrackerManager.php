<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

class TrackerManager {

private static $instance;
private static $monitor_id;
private $metadata = array();
private $monitors = array();
private $paused = false;

private function TrackerManager() {
	require_once('modules/Trackers/config.php');
	$this->metadata = $tracker_config;

    require_once('include/utils.php');
    self::$monitor_id = create_guid();
}

public function setMonitorId($id) {
    self::$monitor_id = $id;
    foreach($this->monitors as $monitor) {
       $monitor->monitor_id = self::$monitor_id;	
    }	
}

/**
 * getMonitorId
 * Returns the monitor id associated with this TrackerManager instance
 * @returns String id value
 */
public function getMonitorId() {
    return self::$monitor_id;
}

/**
 * getInstance
 * Singleton method to return static instance of TrackerManager
 * @returns static TrackerManager instance 
 */
static function getInstance(){	
    if (!isset(self::$instance)) {
        self::$instance = new TrackerManager();
    } // if
    return self::$instance;
}

/**
 * getMonitor
 * This method returns a Monitor instance based on the monitor name.
 * @param $name The String value of the monitor's name to retrieve
 * @return Monitor instance corresponding to name 
 * @throws Exception Thrown when no Monitor could be found for the given $name value
 */
public function getMonitor($name) {

	if(isset($this->monitors[$name])) {
	   return $this->monitors[$name];	
	}
	
	if(isset($this->metadata) && isset($this->metadata[$name])) {
       
       if($GLOBALS['db']->dbType == 'oci8') {



       } else {
         $monitorClass = isset($this->metadata[$name]['monitor']) ? $this->metadata[$name]['monitor'] : 'Monitor';
       }
       
       require_once('modules/Trackers/monitor/'.$monitorClass.'.php');
       $instance = new $monitorClass($this->metadata[$name]['name'], //name
       						   self::$monitor_id, //monitor_id
                               $this->metadata[$name]['metadata'], //metadata
                               $this->metadata[$name]['store'] //store 
                               );
       $this->monitors[$name] = $instance;
       return $this->monitors[$name];
    }
    
    $GLOBALS['log']->error($GLOBALS['app_strings']['ERR_MONITOR_NOT_CONFIGURED'] . "($name)");
    throw new Exception($GLOBALS['app_strings']['ERR_MONITOR_NOT_CONFIGURED'] . "($name)");
}

/**
 * save
 * This method handles saving the monitors and their metrics to the mapped Store implementations
 */
public function save() {
    if(!$this->paused){
		foreach($this->monitors as $monitor) {
    		$monitor->save();
    	}
    }	
}

/**
 * saveMonitor
 */
public function saveMonitor($monitor) {
	if(!$this->paused){
		if(array_key_exists('Trackable', class_implements($monitor))) {
		   $monitor->save();   
		   //Unset the monitor
		   unset($this->monitors[$monitor->name]);
	    }
	}
}

/**
 * pause
 * This function is to be called by a client in order to pause tracking through the lifetime of a Request.
 * Tracking can be started again by calling unPauseTracking
 *
 * Usage: TrackerManager::getInstance()->pauseTracking();
 */
public function pause(){
	$this->paused = true;
}

/**
 * unPause
 * This function is to be called by a client in order to unPause tracking through the lifetime of a Request.
 * Tracking can be paused by calling pauseTracking
 *
 *  * Usage: TrackerManager::getInstance()->unPauseTracking();
 */
public function unPause(){
	$this->paused = false;
}

	
}
?>
