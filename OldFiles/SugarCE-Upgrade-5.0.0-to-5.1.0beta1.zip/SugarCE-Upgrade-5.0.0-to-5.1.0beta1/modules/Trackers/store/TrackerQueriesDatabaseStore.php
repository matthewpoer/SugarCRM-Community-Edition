<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/
/*********************************************************************************
 * $Id$
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/
 
require_once('modules/Trackers/store/Store.php');

class TrackerQueriesDatabaseStore implements Store {
    
    public function flush($monitor) {

       $metrics = $monitor->getMetrics();
       $columns = array();
       $values = array();
       foreach($metrics as $name=>$metric) {
       	  if(!empty($monitor->$name)) {
       	  	 $columns[] = $name;
       	  	 if($metrics[$name]->_type == 'int' || $metrics[$name]->_type == 'double') {
                $values[] = PearDatabase::quote(from_html($monitor->$name));
             } else if ($metrics[$name]->_type == 'datetime') {
             	$values[] = ($GLOBALS['db']->dbType == 'oci8') ? db_convert("'".$monitor->$name."'",'datetime') : "'".$monitor->$name."'";
       	  	 } else {
                $values[] = "'".PearDatabase::quote(from_html($monitor->$name))."'";
             } 
       	  }
       } //foreach
       
       if(empty($values)) {
       	  return;
       }
       
	   $db = & PearDatabase::getInstance();
	   $query = "DELETE FROM $monitor->table_name WHERE query_hash ='$monitor->query_hash'";
	   $db->query($query);
	   
	   //If it's Oracle, we have to do special handling for the text column (CLOB type)	
	   if($GLOBALS['db']->dbType == 'oci8') {
          $query = "INSERT INTO $monitor->table_name (" .implode("," , $columns). " ) VALUES ( ". implode("," , $values). ')';

		  $lob_fields = array();
		  $lob_field_type = array();
		  $lobs = array();
		  
		  //Add text as the lob field
		  $lob_fields['text'] = ":". 'text';
		  $lob_field_type['text'] = OCI_B_CLOB;
		
		  $query .= " RETURNING ".implode(",", array_keys($lob_fields)).' INTO '.implode(",", array_values($lob_fields));
		
		  $stmt = ociparse($db->database, $query);
		  $err = ocierror($db->database);
		  if ($err != false){
		      $GLOBALS['log']->error($query.">>".$err['code'].":".$err['message']);
		      return;
		  }

		  foreach ($lob_fields as $key=>$descriptor) {
		    $newlob = OCINewDescriptor($db->database, OCI_D_LOB);
		    OCIBindByName($stmt, $descriptor, $newlob, -1, $lob_field_type[$key]);
		    $lobs[$key] = $newlob;
		  }
		
		  ociexecute($stmt,OCI_DEFAULT);
		  $err = ocierror($stmt);
		  if ($err != false){
			  $GLOBALS['log']->fatal($query.">>".$err['code'].":".$err['message']);
			  return;
		  } else {
			  foreach ($lobs as $key=>$lob){
			        $val = $monitor->$key;
			        if (empty($val)) $val=" ";
			        $lob->save($val);
			  }
			  ocicommit($db->database);
		  }
		
		  // free all the lobs.
		  foreach ($lobs as $lob){
		    $lob->free();
		  }
		  ocifreecursor($stmt);
	      
	   } else {
          $query = "INSERT INTO $monitor->table_name (" .implode("," , $columns). " ) VALUES ( ". implode("," , $values). ')';
	      $db->query($query);	   	
	   }
    }
}

?>
