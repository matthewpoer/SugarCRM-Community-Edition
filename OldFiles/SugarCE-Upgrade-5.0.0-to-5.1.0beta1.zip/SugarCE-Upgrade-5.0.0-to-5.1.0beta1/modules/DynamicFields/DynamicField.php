<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/
/*********************************************************************************

 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

class DynamicField {
	
    var $use_existing_labels = false; // this value is set to true by install_custom_fields() in ModuleInstaller.php; everything else expects it to be false
    
	function DynamicField($module = '') {
		$this->module = (! empty ( $module )) ? $module :( (isset($_REQUEST['module']) && ! empty($_REQUEST['module'])) ? $_REQUEST ['module'] : '');
	}
	
	function getModuleName()
	{
	    return $this->module ;
	}
	
	/*
	 * As DynamicField has a counterpart in MBModule, provide the MBModule function getPackagename() here also
	 */
    function getPackageName()
    {
        return null ;
    }
	
    function deleteCache(){
        /*
        $GLOBALS['log']->debug("deleting the dynamic fields cache from disk");
        $file = 'cache/dynamic_fields/';
        if(file_exists($file)){
            rmdir_recursive($file);
        }
        if (isset($this->module)) // deleteCache() is called as a class function from some modules and so $this->module may not be set. This is not an issue, as the following code is only relevant for ModuleBuilder, which does set $this->module
        {
            global $beanList;
            $object = $beanList[$this->module];
            $GLOBALS['log']->debug("clearing vardef cache for module=".$this->module." and object=".$object);
            VardefManager::clearVardef($this->module, $object);
            // tyoung bug 15858 - VardefManager::clearVardef doesn't clear out the entry from the GLOBALS['dictionary'] - we need to clear this as getAvailableFields calls loadFromCache which adds back the entries in GLOBALS['dictionary'], which we don't want to include deleted fields
            if (isset($GLOBALS['dictionary'][$object]))
            {
                unset($GLOBALS['dictionary'][$object]);
            }
        }
        return true;
*/
    }
    
	
	/**
	 * This will add the bean as a reference in this object as well as building the custom field cache if it has not been built
	 * LOADS THE BEAN IF THE BEAN IS NOT BEING PASSED ALONG IN SETUP IT SHOULD BE SET PRIOR TO SETUP
	 *
	 * @param SUGARBEAN $bean
	 */
	function setup($bean = null) {
		if ($bean) {
			$this->bean = & $bean;
		}
		if (isset ( $this->bean->module_dir )) {
			$this->module = $this->bean->module_dir;
		}
		if(!isset($GLOBALS['dictionary'][$this->bean->object_name]['custom_fields'])){
			$this->buildCache ( $this->module );
		}
	}
	
    function setLabel( $language='en_us' , $key , $value )
    {
        $params [ "label_" . $key ] = $value;
        require_once 'modules/ModuleBuilder/parsers/parser.label.php' ;
        $parser = new ParserLabel ( $this->module ) ;
        $parser->handleSave( $params , $language);
    }

	/**
	 * Builds the cache for custom fields based on the vardefs 
	 *
	 * @param STRING $module
	 * @return unknown
	 */
	function buildCache($module = false) {
		//We can't build the cache while installing as the required database tables may not exist.
		if (!empty($GLOBALS['installing']) && $GLOBALS['installing'] == true)
			return false;
		if($module == '../data')return false;
		static $results = array ( );
		$where = '';
		if (! empty ( $module )) {
			$where .= " custom_module='$module' AND ";
		}
		$GLOBALS['log']->debug('rebuilding cache for ' . $module);
		$query = "SELECT * FROM fields_meta_data WHERE $where deleted = 0";
		$result = $GLOBALS ['db']->query ( $query );
		require_once ('modules/DynamicFields/FieldCases.php');
		while ( $row = $GLOBALS ['db']->fetchByAssoc ( $result ) ) {
			$field = get_widget ( $row ['type'] );
			foreach ( $row as $key => $value ) {
				$field->$key = $value;
			}
			$field->default = $field->default_value;
			$vardef = $field->get_field_def ();
			$vardef ['id'] = $row ['id'];
			$vardef ['custom_module'] = $row ['custom_module'];
			if (empty ( $vardef ['source'] ))
				$vardef ['source'] = 'custom_fields';
			if (empty ( $results [$row ['custom_module']] ))
				$results [$row ['custom_module']] = array ( );
			$results [$row ['custom_module']] [$row ['name']] = $vardef;
		}
		if (empty ( $module )) {
			foreach ( $results as $module => $result ) {
				$this->saveToVardef ( $module, $result );
			}
		} else {
			if (! empty ( $results [$module] )) {
				$this->saveToVardef ( $module, $results [$module] );
			}else{
				$this->saveToVardef ( $module, false );
			}
		}
		return true;
	
	}
	
	/**
	 * Updates the cached vardefs with the custom field information stored in result
	 *
	 * @param string $module
	 * @param array $result
	 */
	function saveToVardef($module,$result) {
		require_once ('include/SugarObjects/VardefManager.php');
		global $beanList;
		if (! empty ( $beanList [$module] )) {
			$object = $beanList [$module];
			if ($object == 'aCase')
				$object = 'Case';
			$GLOBALS ['dictionary'] [$object] ['custom_fields'] = false;
			if (! empty ( $GLOBALS ['dictionary'] [$object] )) {
				if (! empty ( $result )) {
					// First loop to add

					foreach ( $result as $field ) {
						$GLOBALS ['dictionary'] [$object] ['fields'] [$field ['name']] = $field;
					} //for

					// Second loop to remove
					foreach ( $GLOBALS ['dictionary'] [$object] ['fields'] as $name => $fieldDef ) {
						
						if (isset ( $fieldDef ['custom_module'] )) {
							if (! isset ( $result [$name] )) {
								unset ( $GLOBALS ['dictionary'] [$object] ['fields'] [$name] );
							} else {
								$GLOBALS ['dictionary'] [$object] ['custom_fields'] = true;
							}
						}

					} //if
				}
			}
			$manager = new VardefManager ( );
			$manager->saveCache ( $this->module, $object );
		}
	}
	
	/**
	 * returns either false or an array containint the select and join parameter for a query using custom fields
	 *
	 * @return unknown
	 */
  function getJOIN(){

        if(!$this->bean->hasCustomFields()){
            return false;
        }
        return array('select'=>" , ". $this->bean->table_name. "_cstm.*", 'join'=> " LEFT JOIN " .$this->bean->table_name. "_cstm ON " .$this->bean->table_name. ".id = ". $this->bean->table_name. "_cstm.id_c ");

    }
	
   /**
    * Fills in all the custom fields of type relate relationships for an object
    *
    */
   function fill_relationships(){
        global $beanList, $beanFiles;
        foreach($this->bean->field_defs as $field){
			if(empty($field['source']) || $field['source'] != 'custom_fields')continue;
            if($field['type'] == 'relate'){
                $related_module =$field['ext2'];
                $name = $field['name'];
                $id_name = $field['id_name'];
                if(isset($beanList[ $related_module])){
                    $class = $beanList[$related_module];

                    if(file_exists($beanFiles[$class]) && isset($this->bean->$name)){
                        require_once($beanFiles[$class]);
                        $mod = new $class();
                        $mod->retrieve($this->bean->$id_name);
                        $this->bean->$name = $mod->name;
                    }
                }
            }
        }
    }
    
    /**
     * Process the save action for sugar bean custom fields 
     *
     * @param boolean $isUpdate
     */
     function save($isUpdate){
		
        if($this->bean->hasCustomFields() && isset($this->bean->id)){
            if($isUpdate){
                $query = "UPDATE ". $this->bean->table_name. "_cstm SET ";
            }
            $queryInsert = "INSERT INTO ". $this->bean->table_name. "_cstm (id_c";
            $values = "('".$this->bean->id."'";
            $first = true;
            foreach($this->bean->field_defs as $name=>$field){

                if(empty($field['source']) || $field['source'] != 'custom_fields')continue;
                if($field['type'] == 'html')continue;
                if($field['type'] == 'multienum'){
                    if(isset($_POST[$name]) && is_array($_POST[$name])) {
                        $this->bean->$name = count($_POST[$name]) == 0 ? $field['default_value'] : implode('^,^',$_POST[$name]);
                    } else if(isset($_POST[$name])) {
                        $this->bean->$name = $_POST[$name];
                    }
                }
                if(isset($this->bean->$name)){
                    $quote = "'";
                    if($field['type'] == 'int' || $field['type']== 'float'){
                        if (!empty($this->bean->$name)) {
                            $this->bean->$name = unTranslateNum($this->bean->$name);
                        }
                        $quote = '';
                        if(!isset($this->bean->$name) || !is_numeric($this->bean->$name) ){
                            if($field['required']){
                                $this->bean->$name = 0;
                            }else{
                                $this->bean->$name = 'NULL';
                            }
                        }
                    }
                    if($field['type'] == 'date' && (empty($this->bean->$name )|| $this->bean->$name == '1900-01-01')){
                    	$quote = '';
                        $this->bean->$name = 'NULL';
                    }
                    if($isUpdate){
                        if($first){
                            $query .= " $name=$quote".PearDatabase::quote(from_html($this->bean->$name))."$quote";

                        }else{
                            $query .= " ,$name=$quote".PearDatabase::quote(from_html($this->bean->$name))."$quote";
                        }
                    }
                    $first = false;
                    $queryInsert .= " ,$name";
                    $values .= " ,$quote". PearDatabase::quote(from_html($this->bean->$name )). "$quote";
                }
                unset($this->bean->$name);
            }
            if($isUpdate){
                $query.= " WHERE id_c='" . $this->bean->id ."'";

            }

            $queryInsert .= " ) VALUES $values )";
            if(!$first){
                if(!$isUpdate){
                    $GLOBALS['db']->query($queryInsert);
                }else{
          
                    $result = $GLOBALS['db']->query($query);
                    if((($GLOBALS['db']->dbType=='mysql' || $GLOBALS['db']->dbType=='mssql') && $GLOBALS['db']->getAffectedRowCount($result) == 0) || (($GLOBALS['db']->dbType=='oci8' ) && $GLOBALS['db']->getRowCount($result) == 0) ){
	
                    	$GLOBALS['db']->query($queryInsert);
                    }
                }
            }
       
        }


    }

    /**
     * Deletes the field from fields_meta_data and drops the database column then it rebuilds the cache
     *
     * @param STRING $name - field name
     */
    function deleteField($name){
        $object_name = $this->module;
        $GLOBALS['db']->query("DELETE FROM fields_meta_data WHERE id='" . $this->module . $name . "'");
        $GLOBALS['db']->query("ALTER TABLE " . $this->bean->table_name . "_cstm DROP COLUMN $name");
        $this->buildCache($this->module);
    }
    /*
     * Method required by the TemplateRelatedTextField->save() method
     * Taken from MBModule's implementation
     */
    function fieldExists($name = '', $type = ''){
        // must get the vardefs from the GLOBAL array as $bean->field_defs does not contain the values from the cache at this point
        // TODO: fix this - saveToVardefs() updates GLOBAL['dictionary'] correctly, obtaining its information directly from the fields_meta_data table via buildCache()...
        $vardefs = $GLOBALS['dictionary'][$this->bean->object_name]['fields'];
        if(!empty($vardefs)){
            if(empty($type) && empty($name))
                return false;
            else if(empty($type))
                return !empty($vardefs[$name]);
            else if(empty($name)){
                foreach($vardefs as $def){
                    if($def['type'] == $type)
                        return true;
                }
                return false;
            }else
                return (!empty($vardefs[$name]) && ($vardefs[$name]['type'] == $type));
        }else{
            return false;
        }
    }
    
    
    /**
     * Adds a custom field using a filed object
     *
     * @param Field Object $field
     * @return boolean
     */
	function addFieldObject(&$field){
		$GLOBALS['log']->debug('adding field');
		$object_name = $this->module;
        $db_name = $field->name;
        require_once('modules/EditCustomFields/FieldsMetaData.php');
        $fmd = new FieldsMetaData();
        $id =  $fmd->retrieve($object_name.$db_name,true, false);
        $is_update = false;
        $label = $field->label;
        if(!empty($id)){
            $is_update = true;
        }else{
            $db_name = $this->getDBName($field->name);
            $field->name = $db_name;
        }
     	$this->createCustomTable();
        $fmd->id = $object_name.$db_name;
        $fmd->custom_module= $object_name;
        $fmd->name = $db_name;
        $fmd->vname = $label;
        $fmd->type = $field->type;
        $fmd->help = $field->help;
        $fmd->len = $field->len; // tyoung bug 15407 - was being set to $field->size so changes weren't being saved
        $fmd->required = ($field->required ? 1 : 0);
        $fmd->default_value = $field->default;
        $fmd->ext1 = $field->ext1;
        $fmd->ext2 = $field->ext2;
        $fmd->ext3 = $field->ext3;
        $fmd->ext4 = (isset($field->ext4) ? $field->ext4 : '');
        $fmd->comments = $field->comment;
        $fmd->massupdate = $field->massupdate;
        $fmd->duplicate_merge = $field->duplicate_merge;
        $fmd->audited =$field->audited;
        $fmd->reportable = ($field->reportable ? 1 : 0);
        if(!$is_update){
            $fmd->new_with_id=true;
        }
        $fmd->save();
        $this->buildCache($this->module);
        if($field){
            if(!$is_update){
                $query = $field->get_db_add_alter_table($this->bean->table_name . '_cstm');
            }else{
                $query = $field->get_db_modify_alter_table($this->bean->table_name . '_cstm');
            }
            if(!empty($query)){
                $GLOBALS['db']->query($query);
            }
        }
        return true;
    }
	
    /**
     * Adds a Custom Field using parameters
     *
     * @param unknown_type $name
     * @param unknown_type $label
     * @param unknown_type $type
     * @param unknown_type $max_size
     * @param unknown_type $required_option
     * @param unknown_type $default_value
     * @param unknown_type $ext1
     * @param unknown_type $ext2
     * @param unknown_type $ext3
     * @param unknown_type $audited
     * @param unknown_type $mass_update
     * @param unknown_type $ext4
     * @param unknown_type $help
     * @param unknown_type $duplicate_merge
     * @param unknown_type $comment
     * @return boolean 
     */
    function addField($name,$label='', $type='Text',$max_size='255',$required_option='optional', $default_value='', $ext1='', $ext2='', $ext3='',$audited=0, $mass_update = 0 , $ext4='', $help='',$duplicate_merge=0, $comment=''){
		$field = new Object(); 
    	$field->label = $this->addLabel($label);
        if(empty($field->label)){
            $field->label = $name;
        }
        $field->name = $name;
		$field->type = $type;
		$field->len = $max_size;
		$field->required = (!empty($required_option) && $required_option != 'optional');
		$field->default = $default_value;
		$field->ext1 = $ext1;
		$field->ext2 = $ext2;
		$field->ext3 = $ext3;
		$field->ext4 = $ext4;
		$field->help = $help;
		$field->comments = $comment;
		$field->massupdate = $mass_update;
		$field->duplicate_merge = $duplicate_merge;
		$field->audited = $audited;
		$field->reportable = 1;
        return $this->addFieldObject($field);
        
    }
    
    /**
     * Creates the custom table with an id of id_c 
     *
     */
    function createCustomTable(){

        if (!$GLOBALS['db']->tableExists($this->bean->table_name."_cstm")) {
        	$GLOBALS['log']->debug('creating custom table for '. $this->bean->table_name);
            $query = 'CREATE TABLE '.$this->bean->table_name.'_cstm ( ';
            $query .='id_c ' . $this->bean->dbManager->helper->getColumnType('id') .' NOT NULL';
            $query .=', PRIMARY KEY ( id_c ) )';
            if($GLOBALS['db']->dbType == 'mysql'){
                $query .= ' CHARACTER SET utf8 COLLATE utf8_general_ci';
            }

            $GLOBALS['db']->query($query);
            $this->add_existing_custom_fields();
        }

    }
    
    /**
     * Updates the db schema and adds any custom fields we have used if the custom table was dropped
     *
     */
    function add_existing_custom_fields(){
    	if($this->bean->hasCustomFields()){
	        foreach($this->field_defs as $name=>$data){
	        	if(empty($data['source']) || $data['source'] != 'custom_fields')continue;
	            $field = get_widget ( $data ['type'] );
	            $query = $field->get_db_add_alter_table($this->bean->table_name . '_cstm');
	            $GLOBALS['db']->query($query);
	        }
    	}
    }
    
    /**
     * Adds a label to the module's mod_strings for the current language
     * Note that the system label name 
     * 
     * @param string $displayLabel The label value to be displayed
     * @return string The core of the system label name - returns currency_id5 for example, when the full label would then be LBL_CURRENCY_ID5
     * TODO: Only the core is returned for historical reasons - switch to return the real system label
     */
    function addLabel ( $displayLabel )
    {
        $mod_strings = return_module_language($GLOBALS[ 'current_language' ], $this->module);
        $limit = 10;
        $count = 0;
        $field_key = $this->getDBName($displayLabel, false);
        $systemLabel = $field_key;
        if(!$this->use_existing_labels){ // use_existing_labels defaults to false in this module; as of today, only set to true by ModuleInstaller.php
            while( isset( $mod_strings [ $systemLabel ] ) && $count <= $limit )
            {
                $systemLabel = $field_key. "_$count";
                $count++;
            }
        }
        require_once('modules/ModuleBuilder/parsers/ParserFactory.php') ;
        $parser = ParserFactory::getParser( 'label', $this->module ) ;
        
        // tag the new label with label_ for compatibility with labels set through $_REQUEST which are identified as label_<labelname> for ease of parsing
        $parser->handleSave ( array('label_'. $systemLabel => $displayLabel ) , $this->module , $GLOBALS [ 'current_language' ] );
        return $systemLabel;
    }
    
    /**
     * Returns a Database Safe Name
     *
     * @param STRING $name
     * @param BOOLEAN $_C do we append _c to the name
     * @return STRING
     */
    function getDBName($name, $_C= true){
        static $cached_results = array();
        if(!empty($cached_results[$name]))
        {
            return $cached_results[$name];
        }
        $exclusions = array('parent_type', 'parent_id', 'currency_id', 'parent_name');
        // Remove any non-db friendly characters
        $return_value = preg_replace("/[^\w]+/","_",$name);
        if($_C == true && !in_array($return_value, $exclusions) && substr($return_value, -2) != '_c'){
            $return_value .= '_c';
        }
        $cached_results[$name] = $return_value;
        return $return_value;
    }

    function setWhereClauses(&$where_clauses){
    	if (isset($this->avail_fields)) {
	        foreach($this->avail_fields as $name=>$value){
	            if(!empty($_REQUEST[$name])){
	                array_push($where_clauses, $this->bean->table_name . "_cstm.$name LIKE '". PearDatabase::quote($_REQUEST[$name]). "%'");
	            }
	        }
    	}

    }

	/////////////////////////BACKWARDS COMPATABILITY MODE FOR PRE 5.0 MODULES\\\\\\\\\\\\\\\\\\\\\\\\\\\
   function populateXTPL(&$xtpl, $view){
   		if($this->bean->hasCustomFields()){
	        $results = $this->getAllFieldsView($view, 'xtpl');       
	        foreach($results as $name=>$value){
				if(is_array($value['xtpl'])){
	                foreach($value['xtpl'] as $xName=>$xValue){
	                    $xtpl->assign(strtoupper($xName), $xValue);
	
	                }
	            }else{
	                $xtpl->assign(strtoupper($name), $value['xtpl']);
	            }
	        }
   		}

    }
    
    function populateAllXTPL(&$xtpl, $view){
    	$this->populateXTPL($xtpl, $view);
    
	}
    
    function getAllFieldsView($view, $type){
		$results = array();
         foreach($this->bean->field_defs as $name=>$data){
	        if(empty($data['source']) || $data['source'] != 'custom_fields')continue;
	        require_once ('modules/DynamicFields/FieldCases.php');
	        $field = get_widget ( $data ['type'] );
	        $field->populateFromRow($data);
            $field->view = $view;
            $field->bean =& $this->bean;
            switch(strtolower($type)){
                case 'xtpl':
                    $results[$name] = array('xtpl'=>$field->get_xtpl());
                    break;
                case 'html':
                    $results[$name] = array('html'=> $field->get_html(), 'label'=> $field->get_html_label(), 'fieldType'=>$field->data_type, 'isCustom' =>true);
                    break;

            }

        }
        return $results;
    }
    
	////////////////////////////END BACKWARDS COMPATABILITY MODE FOR PRE 5.0 MODULES\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
}

?>
