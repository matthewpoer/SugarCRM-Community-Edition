<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 *********************************************************************************/

 require_once ('modules/ModuleBuilder/parsers/views/ListLayoutMetaDataParser.php') ;
 require_once ('modules/ModuleBuilder/parsers/views/SearchViewMetaDataParser.php') ;
 require_once 'modules/ModuleBuilder/parsers/constants.php' ;

 class DashletMetaDataParser extends ListLayoutMetaDataParser
 {

 	// Columns is used by the view to construct the listview - each column is built by calling the named function
 	public $columns = array ( 'LBL_DEFAULT' => 'getDefaultFields' , 'LBL_AVAILABLE' => 'getAdditionalFields' , 'LBL_HIDDEN' => 'getAvailableFields' ) ;

 	/*
 	 * Constructor
 	 * Must set:
 	 * $this->columns   Array of 'Column LBL'=>function_to_retrieve_fields_for_this_column() - expected by the view
 	 *
 	 * @param string moduleName     The name of the module to which this listview belongs
 	 * @param string packageName    If not empty, the name of the package to which this listview belongs
 	 */
 	 function __construct ($view, $moduleName , $packageName = '')
 	 {

 	 	$this->search = ($view == MB_DASHLETSEARCH) ? true : false;
 	 	$this->_moduleName = $moduleName;
 	 	$this->_packageName = $packageName;
 	 	if ($this->search)
 	 	{
 	 		$this->columns = array ( 'LBL_DEFAULT' => 'getAdditionalFields' , 'LBL_HIDDEN' => 'getAvailableFields' ) ;
 	 		parent::__construct ( MB_DASHLETSEARCH, $moduleName, $packageName ) ;
 	 	} else
 	 	{
 	 		parent::__construct ( MB_DASHLET, $moduleName, $packageName ) ;
 	 	}
 	 }

 	 /**
 	  * Dashlets contain both a searchview and list view definition, therefore we need to merge only the relevant info
 	  */
    function mergeFieldDefinitions ( $viewdefs, $fielddefs ) {

    	if ($_REQUEST['view'] == MB_DASHLETSEARCH && isset($viewdefs['searchfields']))
    	{
	    	//Remove any relate fields from the possible defs as they will break the homepage
    		foreach($fielddefs as $id=>$def) {
	    		if ($def['type'] == 'relate') {
	    			$fielddefs[$fielddefs[$id]['id_name']] = $def;
	    			unset($fielddefs[$id]);
	    		}
	    	}
    		$viewdefs = array_change_key_case($viewdefs['searchfields']);
    		$viewdefs = $this->_viewdefs = $this->convertSearchToListDefs($viewdefs);
    	}
    	else if ($_REQUEST['view'] == MB_DASHLET && isset($viewdefs['columns']))
    	{
    		$viewdefs = $this->_viewdefs = array_change_key_case($viewdefs['columns']);
    		$viewdefs = $this->_viewdefs = $this->convertSearchToListDefs($viewdefs);
    	}

    	return parent::mergeFieldDefinitions($viewdefs, $fielddefs);
    }

    function convertSearchToListDefs($defs) {
    	$temp = array();
    	foreach($defs as $key=>$value) {
    		$temp[$key] = $value;
    		if (!isset ($temp[$key]['name'])) {
    			$temp[$key]['name'] = $key;
    		}
    	}
    	return $temp;
    }

 	private function ConvertSearchToDashletDefs($defs) {
		$temp = array();
    	foreach($defs as $key=>$value) {
    		if($value['default']) {
    			//$temp[$key] = $value;
    			$temp[$key] = array('default' => '');
    		}
    	}
    	return $temp;
    }

    function handleSave ()
    {
    	$file = $this->implementation->getFileName(MB_DASHLET, $this->_moduleName, $this->_packageName);
    	$this->implementation->_history->append ( $file ) ;
    	$this->_populateFromRequest() ;
    	$out = "<?php\n" ;

    	require($file);

    	$dashletName = $this->implementation->module->key_name . 'Dashlet';
    	if (!isset($dashletData[$dashletName])) {
    		sugar_die ("unable to load Module Dashlet Definition");
    	}
    	if ($fh = sugar_fopen ( $file, 'w' ))
    	{
    		if ($_REQUEST['view'] == MB_DASHLETSEARCH)
    		{
    			$dashletData[$dashletName]['searchFields'] = $this->ConvertSearchToDashletDefs($this->_viewdefs);
    		} else
    		{
    			$dashletData[$dashletName]['columns'] = $this->_viewdefs;
    		}
    		$out .= "\$dashletData['$dashletName']['searchFields'] = " . var_export_helper ($dashletData[$dashletName]['searchFields']) . ";\n";
    		$out .= "\$dashletData['$dashletName']['columns'] = " . var_export_helper ($dashletData[$dashletName]['columns']) . ";\n";
    		fputs ( $fh, $out) ;
    		fclose ( $fh ) ;
    	}
    }
 }
 ?>
