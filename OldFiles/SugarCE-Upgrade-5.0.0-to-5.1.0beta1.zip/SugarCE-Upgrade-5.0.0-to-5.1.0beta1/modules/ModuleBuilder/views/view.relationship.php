<?php
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/
require_once ('modules/ModuleBuilder/MB/AjaxCompose.php') ;
require_once ('modules/ModuleBuilder/MB/ModuleBuilder.php') ;
require_once ('modules/ModuleBuilder/Module/StudioModule.php') ;
require_once ('modules/ModuleBuilder/Module/StudioBrowser.php') ;
require_once ('modules/ModuleBuilder/parsers/constants.php') ;
require_once 'modules/ModuleBuilder/parsers/relationships/RelationshipFactory.php' ;

class ViewRelationship extends SugarView
{

    function ViewRelationship ()
    {
        parent::SugarView () ;
    }

    function overrideDefinitionFromPOST ($definition)
    {
        require_once 'modules/ModuleBuilder/parsers/relationships/AbstractRelationship.php' ;
        foreach ( AbstractRelationship::$definitionKeys as $key )
        {
            if (! empty ( $_POST [ $key ] ))
            {
                $definition [ $key ] = $_POST [ $key ] ;
            }
        }
        return $definition ;
    }

    function display ()
    {
        $this->smarty = new Sugar_Smarty ( ) ;
        $ac = new AjaxCompose ( ) ;
        $this->fromModuleBuilder = isset ( $_REQUEST [ 'MB' ] ) || (isset ( $_REQUEST [ 'view_package' ] ) && $_REQUEST [ 'view_package' ] != 'studio') ;
        $this->smarty->assign ( 'fromModuleBuilder', $this->fromModuleBuilder ) ;
        
        if (empty ( $_REQUEST [ 'view_package' ] ))
        {
            $module = new StudioModule ( $_REQUEST [ 'view_module' ] ) ;
            $moduleName = $_REQUEST [ 'view_module' ] ;
            $fields = $module->fields ;
            require_once 'modules/ModuleBuilder/parsers/relationships/DeployedRelationships.php' ;
            $relatableModules = DeployedRelationships::findRelatableModules () ;
        } else
        {
            $mb = new ModuleBuilder ( ) ;
            $module = $mb->getPackageModule ( $_REQUEST [ 'view_package' ], $_REQUEST [ 'view_module' ] ) ;
            $moduleName = $module->package_key . '_' . $_REQUEST [ 'view_module' ] ;
            $this->smarty->assign ( 'view_package', $_REQUEST [ 'view_package' ] ) ;
            $mbvardefs = $module->getVardefs () ;
            $fields = $mbvardefs [ 'fields' ] ;
            require_once 'modules/ModuleBuilder/parsers/relationships/UndeployedRelationships.php' ;
            $relatableModules = UndeployedRelationships::findRelatableModules () ;
        }
        
        $lhs_subpanels = $module->getProvidedSubpanels () ;
        
        $cardinality = array ( MB_ONETOONE => translate ( 'LBL_ONETOONE' ) , MB_ONETOMANY => translate ( 'LBL_ONETOMANY' ) , MB_MANYTOMANY => translate ( 'LBL_MANYTOMANY' ) ) ;
        $relationships = $module->getRelationships () ;
        
        // if a description for this relationship already exists, then load it so it can be modified
        if (! empty ( $_REQUEST [ 'relationship_name' ] ))
        {
            $relationship = $relationships->get ( $_REQUEST [ 'relationship_name' ] ) ;
            $definition = $relationship->getDefinition();
        } else
        {
            $definition = array ( ) ;
            $firstModuleDefinition = each ( $relatableModules ) ;
            $definition [ 'rhs_module' ] = $firstModuleDefinition [ 'key' ] ;
            $definition [ 'lhs_module' ] = $moduleName ;
        }
        // load the relationship from post - required as we can call view.relationship.php from Ajax when changing the rhs_module for example           
        $definition = $this->overrideDefinitionFromPOST ( $definition ) ;
        $relationship = RelationshipFactory::newRelationship ( $definition ) ;
        
        $rhs_subpanels = $relatableModules [ $relationship->rhs_module ] ;
        
        if (empty ( $_REQUEST [ 'relationship_name' ] ))
        {
            // tidy up the options for the view based on the modules participating in the relationship and the cardinality
            // some modules (e.g., Knowledge Base/KBDocuments) lack subpanels. That means they can't be the lhs of a 1-many or many-many, or the rhs of a many-many for example          

            // fix up the available cardinality options
            $relationship_type = $relationship->getType () ;
            if (count ( $lhs_subpanels ) == 0 || count ( $rhs_subpanels ) == 0)
            {
                unset ( $cardinality [ MB_MANYTOMANY ] ) ;
            }
            if (count ( $rhs_subpanels ) == 0)
            {
                unset ( $cardinality [ MB_ONETOMANY ] ) ;
            }

            if (! isset($cardinality[$relationship->getType()]))
            {
                end ($cardinality) ;
                $definition [ 'relationship_type' ] = key ( $cardinality ) ;
                $relationship = RelationshipFactory::newRelationship ( $definition ) ;
            }
        }
        
        // now enforce the relationship_only requirement - that is, only construct the underlying relationship and link fields, and not the UI, if the subpanel code will have troubles displaying the UI                
        $relationships->enforceRelationshipOnly ( $relationship ) ;
        
        $this->smarty->assign ( 'rel', $relationship->getDefinition () ) ;
        $this->smarty->assign ( 'mod_strings', $GLOBALS [ 'mod_strings' ] ) ;
        $this->smarty->assign ( 'module_key', $relationship->lhs_module ) ;
        $this->smarty->assign ( 'module', $module ) ;
        $this->smarty->assign ( 'cardinality', array_keys ( $cardinality ) ) ;
        $this->smarty->assign ( 'translated_cardinality', $cardinality ) ;
        $this->smarty->assign ( 'selected_cardinality', translate ( $relationship->getType () ) ) ;
        
        $relatable = array ( ) ;
        foreach ( $relatableModules as $moduleName => $dummy )
        {
            $relatable [ $moduleName ] = translate ( $moduleName ) ;
        }
        natcasesort ( $relatable ) ;
        $this->smarty->assign ( 'relatable', array_keys ( $relatable ) ) ;
        $this->smarty->assign ( 'translated_relatable', $relatable ) ;
        $this->smarty->assign ( 'rhspanels', $rhs_subpanels ) ;
        $this->smarty->assign ( 'lhspanels', $lhs_subpanels ) ;
        
        switch ( $relationship->relationship_type)
        {
            case MB_ONETOONE :
                break ;
            
            case MB_ONETOMANY :
                if (empty ( $relationship->relationship_column_name ))
                {
                    $validRoleColumnFields = array ( ) ;
                    foreach ( $fields as $field )
                    {
                        $validRoleColumnFields [] = $field ;
                    }
                    $this->smarty->assign ( 'relationship_role_column_enum', $validRoleColumnFields ) ;
                }
                if (! empty ( $relationship->relationship_role_column_value ))
                    $this->smarty->assign ( 'relationship_role_column_value', $relationship->relationship_role_column_value ) ;
                break ;
            case MB_MANYTOMANY :
                if (! empty ( $relationship->relationship_role_column_value ))
                    $this->smarty->assign ( 'relationship_role_column_value', $relationship->relationship_role_column_value ) ;
                break ;
        }
        
        //see if we use the new system
        if (isset ( $_REQUEST [ 'json' ] ) && $_REQUEST [ 'json' ] == 'false')
        {
            echo $this->smarty->fetch ( 'modules/ModuleBuilder/tpls/studioRelationship.tpl' ) ;
        } else
        {
            $ac->addSection ( 'east', $module->name . ' ' . $GLOBALS [ 'mod_strings' ] [ 'LBL_RELATIONSHIPS' ], $this->smarty->fetch ( 'modules/ModuleBuilder/tpls/studioRelationship.tpl' ) ) ;
            echo $ac->getJavascript () ;
        }
    }

}
