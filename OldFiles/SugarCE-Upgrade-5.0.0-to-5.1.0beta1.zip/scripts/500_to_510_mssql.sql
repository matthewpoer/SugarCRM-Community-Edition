-- MSSQL upgrade script for Sugar 5.0.0 to 5.1.0

--
-- TABLES modified from 500 to 510
--
-- import maps
ALTER TABLE import_maps alter column name varchar(254);
ALTER TABLE import_maps add enclosure varchar(1) NOT NULL;
ALTER TABLE import_maps add delimiter varchar(1) NOT NULL;
ALTER TABLE import_maps add default_values image;

-- inbound email
ALTER TABLE inbound_email alter column mailbox text NOT NULL;
-- project task
 ALTER TABLE project_task add  status varchar(255)  NULL;
 ALTER TABLE project_task add  order_number int default '1';
 ALTER TABLE project_task add  task_number int  default NULL;
 ALTER TABLE project_task add  estimated_effort int  default NULL;
 ALTER TABLE project_task add  utilization int default '100';

-- tracker table changes

ALTER TABLE tracker add monitor_id varchar(36) NULL;




ALTER TABLE tracker add deleted tinyint default '0';
ALTER TABLE tracker alter column session_id varchar(36) NULL;

















































































