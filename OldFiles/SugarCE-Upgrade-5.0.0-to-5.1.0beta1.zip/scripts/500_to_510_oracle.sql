-- ORACLE upgrade script for Sugar 5.0.0 to 5.1.0

--
-- TABLES modified from 500 to 510
--
-- import maps
ALTER TABLE IMPORT_MAPS MODIFY(name VARCHAR2(100));
ALTER TABLE IMPORT_MAPS ADD(enclosure VARCHAR2(1) DEFAULT '' NOT NULL);
ALTER TABLE IMPORT_MAPS ADD(delimiter VARCHAR2(1)  DEFAULT '' NOT NULL);
ALTER TABLE IMPORT_MAPS ADD(default_values CLOB);


-- inbound email  to do
-- ALTER TABLE inbound_email modify column mailbox text NOT NULL;
-- project task
ALTER TABLE project_task add status varchar(255)  NULL;
ALTER TABLE project_task add order_number NUMBER  default '1';
ALTER TABLE project_task add task_number NUMBER  default NULL;
ALTER TABLE project_task add estimated_effort NUMBER default NULL;
ALTER TABLE project_task add utilization NUMBER default '100';

-- tracker table changes
ALTER TABLE tracker add monitor_id VARCHAR2(36) NULL;
ALTER TABLE tracker add team_id VARCHAR2(36) NULL;
ALTER TABLE tracker add deleted NUMBER(1,0) DEFAULT '0' NULL;
ALTER TABLE tracker modify (session_id VARCHAR2(36));

ALTER TABLE saved_reports modify(name varchar2(255));


CREATE TABLE REPORT_CACHE (
  ID varchar2(36) NOT NULL,
  assigned_user_id varchar2(36) NOT NULL,
  contents clob,
  deleted varchar2(1) default '' NOT NULL ,
  date_entered date NOT NULL,
  date_modified date NOT NULL,
  PRIMARY KEY  (ID,assigned_user_id,deleted)
);


CREATE TABLE TRACKER_PERF (
  ID NUMBER NOT NULL ENABLE,
  monitor_id varchar2(36) NOT NULL,
  server_response_time NUMBER default NULL,
  db_round_trips NUMBER default NULL,
  files_opened NUMBER default NULL,
  memory_usage number default NULL,
  DELETED NUMBER(1,0) DEFAULT '0',
  date_modified date,
  CONSTRAINT "trackerperfPK" PRIMARY KEY ("ID") ENABLE
);
CREATE INDEX  "idx_tracker_perf_mon_id" ON  tracker_perf (monitor_id);
CREATE SEQUENCE "TRACKER_PERF_ID_SEQ";
--
-- Table structure for table tracker_queries
--

CREATE TABLE TRACKER_QUERIES (
  ID NUMBER NOT NULL enable,
  query_id VARCHAR2(36) NOT NULL,
  text CLOB,
  query_hash varchar2(36) default NULL,
  sec_total number default NULL,
  sec_avg number default NULL,
  run_count number default NULL,
  deleted number default '0',
  date_modified date default NULL,
  PRIMARY KEY  (ID)
);
CREATE INDEX  "idx_tracker_queries_query_hash" ON  tracker_queries (query_hash);
CREATE SEQUENCE "TRACKER_QUERIES_ID_SEQ";
--
-- Table structure for table tracker_sessions
--

CREATE TABLE TRACKER_SESSIONS (
  ID NUMBER NOT NULL enable,
  session_id varchar2(36) default NULL,
  date_start date default NULL,
  date_end date default NULL,
  seconds NUMBER default '0',
  client_ip varchar2(20) default NULL,
  user_id varchar2(36) default NULL,
  active NUMBER(1,0) default '1',
  round_trips NUMBER default NULL,
  deleted NUMBER(1,0) default '0',
  PRIMARY KEY  (ID)
);
CREATE INDEX  "idx_tracker_sessions_s_id" ON  tracker_sessions (session_id);
CREATE SEQUENCE "TRACKER_SESSIONS_ID_SEQ";
--
-- Table structure for table tracker_tracker_queries
--
CREATE TABLE TRACKER_TRACKER_QUERIES (
  ID NUMBER NOT NULL ENABLE,
  monitor_id varchar2(36) default NULL,
  query_id varchar2(36) default NULL,
  date_modified date default NULL,
  PRIMARY KEY  (ID)
);

CREATE INDEX  "idx_tracker_tq_monitor" ON  tracker_tracker_queries (monitor_id);
CREATE INDEX  "idx_tracker_tq_query" ON  tracker_tracker_queries (query_id);
CREATE SEQUENCE "TRACKER_TRACKER_QUERIES_ID_SEQ";
