-- MySQL upgrade script for Sugar 5.0.0 to 5.1.0

--
-- TABLES modified from 500 to 510
--
-- import maps
ALTER TABLE `import_maps` modify column `name` varchar(254) NOT NULL,
                          add column `enclosure` varchar(1) NOT NULL default ' ',
                          add column `delimiter` varchar(1) NOT NULL default ',',
                          add column `default_values` blob;


-- inbound email
ALTER TABLE `inbound_email` modify column `mailbox` text NOT NULL;
-- project task
ALTER TABLE `project_task` add column `status` varchar(255)  NULL,
                           add column `order_number` int(11)  default '1',
                           add column `task_number` int(11)  default NULL,
                           add column `estimated_effort` int(11)  default NULL,
                           add column `utilization` int(11)  default '100';

-- tracker table changes
ALTER TABLE `tracker` add column `monitor_id` char(36)  NULL,



                      add column deleted tinyint(1)default '0',
                      modify column session_id varchar(36) NULL;





















































































