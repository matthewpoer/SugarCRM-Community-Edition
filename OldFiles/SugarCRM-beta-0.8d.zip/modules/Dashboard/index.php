<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1
 * ("License"); You may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Dashboard/index.php,v 1.9 2004/06/23 05:31:07 sugarjacob Exp $
 * Description:  Main file for the Home module.
 ********************************************************************************/

global $theme;
global $currentModule;
$theme_path="themes/".$theme."/";
$image_path=$theme_path."images/";
require_once($theme_path.'layout_utils.php');
require_once('modules/Opportunities/Opportunity.php');
require_once('data/SugarBean.php');
require_once('include/logging.php');

$list_form=new XTemplate ('modules/Opportunities/ListViewTopTen.html');
$list_form->assign("THEME", $theme);
$list_form->assign("IMAGE_PATH", $image_path);
$list_form->assign("MODULE_NAME", $currentModule);


$log = LoggerManager::getLogger('date_list');

$datax = Array();
$opp = new Opportunity();
$where = '';



if (isset($_REQUEST['choice'])) {
	$choice=$_REQUEST['choice'];
 	$log->debug("foreach2 is: ".$t);
 	$log->debug("foreach3 is: ".$choice);
	if ($choice){
		$where='1=2';
	 foreach ($choice as $t)
	 {
	   $log->debug("foreach1 is: ".$t);
	   $where = $where . ' or sales_stage="'.$t. '"'; 
	//   echo $where ,'<br>';
	 }
	}
}	
if (isset($_REQUEST['test'])) {
	$test=$_REQUEST['test'];
	if ($test){
	 foreach ($test as $t){echo 'You selected ',$t,'<br />';}
	}
}
	
	
if(isset($_REQUEST['query']))
{
	// we have a query
		if (isset($_REQUEST['date_start'])) $date_start = $_REQUEST['date_start'];
		if (isset($_REQUEST['date_end'])) $date_end = $_REQUEST['date_end'];
		
		//	$opp_list = $opp->get_full_list("amount DESC, date_closed DESC", $where); ./.
		
		//$temp_where = $where." date_entered >". $_REQUEST['date_start'] "and date_closed <". $_REQUEST['date_end'];
		$where = $where." date_entered > '".$date_start. "' and date_closed <  '".$date_end."'";
		//$where = $where." date_entered > ". '$date_start' . " and date_closed < ". '$date_end';
		//$where = $where." date_entered > '2004-05-01' and date_closed < '2004-05-30'";
		$log->debug("where clause is: ".$where);
		$log->debug("it is date end: ".$date_end);
			$log->debug("it is date start: ".$date_start);
		
}
//echo $_REQUEST['query'];



//$log " Where = ".$where;
$opp_list = $opp->get_full_list("amount DESC, date_closed DESC", $where);

//$opp_list = $opp->get_full_list("amount DESC, date_closed DESC");
//build pipeline by sales stage data
$i = 0;
if (isset($opp_list)) {
	foreach ($opp_list as $record) {
		$i = $i + 1;	
		if (!isset($sum[$record->sales_stage])) 
		{
			array_push($datax, $record->sales_stage);
			$sum[$record->sales_stage] = 0;
		}
		if (isset($record->amount))	$sum[$record->sales_stage] = $sum[$record->sales_stage] + $record->amount;  
		//$log->debug("record->amount is '$record->amount' and record->sales_stage is '$record->sales_stage' and sum[$record->sales_stage] is ".$sum[$record->sales_stage]); 
	}
}

//echo " i=".$i; 
//$datax =& $opp->sales_stage_dom;
$datay = Array();
//$log->debug("s is : ".$opp->sales_stage_dom);

//foreach ($opp->sales_stage_dom as $stage) {
foreach($datax as $stage){
	array_push($datay, $sum[$stage]/1000);
}

//pipeline($datax,$datay); 
$flat_array1 = urlencode(implode(",",$datax));
$flat_array2 = urlencode(implode(",",$datay));

//build pipeline by lead source data
$total = 0;
if (isset($opp_list)) {
	foreach ($opp_list as $record) {
		if (!isset($sum[$record->lead_source])) $sum[$record->lead_source] = 0;
		if (isset($record->amount) && isset($record->lead_source))	{
			$sum[$record->lead_source] = $sum[$record->lead_source] + ($record->amount/1000);  
			$total = $total + ($record->amount/1000);
		}
	//	$log->debug("record->amount is '$record->amount' and record->lead_source is '$record->lead_source' and sum[$record->lead_source] is ".$sum[$record->lead_source]); 
	}
}

$legends =& $opp->lead_source_dom;
$legends[array_search('', $legends)] = 'None'; 

$data= Array();
foreach ($opp->lead_source_dom as $lead_source) {
	//$percent = $sum[$lead_source]/$total;
	if (isset($sum[$lead_source])) array_push($data, $sum[$lead_source]);
}					

//pipeline_by_lead_source($data,$legends, $title);
$data_string = urlencode(implode(",", $data));
$legends_string = urlencode(implode(",", $legends));

$title = urlencode("Total Pipeline is \$".$total."K");
$subtitle= urlencode("Opportunity size in $1K");


$flat_array1 = urlencode(implode(",",$datax));



?>
<table cellpadding="5" cellspacing="5" border="0" align="left">
<tr>

<td valign="top">
<form action="" method="post">
<select name="choice[]" multiple size="5" >

<?php

//SELECT * FROM $this->table_name
$opp = new Opportunity();
//$query = "select sales_stage from opportunities where sales_stage = $opp->sales_stage_dom";
$query = "select distinct sales_stage from opportunities order by sales_stage";
$result = mysql_query ($query);
$log->debug("result is : ".$result);

//$log->debug("lising is : ".$opp->sales_stage_dom);
while ($row = mysql_fetch_row($result))
{
  printf("<option value='%s'> %s </option>", $row[0],$row[0]);
}
?>
	
	
</select>
<br>
<br>
<input type="submit" class="button" value="View Graph" />
<input type="submit" class="button" value="Search All" />


</form>
<td>
<form action="" method="post" >
  <p class="dataLabel" noWrap>
Date Stared:<br>
    <input name='date_start' size='15' type="text" class=dataField value='Enter Start Date'>

  </p>
  <p class="dataLabel" noWrap>
Date Ended:<br>
<input  name='date_end' size='15' type="text" class=dataField value='Enter End Date'>
			<input type="hidden" name="query" value="true"/>
  <br>
  <?php
//$query = "select date_entered,date_closed from opportunities where date_entered >".$date_start."and date_closed<". $date_end;
//$result = mysql_query ($query);
?>
  
  
  <input class="button" type="submit" name="Search" value="Search"/></p>
</form>
<p>

</p>

</td>

</tr>
</table>
<p><br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
</p>




<p>
<br>
</p>
























<table cellpadding="5" cellspacing="5" border="0">
<tr>

<td valign="top">
	<?php echo get_left_form_header("My Pipeline");
    echo "<img src='graph.php?module=Opportunities&action=Charts&graph=pipeline&flat_array1=".$flat_array1."&flat_array2=".$flat_array2."&title=".$title."&subtitle=".$subtitle."' border=0 align=top>\n";
	echo get_left_form_footer();?></td>
<td valign="top">
	<?php 
	echo get_left_form_header("My Pipeline By Lead Source");
    echo "<img src='graph.php?module=Opportunities&action=Charts&graph=pipeline_by_lead_source&flat_array1=".$flat_array1."&flat_array2=".$flat_array2."&title=&subtitle=".$subtitle."' border=0 align=top>\n";
   	?>
	</td></tr></table>
<p>&nbsp;</p>
<table>


	<?php echo get_form_footer();?>
</td>
</tr><tr>		

</tr>
</table>
