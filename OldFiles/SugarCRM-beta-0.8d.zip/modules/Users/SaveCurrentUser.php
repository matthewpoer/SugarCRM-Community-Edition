<?php 
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1
 * ("License"); You may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Users/SaveCurrentUser.php,v 1.4 2004/06/23 05:31:08 sugarjacob Exp $
 * Description: Saves current user data.
 ********************************************************************************/

global $theme;

require_once('themes/'.$theme.'/layout_utils.php');
require_once('modules/Users/User.php');

require_once('include/logging.php');
$log = LoggerManager::getLogger('user_save');

global $current_user;

if(!isset($current_user))
  $log->info("No user currently in current_user.");

foreach($current_user->column_fields as $field)
{
	if(isset($_REQUEST[$field]))
	{
		$value = $_REQUEST[$field];
		$current_user->$field = $value;
	}
}

$current_user->save();

// save the user's theme selection in the session.
$authenticated_user_theme = $current_user->theme;

header("Location: index.php?module=Users&action=index");
?>