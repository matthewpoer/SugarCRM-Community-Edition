<?php
/**
 * Upgrade the Popups
 *
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */
 
// $Id: upgradepopups.php,v 1.9 2005/08/26 04:09:20 roger Exp $

$editview_replace = array();
$listview_replace = array();

$editview_replace[] = array(
	'modules/Accounts/EditView.html',
	"onclick='return window.open(\"index.php?module=Accounts&action=Popup&form=TasksEditView&form_submit=false\",\"test\",\"width=600,height=400,resizable=1,scrollbars=1\");'",
	"onclick='open_popup(\"Accounts\", 600, 400, \"\", true, false, {encoded_popup_request_data});'",
);

$editview_replace[] = array(
	'modules/Cases/EditView.html',
	"onclick='return window.open(\"index.php?module=Accounts&action=Popup&html=Popup_picker&form=EditView&form_submit=false\",\"test\",\"width=600,height=400,resizable=1,scrollbars=1\");'",
	"onclick='open_popup(\"Accounts\", 600, 400, \"\", true, false, {encoded_popup_request_data});'",
);

$editview_replace[] = array(
	'modules/Contacts/EditView.html',
	"onclick='return window.open(\"index.php?module=Accounts&action=Popup&form=EditView&form_submit=false\",\"test\",\"width=600,height=400,resizable=1,scrollbars=1\");'",
	"onclick='open_popup(\"Accounts\", 600, 400, \"\", true, false, {encoded_account_popup_request_data});'",
);

$editview_replace[] = array(
	'modules/Contacts/EditView.html',
	"onclick='return window.open(\"index.php?module=Contacts&action=Popup&html=Popup_picker&form=ContactEditView{DEFAULT_SEARCH}\",\"test\",\"width=600,height=400,resizable=1,scrollbars=1\");'",
	"onclick='open_popup(\"Contacts\", 600, 400, \"{DEFAULT_SEARCH}\", true, false, {encoded_contact_popup_request_data});'",
);

$editview_replace[] = array(
	'modules/Employees/EditView.html',
	"onclick='return window.open(\"index.php?module=Employees&action=Popup&form=EmployeesEditView&form_submit=false\",\"test\",\"width=600,height=400,resizable=1,scrollbars=1\");'",
	"onclick='open_popup(\"Employees\", 600, 400, \"\", true, false, {encoded_popup_request_data});'",
);

$editview_replace[] = array(
	'modules/Notes/EditView.html',
	"onclick='return window.open(\"index.php?module=Contacts&action=Popup&html=Popup_picker&form=EditView{DEFAULT_SEARCH}\",\"test\",\"width=600,height=400,resizable=1,scrollbars=1\");'",
	"onclick='open_popup(\"Contacts\", 600, 400, \"\", true, false, {encoded_contact_popup_request_data});'",
);

$editview_replace[] = array(
	'modules/Notes/EditView.html',
	"{CHANGE_PARENT_BUTTON}",
	"<input type=\"button\" name=\"button\" class=\"button\" tabindex=\"2\" title=\"{APP.LBL_SELECT_BUTTON_TITLE}\" accesskey=\"{APP.LBL_SELECT_BUTTON_KEY\" value=\"{APP.LBL_SELECT_BUTTON_LABEL}\" onclick='open_popup(document.EditView.parent_type.value, 600, 400, \"{DEFAULT_SEARCH}\", true, false, {encoded_popup_request_data});' />",
);

$editview_replace[] = array(
	'modules/Opportunities/EditView.html',
	"onclick='return window.open(\"index.php?module=Accounts&action=Popup&html=Popup_picker&form=EditView&form_submit=false\",\"test\",\"width=600,height=400,resizable=1,scrollbars=1\");'",
	"onclick='open_popup(\"Accounts\", 600, 400, \"\", true, false, {encoded_popup_request_data});'",
);



























































$editview_replace[] = array(
	'modules/ProjectTask/EditView.html',
	"onclick=\"return window.open('index.php?module=ProjectTask&action=Popup&form=EditView&query=true&parent_id={parent_id}&form_parent_id=depends_on_id&form_parent_name=depends_on_name&form_submit=false','test','width=600,height=400,resizable=1,scrollbars=1');\"",
	"onclick='open_popup(\"ProjectTask\", 600, 400, \"&project_id={parent_id}\", true, false, {encoded_depends_on_popup_request_data});'",
);

$editview_replace[] = array(
	'modules/ProjectTask/EditView.html',
	"onclick=\"return window.open('index.php?module=Project&action=Popup&form=EditView&form_submit=false','test','width=600,height=400,resizable=1,scrollbars=1');\"",
	"onclick='open_popup(\"Project\", 600, 400, \"\", true, false, {encoded_parent_popup_request_data});'",
);

$editview_replace[] = array(
	'modules/Tasks/EditView.html',
	"{CHANGE_PARENT_BUTTON}",
	"<input type=\"button\" name=\"button\" class=\"button\" tabindex=\"2\" title=\"{APP.LBL_SELECT_BUTTON_TITLE}\" accesskey=\"{APP.LBL_SELECT_BUTTON_KEY\" value=\"{APP.LBL_SELECT_BUTTON_LABEL}\" onclick='open_popup(document.EditView.parent_type.value, 600, 400, \"\", true, false, {encoded_popup_request_data});' />",
);

$editview_replace[] = array(
	'modules/Tasks/EditView.html',
	"onclick='return window.open(\"index.php?module=Contacts&action=Popup&html=Popup_picker&form=EditView{DEFAULT_SEARCH}\",\"test\",\"width=600,height=400,resizable=1,scrollbars=1\");'",
	"onclick='open_popup(\"Contacts\", 600, 400, \"\", true, false, {encoded_contact_popup_request_data});'",
);

$editview_replace[] = array(
	'modules/Releases/ListView.html',
	"{RELEASE.STATUS}",
	"{RELEASE.ENCODED_STATUS}",
);


//DetailView
$detailview_replace = array('modules' => array('Accounts',
											'Bugs',
											'Campaigns',
											'Cases',
											'Contacts',
											'Documents',
											'EmailTemplates',
											'Employees',
											'Leads',
											'Notes',
											'Opportunities',
											'Products',
											'ProductTemplates',
											'Project',
											'ProjectTask',
											'Prospects',
											'Quotes',
											'Roles',
											'Tasks',
											'Teams'),
					"class=\"tabDetailView\">",
					"{PAGINATION}");
					
//ListView
$listview_replace = array();
$listview_replace[] = array('Accounts','Account','ACCOUNT');
$listview_replace[] = array('Bugs','Bug','BUG');
$listview_replace[] = array('Cases','Case','CASE');
$listview_replace[] = array('Contacts','Contact','CONTACT');
$listview_replace[] = array('Documents','Document','DOCUMENT');
$listview_replace[] = array('EmailTemplates','EmailTemplate','EMAIL_TEMPLATE');
$listview_replace[] = array('Employees','Employee','EMPLOYEE');
$listview_replace[] = array('Leads','Lead','LEAD');
$listview_replace[] = array('Notes','Note','NOTE');
$listview_replace[] = array('Opportunities','Opportunity','OPPORTUNITY');
$listview_replace[] = array('Products','Product','PRODUCT');
$listview_replace[] = array('ProductTemplates','ProductTemplate','PRODUCT_TEMPLATE');
$listview_replace[] = array('Project','Project','PROJECT');
$listview_replace[] = array('ProjectTask','ProjectTask','PROJECT_TASK');
$listview_replace[] = array('Prospects','Prospect','PROSPECT');
$listview_replace[] = array('Quotes','Quote','QUOTE');
$listview_replace[] = array('Roles','Role','ROLE');
$listview_replace[] = array('Tasks','Task','TASK');
$listview_replace[] = array('Teams','Team','TEAM');


$pagination_listview_tag = array('Accounts',
						'Bugs',
						'Campaigns',
						'Cases',
						'Contacts',
						'Currencies',
						'Documents',
						'EmailMan',
						'EmailTemplates',
						'Employees',
						'Feeds',
						'Forecasts',
						'Leads',
						'Manufacturers',
						'Notes',
						'Opportunities',
						'ProductCategories',
						'Products',
						'ProductTemplates',
						'ProductTypes',
						'Project',
						'ProjectTask',
						'ProspectLists',
						'Prospects',
						'Quotes',
						'Reports',
						'Roles',
						'Tasks',
						'Teams',
						'TimePeriods');

//Popup Replace
$files_processed = array();
foreach($editview_replace as $html){
	if(filesize($html[0]) > 0){
		//0 is file
		//1 is from
		//2 is to
		$fp = fopen($html[0], 'r');
		
		$contents = fread($fp, filesize($html[0]));
		fclose($fp);
		echo 'Changing <code>' . htmlspecialchars($html[1]) . '</code> to <code>' . htmlspecialchars($html[2]) . '</code><br>';  
		
		if(!isset($files_processed[$html[0]] )){
			$contents = str_replace('<!-- BEGIN: main -->', "<!-- BEGIN: main -->\n".'<script type="text/javascript" src="include/javascript/popup_parent_helper.js"></script>', $contents);
		}
		$contents = str_replace($html[1], $html[2], $contents);
		$fp = fopen($html[0], 'w');
		fwrite($fp, $contents);
		fclose($fp);
		echo 'Updated ' . $html[0] . '<br>';
		$files_processed[$html[0]] =1 ;
	}
	
		
}

//DetailView Replace
foreach($detailview_replace['modules'] as $module_name){
	$fileName = 'modules/'.$module_name.'/DetailView.html';
	
	if(filesize($fileName) > 0){
		//0 is file
		//1 is from
		//2 is to
		$fp = fopen($fileName, 'r');
		
		$contents = fread($fp, filesize($fileName));
		fclose($fp);

		//make sure PAGINATION is not already in the file
		$pattern = '/'.$detailview_replace[1].'/';
		preg_match($pattern, $contents, $matches);
		
		if(count($matches) <= 0){
			$contents = str_replace($detailview_replace[0], $detailview_replace[0]."\n".$detailview_replace[1], $contents);
			echo 'Updated ' . $fileName . '<br>';
		}
		$fp = fopen($fileName, 'w');
		fwrite($fp, $contents);
		fclose($fp);
	}		
}

//ListView Replace
foreach($listview_replace as $module_dir){
	$fileName = 'modules/'.$module_dir[0].'/ListView.html';

	$module_name = $module_dir[1];
	if(filesize($fileName) > 0){
		//0 is file
		//1 is from
		//2 is to
		$fp = fopen($fileName, 'r');
		
		$contents = fread($fp, filesize($fileName));
		fclose($fp);
		$upperModuleName = $module_dir[2];
		$url_pattern = "index.php?action=DetailView&module=".$module_dir[0]."&record={".$upperModuleName.".ID}";
		
		$addition = "&offset={".$upperModuleName.".OFFSET}&stamp={".$upperModuleName.".STAMP}";
		
		//make sure STAMP is not already in the file
		$pattern = '/STAMP/';
		preg_match($pattern, $contents, $matches);
		
		if(count($matches) <= 0){
			$contents = str_replace($url_pattern, $url_pattern.$addition, $contents);
			echo 'Updated ' . $fileName . '<br>';
		}
		$fp = fopen($fileName, 'w');
		fwrite($fp, $contents);
		fclose($fp);
	}		
}

//Add Second Pagination Tag to ListView
//ListView Replace
foreach($listview_replace as $module_dir){
	$fileName = 'modules/'.$module_dir[0].'/ListView.html';

	$module_name = $module_dir[1];
	if(filesize($fileName) > 0){
		//0 is file
		//1 is from
		//2 is to
		$fp = fopen($fileName, 'r');
		
		$contents = fread($fp, filesize($fileName));
		fclose($fp);

		//make sure we only have one PAGINATION in the file
		$pattern = '/{PAGINATION}/';
		preg_match($pattern, $contents, $matches);
		
		if(count($matches) <= 1){
			$contents = str_replace("<!-- END: row -->", "<!-- END: row -->\n{PAGINATION}", $contents);
			echo 'Updated ' . $fileName . '<br>';
		}
		$fp = fopen($fileName, 'w');
		fwrite($fp, $contents);
		fclose($fp);
	}		
}


echo '<br>done';

?>
