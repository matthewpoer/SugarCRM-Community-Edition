Sugar Suite v3.5.0b
August 26, 2005

-=Overview=-
For a quick list of new features in Sugar Suite 3.5.0, check out the information 
below.

Our goal continues to be to build the customer relationship management system 
that you have always wanted, so your input is vital.

To share ideas with the Sugar Community, ask questions, find answers and submit 
feedback, please visit our Sugar Forums at http://www.sugarcrm.com/forums.

Check out http://www.sugarcrm.com for more details on acquiring the Sugar Suite, 
the latest product roadmap, support forums, detailed product information and 
much more.  We hope you find this a useful tool for building your business.

Enjoy! 
The Sugar Team  

--------------------------------------------------------------------------------
3.5.0b
--------------------------------------------------------------------------------
Note:   Sugar Suite now requires MySQL 4.0 or greater.  MySQL 3.x is no longer
        supported, due to architectural changes in Sugar that rely on MySQL 4.0
        or greater.
		
New:    Ability to upgrade to 3.5.0b from 2.5.1x or 3.0x.
New:    Ability to upgrade to 3.5.0b from 3.5.0a, using the Upgrade Wizard under 
        Admin.  If you are planning to upgrade using the Upgrade Wizard, you 
        must make the entire Sugar directory writable by your web server.  
        Failure to do so will result in an incomplete upgrade.

Fixed:  A security vulnerability has been resolved.
Fixed:  Sorting columns in subpanels produced MySQL errors.
Fixed:  Error in Product EditView when the Account name contains a comma.
Fixed:  Miscellaneous fixes for Imports.
Fixed:  Miscellaneous fixes for date formats.
Fixed:  The message body of an Email Template was not populating correctly after 
        upgrading to 3.5.0a.
Fixed:  Email notifications were not being sent for certain modules.
Fixed:  Miscellaneous fixes for URL formatting that prevented direct access to 
        some records.
Fixed:  Scheduling Calls and Meetings defaulted to yesterday's date instead of
        today's date.
Fixed:  Searching for a Contact in Calls ListView or Meetings ListView produced
        a MySQL error.
Fixed:  Module Loader unloads did not delete record relationships.
Fixed:  Email Marketing Campaigns DetailView produced a MySQL error for 
        non-admin users.
Fixed:  Immedietly canceling a Campaign produced an error.
Fixed:  Miscellaneous fixes for Email Marketing Campaigns.
Fixed:  Selecting a Contact in an Email produced a "File Not Found" error in 
        upgraded instances of Sugar Suite.  To manually apply this fix, copy the
        file modules/Contacts/Email_Picker.html from the Sugar Suite zip to your 
        upgraded instance.
Fixed:  Miscellaneous fixes for the Edit In Place option of the Studio.
Fixed:  Exporting a Bug Tracker ListView produced a MySQL error.
Fixed:  Activities subpanel produced a MySQL error after upgrading to 3.5.0a.
















--------------------------------------------------------------------------------
3.5.0a
--------------------------------------------------------------------------------
Special Upgrade Install:
The 3.5.0a release provides an upgrade script and instructions that automates 
many, but not all, of the steps necessary to migrate a 3.0.1x version of Sugar 
Suite to the 3.5.0a release. The instructions can be found with the 3.5 
download, in the file "Upgrade_Steps_to_Sugar_Open_Source_v3.5.rtf" located at 
http://www.sugarforge.org/frs/?group_id=6.

Note: 	3.5.0a is primarily a release to address issues with upgrading from 
		3.0.1x versions of Sugar Suite, and is not intended for use with the new 
		3.5.0 Upgrade Wizard functionality.
		
Note:   If you are upgrading from an earlier version of Sugar Suite, you will 
        need to clear your web browser cache in order for all subpanels and 
        popups to behave properly.
        
Note:   If you previously upgraded from 3.0.1x to 3.5.0, you must run
        http://HOST/SUGAR/upgrade/3.5.0_to_3.5.0a.php

Fixed:  Subpanels were not appearing in DetailViews after upgrading from 3.0.1x
        and executing Rebuild Relationships.
Fixed:  Subpanels were only referencing the US English language pack.
Fixed:  PHP and MySQL errors were displaying in subpanels after upgrading from
        3.0.1x, forcing an admin user to execute Rebuild Relationships.
Fixed:  References to 3.5.0beta were removed.
Fixed:  Miscellaneous errors preventing upgrades from 3.0.1x from completing 
        successfully.
Fixed:  MySQL error in Activities subpanel caused by incorrect parent_type in 
        archived emails.
Fixed:  Editing tab configuration system-wide was not saving.
Fixed:  Sugar Plug-in for Outlook will now honor the Private flag in Outlook 
        when synchronizing calendar entries and contacts from Sugar to Outlook.
Fixed:  Sugar Plug-in for Outlook no longer defaults Outlook's view to the 
        Contact SugarView.        








--------------------------------------------------------------------------------
3.5.0
--------------------------------------------------------------------------------
New:    Improved sub-panels now provide paging, sorting, and the ability to 
        expand and collapse each sub-panel.
New:    Upgrade Wizard that supports applying patches, full installs and themes.
New:    Module Loader that allows developers to package new modules that can be 
        installed on a Sugar server with a single point-and-click. This greatly
        enhances the community's and customers' ability to share new modules in 
        Sugar.
New:    HTML emails, enabling the use of embedded graphics and formatted text 
        both in single-use emails and in email marketing campaigns created and 
        managed through Sugar Suite.  This complements existing plain-text email 
        abilities and helps users attract the attention of prospects and 
        customers.
New:    Improved Sugar Plug-in for Outlook, offering faster navigation and 
        greater control over synchronization of contacts and calendars into 
        Sugar Suite.  Users can archive customer emails to a contact, 
        opportunity, lead or account with one click; transfer scheduled meeting
        information from Outlook to Sugar Suite through the Free/Busy Server 
        included with Sugar Suite; and more.
New:    View Change Log in detail views now provides a summary view of the data 
        changes.

















