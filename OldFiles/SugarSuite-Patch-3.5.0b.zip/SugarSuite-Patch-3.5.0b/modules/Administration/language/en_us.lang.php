<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

// $Id: en_us.lang.php,v 1.99 2005/08/26 21:46:16 andrew Exp $

$mod_strings = array (
	'LBL_MODULE_NAME' => 'Administration',
	'LBL_MODULE_TITLE' => 'Administration: Home',
	'LBL_NEW_FORM_TITLE' => 'Create Account',
	'LNK_NEW_USER' => 'Create User',
	'ERR_DELETE_RECORD' => 'A record number must be specified to delete the account.',
	'LBL_CONFIGURE_SETTINGS_TITLE' => 'Configure Settings',
	'LBL_CONFIGURE_SETTINGS' => 'Configure system-wide settings',
	'LBL_UPGRADE_TITLE' => 'Repair',
	'LBL_UPGRADE' => 'Check and repair Sugar Suite',
	'LBL_MANAGE_USERS_TITLE' => 'User Management',
	'LBL_MANAGE_USERS' => 'Manage user accounts and passwords',
	'LBL_ADMINISTRATION_HOME_TITLE' => 'System',
	'LBL_NOTIFY_TITLE' => 'Email Notification Options',
	'LBL_NOTIFY_FROMADDRESS' => '"From" Address:',
	'LBL_MAIL_SMTPSERVER' => 'SMTP Server:',
	'LBL_MAIL_SMTPPORT' => 'SMTP Port:',
	'LBL_MAIL_SENDTYPE' => 'Mail Transfer Agent:',
	'LBL_MAIL_SMTPUSER' => 'SMTP Username:',
	'LBL_MAIL_SMTPPASS' => 'SMTP Password:',
	'LBL_MAIL_SMTPAUTH_REQ' => 'Use SMTP Authentication?',
	'LBL_NOTIFY_SEND_BY_DEFAULT' => 'Send notifications by default?',
	'LBL_NOTIFY_SUBJECT' => 'Email subject:',
	'LBL_NOTIFY_ON' => 'Notifications on?',
	'LBL_NOTIFY_FROMNAME' => '"From" Name:',
	'LBL_CURRENCY' => 'Set up currencies and currency rates',
	'LBL_RELEASE' => 'Manage releases and versions',
	'LBL_LAYOUT' => 'Add, remove, change fields, and layout fields and panels across the application',
	'LBL_MANAGE_CURRENCIES' => 'Currencies',
	'LBL_MANAGE_RELEASES' => 'Releases',
	'LBL_MANAGE_LAYOUT' => 'Field Layout',
	'LBL_MANAGE_OPPORTUNITIES' => 'Opportunities',
	'LBL_UPGRADE_CURRENCY' => 'Upgrade currency amounts in ',
	'LBL_EDIT_CUSTOM_FIELDS' => 'Edit Custom Fields',
	'DESC_MODULES_QUEUED' => 'The following Modules are locally queued for installation:',
	'DESC_FILES_QUEUED' => 'The following Upgades are locally queued for installation:',
	'DESC_MODULES_INSTALLED' => 'The following Modules have been installed:',
	'DESC_FILES_INSTALLED' => 'The following Upgrades have been installed:',
	'DESC_EDIT_CUSTOM_FIELDS' => 'Edit the custom fields created for the Field Layout',
	'LBL_DROPDOWN_EDITOR' => 'Dropdown Editor',
	'DESC_DROPDOWN_EDITOR' => 'Add, delete, or change the dropdown lists in the application',
	'LBL_IFRAME'=> 'Portal',
	'DESC_IFRAME' => 'Add tabs which can display any web site',
	'LBL_BUG_TITLE' => 'Bug Tracker',
	'LBL_TIMEZONE' => 'Time Zone',
	'LBL_STUDIO_TITLE' => 'Studio',
	'LBL_UPLOAD_MODULE' => 'Upload a Module: ',
	'LBL_UPLOAD_UPGRADE' => 'Upload an Upgrade: ',
	'LBL_CONFIGURE_TABS' => 'Configure Tabs',
	'LBL_CHOOSE_WHICH'=>'Choose which tabs are displayed system-wide',
	'LBL_DISPLAY_TABS'=>'Display Tabs',
	'LBL_HIDE_TABS'=>'Hide Tabs',
	'LBL_EDIT_TABS'=>'Edit Tabs',
	'LBL_UPGRADE_DB_TITLE' => 'Upgrade database',
	'LBL_UPGRADE_DB' => 'Update the database from version 2.0.x to 2.5 ',
	'LBL_UPGRADE_DB_BEGIN' => 'Begining Upgrade',
	'LBL_UPGRADE_DB_COMPLETE' => 'Upgrade Complete',
	'LBL_UPGRADE_VERSION'=>'Updating version info',
	'LBL_UPGRADE_DB_FAIL' => 'Upgrade Failed',
	'LBL_FORECAST_TITLE'=> 'Forecast',
	'LBL_PORTAL_TITLE' => 'Customer Self-Service Portal',
	'LBL_PORTAL_ON' => 'Enable Self-Service Portal Integration?',
	'LBL_PORTAL_ON_DESC' => 'Allows Case, Note and other data to be accessible by an external customer self-service portal system.',
	'LBL_SKYPEOUT_TITLE' => 'SkypeOut&reg;',
	'LBL_SKYPEOUT_ON' => 'Enable SkypeOut&reg; Integration?',
	'LBL_SKYPEOUT_ON_DESC' => 'Allows users to click on phone numbers to call using SkypeOut&reg;. The numbers must be formatted properly to make use of this feature. This is it must be "+"  "The Country Code" "The Number" for more information on formatting see the <a href="http://www.skype.com/help/faq/skypeout.html#calling" target="skype">skype&reg; faq</a>    ',
	'LBL_NOTIFICATION_ON_DESC' => 'Sends notification emails when records are assigned.',
    'LBL_UPGRADE_WIZARD' => 'Upgrade Wizard to manage upgrades',
    'LBL_UPGRADE_WIZARD_TITLE' => 'Upgrade Wizard',
    'LBL_MODULE_LOADER' => 'Add or remove modules to Sugar',
    'LBL_MODULE_LOADER_TITLE' => 'Module Loader',
	'LBL_ALLOW_USER_TABS' => 'Allow users to configure tabs',
	'LBL_RENAME_TABS'=>'Rename Tabs',
	'LBL_CHANGE_NAME_TABS'=>'Change the label of the tabs.',
	'LBL_MASS_EMAIL_MANAGER_DESC'=> 'Manage the mass email queue',
	'LBL_MASS_EMAIL_MANAGER_TITLE'=> 'Mass Email Manager',
	'LBL_MANAGE_ROLES_TITLE' => 'Role Management',
	'LBL_MANAGE_ROLES' => 'Manage role membership and properties',
    'LBL_BACKUPS_TITLE' => 'Backups',
    'LBL_BACKUPS' => 'Perform a backup',
	'LBL_IMPORT_CUSTOM_FIELDS_TITLE' => 'Import Custom Fields Structure',
	'LBL_EXPORT_CUSTOM_FIELDS_TITLE' => 'Export Custom Fields Structure',
	'LBL_EXTERNAL_DEV_TITLE'=> 'Migrate Custom Fields',
	'LBL_EXTERNAL_DEV_DESC'=> 'Migrate custom fields structure from one system to another',
	'LBL_IMPORT_CUSTOM_FIELDS'=> 'Import custom field definitions from a .sugar file', 
	'LBL_EXPORT_CUSTOM_FIELDS'=> 'Export custom field definitions to a .sugar file', 
	'LBL_IMPORT_CUSTOM_FIELDS_STRUCT'=> ' Custom Field Structure (SugarCustomFieldStruct.sug)',
	'LBL_IMPORT_CUSTOM_FIELDS_DESC'=> ' <br>Import a .sug file that was exported from another machine. This will cause the custom field structure on this machine to match that of the other machine. It is recommended you export your current Custom Field Structure prior to importing one. After importing the Custom Field Structure, the system will automatically run you through a Custom Field Upgrade informing you of what changes will be made to the database. If you agree with these changes click the execute non-simulation mode link at the bottom. If you wish to revert the import process simply import the structure you exported prior to running this import. If you do <br> Warning: This will remove any previously defined custom field structures that are not defined in the .sug file as well as any data stored in those custom fields.',

	'LBL_REBUILD_AUDIT_TITLE' => 'Rebuild Audit',
	'LBL_REBUILD_AUDIT_DESC' => 'Rebuilds audit table.',
	
	'LBL_REBUILD_EXTENSIONS_TITLE' => 'Rebuild Extensions',
	'LBL_REBUILD_EXTENSIONS_DESC' => 'Rebuild extensions including extended vardefs, language packs, menus, and administration',

    'LBL_REBUILD_CONFIG' =>'Rebuild Config File',
    'LBL_REBUILD_CONFIG_DESC' =>'Rebuild config.php by updating version and adding defaults when not explicitly declared.',
    'BTN_REBUILD_CONFIG' =>'Rebuild',
    'LBL_CONFIG_CHECK' =>'Config Check',
    'MSG_CONFIG_FILE_READY_FOR_REBUILD' => 'The config.php file is ready for rebuild.',
    'MSG_MAKE_CONFIG_FILE_WRITABLE' => 'Please make the config.php writable and try again.',
    'MSG_CONFIG_FILE_REBUILD_SUCCESS' => 'The config.php was successfully rebuilt.',
    'MSG_CONFIG_FILE_REBUILD_FAILED' => 'The config.php could not be rebuilt.',

	'LBL_REPAIR_DATABASE' =>'Repair Database',
	'LBL_REPAIR_DATABASE_DESC' =>'Repair database based on values defined in vardefs (MYSQL ONLY)',
	'LBL_REPAIR_DISPLAYSQL' =>'Display SQL',
	'LBL_REPAIR_DATABASE_TEXT'=>'This tool allows you to upgrade the database to match any changes made to bean vardefs and relationship metadata. <br>You may choose from three options : <br>Display SQL will display the sql that will be executed on the screen<br> Export SQL will export the sql to a file<br> Execute SQL will execute the SQL.',
	'LBL_REPAIR_EXPORTSQL' =>'Export SQL',
	'LBL_REPAIR_EXECUTESQL' =>'Execute SQL',



































































	'LBL_SUGAR_UPDATE_TITLE'=>'Sugar Updates',
	'LBL_SUGAR_UPDATE'=>'Check for latest updates.',
	'LBL_UPDATE_TITLE'=>'Enable Sugar Updates:',
	'LBL_UPDATE_CHECK_TYPE'=>'Check for updates',
	'LBL_UPDATE_CHECK_AUTO'=>'Automatically',
	'LBL_UPDATE_CHECK_MANUAL'=>'Manually',
	'LBL_CHECK_NOW_TITLE' =>'Check Now',
	'LBL_CHECK_NOW_LABEL' =>'Check Now',
	'LBL_SEND_STAT'=>'Usage Statistics Reporting Enabled.',	
	'LBL_CONFIGURE_UPDATER'=>'Configure Sugar Updates',
	'HEARTBEAT_MESSAGE'=>"<BR>When this is enabled your system will periodically send SugarCRM Inc. anonymous statistics about your installation that will help us understand usage patterns and improve the product. In return for this information, administrators will receive update notices when new versions or updates are available.",
	'LBL_ERROR_VERSION_INFO'=>'Error fetching version information, please try again later.',
	'LBL_REBUILD_REL_TITLE'=>'Rebuild Relationships',
	'LBL_REBUILD_REL_DESC'=>'Rebuilds relationship meta data and drops the cache file.',
	'LBL_UPGRADE_CUSTOM_LABELS_TITLE'=>'Upgrade Custom Labels',
	'LBL_UPGRADE_CUSTOM_LABELS_DESC'=>'Upgrade the format of the custom field labels in every language file.',
);
?>
