<?php
// created: 2005-08-26 18:15:13
$manifest = array (
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
      0 => '3.5.0a',
    ),
    'regex_matches' => 
    array (
    ),
  ),
  'acceptable_sugar_flavors' => 
  array (
    0 => 'OS',
  ),
  'name' => 'SugarSuite',
  'description' => '',
  'author' => 'SugarCRM, Inc.',
  'published_date' => '2005-08-26 18:15:13',
  'version' => '3.5.0b',
  'type' => 'patch',
  'icon' => '',
  'copy_files' => 
  array (
    'from_dir' => 'SugarSuite-Patch-3.5.0b',
    'to_dir' => '',
    'force_copy' => 
    array (
    ),
  ),
);
?>
