<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Import/language/ge_ge.lang.php, v 1.5 2004/09/10 erich.althaus@creative-solutions.ch $
 * Description:  Defines the English language pack for the Import module.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/
/* 
'LBL_GO_TO_BUTTON_TITLE'=>'Gehe zu Schritt 2',
'LBL_IMPORT_MODULE_SELECT_DELIMITER'=>'W�hle Feldtrennzeichen',
'LBL_IMPORT_MODULE_COMMA_CSV'=>'Komma (CSV)',
'LBL_IMPORT_MODULE_TAB'=>'Tab',
'LBL_IMPORT_MODULE_CUSTOM'=>'Benutzerdefiniert:',
'LBL_IMPORT_MODULE_ERROR_NO_UPLOAD'=>'Datei wurde nicht korrekt hochgeladen, bitte erneut versuchen.',
'LBL_IMPORT_MODULE_ERROR_LARGE_FILE'=>'Datei ist zu gross. Maximale Dateigr�sse ist:',
'LBL_IMPORT_MODULE_ERROR_LARGE_FILE_END'=>'Bytes',
'LBL_IMPORT_MODULE_ERROR'=>'Error:',
'LBL_IMPORT_MODULE_ERROR_MULTIPLE'=>'Mehrere Kolonnen sind mit dem gleichen Feldnamen definiert!',
'LBL_IMPORT_MODULE_ERROR_DELIMITER_NOT'=>'Feldtrennzeichen ist nicht definiert.',
'LBL_IMPORT_MODULE_ERROR_CANT_OPEN'=>'Datei kann nicht ge�ffnet werden.',
'LBL_IMPORT_MODULE_STEP_1_TITLE'=>'Schritt 1: Datei Upload',
'LBL_IMPORT_MODULE_STEP_2_TITLE'=>'Schritt 2: W�hle Felder und deren Verbindungen',
*/



$mod_strings = Array(
'LBL_MODULE_NAME'=>'Import',
'LBL_TRY_AGAIN'=>'Versuchen Sie es erneut',
'LBL_ERROR'=>'Error:',
'ERR_MULTIPLE'=>'Mehrere Kolonnen sind mit dem gleichen Feldnamen definiert!',
'ERR_MISSING_REQUIRED_FIELDS'=>'Pflichtfelder fehlen:',
'ERR_SELECT_FULL_NAME'=>'Sie k�nnen nicht das Feld Namen ausw�hlen wenn Nachname und Vorname ausgew�hlt sind.',
'ERR_SELECT_FILE'=>'W�hlen Sie eine Datei f�r den upload.',
'LBL_SELECT_FILE'=>'Datei ausw�hlen:',
'LBL_CUSTOM'=>'Benutzerdefiniert',
'LBL_DONT_MAP'=>'-- Dieses Feld nicht verkn�pfen !!! --',
'LBL_STEP_1_TITLE'=>'Schritt 1: W�hlen Sie die Ausgangsdatei',
'LBL_WHAT_IS'=>'Um was f�r einen Dateityp handelt es sich?',
'LBL_MICROSOFT_OUTLOOK'=>'Microsoft Outlook',
'LBL_ACT'=>'Act!',
'LBL_SALESFORCE'=>'Salesforce.com',
'LBL_MY_SAVED'=>'Meine gespeicherten Ausgangsdateien:',
'LBL_PUBLISH'=>'publizieren',
'LBL_DELETE'=>'l�schen',
'LBL_PUBLISHED_SOURCES'=>'Ver�ffentlichte Quellen:',
'LBL_UNPUBLISH'=>'nicht-ver�ffentlichen',
'LBL_NEXT'=>'Vor >',
'LBL_BACK'=>'< Zur�ck',
'LBL_STEP_2_TITLE'=>'Schritt 2: Export Datei upload',
'LBL_HAS_HEADER'=>'Hat Kopfzeile:',

'LBL_NUM_1'=>'1.',
'LBL_NUM_2'=>'2.',
'LBL_NUM_3'=>'3.',
'LBL_NUM_4'=>'4.',
'LBL_NUM_5'=>'5.',
'LBL_NUM_6'=>'6.',
'LBL_NUM_7'=>'7.',
'LBL_NUM_8'=>'8.',
'LBL_NUM_9'=>'9.',
'LBL_NUM_10'=>'10.',
'LBL_NUM_11'=>'11.',
'LBL_NUM_12'=>'12.',
'LBL_NOW_CHOOSE'=>'W�hlen Sie nun die zu importierende Datei:',
'LBL_IMPORT_OUTLOOK_TITLE'=>'Microsoft Outlook 98 und 2000 k�nnen Daten im <b>CSV - Comma Separated Values</b> format exportieren, welches zum Import in Sugar CRM verwendet werden kann. Um die Daten aus Outlook zu exportieren gehen Sie wie folgt vor:',
'LBL_OUTLOOK_NUM_1'=>'Starten Sie <b>Outlook</b>',
'LBL_OUTLOOK_NUM_2'=>'W�hlen Sie im Menu <b>File</b> von Outlook den Menupunkt <b>Importieren und Exportieren ...</b>',
'LBL_OUTLOOK_NUM_3'=>'W�hlen Sie <b>Exportieren in eine Datei</b> und anschliessend auf <b>Weiter ></b>',
'LBL_OUTLOOK_NUM_4'=>'W�hlen Sie <b>Kommagetrennte Werte (Windows)</b> und anschliessend auf <b>Weiter ></b>.<br>  Hinweis: Es kann sein das Sie aufgefordert werden die Export Komponente von Outlook zu installieren!',
'LBL_OUTLOOK_NUM_5'=>'W�hlen Sie den Ordner <b>Kontakte</b> und anschliessend auf  <b>Weiter ></b>. Sie k�nnen durch Dr�cken der Ctrl Taste auch mehrere Ordner ausw�hlen, falls Ihre Kontakte in verschiedenen Ordnern abgelegt sind.',
'LBL_OUTLOOK_NUM_6'=>'W�hlen Sie nun den Speicherort und einen Dateinamen und anschliessend auf <b>Weiter ></b>',
'LBL_OUTLOOK_NUM_7'=>'Klicken Sie auf <b>Fertig stellen</b>',
'LBL_IMPORT_ACT_TITLE'=>'Act! kann Daten im <b>Comma Separated Values</b> format exportieren, welches in Sugar CRM zum importieren von Daten verwendet werden kann. Um die Daten aus Act!, gehen Sie wie folgt vor:',
'LBL_ACT_NUM_1'=>'Starten Sie <b>ACT!</b>',
'LBL_ACT_NUM_2'=>'W�hlen Sie im Menu <b>Datei</b> den Punkt <b>Daten Austausch</b>, Anschliessend den Punkt <b>Export...</b>',
'LBL_ACT_NUM_3'=>'W�hlen Sie den Datei Typ <b>Text-getrennt</b>',
'LBL_ACT_NUM_4'=>'W�hlen Wie einen Dateinamen und den Speicherort f�r die Export Datei und klicken Sie anschliessend auf <b>Weiter</b>',
'LBL_ACT_NUM_5'=>'W�hlen Sie <b>nur Kontakt Eintr�ge</b>',
'LBL_ACT_NUM_6'=>'Klicken Sie auf den Button <b>Optionen...</b>',
'LBL_ACT_NUM_7'=>'W�hlen Sie <b>Komma</b> als Feld Trennzeichen',
'LBL_ACT_NUM_8'=>'Klicken Sie die Checkbox <b>Ja, Feldnamen exportieren</b> an und anschliessend auf <b>OK</b>',
'LBL_ACT_NUM_9'=>'Klicken Sie auf <b>Weiter</b>',
'LBL_ACT_NUM_10'=>'W�hlen Sie <b>Alle Eintr�ge</b> und anschliessen auf <b>Fertig stellen</b>',

'LBL_IMPORT_SF_TITLE'=>'Salesforce.com kann die Daten in das <b>Comma Separated Values</b> Format exportieren, welches in Sugar CRM importiert werden kann. Um Ihre Daten aus Salesforce.com zu exportieren, gehen Sie wie folgt vor:',
'LBL_SF_NUM_1'=>'�ffnen Sie Ihren Internet Browser und gehen Sie zu http://www.salesforce.com, anschliessend loggen Sie sich mit Ihrer Email Adresse und Ihrem Passwort ein.',
'LBL_SF_NUM_2'=>'Klicken Sie auf den <b>Reports</b> Reiter im oberen Menu',
'LBL_SF_NUM_3'=>'Um die Daten zu exportieren, klicken Sie auf den <b>Active Accounts</b> Link<br><b>Um die Kontatk Daten zu exportieren:</b> Klicken Sie auf den <b>Mailing List</b> Link',
'LBL_SF_NUM_4'=>'Auf dem Screen <b>Step 1: Select your report type</b>, w�hlen Sie <b>Tabular Report</b> und anschliessend auf <b>Next</b>',
'LBL_SF_NUM_5'=>'Auf dem Screen <b>Step 2: Select the report columns</b> w�hlen Sie die Kolonnen welche Sie exportieren m�chten und anschliessend auf <b>Next</b>',
'LBL_SF_NUM_6'=>'Auf dem Screen <b>Step 3: Select the information to summarize</b> klicken Sie einfach auf <b>Next</b>',
'LBL_SF_NUM_7'=>'Auf dem Screen <b>Step 4: Order the report columns</b> klicken Sie einfach auf <b>Next</b>',
'LBL_SF_NUM_8'=>'Auf dem Screen <b>Step 5: Select your report criteria</b>, w�hlen Sie unter <b>Start Date</b> ein Datum welches so weit zur�ck liegt, das alle Ihre Kontakte exportiert werden. Sie k�nnen auch ein Auszug Ihrer Kontakte exportieren indem Sie weitere Einstellungen verwenden. Wenn Sie dies beendet haben, klicken Sie auf <b>Run Report</b>',
'LBL_SF_NUM_9'=>'Der Report wird nun erstellt. Wenn dieser Fertig ist, sollte eine Meldung angezeigt werden: <b>Report Generation Status: Complete.</b> klicken Sie nun auf <b>Export to Excel</b>',
'LBL_SF_NUM_10'=>'Auf dem Screen <b>Export Report:</b>, w�hlen Sie unter <b>Export File Format:</b> den Eintrag <b>Comma Delimited .csv</b>. Klicken Sie auf <b>Export</b>.',
'LBL_SF_NUM_11'=>'Ein Dialog Fenster erscheint auf Ihrem Bildschirm um die Export Datei auf Ihrem Computer abzuspeichern.',
'LBL_IMPORT_CUSTOM_TITLE'=>'Viele Programme erlauben Ihnen die Daten im <b>CSV - Comma Delimited text file (.csv)</b> zu exportieren. In den meisten Applikationen k�nnen Sie dies wie folgt t�tigen:',
'LBL_CUSTOM_NUM_1'=>'Starten Sie das Programm und �ffnen Sie die Datei, in welcher Ihre Kontakt Informationen abgelegt sind.',
'LBL_CUSTOM_NUM_2'=>'W�hlen Sie <b>Speichern unter ...</b> oder <b>Exportieren...</b> in dem Menu Datei',
'LBL_CUSTOM_NUM_3'=>'Speichern Sie die Datei im <b>CSV</b> oder <b>Comma Separated Values</b> oder <b>Kommagetrente Werte</b> Format. Falls noch weitere Angaben angegeben sind, w�hlen Sie (Windows)',

'LBL_STEP_3_TITLE'=>'Schritt 3: Felder best�tigen und anschliessend Import der Daten',

'LBL_SELECT_FIELDS_TO_MAP'=>'W�hlen Sie in der Liste unten die Felder welche importiert werden sollen und weisen Sie dieses einem Feld in Sugar CRM zu. Wenn Sie dies get�tigt haben, klicken Sie auf <b>Jetzt Importieren</b>:',

'LBL_DATABASE_FIELD'=>'Datenbank Feld',
'LBL_HEADER_ROW'=>'Kopfzeile',
'LBL_ROW'=>'Zeile',
'LBL_SAVE_AS_CUSTOM'=>'Speichern als Benutzerdefinierte Verkn�pfungen:',
'LBL_CONTACTS_NOTE_1'=>'Mindesten eines der Felder Nachnamen oder Namen m�ssen verkn�pft sein.',
'LBL_CONTACTS_NOTE_2'=>'Wenn Sie das Feld Namen verkn�pfen, werden die Felder Vornamen und Nachnamen nicht importiert!',
'LBL_CONTACTS_NOTE_3'=>'Wenn das Feld Namen verkn�pft wird, werden die Informationen aus dem Feld Namen beim Import automatisch in die beiden Felder Vornamen und Namen eingef�gt.',
'LBL_CONTACTS_NOTE_4'=>'Felder welche mit Adresse 2 und Adresse 3 enden werden automatisch in dem Haupt Adress Feld zusammengef�hrt.',
'LBL_ACCOUNTS_NOTE_1'=>'Der Kunden Name muss verkn�pft sein.',
'LBL_ACCOUNTS_NOTE_2'=>'Felder welche mit Adresse 2 und Adresse 3 enden werden automatisch in dem Haupt Adress Feld zusammengef�hrt.',
'LBL_IMPORT_NOW'=>'Jetzt importieren',
'LBL_'=>'',
'LBL_'=>'',
'LBL_CANNOT_OPEN'=>'Die Import Datei kann nicht ge�ffnet werden',
'LBL_NOT_SAME_NUMBER'=>'Ihre Import Datei enth�lt nicht die gleiche Anzahl Felder',
'LBL_NO_LINES'=>'Die Import Datei ist leer!',
'LBL_FILE_ALREADY_BEEN_OR'=>'Die Import Datei wurde schon verarbeitet oder existiert nicht!',
'LBL_SUCCESS'=>'Erfolgreich:',
'LBL_SUCCESSFULLY'=>'Die Daten wurden erfolgreich importiert',
'LBL_LAST_IMPORT_UNDONE'=>'Ihr letzter Import wurde r�ckg�ngig gemacht',
'LBL_NO_IMPORT_TO_UNDO'=>'Es ist keine Import vorhanden welcher r�ckg�ngig gemacht werden kann!',
'LBL_FAIL'=>'Fehler:',
'LBL_RECORDS_SKIPPED'=>'Import wurde abgebrochen',
'LBL_IDS_EXISTED_OR_LONGER'=>'IDs sind bereits vorhanden oder sind l�nger als 36 Zeichen',
'LBL_RESULTS'=>'Resultate',
'LBL_IMPORT_MORE'=>'Weitere Daten importieren',
'LBL_FINISHED'=>'Fertug',
'LBL_UNDO_LAST_IMPORT'=>'Letzten Import r�ckg�ngig machen',



);

$mod_list_strings = Array(
'contacts_import_fields' => Array(
	"id"=>"ID"
	,"first_name"=>"Vornamen"
	,"last_name"=>"Nachnamen"
	,"salutation"=>"Anrede"
	,"lead_source"=>"Auftragsherkunft"
	,"birthdate"=>"Geburtsdatum"
	,"do_not_call"=>"Nicht anrufen"
	,"email_opt_out"=>"Email Opt Out"
	,"primary_address_street_2"=>"Prim�re Adresse 2"
	,"primary_address_street_3"=>"Prim�re Adresse 3"
	,"alt_address_street_2"=>"Andere Adresse 2"
	,"alt_address_street_3"=>"Andere Adresse 3"
	,"full_name"=>"Name"
	,"account_name"=>"Kunde"
	,"account_id"=>"Kunde ID"
	,"title"=>"Titel"
	,"department"=>"Abteilung"
	,"birthdate"=>"Geburtsdatum"
	,"do_not_call"=>"Nicht anrufen"
	,"phone_home"=>"Telefon (Privat)"
	,"phone_mobile"=>"Telefon (Mobile)"
	,"phone_work"=>"Telefon (Gesch�ft)"
	,"phone_other"=>"Telefon (Andere)"
	,"phone_fax"=>"Fax"
	,"email1"=>"Email"
	,"email2"=>"Email (Andere)"
	,"yahoo_id"=>"Yahoo! ID"
	,"assistant"=>"Assistent"
	,"assistant_phone"=>"Assistent Telefon"
	,"primary_address_street"=>"Prim�re Adresse"
	,"primary_address_city"=>"Prim�re Address Ort"
	,"primary_address_state"=>"Prim�re Adresse Bundesland"
	,"primary_address_postalcode"=>"Prim�re Adresse PLZ"
	,"primary_address_country"=>"Prim�re Adresse Land"
	,"alt_address_street"=>"Andere Adresse"
	,"alt_address_city"=>"Andere Adresse Ort"
	,"alt_address_state"=>"Andere Adresse Bundesland"
	,"alt_address_postalcode"=>"Andere Adresse PLZ"
	,"alt_address_country"=>"Andere Adresse Land"
	,"description"=>"Bemerkungen"

	),

'accounts_import_fields' => Array(
	"id"=>"Kunden ID",
	"name"=>"Kunde",
	"website"=>"Webseite",
	"industry"=>"Branche",
	"type"=>"Typ",
	"ticker_symbol"=>"Ticker Symbol",
	"parent_name"=>"Mitglied von",
	"employees"=>"Mitarbeiter",
	"ownership"=>"Eigent�mer",
	"phone_office"=>"Telefon",
	"phone_fax"=>"Fax",
	"phone_alternate"=>"Andere Telefon",
	"email1"=>"Email",
	"email2"=>"Andere Email",
	"rating"=>"Bewertung",
	"sic_code"=>"SIC Code",
	"annual_revenue"=>"Umsatz pro Jahr",
	"billing_address_street"=>"Rechnungs Adresse",
	"billing_address_street_2"=>"Rechnungs Adresse 2",
	"billing_address_street_3"=>"Rechnungs Adresse 3",
	"billing_address_street_4"=>"Rechnungs Adresse 4",
	"billing_address_city"=>"Rechnungs Adresse Ort",
	"billing_address_state"=>"Rechnungs Adresse Bundesland",
	"billing_address_postalcode"=>"Rechnungs Adresse PLZ",
	"billing_address_country"=>"Rechnungs Adresse Land",
	"shipping_address_street"=>"Liefer Adresse",
	"shipping_address_street_2"=>"Liefer Adresse 2",
	"shipping_address_street_3"=>"Liefer Adresse 3",
	"shipping_address_street_4"=>"Liefer Adresse 4",
	"shipping_address_city"=>"Liefer Adresse Ort",
	"shipping_address_state"=>"Liefer Adresse Bundesland",
	"shipping_address_postalcode"=>"Liefer Adresse PLZ",
	"shipping_address_country"=>"Liefer Adresse Land",
	"description"=>"Bemerkungen"
	)

);

?>