-- $Id: 25pre2_to_25pre3.sql,v 1.1 2005/01/17 04:57:06 andrew Exp $
--
-- upgrade script for bringing a SugarCRM database
-- version 2.5pre2 to version 2.5pre3
--

-- --------------------------------------------------------

--
-- 24a25
--

ALTER TABLE `accounts`
ADD `created_by` varchar(36) default NULL AFTER `assigned_user_id`;

-- --------------------------------------------------------

--
-- Table structure for table `accounts_bugs`
--

CREATE TABLE `accounts_bugs` (
  `id` char(36) NOT NULL default '',
  `account_id` char(36) default NULL,
  `bug_id` char(36) default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `idx_acc_bug_acc` (`account_id`),
  KEY `idx_acc_bug_bug` (`bug_id`)
) TYPE=MyISAM;

--
-- Move the data from the old table to the new table
--

INSERT INTO accounts_bugs (id, account_id, bug_id, deleted)
SELECT accounts_issues.id, accounts_issues.account_id,
		accounts_issues.issue_id, accounts_issues.deleted
FROM accounts_issues;

--
-- Drop the old table
--

DROP TABLE IF EXISTS accounts_issues;

-- --------------------------------------------------------

--
-- Table structure for table `bugs`
--

CREATE TABLE `bugs` (
  `id` varchar(36) NOT NULL default '',
  `number` int(11) NOT NULL auto_increment,
  `date_entered` datetime NOT NULL default '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL default '0000-00-00 00:00:00',
  `modified_user_id` varchar(36) NOT NULL default '',
  `assigned_user_id` varchar(36) default NULL,
  `team_id` varchar(36) default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  `name` varchar(255) default NULL,
  `status` varchar(25) default NULL,
  `priority` varchar(25) default NULL,
  `description` text,
  `created_by` varchar(255) default NULL,
  `created_by_hash` varchar(255) default NULL,
  `resolution` varchar(255) default NULL,
  `hours_remaining` float default NULL,
  `release` varchar(255) default NULL,
  `type` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `number` (`number`),
  KEY `idx_bug_name` (`name`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

--
-- Move the data from the old table to the new table
--

INSERT INTO `bugs` ( `id` , `number` , `date_entered` , `date_modified` ,
`modified_user_id` , `assigned_user_id` , `team_id` , `deleted` , `name` ,
`status` , `priority` , `description` , `created_by` , `created_by_hash` ,
`resolution` , `hours_remaining` , `release` , `type` )
SELECT issues.id, issues.number, issues.date_entered, issues.date_modified,
issues.modified_user_id, issues.assigned_user_id, issues.team_id,
issues.deleted, issues.name, issues.status, issues.priority,
issues.description, issues.created_by, issues.created_by_hash,
issues.resolution, issues.hours_remaining, issues.release, issues.type
FROM issues;

--
-- Drop the old table
--

DROP TABLE IF EXISTS issues;

-- --------------------------------------------------------

--
-- 115a147,148
--

ALTER TABLE `calls`
ADD `modified_user_id` varchar(36) default NULL AFTER `assigned_user_id`;

ALTER TABLE `calls`
ADD `created_by` varchar(36) default NULL AFTER `modified_user_id`;

-- --------------------------------------------------------

--
-- 177a211
--

ALTER TABLE `cases`
ADD `created_by` varchar(36) default NULL AFTER `assigned_user_id`;

-- --------------------------------------------------------

--
-- Table structure for table `cases_bugs`
--

CREATE TABLE `cases_bugs` (
  `id` char(36) NOT NULL default '',
  `case_id` char(36) default NULL,
  `bug_id` char(36) default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `idx_cas_bug_cas` (`case_id`),
  KEY `idx_cas_bug_bug` (`bug_id`)
) TYPE=MyISAM;

--
-- Move the data from the old table to the new table
--

INSERT INTO cases_bugs (id, case_id, bug_id, deleted)
SELECT cases_issues.id, cases_issues.case_id,
		cases_issues.issue_id, cases_issues.deleted
FROM cases_issues;

--
-- Drop the old table
--

DROP TABLE IF EXISTS cases_issues;

-- --------------------------------------------------------

--
-- 232a267
--

ALTER TABLE `contacts`
ADD `created_by` varchar(36) default NULL AFTER `assigned_user_id`;

-- --------------------------------------------------------

--
-- Table structure for table `contacts_bugs`
--

CREATE TABLE `contacts_bugs` (
  `id` char(36) NOT NULL default '',
  `contact_id` char(36) default NULL,
  `bug_id` char(36) default NULL,
  `contact_role` char(50) default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `idx_con_bug_con` (`contact_id`),
  KEY `idx_con_bug_bug` (`bug_id`)
) TYPE=MyISAM;

--
-- Move the data from the old table to the new table
--

INSERT INTO contacts_bugs (id, contact_id, bug_id, contact_role, deleted)
SELECT contacts_issues.id, contacts_issues.contact_id,
		contacts_issues.issue_id, contacts_issues.contact_role,
		contacts_issues.deleted
FROM contacts_issues;

--
-- Drop the old table
--

DROP TABLE IF EXISTS contacts_issues;

-- --------------------------------------------------------

--
-- 356a392,393
--

ALTER TABLE `emails`
ADD `modified_user_id` varchar(36) default NULL AFTER `assigned_user_id`;

ALTER TABLE `emails`
ADD `created_by` varchar(36) default NULL AFTER `modified_user_id`;

-- --------------------------------------------------------

--
-- 461a499
--

ALTER TABLE `feeds`
ADD `created_by` char(36) default NULL AFTER `assigned_user_id`;

-- --------------------------------------------------------

--
-- Table structure for table `iframes`
--

CREATE TABLE `iframes` (
  `id` char(36) NOT NULL default '',
  `name` char(255) NOT NULL default '',
  `url` char(255) NOT NULL default '',
  `placement` char(255) NOT NULL default '',
  `status` tinyint(1) NOT NULL default '0',
  `deleted` tinyint(1) NOT NULL default '0',
  `date_entered` datetime NOT NULL default '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`),
  KEY `idx_cont_name` (`name`,`deleted`)
) TYPE=MyISAM;

-- --------------------------------------------------------

--
-- 551a579
--

ALTER TABLE `leads`
ADD `created_by` varchar(36) default NULL AFTER `assigned_user_id`;

-- --------------------------------------------------------

--
-- 606a635
--

ALTER TABLE `manufacturers`
ADD `created_by` char(36) default NULL AFTER `modified_user_id`;

-- --------------------------------------------------------

--
-- 625a655,656
--

ALTER TABLE `meetings`
ADD `modified_user_id` varchar(36) default NULL AFTER `assigned_user_id`;

ALTER TABLE `meetings`
ADD `created_by` varchar(36) default NULL AFTER `modified_user_id`;

-- --------------------------------------------------------

--
-- 684a716,717
--

ALTER TABLE `notes`
ADD `modified_user_id` varchar(36) default NULL AFTER `date_modified`;

ALTER TABLE `notes`
ADD `created_by` varchar(36) default NULL AFTER `modified_user_id`;

-- --------------------------------------------------------

--
-- 708a742
--

ALTER TABLE `opportunities`
ADD `created_by` varchar(36) default NULL AFTER `assigned_user_id`;

-- --------------------------------------------------------

--
-- 755a790
--

ALTER TABLE `product_categories`
ADD `created_by` varchar(36) default NULL AFTER `modified_user_id`;

-- --------------------------------------------------------

--
-- 794a830
--

ALTER TABLE `product_templates`
ADD `created_by` varchar(36) default NULL AFTER `modified_user_id`;

-- --------------------------------------------------------

--
-- 838a875
--

ALTER TABLE `product_types`
ADD `created_by` varchar(36) default NULL AFTER `modified_user_id`;

-- --------------------------------------------------------

--
-- 858a896
--

ALTER TABLE `products`
ADD `created_by` varchar(36) default NULL AFTER `modified_user_id`;

-- --------------------------------------------------------

--
-- 912a951
--

ALTER TABLE `quotes`
ADD `created_by` varchar(36) default NULL AFTER `assigned_user_id`;

-- --------------------------------------------------------

--
-- 1012a1052
--

ALTER TABLE `releases`
ADD `created_by` varchar(36) default NULL AFTER `modified_user_id`;

-- --------------------------------------------------------

--
-- 1030a1071
--

ALTER TABLE `saved_reports`
ADD `report_type` varchar(36) NOT NULL default '' AFTER `module`;

-- --------------------------------------------------------

--
-- 1035a1077,1078
--

ALTER TABLE `saved_reports`
ADD `modified_user_id` varchar(36) default NULL AFTER `assigned_user_id`;

ALTER TABLE `saved_reports`
ADD `created_by` varchar(36) default NULL AFTER `modified_user_id`;

-- --------------------------------------------------------

--
-- 1053a1097
--

ALTER TABLE `shippers`
ADD `created_by` char(36) default NULL AFTER `modified_user_id`;

-- --------------------------------------------------------

--
-- 1072a1117,1118
--

ALTER TABLE `tasks`
ADD `modified_user_id` varchar(36) default NULL AFTER `assigned_user_id`;

ALTER TABLE `tasks`
ADD `created_by` varchar(36) default NULL AFTER `modified_user_id`;

-- --------------------------------------------------------

--
-- 1100a1147
--

ALTER TABLE `taxrates`
ADD `created_by` char(36) default NULL AFTER `modified_user_id`;

-- --------------------------------------------------------

--
-- 1140a1188
--

ALTER TABLE `team_notices`
ADD `created_by` varchar(36) default NULL AFTER `modified_user_id`;

-- --------------------------------------------------------

--
-- 1163a1212
--

ALTER TABLE `teams`
ADD `created_by` varchar(36) default NULL AFTER `modified_user_id`;

-- --------------------------------------------------------

--
-- 1205a1255
--

ALTER TABLE `users`
ADD `created_by` varchar(36) default NULL AFTER `modified_user_id`;

-- --------------------------------------------------------

--
-- update the version number of SugarCRM on the database
--

UPDATE `config`
SET `value`='2.5pre3'
WHERE `name` LIKE 'sugar_version' ;

-- --------------------------------------------------------

--
-- add more date fields to the tasks
--

ALTER TABLE `tasks`
ADD `date_start_flag` CHAR( 5 ) DEFAULT 'on' AFTER `time_due`;

ALTER TABLE `tasks`
ADD `date_start` DATE DEFAULT NULL AFTER `date_start_flag`;

ALTER TABLE `tasks`
ADD `time_start` TIME DEFAULT NULL AFTER `date_start` ;
