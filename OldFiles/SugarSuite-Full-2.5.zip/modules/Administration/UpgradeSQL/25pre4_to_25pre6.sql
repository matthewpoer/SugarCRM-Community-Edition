--
-- $Id: 25pre4_to_25pre6.sql,v 1.3 2005/01/20 19:07:34 andrew Exp $
--
-- Upgrade script for 2.5pre5 to 2.5pre6
--

-- --------------------------------------------------------

-- 
-- Table structure for table `report_schedules`
-- 

CREATE TABLE `report_schedules` (
  `id` char(36) NOT NULL default '',
  `user_id` char(36) NOT NULL default '',
  `report_id` char(36) NOT NULL default '',
  `next_run` datetime NOT NULL default '0000-00-00 00:00:00',
  `active` tinyint(1) NOT NULL default '0',
  `time_interval` int(11) default NULL,
  `deleted` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

-- --------------------------------------------------------

UPDATE `saved_reports`
SET `report_type` = 'tabular'
WHERE `report_type` = '';

UPDATE `saved_reports`
SET `report_type` = 'tabular'
WHERE `report_type` IS NULL;

-- --------------------------------------------------------

--
-- update the version number of SugarCRM on the database
--

UPDATE `config`
SET `value`='2.5pre6'
WHERE `name` LIKE 'sugar_version' ;


