-- $Id: 25pre1_to_25pre2.sql,v 1.2 2005/01/13 18:21:08 andrew Exp $
--
-- upgrade script for bringing a SugarCRM database
-- version 2.5pre1 to version 2.5pre2
--

--
-- Table structure for table `feeds`
-- 

CREATE TABLE `feeds` (
  `id` char(36) NOT NULL default '',
  `deleted` tinyint(1) NOT NULL default '0',
  `date_entered` datetime NOT NULL default '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL default '0000-00-00 00:00:00',
  `modified_user_id` char(36) NOT NULL default '',
  `assigned_user_id` char(36) default NULL,
  `team_id` char(36) default NULL,
  `title` char(100) default NULL,
  `description` char(100) default NULL,
  `url` char(100) default NULL,
  PRIMARY KEY  (`id`),
  KEY `idx_desc` (`title`,`deleted`)
) TYPE=MyISAM ;

-- --------------------------------------------------------

-- 
-- 63c1184
-- changed from : AUTO_INCREMENT=1 ;
--

ALTER TABLE `tracker`
AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Table structure for table `users_feeds`
-- 

CREATE TABLE `users_feeds` (
  `user_id` char(36) NOT NULL default '',
  `feed_id` char(36) NOT NULL default '',
  `rank` int(11) NOT NULL default '0',
  `deleted` tinyint(1) NOT NULL default '0',
  KEY `idx_user_id` (`user_id`,`feed_id`)
) TYPE=MyISAM ;

-- --------------------------------------------------------

--
-- update the version number of SugarCRM on the database
-- 

UPDATE `config`
SET `value`='2.5pre2'
WHERE `name` LIKE 'sugar_version' ;

