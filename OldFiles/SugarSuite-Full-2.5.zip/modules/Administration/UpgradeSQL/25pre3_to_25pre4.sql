--
-- $Id: 25pre3_to_25pre4.sql,v 1.1 2005/01/19 03:33:19 andrew Exp $
--
-- upgrade script for bringing a SugarCRM database
-- version 2.5pre3 to version 2.5pre4
--

-- --------------------------------------------------------

--
-- 55c55,57
--

ALTER TABLE `accounts`
ADD INDEX `idx_accnt_id_del` (`id`,`deleted`),
ADD INDEX `idx_accnt_team_del` (`team_id`,`deleted`,`assigned_user_id`);

-- --------------------------------------------------------

--
-- 103c105,106
--

ALTER TABLE `accounts_opportunities`
ADD INDEX `idx_a_o_opp_acc_del` (`opportunity_id`,`account_id`,`deleted`);

-- --------------------------------------------------------

--
-- 125,126c128
--

ALTER TABLE `bugs`
CHANGE COLUMN `created_by` `created_by` varchar(36) default NULL;

ALTER TABLE `bugs`
DROP COLUMN `created_by_hash`;

-- --------------------------------------------------------

--
-- 128d129
--

ALTER TABLE `bugs`
DROP COLUMN `hours_remaining`;

-- --------------------------------------------------------

--
-- 300c301,304
--

ALTER TABLE `contacts`
ADD INDEX `idx_contacts_del_last` (`deleted`,`last_name`),
ADD INDEX `idx_cont_del_reports` (`deleted`,`reports_to_id`,`last_name`),
ADD INDEX `idx_contact_del_team` (`deleted`,`team_id`);

-- --------------------------------------------------------

--
-- 365d368
--

ALTER TABLE `custom_fields`
DROP COLUMN `bean_name`;

-- --------------------------------------------------------

--
-- 378c381
--

ALTER TABLE `custom_fields`
DROP INDEX `bean_id`;

ALTER TABLE `custom_fields`
ADD INDEX `idx_beanid_set_num` (`bean_id`,`set_num`);

-- --------------------------------------------------------

--
-- 534a538
--

ALTER TABLE `iframes`
ADD COLUMN `type` char(255) NOT NULL default '' AFTER `url`;

-- --------------------------------------------------------

--
-- 539a544
--

ALTER TABLE `iframes`
ADD COLUMN `created_by` char(36) NOT NULL default '' AFTER `date_modified`;

-- --------------------------------------------------------

--
-- 574a580
--

ALTER TABLE `leads`
ADD COLUMN `converted` tinyint(1) NOT NULL default '0' AFTER `deleted`;

-- --------------------------------------------------------

--
-- 620c626,631
--

ALTER TABLE `leads`
ADD INDEX `idx_lead_del_stat` (`last_name`,`status`,`deleted`,`first_name`),
ADD INDEX `idx_lead_opp_del` (`opportunity_id`,`deleted`),
ADD INDEX `idx_leads_acct_del` (`account_id`,`deleted`),
ADD INDEX `idx_lead_stat_del` (`status`,`deleted`,`team_id`,`converted`),
ADD INDEX `idx_leads_tem_del_conv` (`team_id`,`deleted`,`converted`);

-- --------------------------------------------------------

--
-- 671c682,684
--

ALTER TABLE `meetings`
ADD INDEX `idx_meet_par_del` (`parent_id`,`parent_type`,`deleted`),
ADD INDEX `idx_meet_team_user_del` (`team_id`,`assigned_user_id`,`deleted`);

-- --------------------------------------------------------

--
-- 758c771,772
--

ALTER TABLE `opportunities`
ADD INDEX `idx_opp_team_asg_del` (`team_id`,`assigned_user_id`,`deleted`);

-- --------------------------------------------------------

--
-- 1135c1149,1151
--

ALTER TABLE `tasks`
ADD INDEX `idx_task_con_del` (`contact_id`,`deleted`),
ADD INDEX `idx_task_par_del` (`parent_id`,`parent_type`,`deleted`);

-- --------------------------------------------------------

--
-- 1174c1190,1191
--

ALTER TABLE `team_memberships`
DROP INDEX `idx_team_membership`;

ALTER TABLE `team_memberships`
ADD INDEX `idx_team_membership` (`user_id`,`team_id`);

ALTER TABLE `team_memberships`
ADD INDEX `idx_teammemb_team_user` (`team_id`,`user_id`);

-- --------------------------------------------------------

--
-- update the version number of SugarCRM on the database
--

UPDATE `config`
SET `value`='2.5pre4'
WHERE `name` LIKE 'sugar_version' ;

-- --------------------------------------------------------

--
-- data migration for leads table
--

UPDATE `leads`
SET `converted`='1'
WHERE `status` LIKE 'Converted';

-- --------------------------------------------------------

--
-- data migration for bugs table
--

update bugs set priority='Urgent'
where priority LIKE 'P1' OR priority LIKE 'P2';

update bugs set priority='High'
where priority LIKE 'P3' OR priority LIKE 'P4';

update bugs set priority='Medium'
where priority LIKE 'P5' OR priority LIKE 'P6' OR priority LIKE 'P7';

update bugs set priority='Low'
where priority LIKE 'P8' OR priority LIKE 'P9' OR priority LIKE 'P10';

-- --------------------------------------------------------

--
-- data migration: deleting unused rows
--

DELETE FROM `accounts_bugs`
WHERE `deleted`=1;

DELETE FROM `accounts_contacts`
WHERE `deleted`=1;

DELETE FROM `accounts_opportunities`
WHERE `deleted`=1;

DELETE FROM `calls_contacts`
WHERE `deleted`=1;

DELETE FROM `calls_users`
WHERE `deleted`=1;

DELETE FROM `cases_bugs`
WHERE `deleted`=1;

DELETE FROM `contacts_bugs`
WHERE `deleted`=1;

DELETE FROM `contacts_cases`
WHERE `deleted`=1;

DELETE FROM `custom_fields`
WHERE `deleted`=1;

DELETE FROM `emails_accounts`
WHERE `deleted`=1;

DELETE FROM `emails_cases`
WHERE `deleted`=1;

DELETE FROM `emails_contacts`
WHERE `deleted`=1;

DELETE FROM `emails_opportunities`
WHERE `deleted`=1;

DELETE FROM `emails_users`
WHERE `deleted`=1;

DELETE FROM `import_maps`
WHERE `deleted`=1;

DELETE FROM `meetings_contacts`
WHERE `deleted`=1;

DELETE FROM `meetings_users`
WHERE `deleted`=1;

DELETE FROM `opportunities_contacts`
WHERE `deleted`=1;

DELETE FROM `product_categories`
WHERE `deleted`=1;

DELETE FROM `product_product`
WHERE `deleted`=1;

DELETE FROM `product_templates`
WHERE `deleted`=1;

DELETE FROM `product_types`
WHERE `deleted`=1;

DELETE FROM `quotes_accounts`
WHERE `deleted`=1;

DELETE FROM `quotes_contacts`
WHERE `deleted`=1;

DELETE FROM `quotes_opportunities`
WHERE `deleted`=1;

DELETE FROM `saved_reports`
WHERE `deleted`=1;

DELETE FROM `team_memberships`
WHERE `deleted`=1;

DELETE FROM `team_notices`
WHERE `deleted`=1;

DELETE FROM `users_feeds`
WHERE `deleted`=1;

DELETE FROM `users_last_import`
WHERE `deleted`=1;


