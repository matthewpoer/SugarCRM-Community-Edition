<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

class AddField{
	var $div='';
	var $script ='';
	var $html = '';
	var $counter = 0;
	var $slot = '-SLOT-';
	var $font_slot = "<font color='red'>-SLOT-</font>";
	function AddField(){
		
		
	
	}
	
	function get_remove_from_add_field($field){
		return <<<EOQ
			remove_field_row_from_table('$field');
EOQ;
	}
	

	function quote_cleanup($value){
		$quote_cleanup=  array('"' =>'&qt;', "'" =>  '&sqt;',"\r\n"=>'', "\n"=>'');
		return str_replace(array_keys($quote_cleanup), array_values($quote_cleanup), $value);
	}
	
	function add_deleted_field($html_code, $prefix=''){
			$count = get_register_value('dyn_layout', 'field_counter');
			if(!$count){
				$count = 0;	
			}
			$div_id = 'dyn_field_' .$count;
			set_register_value('dyn_layout_fields', $div_id, array($div_id, $html_code));
			$html_code = $this->quote_cleanup($html_code);
			$script = "\n \n". $prefix. "add_new_field_row_to_table('$div_id', '$html_code');";
			$count += 1;
			set_register_value('dyn_layout', 'field_counter', $count);
			$this->script .= $script;
			return $script;
	}
	
	function add_field_no_label($name, $html_code, $prefix=''){
			$count = get_register_value('dyn_layout', 'field_counter');
			if(!$count){
				$count = 0;	
			}
			$div_id = 'dyn_field_' .$count;
			set_register_value('dyn_layout_fields', $div_id, array($name, $html_code));
			$html_code = $this->quote_cleanup($html_code);
			$script = "\n \n". $prefix. "add_new_field_row_to_table('$div_id', '$html_code');";
			$count += 1;
			set_register_value('dyn_layout', 'field_counter', $count);
			$this->script .= $script;
			return $script;
			

	}
	
	function add_field($name, $html_code, $html_label, $prefix=''){
		
		
			$count = get_register_value('dyn_layout', 'field_counter');
			if(empty($count)){
				$count = 0;	
			}
			$div_id = 'dyn_field_' .$count;
			$counter1 = $count + 1;
			$div_label_id = 'dyn_field_' . $counter1;
			set_register_value('dyn_layout_fields', $div_id, array($name, $html_code));
			set_register_value('dyn_layout_fields', $div_label_id, array($name.'_label', $html_label));
			$html_code = $this->quote_cleanup($html_code);
			$html_label = $this->quote_cleanup($html_label);
			$script = "\n \n". $prefix. "add_new_field_row_to_table('$div_id', '$html_code');";
			$script .= "\n". $prefix. "add_new_field_row_to_table('$div_label_id', '$html_label');";
			$count += 2;
			set_register_value('dyn_layout', 'field_counter', $count);
			$this->script .= $script;
			return $script;
			/*$this->html .= <<<EOQ
			
			<tr>
				<td nowrap><div id='slot_{$div_label_id}' style='display:inline;cursor:pointer;cursor:hand;border:1px solid #ff0000;'  onclick="swap_div('$div_label_id');"><input type='text' name='add_$div_label_id'  id='add_$div_label_id' value='$html_code'><input type='hidden' id='form_$div_label_id' name='form_$div_label_id' value='-66'><div id='$div_label_id' style='display:inline'>$html_label</div></div></td>
			</tr>
			<tr>	
				<td nowrap><div id='slot_{$div_id}' style='display:inline;cursor:pointer;cursor:hand;border:1px solid #ff0000;'  onclick="swap_div('$div_id');"><input type='text' name='add_$div_id' id='add_$div_id' value='$html_code'><input type='hidden' name='form_$div_id' id='form_$div_id' value='-66'><div id='$div_id' style='display:inline'>$html_code</div></div></td>
			</tr>
EOQ;
$this->counter += 2;
*/

	}
	
	function get_html(){
		global $image_path;
		return '<a href="#" onclick="delete_div()" class="leftColumnModuleS3Link"><table class="contentBox" cellpadding="0" cellspacing="0" border="0" width="100%" id="field_table_MSI"><tr><td>Drag unwanted items here.</td></tr>' . $this->html . '</table></a>';	
	}
	
	function get_script($prefix=''){
		$count = get_register_value('dyn_layout', 'field_counter');
		if(empty($count)){
			$count = 0;	
		}
		return '<script>' . $this->script . "\n$prefix". "field_count_MSI+=$count;" . '</script>';
	}
	
	
}
?>
