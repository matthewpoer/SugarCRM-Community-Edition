<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/modules/Accounts/Account.php,v 1.92 2004/11/10 22:27:36 clint Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_NEW_FORM_TITLE' => 'Nuevo Contacto',
  'LBL_FIRST_NAME' => 'Nombre:',
  'LBL_LAST_NAME' => 'Apellido:',
  'LBL_LIST_LAST_NAME' => 'Apellido',
  'LBL_PHONE' => 'Tel�fono:',
  'LBL_EMAIL_ADDRESS' => 'Email:',
  'LBL_PIPELINE_FORM_TITLE' => 'Mi Portafolio',
  'LNK_NEW_CONTACT' => 'Crear Contacto',
  'LNK_NEW_ACCOUNT' => 'Crear Cuenta',
  'LNK_NEW_OPPORTUNITY' => 'Crear Oportunidad',
  'LNK_NEW_LEAD' => 'Crear Cliente',
  'LNK_NEW_CASE' => 'Crear Caso',
  'LNK_NEW_NOTE' => 'Crear Nota',
  'LNK_NEW_CALL' => 'Crear Llamada',
  'LNK_NEW_EMAIL' => 'Crear Email',
  'LNK_NEW_MEETING' => 'Crear Reuni�n',
  'LNK_NEW_TASK' => 'Crear Tarea',
  'ERR_ONE_CHAR' => 'Porfavor entrar al menos una letra o numero para su busqueda ...',
  'LBL_OPEN_TASKS' => 'Mis tareas abiertas',
);


?>