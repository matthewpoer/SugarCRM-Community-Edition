<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/modules/Accounts/Account.php,v 1.92 2004/11/10 22:27:36 clint Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Contactos',
  'LBL_INVITEE' => 'Reportan',
  'LBL_MODULE_TITLE' => 'Contactos: Inicio',
  'LBL_SEARCH_FORM_TITLE' => 'Buscar Contactos',
  'LBL_LIST_FORM_TITLE' => 'Listar Contactos',
  'LBL_NEW_FORM_TITLE' => 'Nuevo Contacto',
  'LBL_CONTACT_OPP_FORM_TITLE' => 'Contacto-Oportunidad:',
  'LBL_CONTACT' => 'Contacto:',
  'LBL_BUSINESSCARD' => 'Tarjeta',
  'LBL_LIST_NAME' => 'Nombre',
  'LBL_LIST_LAST_NAME' => 'Apellido',
  'LBL_LIST_CONTACT_NAME' => 'Nombre',
  'LBL_LIST_TITLE' => 'Cargo',
  'LBL_LIST_ACCOUNT_NAME' => 'Nombre Cuenta',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email',
  'LBL_LIST_OTHER_EMAIL_ADDRESS' => 'Otro Email',
  'LBL_LIST_PHONE' => 'Tel�fono',
  'LBL_LIST_CONTACT_ROLE' => 'Rol',
  'LBL_LIST_FIRST_NAME' => 'Nombre',
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_email2' => 'LBL_LIST_OTHER_EMAIL_ADDRESS',
  'LBL_EXISTING_CONTACT' => 'Contacto existente',
  'LBL_CREATED_CONTACT' => 'Nuevo contacto creado',
  'LBL_EXISTING_ACCOUNT' => 'Cuenta existente',
//END DON'T CONVERT
  'LBL_CREATED_ACCOUNT' => 'Nueva cuenta creada',
  'LBL_CREATED_CALL' => 'Nueva llamada creada',
  'LBL_CREATED_MEETING' => 'Nueva reuni�n creada',
  'LBL_ADDMORE_BUSINESSCARD' => 'Addicionar otra tarjeta',
  'LBL_ADD_BUSINESSCARD' => 'Crear de tarjeta',
  'LBL_NAME' => 'Nombre:',
  'LBL_CONTACT_NAME' => 'Nombre:',
  'LBL_CONTACT_INFORMATION' => 'Informaci�n',
  'LBL_FIRST_NAME' => 'Nombre:',
  'LBL_OFFICE_PHONE' => 'Tel�fono Oficina:',
  'LBL_ACCOUNT_NAME' => 'Nombre Cuenta:',
  'LBL_ANY_PHONE' => 'Otro Tel�fono:',
  'LBL_PHONE' => 'Tel�fono:',
  'LBL_LAST_NAME' => 'Apellido:',
  'LBL_MOBILE_PHONE' => 'Celular:',
  'LBL_HOME_PHONE' => 'Tel�fono Casa:',
  'LBL_LEAD_SOURCE' => 'Origen:',
  'LBL_OTHER_PHONE' => 'Otro Tel�fono:',
  'LBL_FAX_PHONE' => 'Fax:',
  'LBL_TITLE' => 'Cargo:',
  'LBL_DEPARTMENT' => 'Departamento:',
  'LBL_BIRTHDATE' => 'Cumplea�os:',
  'LBL_EMAIL_ADDRESS' => 'Email:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Otro Email:',
  'LBL_ANY_EMAIL' => 'Otro Email:',
  'LBL_REPORTS_TO' => 'Reportas a:',
  'LBL_ASSISTANT' => 'Asistente:',
  'LBL_ASSISTANT_PHONE' => 'Tel�fono Asistente:',
  'LBL_DO_NOT_CALL' => 'No llamar:',
  'LBL_EMAIL_OPT_OUT' => 'Email Salida:',
  'LBL_PRIMARY_ADDRESS' => 'Direcci�pn Principal:',
  'LBL_ALTERNATE_ADDRESS' => 'Direcci�n Alterna:',
  'LBL_ANY_ADDRESS' => 'Otra Direcci�n:',
  'LBL_CITY' => 'Ciudad:',
  'LBL_STATE' => 'Estado:',
  'LBL_POSTAL_CODE' => 'C�digo Postal:',
  'LBL_COUNTRY' => 'Pa�s:',
  'LBL_DESCRIPTION_INFORMATION' => 'Informaci�n Adicional',
  'LBL_ADDRESS_INFORMATION' => 'Informaci�n Localizaci�n',
  'LBL_DESCRIPTION' => 'Descripci�n:',
  'LBL_CONTACT_ROLE' => 'Rol:',
  'LBL_OPP_NAME' => 'Nombre Oportunidad:',
  'LBL_IMPORT_VCARD' => 'Importar vCard',
  'LBL_IMPORT_VCARDTEXT' => 'Automaticamnete crea nuevo contacto importando una vCard.',
  'LBL_DUPLICATE' => 'Posibles Contactos Duplicados',
  'MSG_DUPLICATE' => 'Crear este contacto puede potencialmente crear un contacto duplicado. Usted puede seleccionar un contacto de la lista siguiente o dar Click en Crear Nuevo Contacto con la informaci�n previamente ingresada.',
  'LNK_CONTACT_LIST' => 'Contactos',
  'LNK_IMPORT_VCARD' => 'Crear de vCard',
  'LNK_NEW_CONTACT' => 'Crear Contacto',
  'LNK_NEW_ACCOUNT' => 'Crear Cuenta',
  'LNK_NEW_OPPORTUNITY' => 'Crear Oportunidad',
  'LNK_NEW_CASE' => 'Crear Caso',
  'LNK_NEW_NOTE' => 'Crear Nota',
  'LNK_NEW_CALL' => 'Crear Llamada',
  'LNK_NEW_EMAIL' => 'Crear Email',
  'LNK_NEW_MEETING' => 'Crear Reuni�n',
  'LNK_NEW_TASK' => 'Crear Tarea',
  'LNK_NEW_APPOINTMENT' => 'Crear Cita',
  'NTC_DELETE_CONFIRMATION' => 'Esta seguro de querer borrar este registro?',
  'NTC_REMOVE_CONFIRMATION' => 'Esta seguro de querer remover este contacto de este caso?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Esta seguro de querer remover este registro como reporte directo?',
  'ERR_DELETE_RECORD' => 'Un registro debe ser especificado para borrar el contacto.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Copiar direcci�n principal a direcci�n alterna',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Copiar direcci�n alterna a direcci�n principal',
  'LBL_SALUTATION' => 'Saludo',
);


?>