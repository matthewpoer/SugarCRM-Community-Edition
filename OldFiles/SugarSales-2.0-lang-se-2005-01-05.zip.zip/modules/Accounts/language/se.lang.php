<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/modules/Accounts/Account.php,v 1.92 2004/11/10 22:27:36 clint Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'F�retag',
  'LBL_MODULE_TITLE' => 'F�retag: Hem',
  'LBL_SEARCH_FORM_TITLE' => 'S�k F�retag',
  'LBL_LIST_FORM_TITLE' => 'F�retagslista',
  'LBL_NEW_FORM_TITLE' => 'Nytt F�retag',
  'LBL_MEMBER_ORG_FORM_TITLE' => 'Medlems Organisationer',
  'LBL_LIST_ACCOUNT_NAME' => 'F�retags Namn',
  'LBL_LIST_CITY' => 'Ort',
  'LBL_LIST_WEBSITE' => 'Website',
  'LBL_LIST_STATE' => 'Stat',
  'LBL_LIST_PHONE' => 'Telefon',
  'LBL_LIST_EMAIL_ADDRESS' => '*Email Address',
  'LBL_LIST_CONTACT_NAME' => '*Contact Name',
  'db_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_website' => 'LBL_LIST_WEBSITE',
  'db_billing_address_city' => 'LBL_LIST_CITY',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'LBL_ACCOUNT_INFORMATION' => '*Account Information',
  'LBL_ACCOUNT' => 'F�retag:',
  'LBL_ACCOUNT_NAME' => 'F�retags Namn:',
//END DON'T CONVERT
  'LBL_PHONE' => 'Telefon:',
  'LBL_WEBSITE' => 'Website:',
  'LBL_FAX' => 'Fax:',
  'LBL_TICKER_SYMBOL' => 'Ticker Symbol:',
  'LBL_OTHER_PHONE' => '�vrig Telefon:',
  'LBL_ANY_PHONE' => 'Telefon:',
  'LBL_MEMBER_OF' => 'Medlem av:',
  'LBL_EMAIL' => 'Epost:',
  'LBL_EMPLOYEES' => 'Anst�llda:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Annan Epost:',
  'LBL_ANY_EMAIL' => 'Epost:',
  'LBL_OWNERSHIP' => '�gande:',
  'LBL_RATING' => 'Rating:',
  'LBL_INDUSTRY' => 'Bransch:',
  'LBL_SIC_CODE' => 'SIC Code:',
  'LBL_TYPE' => 'Typ:',
  'LBL_ANNUAL_REVENUE' => 'Oms�ttning:',
  'LBL_ADDRESS_INFORMATION' => 'Adressinformation',
  'LBL_BILLING_ADDRESS' => 'Faktureringsadress:',
  'LBL_SHIPPING_ADDRESS' => 'Postadress:',
  'LBL_ANY_ADDRESS' => '�vrig adress:',
  'LBL_CITY' => 'Ort:',
  'LBL_STATE' => 'Stat:',
  'LBL_POSTAL_CODE' => 'Postnummer:',
  'LBL_COUNTRY' => 'Land:',
  'LBL_DESCRIPTION_INFORMATION' => 'Beskrivning',
  'LBL_DESCRIPTION' => 'Beskrivning:',
  'NTC_COPY_BILLING_ADDRESS' => 'Kopiera faktureringsadress till postadress',
  'NTC_COPY_SHIPPING_ADDRESS' => 'Kopiera postadress till faktureringsadress',
  'NTC_REMOVE_MEMBER_ORG_CONFIRMATION' => '�r du s�ker p� att du vill ta bort denna post som medlemsorganisation?',
  'LBL_DUPLICATE' => 'Possible Duplicate Account',
  'MSG_DUPLICATE' => 'Creating this account may potentialy create a duplicate account. You may either select an account from the list below or you may click on Create New Account to continue creating a new account with the previously entered data.',
  'LNK_NEW_ACCOUNT' => 'Nytt F�retag',
  'LNK_ACCOUNT_LIST' => 'Accounts',
  'LBL_INVITEE' => '*Contacts',
  'ERR_DELETE_RECORD' => 'Ett Post nummer m�ste anges f�r att radera F�retaget.',
  'NTC_DELETE_CONFIRMATION' => 'Are you sure you want to delete this record?',
  'LNK_NEW_CONTACT' => 'Ny Kontakt',
  'LNK_NEW_OPPORTUNITY' => 'Ny Aff�r',
  'LNK_NEW_CASE' => 'Nytt �rende',
  'LNK_NEW_NOTE' => 'Ny Anteckning',
  'LNK_NEW_CALL' => 'Nytt Samtal',
  'LNK_NEW_EMAIL' => 'Nytt Epost',
  'LNK_NEW_MEETING' => 'Nytt M�te',
  'LNK_NEW_TASK' => 'Ny Uppgift',
);


?>