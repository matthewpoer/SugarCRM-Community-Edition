<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Calls/language/sp_ve.lang.php,v 1.14 2004/08/20 13:09:32 sugarclint Exp $
 * Description:  Defines the Spanish language pack for the Account module.
 ********************************************************************************/

$mod_strings = Array(
'LBL_MODULE_NAME'=>'Llamadas',
'LBL_MODULE_TITLE'=>'Llamadas: Inicio',
'LBL_SEARCH_FORM_TITLE'=>'B�squeda Llamadas',
'LBL_LIST_FORM_TITLE'=>'Lista Llamadas',
'LBL_NEW_FORM_TITLE'=>'Programaci�n Llamadas',

'LBL_LIST_CLOSE'=>'Cerrar',
'LBL_LIST_SUBJECT'=>'Asunto',
'LBL_LIST_CONTACT'=>'Contacto',
'LBL_LIST_RELATED_TO'=>'Relacionado a',
'LBL_LIST_DATE'=>'Fecha Inicio',
'LBL_LIST_TIME'=>'Hora Inicio',
'LBL_LIST_DURATION'=>'Duraci�n',

'LBL_SUBJECT'=>'Asunto:',
'LBL_CONTACT_NAME'=>'Contacto:',
'LBL_DESCRIPTION_INFORMATION'=>'Informaci�n Descripci�n',
'LBL_DESCRIPTION'=>'Descripci�n:',
'LBL_STATUS'=>'Estado:',
'LBL_DATE'=>'Fecha:',
'LBL_DURATION'=>'Duraci�n:',
'LBL_HOURS_MINUTES'=>'(horas/minutos)',
'LBL_CALL'=>'Llamada:',
'LBL_DATE_TIME'=>"Fecha y Hora Inicio:",
'LBL_DATE'=>"Fecha Inicio:",
'LBL_TIME'=>"Hora Inicio:",
'LBL_HOURS_ABBREV'=>'h',
'LBL_MINSS_ABBREV'=>'m',
'LBL_COLON'=>':',
'LBL_DEFAULT_STATUS'=>'Planificado',

'LNK_NEW_CONTACT'=>'Nuevo Contacto',
'LNK_NEW_ACCOUNT'=>'Nueva Cuenta',
'LNK_NEW_OPPORTUNITY'=>'Nueva Oportunidad',
'LNK_NEW_CASE'=>'Nuevo Caso',
'LNK_NEW_NOTE'=>'Nueva Nota',
'LNK_NEW_CALL'=>'Nueva Llamada',
'LNK_NEW_EMAIL'=>'Nuevo Email',
'LNK_NEW_MEETING'=>'Nueva Reuni�n',
'LNK_NEW_TASK'=>'Nueva Tarea',
'ERR_DELETE_RECORD'=>"Un n�mero de registro debe ser indicado para borrar la cuenta.",
'NTC_REMOVE_INVITEE'=>'�Est� seguro que desea remover ste invitado de la llamada?',
'LBL_INVITEES'=>'Invitados',
);

?>