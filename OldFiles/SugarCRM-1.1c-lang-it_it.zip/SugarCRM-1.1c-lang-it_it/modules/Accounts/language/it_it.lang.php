<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Accounts/language/en_us.lang.php,v 1.6 2004/08/03 07:43:13 sugarclint Exp $
 * Description:  Defines the English language pack 
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_MODULE_NAME'=>'Clienti',
'LBL_MODULE_TITLE'=>'Client: Home',
'LBL_SEARCH_FORM_TITLE'=>'Cerca Cliente',
'LBL_LIST_FORM_TITLE'=>'Elenco Clienti',
'LBL_NEW_FORM_TITLE'=>'Nuovo Cliente',
'LBL_MEMBER_ORG_FORM_TITLE'=>'Membri delle organizzazioni',

'LBL_LIST_ACCOUNT_NAME'=>'Nome del Cliente',
'LBL_LIST_CITY'=>'Città',
'LBL_LIST_WEBSITE'=>'Sito web',
'LBL_LIST_STATE'=>'Età',
'LBL_LIST_PHONE'=>'Telefono',

'LBL_ACCOUNT'=>'Cliente:',
'LBL_ACCOUNT_NAME'=>'Nome del Cliente:',
'LBL_PHONE'=>'Telefono:',
'LBL_WEBSITE'=>'Sito web:',
'LBL_FAX'=>'Fax:',
'LBL_TICKER_SYMBOL'=>'Ticker:',
'LBL_OTHER_PHONE'=>'Altro Telefono:',
'LBL_ANY_PHONE'=>'Telefono alternativo:',
'LBL_MEMBER_OF'=>'Membro di:',
'LBL_EMAIL'=>'Email:',
'LBL_EMPLOYEES'=>'Dipendenti:',
'LBL_OTHER_EMAIL_ADDRESS'=>'Altra Email:',
'LBL_ANY_EMAIL'=>'Email alternativa:',
'LBL_OWNERSHIP'=>'Proprietario:',
'LBL_RATING'=>'Note:',
'LBL_INDUSTRY'=>'Attività',
'LBL_SIC_CODE'=>'Partita IVA:',
'LBL_TYPE'=>'Tipo:',
'LBL_ANNUAL_REVENUE'=>'Fatturato Annuo:',
'LBL_ADDRESS_INFORMATION'=>'Indirizzo',
'LBL_BILLING_ADDRESS'=>'Indirizzo di Fatturazione:',
'LBL_SHIPPING_ADDRESS'=>'Indirizzo di Spedizione:',
'LBL_ANY_ADDRESS'=>'Altro Indirizzo:',
'LBL_CITY'=>'Città:',
'LBL_STATE'=>'Provincia:',
'LBL_POSTAL_CODE'=>'C.A.P.:',
'LBL_COUNTRY'=>'Nazione:',
'LBL_DESCRIPTION_INFORMATION'=>'Descrizione',
'LBL_DESCRIPTION'=>'Descrizione:',
'NTC_COPY_BILLING_ADDRESS'=>'Copia indirizzo di fatturazione come indirizzo di spedizione',
'NTC_COPY_SHIPPING_ADDRESS'=>'Copia indirizzo di spedizione come indirizzo di fatturazione',
'NTC_REMOVE_MEMBER_ORG_CONFIRMATION'=>'Sei sicuro di voler eliminare questa informazione?',

'LNK_NEW_CONTACT'=>'Nuovo Contatto',
'LNK_NEW_ACCOUNT'=>'Nuovo Cliente',
'LNK_NEW_OPPORTUNITY'=>'Nuova Opportunità',
'LNK_NEW_CASE'=>'Nuovo Ticket Supporto',
'LNK_NEW_NOTE'=>'Nuova Nota',
'LNK_NEW_CALL'=>'Nuova Chiamata',
'LNK_NEW_EMAIL'=>'Nuova Email',
'LNK_NEW_MEETING'=>'Nuova Riunione',
'LNK_NEW_TASK'=>'Nuovo Task',
'ERR_DELETE_RECORD'=>"Devi specificare un numero record per eliminare il cliente.",


);

?>