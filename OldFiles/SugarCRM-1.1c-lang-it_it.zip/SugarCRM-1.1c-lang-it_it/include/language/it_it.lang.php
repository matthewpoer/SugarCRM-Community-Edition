<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/include/language/en_us.lang.php,v 1.22 2004/08/03 09:48:58 sugarclint Exp $
 * Description:  Defines the English language pack for the base application.
 ********************************************************************************/
 
$app_strings = Array(
'LBL_CHARSET'=>'ISO-8859-1',
'LBL_BROWSER_TITLE'=>'SugarCRM - CRM commerciale Open Source',
'LBL_MY_ACCOUNT'=>'Il mio account',
'LBL_ADMIN'=>'Amministra',
'LBL_LOGOUT'=>'Logout',
'LBL_SEARCH'=>'Cerca',
'LBL_LAST_VIEWED'=>'Ultime visualizzazioni',
'NTC_WELCOME'=>'Benvenuto',
'NTC_SUPPORT_SUGARCRM'=>"Supporta il progetto open source SugarCRM con una donazione via PayPal - è rapido, gratuito e sicuro !",
'NTC_NO_ITEMS_DISPLAY'=>'nessuno',
'LBL_ALT_HOT_KEY'=>'Alt+',

'LBL_SAVE_BUTTON_TITLE'=>'Salva [Alt+S]',
'LBL_EDIT_BUTTON_TITLE'=>'Modifica [Alt+E]',
'LBL_EDIT_BUTTON'=>'Modifica',
'LBL_DUPLICATE_BUTTON_TITLE'=>'Duplica [Alt+U]',
'LBL_DUPLICATE_BUTTON'=>'Duplica',
'LBL_DELETE_BUTTON_TITLE'=>'Elimina [Alt+D]',
'LBL_DELETE_BUTTON'=>'Elimina',
'LBL_NEW_BUTTON_TITLE'=>'Nuovo [Alt+N]',
'LBL_CHANGE_BUTTON_TITLE'=>'Cambia [Alt+G]',
'LBL_CANCEL_BUTTON_TITLE'=>'Annulla [Alt+X]',
'LBL_SEARCH_BUTTON_TITLE'=>'Cerca [Alt+Q]',
'LBL_CLEAR_BUTTON_TITLE'=>'Annulla [Alt+C]',
'LBL_SELECT_BUTTON_TITLE'=>'Seleziona [Alt+T]',
'LBL_SAVE_BUTTON_KEY'=>'S',
'LBL_EDIT_BUTTON_KEY'=>'E',
'LBL_DUPLICATE_BUTTON_KEY'=>'U',
'LBL_DELETE_BUTTON_KEY'=>'D',
'LBL_NEW_BUTTON_KEY'=>'N',
'LBL_CHANGE_BUTTON_KEY'=>'G',
'LBL_CANCEL_BUTTON_KEY'=>'X',
'LBL_SEARCH_BUTTON_KEY'=>'Q',
'LBL_CLEAR_BUTTON_KEY'=>'C',
'LBL_SELECT_BUTTON_KEY'=>'T',
'LBL_SAVE_BUTTON_LABEL'=>'Salva',
'LBL_EDIT_BUTTON_LABEL'=>'Modifica',
'LBL_DUPLICATE_BUTTON_LABEL'=>'Duplica',
'LBL_DELETE_BUTTON_LABEL'=>'Elimina',
'LBL_NEW_BUTTON_LABEL'=>'Nuovo',
'LBL_CHANGE_BUTTON_LABEL'=>'Modifica',
'LBL_CANCEL_BUTTON_LABEL'=>'Annulla',
'LBL_SEARCH_BUTTON_LABEL'=>'Cerca',
'LBL_CLEAR_BUTTON_LABEL'=>'Annulla',
'LBL_SELECT_BUTTON_LABEL'=>'Seleziona',

'LNK_ADVANCED_SEARCH'=>'Avanzata',
'LNK_BASIC_SEARCH'=>'Normale',
'LNK_EDIT'=>'modifica',
'LNK_REMOVE'=>'elimina',
'LNK_DELETE'=>'cancella',
'LNK_LIST_START'=>'Inizio',
'LNK_LIST_NEXT'=>'Successivo',
'LNK_LIST_PREVIOUS'=>'Precedente',
'LNK_LIST_END'=>'Fine',
'LBL_LIST_OF'=>'di',
'LNK_PRINT'=>'Stampa',
'LNK_HELP'=>'Aiuto',

'NTC_REQUIRED'=>'Indica un campo obbligatorio',
'LBL_REQUIRED_SYMBOL'=>'*',
'LBL_CURRENCY_SYMBOL'=>'EUR.',
'LBL_THOUSANDS_SYMBOL'=>'K',
'NTC_DATE_FORMAT'=>'(aaaa-mm-jj)',
'NTC_TIME_FORMAT'=>'(24:00)',
'NTC_DATE_TIME_FORMAT'=>'(aaaa-mm-jj 24:00)',
'NTC_DELETE_CONFIRMATION'=>'Sei sicuro di voler eliminare questo record ?',
'ERR_DELETE_RECORD'=>"Deve essere specificato un numero record per eliminare il contatto.",
'ERR_CREATING_TABLE'=>'Errore nella creazione della tabella: ',
'ERR_CREATING_FIELDS'=>'Errore nell\'inserimento di dati aggiuntivi nei campi: ',
'ERR_MISSING_REQUIRED_FIELDS'=>'Mancano i campi richiesti:',
'ERR_INVALID_EMAIL_ADDRESS'=>"indirizzo email non valido.",
'ERR_INVALID_DATE_FORMAT'=>'Il formato della data deve essere: aaaa-mm-jj',
'ERR_INVALID_MONTH'=>'Prego inserisci un mese valido.',
'ERR_INVALID_DAY'=>'Prego inserisci un giorno valido.',
'ERR_INVALID_YEAR'=>'Prego inserisci un anno a 4 cifre valido.',
'ERR_INVALID_DATE'=>'Prego inserisci una data valida.',
'ERR_INVALID_HOUR'=>'Prego inserisci un\'ora valida.',
'ERR_INVALID_TIME'=>'Prego inserisci un orario valido.',
'NTC_CLICK_BACK'=>'Prego utilizza il bottone "indietro" del browser e correggi il problema.',
'LBL_LIST_ASSIGNED_USER'=>'Assegnato a ',
'LBL_ASSIGNED_TO'=>'Assegnato a:',
'LBL_CURRENT_USER_FILTER'=>'Solo i miei elementi:',



//New to SugarCRM 1.1c.  Still need to be translated.
'LBL_SELECT_CONTACT_BUTTON_TITLE'=>'Seleziona Contatto [Alt+T]',
'LBL_SELECT_CONTACT_BUTTON_KEY'=>'T',
'LBL_SELECT_CONTACT_BUTTON_LABEL'=>'Seleziona Contatto',
'LBL_SELECT_USER_BUTTON_TITLE'=>'Seleziona Utente [Alt+U]',
'LBL_SELECT_USER_BUTTON_KEY'=>'U',
'LBL_SELECT_USER_BUTTON_LABEL'=>'Seleziona Utente',
'LBL_LIST_NAME'=>'Nome',
'LBL_LIST_USER_NAME'=>'Nome Utente',
'LBL_LIST_EMAIL'=>'Email',
'LBL_LIST_PHONE'=>'Telefono',
'LBL_LIST_CONTACT_NAME'=>'Nome Contatto',
'LBL_LIST_ACCOUNT_NAME'=>'Nome Cliente',
'LBL_USER_LIST'=>'Lista Utenti',
'LBL_CONTACT_LIST'=>'Lista Contatti',
'NTC_LOGIN_MESSAGE'=>"Prego fai login all\'applicazione.",
'LBL_NONE'=>'--Nessuno--',
);

//the left value is the key stored in the db and the right value is the display value
//to translate, only modify the right value in each key/value pair
$app_list_strings = Array(
//e.g. auf Deutsch 'Contacts'=>'Contakten', 
'moduleList' => Array('Home'=>'Home' 
				, 'Dashboard'=>'Tableau de bord' 
				, 'Contacts'=>'Contatti' 
				, 'Accounts'=>'Clienti'
				, 'Opportunities'=>'Opportunità' 
				, 'Cases'=>'Ticket Supporto' 
				, 'Notes'=>'Note' 
				, 'Calls'=>'Chiamata'
				, 'Emails'=>'Email'
				, 'Meetings'=>'Riunioni' 
				, 'Tasks'=>'Task'),

//e.g. en français 'Analyst'=>'Analyste', 
'account_type_dom' => Array(''=>''
		, 'Analyst'=>'Analista'
		, 'Competitor'=>'Concorrenza'
		, 'Customer'=>'Cliente'
		, 'Integrator'=>'Integratore'
		, 'Investor'=>'Investitore'
		, 'Partner'=>'Partner'
		, 'Press'=>'Stampa'
		, 'Prospect'=>'Prospect'
		, 'Reseller'=>'Rivenditore'
		, 'Other'=>'Altro'
		),
		
//e.g. en español 'Apparel'=>'Ropa', 
'industry_dom' => Array(''=>''
		, 'Apparel'=>'Tessile'
		, 'Banking'=>'Banca'
		, 'Biotechnology'=>'Biotecnologie'
		, 'Chemicals'=>'Industria Chimica'
		, 'Communications'=>'Communicazioni'
		, 'Construction'=>'Construzioni'
		, 'Consulting'=>'Consulenza'
		, 'Education'=>'Educazione'
		, 'Electronics'=>'Informatica - Elettronica'
		, 'Energy'=>'Energia'
		, 'Engineering'=>'Ingenieria'
		, 'Entertainment'=>'Cultura-Stampa'
		, 'Environmental'=>'Ambiente'
		, 'Finance'=>'Finanza'
		, 'Food & Beverage'=>'Agro-alimentare'
		, 'Government'=>'Pubblica Amministratione'
		, 'Healthcare'=>'Sanità'
		, 'Hospitality'=>'Ospitalità'
		, 'Insurance'=>'Assicurazione'
		, 'Machinery'=>'Industria Compon.'
		, 'Manufacturing'=>'Industria Manifatt.'
		, 'Media'=>'Media'
		, 'Not For Profit'=>'Non Profit'
		, 'Recreation'=>'Ricreazione'
		, 'Retail'=>'Commercio Retail'
		, 'Shipping'=>'Trasporti e Logistica'
		, 'Technology'=>'Tecnologie'
		, 'Telecommunications'=>'Telecommunicazioni'
		, 'Transportation'=>'Viaggi e turismo'
		, 'Utilities'=>'Servizi e utility'
		, 'Other'=>'Altro'
		),

'lead_source_dom' => Array(''=>''
		, 'Cold Call'=>'Chiamata a Freddo'
		, 'Existing Customer'=>'Cliente Esistente'
		, 'Self Generated'=>'Auto Generata'
		, 'Employee'=>'Impiegato'
		, 'Partner'=>'Partner'
		, 'Public Relations'=>'Pubbliche Relazioni'
		, 'Direct Mail'=>'Direct Mailing'
		, 'Conference'=>'Conferenza'
		, 'Trade Show'=>'Trade Show'
		, 'Web Site'=>'Sito web'
		, 'Word of mouth'=>'Segnalazione personale'
		, 'Other'=>'Altro'
		),

'opportunity_type_dom' => Array(''=>''
		, 'Existing Business'=>'Business esistente'
		, 'New Business'=>'Nuovo affare'
		),

//Note:  do not translate opportunity_relationship_type_default_key
//       it is the key for the default opportunity_relationship_type_dom value
'opportunity_relationship_type_default_key' => 'Primary Decision Maker',
'opportunity_relationship_type_dom' => Array(''=>''
		, 'Primary Decision Maker'=>'Decision Maker Primario'
		, 'Business Decision Maker'=>'Decision Maker - business'
		, 'Business Evaluator'=>'Valutatore - Business'
		, 'Technical Decision Maker'=>'Decision Maker - Tecnico'
		, 'Technical Evaluator'=>'Valutatore - Tecnico'
		, 'Executive Sponsor'=>'Sponsor'
		, 'Influencer'=>'Esercita Influenza'
		, 'Other'=>'Altro'
		),
		
//Note:  do not translate case_relationship_type_default_key
//       it is the key for the default case_relationship_type_dom value
'case_relationship_type_default_key' => 'Contact Principal',
'case_relationship_type_dom' => Array(''=>''
		, 'Primary Contact'=>'Contatto Principale'
		, 'Alternate Contact'=>'Contato Alternativo'
		),
		
'sales_stage_dom' => Array('Prospecting'=>'Prospection'
		, 'Qualification'=>'Qualificazione'
		, 'Needs Analysis'=>'Analisi Bisogni'
		, 'Value Proposition'=>'Propos. Valore'
		, 'Id. Decision Makers'=>'Id. Decision Maker'
		, 'Perception Analysis'=>'Analisi Percezione'
		, 'Proposal/Price Quote'=>'Proposta Economica'
		, 'Negotiation/Review'=>'Negoziazione/Review'
		, 'Closed Won'=>'Chiuso Vinto'
		, 'Closed Lost'=>'Chiuso Preso'
		),

'salutation_dom' => Array(''=>''
		, 'Mr.'=>'Sig.'
		, 'Ms.'=>'Sig.na.'
		, 'Mrs.'=>'Sig.ra.'
		, 'Dr.'=>'Dr.'
		, 'Prof.'=>'Prof.'
		),

'task_priority_dom' => Array('High'=>'Alto'
		, 'Medium'=>'Medio'
		, 'Low'=>'Basso'
		),

'task_status_dom' => Array('Not Started'=>'Non Iniziato'
		, 'In Progress'=>'In Corso'
		, 'Completed'=>'Completato'
		, 'Pending Input'=>'In attesa di azione'
		, 'Deferred'=>'Rimandato'
		),

'meeting_status_dom' => Array('Planned'=>'Pianificato'
		, 'Held'=>'Confermato'
		, 'Not Held'=>'Non Confermato'
		),

'call_status_dom' => Array('Planned'=>'Pianificato'
		, 'Held'=>'Confermato'
		, 'Not Held'=>'Non Confermato'
		),

'case_status_dom' => Array('New'=>'Nuovo'
		, 'Assigned'=>'Assegnato'
		, 'Closed'=>'Chiuso'
		, 'Pending Input'=>'In attesa di azione'
		, 'Rejected'=>'Respinto'
		),

'user_status_dom' => Array('Active'=>'Attivo'
		, 'Inactive'=>'Inattivo'
		),

//Note:  do not translate record_type_default_key
//       it is the key for the default record_type_module value
'record_type_default_key' => 'Account',
'record_type_display' => array('Account' => 'Cliente', 
		'Opportunity' => 'Opportunità', 
		'Case' => 'Ticket Supporto'),

);

?>