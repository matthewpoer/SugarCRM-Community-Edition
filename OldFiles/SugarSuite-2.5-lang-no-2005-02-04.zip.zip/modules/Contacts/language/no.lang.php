<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Kontakter',
  'LBL_INVITEE' => 'Direkte Rapporter',
  'LBL_MODULE_TITLE' => 'Kontakter : Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'S&oslash;k Kontakt',
  'LBL_LIST_FORM_TITLE' => 'Kontaktliste',
  'LBL_NEW_FORM_TITLE' => 'Ny Kontakt',
  'LBL_CONTACT_OPP_FORM_TITLE' => 'Kontakt - Virksomhet:',
  'LBL_CONTACT' => 'Kontakt:',
  'LBL_BUSINESSCARD' => 'Business Card',
  'LBL_LIST_NAME' => 'Navn',
  'LBL_LIST_LAST_NAME' => 'Etternavn',
  'LBL_LIST_CONTACT_NAME' => 'Kontaktnavn',
  'LBL_LIST_TITLE' => 'Tittel',
  'LBL_LIST_ACCOUNT_NAME' => 'Virksomhet',
  'LBL_LIST_EMAIL_ADDRESS' => 'Epost',
  'LBL_LIST_OTHER_EMAIL_ADDRESS' => 'Other Email',
  'LBL_LIST_PHONE' => 'Telefon',
  'LBL_LIST_CONTACT_ROLE' => 'Rolle',
  'LBL_LIST_FIRST_NAME' => 'First Name',
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_email2' => 'LBL_LIST_OTHER_EMAIL_ADDRESS',
  'LBL_EXISTING_CONTACT' => 'Used an existing contact',
  'LBL_CREATED_CONTACT' => 'Created a new contact',
  'LBL_EXISTING_ACCOUNT' => 'Used an existing account',
//END DON'T CONVERT
  'LBL_CREATED_ACCOUNT' => 'Created a new account',
  'LBL_CREATED_CALL' => 'Created a new call',
  'LBL_CREATED_MEETING' => 'Created a new meeting',
  'LBL_ADDMORE_BUSINESSCARD' => 'Add another business card',
  'LBL_ADD_BUSINESSCARD' => 'Create From Business Card',
  'LBL_NAME' => 'Navn:',
  'LBL_CONTACT_NAME' => 'Kontakt Navn:',
  'LBL_CONTACT_INFORMATION' => 'Kontakt Information',
  'LBL_FIRST_NAME' => 'Fornavn:',
  'LBL_OFFICE_PHONE' => 'Firmatlf:',
  'LBL_ACCOUNT_NAME' => 'Virksomhet:',
  'LBL_ANY_PHONE' => 'Telefon:',
  'LBL_PHONE' => 'Telefon:',
  'LBL_LAST_NAME' => 'Etternavn:',
  'LBL_MOBILE_PHONE' => 'Mobiltlf:',
  'LBL_HOME_PHONE' => 'Hjemmetlf:',
  'LBL_LEAD_SOURCE' => 'Kilde:',
  'LBL_OTHER_PHONE' => 'Annen Telefon:',
  'LBL_FAX_PHONE' => 'Faks:',
  'LBL_PRIMARY_ADDRESS_STREET' => 'Primary Address Street:',
  'LBL_PRIMARY_ADDRESS_CITY' => 'Primary Address City:',
  'LBL_PRIMARY_ADDRESS_COUNTRY' => 'Primary Address Country:',
  'LBL_PRIMARY_ADDRESS_STATE' => 'Primary Address State:',
  'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'Primary Address Postal Code:',
  'LBL_ALT_ADDRESS_STREET' => 'Alternate Address Street:',
  'LBL_ALT_ADDRESS_CITY' => 'Alternate Address City:',
  'LBL_ALT_ADDRESS_COUNTRY' => 'Alternate Address Country:',
  'LBL_ALT_ADDRESS_STATE' => 'Alternate Address State:',
  'LBL_ALT_ADDRESS_POSTALCODE' => 'Alternate Address Postal Code:',
  'LBL_TITLE' => 'Tittel:',
  'LBL_DEPARTMENT' => 'Avdeling:',
  'LBL_BIRTHDATE' => 'F&oslash;dselsdato:',
  'LBL_EMAIL_ADDRESS' => 'Epost:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Annen Epost:',
  'LBL_ANY_EMAIL' => 'Epost:',
  'LBL_REPORTS_TO' => 'Rapporterer Til:',
  'LBL_ASSISTANT' => 'Assistent:',
  'LBL_ASSISTANT_PHONE' => 'Assistent Telefon:',
  'LBL_DO_NOT_CALL' => '�nsker ikke opkald:',
  'LBL_EMAIL_OPT_OUT' => '�nsker ikke epost:',
  'LBL_PRIMARY_ADDRESS' => 'Prim&aelig;r Adresse:',
  'LBL_ALTERNATE_ADDRESS' => 'Annen Adresse:',
  'LBL_ANY_ADDRESS' => 'Adresse:',
  'LBL_CITY' => 'By:',
  'LBL_STATE' => 'Fylke:',
  'LBL_POSTAL_CODE' => 'Postnummer:',
  'LBL_COUNTRY' => 'Land:',
  'LBL_DESCRIPTION_INFORMATION' => 'Beskrivelse',
  'LBL_ADDRESS_INFORMATION' => 'Addresse Information',
  'LBL_DESCRIPTION' => 'Beskrivelse:',
  'LBL_CONTACT_ROLE' => 'Rolle:',
  'LBL_OPP_NAME' => 'Virksomhet Navn:',
  'LBL_IMPORT_VCARD' => 'Import vCard',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new contact by importing a vCard from your file system.',
  'LBL_DUPLICATE' => 'Possible Duplicate Contacts',
  'MSG_SHOW_DUPLICATES' => 'Creating this contact may potentialy create a duplicate contact. You may either click on Create Contact to continue creating this new contact with the previously entered data or you may click Cancel.',
  'MSG_DUPLICATE' => 'Creating this contact may potentialy create a duplicate contact. You may either select a contact from the list below or you may click on Create New Contact to continue creating a new contact with the previously entered data.',
  'LNK_CONTACT_LIST' => 'Contacts',
  'LNK_IMPORT_VCARD' => 'Create From vCard',
  'LNK_NEW_CONTACT' => 'Ny Kontakt',
  'LNK_NEW_ACCOUNT' => 'Ny Virksomhet',
  'LNK_NEW_OPPORTUNITY' => 'Ny Salgs Mulighet',
  'LNK_NEW_CASE' => 'Ny Sak',
  'LNK_NEW_NOTE' => 'Nytt Notat',
  'LNK_NEW_CALL' => 'Ny Samtale',
  'LNK_NEW_EMAIL' => 'Ny Epost',
  'LNK_NEW_MEETING' => 'Nytt M&oslash;te',
  'LNK_NEW_TASK' => 'Ny Oppgave',
  'LNK_NEW_APPOINTMENT' => 'Create Appointment',
  'NTC_DELETE_CONFIRMATION' => 'Er du sikker p&aring; at du vil slette denne oppf&oslash;ringen?',
  'NTC_REMOVE_CONFIRMATION' => 'Er du sikker p&aring; at du vil slette Kontakten fra denne Virksomheten?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Er du sikker p&aring; at du vil slette denne oppf&oslash;ringen som direkte rapporterende?',
  'ERR_DELETE_RECORD' => 'Et Postnummer skal oppgis for &aring; slette denne Kontakten.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Kopier prim&aelig;r adresse til sekund&aelig;r adresse',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Kopier sekund&aelig;r adresse til prim&aelig;r adresse',
  'LBL_SALUTATION' => 'Salutation',
  'LBL_SAVE_CONTACT' => 'Save Contact',
  'LBL_YAHOO_ID' => 'Yahoo! ID:',
);


?>