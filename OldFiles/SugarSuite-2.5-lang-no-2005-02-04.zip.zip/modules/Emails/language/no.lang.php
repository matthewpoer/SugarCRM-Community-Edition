<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master/project/utils/sync_lang.php,v 1.3 2004/11/11 00:42:50 julian Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Epost',
  'LBL_MODULE_TITLE' => 'Epost : Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'S&oslash;k Epost',
  'LBL_LIST_FORM_TITLE' => 'Epost liste',
  'LBL_NEW_FORM_TITLE' => 'Oppf&oslash;lgings Epost',
  'LBL_LIST_SUBJECT' => 'Vedr&oslash;rende',
  'LBL_LIST_CONTACT' => 'Kontakt',
  'LBL_LIST_RELATED_TO' => 'Relatert til',
  'LBL_LIST_DATE' => 'Sendt Dato',
  'LBL_LIST_TIME' => 'Sendt Tid',
  'ERR_DELETE_RECORD' => 'Et Postnummer skal oppgis for &aring; slette Virksomheten.',
  'LBL_DATE_SENT' => 'Sendt Dato:',
  'LBL_SUBJECT' => 'Vedr&oslash;rende:',
  'LBL_BODY' => 'Innhold:',
  'LBL_DATE_AND_TIME' => 'Sendt Dato & Tid:',
  'LBL_DATE' => 'Sendt Dato:',
  'LBL_TIME' => 'Sendt Tid:',
  'LBL_CONTACT_NAME' => ' Kontakt Navn: ',
  'LBL_EMAIL' => 'Epost:',
  'LBL_COLON' => ':',
  'NTC_REMOVE_INVITEE' => 'Er du sikker p&aring; &aring; slette denne mottakeren fra Epost?',
  'LBL_INVITEE' => 'Mottakere',
  'LNK_NEW_CALL' => 'Ny Samtale',
  'LNK_NEW_MEETING' => 'Nytt M&oslash;te',
  'LNK_NEW_TASK' => 'Ny Oppgave',
  'LNK_NEW_NOTE' => 'Nytt Notat',
  'LNK_NEW_EMAIL' => 'Ny Epost',
  'LNK_CALL_LIST' => 'Calls',
  'LNK_MEETING_LIST' => 'Meetings',
  'LNK_TASK_LIST' => 'Tasks',
  'LNK_NOTE_LIST' => 'Notes',
  'LNK_EMAIL_LIST' => 'Emails',
  'LNK_VIEW_CALENDAR' => 'Today',
  'LNK_NEW_CONTACT' => 'Ny Kontakt',
  'LNK_NEW_ACCOUNT' => 'Ny Virksomhet',
  'LNK_NEW_OPPORTUNITY' => 'Ny Salgs Mulighet',
  'LNK_NEW_CASE' => 'Nytt Sak',
);


?>