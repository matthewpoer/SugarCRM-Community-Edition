<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Contacts/language/en_us.lang.php,v 1.17 2004/09/09 06:26:45 jostrow Exp $
 * Description:  Defines the English language pack
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = Array(
'LBL_MODULE_NAME'=>'Contactpersonen',
'LBL_INVITEE'=>'Rapporteert aan:',
'LBL_MODULE_TITLE'=>'Contactpersonen: Home',
'LBL_SEARCH_FORM_TITLE'=>'Contactpersoon Zoeken',
'LBL_LIST_FORM_TITLE'=>'Contactpersoon Lijst',
'LBL_NEW_FORM_TITLE'=>'Nieuw Contactpersoon',
'LBL_CONTACT_OPP_FORM_TITLE'=>'Contactpersoon - Kans:',
'LBL_CONTACT'=>'Contactpersoon:',

'LBL_LIST_NAME'=>'Naam',
'LBL_LIST_LAST_NAME'=>'Achter Naam',
'LBL_LIST_CONTACT_NAME'=>'Contactpersoon Naam',
'LBL_LIST_TITLE'=>'Aanhef',
'LBL_LIST_ACCOUNT_NAME'=>'Bedrijf Naam',
'LBL_LIST_EMAIL_ADDRESS'=>'Email',
'LBL_LIST_PHONE'=>'Telefoon',
'LBL_LIST_CONTACT_ROLE'=>'Rol',

'LBL_NAME'=>'Naam:',
'LBL_CONTACT_NAME'=>'Contactpersoon Naam:',
'LBL_CONTACT_INFORMATION'=>'Contactpersoon Informatie',
'LBL_FIRST_NAME'=>'Voor Naam:',
'LBL_OFFICE_PHONE'=>'Telefoon Werk:',
'LBL_ACCOUNT_NAME'=>'Bedrijf Naam:',
'LBL_ANY_PHONE'=>'Alternatieve Telefoon:',
'LBL_PHONE'=>'Telefoon:',
'LBL_LAST_NAME'=>'Achter Naam:',
'LBL_MOBILE_PHONE'=>'Mobiel:',
'LBL_HOME_PHONE'=>'Prive:',
'LBL_LEAD_SOURCE'=>'Bron contactpersoon:',
'LBL_OTHER_PHONE'=>'Andere telefoon:',
'LBL_FAX_PHONE'=>'Fax:',
'LBL_TITLE'=>'Titel:',
'LBL_DEPARTMENT'=>'Afdeling:',
'LBL_BIRTHDATE'=>'Verjaardag:',
'LBL_EMAIL_ADDRESS'=>'Email:',
'LBL_OTHER_EMAIL_ADDRESS'=>'Alternatieve Email:',
'LBL_ANY_EMAIL'=>'Andere Email:',
'LBL_REPORTS_TO'=>'Rapporteert aan:',
'LBL_ASSISTANT'=>'Assistent:',
'LBL_YAHOO_ID'=>'Yahoo! ID:',
'LBL_ASSISTANT_PHONE'=>'Assistent Telefoon:',
'LBL_DO_NOT_CALL'=>'Niet Bellen!:',
'LBL_EMAIL_OPT_OUT'=>'Email Opt Out:',
'LBL_PRIMARY_ADDRESS'=>'Hoofd Adres:',
'LBL_ALTERNATE_ADDRESS'=>'Alternatieve Adres:',
'LBL_ANY_ADDRESS'=>'Ander Adres:',
'LBL_CITY'=>'Plaats:',
'LBL_STATE'=>'Provincie:',
'LBL_POSTAL_CODE'=>'Postcode:',
'LBL_COUNTRY'=>'Land:',
'LBL_DESCRIPTION_INFORMATION'=>'Omschrijving Informatie',
'LBL_ADDRESS_INFORMATION'=>'Adres Informatie',
'LBL_DESCRIPTION'=>'Omschrijving:',
'LBL_CONTACT_ROLE'=>'Rol:',
'LBL_OPP_NAME'=>'Naam van Kans:',

'LNK_NEW_CONTACT'=>'Nieuw Contact',
'LNK_NEW_ACCOUNT'=>'Nieuw Bedrijf',
'LNK_NEW_OPPORTUNITY'=>'Nieuwe Kans',
'LNK_NEW_CASE'=>'Nieuwe Zaak',
'LNK_NEW_NOTE'=>'Nieuwe Notitie',
'LNK_NEW_CALL'=>'Nieuw Telefoon Gesprek',
'LNK_NEW_EMAIL'=>'Nieuwe Email',
'LNK_NEW_MEETING'=>'Nieuwe Afspraak',
'LNK_NEW_TASK'=>'Nieuwe Taak',
'NTC_DELETE_CONFIRMATION'=>'Weet u zeker dat u dit record wilt verwijderen?',
'NTC_REMOVE_CONFIRMATION'=>'Weet u zeker dat u deze contactpersoon wilt verwijderen van deze zaak?',
'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION'=>'Weet u zeker dat u dit record wilt verwijderen?',
'ERR_DELETE_RECORD'=>"Er moet een record nummer worden gespecificeerd om dit contact te verwijderen.",
'NTC_COPY_PRIMARY_ADDRESS'=>'Kopieer Hoofd Adres naar alternatieve adres',
'NTC_COPY_ALTERNATE_ADDRESS'=>'Kopieer Alternatieve Adres naar Hoofd adres',
);

?>