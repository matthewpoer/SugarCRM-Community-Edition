<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Import/language/en_us.lang.php,v 1.2.2.3 2004/09/16 22:47:08 sugarrob Exp $
 * Description:  Defines the English language pack for the Account module.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/


$mod_strings = Array(
'LBL_IMPORT_MODULE_NO_DIRECTORY'=>'De directory ',
'LBL_IMPORT_MODULE_NO_DIRECTORY_END'=>' Bestaat niet of is niet beschrijfbaar',
'LBL_IMPORT_MODULE_ERROR_NO_UPLOAD'=>'De file kan niet worden opgehaald (geimporteerd), probeer het opnieuw',
'LBL_IMPORT_MODULE_ERROR_LARGE_FILE'=>'De file is te groot Max.:',
'LBL_IMPORT_MODULE_ERROR_LARGE_FILE_END'=>'Bytes. Wijzig de string $upload_maxsize in config.php',
'LBL_MODULE_NAME'=>'Importeer',
'LBL_TRY_AGAIN'=>'Probeer opnieuw',
'LBL_ERROR'=>'Foutmelding:',
'ERR_MULTIPLE'=>'Er zijn meerdere kolommen gedefinieerd met dezelfde veldnaam .',
'ERR_MISSING_REQUIRED_FIELDS'=>'Er missen verplichte velden:',
'ERR_SELECT_FULL_NAME'=>'U kunt niet [Volledige Naam] selecteren als [Voor Naam] en [Achter Naam] zijn geselecteerd.',
'ERR_SELECT_FILE'=>'Selecteer de te importeren file.',
'LBL_SELECT_FILE'=>'Selecteer file:',
'LBL_CUSTOM'=>'Eigen Opmaak',
'LBL_DONT_MAP'=>'-- Dit veld niet gebruiken --',
'LBL_STEP_1_TITLE'=>'Stap 1: Selecteer de bron',
'LBL_WHAT_IS'=>'Wat is de bron van de te importeren data?',
'LBL_MICROSOFT_OUTLOOK'=>'Microsoft Outlook',
'LBL_ACT'=>'Act!',
'LBL_SALESFORCE'=>'Salesforce.com',
'LBL_MY_SAVED'=>'Mijn opgeslagen bronnen:',
'LBL_PUBLISH'=>'publiceer',
'LBL_DELETE'=>'verwijder',
'LBL_PUBLISHED_SOURCES'=>'Gepubliseerde Bronnen:',
'LBL_UNPUBLISH'=>'Maak publiceren ongedaan',
'LBL_NEXT'=>'Volgende >',
'LBL_BACK'=>'< Terug',
'LBL_STEP_2_TITLE'=>'Stap 2: Ophalen van de ge-exporteerde file',
'LBL_HAS_HEADER'=>'Heeft kopteks boven de kolommen:',

'LBL_NUM_1'=>'1.',
'LBL_NUM_2'=>'2.',
'LBL_NUM_3'=>'3.',
'LBL_NUM_4'=>'4.',
'LBL_NUM_5'=>'5.',
'LBL_NUM_6'=>'6.',
'LBL_NUM_7'=>'7.',
'LBL_NUM_8'=>'8.',
'LBL_NUM_9'=>'9.',
'LBL_NUM_10'=>'10.',
'LBL_NUM_11'=>'11.',
'LBL_NUM_12'=>'12.',
'LBL_NOW_CHOOSE'=>'Kies nu de file om te importeren:',
'LBL_IMPORT_OUTLOOK_TITLE'=>'Microsoft Outlook 98 en 2000 kunnen data in het <b>Comma Separated Values</b> formaatexporteren. Dit kan gebruikt worden om data in dit systeem te importeren. Om data van vanuit Outlook te exporteren volgt u de volgende stappen:',
'LBL_OUTLOOK_NUM_1'=>'Start <b>Outlook</b>',
'LBL_OUTLOOK_NUM_2'=>'Selecteer het <b>File</b> menu, daarna de <b>Import and Export ...</b> menu optie',
'LBL_OUTLOOK_NUM_3'=>'Kies<b>Export to a file</b> en klik op Next',
'LBL_OUTLOOK_NUM_4'=>'Kies <b>Comma Separated Values (Windows)</b> en klik <b>Next</b>.<br>  Let op: Het kan zijn dat u een melding krijgt om eerst de export component te installeren',
'LBL_OUTLOOK_NUM_5'=>'Selecteer de <b>Contacts</b> folder and klik <b>Next</b>. U kunt verschillende contact folders selecteren. Als uw contacten in meerdere folders zijn opgeslagen',
'LBL_OUTLOOK_NUM_6'=>'Kies een filename en klik op <b>Next</b>',
'LBL_OUTLOOK_NUM_7'=>'Klik <b>Finish</b>',
'LBL_IMPORT_ACT_TITLE'=>'Act! kan data exporteren in het <b>Comma Separated Values</b> formaat. Dit formaat kan gebruikt worden om data in dit systeem te importeren. Om uw datat te exporteren vanuit Act! volgt u de onderstaande stappen:',
'LBL_ACT_NUM_1'=>'Start <b>ACT!</b>',
'LBL_ACT_NUM_2'=>'Selecteer het <b>File</b> menu, daarna de <b>Data Exchange</b> menu optie, dan de <b>Export...</b> menu optie',
'LBL_ACT_NUM_3'=>'Selecteer de het file type <b>Text-Delimited</b>',
'LBL_ACT_NUM_4'=>'Kies een filenaam en locatie om het te exporteren bestand naar op te slaan en klik <b>Next</b>',
'LBL_ACT_NUM_5'=>'Selecteer <b>Contacts records only</b>',
'LBL_ACT_NUM_6'=>'Klik de <b>Options...</b> knop',
'LBL_ACT_NUM_7'=>'Selecteer <b>Comma</b> als het veld scheidings karakter',
'LBL_ACT_NUM_8'=>'Vink het <b>Yes, export field names</b> keuzehokje aan en klik op <b>OK</b>',
'LBL_ACT_NUM_9'=>'Klik <b>Next</b>',
'LBL_ACT_NUM_10'=>'Selecteer <b>All Records</b> en klik vervolgens op <b>Finish</b>',

'LBL_IMPORT_SF_TITLE'=>'Salesforce.com kan data exporteren in het <b>Comma Separated Values</b> formaat. Dit kan gebruikt worden om de data te importeren in dit systeem. Om uw data op de juiste manier te exporteren vanuit Salesforce.com volgt u de volgende stappen:',
'LBL_SF_NUM_1'=>'Open uw webbrowser en ga naar http://www.salesforce.com, log in met uw accountgegevens (email adres en paswoord)',
'LBL_SF_NUM_2'=>'Klik op het tabblad <b>Reports</b> aan de bovenzijde in het menu',
'LBL_SF_NUM_3'=>'Om accounts te exporteren:</b> Klik op de <b>Active Accounts</b> link<br><b>Om contact personene te exporteren:</b> Klik op de <b>Mailing List</b> link',
'LBL_SF_NUM_4'=>'In <b>Stap 1: Select your report type</b>, selecteer <b>Tabular Report</b>Klik <b>Next</b>',
'LBL_SF_NUM_5'=>'In <b>Stap 2: Select the report columns</b>, Kies de kolommen die u wilt exporteren en klik <b>Next</b>',
'LBL_SF_NUM_6'=>'In <b>Step 3: Select the information to summarize</b>, gewoon op <b>Next</b> klikken.',
'LBL_SF_NUM_7'=>'In <b>Step 4: Order the report columns</b>, Gewoon op <b>Next</b> klikken',
'LBL_SF_NUM_8'=>'In <b>Step 5: Select your report criteria</b>, onder <b>Start Date</b>, kies een datum ver genoeg in de tijd terug om al uw berijven/contacten te selecteren. U kunt ook een sub selectie creeeren door gebruik te maken van de geavanceerde criteria. Wanneer u klaar bent klik op <b>Run Report</b>',
'LBL_SF_NUM_9'=>'Er wordt een rapport gegenereerd, en de pagina wordt weergegeven <b>Report Generation Status: Complete.</b> Klik nu op <b>Export to Excel</b>',
'LBL_SF_NUM_10'=>'In <b>Export Report:</b>, voor <b>Export File Format:</b>, kies <b>Comma Delimited .csv</b>. Klik <b>Export</b>.',
'LBL_SF_NUM_11'=>'Een dialoog venster verschijnt waarin u de locatie kunt opgeven waarnaar u het bestand wilt opslaan.',
'LBL_IMPORT_CUSTOM_TITLE'=>'Veel software applicaties bieden de mogelijkheid om data te exporteren naar <b>Comma Delimited text file (.csv)</b>. Over het algemeen moeten de volgende stappen worden gevolgd:',
'LBL_CUSTOM_NUM_1'=>'Start de applicatie en open de te exporteren file',
'LBL_CUSTOM_NUM_2'=>'Selecteer de <b>Save As...</b> of <b>Export...</b> menu optie',
'LBL_CUSTOM_NUM_3'=>'Sla de file op in een <b>CSV</b> of <b>Comma Separated Values</b> formaat',

'LBL_STEP_3_TITLE'=>'Stap 3: Bevestig de velden en Import',

'LBL_SELECT_FIELDS_TO_MAP'=>'Selecteer in de lijst hieronder de juiste velden uit uw te importeren databestand die moeten worden opgeslagen onder het betreffene veld van dit systeem. Als u klaar bent klikt u op <b>Nu Importeren</b>:',

'LBL_DATABASE_FIELD'=>'Database Veld',
'LBL_HEADER_ROW'=>'Kop tekst',
'LBL_ROW'=>'Rij',
'LBL_SAVE_AS_CUSTOM'=>'Sla deze indeling op als een eigen opmaak:',
'LBL_CONTACTS_NOTE_1'=>'Ofwel [Achter Naam] of [Volledige Naam] moeten zijn toegewezen.',
'LBL_CONTACTS_NOTE_2'=>'Als de [Volledig Naam] is toegewezen, dan worden [Voor Naam] en [Achter Naam] genegeerd.',
'LBL_CONTACTS_NOTE_3'=>'Als de [volledig naam] is toegewezen, dan wordt de data in Volledige Naam opgesplitst naar [Voor Naam] en [Achter Naam].',
'LBL_CONTACTS_NOTE_4'=>'Velden in [Adres Straat 2] en [Adres Straat 3] worden samengevoegd met het veld [Adres Straat].',
'LBL_ACCOUNTS_NOTE_1'=>'Bedrijf Naam moet zijn toegewezen.',
'LBL_ACCOUNTS_NOTE_2'=>'Velden in [Adres Straat 2] en [Adres Straat 3] worden samengevoegd met het veld [Adres Straat].',
'LBL_OPPORTUNITIES_NOTE_1'=>'Kansen Naam, Bedrijf Naam, Datum Gesloten, en Verkoop Stadium zijn verplichte velden.',
'LBL_IMPORT_NOW'=>'Nu Importeren',
'LBL_'=>'',
'LBL_'=>'',
'LBL_CANNOT_OPEN'=>'Kan het geimporteerde bestand niet lezen.',
'LBL_NOT_SAME_NUMBER'=>'Er zijn niet hetzelfde aantal velden per regel in het bestand.',
'LBL_NO_LINES'=>'Er zijn geen bestands regels in het te importeren bestan ( bestand is leeg)',
'LBL_FILE_ALREADY_BEEN_OR'=>'Het import bestand is al verwerkt of bestaat niet',
'LBL_SUCCESS'=>'Succes:',
'LBL_SUCCESSFULLY'=>'Succesvol Geimporteerd',
'LBL_LAST_IMPORT_UNDONE'=>'Uw laatste Import bewerking is ongedaan gemaakt',
'LBL_NO_IMPORT_TO_UNDO'=>'Er bestaat geen import bewerking die ongedaan kan worden gemaakt.',
'LBL_FAIL'=>'Mislukt:',
'LBL_RECORDS_SKIPPED'=>'Er is een aantal records overgeslagen omdat er een of meer verplichte velden missen',
'LBL_IDS_EXISTED_OR_LONGER'=>'Er is een aantal records overgeslagen omdat de id\'s als bestaan of omdat deze langer zijn dan 36 karakters',
'LBL_RESULTS'=>'Resultaten',
'LBL_IMPORT_MORE'=>'Meer Importeren',
'LBL_FINISHED'=>'Beeindigen',
'LBL_UNDO_LAST_IMPORT'=>'Maak de laatste import bewerking ongedaan',



);

$mod_list_strings = Array(
'contacts_import_fields' => Array(
	"id"=>"Contactpersoon ID"
	,"first_name"=>"Voor Naam"
	,"last_name"=>"Achter Naam"
	,"salutation"=>"Aanhef"
	,"lead_source"=>"Bron Contactpersoon"
	,"birthdate"=>"Verjaardag"
	,"do_not_call"=>"Niet Bellen"
	,"email_opt_out"=>"Email Opt Out"
	,"primary_address_street_2"=>"Hoofd Adres Straat 2"
	,"primary_address_street_3"=>"Hoofd Adres Straat 3"
	,"alt_address_street_2"=>"Alternatieve Adres Straat 2"
	,"alt_address_street_3"=>"Alternatieve Adres Straat 3"
	,"full_name"=>"Volledige Naam"
	,"account_name"=>"Bedrijf Naam"
	,"account_id"=>"Bedrijf ID"
	,"title"=>"Titel"
	,"department"=>"Afdeling"
	,"birthdate"=>"Verjaardag"
	,"do_not_call"=>"Niet Bellen"
	,"phone_home"=>"Telefoon (Thuis)"
	,"phone_mobile"=>"Telefoon (Mobiel)"
	,"phone_work"=>"Telefoon (Werk)"
	,"phone_other"=>"Telefoon (Anders)"
	,"phone_fax"=>"Fax"
	,"email1"=>"Email"
	,"email2"=>"Email (Alternatieve)"
	,"yahoo_id"=>"Yahoo! ID"
	,"assistant"=>"Assistent"
	,"assistant_phone"=>"Assistent Telefoon"
	,"primary_address_street"=>"Hoofd Adres Straat"
	,"primary_address_city"=>"Hoofd Adres Plaats"
	,"primary_address_state"=>"Hoofd Adres Provincie"
	,"primary_address_postalcode"=>"Hoofd Adres Postcode"
	,"primary_address_country"=>"Hoofd Adres Land"
	,"alt_address_street"=>"Alternatieve adres Straat"
	,"alt_address_city"=>"Alternatieve Adres Plaats"
	,"alt_address_state"=>"Alternatieve Adres Provincie"
	,"alt_address_postalcode"=>"Alternatieve Adres Postcode"
	,"alt_address_country"=>"Alternatieve Adres Land"
	,"description"=>"Omschrijving"

	),

'accounts_import_fields' => Array(
	"id"=>"Bedrijf ID",
	"name"=>"Bedrijf Naam",
	"website"=>"Website",
	"industry"=>"Industrie",
	"type"=>"Type",
	"ticker_symbol"=>"Beurs Symbool",
	"parent_name"=>"Lid van",
	"employees"=>"Werknemers",
	"ownership"=>"Eigenaar",
	"phone_office"=>"Telefoon",
	"phone_fax"=>"Fax",
	"phone_alternate"=>"Alternatieve Telefoon",
	"email1"=>"Email",
	"email2"=>"Alternatieve Email",
	"rating"=>"Beoordeling",
	"sic_code"=>"SIC Code",
	"annual_revenue"=>"Jaarlijks resultaat",
	"billing_address_street"=>"Factuur Adres Straat",
	"billing_address_street_2"=>"Factuur Adres Straat 2",
	"billing_address_street_3"=>"Factuur Adres Straat 3",
	"billing_address_street_4"=>"Factuur Adres Straat 4",
	"billing_address_city"=>"Factuur Adres Plaats",
	"billing_address_state"=>"Factuur Adres Provincie",
	"billing_address_postalcode"=>"Factuur Adres Postcode",
	"billing_address_country"=>"Factuur Adres Land",
	"shipping_address_street"=>"Aflever Adres Straat",
	"shipping_address_street_2"=>"Aflever Adres Straat 2",
	"shipping_address_street_3"=>"Aflever Adres Straat 3",
	"shipping_address_street_4"=>"Aflever Adres Straat 4",
	"shipping_address_city"=>"Aflever Adres Plaats",
	"shipping_address_state"=>"Aflever Adres Provincie",
	"shipping_address_postalcode"=>"Aflever Adres Postcode",
	"shipping_address_country"=>"Aflever Adres Land",
	"description"=>"Omschrijving"
	),

'opportunities_import_fields' => Array(
		"id"=>"Bedrijf ID"
                , "name"=>"Kans Naam"
                , "account_name"=>"Bedrijf Naam"
                , "opportunity_type"=>"Kans Type"
                , "lead_source"=>"Bron van deze Kans"
                , "amount"=>"Bedrag"
                , "date_closed"=>"Datum Gesloten"
                , "next_step"=>"Volgende Stap"
                , "sales_stage"=>"Verkoop Stadium"
                , "probability"=>"Waarschijnlijkheid"
                , "description"=>"Omschrijving"
                )

);

?>
