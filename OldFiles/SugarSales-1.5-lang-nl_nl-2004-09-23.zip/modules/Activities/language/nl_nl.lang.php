<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Activities/language/en_us.lang.php,v 1.11 2004/09/04 20:36:16 sugarclint Exp $
 * Description:  Defines the English language pack for the Account module.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_OPEN_ACTIVITIES'=>'Openstaande Aktiviteiten',
'LBL_HISTORY'=>'Historie',
'LBL_UPCOMING'=>"Mijn Opkomende Aktiviteiten",
'LBL_TODAY'=>'tot ',

'LBL_NEW_TASK_BUTTON_TITLE'=>'Nieuw Taak [Alt+N]',
'LBL_NEW_TASK_BUTTON_KEY'=>'N',
'LBL_NEW_TASK_BUTTON_LABEL'=>'Nieuwe Taak',
'LBL_SCHEDULE_MEETING_BUTTON_TITLE'=>'Agendeer een Afspraak [Alt+M]',
'LBL_SCHEDULE_MEETING_BUTTON_KEY'=>'M',
'LBL_SCHEDULE_MEETING_BUTTON_LABEL'=>'Agendeer een Afspraak',
'LBL_SCHEDULE_CALL_BUTTON_TITLE'=>'Inplannen Telefoon Gesprek [Alt+C]',
'LBL_SCHEDULE_CALL_BUTTON_KEY'=>'C',
'LBL_SCHEDULE_CALL_BUTTON_LABEL'=>'Inplannen Telefoon Gesprek',
'LBL_NEW_NOTE_BUTTON_TITLE'=>'Nieuwe Notitie [Alt+T]',
'LBL_NEW_NOTE_BUTTON_KEY'=>'T',
'LBL_NEW_NOTE_BUTTON_LABEL'=>'Nieuwe Notitie',
'LBL_TRACK_EMAIL_BUTTON_TITLE'=>'Volgen Email [Alt+K]',
'LBL_TRACK_EMAIL_BUTTON_KEY'=>'K',
'LBL_TRACK_EMAIL_BUTTON_LABEL'=>'Volgen Email',

'LBL_LIST_CLOSE'=>'Sluiten',
'LBL_LIST_STATUS'=>'Status',
'LBL_LIST_CONTACT'=>'Contactpersoon',
'LBL_LIST_RELATED_TO'=>'Gerelateerd aan',
'LBL_LIST_DUE_DATE'=>'Verval Datum',
'LBL_LIST_DATE'=>'Datum',
'LBL_LIST_SUBJECT'=>'Onderwerp',
'LBL_LIST_LAST_MODIFIED'=>'Laatst Gewijzigd',

'LNK_NEW_CONTACT'=>'Nieuw Contact',
'LNK_NEW_ACCOUNT'=>'Nieuw Bedrijf',
'LNK_NEW_OPPORTUNITY'=>'Nieuwe Kans',
'LNK_NEW_CASE'=>'Nieuwe Zaak',
'LNK_NEW_NOTE'=>'Nieuwe Notitie',
'LNK_NEW_CALL'=>'Nieuw Telefoon Gesprek',
'LNK_NEW_EMAIL'=>'Nieuwe Email',
'LNK_NEW_MEETING'=>'Nieuwe Afspraak',
'LNK_NEW_TASK'=>'Nieuwe Taak',
'ERR_DELETE_RECORD'=>"Er moet een record nummer zijn gespecificeerd om het bedrijf te verwijderen.",
'NTC_NONE_SCHEDULED'=>'Er staan geen activiteiten te wachten.',
);


?>