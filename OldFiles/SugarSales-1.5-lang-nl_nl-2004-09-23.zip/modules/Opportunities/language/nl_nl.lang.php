<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Opportunities/language/en_us.lang.php,v 1.19 2004/09/09 06:26:14 jostrow Exp $
 * Description:  Defines the English language pack for the Account module.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = Array(
'LBL_MODULE_NAME'=>'Kansen',
'LBL_MODULE_TITLE'=>'Kansen: Home',
'LBL_SEARCH_FORM_TITLE'=>'Kansen Zoeken',
'LBL_LIST_FORM_TITLE'=>'Kansen Lijst',
'LBL_OPPORTUNITY_NAME'=>'Kans Naam:',
'LBL_OPPORTUNITY'=>'Kans:',
'LBL_NAME'=>'Opportunity Naam',
'LBL_INVITEE'=>'Contactpersonen',
'LBL_LIST_OPPORTUNITY_NAME'=>'Kansen',
'LBL_LIST_ACCOUNT_NAME'=>'Bedrijf Naam',
'LBL_LIST_AMOUNT'=>'Bedrag',
'LBL_LIST_DATE_CLOSED'=>'Verwachte Afsluiting',
'LBL_LIST_SALES_STAGE'=>'Verkoop Stadium',

'LBL_OPPORTUNITY_NAME'=>'Kans Naam:',
'LBL_ACCOUNT_NAME'=>'Bedrijf Naam:',
'LBL_AMOUNT'=>'Bedrag:',
'LBL_DATE_CLOSED'=>'Verwachte Afsluiting:',
'LBL_TYPE'=>'Type:',
'LBL_NEXT_STEP'=>'Volgende Stap:',
'LBL_LEAD_SOURCE'=>'Bron van deze Kans:',
'LBL_SALES_STAGE'=>'Verkoop Stadium:',
'LBL_PROBABILITY'=>'Waarschijnlijkheid (%):',
'LBL_DESCRIPTION'=>'Omschrijving:',

'LNK_NEW_CONTACT'=>'Nieuw Contact',
'LNK_NEW_ACCOUNT'=>'Nieuw Bedrijf',
'LNK_NEW_OPPORTUNITY'=>'Nieuwe Kans',
'LNK_NEW_CASE'=>'Nieuwe Zaak',
'LNK_NEW_NOTE'=>'Nieuwe Notitie',
'LNK_NEW_CALL'=>'Nieuw Telefoon Gesprek',
'LNK_NEW_EMAIL'=>'Nieuwe Email',
'LNK_NEW_MEETING'=>'Nieuwe Afspraak',
'LNK_NEW_TASK'=>'Nieuwe Taak',

'ERR_DELETE_RECORD'=>"Er moet een record nummer zijn gespecificeerd om deze Kans te verwijderen.",
'LBL_TOP_OPPORTUNITIES'=>"Mijn Top Openstaande Kansen",

'NTC_REMOVE_OPP_CONFIRMATION'=>'Weet u zeker datu deze contactpersoon van deze Kans wilt verwijderen?',
);

?>