<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Calls/language/en_us.lang.php,v 1.17 2004/09/04 20:36:18 sugarclint Exp $
 * Description:  Defines the English language pack for the Account module.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_MODULE_NAME'=>'Telefoon Gesprekken',
'LBL_MODULE_TITLE'=>'Telefoon Gesprekken: Home',
'LBL_SEARCH_FORM_TITLE'=>'Telefoon Gesprek Zoeken',
'LBL_LIST_FORM_TITLE'=>'Liist met Telefoon Gesprekken',
'LBL_NEW_FORM_TITLE'=>'Inplannen Telefoongesprek',

'LBL_LIST_CLOSE'=>'Sluiten',
'LBL_LIST_SUBJECT'=>'Onderwerp',
'LBL_LIST_CONTACT'=>'Contactpersoon',
'LBL_LIST_RELATED_TO'=>'Gerelateerd aan',
'LBL_LIST_DATE'=>'Start Datum',
'LBL_LIST_TIME'=>'Start Tijd',
'LBL_LIST_DURATION'=>'Gespreksduur',

'LBL_SUBJECT'=>'Onderwerp:',
'LBL_CONTACT_NAME'=>'Contactpersoon:',
'LBL_DESCRIPTION_INFORMATION'=>'Beschrijving Informatie',
'LBL_DESCRIPTION'=>'Beschrijving:',
'LBL_STATUS'=>'Status:',
'LBL_DATE'=>'Datum:',
'LBL_DURATION'=>'Gespreksduur:',
'LBL_HOURS_MINUTES'=>'(uren/minuten)',
'LBL_CALL'=>'Telefoongesprek:',  
'LBL_DATE_TIME'=>"Start Datum & Tijd:",
'LBL_DATE'=>"Start Datum",
'LBL_TIME'=>"Start Tijd:",
'LBL_HOURS_ABBREV'=>'uur',  
'LBL_MINSS_ABBREV'=>'min',  
'LBL_COLON'=>':',
'LBL_DEFAULT_STATUS'=>'Genoteerd',

'LNK_NEW_CONTACT'=>'Nieuw Contact',
'LNK_NEW_ACCOUNT'=>'Nieuw Bedrijf',
'LNK_NEW_OPPORTUNITY'=>'Nieuwe Kans',
'LNK_NEW_CASE'=>'Nieuwe Zaak',
'LNK_NEW_NOTE'=>'Nieuwe Notitie',
'LNK_NEW_CALL'=>'Nieuw Telefoon Gesprek',
'LNK_NEW_EMAIL'=>'Nieuwe Email',
'LNK_NEW_MEETING'=>'Nieuwe Afspraak',
'LNK_NEW_TASK'=>'Nieuwe Taak',
'ERR_DELETE_RECORD'=>" er moet een record nummer zijn gespecificeerd om dit berijf te verwijderen",
'NTC_REMOVE_INVITEE'=>'Weet u zeker dat u deze uitgenodigde persoon wilt verwijderen voor dit telefoon gesprek?',
'LBL_INVITEE'=>'Uitgenodigde',
);

?>