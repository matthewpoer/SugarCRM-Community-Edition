-- MSSql upgrade script for Sugar 5.1.0 to 5.5.0















 ALTER TABLE users ADD system_generated_password bit  DEFAULT '0' NOT NULL ,
                       pwd_last_changed datetime  NULL ,



                       external_auth_only bit  DEFAULT '0' NULL;
                       



                       
















































































CREATE TABLE sugarfeed (
				id varchar(36)  NOT NULL ,
				name varchar(255)  NULL ,
				date_entered datetime  NULL ,
				date_modified datetime  NULL ,
				modified_user_id varchar(36)  NULL ,
				created_by varchar(36)  NULL ,
				description varchar(255)  NULL ,
				deleted bit  DEFAULT '0' NULL ,




				assigned_user_id varchar(36)  NULL ,
				related_module varchar(100)  NULL ,
				related_id varchar(36)  NULL ,
				link_url varchar(255)  NULL ,
				link_type varchar(30)  NULL  ) 
ALTER TABLE sugarfeed 
            ADD CONSTRAINT pk_sugarfeed PRIMARY KEY (id) 
            create index sgrfeed_date on sugarfeed ( date_entered, deleted );














CREATE TABLE users_password_link (
                id varchar(36)  NOT NULL ,
                username varchar(36)  NULL ,
                date_generated datetime  NULL ,
                deleted bit  DEFAULT 0  NOT NULL  ) 
ALTER TABLE users_password_link 
    ADD CONSTRAINT pk_users_password_link PRIMARY KEY (id) 
    create index idx_username on users_password_link ( username );
alter table email_cache alter column senddate datetime null;








































