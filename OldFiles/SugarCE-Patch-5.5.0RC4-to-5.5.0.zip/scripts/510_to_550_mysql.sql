-- MySQL upgrade script for Sugar 5.1.0 to 5.5.0


ALTER TABLE upgrade_history modify column manifest longtext NULL;





































ALTER TABLE users   add column system_generated_password bool  DEFAULT '0' NOT NULL ,  
                    add column pwd_last_changed datetime  NULL ,




                    add column external_auth_only bool  DEFAULT '0' NULL; 

ALTER TABLE outbound_email modify mail_smtpssl int(1) DEFAULT 0 NULL; 













































































































CREATE TABLE sugarfeed (
				id char(36)  NOT NULL ,
				name varchar(255)  NULL ,
				date_entered datetime  NULL ,
				date_modified datetime  NULL ,
				modified_user_id char(36)  NULL ,
				created_by char(36)  NULL ,
				description varchar(255)  NULL ,
				deleted bool  DEFAULT '0' NULL ,




				assigned_user_id char(36)  NULL ,
				related_module varchar(100)  NULL ,
				related_id char(36)  NULL ,
				link_url varchar(255)  NULL ,
				link_type varchar(30)  NULL  , 
				PRIMARY KEY (id),   



                KEY sgrfeed_date (date_entered, deleted))
			CHARACTER SET utf8 COLLATE utf8_general_ci;














CREATE TABLE users_password_link (
                id char(36)  NOT NULL ,
                username varchar(36)  NULL ,
                date_generated datetime  NULL ,
                deleted bool  DEFAULT 0  NOT NULL  , 
                PRIMARY KEY (id),   
                KEY idx_username (username)) 
            CHARACTER SET utf8 COLLATE utf8_general_ci;
ALTER TABLE email_cache   modify column senddate datetime  NULL ;
ALTER TABLE import_maps   modify column content text  NULL ,  modify column default_values text  NULL ;