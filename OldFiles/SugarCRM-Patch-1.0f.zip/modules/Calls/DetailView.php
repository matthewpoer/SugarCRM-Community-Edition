<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1
 * ("License"); You may not use this file except in compliance with the 
 * License. You may obtain a copy of the License at http://www.mozilla.org/MPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/sugarcrm/sugarcrm/modules/Calls/DetailView.php,v 1.6 2004/07/11 20:08:51 sugarjacob Exp $
 * Description:  TODO: To be written.
 ********************************************************************************/

require_once('XTemplate/xtpl.php');
require_once('data/Tracker.php');
require_once('modules/Calls/Call.php');
require_once('modules/Calls/Forms.php');

$focus = new Call();

if(isset($_REQUEST['record'])) {
    $focus->retrieve($_REQUEST['record']);
}
if(isset($_REQUEST['isDuplicate']) && $_REQUEST['isDuplicate'] == 'true') {
	$focus->id = "";
} 

//needed when creating a new call with default values passed in 
if (isset($_REQUEST['contact_name']) && is_null($focus->contact_name)) {
	$focus->contact_name = $_REQUEST['contact_name'];
}
if (isset($_REQUEST['contact_id']) && is_null($focus->contact_id)) {
	$focus->contact_id = $_REQUEST['contact_id'];
}
if (isset($_REQUEST['opportunity_name']) && is_null($focus->parent_name)) {
	$focus->parent_name = $_REQUEST['opportunity_name'];
}
if (isset($_REQUEST['opportunity_id']) && is_null($focus->parent_id)) {
	$focus->parent_id = $_REQUEST['opportunity_id'];
}
if (isset($_REQUEST['account_name']) && is_null($focus->parent_name)) {
	$focus->parent_name = $_REQUEST['account_name'];
}
if (isset($_REQUEST['account_id']) && is_null($focus->parent_id)) {
	$focus->parent_id = $_REQUEST['account_id'];
}

global $theme;
$theme_path="themes/".$theme."/";
$image_path=$theme_path."images/";
require_once($theme_path.'layout_utils.php');

$log->info("Call detail view");

$xtpl=new XTemplate ('modules/Calls/DetailView.html');

if (isset($_REQUEST['return_module'])) $xtpl->assign("RETURN_MODULE", $_REQUEST['return_module']);
if (isset($_REQUEST['return_action'])) $xtpl->assign("RETURN_ACTION", $_REQUEST['return_action']);
if (isset($_REQUEST['return_id'])) $xtpl->assign("RETURN_ID", $_REQUEST['return_id']);
$xtpl->assign("THEME", $theme);
$xtpl->assign("IMAGE_PATH", $image_path);$xtpl->assign("PRINT_URL", "phprint.php?jt=".session_id());
$xtpl->assign("ID", $focus->id);
$xtpl->assign("PARENT_NAME", $focus->parent_name);	
if (isset($focus->parent_type)) $xtpl->assign("PARENT_MODULE", $focus->record_type_dom[$focus->parent_type]);
$xtpl->assign("PARENT_TYPE", $focus->parent_type);	
$xtpl->assign("PARENT_ID", $focus->parent_id);	
$xtpl->assign("NAME", $focus->name);

$xtpl->assign("DATE_START", $focus->date_start);
$xtpl->assign("TIME_START", substr($focus->time_start, 0, 5));
$xtpl->assign("STATUS", $focus->status);
$xtpl->assign("DESCRIPTION", $focus->description);

$xtpl->assign("DURATION_HOURS", $focus->duration_hours);
$xtpl->assign("DURATION_MINUTES", $focus->duration_minutes);

$xtpl->parse("main");

$xtpl->out("main");

echo "<BR>\n";

// Now get the list of invitees that match this one.
$focus_users_list = & $focus->get_users();
$focus_contacts_list = & $focus->get_contacts();

include('modules/Calls/SubPanelViewInvitees.php');

echo "</td></tr>\n";

?>