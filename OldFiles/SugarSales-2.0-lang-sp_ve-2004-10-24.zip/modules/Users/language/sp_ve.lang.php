<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.3
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /home/httpd/vhosts/sugarcrm.com/master//sugarcrm/include/language/en_us.lang.php,v 1.89 2004/10/25 02:32:20 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Usuarios',
  'LBL_MODULE_TITLE' => 'Usuarios: Inicio',
  'LBL_SEARCH_FORM_TITLE' => 'Usuario Search',
  'LBL_LIST_FORM_TITLE' => 'Usuario Lista',
  'LBL_NEW_FORM_TITLE' => 'New Usuario',
  'LBL_USER' => 'Usuarios:',
  'LBL_LOGIN' => 'Login',
  'LBL_RESET_PREFERENCES' => '*Reset To Default Preferences',
  'LBL_TIME_FORMAT' => 'Time Format:',
  'LBL_CURRENCY' => 'Currency:',
  'LBL_LIST_NAME' => 'Nombre',
  'LBL_LIST_LAST_NAME' => 'Apellido',
  'LBL_LIST_USER_NAME' => 'Nombre Usuario',
  'LBL_LIST_DEPARTMENT' => 'Departmento',
  'LBL_LIST_EMAIL' => 'Email',
  'LBL_LIST_PRIMARY_PHONE' => 'Tel�fono Primario',
  'LBL_LIST_ADMIN' => 'Administrador',
  'LBL_NEW_USER_BUTTON_TITLE' => 'Nuevo Usuario [Alt+N]',
  'LBL_NEW_USER_BUTTON_LABEL' => 'Nuevo Usuario',
  'LBL_NEW_USER_BUTTON_KEY' => 'N',
  'LBL_ERROR' => 'Error:',
  'LBL_PASSWORD' => 'Contrase�a:',
  'LBL_USER_NAME' => 'Nombre Usuario:',
  'LBL_FIRST_NAME' => 'Nombre:',
  'LBL_LAST_NAME' => 'Apellido:',
  'LBL_USER_SETTINGS' => 'configuraci�n Usuario',
  'LBL_THEME' => 'Tema:',
  'LBL_LANGUAGE' => 'Lenguaje:',
  'LBL_ADMIN' => 'Administrador:',
  'LBL_USER_INFORMATION' => 'Informaci�n Usuario',
  'LBL_OFFICE_PHONE' => 'Tel�fono Oficina:',
  'LBL_REPORTS_TO' => 'Reporta A:',
  'LBL_OTHER_PHONE' => 'Otro:',
  'LBL_OTHER_EMAIL' => 'Otro Email:',
  'LBL_NOTES' => 'Notas:',
  'LBL_DEPARTMENT' => 'Departmento:',
  'LBL_STATUS' => 'Estado:',
  'LBL_TITLE' => 'T�tulo:',
  'LBL_ANY_PHONE' => 'Cualquier Phone:',
  'LBL_ANY_EMAIL' => 'Cualquier Email:',
  'LBL_ADDRESS' => 'Direcci�n:',
  'LBL_CITY' => 'Ciudad:',
  'LBL_STATE' => 'Estado:',
  'LBL_POSTAL_CODE' => 'C�digo Postal:',
  'LBL_COUNTRY' => 'Pa�s:',
  'LBL_NAME' => 'Nombre:',
  'LBL_MOBILE_PHONE' => 'Celular:',
  'LBL_OTHER' => 'Otro:',
  'LBL_FAX' => 'Fax:',
  'LBL_EMAIL' => 'Email:',
  'LBL_HOME_PHONE' => 'Tel�fono Casa:',
  'LBL_ADDRESS_INFORMATION' => 'Infomraci�n Direcci�n',
  'LBL_PRIMARY_ADDRESS' => 'Direcci�n Principal:',
  'LBL_CHANGE_PASSWORD_BUTTON_TITLE' => 'Cambiar Contrase�a [Alt+P]',
  'LBL_CHANGE_PASSWORD_BUTTON_KEY' => 'P',
  'LBL_CHANGE_PASSWORD_BUTTON_LABEL' => 'Cambiar Contrase�a',
  'LBL_LOGIN_BUTTON_TITLE' => 'Login [Alt+L]',
  'LBL_LOGIN_BUTTON_KEY' => 'L',
  'LBL_LOGIN_BUTTON_LABEL' => 'Login',
  'LBL_CHANGE_PASSWORD' => 'Cambiar Contrase�a',
  'LBL_OLD_PASSWORD' => 'Contrase�a Antigua:',
  'LBL_NEW_PASSWORD' => 'Nueva Contrase�a:',
  'LBL_CONFIRM_PASSWORD' => 'Confirmar Contrase�a:',
  'ERR_ENTER_OLD_PASSWORD' => 'Por favor introduzca su antigua contrase�a.',
  'ERR_ENTER_NEW_PASSWORD' => 'PPor favor introduzca su nueva contrase�a.',
  'ERR_ENTER_CONFIRMATION_PASSWORD' => 'Por favor introduzca su confirmaci�n de contrase�a.',
  'ERR_REENTER_PASSWORDS' => 'Por favor re-introduzca contrase�as.  La \\"nueva contrase�a\\" y \\"confirme contrase�a\\" no coinciden.',
  'ERR_INVALID_PASSWORD' => 'Debe indicar un usuario y contrase�a v�lidos.',
  'ERR_PASSWORD_CHANGE_FAILED_1' => 'Cambio de contrase�a change fallido por ',
  'ERR_PASSWORD_CHANGE_FAILED_2' => ' fallido.  La nueva contrase�a debe ser establecida.',
  'ERR_PASSWORD_INCORRECT_OLD' => 'Antigua contrase�a incorrecta para el usuario $this->user_name. Re-introduzca la contrase�a.',
  'ERR_USER_NAME_EXISTS_1' => 'El nombre de usuario ',
  'ERR_USER_NAME_EXISTS_2' => ' ya existe.  Nombres de usuarios duplicados no son permitidos.<br>Cambien el nombre de usuario a uno �nico.',
  'ERR_LAST_ADMIN_1' => 'el nombre de usuario ',
  'ERR_LAST_ADMIN_2' => ' es el �ltimo usuario Administrador.  Al menos un usuario debe ser Administrador.<br>Revise la configuraci�n del usuario Administrador.',
  'LNK_NEW_USER' => 'New User',
  'LNK_USER_LIST' => 'Users',
  'ERR_DELETE_RECORD' => 'Un n�mero de registro debe ser especificado para borrar la cuenta.',
  'LBL_RECEIVE_NOTIFICATIONS' => 'Assignment Notification:',
  'LBL_RECEIVE_NOTIFICATIONS_TEXT' => 'Receive an e-mail notification when a record is assigned to you.',
  'LBL_ADMIN_TEXT' => 'Grants administrator privileges to this user',
  'LBL_TIME_FORMAT_TEXT' => 'Set the display format for time stamps',
  'LBL_GRIDLINE' => 'Show Gridlines:',
  'LBL_GRIDLINE_TEXT' => 'Controls gridlines on detail views',
  'LBL_CURRENCY_TEXT' => 'Select the default currency',
  'LBL_YAHOO_ID' => 'Yahoo ID:',
  'LNK_NEW_CONTACT' => 'Nuevo Contacto',
  'LNK_NEW_ACCOUNT' => 'Nueva Cuenta',
  'LNK_NEW_OPPORTUNITY' => 'Nueva Oportunidad',
  'LNK_NEW_CASE' => 'Nuevo Caso',
  'LNK_NEW_NOTE' => 'Nueva Nota',
  'LNK_NEW_CALL' => 'Nueva Llamada',
  'LNK_NEW_EMAIL' => 'Nuevo Email',
  'LNK_NEW_MEETING' => 'Nueva Reuni�n',
  'LNK_NEW_TASK' => 'Nueva Tarea',
);


?>