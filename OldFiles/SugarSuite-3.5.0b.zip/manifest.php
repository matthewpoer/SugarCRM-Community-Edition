<?php
// created: 2005-08-26 18:15:04
$manifest = array (
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '3\\.0\\.1.*',
    ),
  ),
  'acceptable_sugar_flavors' => 
  array (
    0 => 'OS',
  ),
  'name' => 'SugarSuite',
  'description' => '',
  'author' => 'SugarCRM, Inc.',
  'published_date' => '2005-08-26 18:15:04',
  'version' => '3.5.0b',
  'type' => 'full',
  'icon' => '',
  'copy_files' => 
  array (
    'from_dir' => 'SugarSuite-Full-3.5.0b',
    'to_dir' => '',
    'force_copy' => 
    array (
    ),
  ),
);
?>
