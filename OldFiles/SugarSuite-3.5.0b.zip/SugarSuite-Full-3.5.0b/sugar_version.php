<?php
    // $Id: sugar_version.php,v 1.41 2005/08/24 19:47:26 bob Exp $
    $sugar_version      = '3.5.0b';
    $sugar_db_version   = '3.5.0';
    $sugar_flavor       = 'OS';
?>
