<?php
//utility functions for use with the expression object



function translate_operator($operator, $type="php"){
	$php_operator_array = array(
		"More Than" => ">",
		"Less Than" => "<",
		"Equals" => "=",
		"Does not Equal" => "!=",	
	);
	
	$sql_operator_array = array(
	"More Than" => ">",
	"Less Than" => "<",
	"Equals" => "=",
	"Does not Equal" => "!=",
	);
	
	//two types.  PHP and SQL
	
	if($type=="php"){
		return $php_operator_array[$operator];
	}
	if($type=="sql"){

		return $sql_operator_array[$operator];
	}		
	

	
//end function translate_operator
}	

function setup_filter_records($target_list, $target_exp_array, $type="php"){
	
	$optional_where['lhs_field'] = $target_exp_array['lhs_field'];
	$optional_where['operator'] = translate_operator($target_exp_array['operator'], $type);
	$optional_where['rhs_value'] = $target_exp_array['rhs_value'];

	//remove the unnecessary rel_list items
	return filter_out_linked_records($target_list, $optional_where['lhs_field'], $optional_where['operator'], $optional_where['rhs_value']);

//end function setup_filter_records
}	


function filter_out_linked_records($rel_list, $lhs_field, $operator, $rhs_value){
	
		$new_rel_list = array();
		$jam = array();
	
	foreach($rel_list as $key => $rel_object){
		echo "KEY".$key."REL_OBJECT".$rel_object->id."RHS".$rhs_value."HMM".$rel_object->$lhs_field."<BR>";
		if(compare_values($rel_object, $lhs_field, $operator, $rhs_value)===false){
			unset($rel_list[$key]);
		}	
	}
	$rel_list = array_values($rel_list);
	return $rel_list;
	
	
//end function filter_out_linked_records
}	

function compare_values(& $target_object, $lhs_field, $operator, $rhs_value){
	echo "VALU".$rhs_value;
	if($rhs_value=="bool_true" || $rhs_value=="bool_false"){
		return compare_bool_values($target_object, $lhs_field, $operator, $rhs_value);
	}
	if($operator=="="){
		if($target_object->$lhs_field == $rhs_value) return true;
	}
	if($operator=="!="){
		if($target_object->$lhs_field != $rhs_value) return true;	
	}	
	if($operator=="<"){
		if($target_object->$lhs_field < $rhs_value) return true;
	}
	if($operator==">"){
		if($target_object->$lhs_field > $rhs_value) return true;
	}
	
		return false;
	
//end function compare_values
}	

function compare_bool_values(& $target_object, $lhs_field, $operator, $rhs_value){
		
	if($rhs_value == "bool_true"){
		echo $target_object->$lhs_field;
			if(
			$target_object->$lhs_field == "on" || 
			$target_object->$lhs_field==1 ||
			$target_object->$lhs_field==true
			 ) return true;
		} 
		if($rhs_value == "bool_false"){
			if(
			$target_object->$lhs_field == "off" || 
			$target_object->$lhs_field==0 ||
			$target_object->$lhs_field==false
			 ) return true;
		}		
		
		return false;
		
//end function compare_bool_values
}

function convert_bool($value){

	if($value=="bool_true"){
		return "on";
	}
	if($value=="bool_false"){
		return "off";
	}
		return $value;	
	
//end function convert_bool
}



function build_filter_where($table_name, $where, $filter_array){
	
	if($where!=""){
		$where .= " AND ";	
	}	
	
	//field
	$where .= $table_name.".".$filter_array['lhs_field']." ";
	
	//operator
	$where .= translate_operator($filter_array['operator'], "sql");
	
	//value
	$where .= "'".$filter_array['rhs_value']."'";
	
	return $where;
	
//end function build_filter_where
}	



function compare_values_number($lhs_field, $operator, $rhs_value){
	
	if($operator=="="){
		if($lhs_field == $rhs_value) return true;
	}
	if($operator=="!="){
		if($lhs_field != $rhs_value) return true;	
	}	
	if($operator=="<"){
		if($lhs_field < $rhs_value) return true;
	}
	if($operator==">"){
		if($lhs_field > $rhs_value) return true;
	}

		return false;
	
//end function compare_values
}	

?>
