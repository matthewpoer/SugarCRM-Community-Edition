<?php

/**
 * This method fires the business logic for the current module.
 */
function process_business_logic(&$this, $logic_hook=false)
{

    // Look for the current file in the module folder.
    // If the file is there, call it.



















	//end function process_business_logic
}
	
//End Business Logic	
?>
