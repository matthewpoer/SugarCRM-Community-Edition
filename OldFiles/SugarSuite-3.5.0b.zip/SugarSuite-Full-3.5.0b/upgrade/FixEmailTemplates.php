<?php
if( !is_file( "config.php" ) ){
    // running directly, not from index.php
    chdir( ".." );
}
require_once("config.php");
require_once("include/database/PearDatabase.php");

$db = PearDatabase::getInstance();
$result = $db->query("UPDATE email_templates SET body_html = body");

echo "<br>Email Templates Corrected.<br><br>";
?>
